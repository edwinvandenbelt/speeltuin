"""
prepare_runner.py — CLI entry point for the GMT preparation pipeline.

Usage
-----
    python -m prepare.prepare_runner <minLon> <minLat> <maxLon> <maxLat> \\
        <MODE> [<MODE> ...] <NAME> <OUT_DIR> [--mode-label LABEL] \\
        [--refresh] [--debug] \\
        [--catalog CATALOG] [--schema SCHEMA] \\
        [--repair-gaps] [--nvp-table TABLE --nvp-year YEAR] \\
        [--w-mrh HOURS] [--w-erh HOURS] [--w-rest HOURS] \\
        [--export-geojson] \\
        [--annotate-traffic-signals] [--signal-tolerance-m METRES] [--signal-overpass-timeout SECONDS] \\
        [--network-max-speed KM_H] [--network-max-flow PAE_PER_DAY] \\
        [--no-osm | --only-osm]

OSM modes (mutually exclusive)
------------------------------
    --no-osm    Run the full pipeline but skip every OSM/Overpass-dependent
                enrichment (traffic signals, OSM assets, buildings; parking
                falls back to BGT-only; traffic signs run only when NDW data
                is available).
    --only-osm  Take an EXISTING prepared area and (re)generate only the OSM
                asset enrichment (stage 05), rewriting the NETWORK trafficSignal
                flags, TRAFFIC-ASSETS and BUILDINGS outputs.  All Databricks
                stages are skipped; zones/feedlinks/routes are left untouched.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Ensure src/ is on sys.path when run directly (not via -m from repo root).
_RUNNER_FILE = Path(__file__).resolve()
_REPO_ROOT = _RUNNER_FILE.parent.parent.parent  # src/prepare/ -> repo root
_SRC_DIR = str(_REPO_ROOT / "src")
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

from prepare.core.prepare_core import run_pipeline  # noqa: E402


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


def _resolve_out_dir(raw: str) -> Path:
    """Return an absolute Path for OUT_DIR, relative to repo root if not absolute."""
    p = Path(raw)
    if p.is_absolute():
        return p
    return _REPO_ROOT / raw


def main() -> None:
    parser = argparse.ArgumentParser(description="GMT preparation pipeline — 10 fixed steps.")
    parser.add_argument("min_lon", type=float, help="Western bbox boundary (decimal degrees).")
    parser.add_argument("min_lat", type=float, help="Southern bbox boundary (decimal degrees).")
    parser.add_argument("max_lon", type=float, help="Eastern bbox boundary (decimal degrees).")
    parser.add_argument("max_lat", type=float, help="Northern bbox boundary (decimal degrees).")
    parser.add_argument(
        "modes",
        nargs="+",
        metavar="MODE",
        help=(
            "One or more transport modes, e.g. CAR BIKE.  "
            "PEDESTRIAN cannot be combined with other modes."
        ),
    )
    parser.add_argument("name", help="Human-readable area name passed to network_fetcher.")
    parser.add_argument("out_dir", help="Output directory (relative to repo root or absolute).")
    parser.add_argument("--refresh", action="store_true", help="Overwrite existing output files.")
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Copy outputs after each step to STEP_x_… snapshot files.",
    )
    parser.add_argument(
        "--catalog", default="spectrum", help="Databricks Unity Catalog name.  Default: spectrum."
    )
    parser.add_argument(
        "--schema",
        default="2024_01",
        help="Databricks schema / dataset version.  Default: 2024_01.",
    )
    parser.add_argument(
        "--max-routes",
        type=int,
        default=2,
        metavar="N",
        help="Maximum k-shortest routes per OD pair for matrix_builder (step 10). Default: 2.",
    )
    parser.add_argument(
        "--exclude-zones",
        nargs="+",
        default=[],
        metavar="ZONE_ID",
        help="One or more zoneId values to exclude from the zone fetch (step 1).",
    )
    parser.add_argument(
        "--nvp-table",
        default=None,
        metavar="TABLE",
        help=(
            "(Optional) Fully qualified Databricks NVP table name for step 7.5, "
            "e.g. nvp_experimental.silver.vw_segments.  "
            "When omitted, step 7.5 is skipped entirely."
        ),
    )
    parser.add_argument(
        "--nvp-year",
        type=int,
        default=None,
        metavar="YEAR",
        help=(
            "NVP location_year value to filter on (e.g. 2025).  Required when --nvp-table is set."
        ),
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="UUID",
        help=(
            "Pin the area UUID instead of auto-discovering it from existing files.  "
            "Useful when you want to re-use a specific ID for a new output folder."
        ),
    )
    parser.add_argument(
        "--mode-label",
        default=None,
        metavar="LABEL",
        help=(
            "External label used in output filenames, e.g. MIXED.  "
            "Defaults to MIXED when more than one mode is given, or the single mode name otherwise.  "
            "Must not contain a hyphen."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        metavar="PATH",
        help="Path to .env file for Databricks + AWS credentials (auto-discovered if omitted).",
    )
    parser.add_argument(
        "--w-mrh",
        type=float,
        default=2.0,
        metavar="HOURS",
        help="ETM hour-weight for ochtendspits passed to network_fetcher (default: 2.0).",
    )
    parser.add_argument(
        "--w-erh",
        type=float,
        default=2.0,
        metavar="HOURS",
        help="ETM hour-weight for avondspits passed to network_fetcher (default: 2.0).",
    )
    parser.add_argument(
        "--w-rest",
        type=float,
        default=13.72,
        metavar="HOURS",
        help="ETM hour-weight voor restdag doorgegeven aan network_fetcher (default: 20.0).",
    )
    parser.add_argument(
        "--export-geojson",
        action="store_true",
        help=("Schrijf het finale network parquet ook als .geojson weg naast het parquet bestand."),
    )
    parser.add_argument(
        "--annotate-traffic-signals",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Query Overpass for OSM traffic-signal nodes, set a trafficSignal boolean on "
            "every network link, and add signal point assets to the TRAFFIC-ASSETS parquet. "
            "Default: enabled (use --no-annotate-traffic-signals to disable).  Requires internet."
        ),
    )
    parser.add_argument(
        "--fetch-traffic-signs",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Fetch traffic-sign point assets (NDW in the Netherlands, otherwise OSM Overpass) "
            "and add them to the TRAFFIC-ASSETS parquet. "
            "Default: enabled (use --no-fetch-traffic-signs to disable)."
        ),
    )
    parser.add_argument(
        "--ndw-data-uri",
        default=None,
        metavar="URI",
        help=(
            "URI of the pre-provisioned NDW traffic-signs GeoJSON dataset (never downloaded). "
            "Used only when --fetch-traffic-signs is enabled and the bbox lies in the Netherlands."
        ),
    )
    parser.add_argument(
        "--fetch-bgt-assets",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Fetch BGT speed-bump polygons (verkeersdrempels) from the PDOK OGC API and add "
            "them to the TRAFFIC-ASSETS parquet. Netherlands only. "
            "Default: enabled (use --no-fetch-bgt-assets to disable)."
        ),
    )
    parser.add_argument(
        "--bgt-url",
        default=None,
        metavar="URL",
        help="BGT OGC API Features base URL (default: PDOK_BGT_URL env var or public PDOK BGT).",
    )
    parser.add_argument(
        "--fetch-osm-assets",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Fetch OSM traffic objects (crossings, speed bumps, stop/give-way signs, "
            "mini-roundabouts) from Overpass and add them to the TRAFFIC-ASSETS parquet. "
            "When BGT is also enabled, speed bumps are excluded here to avoid duplicates. "
            "Default: enabled (use --no-fetch-osm-assets to disable)."
        ),
    )
    parser.add_argument(
        "--buildings",
        dest="fetch_buildings",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Fetch OSM buildings (footprints + use classification) from Overpass and "
            "write them to a separate {area_id}-BUILDINGS.parquet. Large areas are "
            "fetched in tiles and merged. Default: enabled (use --no-buildings to disable)."
        ),
    )
    parser.add_argument(
        "--vegetation",
        dest="fetch_vegetation",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Fetch OSM vegetation (trees, tree rows, shrubs, and wood / forest / scrub / "
            "grass areas) from Overpass and write them to a separate "
            "{area_id}-VEGETATION.parquet. Best-effort: failures are logged and the "
            "pipeline continues. Default: enabled (use --no-vegetation to disable)."
        ),
    )
    parser.add_argument(
        "--parking-areas",
        dest="fetch_parking_areas",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Fetch parking areas (parkeervlakken) as polygons and add them to the "
            "TRAFFIC-ASSETS parquet with assetType='parkingArea'. BGT is used inside the "
            "Netherlands, OSM everywhere. The OSM leg is fail-safe. "
            "Default: enabled (use --no-parking-areas to disable)."
        ),
    )
    parser.add_argument(
        "--signal-tolerance-m",
        type=float,
        default=15.0,
        metavar="METRES",
        help=(
            "Maximum distance in metres from a link toNode to the nearest OSM traffic-signal "
            "node to be considered signalised (default: 15.0)."
        ),
    )
    parser.add_argument(
        "--signal-overpass-timeout",
        type=int,
        default=60,
        metavar="SECONDS",
        help="HTTP + server-side timeout in seconds for the Overpass API request (default: 60).",
    )
    parser.add_argument(
        "--osm-path",
        dest="osm_path",
        default=None,
        metavar="PATH",
        help=(
            "Path to a local .osm.pbf extract to read instead of querying the "
            "Overpass HTTP API. Falls back to the OSM_PBF_PATH environment "
            "variable / .env when omitted."
        ),
    )
    parser.add_argument(
        "--osm-workers",
        dest="osm_workers",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Worker processes for reading the local .osm.pbf extract. Defaults "
            "to the OSM_PBF_WORKERS environment variable / CPU count (capped at 8)."
        ),
    )
    parser.add_argument(
        "--network-max-speed",
        type=float,
        default=None,
        metavar="KM_H",
        help=(
            "Exclude network links whose maximum design speed exceeds this value (km/h). "
            "Use e.g. 90 to remove motorways.  Default: no filter."
        ),
    )
    parser.add_argument(
        "--network-max-flow",
        type=float,
        default=None,
        metavar="PAE_PER_DAY",
        help=(
            "Exclude network links whose total 24-hr ETM flow exceeds this value. "
            "Default: no filter."
        ),
    )
    osm_group = parser.add_mutually_exclusive_group()
    osm_group.add_argument(
        "--no-osm",
        action="store_true",
        help=(
            "Skip every OSM/Overpass-dependent enrichment: traffic signals, OSM "
            "assets and buildings are disabled, parking falls back to BGT-only, and "
            "traffic signs run only when NDW data is available. "
            "Mutually exclusive with --only-osm."
        ),
    )
    osm_group.add_argument(
        "--only-osm",
        action="store_true",
        help=(
            "Take an EXISTING prepared area and (re)generate only the OSM asset "
            "enrichment (stage 05): rewrites NETWORK trafficSignal flags, "
            "TRAFFIC-ASSETS and BUILDINGS. All Databricks stages are skipped. "
            "Mutually exclusive with --no-osm."
        ),
    )
    args = parser.parse_args()

    # Load credentials from .env (auto-discover tools/.env walking up from the runner file).
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    os.environ.setdefault("PYTHONPATH", _SRC_DIR)

    run_pipeline(
        min_lon=args.min_lon,
        min_lat=args.min_lat,
        max_lon=args.max_lon,
        max_lat=args.max_lat,
        modes=args.modes,
        name=args.name,
        out_dir=_resolve_out_dir(args.out_dir),
        mode_label=args.mode_label or None,
        catalog=args.catalog,
        schema=args.schema,
        refresh=args.refresh,
        debug=args.debug,
        exclude_zones=args.exclude_zones or None,
        max_routes=args.max_routes,
        nvp_table=args.nvp_table or None,
        nvp_year=args.nvp_year,
        area_id=args.area_id or None,
        w_mrh=args.w_mrh,
        w_erh=args.w_erh,
        w_rest=args.w_rest,
        export_geojson=args.export_geojson,
        annotate_traffic_signals=args.annotate_traffic_signals,
        fetch_traffic_signs=args.fetch_traffic_signs,
        ndw_data_uri=args.ndw_data_uri or None,
        fetch_bgt_assets=args.fetch_bgt_assets,
        bgt_url=args.bgt_url or None,
        fetch_osm_assets=args.fetch_osm_assets,
        fetch_parking_areas=args.fetch_parking_areas,
        fetch_buildings=args.fetch_buildings,
        fetch_vegetation=args.fetch_vegetation,
        signal_tolerance_m=args.signal_tolerance_m,
        signal_overpass_timeout=args.signal_overpass_timeout,
        network_max_speed_kmh=args.network_max_speed,
        network_max_flow=args.network_max_flow,
        no_osm=args.no_osm,
        only_osm=args.only_osm,
        osm_path=args.osm_path,
        osm_workers=args.osm_workers,
    )


if __name__ == "__main__":
    main()
