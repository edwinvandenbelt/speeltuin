"""Pure-Python osm_asset_fetcher core — fetches traffic objects from OSM.

Fetches point-based traffic objects for a bounding box from the OpenStreetMap
Overpass API and returns them as a GeoJSON point ``FeatureCollection``.  Every
feature is tagged ``properties.assetType`` (camelCase) so the result can be
merged into the combined ``{area_id}-TRAFFIC-ASSETS.parquet`` produced by the
prepare pipeline.

Unlike the Dutch BGT (which only covers the Netherlands and only usefully
registers speed bumps), OSM provides worldwide coverage of a range of traffic
objects encoded as node tags — most notably pedestrian crossings, stop /
give-way signs, mini-roundabouts and traffic-calming (speed) bumps.

Supported asset kinds
---------------------
Each *kind* maps an OSM tag match to an ``assetType`` value:

* ``pedestrianCrossing`` — ``highway=crossing``
* ``speedBump``          — ``traffic_calming=*`` (bump, hump, table, cushion …)
* ``stopSign``           — ``highway=stop``
* ``giveWay``            — ``highway=give_way``
* ``miniRoundabout``     — ``highway=mini_roundabout``
* ``mailbox``            — ``amenity=post_box``
* ``busShelter``         — ``amenity=shelter`` + ``shelter_type=public_transport``
  (node *or* way; ways are reduced to their centroid)
* ``mast``               — ``man_made=mast``
* ``bikeGate``           — ``barrier=cycle_barrier``
* ``infoBoard``          — ``information=board``
* ``trashBin``           — ``amenity=waste_basket``
* ``busStop``            — ``highway=bus_stop``

The set of kinds fetched is configurable (see :func:`fetch_osm_assets`), so the
prepare pipeline can exclude ``speedBump`` in the Netherlands where BGT already
provides authoritative verkeersdrempels.

Public API
----------
classify_element(tags, kinds) -> str | None
    Return the assetType for an OSM element's tags, or None when it matches none
    of the requested kinds.
overpass_query_for_bbox(bbox, kinds, timeout) -> str
    Build an Overpass QL query for the requested kinds inside *bbox*.
elements_to_asset_features(elements, kinds) -> list[dict]
    Convert raw Overpass node elements to GeoJSON asset Feature dicts.
fetch_osm_assets(bbox, *, kinds, tiles, timeout) -> tuple[dict, dict]
    High-level entry: fetch + classify + tag, return (fc, stats).
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached OSM asset output.
OSM_ASSET_QUERY_VER: int = 3

#: Default NxN tile grid for Overpass fetches.
OVERPASS_GRID: int = 3

#: Asset-type tags (camelCase) written on produced features.
KIND_PEDESTRIAN_CROSSING: str = "pedestrianCrossing"
KIND_SPEED_BUMP: str = "speedBump"
KIND_STOP_SIGN: str = "stopSign"
KIND_GIVE_WAY: str = "giveWay"
KIND_MINI_ROUNDABOUT: str = "miniRoundabout"
KIND_MAILBOX: str = "mailbox"
KIND_BUS_SHELTER: str = "busShelter"
KIND_MAST: str = "mast"
KIND_BIKE_GATE: str = "bikeGate"
KIND_INFO_BOARD: str = "infoBoard"
KIND_TRASH_BIN: str = "trashBin"
KIND_BUS_STOP: str = "busStop"

#: Mapping of assetType -> Overpass tag filter clause (the part inside the
#: ``node[...]`` selector).  A leading ``~`` value means "any value" for that
#: key (encoded as a key-only selector in the query).  Multi-tag matches chain
#: additional ``][`` bracket clauses inside the same selector (logical AND).
_KIND_TAG_FILTERS: dict[str, str] = {
    KIND_PEDESTRIAN_CROSSING: '"highway"="crossing"',
    KIND_SPEED_BUMP: '"traffic_calming"',
    KIND_STOP_SIGN: '"highway"="stop"',
    KIND_GIVE_WAY: '"highway"="give_way"',
    KIND_MINI_ROUNDABOUT: '"highway"="mini_roundabout"',
    KIND_MAILBOX: '"amenity"="post_box"',
    KIND_BUS_SHELTER: '"amenity"="shelter"]["shelter_type"="public_transport"',
    KIND_MAST: '"man_made"="mast"',
    KIND_BIKE_GATE: '"barrier"="cycle_barrier"',
    KIND_INFO_BOARD: '"information"="board"',
    KIND_TRASH_BIN: '"amenity"="waste_basket"',
    KIND_BUS_STOP: '"highway"="bus_stop"',
}

#: Default kinds fetched when the caller does not restrict them.
DEFAULT_KINDS: list[str] = [
    KIND_PEDESTRIAN_CROSSING,
    KIND_SPEED_BUMP,
    KIND_STOP_SIGN,
    KIND_GIVE_WAY,
    KIND_MINI_ROUNDABOUT,
    KIND_MAILBOX,
    KIND_BUS_SHELTER,
    KIND_MAST,
    KIND_BIKE_GATE,
    KIND_INFO_BOARD,
    KIND_TRASH_BIN,
    KIND_BUS_STOP,
]

#: Kinds that may also be mapped as OSM *ways* / areas (not just nodes).  For
#: these, the query emits an extra ``way[...]`` selector and matching ways are
#: reduced to a representative centroid ``Point`` feature.  Bus shelters (abris)
#: are commonly drawn as small building-like areas rather than single nodes.
_WAY_KINDS: frozenset[str] = frozenset({KIND_BUS_SHELTER})


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------


def classify_element(tags: dict, kinds: list[str]) -> str | None:
    """Return the ``assetType`` for an OSM element's *tags*, or ``None``.

    The requested *kinds* are evaluated in order and the first match wins, so
    the caller controls precedence.  Only kinds present in *kinds* are ever
    returned.

    Parameters
    ----------
    tags:
        The ``tags`` dict of an Overpass node element.
    kinds:
        The list of assetType kinds to consider (see module constants).
    """
    for kind in kinds:
        if kind == KIND_PEDESTRIAN_CROSSING and tags.get("highway") == "crossing":
            return kind
        if kind == KIND_SPEED_BUMP and "traffic_calming" in tags:
            return kind
        if kind == KIND_STOP_SIGN and tags.get("highway") == "stop":
            return kind
        if kind == KIND_GIVE_WAY and tags.get("highway") == "give_way":
            return kind
        if kind == KIND_MINI_ROUNDABOUT and tags.get("highway") == "mini_roundabout":
            return kind
        if kind == KIND_MAILBOX and tags.get("amenity") == "post_box":
            return kind
        if (
            kind == KIND_BUS_SHELTER
            and tags.get("amenity") == "shelter"
            and tags.get("shelter_type") == "public_transport"
        ):
            return kind
        if kind == KIND_MAST and tags.get("man_made") == "mast":
            return kind
        if kind == KIND_BIKE_GATE and tags.get("barrier") == "cycle_barrier":
            return kind
        if kind == KIND_INFO_BOARD and tags.get("information") == "board":
            return kind
        if kind == KIND_TRASH_BIN and tags.get("amenity") == "waste_basket":
            return kind
        if kind == KIND_BUS_STOP and tags.get("highway") == "bus_stop":
            return kind
    return None


# ---------------------------------------------------------------------------
# Overpass query + parsing
# ---------------------------------------------------------------------------


def overpass_query_for_bbox(
    bbox: list[float],
    kinds: list[str],
    timeout: int = 40,
) -> str:
    """Build an Overpass QL query for the requested *kinds* inside *bbox*.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    kinds:
        The list of assetType kinds to fetch.  Unknown kinds are ignored.
    timeout:
        Overpass server-side timeout in seconds.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    # Overpass uses (south, west, north, east) coordinate order.
    coord_str = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    clauses: list[str] = []
    for kind in kinds:
        tag_filter = _KIND_TAG_FILTERS.get(kind)
        if tag_filter is None:
            continue
        clauses.append(f"node[{tag_filter}]({coord_str});")
        if kind in _WAY_KINDS:
            clauses.append(f"way[{tag_filter}]({coord_str});")
    body = "\n  ".join(clauses)
    # ``out geom;`` includes node lat/lon *and* full way geometry, so way-based
    # kinds (e.g. bus shelters) can be reduced to a centroid client-side.
    return f"[out:json][timeout:{timeout}];\n(\n  {body}\n);\nout geom;"


def _way_centroid(geometry: list[dict]) -> tuple[float, float] | None:
    """Return the ``(lon, lat)`` centroid of an Overpass ``out geom;`` way.

    *geometry* is the list of ``{"lat": .., "lon": ..}`` vertices attached to a
    way element.  Returns ``None`` when there are no usable vertices.  For a
    closed ring the duplicated closing vertex is dropped so it does not bias the
    average.
    """
    pts = [(float(p["lon"]), float(p["lat"])) for p in geometry if "lat" in p and "lon" in p]
    if len(pts) >= 2 and pts[0] == pts[-1]:
        pts = pts[:-1]
    if not pts:
        return None
    lon = sum(p[0] for p in pts) / len(pts)
    lat = sum(p[1] for p in pts) / len(pts)
    return lon, lat


def elements_to_asset_features(elements: list[dict], kinds: list[str]) -> list[dict]:
    """Convert raw Overpass elements to GeoJSON asset Feature dicts.

    Each element is classified via :func:`classify_element`; elements that match
    none of the requested *kinds* are skipped.  Every produced feature is a
    ``Point`` tagged ``properties.assetType``.

    ``node`` elements use their own coordinate.  ``way`` elements (only relevant
    for :data:`_WAY_KINDS`, e.g. bus-shelter abris drawn as small areas) are
    reduced to their centroid so they fit the point-based traffic-asset model.
    """
    features: list[dict] = []
    for elem in elements:
        etype = elem.get("type")
        tags = elem.get("tags") or {}
        asset_type = classify_element(tags, kinds)
        if asset_type is None:
            continue
        if etype == "node":
            lat = elem.get("lat")
            lon = elem.get("lon")
            if lat is None or lon is None:
                continue
            coords = [lon, lat]
        elif etype == "way" and asset_type in _WAY_KINDS:
            centroid = _way_centroid(elem.get("geometry") or [])
            if centroid is None:
                continue
            coords = [centroid[0], centroid[1]]
        else:
            continue
        props = {
            **tags,
            "osm_id": elem.get("id"),
            "assetType": asset_type,
        }
        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": coords},
                "properties": props,
            }
        )
    return features


# ---------------------------------------------------------------------------
# High-level entry point
# ---------------------------------------------------------------------------


def fetch_osm_assets(
    bbox: list[float],
    *,
    kinds: list[str] | None = None,
    tiles: int = OVERPASS_GRID,
    timeout: int = 40,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> tuple[dict, dict]:
    """Fetch OSM traffic objects for *bbox* via the shared Overpass client.

    Uses the repository's shared :mod:`shared.overpass` client, which provides
    on-disk caching, retries and rate-limit handling.  The bbox is split into a
    ``tiles x tiles`` grid to keep individual requests small.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    kinds:
        The assetType kinds to fetch.  Defaults to :data:`DEFAULT_KINDS`.
    tiles:
        NxN Overpass tile grid.
    timeout:
        Overpass HTTP + server-side timeout in seconds.

    Returns
    -------
    fc:
        A GeoJSON ``FeatureCollection`` of OSM traffic-object point features,
        each tagged ``properties.assetType``.
    stats:
        ``{"counts": dict[str, int], "total": int, "source": str}``.  ``counts``
        maps each assetType to the number of features produced.
    """
    from shared.overpass import fetch_overpass_tiled  # noqa: PLC0415

    active_kinds = list(kinds) if kinds is not None else list(DEFAULT_KINDS)

    if not active_kinds:
        logger.info("No OSM asset kinds requested — skipping fetch.")
        return (
            {
                "type": "FeatureCollection",
                "features": [],
                "properties": {"_qv": OSM_ASSET_QUERY_VER, "source": "skipped"},
            },
            {"counts": {}, "total": 0, "source": "skipped"},
        )

    logger.info("Fetching OSM assets %s from Overpass (tiles=%dx%d).", active_kinds, tiles, tiles)
    response = fetch_overpass_tiled(
        lambda b: overpass_query_for_bbox(b, active_kinds, timeout=timeout),
        bbox,
        tiles=(tiles, tiles),
        timeout=timeout,
        osm_path=osm_path,
        osm_workers=osm_workers,
    )
    features = elements_to_asset_features(response.get("elements") or [], active_kinds)

    counts: dict[str, int] = dict.fromkeys(active_kinds, 0)
    for feat in features:
        counts[feat["properties"]["assetType"]] += 1

    logger.info("Fetched %d OSM asset features (counts=%s).", len(features), counts)
    fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"_qv": OSM_ASSET_QUERY_VER, "source": "OSM"},
    }
    stats = {"counts": counts, "total": len(features), "source": "OSM"}
    return fc, stats
