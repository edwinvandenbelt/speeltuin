# Databricks notebook source
# ---------------------------------------------------------------------------
# emission_estimator_nb.py - Databricks notebook interface.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads an input network GeoParquet (with the traffic-flow schema).
#   3. Computes per-link air-pollutant emissions via the pure core
#      (stage 1 fast, or stage 2 detailed).
#   4. Optionally writes the emission-enriched network as GeoParquet.
#   5. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s - %(message)s")
logger = logging.getLogger("emission_estimator_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uri",
    "",
    "Input network GeoParquet URI (with flow24hrs/length schema)",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri",
    "",
    "Output GeoParquet URI for the emission-enriched network (empty = in-memory only)",
)
dbutils.widgets.dropdown(  # noqa: F821
    "model",
    "stage1",
    ["stage1", "stage2"],
    "Model: stage1 (fast) or stage2 (detailed)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from emission_estimator.core.emission_estimator_core import (  # noqa: E402, PLC0415
    estimate_emissions,
    estimate_emissions_detailed,
)

# COMMAND ----------
# Widget read + validation

NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()  # noqa: F821
MODEL = dbutils.widgets.get("model").strip()  # noqa: F821

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")

logger.info(
    "network_uri=%s  output_uri=%s  model=%s",
    NETWORK_URI,
    OUTPUT_URI or "(in-memory only)",
    MODEL,
)

# COMMAND ----------
# S3 helpers

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/vnd.apache.parquet",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    import os  # noqa: PLC0415

    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run EmissionEstimator
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# Main execution

from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402, PLC0415

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")

_fc = from_geoparquet(_read_uri(NETWORK_URI))
_fc_out = estimate_emissions_detailed(_fc) if MODEL == "stage2" else estimate_emissions(_fc)

_features = _fc_out.get("features") or []
_total_co2 = sum((_f.get("properties") or {}).get("co2Kg", 0.0) for _f in _features)

if OUTPUT_URI:
    _write_uri(OUTPUT_URI, to_geoparquet(_fc_out))

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# Results summary

_SEP = "-" * 60
print(_SEP)
print(f"EmissionEstimator complete - {_elapsed:.1f}s")
print(_SEP)
print(f"  Network URI    : {NETWORK_URI}")
print(f"  Output URI     : {OUTPUT_URI or '(in-memory only)'}")
print(f"  Model          : {MODEL}")
print(f"  Links          : {len(_features):,}")
print(f"  Total CO2      : {_total_co2:,.1f} kg/day")
print(_SEP)
