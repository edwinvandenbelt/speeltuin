# Databricks notebook source
# ---------------------------------------------------------------------------
# noise_estimator_nb.py - Databricks notebook interface (phase A).
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads an input network GeoParquet (with the traffic-flow schema).
#   3. Computes per-link road-traffic noise emission via the pure core.
#   4. Optionally writes the noise-enriched network as GeoParquet.
#   5. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("noise_estimator_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uri",
    "",
    "Input network GeoParquet URI (with flow24hrs/speed schema)",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri",
    "",
    "Output GeoParquet URI for the noise-enriched network (leave empty for in-memory only)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from noise_estimator.core.noise_estimator_core import (  # noqa: E402, PLC0415
    PROP_NOISE_LDEN,
    estimate_noise_emission,
)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()  # noqa: F821

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")

logger.info("network_uri=%s  output_uri=%s", NETWORK_URI, OUTPUT_URI or "(in-memory only)")

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/vnd.apache.parquet",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    import os  # noqa: PLC0415

    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run NoiseEstimator
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402, PLC0415

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")

_fc = from_geoparquet(_read_uri(NETWORK_URI))
_fc_out = estimate_noise_emission(_fc)

_features = _fc_out.get("features") or []
_with_lden = sum(
    1 for _f in _features if (_f.get("properties") or {}).get(PROP_NOISE_LDEN) is not None
)

if OUTPUT_URI:
    _write_uri(OUTPUT_URI, to_geoparquet(_fc_out))

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"NoiseEstimator complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Network URI    : {NETWORK_URI}")
print(f"  Output URI     : {OUTPUT_URI or '(in-memory only)'}")
print(f"  Links          : {len(_features):,}")
print(f"  With Lden      : {_with_lden:,}")
print(_SEP)
