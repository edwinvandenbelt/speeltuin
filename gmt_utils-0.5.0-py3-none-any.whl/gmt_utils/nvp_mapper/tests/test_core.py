"""Unit tests for nvp_mapper core and domain functions.

All tests are purely in-memory — no Databricks, no S3.
"""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# sys.path bootstrap — ensure src/ is importable when run with pytest from
# any working directory.
# ---------------------------------------------------------------------------

_HERE = Path(__file__).resolve()
for _parent in _HERE.parents:
    _src = _parent / "src"
    if _src.is_dir():
        if str(_src) not in sys.path:
            sys.path.insert(0, str(_src))
        break

import numpy as np
from gmt_shared.rd_projection import wgs84_to_rd

from gmt_utils.nvp_mapper.core.nvp_mapper_core import map_nvp_trips
from gmt_utils.nvp_mapper.domain.matching import (
    get_sublinks,
    get_trips_per_link,
    get_vertices,
    map1to2,
)

# ---------------------------------------------------------------------------
# Shared test fixtures
# ---------------------------------------------------------------------------


def _make_two_link_network() -> dict:
    """Minimal 2-link directed network in WGS-84 around Deventer.

    Link 1001: eastward  (6.15, 52.25) → (6.155, 52.25)
    Link 1002: westward  (6.155, 52.25) → (6.15, 52.25)
    """
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[6.15, 52.25], [6.155, 52.25]],
                },
                "properties": {"linkId": 1001, "fromNode": 1, "toNode": 2},
            },
            {
                "type": "Feature",
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[6.155, 52.25], [6.15, 52.25]],
                },
                "properties": {"linkId": 1002, "fromNode": 2, "toNode": 1},
            },
        ],
        "properties": {},
    }


def _empty_nvp_arrays():
    """Return four empty NVP arrays (links, vertlengths, vertxys, vertdxys)."""
    return (
        np.empty((0, 3), dtype=object),
        np.array([]),
        np.empty((0, 2), dtype=float),
        np.empty((0, 2), dtype=float),
    )


# ---------------------------------------------------------------------------
# get_vertices
# ---------------------------------------------------------------------------


class TestGetVertices:
    def test_single_segment_link(self):
        links = np.array([0])
        xys = [[[0.0, 0.0], [10.0, 0.0]]]
        vertlinks, vertlengths, _vertxys1, vertdxys = get_vertices(links, xys)
        assert len(vertlinks) == 1
        assert vertlengths[0] == pytest.approx(10.0)
        assert vertdxys[0, 0] == pytest.approx(1.0)
        assert vertdxys[0, 1] == pytest.approx(0.0)

    def test_multi_segment_link(self):
        """A 3-point polyline produces 2 vertex segments."""
        links = np.array([0])
        xys = [[[0.0, 0.0], [5.0, 0.0], [10.0, 0.0]]]
        vertlinks, _vertlengths, _vertxys1, _vertdxys = get_vertices(links, xys)
        assert len(vertlinks) == 2

    def test_degenerate_segment_skipped(self):
        """A zero-length segment (duplicate point) is not emitted."""
        links = np.array([0])
        xys = [[[0.0, 0.0], [0.0, 0.0], [5.0, 0.0]]]  # first segment is zero-length
        vertlinks, vertlengths, _vertxys1, _vertdxys = get_vertices(links, xys)
        assert len(vertlinks) == 1
        assert vertlengths[0] == pytest.approx(5.0)


# ---------------------------------------------------------------------------
# get_sublinks
# ---------------------------------------------------------------------------


class TestGetSublinks:
    def test_output_shape(self):
        """A 10 m vertex with maxlength=5 produces 3 sub-links (int(10/5)+1)."""
        vertlinks = np.array([0])
        vertlengths = np.array([10.0])
        vertxys1 = np.array([[0.0, 0.0]])
        vertdxys = np.array([[1.0, 0.0]])
        sublinks, sublengths, subxys, subdxys = get_sublinks(
            vertlinks, vertlengths, vertxys1, vertdxys, maxlength_sublink=5.0
        )
        assert len(sublinks) == 3
        assert len(sublengths) == 3
        assert subxys.shape == (3, 2)
        assert subdxys.shape == (3, 2)

    def test_sublength_sum_equals_vertlength(self):
        vertlinks = np.array([0])
        vertlengths = np.array([9.0])
        vertxys1 = np.array([[0.0, 0.0]])
        vertdxys = np.array([[1.0, 0.0]])
        _sublinks, sublengths, _, _ = get_sublinks(
            vertlinks, vertlengths, vertxys1, vertdxys, maxlength_sublink=5.0
        )
        assert abs(np.sum(sublengths) - 9.0) < 1e-9

    def test_short_vertex_produces_one_sublink(self):
        """A vertex shorter than maxlength produces exactly 1 sub-link."""
        vertlinks = np.array([0])
        vertlengths = np.array([3.0])
        vertxys1 = np.array([[0.0, 0.0]])
        vertdxys = np.array([[0.0, 1.0]])
        sublinks, sublengths, _, _ = get_sublinks(
            vertlinks, vertlengths, vertxys1, vertdxys, maxlength_sublink=5.0
        )
        assert len(sublinks) == 1
        assert sublengths[0] == pytest.approx(3.0)

    def test_centroid_position(self):
        """Sub-link centroids are at the midpoints of the sub-segments."""
        vertlinks = np.array([0])
        vertlengths = np.array([10.0])
        vertxys1 = np.array([[0.0, 0.0]])
        vertdxys = np.array([[1.0, 0.0]])
        _, _, subxys, _ = get_sublinks(
            vertlinks, vertlengths, vertxys1, vertdxys, maxlength_sublink=5.0
        )
        # 3 sub-links of 10/3 m each; centroids at 0.5/3, 1.5/3, 2.5/3 × 10
        sub_len = 10.0 / 3
        assert subxys[0, 0] == pytest.approx(sub_len * 0.5, rel=1e-6)
        assert subxys[1, 0] == pytest.approx(sub_len * 1.5, rel=1e-6)
        assert subxys[2, 0] == pytest.approx(sub_len * 2.5, rel=1e-6)

    def test_direction_vectors_preserved(self):
        """Direction vectors are identical across all sub-links of the same vertex."""
        vertlinks = np.array([0])
        vertlengths = np.array([10.0])
        vertxys1 = np.array([[0.0, 0.0]])
        vertdxys = np.array([[0.6, 0.8]])  # non-trivial unit vector
        _, _, _, subdxys = get_sublinks(
            vertlinks, vertlengths, vertxys1, vertdxys, maxlength_sublink=5.0
        )
        for row in subdxys:
            assert row[0] == pytest.approx(0.6)
            assert row[1] == pytest.approx(0.8)


# ---------------------------------------------------------------------------
# map1to2
# ---------------------------------------------------------------------------


class TestMap1to2:
    """Tests for the k-NN sub-link matching function."""

    def _single_link_pair(self, offset_y: float, angle_deg: float = 0.0):
        """Two 1-sub-link networks; network 2 offset in y and rotated by angle_deg.

        A far-away dummy point is added to network 2 so that KDTree2D's adaptive
        cell_size is large enough for the ring-search to reach the candidate
        (works around the guard ``r > 2*ceil(sqrt(N))+1`` that fires when N=1).
        """
        import math

        links1 = np.array([0])
        sublinks1 = np.array([0])
        subxys1 = np.array([[0.0, 0.0]])
        subdxys1 = np.array([[1.0, 0.0]])

        angle_rad = angle_deg * math.pi / 180
        # Real candidate at (0, offset_y) + far-away dummy at (0, 1e6).
        # The large span inflates cell_size so both points land in the same or
        # adjacent cells and are found within r=1.
        np.array([0, 99])
        sublinks2 = np.array([0, 99])
        subxys2 = np.array([[0.0, offset_y], [0.0, 1e6]])
        subdxys2 = np.array([[math.cos(angle_rad), math.sin(angle_rad)], [1.0, 0.0]])

        return links1, sublinks1, sublinks2, subxys1, subxys2, subdxys1, subdxys2

    def _call_map1to2(
        self,
        links1,
        sublinks1,
        sublinks2,
        subxys1,
        subxys2,
        subdxys1,
        subdxys2,
        maxdist=20.0,
        maxalpha=15.0,
    ):
        mapped = np.zeros(1, dtype=int)
        idx1, idx2 = map1to2(
            links1,
            sublinks1,
            sublinks2,
            subxys1,
            subxys2,
            subdxys1,
            subdxys2,
            mapped,
            maxlength_sublink=5.0,
            maxdist=maxdist,
            maxalpha=maxalpha,
            nnb=1,
            map_direction="same",
            map_on_self=False,
            use_parallel_distance=False,
        )
        return idx1, idx2

    def test_close_parallel_links_match(self):
        """Two parallel links 5 m apart should match with maxdist=20."""
        args = self._single_link_pair(offset_y=5.0)
        idx1, idx2 = self._call_map1to2(*args, maxdist=20.0, maxalpha=15.0)
        assert len(idx1) == 1
        assert len(idx2) == 1

    def test_distant_links_do_not_match(self):
        """Two links 50 m apart should NOT match with maxdist=20."""
        args = self._single_link_pair(offset_y=50.0)
        idx1, _idx2 = self._call_map1to2(*args, maxdist=20.0, maxalpha=15.0)
        assert len(idx1) == 0

    def test_perpendicular_links_do_not_match(self):
        """A perpendicular link (90°) should NOT match with maxalpha=15°."""
        args = self._single_link_pair(offset_y=5.0, angle_deg=90.0)
        idx1, _idx2 = self._call_map1to2(*args, maxdist=20.0, maxalpha=15.0)
        assert len(idx1) == 0

    def test_slightly_angled_links_match_within_tolerance(self):
        """A link rotated 10° should still match with maxalpha=15°."""
        args = self._single_link_pair(offset_y=5.0, angle_deg=10.0)
        idx1, _idx2 = self._call_map1to2(*args, maxdist=20.0, maxalpha=15.0)
        assert len(idx1) == 1

    def test_mapped_flag_prevents_double_matching(self):
        """A sub-link flagged as already mapped (mapped=1) is never re-matched."""
        links1 = np.array([0])
        sublinks1 = np.array([0])
        subxys1 = np.array([[0.0, 0.0]])
        subdxys1 = np.array([[1.0, 0.0]])
        # Two points in network 2 to ensure KDTree finds the candidate.
        np.array([0, 99])
        sublinks2 = np.array([0, 99])
        subxys2 = np.array([[0.0, 5.0], [0.0, 1e6]])
        subdxys2 = np.array([[1.0, 0.0], [1.0, 0.0]])

        mapped = np.ones(1, dtype=int)  # already marked as matched
        idx1, _idx2 = map1to2(
            links1,
            sublinks1,
            sublinks2,
            subxys1,
            subxys2,
            subdxys1,
            subdxys2,
            mapped,
            maxlength_sublink=5.0,
            maxdist=20.0,
            maxalpha=15.0,
            nnb=1,
            map_direction="same",
            map_on_self=False,
            use_parallel_distance=False,
        )
        assert len(idx1) == 0


# ---------------------------------------------------------------------------
# get_trips_per_link
# ---------------------------------------------------------------------------


class TestGetTripsPerLink:
    def test_trivial_trip_assignment(self):
        """A single Spectrum link matched to a single NVP link gets all its trips."""
        np.array([0, 0])  # both sub-links belong to Spectrum link 0
        sublengths2 = np.array([5.0, 5.0])
        tindex = {0: [0, 2]}  # segment spans sub-links 0..1 (indices 0–2)
        nvpmatch = {0: [[0]]}  # Spectrum link 0 → NVP link 0

        links1 = np.array([[100, 200, 0]], dtype=object)
        linktrips1 = {(100, 200, 0): ["trip-A", "trip-B"]}

        links2 = np.array([42], dtype=object)
        linklengths2 = [10.0]

        result = get_trips_per_link(
            tindex, nvpmatch, links1, linktrips1, links2, linklengths2, sublengths2
        )
        assert 42 in result
        # Both sub-links total 10 m = 100 % of link length → both trips qualify
        assert set(result[42].tolist()) == {"trip-A", "trip-B"}

    def test_no_match_gives_empty_array(self):
        """A Spectrum link absent from nvpmatch gets an empty trip array."""
        tindex = {}
        nvpmatch = {}
        links1 = np.array([[100, 200, 0]], dtype=object)
        linktrips1 = {(100, 200, 0): ["trip-A"]}
        links2 = np.array([999], dtype=object)
        linklengths2 = [10.0]
        sublengths2 = np.array([5.0, 5.0])

        result = get_trips_per_link(
            tindex, nvpmatch, links1, linktrips1, links2, linklengths2, sublengths2
        )
        assert 999 in result
        assert len(result[999]) == 0

    def test_integer_trip_ids_are_preserved(self):
        """Integer trip IDs (instead of strings) are stored as-is in the array."""
        np.array([0, 0])
        sublengths2 = np.array([5.0, 5.0])
        tindex = {0: [0, 2]}
        nvpmatch = {0: [[0]]}
        links1 = np.array([[1, 2, 0]], dtype=object)
        linktrips1 = {(1, 2, 0): [12345, 67890]}
        links2 = np.array([77], dtype=object)
        linklengths2 = [10.0]

        result = get_trips_per_link(
            tindex, nvpmatch, links1, linktrips1, links2, linklengths2, sublengths2
        )
        assert set(result[77].tolist()) == {12345, 67890}

    def test_short_segment_trip_filtered_out(self):
        """A trip whose mapped length is < 50 % of the Spectrum link is excluded."""
        # Spectrum link is 100 m; only 10 m of it is matched → below 50 % threshold
        np.array([0])  # 1 sub-link for link 0
        sublengths2 = np.array([10.0])
        tindex = {0: [0, 1]}
        nvpmatch = {0: [[0]]}
        links1 = np.array([[1, 2, 0]], dtype=object)
        linktrips1 = {(1, 2, 0): ["short-trip"]}
        links2 = np.array([55], dtype=object)
        linklengths2 = [100.0]  # long link; 10 m covered < 50 %

        result = get_trips_per_link(
            tindex, nvpmatch, links1, linktrips1, links2, linklengths2, sublengths2
        )
        assert 55 in result
        assert len(result[55]) == 0  # "short-trip" filtered out


# ---------------------------------------------------------------------------
# map_nvp_trips
# ---------------------------------------------------------------------------


class TestMapNvpTrips:
    """Integration tests for the public API of nvp_mapper_core."""

    # ── helpers ──────────────────────────────────────────────────────────────

    def _coincident_nvp(self):
        """NVP link exactly coincident with link 1001 (eastward)."""
        x1, y1 = wgs84_to_rd(6.15, 52.25)
        x2, y2 = wgs84_to_rd(6.155, 52.25)
        length = ((x2 - x1) ** 2 + (y2 - y1) ** 2) ** 0.5
        dx, dy = (x2 - x1) / length, (y2 - y1) / length
        return (
            np.array([[100, 200, 0]], dtype=object),
            np.array([length]),
            np.array([[x1, y1]]),
            np.array([[dx, dy]]),
        )

    # ── stats dict ───────────────────────────────────────────────────────────

    def test_stats_keys_present(self):
        """Stats dict must contain the expected keys."""
        network = _make_two_link_network()
        stats, _ = map_nvp_trips(network, *_empty_nvp_arrays(), linktrips1={})
        assert {"spectrum_links", "nvp_links", "matched_links", "match_rows"}.issubset(stats.keys())

    def test_spectrum_links_count_matches_features(self):
        """stats['spectrum_links'] equals the number of valid features in the network."""
        network = _make_two_link_network()
        stats, _ = map_nvp_trips(network, *_empty_nvp_arrays(), linktrips1={})
        assert stats["spectrum_links"] == len(network["features"])

    def test_empty_network_returns_zero_stats(self):
        """An empty FeatureCollection produces all-zero stats."""
        network = {"type": "FeatureCollection", "features": [], "properties": {}}
        stats, match_rows = map_nvp_trips(network, *_empty_nvp_arrays(), linktrips1={})
        assert stats["spectrum_links"] == 0
        assert stats["matched_links"] == 0
        assert match_rows == []

    def test_empty_nvp_gives_empty_match_rows(self):
        """With no NVP data, match_rows must be an empty list."""
        network = _make_two_link_network()
        stats, match_rows = map_nvp_trips(network, *_empty_nvp_arrays(), linktrips1={})
        assert match_rows == []
        assert stats["match_rows"] == 0

    # ── match_rows schema ────────────────────────────────────────────────────

    def test_match_rows_schema(self):
        """Every match row must have linkId (int), nvpLinkIds (list), nvpTripIds (list)."""
        network = _make_two_link_network()
        nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys = self._coincident_nvp()
        linktrips1 = {(100, 200, 0): ["trip-A"]}

        _stats, match_rows = map_nvp_trips(
            network,
            nvp_links=nvp_links,
            nvp_vertlengths=nvp_vertlengths,
            nvp_vertxys=nvp_vertxys,
            nvp_vertdxys=nvp_vertdxys,
            linktrips1=linktrips1,
            maxdist=1.0,
            fmatch12=0.3,
        )

        for row in match_rows:
            assert isinstance(row["linkId"], int)
            assert isinstance(row["nvpLinkIds"], list)
            assert isinstance(row["nvpTripIds"], list)

    def test_one_row_per_spectrum_link(self):
        """match_rows must contain at most one row per Spectrum linkId."""
        network = _make_two_link_network()
        nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys = self._coincident_nvp()
        linktrips1 = {(100, 200, 0): ["trip-A", "trip-B"]}

        _, match_rows = map_nvp_trips(
            network,
            nvp_links=nvp_links,
            nvp_vertlengths=nvp_vertlengths,
            nvp_vertxys=nvp_vertxys,
            nvp_vertdxys=nvp_vertdxys,
            linktrips1=linktrips1,
            maxdist=1.0,
            fmatch12=0.3,
        )

        link_ids = [row["linkId"] for row in match_rows]
        assert len(link_ids) == len(set(link_ids)), "Duplicate linkId in match_rows"

    def test_trip_ids_are_strings(self):
        """Integer trip IDs must be serialised as strings in nvpTripIds."""
        network = _make_two_link_network()
        nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys = self._coincident_nvp()
        linktrips1 = {(100, 200, 0): [11111, 22222]}  # integer trip IDs

        _, match_rows = map_nvp_trips(
            network,
            nvp_links=nvp_links,
            nvp_vertlengths=nvp_vertlengths,
            nvp_vertxys=nvp_vertxys,
            nvp_vertdxys=nvp_vertdxys,
            linktrips1=linktrips1,
            maxdist=1.0,
            fmatch12=0.3,
        )

        all_trip_ids = [tid for row in match_rows for tid in row["nvpTripIds"]]
        assert all_trip_ids, "Expected at least one trip ID"
        for tid in all_trip_ids:
            assert isinstance(tid, str), f"Expected str, got {type(tid)}: {tid!r}"

    def test_nvp_link_ids_are_strings(self):
        """nvpLinkIds entries must be strings in 'from_to_pair' format."""
        network = _make_two_link_network()
        nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys = self._coincident_nvp()
        linktrips1 = {(100, 200, 0): ["trip-A"]}

        _, match_rows = map_nvp_trips(
            network,
            nvp_links=nvp_links,
            nvp_vertlengths=nvp_vertlengths,
            nvp_vertxys=nvp_vertxys,
            nvp_vertdxys=nvp_vertdxys,
            linktrips1=linktrips1,
            maxdist=1.0,
            fmatch12=0.3,
        )

        all_nvp_ids = [nid for row in match_rows for nid in row["nvpLinkIds"]]
        assert all_nvp_ids, "Expected at least one nvpLinkId"
        for nid in all_nvp_ids:
            assert isinstance(nid, str)
            assert nid.count("_") == 2, f"Expected 'from_to_pair' format, got {nid!r}"

    def test_opposite_direction_link_not_matched(self):
        """Link 1002 (westward) must not appear in match_rows for an eastward NVP link."""
        network = _make_two_link_network()
        nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys = self._coincident_nvp()
        linktrips1 = {(100, 200, 0): ["trip-east"]}

        _, match_rows = map_nvp_trips(
            network,
            nvp_links=nvp_links,
            nvp_vertlengths=nvp_vertlengths,
            nvp_vertxys=nvp_vertxys,
            nvp_vertdxys=nvp_vertdxys,
            linktrips1=linktrips1,
            maxdist=1.0,
            maxalpha_forward1=10.0,
            fmatch12=0.3,
        )

        matched_ids = {row["linkId"] for row in match_rows}
        assert 1002 not in matched_ids, (
            "Westward link 1002 should not appear in match_rows for an eastward NVP link"
        )

    def test_network_not_modified(self):
        """map_nvp_trips must not add any fields to the NETWORK features."""
        network = _make_two_link_network()
        original_keys = {frozenset(feat["properties"].keys()) for feat in network["features"]}
        nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys = self._coincident_nvp()
        map_nvp_trips(
            network,
            nvp_links=nvp_links,
            nvp_vertlengths=nvp_vertlengths,
            nvp_vertxys=nvp_vertxys,
            nvp_vertdxys=nvp_vertdxys,
            linktrips1={(100, 200, 0): ["trip-A"]},
            maxdist=1.0,
            fmatch12=0.3,
        )
        for feat in network["features"]:
            assert frozenset(feat["properties"].keys()) in original_keys, (
                "map_nvp_trips must not modify feature properties"
            )
