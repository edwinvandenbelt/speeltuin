# Databricks notebook source
"""
NVP Mapper — Databricks notebook entry point.

Reads a directed NETWORK GeoJSON from S3 or local path, queries the NVP
(Nationale Verkeersprestatie) Databricks table for GPS trip segments that
spatially intersect a given polygon, map-matches them onto Spectrum links,
and enriches the NETWORK file in-place with a ``nvpTripIds`` array per link.

Set the widgets below and run all cells.
"""

# COMMAND ----------

dbutils.widgets.text("network_uri", "", "Full URI of the NETWORK GeoJSON (s3:// or local path)")
dbutils.widgets.text(
    "nvp_table", "nvp_experimental.silver.vw_segments", "NVP Databricks table (fully qualified)"
)
dbutils.widgets.text("polygon", "", "GeoJSON Polygon geometry string for spatial filter")
dbutils.widgets.text("mode", "CAR", "Transport mode: CAR or BIKE")
dbutils.widgets.text("nvp_year", "2025", "NVP location_year to filter on")
dbutils.widgets.text("maxlength_sublink", "5", "Max sub-link length (m)")
dbutils.widgets.text("maxdist", "20", "Max lateral distance (m)")
dbutils.widgets.text("maxalpha_forward1", "15", "Tight forward angle threshold (deg)")
dbutils.widgets.text("maxalpha_forward2", "45", "Wide forward angle threshold (deg)")
dbutils.widgets.text("maxalpha_backward", "30", "Backward validation angle threshold (deg)")
dbutils.widgets.text("fmatch12", "0.5", "Minimum overlap fraction (0–1)")
dbutils.widgets.text("nnb", "20", "k-NN neighbours in KD-tree query")

# COMMAND ----------

import logging
import sys

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("nvp_mapper_nb")
logger.setLevel(logging.INFO)
logging.getLogger().setLevel(logging.INFO)

# COMMAND ----------

# Add the workspace source root to sys.path so all module packages are importable.
_workspace_path = (
    dbutils.widgets.get("workspace_path")
    if "workspace_path" in [w.name for w in dbutils.widgets.getAll()]
    else "/Workspace/Shared/gmt-calculation-lib/src"
)
if _workspace_path not in sys.path:
    sys.path.insert(0, _workspace_path)

# COMMAND ----------

import json

import gmt_shared.s3 as _s3
from gmt_shared.databricks_sql import connect_from_env

from gmt_utils.nvp_mapper.core.nvp_mapper_core import enrich_network_with_nvp_trips
from gmt_utils.nvp_mapper.domain.sql import fetch_nvp

# ── Read widget values ────────────────────────────────────────────────────────
network_uri = dbutils.widgets.get("network_uri").strip()
nvp_table = dbutils.widgets.get("nvp_table").strip()
polygon_json = dbutils.widgets.get("polygon").strip()
mode = dbutils.widgets.get("mode").strip().upper()
nvp_year = int(dbutils.widgets.get("nvp_year").strip())
maxlength_sublink = float(dbutils.widgets.get("maxlength_sublink"))
maxdist = float(dbutils.widgets.get("maxdist"))
maxalpha_forward1 = float(dbutils.widgets.get("maxalpha_forward1"))
maxalpha_forward2 = float(dbutils.widgets.get("maxalpha_forward2"))
maxalpha_backward = float(dbutils.widgets.get("maxalpha_backward"))
fmatch12 = float(dbutils.widgets.get("fmatch12"))
nnb = int(dbutils.widgets.get("nnb"))

if not network_uri:
    raise ValueError("Widget 'network_uri' must not be empty.")
if not nvp_table:
    raise ValueError("Widget 'nvp_table' must not be empty.")
if not polygon_json:
    raise ValueError("Widget 'polygon' must not be empty.")

logger.info(
    "network_uri=%s  nvp_table=%s  mode=%s  nvp_year=%d",
    network_uri,
    nvp_table,
    mode,
    nvp_year,
)

# COMMAND ----------


def _read_bytes(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, k = _s3.s3_split(uri)
        data: bytes = _s3.get_bytes_s3(bucket, k)
        return data
    with open(uri, "rb") as fh:
        return fh.read()


def _write_bytes(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, k = _s3.s3_split(uri)
        _s3.put_bytes_s3(bucket, k, data)
    else:
        import pathlib

        pathlib.Path(uri).parent.mkdir(parents=True, exist_ok=True)
        pathlib.Path(uri).write_bytes(data)


print(f"Reading {network_uri} …")
fc = json.loads(_read_bytes(network_uri))
print(f"  {len(fc.get('features', []))} features loaded")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 1 — Fetch NVP data from Databricks
# MAGIC
# MAGIC Connects via ``shared.databricks_sql.connect_from_env()``; credentials
# MAGIC must be in environment variables ``DATABRICKS_HOST``, ``DATABRICKS_TOKEN``.

# COMMAND ----------

print("Connecting to Databricks …")
conn = connect_from_env()
cursor = conn.cursor()

print(f"Fetching NVP data: table={nvp_table}  mode={mode}  year={nvp_year} …")
nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys, linktrips1 = fetch_nvp(
    cursor, nvp_table, polygon_json, mode, nvp_year
)
conn.close()
print(f"  {len(nvp_links)} NVP link segments fetched  /  {len(linktrips1)} segments with trips")

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 2 — Map-match NVP trips onto Spectrum links

# COMMAND ----------

print("Matching NVP trips onto NETWORK …")
enriched_fc, stats = enrich_network_with_nvp_trips(
    fc,
    nvp_links=nvp_links,
    nvp_vertlengths=nvp_vertlengths,
    nvp_vertxys=nvp_vertxys,
    nvp_vertdxys=nvp_vertdxys,
    linktrips1=linktrips1,
    maxlength_sublink=maxlength_sublink,
    maxdist=maxdist,
    maxalpha_forward1=maxalpha_forward1,
    maxalpha_forward2=maxalpha_forward2,
    maxalpha_backward=maxalpha_backward,
    fmatch12=fmatch12,
    nnb=nnb,
)

print(
    f"  features_enriched   : {stats['features_enriched']}\n"
    f"  features_with_trips : {stats['features_with_trips']}\n"
    f"  nvp_links           : {stats['nvp_links']}\n"
    f"  spectrum_links      : {stats['spectrum_links']}\n"
    f"  matched_links       : {stats['matched_links']}"
)

# COMMAND ----------

# MAGIC %md
# MAGIC ## Step 3 — Write enriched NETWORK back to source URI

# COMMAND ----------

print(f"Writing enriched NETWORK to {network_uri} …")
_write_bytes(network_uri, json.dumps(enriched_fc, ensure_ascii=False).encode("utf-8"))
print("Done.")

displayHTML(
    f"<b>NVP Mapper complete</b><br>"
    f"Network: {network_uri}<br>"
    f"Features enriched: <b>{stats['features_enriched']}</b><br>"
    f"Features with trips: <b>{stats['features_with_trips']}</b> "
    f"({100 * stats['features_with_trips'] // max(stats['spectrum_links'], 1)} %)<br>"
    f"Matched links: <b>{stats['matched_links']}</b>"
)
