"""Spatial map-matching geometry helpers for nvp_mapper — no I/O, no boto3.

Ports the core algorithm from ``mapping_mapping_lib.py`` (what_if_quick_scan),
replacing ``scipy.spatial.cKDTree`` with the repo-native ``shared.kd_tree.KDTree2D``.

The functions ``get_vertices``, ``get_sublinks``, and ``map1to2`` are
intentionally identical to those in ``parallel_link_finder.domain.geometry``
(modules do not cross-import from each other's domain packages).

Public API
----------
get_vertices(links, xys)
    Split polyline links into individual straight-line vertex segments.
get_sublinks(vertlinks, vertlengths, vertxys1, vertdxys, maxlength)
    Subdivide vertex segments into equal-length sub-links.
map1to2(...)
    k-NN sub-link matching with angle and distance filters.
mapped_with_overlap(...)
    Keep only matches where ≥ fmatch12 of source or target link is covered.
add_inbetween_sublinks(mapindex, sublinks2)
    Fill gaps between consecutively mapped sub-links on the same link pair.
add_missing_sublinks(mapindex, sublinks2)
    Add unmapped sub-links that belong to an already-mapped Spectrum link.
get_mapped_segments(mapindex, sublinks2)
    Group sub-link mapping into contiguous link-level segments.
get_unmapped_segments(tindex, nvpmatch, sublinks2)
    Identify unmapped portions of Spectrum links.
get_trips_per_link(tindex, nvpmatch, links1, linktrips1,
                   links2, linklengths2, sublengths2)
    Aggregate NVP trip IDs onto Spectrum links (per-link, not per mainlink).
"""

from __future__ import annotations

from collections import defaultdict

try:
    import numpy as np
except ImportError as _np_err:
    raise ImportError(
        "numpy is required for nvp_mapper. "
        "Install it with: pip install numpy"
    ) from _np_err

try:
    from scipy.spatial import cKDTree as _KDTree
except ImportError:
    from gmt_shared.kd_tree import KDTree2D as _KDTree  # type: ignore[assignment]


# ---------------------------------------------------------------------------
# Geometry decomposition
# ---------------------------------------------------------------------------


def get_vertices(
    links: np.ndarray,
    xys: list[list[list[float]]],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Split polyline links into individual straight-line vertex segments.

    Parameters
    ----------
    links:
        Array of link indices (or IDs), shape ``(N,)``.
    xys:
        List of coordinate lists — one per link, each coord is ``[x, y]``
        in RD New metres.

    Returns
    -------
    vertlinks : ndarray, shape (M,)
        Index into *links* for each vertex segment.
    vertlengths : ndarray, shape (M,)
        Length in metres of each vertex segment.
    vertxys1 : ndarray, shape (M, 2)
        Start-point coordinates of each vertex segment.
    vertdxys : ndarray, shape (M, 2)
        Unit direction vectors of each vertex segment.
    """
    vertlinks, vertxys1, vertxys2 = [], [], []

    for i in range(len(links)):
        for j in range(len(xys[i]) - 1):
            x1, y1 = xys[i][j][0], xys[i][j][1]
            x2, y2 = xys[i][j + 1][0], xys[i][j + 1][1]
            if not (x1 == x2 and y1 == y2):
                vertlinks.append(i)
                vertxys1.append([x1, y1])
                vertxys2.append([x2, y2])

    vertlinks = np.array(vertlinks)
    vertxys1 = np.array(vertxys1)
    vertxys2 = np.array(vertxys2)

    vertlengths = np.sqrt(
        (vertxys1[:, 0] - vertxys2[:, 0]) ** 2 + (vertxys1[:, 1] - vertxys2[:, 1]) ** 2
    )

    vertdxys = np.zeros((len(vertlinks), 2))
    vertdxys[:, 0] = (vertxys2[:, 0] - vertxys1[:, 0]) / vertlengths
    vertdxys[:, 1] = (vertxys2[:, 1] - vertxys1[:, 1]) / vertlengths

    return vertlinks, vertlengths, vertxys1, vertdxys


def get_sublinks(
    vertlinks: np.ndarray,
    vertlengths: np.ndarray,
    vertxys1: np.ndarray,
    vertdxys: np.ndarray,
    maxlength_sublink: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Subdivide vertex segments into equal-length sub-links.

    Each vertex is cut into ``ceil(length / maxlength_sublink)`` sub-links of
    equal length, represented by their centroid point and direction vector.

    Parameters
    ----------
    vertlinks:
        Index into the parent link array for each vertex, shape ``(M,)``.
    vertlengths:
        Length in metres of each vertex, shape ``(M,)``.
    vertxys1:
        Start-point coordinates of each vertex in RD metres, shape ``(M, 2)``.
    vertdxys:
        Unit direction vectors of each vertex, shape ``(M, 2)``.
    maxlength_sublink:
        Maximum sub-link length in metres.

    Returns
    -------
    sublinks, sublengths, subxys, subdxys — all ndarrays, one row per sub-link.
    ``subxys`` holds the centroid (mid-point) of each sub-link.
    """
    sublinks, sublengths = [], []
    subxys, subdxys = [], []

    for i in range(len(vertlinks)):
        nsub = int(vertlengths[i] / maxlength_sublink) + 1
        for j in range(nsub):
            f = (j + 0.5) / nsub
            sublinks.append(vertlinks[i])
            sublengths.append(vertlengths[i] / nsub)
            subxys.append(vertxys1[i, :] + f * vertlengths[i] * vertdxys[i, :])
            subdxys.append(vertdxys[i])

    return (
        np.array(sublinks),
        np.array(sublengths),
        np.array(subxys),
        np.array(subdxys),
    )


# ---------------------------------------------------------------------------
# k-NN matching
# ---------------------------------------------------------------------------


def map1to2(
    links1: np.ndarray,
    sublinks1: np.ndarray,
    sublinks2: np.ndarray,
    subxys1: np.ndarray,
    subxys2: np.ndarray,
    subdxys1: np.ndarray,
    subdxys2: np.ndarray,
    mapped: np.ndarray,
    maxlength_sublink: float,
    maxdist: float,
    maxalpha: float,
    nnb: int,
    map_direction: str,
    map_on_self: bool,
    use_parallel_distance: bool,
) -> tuple[np.ndarray, np.ndarray]:
    """Match sub-links from network 1 onto network 2 using a k-d tree.

    Candidates are filtered by:
    - Euclidean distance ≤ *maxdist* metres
    - Cosine angular similarity ≥ cos(*maxalpha*°)
    - Optionally: parallel (along-track) distance ≤ *maxlength_sublink* / 2

    Each sub-link in network 1 is matched at most once (``mapped`` flag array
    tracks already-matched sub-links and is updated in-place).

    Parameters
    ----------
    links1:
        Link ID array for network 1, shape ``(N1,)``.
    sublinks1, sublinks2:
        Sub-link → link index arrays for network 1 and 2.
    subxys1, subxys2:
        Sub-link centroid coordinates (RD New metres).
    subdxys1, subdxys2:
        Sub-link unit direction vectors.
    mapped:
        Boolean flag array for network 1 sub-links; 1 = already matched.
        **Modified in-place.**
    maxlength_sublink:
        Maximum sub-link length (metres) — used for parallel-distance check.
    maxdist:
        Maximum lateral distance (metres) for a valid match.
    maxalpha:
        Maximum heading difference (degrees) for a valid match.
    nnb:
        Number of nearest neighbours to query per sub-link.
    map_direction:
        ``"same"`` | ``"opposite"`` | ``"both"``
    map_on_self:
        When ``True`` the source and target belong to the same network, so
        self-matches (same absolute link ID) are excluded.
    use_parallel_distance:
        When ``True`` additionally filter by along-track distance.

    Returns
    -------
    index1 : ndarray
        Sub-link indices in network 1 that were matched.
    index2 : ndarray
        Corresponding sub-link indices in network 2.
    """
    ckd_tree = _KDTree(subxys2)
    dist, idx = ckd_tree.query(subxys1, k=nnb)
    # scipy's cKDTree returns 1-D arrays when k=1; normalise to (M, k).
    if dist.ndim == 1:
        dist = dist[:, np.newaxis]
        idx = idx[:, np.newaxis]

    mininprod = np.cos(maxalpha * np.pi / 180)
    index1 = np.array([], dtype=int)
    index2 = np.array([], dtype=int)

    for i in range(nnb):
        if map_direction == "both":
            inprod = np.abs(
                subdxys1[:, 0] * subdxys2[idx[:, i], 0]
                + subdxys1[:, 1] * subdxys2[idx[:, i], 1]
            )
        elif map_direction == "opposite":
            inprod = -(
                subdxys1[:, 0] * subdxys2[idx[:, i], 0]
                + subdxys1[:, 1] * subdxys2[idx[:, i], 1]
            )
        else:  # "same"
            inprod = (
                subdxys1[:, 0] * subdxys2[idx[:, i], 0]
                + subdxys1[:, 1] * subdxys2[idx[:, i], 1]
            )

        dxys12 = np.zeros((len(idx), 2))
        dxys12[:, 0] = subxys2[idx[:, i], 0] - subxys1[:, 0]
        dxys12[:, 1] = subxys2[idx[:, i], 1] - subxys1[:, 1]
        dist_parallel = np.abs(
            subdxys1[:, 0] * dxys12[:, 0] + subdxys1[:, 1] * dxys12[:, 1]
        )

        if use_parallel_distance:
            if map_on_self:
                hindex = np.where(
                    (mapped == 0)
                    & (dist_parallel <= maxlength_sublink / 2)
                    & (dist[:, i] <= maxdist)
                    & (inprod >= mininprod)
                    & (links1[sublinks1] != links1[sublinks2[idx[:, i]]])
                )[0]
            else:
                hindex = np.where(
                    (mapped == 0)
                    & (dist_parallel <= maxlength_sublink / 2)
                    & (dist[:, i] <= maxdist)
                    & (inprod >= mininprod)
                )[0]
        else:
            if map_on_self:
                hindex = np.where(
                    (mapped == 0)
                    & (dist[:, i] <= maxdist)
                    & (inprod >= mininprod)
                    & (links1[sublinks1] != links1[sublinks2[idx[:, i]]])
                )[0]
            else:
                hindex = np.where(
                    (mapped == 0) & (dist[:, i] <= maxdist) & (inprod >= mininprod)
                )[0]

        index1 = np.concatenate((index1, hindex))
        index2 = np.concatenate((index2, idx[hindex, i]))
        mapped[hindex] = 1

    return index1, index2


# ---------------------------------------------------------------------------
# Overlap validation
# ---------------------------------------------------------------------------


def mapped_with_overlap(
    findex1: np.ndarray,
    findex2: np.ndarray,
    bindex1: np.ndarray,
    bindex2: np.ndarray,
    sublinks1: np.ndarray,
    sublinks2: np.ndarray,
    sublengths1: np.ndarray,
    sublengths2: np.ndarray,
    vertlengths1: np.ndarray,
    linklengths2: list[float],
    fmatch12: float,
) -> np.ndarray:
    """Keep only NVP–Spectrum sub-link matches with sufficient length overlap.

    A match is kept when the total mapped sub-link length on either side is
    ≥ *fmatch12* × the full length of the corresponding source or target link.

    Parameters
    ----------
    findex1, findex2:
        Forward-pass match indices (source sub-links → target sub-links).
    bindex1, bindex2:
        Backward-pass match indices (target → source, re-ordered to
        source/target order for consistency).
    sublinks1, sublinks2:
        Sub-link → link index mappings for source and target networks.
    sublengths1, sublengths2:
        Sub-link lengths (metres).
    vertlengths1:
        Length of each NVP vertex/link (metres), shape ``(N1,)``.
    linklengths2:
        Length of each Spectrum link (metres), length ``N2``.
    fmatch12:
        Minimum overlap fraction (default 0.5 = 50 %).

    Returns
    -------
    mapindex : ndarray, shape (K, 2)
        Valid ``[sublink1_index, sublink2_index]`` pairs after overlap filter.
    """
    check_overlap12: dict = {}
    nmapped_links12: dict = defaultdict(lambda: np.zeros(2))

    for i1, i2 in zip(findex1, findex2):
        key = (int(sublinks1[i1]), int(sublinks2[i2]))
        nmapped_links12[key] += np.array([sublengths1[i1], sublengths2[i2]])
        check_overlap12[key] = 0

    for i1, i2 in zip(bindex1, bindex2):
        key = (int(sublinks1[i1]), int(sublinks2[i2]))
        check_overlap12[key] = 0

    for (ilink1, ilink2), lengths in nmapped_links12.items():
        if (
            lengths[0] >= fmatch12 * vertlengths1[ilink1]
            or lengths[1] >= fmatch12 * linklengths2[ilink2]
        ):
            check_overlap12[ilink1, ilink2] = 1

    mapindex_dict: dict = {}
    for i1, i2 in zip(findex1, findex2):
        key = (int(sublinks1[i1]), int(sublinks2[i2]))
        mapindex_dict[i1, i2] = check_overlap12.get(key, 0)
    for i1, i2 in zip(bindex1, bindex2):
        key = (int(sublinks1[i1]), int(sublinks2[i2]))
        mapindex_dict[i1, i2] = check_overlap12.get(key, 0)

    mapindex = np.array(list(mapindex_dict.keys()))
    valid = np.array(list(mapindex_dict.values()))
    return mapindex[valid == 1]


# ---------------------------------------------------------------------------
# Gap filling
# ---------------------------------------------------------------------------


def add_inbetween_sublinks(
    mapindex: np.ndarray,
    sublinks2: np.ndarray,
) -> np.ndarray:
    """Fill gaps between consecutively mapped sub-links on the same link pair.

    If sub-links s and s+2 of a Spectrum link are both mapped to the same NVP
    link but s+1 is not, s+1 is inserted so that the matched trajectory is
    contiguous.

    Parameters
    ----------
    mapindex:
        Array of shape ``(K, 2)`` with ``[nvp_sublink_idx, spectrum_sublink_idx]``
        rows.  Column 0 holds NVP **link** indices (not sub-link indices) after
        the caller replaces ``mapindex[:,0] = sublinks1[mapindex[:,0]]``.
    sublinks2:
        Sub-link → Spectrum link index array.

    Returns
    -------
    mapindex : ndarray, shape (K', 2)
        Extended mapping with in-between sub-links inserted.
    """
    linkcom = np.zeros((len(mapindex), 3), dtype=int)
    linkcom[:, 0] = mapindex[:, 0]                    # NVP link index
    linkcom[:, 1] = sublinks2[mapindex[:, 1]]          # Spectrum link index
    linkcom[:, 2] = mapindex[:, 1]                     # Spectrum sub-link index

    ulinkcom_index = np.unique(linkcom, axis=0)
    ulinkcom, nlinkcom = np.unique(ulinkcom_index[:, 0:2], axis=0, return_counts=True)
    indices = np.concatenate((np.array([0], dtype=int), np.cumsum(nlinkcom)))

    index1 = ulinkcom_index[:, 0]
    index2 = ulinkcom_index[:, 2]

    addindex1, addindex2 = [], []
    for i in range(len(ulinkcom)):
        minindex = int(ulinkcom_index[indices[i], 2])
        maxindex = int(ulinkcom_index[indices[i + 1] - 1, 2])
        port = np.zeros(maxindex - minindex + 1, dtype=int)
        hindex = ulinkcom_index[indices[i]:indices[i + 1], 2] - minindex
        port[hindex] = 1
        for j in np.where(port == 0)[0]:
            addindex1.append(ulinkcom[i, 0])
            addindex2.append(minindex + j)

    index1 = np.concatenate((index1, np.array(addindex1, dtype=int)))
    index2 = np.concatenate((index2, np.array(addindex2, dtype=int)))

    result = np.zeros((len(index1), 2), dtype=int)
    result[:, 0] = index1
    result[:, 1] = index2
    return result


def add_missing_sublinks(
    mapindex: np.ndarray,
    sublinks2: np.ndarray,
) -> np.ndarray:
    """Add all unmapped sub-links of Spectrum links that are already partially mapped.

    For every Spectrum link that has at least one matched sub-link, any
    remaining un-matched sub-links are appended with NVP link index ``-1``
    (meaning "no NVP match for this portion").

    Parameters
    ----------
    mapindex:
        Current mapping array, shape ``(K, 2)``.
    sublinks2:
        Sub-link → Spectrum link index array.

    Returns
    -------
    mapindex : ndarray, shape (K', 2)
    """
    port_links = np.zeros(int(np.max(sublinks2)) + 1, dtype=int)
    port_links[sublinks2[mapindex[:, 1]]] = 1

    port_linkindex = port_links[sublinks2]
    all_sublinks_of_mapped = np.where(port_linkindex == 1)[0]
    addindex2 = np.array(list(set(all_sublinks_of_mapped.tolist()) - set(mapindex[:, 1].tolist())))
    addindex1 = -np.ones(len(addindex2), dtype=int)

    index1 = np.concatenate((mapindex[:, 0], addindex1))
    index2 = np.concatenate((mapindex[:, 1], addindex2))

    result = np.zeros((len(index1), 2), dtype=int)
    result[:, 0] = index1
    result[:, 1] = index2
    return result


# ---------------------------------------------------------------------------
# Segment derivation
# ---------------------------------------------------------------------------


def get_mapped_segments(
    mapindex: np.ndarray,
    sublinks2: np.ndarray,
) -> tuple[dict, dict]:
    """Group sub-link matches into contiguous link-level segments.

    For each Spectrum link, consecutive sub-links with the same NVP assignment
    form a segment.  Each segment is represented by its start/end sub-link
    index boundaries and the list of NVP link indices assigned to it.

    Parameters
    ----------
    mapindex:
        Mapping array ``(K, 2)`` with ``[nvp_link_idx, spectrum_sublink_idx]``.
        NVP index ``-1`` means the sub-link is unmapped.
    sublinks2:
        Sub-link → Spectrum link index array.

    Returns
    -------
    tindex : dict[spectrum_link_idx, list[int]]
        Start/end sub-link indices delimiting each segment.
        Length of each list is ``n_segments + 1``.
    nvpmatch : dict[spectrum_link_idx, list[list[int]]]
        NVP link index lists for each segment (length ``n_segments``).
    """
    linkcom = np.zeros((len(mapindex), 2), dtype=int)
    linkcom[:, 0] = mapindex[:, 1]   # Spectrum sub-link index
    linkcom[:, 1] = mapindex[:, 0]   # NVP link index

    ulinkcom_index = np.unique(linkcom, axis=0)
    ulinkcom, nlinkcom = np.unique(ulinkcom_index[:, 0], axis=0, return_counts=True)
    indices = np.concatenate((np.array([0], dtype=int), np.cumsum(nlinkcom)))

    tindex: dict = {}
    nvpmatch: dict = {}

    if len(ulinkcom) == 0:
        return tindex, nvpmatch

    ilink2 = int(sublinks2[ulinkcom[0]])
    tindex_dummy = [int(ulinkcom[0])]
    nvpmatch_dummy = [list(ulinkcom_index[indices[0]:indices[1], 1])]
    last_index = int(ulinkcom[0])

    for i in range(1, len(ulinkcom)):
        cur_link2 = int(sublinks2[ulinkcom[i]])

        if cur_link2 == ilink2:
            hmatch = list(ulinkcom_index[indices[i]:indices[i + 1], 1])
            if hmatch != nvpmatch_dummy[-1]:
                tindex_dummy.append(int(ulinkcom[i]))
                nvpmatch_dummy.append(hmatch)

        if cur_link2 != ilink2 or i == len(ulinkcom) - 1:
            tindex[ilink2] = []
            nvpmatch[ilink2] = []
            tindex_start = tindex_dummy[0]
            tindex_dummy.append(last_index + 1)

            for j in range(len(nvpmatch_dummy)):
                if nvpmatch_dummy[j] == [-1]:
                    tp = int((tindex_dummy[j] + tindex_dummy[j + 1]) / 2)
                    tindex_dummy[j] = tp
                    tindex_dummy[j + 1] = tp

            for j in range(len(nvpmatch_dummy)):
                if nvpmatch_dummy[j] != [-1]:
                    tindex[ilink2].append(tindex_dummy[j])
                    nvpmatch[ilink2].append(nvpmatch_dummy[j])

            if tindex[ilink2]:
                tindex[ilink2][0] = tindex_start
                tindex[ilink2].append(last_index + 1)

            ilink2 = cur_link2
            tindex_dummy = [int(ulinkcom[i])]
            nvpmatch_dummy = [list(ulinkcom_index[indices[i]:indices[i + 1], 1])]

        last_index = int(ulinkcom[i])

    return tindex, nvpmatch


def get_unmapped_segments(
    tindex: dict,
    nvpmatch: dict,
    sublinks2: np.ndarray,
) -> tuple[dict, dict]:
    """Identify unmapped portions of Spectrum links.

    Parameters
    ----------
    tindex, nvpmatch:
        Output of :func:`get_mapped_segments`.
    sublinks2:
        Sub-link → Spectrum link index array.

    Returns
    -------
    tindex1_unmapped, tindex2_unmapped : dict[spectrum_link_idx, list[int]]
        Start and end sub-link indices for each unmapped segment.
    """
    port_mapped = np.zeros(len(sublinks2), dtype=int)
    for ilink2, segments in nvpmatch.items():
        for i in range(len(segments)):
            port_mapped[tindex[ilink2][i]:tindex[ilink2][i + 1]] = 1

    tindex1_unmapped: dict = {}
    tindex2_unmapped: dict = {}
    hindex = np.where(port_mapped == 0)[0]

    if len(hindex) == 0:
        return tindex1_unmapped, tindex2_unmapped

    first_link = int(sublinks2[hindex[0]])
    tindex1_unmapped[first_link] = [int(hindex[0])]
    tindex2_unmapped[first_link] = []

    for i in range(1, len(hindex)):
        prev_link = int(sublinks2[hindex[i - 1]])
        cur_link = int(sublinks2[hindex[i]])
        if hindex[i] > hindex[i - 1] + 1 or cur_link != prev_link:
            tindex2_unmapped[prev_link].append(int(hindex[i - 1]) + 1)
            if cur_link != prev_link:
                tindex1_unmapped[cur_link] = [int(hindex[i])]
                tindex2_unmapped[cur_link] = []
            else:
                tindex1_unmapped[cur_link].append(int(hindex[i]))

    last_link = int(sublinks2[hindex[-1]])
    tindex2_unmapped[last_link].append(int(hindex[-1]) + 1)

    return tindex1_unmapped, tindex2_unmapped


# ---------------------------------------------------------------------------
# Trip aggregation
# ---------------------------------------------------------------------------


def get_trips_per_link(
    tindex: dict,
    nvpmatch: dict,
    links1: np.ndarray,
    linktrips1: dict,
    links2: np.ndarray,
    linklengths2: list[float],
    sublengths2: np.ndarray,
) -> dict:
    """Aggregate NVP trip IDs onto Spectrum links.

    For each Spectrum link, collects all NVP trips from the mapped NVP links,
    deduplicates by trip ID, and keeps only trips whose total mapped segment
    length is ≥ 50 % of the Spectrum link length.

    Parameters
    ----------
    tindex, nvpmatch:
        Output of :func:`get_mapped_segments`.
    links1:
        NVP link tuple array, shape ``(N1, 3)`` — rows are
        ``(nodeId, next_nodeId, pairindex)``.
    linktrips1:
        Dict mapping ``(nodeId, next_nodeId, pairindex)`` → list of trip IDs.
    links2:
        Spectrum link ID array, shape ``(N2,)``.
    linklengths2:
        Spectrum link lengths in metres, length ``N2``.
    sublengths2:
        Spectrum sub-link lengths in metres.

    Returns
    -------
    linktrips : dict[spectrum_link_id, ndarray]
        Array of trip IDs (dtype object) for each Spectrum link.
        Links with no NVP match have an empty array.
    """
    linktrips: dict = {int(link2): np.array([], dtype=object) for link2 in links2}

    for ilink2, segments in nvpmatch.items():
        trips = np.array([], dtype=object)
        triplengths = np.array([], dtype=float)

        for i in range(len(segments)):
            seg_length = float(np.sum(sublengths2[tindex[ilink2][i]:tindex[ilink2][i + 1]]))
            for ilink1 in segments[i]:
                key = tuple(int(v) for v in links1[ilink1])
                addtrips = linktrips1.get(key, [])
                trips = np.concatenate((trips, np.array(addtrips, dtype=object)))
                triplengths = np.concatenate(
                    (triplengths, seg_length * np.ones(len(addtrips)))
                )

        if len(trips) == 0:
            continue

        xs = np.argsort(trips)
        triplengths = triplengths[xs]
        utrips, ntrips = np.unique(trips, return_counts=True)

        dummy = np.array([0])
        indices = np.concatenate((dummy, np.cumsum(ntrips)))
        cumlengths = np.concatenate((dummy.astype(float), np.cumsum(triplengths)))
        agglengths = np.take(cumlengths, indices[1:]) - np.take(cumlengths, indices[:-1])

        valid_mask = agglengths >= 0.5 * linklengths2[ilink2]
        linktrips[int(links2[ilink2])] = utrips[valid_mask]

    return linktrips
