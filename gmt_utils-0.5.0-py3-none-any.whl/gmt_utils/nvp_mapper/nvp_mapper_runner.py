"""Local debug runner for nvp_mapper.

Calls map_nvp_trips() directly — no Lambda handler involved.

Reads the NETWORK GeoJSON for spatial geometry (read-only — the file is never
modified).  The spatial polygon used to filter NVP segments is derived
automatically from the ``bbox`` stored in the NETWORK file's top-level
``properties`` object (``$.properties.bbox``), so no separate polygon argument
is required.

Output is a CSV file with one row per matched Spectrum link:
    linkId, nvpLinkIds, nvpTripIds

    ``nvpLinkIds`` and ``nvpTripIds`` are pipe-separated (``|``) strings.

Usage
-----
    python -m nvp_mapper.nvp_mapper_runner \\
        --network-file /tmp/deventer-NETWORK-CAR.geojson \\
        --nvp-table nvp_experimental.silver.vw_segments \\
        --mode CAR \\
        --nvp-year 2025 \\
        --output-csv /tmp/deventer-NVP-ROUTES-CAR.csv

    # S3 network file (read-only):
    python -m nvp_mapper.nvp_mapper_runner \\
        --network-file s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.geojson \\
        --nvp-table nvp_experimental.silver.vw_segments \\
        --mode CAR \\
        --nvp-year 2025 \\
        --output-csv /tmp/deventer-NVP-ROUTES-CAR.csv

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only for s3:// URIs).
* Databricks credentials in the environment or .env file:
  DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID and one of:
  - DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET  (OAuth M2M, preferred)
  - DATABRICKS_TOKEN  (personal access token, fallback)
* numpy installed (pip install gmt-calculation-lib[nvp]).
"""

from __future__ import annotations

import argparse
import csv
import json
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_csv(match_rows: list, output_path: str) -> None:
    """Write match rows to a CSV file.

    Columns: linkId, nvpLinkIds, nvpTripIds.
    List values (nvpLinkIds, nvpTripIds) are serialised as pipe-separated strings.
    """
    dest = output_path.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(dest)), exist_ok=True)
    with open(dest, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["linkId", "nvpLinkIds", "nvpTripIds"])
        for row in match_rows:
            writer.writerow([
                row["linkId"],
                "|".join(row["nvpLinkIds"]),
                "|".join(row["nvpTripIds"]),
            ])
    print(f"Written {len(match_rows):,} rows -> {dest}")


# ---------------------------------------------------------------------------
# Polygon extractor
# ---------------------------------------------------------------------------


def _polygon_from_network(fc: dict) -> str:
    """Return a GeoJSON Polygon geometry string derived from the NETWORK file.

    Reads ``$.properties.bbox`` — a ``[minLon, minLat, maxLon, maxLat]`` array
    stored on the FeatureCollection by network_fetcher — and wraps it into a
    closed GeoJSON Polygon ring.

    Raises
    ------
    KeyError / ValueError
        When ``$.properties.bbox`` is absent or has the wrong shape.
    """
    props = fc.get("properties") or {}
    bbox = props.get("bbox")
    if bbox is None:
        raise KeyError(
            "NETWORK GeoJSON has no 'bbox' in $.properties. "
            "This field is written by network_fetcher; ensure the file was "
            "produced by the standard GMT pipeline."
        )
    try:
        min_lon, min_lat, max_lon, max_lat = (float(v) for v in bbox)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"$.properties.bbox must be [minLon, minLat, maxLon, maxLat], got {bbox!r}"
        ) from exc

    geom = {
        "type": "Polygon",
        "coordinates": [[
            [min_lon, min_lat],
            [max_lon, min_lat],
            [max_lon, max_lat],
            [min_lon, max_lat],
            [min_lon, min_lat],
        ]],
    }
    return json.dumps(geom)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for nvp_mapper, creates a CSV file"
            "with NVP trip IDs per link.  The spatial filter polygon is derived "
            "automatically from $.properties.bbox in the NETWORK file."
        )
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help=(
            "Full URI of the NETWORK GeoJSON to enrich "
            "(s3:// or local path).  Overwritten in-place."
        ),
    )
    parser.add_argument(
        "--nvp-table",
        required=True,
        metavar="TABLE",
        default="nvp_experimental.silver.vw_segments",
        help=(
            "Fully qualified Databricks table name for NVP trip segments, "
            "e.g. nvp_experimental.silver.vw_segments."
        ),
    )
    parser.add_argument(
        "--mode",
        required=True,
        metavar="MODE",
        help="Transport mode: CAR or BIKE.",
    )
    parser.add_argument(
        "--nvp-year",
        required=True,
        type=int,
        metavar="YEAR",
        default=2025,
        help="NVP location_year value to filter on (e.g. 2025).",
    )
    parser.add_argument(
        "--maxlength-sublink",
        type=float,
        default=5.0,
        help="Max sub-link length in metres (default: 5).",
    )
    parser.add_argument(
        "--maxdist",
        type=float,
        default=20.0,
        help="Max lateral distance in metres for a valid match (default: 20).",
    )
    parser.add_argument(
        "--maxalpha-forward1",
        type=float,
        default=15.0,
        help="Tight angular threshold for forward pass 1, degrees (default: 15).",
    )
    parser.add_argument(
        "--maxalpha-forward2",
        type=float,
        default=45.0,
        help="Wide angular threshold for forward pass 2, degrees (default: 45).",
    )
    parser.add_argument(
        "--maxalpha-backward",
        type=float,
        default=30.0,
        help="Angular threshold for backward validation pass, degrees (default: 30).",
    )
    parser.add_argument(
        "--fmatch12",
        type=float,
        default=0.5,
        help="Minimum overlap fraction to accept a match (default: 0.5 = 50%%).",
    )
    parser.add_argument(
        "--nnb",
        type=int,
        default=20,
        help="Number of nearest neighbours in the k-d tree query (default: 20).",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        help="Python logging level (default: INFO).",
    )
    parser.add_argument(
        "--output-csv",
        default=None,
        required=True,
        metavar="PATH",
        help=(
            "Local path for the NVP-ROUTES CSV output file, "
            "e.g. output/deventer/{areaId}-NVP-ROUTES-CAR.csv. "
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS + Databricks credentials.",
    )
    args = parser.parse_args()

    # ── Load .env ──────────────────────────────────────────────────────────
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    # ── Logging ─────────────────────────────────────────────────────────────
    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
        level=getattr(logging, args.log_level.upper(), logging.INFO),
    )

    # ── Late imports (after sys.path is ready) ───────────────────────────────
    from gmt_shared.databricks_sql import connect_from_env
    from gmt_shared.geoparquet import from_geoparquet

    from gmt_utils.nvp_mapper.core.nvp_mapper_core import map_nvp_trips
    from gmt_utils.nvp_mapper.domain.sql import fetch_nvp

    # ── Read network ─────────────────────────────────────────────────────────
    print(f"\nReading   : {args.network_file}")
    fc = from_geoparquet(_read_uri(args.network_file))
    print(f"  {len(fc.get('features', []))} features loaded")

    # ── Derive spatial filter polygon from the network's bbox ─────────────────
    polygon_json = _polygon_from_network(fc)
    fc_props = fc.get("properties") or {}
    print(f"  bbox     : {fc_props.get('bbox')}")

    # ── Connect to Databricks ────────────────────────────────────────────────
    print("Connecting to Databricks ...")
    conn = connect_from_env()
    cursor = conn.cursor()

    # ── Fetch NVP geometry + trip IDs in one query ───────────────────────────
    print(
        f"Fetching NVP data: table={args.nvp_table}  mode={args.mode}  year={args.nvp_year}"
    )
    nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys, linktrips1 = fetch_nvp(
        cursor, args.nvp_table, polygon_json, args.mode, args.nvp_year
    )
    conn.close()
    print(f"  NVP links fetched: {len(nvp_links)}  segments with trips: {len(linktrips1)}")

    # ── Map NVP trips onto NETWORK (read-only) ───────────────────────────────
    print("Matching NVP trips onto NETWORK ...")
    stats, match_rows = map_nvp_trips(
        fc,
        nvp_links=nvp_links,
        nvp_vertlengths=nvp_vertlengths,
        nvp_vertxys=nvp_vertxys,
        nvp_vertdxys=nvp_vertdxys,
        linktrips1=linktrips1,
        maxlength_sublink=args.maxlength_sublink,
        maxdist=args.maxdist,
        maxalpha_forward1=args.maxalpha_forward1,
        maxalpha_forward2=args.maxalpha_forward2,
        maxalpha_backward=args.maxalpha_backward,
        fmatch12=args.fmatch12,
        nnb=args.nnb,
    )

    # ── Write NVP-ROUTES CSV ──────────────────────────────────────────────────
    if args.output_csv:
        print(f"Writing   : {args.output_csv}")
        _write_csv(match_rows, args.output_csv)

    print(
        f"\n  spectrum_links : {stats['spectrum_links']}"
        f"\n  nvp_links      : {stats['nvp_links']}"
        f"\n  matched_links  : {stats['matched_links']}"
        f"\n  match_rows     : {stats['match_rows']}"
    )


if __name__ == "__main__":
    main()
