"""Local debug runner for geojson_filter.

Reads a GeoJSON FeatureCollection, filters its features using a Python
eval expression, and writes the result to an output file.

Usage
-----
    python -m geojson_filter.geojson_filter_runner \\
        --input-file  path/to/input.parquet \\
        --output-file path/to/output.parquet \\
        --filter      "p.get('speed', 0) >= 50"

    # S3 URIs are also accepted:
    python -m geojson_filter.geojson_filter_runner \\
        --input-file  s3://bucket/prefix/input.parquet \\
        --output-file s3://bucket/prefix/output.parquet \\
        --filter      "p.get('zoneClass') == 'STUDY'"

Variables available in --filter expression
------------------------------------------
    f   full GeoJSON Feature dict
    p   feature["properties"]  (never None)
    g   feature["geometry"]    (may be None)
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Filter a GeoJSON FeatureCollection using a Python eval expression. "
            "Available variables: f (feature), p (properties), g (geometry)."
        )
    )
    parser.add_argument(
        "--input-file", required=True, metavar="URI",
        help="URI of the input GeoParquet file (s3:// or local path).",
    )
    parser.add_argument(
        "--output-file", required=True, metavar="URI",
        help="URI for the filtered output GeoParquet file (s3:// or local path).",
    )
    parser.add_argument(
        "--filter", required=True, metavar="EXPR",
        help=(
            "Python eval expression evaluated per feature. "
            "Feature is kept when expression is truthy. "
            "Example: \"p.get('speed', 0) >= 50\""
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_utils.geojson_filter.core.geojson_filter_core import filter_geojson

    # Read input
    print(f"Reading  : {args.input_file}")
    fc: dict = from_geoparquet(_read_uri(args.input_file))
    n_input = len(fc.get("features") or [])
    print(f"Features : {n_input}")
    print(f"Filter   : {args.filter}")

    # Filter
    filtered_fc, stats = filter_geojson(fc, args.filter)
    print(f"Kept     : {stats['kept']} / {stats['total']}  ({stats['removed']} removed)")

    # Write output
    print(f"Writing  : {args.output_file}")
    _write_uri(args.output_file, to_geoparquet(filtered_fc))
    print("Done.")


if __name__ == "__main__":
    main()
