"""Pure-Python GeoJSON filter core — no I/O, no boto3.

Filters the features of a GeoJSON FeatureCollection by evaluating a
user-supplied Python expression for each feature.  The top-level
FeatureCollection properties are preserved unchanged.

Public API
----------
filter_geojson(fc, filter_expr) -> tuple[dict, dict]
    Returns (filtered_fc, stats).
    stats: {"total": int, "kept": int, "removed": int}
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def filter_geojson(
    fc: dict,
    filter_expr: str,
) -> tuple[dict, dict]:
    """Filter a GeoJSON FeatureCollection using a Python eval expression.

    The expression is evaluated once per feature.  Three local names are
    available inside the expression:

    * ``f``  — the full GeoJSON Feature dict
    * ``p``  — shorthand for ``f["properties"]`` (a dict, never None)
    * ``g``  — shorthand for ``f["geometry"]``   (may be None)

    A feature is kept when the expression evaluates to a truthy value.

    Parameters
    ----------
    fc:
        Input GeoJSON FeatureCollection.
    filter_expr:
        Python expression string, e.g. ``"p.get('speed', 0) >= 50"``.

    Returns
    -------
    filtered_fc:
        New FeatureCollection containing only the features for which
        *filter_expr* evaluated to True.  The top-level ``properties``
        of the input FeatureCollection are copied unchanged.
    stats:
        ``{"total": int, "kept": int, "removed": int}``

    Raises
    ------
    ValueError
        When *filter_expr* is empty or blank.
    SyntaxError
        When *filter_expr* is not valid Python.
    """
    if not filter_expr or not filter_expr.strip():
        raise ValueError("filter_expr must be a non-empty string.")

    # Compile once — raises SyntaxError early if the expression is invalid.
    compiled = compile(filter_expr.strip(), "<filter_expr>", "eval")

    features: list[dict] = fc.get("features") or []
    kept: list[dict] = []

    for feat in features:
        f = feat
        p = feat.get("properties") or {}
        g = feat.get("geometry")
        try:
            result = eval(compiled, {"__builtins__": {}}, {"f": f, "p": p, "g": g})  # noqa: S307
        except Exception as exc:
            logger.warning("filter_expr raised %s for feature %r — skipping", exc, feat)
            continue
        if result:
            kept.append(feat)

    total = len(features)
    n_kept = len(kept)
    stats = {"total": total, "kept": n_kept, "removed": total - n_kept}

    logger.info(
        "filter_geojson: %d / %d features kept (%d removed)",
        n_kept, total, total - n_kept,
    )

    filtered_fc: dict = {
        "type": "FeatureCollection",
        "features": kept,
    }
    # Preserve any top-level FeatureCollection properties
    if "properties" in fc:
        filtered_fc["properties"] = fc["properties"]

    return filtered_fc, stats
