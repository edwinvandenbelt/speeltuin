# Databricks notebook source
# ---------------------------------------------------------------------------
# geojson_filter_nb.py — Databricks notebook interface for GeoJSON filtering.
#
# This notebook:
#   1. Reads widget parameters (input_uri, filter_expr, output_uri).
#   2. Reads the GeoJSON FeatureCollection (s3:// or local path).
#   3. Calls pure core function (filter_geojson).
#   4. Writes the filtered GeoJSON to output_uri.
#   5. Prints a summary of kept / removed features.
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("geojson_filter_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "input_uri",
    "",
    "Full URI of the input GeoJSON FeatureCollection (s3:// or local path)",
)
dbutils.widgets.text(
    "output_uri",
    "",
    "Full URI for the filtered output GeoJSON (leave blank to overwrite input_uri)",
)
dbutils.widgets.text(
    "filter_expr",
    "",
    "Python eval expression; p = properties dict, f = full feature, g = geometry",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_utils.geojson_filter.core.geojson_filter_core import filter_geojson

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

INPUT_URI = dbutils.widgets.get("input_uri").strip()
OUTPUT_URI = dbutils.widgets.get("output_uri").strip() or INPUT_URI
FILTER_EXPR = dbutils.widgets.get("filter_expr").strip()

if not INPUT_URI:
    raise ValueError("Widget 'input_uri' is empty — provide a full GeoJSON URI.")
if not FILTER_EXPR:
    raise ValueError(
        "Widget 'filter_expr' is empty — provide a Python eval expression, "
        "e.g. \"p.get('speed', 0) >= 50\""
    )

logger.info("input_uri=%s  output_uri=%s  filter_expr=%r", INPUT_URI, OUTPUT_URI, FILTER_EXPR)

# COMMAND ----------
# ── S3 helpers ────────────────────────────────────────────────────────────────

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body: bytes = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run GeoJSON Filter
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")
print(f"Expr      : {FILTER_EXPR!r}")
print()

_raw = _read_uri(INPUT_URI)
_fc = json.loads(_raw)

_filtered_fc, _stats = filter_geojson(_fc, FILTER_EXPR)

_payload = json.dumps(_filtered_fc, ensure_ascii=False).encode("utf-8")
_write_uri(OUTPUT_URI, _payload)

_total_elapsed = (datetime.now(UTC) - _t_start).total_seconds()
logger.info("Done in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"GeoJSON filter complete — {_total_elapsed:.1f}s total")
print(_SEP)
print()
print(f"  Total features   : {_stats['total']}")
print(f"  Kept             : {_stats['kept']}")
print(f"  Removed          : {_stats['removed']}")
print(f"  Output URI       : {OUTPUT_URI}")
print()
print(_SEP)
