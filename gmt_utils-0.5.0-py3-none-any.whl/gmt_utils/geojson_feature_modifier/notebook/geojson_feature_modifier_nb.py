# Databricks notebook source
# ---------------------------------------------------------------------------
# geojson_feature_modifier_nb.py — Databricks notebook interface for
# GeoJSON feature modification.
#
# This notebook:
#   1. Reads widget parameters (input_file, output_file, match_field, changes_json).
#   2. Reads a GeoJSON FeatureCollection from the input file reference
#      (s3://bucket/key or local path).
#   3. Calls the pure core function (modify_geojson) — no Spark I/O.
#   4. Writes the modified FeatureCollection to the output file reference.
#   5. Prints a summary of changes applied.
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import UTC, datetime
from pathlib import Path

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("geojson_feature_modifier_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "input_file", "",
    "File reference for the input GeoJSON — s3://bucket/key or local path",
)
dbutils.widgets.text(
    "output_file", "",
    "File reference for the modified GeoJSON output — s3://bucket/key or local path",
)
dbutils.widgets.text(
    "match_field", "linkId",
    "Feature property name used to identify features (e.g. linkId, zoneId)",
)
dbutils.widgets.text(
    "changes_json",
    '[{"linkId": "342", "flow": "+3"}]',
    "JSON array of change objects",
)
dbutils.widgets.text(
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_utils.geojson_feature_modifier.core.geojson_feature_modifier_core import modify_geojson

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

INPUT_FILE = dbutils.widgets.get("input_file").strip()
if not INPUT_FILE:
    raise ValueError("Widget 'input_file' is empty — provide a file reference (s3://bucket/key or local path).")

OUTPUT_FILE = dbutils.widgets.get("output_file").strip()
if not OUTPUT_FILE:
    raise ValueError("Widget 'output_file' is empty — provide a destination file reference.")

MATCH_FIELD = dbutils.widgets.get("match_field").strip()
if not MATCH_FIELD:
    raise ValueError("Widget 'match_field' is empty — provide the property name to match on (e.g. linkId).")

_changes_raw = dbutils.widgets.get("changes_json").strip()
if not _changes_raw:
    raise ValueError("Widget 'changes_json' is empty — provide a JSON array of change objects.")
CHANGES: list = json.loads(_changes_raw)

logger.info(
    "input=%s  output=%s  match_field=%s  changes=%d",
    INPUT_FILE, OUTPUT_FILE, MATCH_FIELD, len(CHANGES),
)

# COMMAND ----------
# ── I/O helpers ───────────────────────────────────────────────────────────────

import boto3


def _read_file(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read %s  (%d bytes)", uri, len(body))
        return body
    logger.info("Reading local file %s", uri)
    return Path(uri).read_bytes()


def _write_file(uri: str, data: bytes) -> str:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
        )
        logger.info("Wrote %s  (%d bytes)", uri, len(data))
        return uri
    local_path = Path(uri)
    local_path.parent.mkdir(parents=True, exist_ok=True)
    local_path.write_bytes(data)
    logger.info("Wrote %s  (%d bytes)", local_path, len(data))
    return str(local_path)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run GeoJSON Feature Modifier
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(UTC)
_created = _t_start.isoformat()

print(f"Starting    {_created}")
print(f"Input       : {INPUT_FILE}")
print(f"Output      : {OUTPUT_FILE}")
print(f"Match field : {MATCH_FIELD}")
print(f"Changes     : {len(CHANGES)}")
print()

_raw = _read_file(INPUT_FILE)
_fc = json.loads(_raw)

_modified_fc, _stats = modify_geojson(_fc, MATCH_FIELD, CHANGES)

_payload = json.dumps(_modified_fc, ensure_ascii=False).encode("utf-8")
_actual_output = _write_file(OUTPUT_FILE, _payload)

_total_elapsed = (datetime.now(UTC) - _t_start).total_seconds()
logger.info("GeoJSON feature modifier complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"GeoJSON Feature Modifier complete — {_total_elapsed:.1f}s")
print(_SEP)
print(f"  Input        : {INPUT_FILE}")
print(f"  Output       : {_actual_output}")
print(f"  Total        : {_stats['total']} features")
print(f"  Changes      : {_stats['changes']} change objects")
print(f"  Modified     : {_stats['modified']} feature-updates applied")
if _stats["warnings"]:
    print(f"  Warnings     : {len(_stats['warnings'])}")
    for _w in _stats["warnings"]:
        print(f"    ! {_w}")
print(_SEP)
