"""Request models for the geojson_feature_modifier Lambda."""

from __future__ import annotations

from pydantic import BaseModel, Field


class HandlerInput(BaseModel):
    """Validated input for the geojson_feature_modifier handler."""

    input_file: str = Field(
        ..., description="Full URI of the input GeoJSON (s3://bucket/key or local path)."
    )
    output_file: str = Field(
        ..., description="Full URI where the modified GeoJSON will be written."
    )
    match_field: str = Field(
        ..., description="Feature property name used to identify which features to update."
    )
    changes: list[dict] = Field(..., min_length=1, description="List of change objects to apply.")
