"""Pure-Python janitor core — no I/O, no boto3, no external deps.

Removes all GeoJSON feature properties not listed in a *schema*, optionally
renames them via ``source_field_name``, and supports computed fields via
``expression`` (e.g. ``"=flow/capacity"`` or ``"=round(flow/capacity, 2)"``).

Schema format
-------------
A plain ``dict[str, None | dict]`` where:

* ``null``  → keep the property as-is (target key == source key); set to
              ``null`` in the output if the property is absent on a feature.
* ``dict``  → one of three modes (evaluated in this order):

  - **Default value**: set ``default_value`` to any JSON-serialisable value
    (scalar, list, or object, e.g. ``{}`` or ``1``).  Every feature gets
    that exact value regardless of its own properties.
  - **Expression**: set ``expression`` to a formula string starting with
    ``=`` (e.g. ``"=flow/capacity"``).  The expression is evaluated against
    the feature's properties as variables.  Available functions: all
    ``math.*`` names plus ``round``, ``min``, ``max``.  Any missing or
    non-numeric property referenced in the formula produces ``null`` in the
    output.
  - **Copy / rename**: set ``source_field_name`` (optional) to read from a
    different source key.  The value is passed through unchanged.

Public API
----------
evaluate_expression(expression, props) -> float | None
    Evaluate a simple arithmetic expression against feature properties.

clean_features(features, schema) -> list[dict]
    Return a new list of features with only schema-defined properties.

clean_geojson(fc, schema) -> tuple[dict, dict]
    Clean one FeatureCollection; return (cleaned_fc, stats).
    stats: {"total": int, "cleaned": int, "schema_fields": int}
"""

from __future__ import annotations

import logging

from gmt_utils.janitor.domain.cleaner import clean_features, evaluate_expression  # noqa: F401

logger = logging.getLogger(__name__)


def clean_geojson(fc: dict, schema: dict) -> tuple[dict, dict]:
    """Remove all properties not listed in *schema* from a FeatureCollection.

    Parameters
    ----------
    fc:
        A GeoJSON FeatureCollection dict.
    schema:
        Field mapping as described in the module docstring.

    Returns
    -------
    cleaned_fc:
        A new FeatureCollection dict.  Top-level ``"properties"`` of the
        input are preserved unchanged.
    stats:
        ``{"total": int, "cleaned": int, "schema_fields": int}``
        where *cleaned* == *total* (every feature is always processed).
    """
    features: list[dict] = fc.get("features") or []

    if not features:
        logger.warning("clean_geojson called on empty FeatureCollection — nothing to clean.")
        surviving_keys = list(schema.keys())
        input_props = dict(fc.get("properties") or {})
        input_props["fields"] = surviving_keys
        return (
            {"type": "FeatureCollection", "features": [], "properties": input_props},
            {"total": 0, "cleaned": 0, "schema_fields": len(schema)},
        )

    logger.info(
        "Cleaning GeoJSON: %d features, %d schema fields", len(features), len(schema)
    )

    cleaned_features = clean_features(features, schema)

    # Derive linkProperties from schema output keys (the surviving property keys after cleaning).
    # This replaces any stale linkProperties inherited from the input FC.
    surviving_keys = list(schema.keys())
    out_props = dict(fc.get("properties") or {})
    out_props["fields"] = surviving_keys

    cleaned_fc = {
        "type": "FeatureCollection",
        "features": cleaned_features,
        "properties": out_props,
    }
    stats = {
        "total": len(features),
        "cleaned": len(cleaned_features),
        "schema_fields": len(schema),
    }

    logger.info(
        "Cleaning complete: %d features cleaned with %d schema fields",
        stats["cleaned"], stats["schema_fields"],
    )
    return cleaned_fc, stats
