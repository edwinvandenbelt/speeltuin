"""Local debug runner for melvin_downloader.

Authenticates with the NDW Melvin API, downloads roadworks data for a bounding
box, converts it to the GMT analytics GeoJSON format, and writes the result to
S3 or a local path.

Usage
-----
    # S3 areas file + S3 output:
    python -m melvin_downloader.melvin_downloader_runner \\
        --bbox "4.64,51.80,4.69,51.83" \\
        --start-period 2025-10-01 \\
        --end-period   2025-10-31 \\
        --areas-file   s3://gmp-networks/indices/melvin_areas.json \\
        --output       s3://gmp-networks/roadworks/roadworks-20251001.parquet

    # Local files:
    python -m melvin_downloader.melvin_downloader_runner \\
        --bbox "4.64,51.80,4.69,51.83" \\
        --start-period 2025-10-01 \\
        --end-period   2025-10-31 \\
        --areas-file   artifacts/indices/melvin_areas.json \\
        --output       /tmp/roadworks.parquet

Prerequisites
-------------
* MELVIN_USERNAME and MELVIN_PASSWORD must be set (env or .env file).
* AWS credentials available in the environment or .env file (only for s3:// URIs).

Environment variables
---------------------
MELVIN_USERNAME     Melvin account username (required).
MELVIN_PASSWORD     Melvin account password (required).
MELVIN_BASE_URL     Melvin REST base URL (default: https://melvin.ndw.nu/melvinservice/rest).
MELVIN_AUTH_URL     Melvin auth token URL (default: https://iam.ndw.nu/auth/realms/ndw/protocol/openid-connect/token).
MELVIN_CLIENT_ID    OAuth2 client ID (default: melvin-frontend-prod).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap — allow running as a script without pip-installing
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Melvin HTTP helpers (stdlib only — no requests)
# ---------------------------------------------------------------------------

_DEFAULT_BASE_URL = "https://melvin.ndw.nu/melvinservice/rest"
_DEFAULT_AUTH_URL = (
    "https://iam.ndw.nu/auth/realms/ndw/protocol/openid-connect/token"
)
_DEFAULT_CLIENT_ID = "melvin-frontend-prod"


def _authenticate(auth_url: str, client_id: str, username: str, password: str) -> str:
    """Obtain a Melvin JWT access token via the resource-owner-password flow."""
    payload = urllib.parse.urlencode({
        "username": username,
        "password": password,
        "grant_type": "password",
        "client_id": client_id,
    }).encode()
    req = urllib.request.Request(
        auth_url,
        data=payload,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:
        body = json.loads(resp.read())
    token: str = body.get("access_token", "")
    if not token:
        raise ValueError("No access_token found in Melvin auth response.")
    return token


def _export_geojson(
    base_url: str,
    token: str,
    start_period: str,
    end_period: str,
    area_id: int,
    activity_types: list[str],
    restriction_types: list[str],
) -> dict:
    """Call the Melvin /export endpoint for a single area and return the raw GeoJSON dict."""
    url = f"{base_url}/export"
    body_data = {
        "startPeriod": f"{start_period}T00:00:00Z",
        "endPeriod": f"{end_period}T23:59:59Z",
        "sources": ["MELVIN", "SPIN", "LTC"],
        "areaIds": [area_id],
        "statuses": ["START", "INITIAL", "CONCEPT", "FINAL"],
        "activityTypes": activity_types,
        "restrictionTypes": restriction_types,
        "includeDetours": True,
    }

    payload = json.dumps(body_data).encode()
    req = urllib.request.Request(
        url,
        data=payload,
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:
        return json.loads(resp.read())


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for melvin_downloader — downloads and converts Melvin roadworks data."
    )
    parser.add_argument(
        "--bbox",
        required=True,
        help="Bounding box as comma-separated 'min_lon,min_lat,max_lon,max_lat'.",
    )
    parser.add_argument(
        "--start-period",
        required=True,
        dest="start_period",
        help="Start date of the reporting period (YYYY-MM-DD).",
    )
    parser.add_argument(
        "--end-period",
        required=True,
        dest="end_period",
        help="End date of the reporting period (YYYY-MM-DD).",
    )
    parser.add_argument(
        "--areas-file",
        required=True,
        dest="areas_file",
        help="URI of the Melvin areas JSON file (s3://bucket/key or local path).",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="URI for the output analytics GeoParquet (s3://bucket/key or local path).",
    )
    parser.add_argument(
        "--activity-types",
        default="WORK,EVENT",
        dest="activity_types",
        help="Comma-separated Melvin activity types (default: WORK,EVENT).",
    )
    parser.add_argument(
        "--restriction-types",
        default="SPEED,COMPLETE",
        dest="restriction_types",
        help="Comma-separated Melvin restriction types (default: SPEED,COMPLETE).",
    )
    parser.add_argument(
        "--road-operator-types",
        default="MUNICIPALITY",
        dest="road_operator_types",
        help="Comma-separated roadOperatorType values to include (default: all).",
    )
    parser.add_argument(
        "--debug",
        type=int,
        default=None,
        metavar="N",
        dest="debug",
        help="Limit download to the first N areas (for debugging).",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        dest="env_file",
        help="Path to .env file for credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file: Path | None = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    # Parse bbox
    try:
        bbox_parts = [float(x.strip()) for x in args.bbox.split(",")]
        if len(bbox_parts) != 4:
            raise ValueError("Expected exactly 4 values.")
    except ValueError as exc:
        print(f"[error] --bbox must be 'min_lon,min_lat,max_lon,max_lat': {exc}", file=sys.stderr)
        sys.exit(1)

    # Credentials
    username = os.environ.get("MELVIN_USERNAME", "")
    password = os.environ.get("MELVIN_PASSWORD", "")
    if not username or not password:
        print(
            "[error] MELVIN_USERNAME and MELVIN_PASSWORD must be set in the environment or .env file.",
            file=sys.stderr,
        )
        sys.exit(1)

    base_url = os.environ.get("MELVIN_BASE_URL", _DEFAULT_BASE_URL)
    auth_url = os.environ.get("MELVIN_AUTH_URL", _DEFAULT_AUTH_URL)
    client_id = os.environ.get("MELVIN_CLIENT_ID", _DEFAULT_CLIENT_ID)

    from gmt_utils.melvin_downloader.core.melvin_downloader_core import (
        find_area_ids,
        to_analytics_geojson,
    )

    # Read areas file
    print(f"Reading areas file : {args.areas_file}")
    areas: list = json.loads(_read_uri(args.areas_file))
    print(f"Loaded {len(areas):,} areas.")

    # Apply road operator type filter
    road_operator_types = [t.strip() for t in args.road_operator_types.split(",") if t.strip()]
    if road_operator_types:
        areas = [a for a in areas if a.get("type") in road_operator_types]
        print(f"Filtered to {len(areas):,} areas by roadOperatorType {road_operator_types}.")

    # Find overlapping area IDs
    area_ids = find_area_ids(areas, bbox_parts)
    if args.debug is not None:
        area_ids = area_ids[:args.debug]
        print(f"[debug] Limiting to first {args.debug} area(s): {area_ids}")
    else:
        print(f"Area IDs overlapping bbox: {area_ids}")
    if not area_ids:
        print("[warning] No Melvin areas overlap the given bounding box.", file=sys.stderr)

    # Authenticate
    print("Authenticating with Melvin ...")
    token = _authenticate(auth_url, client_id, username, password)
    print("Authentication successful.")

    activity_type_list = [t.strip() for t in args.activity_types.split(",") if t.strip()]
    restriction_type_list = [t.strip() for t in args.restriction_types.split(",") if t.strip()]

    # Download per area, deduplicate by feature ID.
    print(f"Downloading from Melvin ({args.start_period} -> {args.end_period}) ...")
    features_by_id: dict[str, dict] = {}
    for area_id in area_ids:
        print(f"  Fetching area {area_id} ...", end=" ", flush=True)
        raw = _export_geojson(
            base_url, token,
            args.start_period, args.end_period,
            area_id,
            activity_type_list,
            restriction_type_list,
        )
        n = len(raw.get("features", []))
        print(f"{n} features")
        for feat in raw.get("features", []):
            fid = str(feat.get("id") or id(feat))
            features_by_id[fid] = feat

    raw_geojson = {"type": "FeatureCollection", "features": list(features_by_id.values())}
    print(f"Total raw features after deduplication: {len(features_by_id):,}")

    # Convert
    result_fc, stats = to_analytics_geojson(raw_geojson, bbox_parts)

    from gmt_shared.geoparquet import to_geoparquet

    # Write output
    print(f"Writing  : {args.output}")
    _write_uri(args.output, to_geoparquet(result_fc))

    print()
    print(f"Total raw features  : {stats['total']}")
    print(f"Skipped (Point)     : {stats['skipped_point']}")
    print(f"Skipped (bbox)      : {stats['skipped_bbox']}")
    print(f"Skipped (type)      : {stats['skipped_type']}")
    if stats["skipped_type_counts"]:
        print("  Other type breakdown:")
        for raw_type, count in sorted(
            stats["skipped_type_counts"].items(), key=lambda kv: -kv[1]
        ):
            print(f"    {raw_type}: {count}")
    print(f"Written to output   : {stats['output']}")
    print("Done.")


if __name__ == "__main__":
    main()
