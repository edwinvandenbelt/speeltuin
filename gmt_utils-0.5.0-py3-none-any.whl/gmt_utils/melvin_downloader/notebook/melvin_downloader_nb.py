# Databricks notebook source
# ---------------------------------------------------------------------------
# melvin_downloader_nb.py — Databricks notebook interface for melvin_downloader.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads the Melvin areas JSON from S3 (or local path when bucket is empty).
#   3. Authenticates with the NDW Melvin API.
#   4. Downloads raw roadworks GeoJSON from the Melvin /export endpoint.
#   5. Calls pure core functions to convert to analytics format.
#   6. Writes the result back to S3 (or local path).
#   7. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
import urllib.error
import urllib.parse
import urllib.request
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("melvin_downloader_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "bbox",
    "4.64,51.80,4.69,51.83",
    "Bounding box as min_lon,min_lat,max_lon,max_lat",
)
dbutils.widgets.text(
    "start_period",
    "2025-10-01",
    "Start date of the reporting period (YYYY-MM-DD)",
)
dbutils.widgets.text(
    "end_period",
    "2025-10-31",
    "End date of the reporting period (YYYY-MM-DD)",
)
dbutils.widgets.text(
    "areas_file",
    "s3://gmp-networks/indices/melvin_areas.json",
    "Full URI of the Melvin areas JSON file (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "output_file",
    "s3://gmp-networks/roadworks/roadworks.geojson",
    "Full URI for the output analytics GeoJSON (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "activity_types",
    "WORK,EVENT",
    "Comma-separated Melvin activity types (e.g. WORK,EVENT,WATERWAY)",
)
dbutils.widgets.text(
    "restriction_types",
    "SPEED,COMPLETE",
    "Comma-separated Melvin restriction types (e.g. SPEED,COMPLETE,NONE)",
)
dbutils.widgets.text(
    "debug_max_areas",
    "",
    "Limit download to first N areas (leave empty to download all)",
)
dbutils.widgets.text(
    "road_operator_types",
    "MUNICIPALITY",
    "Comma-separated roadOperatorType values to include (leave empty for all)",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

_BBOX_STR = dbutils.widgets.get("bbox").strip()
_START = dbutils.widgets.get("start_period").strip()
_END = dbutils.widgets.get("end_period").strip()
_AREAS_FILE = dbutils.widgets.get("areas_file").strip()
_OUTPUT_FILE = dbutils.widgets.get("output_file").strip()
_ACTIVITY_TYPES: list[str] = [
    t.strip() for t in dbutils.widgets.get("activity_types").split(",") if t.strip()
]
_RESTRICTION_TYPES: list[str] = [
    t.strip() for t in dbutils.widgets.get("restriction_types").split(",") if t.strip()
]
_DEBUG_MAX_AREAS_STR = dbutils.widgets.get("debug_max_areas").strip()
_DEBUG_MAX_AREAS: int | None = int(_DEBUG_MAX_AREAS_STR) if _DEBUG_MAX_AREAS_STR else None
_ROAD_OPERATOR_TYPES: list[str] = [
    t.strip() for t in dbutils.widgets.get("road_operator_types").split(",") if t.strip()
]

if not _BBOX_STR:
    raise ValueError("Widget 'bbox' is empty.")
if not _START:
    raise ValueError("Widget 'start_period' is empty.")
if not _END:
    raise ValueError("Widget 'end_period' is empty.")
if not _AREAS_FILE:
    raise ValueError("Widget 'areas_file' is empty.")
if not _OUTPUT_FILE:
    raise ValueError("Widget 'output_file' is empty.")

_BBOX: list[float] = [float(x.strip()) for x in _BBOX_STR.split(",")]
if len(_BBOX) != 4:
    raise ValueError(f"bbox must have 4 values, got: {_BBOX_STR!r}")

logger.info("bbox=%s  start=%s  end=%s", _BBOX, _START, _END)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3


def _get_s3_by_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        _, rest = uri.split("://", 1)
        bucket, key = rest.split("/", 1)
        body: bytes = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _put_s3_by_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        _, rest = uri.split("://", 1)
        bucket, key = rest.split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
    else:
        import os as _os

        _os.makedirs(_os.path.dirname(uri) or ".", exist_ok=True)
        with open(uri, "wb") as _fh:
            _fh.write(data)
        logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# ── Melvin HTTP helpers ────────────────────────────────────────────────────────

_DEFAULT_BASE_URL = "https://melvin.ndw.nu/melvinservice/rest"
_DEFAULT_AUTH_URL = "https://iam.ndw.nu/auth/realms/ndw/protocol/openid-connect/token"
_DEFAULT_CLIENT_ID = "melvin-frontend-prod"


def _authenticate(auth_url: str, client_id: str, username: str, password: str) -> str:
    payload = urllib.parse.urlencode(
        {
            "username": username,
            "password": password,
            "grant_type": "password",
            "client_id": client_id,
        }
    ).encode()
    req = urllib.request.Request(
        auth_url,
        data=payload,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:
        body = json.loads(resp.read())
    token: str = body.get("access_token", "")
    if not token:
        raise ValueError("No access_token in Melvin auth response.")
    return token


def _export_geojson(
    base_url: str,
    token: str,
    start_period: str,
    end_period: str,
    area_id: int,
    activity_types: list[str],
    restriction_types: list[str],
) -> dict:
    url = f"{base_url}/export"
    body_data = {
        "startPeriod": f"{start_period}T00:00:00Z",
        "endPeriod": f"{end_period}T23:59:59Z",
        "sources": ["MELVIN", "SPIN", "LTC"],
        "areaIds": [area_id],
        "statuses": ["START", "INITIAL", "CONCEPT", "FINAL"],
        "activityTypes": activity_types,
        "restrictionTypes": restriction_types,
        "includeDetours": True,
    }
    payload = json.dumps(body_data).encode()
    req = urllib.request.Request(
        url,
        data=payload,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:
        result: dict = json.loads(resp.read())
    return result


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run MelvinDownloader
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from gmt_utils.melvin_downloader.core.melvin_downloader_core import (
    find_area_ids,
    to_analytics_geojson,
)

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")
print(f"BBox      : {_BBOX}")
print(f"Period    : {_START} → {_END}")
print()

# Read areas file
print(f"Reading areas file: {_AREAS_FILE}")
_areas: list = json.loads(_get_s3_by_uri(_AREAS_FILE))
print(f"Loaded {len(_areas):,} areas.")

# Apply road operator type filter
if _ROAD_OPERATOR_TYPES:
    _areas = [a for a in _areas if a.get("roadOperatorType") in _ROAD_OPERATOR_TYPES]
    print(f"Filtered to {len(_areas):,} areas by roadOperatorType {_ROAD_OPERATOR_TYPES}.")

# Find area IDs
_area_ids = find_area_ids(_areas, _BBOX)
if _DEBUG_MAX_AREAS is not None:
    _area_ids = _area_ids[:_DEBUG_MAX_AREAS]
    print(f"[debug] Limiting to first {_DEBUG_MAX_AREAS} area(s): {_area_ids}")
else:
    print(f"Area IDs: {_area_ids}")

# Authenticate
_base_url = os.environ.get("MELVIN_BASE_URL", _DEFAULT_BASE_URL)
_auth_url = os.environ.get("MELVIN_AUTH_URL", _DEFAULT_AUTH_URL)
_client_id = os.environ.get("MELVIN_CLIENT_ID", _DEFAULT_CLIENT_ID)
_username = os.environ["MELVIN_USERNAME"]
_password = os.environ["MELVIN_PASSWORD"]

print("Authenticating ...")
_token = _authenticate(_auth_url, _client_id, _username, _password)
print("OK")

# Download per area, deduplicate by feature ID
print(f"Downloading ({_START} -> {_END}) ...")
_features_by_id: dict = {}
for _area_id in _area_ids:
    logger.info("Fetching area %s ...", _area_id)
    _area_raw = _export_geojson(
        _base_url,
        _token,
        _START,
        _END,
        _area_id,
        _ACTIVITY_TYPES,
        _RESTRICTION_TYPES,
    )
    for _feat in _area_raw.get("features", []):
        _fid = str(_feat.get("id") or id(_feat))
        _features_by_id[_fid] = _feat
_raw_geojson = {"type": "FeatureCollection", "features": list(_features_by_id.values())}
print(f"Total raw features after deduplication: {len(_features_by_id):,}")

# Convert
_result_fc, _stats = to_analytics_geojson(_raw_geojson, _BBOX)

# Write
_payload = json.dumps(_result_fc, ensure_ascii=False).encode("utf-8")
_put_s3_by_uri(_OUTPUT_FILE, _payload)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"MelvinDownloader complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  BBox           : {_BBOX}")
print(f"  Period         : {_START} → {_END}")
print(f"  Area IDs       : {_area_ids}")
print(f"  Raw features   : {_stats['total']}")
print(f"  Skipped Point  : {_stats['skipped_point']}")
print(f"  Skipped bbox   : {_stats['skipped_bbox']}")
print(f"  Skipped type   : {_stats['skipped_type']}")
if _stats["skipped_type_counts"]:
    print("  Other type breakdown:")
    for _raw_type, _cnt in sorted(_stats["skipped_type_counts"].items(), key=lambda kv: -kv[1]):
        print(f"    {_raw_type}: {_cnt}")
print(f"  Output written : {_stats['output']}")
print(f"  Output file    : {_OUTPUT_FILE}")
print(_SEP)
