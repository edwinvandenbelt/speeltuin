"""Unit tests for melvin_downloader_core pure functions."""

from __future__ import annotations

import sys
from pathlib import Path
from typing import ClassVar

# Ensure src/ is on the path when running pytest directly.
_HERE = Path(__file__).resolve()
for _parent in _HERE.parents:
    _cand = _parent / "src"
    if _cand.is_dir():
        if str(_cand) not in sys.path:
            sys.path.insert(0, str(_cand))
        break


from gmt_utils.melvin_downloader.core.melvin_downloader_core import (
    MELVIN_LINK_PROPERTIES,
    bbox_overlaps,
    find_area_ids,
    merge_multilinestring,
    to_analytics_geojson,
)

# ---------------------------------------------------------------------------
# bbox_overlaps
# ---------------------------------------------------------------------------


class TestBboxOverlaps:
    def test_identical_boxes_overlap(self) -> None:
        assert bbox_overlaps((0.0, 0.0, 1.0, 1.0), (0.0, 0.0, 1.0, 1.0)) is True

    def test_partial_overlap(self) -> None:
        assert bbox_overlaps((0.0, 0.0, 2.0, 2.0), (1.0, 1.0, 3.0, 3.0)) is True

    def test_touching_edge_overlap(self) -> None:
        # Boxes that share exactly one edge are considered overlapping.
        assert bbox_overlaps((0.0, 0.0, 1.0, 1.0), (1.0, 0.0, 2.0, 1.0)) is True

    def test_no_overlap_east(self) -> None:
        assert bbox_overlaps((0.0, 0.0, 1.0, 1.0), (2.0, 0.0, 3.0, 1.0)) is False

    def test_no_overlap_north(self) -> None:
        assert bbox_overlaps((0.0, 0.0, 1.0, 1.0), (0.0, 2.0, 1.0, 3.0)) is False

    def test_one_contained_in_other(self) -> None:
        assert bbox_overlaps((0.0, 0.0, 10.0, 10.0), (1.0, 1.0, 2.0, 2.0)) is True


# ---------------------------------------------------------------------------
# find_area_ids
# ---------------------------------------------------------------------------


def _make_polygon_area(area_id: int, minx: float, miny: float, maxx: float, maxy: float) -> dict:
    """Create a minimal Melvin area dict with a Polygon geometry."""
    coords = [
        [minx, miny],
        [maxx, miny],
        [maxx, maxy],
        [minx, maxy],
        [minx, miny],
    ]
    return {
        "id": area_id,
        "name": f"Area {area_id}",
        "geometry": {"type": "Polygon", "coordinates": [coords]},
    }


class TestFindAreaIds:
    def test_returns_overlapping_ids(self) -> None:
        areas = [
            _make_polygon_area(1, 0.0, 0.0, 1.0, 1.0),  # overlaps query
            _make_polygon_area(2, 5.0, 5.0, 6.0, 6.0),  # does not overlap
            _make_polygon_area(3, 0.5, 0.5, 1.5, 1.5),  # overlaps query
        ]
        result = find_area_ids(areas, [0.0, 0.0, 1.2, 1.2])
        assert result == [1, 3]

    def test_no_geometry_area_skipped(self) -> None:
        areas = [{"id": 99, "name": "No geometry"}]
        assert find_area_ids(areas, [0.0, 0.0, 1.0, 1.0]) == []

    def test_empty_areas_list(self) -> None:
        assert find_area_ids([], [0.0, 0.0, 1.0, 1.0]) == []

    def test_result_is_sorted(self) -> None:
        areas = [
            _make_polygon_area(10, 0.0, 0.0, 1.0, 1.0),
            _make_polygon_area(2, 0.0, 0.0, 1.0, 1.0),
            _make_polygon_area(7, 0.0, 0.0, 1.0, 1.0),
        ]
        assert find_area_ids(areas, [0.0, 0.0, 1.0, 1.0]) == [2, 7, 10]

    def test_multipolygon_geometry(self) -> None:
        area = {
            "id": 42,
            "geometry": {
                "type": "MultiPolygon",
                "coordinates": [
                    [[[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.0, 0.0]]],
                    [[[5.0, 5.0], [6.0, 5.0], [6.0, 6.0], [5.0, 6.0], [5.0, 5.0]]],
                ],
            },
        }
        # Query overlaps first polygon only.
        assert find_area_ids([area], [0.0, 0.0, 0.5, 0.5]) == [42]


# ---------------------------------------------------------------------------
# merge_multilinestring
# ---------------------------------------------------------------------------


class TestMergeMultilinestring:
    def test_empty(self) -> None:
        assert merge_multilinestring([]) == []

    def test_single_segment(self) -> None:
        seg = [[0.0, 0.0], [1.0, 0.0], [2.0, 0.0]]
        assert merge_multilinestring([seg]) == seg

    def test_two_connected_segments(self) -> None:
        s1 = [[0.0, 0.0], [1.0, 0.0]]
        s2 = [[1.0, 0.0], [2.0, 0.0]]
        result = merge_multilinestring([s1, s2])
        assert result == [[0.0, 0.0], [1.0, 0.0], [2.0, 0.0]]

    def test_two_disconnected_segments(self) -> None:
        s1 = [[0.0, 0.0], [1.0, 0.0]]
        s2 = [[9.0, 9.0], [10.0, 9.0]]
        result = merge_multilinestring([s1, s2])
        assert result == [[0.0, 0.0], [1.0, 0.0], [9.0, 9.0], [10.0, 9.0]]

    def test_three_segments_connected(self) -> None:
        s1 = [[0.0, 0.0], [1.0, 0.0]]
        s2 = [[1.0, 0.0], [2.0, 0.0]]
        s3 = [[2.0, 0.0], [3.0, 0.0]]
        result = merge_multilinestring([s1, s2, s3])
        assert result == [[0.0, 0.0], [1.0, 0.0], [2.0, 0.0], [3.0, 0.0]]


# ---------------------------------------------------------------------------
# to_analytics_geojson
# ---------------------------------------------------------------------------


def _make_fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features}


def _linestring_feature(
    feature_id: str | None = "f1", coords: list | None = None, props: dict | None = None
) -> dict:
    if coords is None:
        coords = [[4.64, 51.80], [4.65, 51.81]]
    return {
        "type": "Feature",
        "id": feature_id,
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": props
        if props is not None
        else {
            "type": "RESTRICTION",
            "recordId": feature_id,
            "name": "Test road",
            "restrictionType": "COMPLETE",
            "direction": "BOTH",
        },
    }


class TestToAnalyticsGeojson:
    _BBOX: ClassVar[list[float]] = [4.60, 51.75, 4.70, 51.85]

    def test_basic_linestring_passes_through(self) -> None:
        fc = _make_fc([_linestring_feature()])
        result, stats = to_analytics_geojson(fc, self._BBOX)
        assert stats["total"] == 1
        # direction=BOTH splits into 2 output features
        assert stats["output"] == 2
        assert stats["skipped_point"] == 0
        assert len(result["features"]) == 2

    def test_fc_has_properties(self) -> None:
        fc = _make_fc([_linestring_feature()])
        result, _ = to_analytics_geojson(fc, self._BBOX)
        fc_props = result["properties"]
        assert fc_props["modes"] == ["CAR"]
        assert fc_props["fields"] == list(MELVIN_LINK_PROPERTIES)
        assert fc_props["bbox"] == self._BBOX

    def test_point_feature_is_skipped(self) -> None:
        feature = {
            "type": "Feature",
            "id": "p1",
            "geometry": {"type": "Point", "coordinates": [4.64, 51.80]},
            "properties": {},
        }
        fc = _make_fc([feature])
        _result, stats = to_analytics_geojson(fc, self._BBOX)
        assert stats["skipped_point"] == 1
        assert stats["output"] == 0

    def test_out_of_bbox_feature_is_skipped(self) -> None:
        # LineString far outside the bbox.
        far_coords = [[10.0, 52.0], [11.0, 52.0]]
        fc = _make_fc([_linestring_feature(coords=far_coords)])
        _result, stats = to_analytics_geojson(fc, self._BBOX)
        assert stats["skipped_bbox"] == 1
        assert stats["output"] == 0

    def test_type_and_ids_set(self) -> None:
        coords = [[4.64, 51.80], [4.65, 51.81]]
        fc = _make_fc([_linestring_feature(feature_id="road42", coords=coords)])
        result, _ = to_analytics_geojson(fc, self._BBOX)
        # direction=BOTH splits into 2 features
        assert len(result["features"]) == 2
        fwd = result["features"][0]
        props = fwd["properties"]
        assert fwd["id"] == "road42"
        assert props["linkId"] == "road42"
        assert props["melvinId"] == "road42"
        assert props["mode"] == "CAR"
        assert props["direction"] == "A_B"
        assert props["reverseLinkIds"] == ["-road42"]
        assert "spectrumId" not in props
        assert "fromNode" not in props
        assert "toNode" not in props
        assert isinstance(props["length"], float)
        assert props["length"] > 0
        assert isinstance(props["heading"], float)

        bwd = result["features"][1]
        assert bwd["id"] == "-road42"
        assert bwd["properties"]["direction"] == "B_A"
        assert bwd["properties"]["reverseLinkIds"] == ["road42"]

    def test_both_direction_produces_two_offset_features(self) -> None:
        coords = [[4.64, 51.80], [4.65, 51.80]]  # east-going segment
        props = {
            "type": "RESTRICTION",
            "recordId": "r-both",
            "restrictionType": "COMPLETE",
            "direction": "BOTH",
        }
        fc = _make_fc([_linestring_feature(props=props, coords=coords)])
        result, stats = to_analytics_geojson(fc, self._BBOX)
        assert stats["output"] == 2
        fwd, bwd = result["features"]
        # IDs
        assert fwd["id"] == "r-both"
        assert bwd["id"] == "-r-both"
        # Directions
        assert fwd["properties"]["direction"] == "A_B"
        assert bwd["properties"]["direction"] == "B_A"
        # Cross-references
        assert fwd["properties"]["reverseLinkIds"] == ["-r-both"]
        assert bwd["properties"]["reverseLinkIds"] == ["r-both"]
        # Geometries are offset — not identical to original
        assert fwd["geometry"]["coordinates"] != coords
        # Forward and backward are different (one is offset of reversed)
        assert fwd["geometry"]["coordinates"] != bwd["geometry"]["coordinates"]

    def test_a_b_direction_single_feature(self) -> None:
        coords = [[4.64, 51.80], [4.65, 51.80]]
        props = {
            "type": "RESTRICTION",
            "recordId": "r-ab",
            "restrictionType": "SPEED",
            "direction": "A_B",
            "speed": 30,
        }
        fc = _make_fc([_linestring_feature(props=props, coords=coords)])
        result, stats = to_analytics_geojson(fc, self._BBOX)
        assert stats["output"] == 1
        feat = result["features"][0]
        assert feat["properties"]["direction"] == "A_B"
        assert feat["properties"]["reverseLinkIds"] == []
        # Coordinates unchanged (no offset for single-direction)
        assert feat["geometry"]["coordinates"] == coords

    def test_b_a_direction_reverses_coordinates(self) -> None:
        coords = [[4.64, 51.80], [4.65, 51.80]]
        props = {
            "type": "RESTRICTION",
            "recordId": "r-ba",
            "restrictionType": "SPEED",
            "direction": "B_A",
            "speed": 20,
        }
        fc = _make_fc([_linestring_feature(props=props, coords=coords)])
        result, stats = to_analytics_geojson(fc, self._BBOX)
        assert stats["output"] == 1
        feat = result["features"][0]
        assert feat["properties"]["direction"] == "B_A"
        assert feat["properties"]["reverseLinkIds"] == []
        assert feat["geometry"]["coordinates"] == list(reversed(coords))

    def test_linkid_from_record_id(self) -> None:
        props = {
            "type": "RESTRICTION",
            "recordId": "REC-99",
            "restrictionType": "COMPLETE",
            "direction": "A_B",
        }
        fc = _make_fc([_linestring_feature(feature_id="feat-1", props=props)])
        result, _ = to_analytics_geojson(fc, self._BBOX)
        out = result["features"][0]["properties"]
        assert out["linkId"] == "REC-99"
        assert out["melvinId"] == "REC-99"
        assert "recordId" not in out

    def test_complete_restriction_sets_capacity_and_flow_to_zero(self) -> None:
        props = {
            "type": "RESTRICTION",
            "recordId": "r1",
            "restrictionType": "COMPLETE",
            "direction": "BOTH",
            "speed": 30,
        }
        fc = _make_fc([_linestring_feature(props=props)])
        result, _ = to_analytics_geojson(fc, self._BBOX)
        # BOTH splits into two features; check both get capacity=0, flow=0, speed=None
        assert len(result["features"]) == 2
        for feat in result["features"]:
            out = feat["properties"]
            assert out["capacity"] == 0
            assert out["flow"] == 0
            assert out["speed"] is None
            assert out["restrictionType"] == "COMPLETE"
            assert out["direction"] in ("A_B", "B_A")

    def test_speed_restriction_sets_speed(self) -> None:
        props = {
            "type": "RESTRICTION",
            "recordId": "r2",
            "restrictionType": "SPEED",
            "direction": "A_B",
            "speed": 30,
        }
        fc = _make_fc([_linestring_feature(props=props)])
        result, _ = to_analytics_geojson(fc, self._BBOX)
        out = result["features"][0]["properties"]
        assert out["speed"] == 30
        assert out["capacity"] is None
        assert out["flow"] is None
        assert out["restrictionType"] == "SPEED"
        assert out["direction"] == "A_B"

    def test_melvin_type_and_excluded_fields_stripped(self) -> None:
        raw_props = {
            "type": "RESTRICTION",
            "recordId": "r3",
            "restrictionType": "COMPLETE",
            "direction": "B_A",
            "railwayTypes": ["FOO"],
            "boatTypes": [],
            "vehicleTypes": ["CAR"],
            "emergency": False,
            "roadManagementType": "NATIONAL",
            "transportMode": "ROAD",
            "periods": [],
            "publicTransport": False,
            "name": "Keep me",
        }
        fc = _make_fc([_linestring_feature(props=raw_props)])
        result, _ = to_analytics_geojson(fc, self._BBOX)
        out = result["features"][0]["properties"]
        for excluded in (
            "type",
            "melvinType",
            "recordId",
            "railwayTypes",
            "boatTypes",
            "vehicleTypes",
            "emergency",
            "roadManagementType",
            "transportMode",
            "periods",
            "publicTransport",
        ):
            assert excluded not in out, f"Expected {excluded!r} to be absent"
        assert out["name"] == "Keep me"
        assert out["direction"] == "B_A"

    def test_noisy_properties_stripped(self) -> None:
        noisy_props = {
            "name": "A road",
            "type": "RESTRICTION",
            "recordId": "r-noisy",
            "restrictionType": "COMPLETE",
            "direction": "BOTH",
            "createdBy": "user@example.com",
            "lastChangedBy": "editor@example.com",
            "remarks": "some remark",
            "contacts": ["contact1"],
            "source": "MELVIN",
        }
        fc = _make_fc([_linestring_feature(props=noisy_props)])
        result, _ = to_analytics_geojson(fc, self._BBOX)
        props = result["features"][0]["properties"]
        for noisy_key in ("createdBy", "lastChangedBy", "remarks", "contacts", "source"):
            assert noisy_key not in props, f"Expected {noisy_key!r} to be stripped"
        assert props["name"] == "A road"

    def test_multilinestring_merged_to_linestring(self) -> None:
        multi_coords = [
            [[4.64, 51.80], [4.645, 51.801]],
            [[4.645, 51.801], [4.65, 51.802]],
        ]
        feature = {
            "type": "Feature",
            "id": "ml1",
            "geometry": {"type": "MultiLineString", "coordinates": multi_coords},
            "properties": {
                "type": "RESTRICTION",
                "recordId": "ml1",
                "restrictionType": "COMPLETE",
                "direction": "A_B",
            },
        }
        fc = _make_fc([feature])
        result, stats = to_analytics_geojson(fc, self._BBOX)
        assert stats["output"] == 1
        out_geom = result["features"][0]["geometry"]
        assert out_geom["type"] == "LineString"
        # Shared endpoint should not be duplicated.
        assert out_geom["coordinates"] == [
            [4.64, 51.80],
            [4.645, 51.801],
            [4.65, 51.802],
        ]

    def test_empty_feature_collection(self) -> None:
        result, stats = to_analytics_geojson(_make_fc([]), self._BBOX)
        assert stats["total"] == 0
        assert stats["output"] == 0
        assert result["type"] == "FeatureCollection"
        assert result["features"] == []
