"""Local runner for parquet_exporter.

Converts a GeoParquet pipeline artifact to GeoJSON or GeoJSONL format.
Reads from a local path or ``s3://`` URI; writes to a local path, an
``s3://`` URI, or stdout.

Usage
-----
    # Convert to GeoJSON, write to file:
    python -m parquet_exporter.parquet_exporter_runner \\
        --input  s3://gmp-networks/network/deventer-NETWORK-CAR.parquet \\
        --output s3://gmp-networks/exports/deventer-NETWORK-CAR.geojson

    # Convert to GeoJSONL with metadata header, write locally:
    python -m parquet_exporter.parquet_exporter_runner \\
        --input  /tmp/deventer-NETWORK-CAR.parquet \\
        --format geojsonl \\
        --geojsonl-include-metadata \\
        --output /tmp/deventer-NETWORK-CAR.geojsonl

    # Stream GeoJSON to stdout (stats go to stderr):
    python -m parquet_exporter.parquet_exporter_runner \\
        --input  s3://gmp-networks/network/deventer-NETWORK-CAR.parquet

Prerequisites
-------------
* geopandas, pyarrow, shapely installed (for GeoParquet deserialisation).
* AWS credentials available in the environment or a .env file (only needed
  for s3:// URIs).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# Format constants
# ---------------------------------------------------------------------------

_FORMAT_EXT: dict[str, str] = {"geojson": ".geojson", "geojsonl": ".geojsonl"}
_FORMAT_CTYPE: dict[str, str] = {
    "geojson": "application/geo+json",
    "geojsonl": "application/x-ndjson",
}


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes, *, content_type: str) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data, content_type)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Extension correction
# ---------------------------------------------------------------------------

def _correct_extension(output_uri: str, fmt: str) -> str:
    """Ensure *output_uri* ends with the correct extension for *fmt*.

    If the existing file extension differs from what *fmt* requires, it is
    replaced and a warning is printed to stderr.
    """
    expected_ext = _FORMAT_EXT[fmt]
    # Normalise separators and extract the last path component.
    last_seg = output_uri.replace("\\", "/").rsplit("/", 1)[-1]
    if "." in last_seg:
        current_ext = "." + last_seg.rsplit(".", 1)[-1]
        if current_ext.lower() != expected_ext.lower():
            # Replace the last occurrence of the current extension.
            idx = output_uri.rfind(current_ext)
            corrected = output_uri[:idx] + expected_ext
            print(
                f"[warn] Output extension '{current_ext}' does not match "
                f"--format '{fmt}'; renaming to '{expected_ext}'.",
                file=sys.stderr,
            )
            return corrected
    return output_uri


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Convert a GeoParquet file to GeoJSON or GeoJSONL.",
    )
    parser.add_argument(
        "--input",
        required=True,
        help="Input file reference: s3://bucket/key or local path.",
    )
    parser.add_argument(
        "--format",
        choices=["geojson", "geojsonl"],
        default="geojson",
        help="Output format (default: geojson).",
    )
    parser.add_argument(
        "--output",
        default=None,
        help=(
            "Output file reference: s3://bucket/key or local path. "
            "Omit to write to stdout."
        ),
    )
    parser.add_argument(
        "--geojsonl-include-metadata",
        action="store_true",
        default=False,
        help=(
            "GeoJSONL only: prepend a header line with the FeatureCollection-level "
            "properties dict. Ignored when --format is geojson."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet

    from gmt_utils.parquet_exporter.core.parquet_exporter_core import (
        export_to_geojson,
        export_to_geojsonl,
    )

    # Read and deserialise the GeoParquet input.
    print(f"Reading  : {args.input}", file=sys.stderr)
    raw_bytes = _read_uri(args.input)
    fc = from_geoparquet(raw_bytes)

    feature_count = len(fc.get("features") or [])

    # Serialise to the requested format.
    if args.format == "geojson":
        content = export_to_geojson(fc)
    else:
        content = export_to_geojsonl(fc, include_metadata=args.geojsonl_include_metadata)

    content_bytes = content.encode("utf-8")

    if args.output:
        # Correct the output extension if needed.
        out_uri = _correct_extension(args.output, args.format)
        _write_uri(out_uri, content_bytes, content_type=_FORMAT_CTYPE[args.format])

        # Stats → stdout (normal print, visible alongside other pipeline output).
        print()
        print(f"Features : {feature_count:,}")
        print(f"Format   : {args.format}")
        print(f"Bytes    : {len(content_bytes):,}")
        print(f"Output   : {out_uri}")
    else:
        # Stream content to stdout; stats go to stderr so they don't pollute the pipe.
        sys.stdout.buffer.write(content_bytes)
        sys.stdout.buffer.flush()

        print(f"Features : {feature_count:,}", file=sys.stderr)
        print(f"Format   : {args.format}", file=sys.stderr)
        print(f"Bytes    : {len(content_bytes):,}", file=sys.stderr)


if __name__ == "__main__":
    main()
