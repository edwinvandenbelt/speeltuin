"""Unit tests for prepare.core.prepare_core — pure helper functions only."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from prepare.core.prepare_core import (
    _CheckpointStore,
    _discover_or_create_area_id,
    _extract_area_polygon_json,
    _filter_fc_by_mode,
    _resolve_osm_flags,
    _validate_modes,
    run_pipeline,
)


# ---------------------------------------------------------------------------
# _validate_modes
# ---------------------------------------------------------------------------


class TestValidateModes:
    def test_single_valid_mode_passes(self):
        _validate_modes(["CAR"], "CAR")  # no exception

    def test_multi_mode_passes(self):
        _validate_modes(["CAR", "BIKE"], "MIXED")  # no exception

    def test_pedestrian_alone_passes(self):
        _validate_modes(["PEDESTRIAN"], "PEDESTRIAN")  # no exception

    def test_empty_modes_raises(self):
        with pytest.raises(ValueError, match="At least one transport mode"):
            _validate_modes([], "CAR")

    def test_unknown_mode_raises(self):
        with pytest.raises(ValueError, match="Unsupported mode"):
            _validate_modes(["HELICOPTER"], "HELICOPTER")

    def test_pedestrian_combined_raises(self):
        with pytest.raises(ValueError, match="PEDESTRIAN cannot be combined"):
            _validate_modes(["PEDESTRIAN", "CAR"], "MIXED")

    def test_mode_label_with_hyphen_raises(self):
        with pytest.raises(ValueError, match="must not contain hyphens"):
            _validate_modes(["CAR"], "CAR-BIKE")

    def test_multi_mode_label_without_hyphen_passes(self):
        _validate_modes(["CAR", "BIKE"], "CARBIKE")  # no exception


# ---------------------------------------------------------------------------
# mode_label default logic
# ---------------------------------------------------------------------------


class TestModeLabelDefault:
    """Verify that the default-label logic applied in run_pipeline is correct.

    We test the logic directly rather than calling run_pipeline (which requires
    a live Databricks connection).  The rule is:
        len(modes) == 1  →  label = modes[0]
        len(modes) >  1  →  label = "MIXED"
    """

    def _apply_default(self, modes: list[str], mode_label: str | None = None) -> str:
        """Mirror the normalise/default block at the top of run_pipeline."""
        modes = [m.strip().upper() for m in modes]
        if mode_label is None:
            return "MIXED" if len(modes) > 1 else modes[0]
        return mode_label.strip().upper()

    def test_single_mode_defaults_to_mode_name(self):
        assert self._apply_default(["CAR"]) == "CAR"

    def test_multi_mode_defaults_to_mixed(self):
        assert self._apply_default(["CAR", "BIKE"]) == "MIXED"

    def test_explicit_label_overrides_default(self):
        assert self._apply_default(["CAR", "BIKE"], "MULTIMODAAL") == "MULTIMODAAL"

    def test_explicit_label_single_mode(self):
        assert self._apply_default(["CAR"], "WEGNETWERK") == "WEGNETWERK"


# ---------------------------------------------------------------------------
# _discover_or_create_area_id
# ---------------------------------------------------------------------------


class TestDiscoverOrCreateAreaId:
    def test_generates_fresh_uuid_for_empty_dir(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            area_id = _discover_or_create_area_id(out_dir)
            assert len(area_id) == 36  # UUID format

    def test_discovers_from_existing_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "my-fixed-id-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_or_create_area_id(out_dir) == "my-fixed-id"

    def test_stable_across_calls(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "stable-id-NETWORK-CAR.parquet").write_bytes(b"")
            id1 = _discover_or_create_area_id(out_dir)
            id2 = _discover_or_create_area_id(out_dir)
            assert id1 == id2

    def test_explicit_override_takes_priority(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "other-id-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_or_create_area_id(out_dir, area_id="forced-id") == "forced-id"


# ---------------------------------------------------------------------------
# _extract_area_polygon_json
# ---------------------------------------------------------------------------


class TestExtractAreaPolygonJson:
    def _make_zones_fc(self, features: list[dict]) -> dict:
        return {"type": "FeatureCollection", "features": features}

    def test_extracts_area_geometry(self):
        geom = {"type": "Polygon", "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 0]]]}
        zones_fc = self._make_zones_fc(
            [
                {"type": "Feature", "properties": {"zoneClass": "STUDY"}, "geometry": {}},
                {"type": "Feature", "properties": {"zoneClass": "AREA"}, "geometry": geom},
            ]
        )
        result = json.loads(_extract_area_polygon_json(zones_fc))
        assert result == geom

    def test_raises_when_no_area_feature(self):
        zones_fc = self._make_zones_fc(
            [
                {"type": "Feature", "properties": {"zoneClass": "STUDY"}, "geometry": {}},
            ]
        )
        with pytest.raises(ValueError, match="No AREA feature"):
            _extract_area_polygon_json(zones_fc)

    def test_raises_on_empty_feature_collection(self):
        with pytest.raises(ValueError):
            _extract_area_polygon_json(self._make_zones_fc([]))


# ---------------------------------------------------------------------------
# _filter_fc_by_mode
# ---------------------------------------------------------------------------


def _make_fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features, "properties": {"modeLabel": "MIXED"}}


def _make_link(mode: str) -> dict:
    return {"type": "Feature", "geometry": None, "properties": {"mode": mode, "linkId": 1}}


class TestFilterFcByMode:
    def test_keeps_matching_mode(self):
        fc = _make_fc([_make_link("CAR"), _make_link("BIKE")])
        result = _filter_fc_by_mode(fc, "CAR")
        assert len(result["features"]) == 1
        assert result["features"][0]["properties"]["mode"] == "CAR"

    def test_excludes_non_matching_mode(self):
        fc = _make_fc([_make_link("CAR"), _make_link("CAR")])
        result = _filter_fc_by_mode(fc, "BIKE")
        assert result["features"] == []

    def test_empty_input_stays_empty(self):
        fc = _make_fc([])
        result = _filter_fc_by_mode(fc, "CAR")
        assert result["features"] == []

    def test_preserves_top_level_properties(self):
        fc = _make_fc([_make_link("CAR")])
        result = _filter_fc_by_mode(fc, "CAR")
        assert result["properties"]["modeLabel"] == "MIXED"

    def test_features_without_mode_excluded(self):
        no_mode = {"type": "Feature", "geometry": None, "properties": {"linkId": 99}}
        fc = _make_fc([no_mode, _make_link("CAR")])
        result = _filter_fc_by_mode(fc, "CAR")
        assert len(result["features"]) == 1

    def test_returns_new_dict_not_mutation(self):
        fc = _make_fc([_make_link("CAR"), _make_link("BIKE")])
        result = _filter_fc_by_mode(fc, "CAR")
        assert len(fc["features"]) == 2  # original unchanged
        assert len(result["features"]) == 1


# ---------------------------------------------------------------------------
# source metadata in FC properties
# ---------------------------------------------------------------------------


class TestFcSourceMetadata:
    """Verify that prepare_core sets source='Spectrum' on output FCs.

    These tests exercise the dict-update patterns directly rather than
    running the full pipeline (which requires mocking Databricks).
    """

    def test_network_fc_properties_update_sets_source(self):
        fc: dict = {"type": "FeatureCollection", "features": []}
        fc.setdefault("properties", {}).update(
            {
                "bbox": [0.0, 0.0, 1.0, 1.0],
                "region": None,
                "area_id": "test",
                "name": "Test",
                "modeLabel": "CAR",
                "source": "Spectrum",
            }
        )
        assert fc["properties"]["source"] == "Spectrum"

    def test_zones_fc_properties_update_sets_source(self):
        fc: dict = {"type": "FeatureCollection", "features": [], "properties": {"name": "old"}}
        fc.setdefault("properties", {}).update({"name": "Test", "source": "Spectrum"})
        assert fc["properties"]["source"] == "Spectrum"
        assert fc["properties"]["name"] == "Test"

    def test_feedlinks_fc_properties_dict_contains_source(self):
        base_props: dict = {"area_id": "test"}
        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": [],
            "properties": {**base_props, "source": "Spectrum"},
        }
        assert feedlinks_fc["properties"]["source"] == "Spectrum"
        assert feedlinks_fc["properties"]["area_id"] == "test"  # base props preserved


# ---------------------------------------------------------------------------
# _CheckpointStore
# ---------------------------------------------------------------------------


def _sample_fc(n: int = 2) -> dict:
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [float(i), float(i)]},
                "properties": {"id": i},
            }
            for i in range(n)
        ],
        "properties": {"area_id": "test", "modes": ["CAR"]},
    }


class TestCheckpointStore:
    def test_save_load_roundtrip_preserves_features_and_properties(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            fc = _sample_fc(3)
            store.save("01_stage", fc)

            loaded = store.load("01_stage")
            assert loaded is not None
            assert len(loaded["features"]) == 3
            assert loaded["properties"]["area_id"] == "test"
            assert loaded["properties"]["modes"] == ["CAR"]

    def test_load_missing_returns_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            assert store.load("does_not_exist") is None

    def test_refresh_wipes_existing_and_disables_loading(self):
        with tempfile.TemporaryDirectory() as tmp:
            _CheckpointStore(Path(tmp), refresh=False).save("01_stage", _sample_fc())
            # A fresh store with refresh=True should ignore the pre-existing checkpoint.
            store = _CheckpointStore(Path(tmp), refresh=True)
            assert store.load("01_stage") is None

    def test_load_corrupt_checkpoint_returns_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            (store.dir / "01_stage.parquet").write_bytes(b"not a parquet file")
            assert store.load("01_stage") is None

    def test_save_is_atomic_no_tmp_left_behind(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            store.save("01_stage", _sample_fc())
            assert not (store.dir / "01_stage.parquet.tmp").exists()
            assert (store.dir / "01_stage.parquet").exists()

    def test_clear_removes_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            store.save("01_stage", _sample_fc())
            store.clear()
            assert not store.dir.exists()

    def test_empty_featurecollection_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            store.save("01_empty", {"type": "FeatureCollection", "features": [], "properties": {}})
            loaded = store.load("01_empty")
            assert loaded is not None
            assert loaded["features"] == []


# ---------------------------------------------------------------------------
# _resolve_osm_flags
# ---------------------------------------------------------------------------


class TestResolveOsmFlags:
    def _all_on(self, *, no_osm: bool, ndw_available: bool) -> dict:
        return _resolve_osm_flags(
            no_osm=no_osm,
            annotate_traffic_signals=True,
            fetch_traffic_signs=True,
            fetch_osm_assets=True,
            fetch_buildings=True,
            fetch_vegetation=True,
            fetch_parking_areas=True,
            ndw_available=ndw_available,
        )

    def test_no_osm_false_passes_through(self):
        result = self._all_on(no_osm=False, ndw_available=False)
        assert result == {
            "annotate_traffic_signals": True,
            "fetch_traffic_signs": True,
            "fetch_osm_assets": True,
            "fetch_buildings": True,
            "fetch_vegetation": True,
            "fetch_parking_areas": True,
            "parking_use_osm": True,
        }

    def test_no_osm_false_preserves_disabled_flags(self):
        result = _resolve_osm_flags(
            no_osm=False,
            annotate_traffic_signals=False,
            fetch_traffic_signs=False,
            fetch_osm_assets=False,
            fetch_buildings=False,
            fetch_vegetation=False,
            fetch_parking_areas=False,
            ndw_available=True,
        )
        assert result["annotate_traffic_signals"] is False
        assert result["fetch_osm_assets"] is False
        assert result["fetch_buildings"] is False
        assert result["fetch_parking_areas"] is False
        assert result["parking_use_osm"] is True

    def test_no_osm_disables_pure_osm_sources(self):
        result = self._all_on(no_osm=True, ndw_available=True)
        assert result["annotate_traffic_signals"] is False
        assert result["fetch_osm_assets"] is False
        assert result["fetch_buildings"] is False
        assert result["fetch_vegetation"] is False

    def test_no_osm_keeps_bgt_and_parking_bgt_only(self):
        result = self._all_on(no_osm=True, ndw_available=True)
        # parking stays enabled but its OSM leg is off (BGT-only)
        assert result["fetch_parking_areas"] is True
        assert result["parking_use_osm"] is False

    def test_no_osm_signs_on_only_when_ndw_available(self):
        with_ndw = self._all_on(no_osm=True, ndw_available=True)
        without_ndw = self._all_on(no_osm=True, ndw_available=False)
        assert with_ndw["fetch_traffic_signs"] is True
        assert without_ndw["fetch_traffic_signs"] is False

    def test_no_osm_signs_off_when_disabled_even_with_ndw(self):
        result = _resolve_osm_flags(
            no_osm=True,
            annotate_traffic_signals=True,
            fetch_traffic_signs=False,
            fetch_osm_assets=True,
            fetch_buildings=True,
            fetch_vegetation=True,
            fetch_parking_areas=True,
            ndw_available=True,
        )
        assert result["fetch_traffic_signs"] is False


# ---------------------------------------------------------------------------
# run_pipeline — no_osm / only_osm guards (no Databricks required)
# ---------------------------------------------------------------------------


class TestRunPipelineOsmModes:
    def test_no_osm_and_only_osm_mutually_exclusive(self):
        with (
            tempfile.TemporaryDirectory() as tmp,
            pytest.raises(ValueError, match="mutually exclusive"),
        ):
            run_pipeline(
                min_lon=6.0,
                min_lat=52.0,
                max_lon=6.1,
                max_lat=52.1,
                modes=["CAR"],
                name="Test",
                out_dir=Path(tmp),
                catalog="spectrum",
                schema="2024_01",
                refresh=False,
                debug=False,
                no_osm=True,
                only_osm=True,
            )

    def test_only_osm_without_existing_network_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError, match="requires an existing network"):
                run_pipeline(
                    min_lon=6.0,
                    min_lat=52.0,
                    max_lon=6.1,
                    max_lat=52.1,
                    modes=["CAR"],
                    name="Test",
                    out_dir=Path(tmp),
                    catalog="spectrum",
                    schema="2024_01",
                    refresh=False,
                    debug=False,
                    only_osm=True,
                )
            # No output files should have been written.
            assert not any(Path(tmp).glob("*-NETWORK-*.parquet"))
