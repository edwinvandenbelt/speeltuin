"""Overpass API client — puur stdlib (urllib), geen extra dependencies.

Used by osm_network_fetcher and osm_zone_fetcher to query the Overpass API.

Public API
----------
fetch_overpass(query, *, url, timeout) -> dict
    Send an Overpass QL query and return the parsed JSON response.
    Responses are cached on disk when OVERPASS_CACHE_DIR is set (or always
    when the default cache dir ``{tempdir}/overpass_cache`` exists).
split_bbox(bbox, nx, ny) -> list[list[float]]
    Split a bounding box into nx × ny sub-bboxes (tiles).
merge_elements(lists) -> list[dict]
    Merge and deduplicate Overpass element lists by (type, id).
fetch_overpass_tiled(query_fn, bbox, *, tiles, url, timeout) -> dict
    Fetch Overpass data in tiles and return a merged response.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any, Callable

logger = logging.getLogger(__name__)

_OVERPASS_URL_FALLBACK = "https://overpass-api.de/api/interpreter"


def resolve_overpass_url(url: str | None = None) -> str:
    """Resolve the effective Overpass endpoint at call time.

    Resolution order:
    1. An explicit, non-empty *url* argument.
    2. The ``OVERPASS_URL`` environment variable (empty / whitespace-only is
       treated as *unset* so a blank override falls through).
    3. The public Overpass instance as a last resort.

    Resolving lazily (rather than freezing a module constant at import time)
    means a ``.env`` file loaded *after* this module is imported is still
    honoured, and a stale/blank ``OVERPASS_URL`` never yields a broken endpoint.
    """
    if url and url.strip():
        return url.strip()
    env_url = os.environ.get("OVERPASS_URL", "").strip()
    return env_url or _OVERPASS_URL_FALLBACK


# Backwards-compatible module constant.  NOTE: this is a snapshot taken at import
# time — prefer ``resolve_overpass_url()`` (or pass ``url=None`` to the fetch
# helpers) so that a later-loaded ``.env`` and empty overrides are respected.
DEFAULT_OVERPASS_URL: str = resolve_overpass_url()

# Serialise all Overpass HTTP requests across threads.  Private Overpass
# instances (and the public one) reject concurrent queries from the same
# client with a `duplicate_query` dispatcher error.
_overpass_lock = threading.Lock()


# ---------------------------------------------------------------------------
# Disk cache helpers
# ---------------------------------------------------------------------------


def _cache_dir() -> Path | None:
    """Return the active cache directory, or None when caching is disabled.

    Resolution order:
    1. ``OVERPASS_CACHE_DIR`` environment variable (set to an empty string to
       disable caching explicitly).
    2. ``{tempdir}/overpass_cache`` when that directory already exists (created
       by a previous run or by the user).
    3. ``None`` — no caching.
    """
    env_val = os.environ.get("OVERPASS_CACHE_DIR")
    if env_val is not None:
        return Path(env_val) if env_val.strip() else None
    default = Path(tempfile.gettempdir()) / "overpass_cache"
    return default if default.is_dir() else None


def _cache_key(query: str) -> str:
    """Return a stable filename-safe key for *query*."""
    return hashlib.sha256(query.encode()).hexdigest()


def _cache_load(cache_dir: Path, key: str) -> dict[str, Any] | None:
    """Load a cached response.  Returns None on miss or read error."""
    path = cache_dir / f"{key}.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        logger.info("Overpass cache HIT  %s", path.name)
        return data
    except Exception as exc:  # noqa: BLE001
        logger.warning("Overpass cache read failed (%s): %s", path.name, exc)
        return None


def _cache_store(cache_dir: Path, key: str, data: dict[str, Any]) -> None:
    """Persist *data* to the cache directory.  Silently ignores write errors."""
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        path = cache_dir / f"{key}.json"
        path.write_text(json.dumps(data), encoding="utf-8")
        n = len(data.get("elements") or [])
        logger.info("Overpass cache STORE %s  (%d elements)", path.name, n)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Overpass cache write failed: %s", exc)


def fetch_overpass(
    query: str,
    *,
    url: str | None = None,
    timeout: int = 90,
    retries: int = 3,
) -> dict[str, Any]:
    """Send an Overpass QL query and return the parsed JSON response.

    Responses are cached on disk so that repeated calls with the same query
    skip the network entirely.  See :func:`_cache_dir` for the resolution
    order of the cache directory.

    Parameters
    ----------
    query:
        Overpass QL query string.
    url:
        Overpass API endpoint URL.  Defaults to the public instance.
    timeout:
        HTTP request timeout in seconds.
    retries:
        Maximum number of retry attempts on transient errors (connection
        refused, network errors, HTTP 429 / 5xx).  Uses exponential backoff:
        ``2 ** attempt`` seconds between retries.  Defaults to 3.

    Returns
    -------
    Parsed JSON response dict.

    Raises
    ------
    urllib.error.URLError:
        On network / DNS errors after all retries are exhausted.
    urllib.error.HTTPError:
        On HTTP 4xx / 5xx responses after all retries are exhausted.
    ValueError:
        If the response body is not valid JSON.
    RuntimeError:
        If Overpass returns a ``remark`` element containing an error or
        ``exceeded`` (rate-limit hit).
    """
    # Cache lookup — keyed on the raw query (without the unique run_id).
    url = resolve_overpass_url(url)
    cache = _cache_dir()
    key: str | None = None
    if cache is not None:
        key = _cache_key(query)
        cached = _cache_load(cache, key)
        if cached is not None:
            print(f"  [Overpass] cache HIT  (key={key[:12]}…)")
            return cached

    # Serialise all HTTP requests: private (and public) Overpass instances
    # reject concurrent queries from the same client with `duplicate_query`.
    last_exc: Exception | None = None
    body: str = ""
    for attempt in range(retries):
        if attempt > 0:
            wait = 2**attempt
            logger.warning(
                "Overpass retry %d/%d after %.0fs (last error: %s)",
                attempt,
                retries - 1,
                wait,
                last_exc,
            )
            time.sleep(wait)

        try:
            with _overpass_lock:
                # Prepend a unique comment so the dispatcher never rejects the
                # request as a duplicate of a recently completed query.
                unique_query = f"/* run_id:{uuid.uuid4()} */\n{query}"
                encoded = urllib.parse.urlencode({"data": unique_query}).encode("utf-8")
                req = urllib.request.Request(url, data=encoded, method="POST")
                req.add_header("Content-Type", "application/x-www-form-urlencoded")
                req.add_header("User-Agent", "gmt-calculation-lib/1.0")
                req.add_header("Accept", "application/json")

                print(f"  [Overpass] POST {url}  ({len(encoded)} bytes)")
                logger.debug("Overpass POST %s  (%d bytes)", url, len(encoded))
                with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
                    # Retry on HTTP 429 (rate-limit) and 5xx (server error).
                    if resp.status in (429, 500, 502, 503, 504):
                        raise urllib.error.HTTPError(
                            url, resp.status, resp.reason, resp.headers, None
                        )
                    body = resp.read().decode("utf-8")
            break  # success — exit retry loop
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504):
                last_exc = exc
                continue  # retryable
            raise  # 4xx or other non-retryable HTTP error
        except urllib.error.URLError as exc:
            last_exc = exc
            continue  # connection refused, DNS failure, timeout — all retryable
    else:
        # All attempts exhausted — re-raise the last recorded exception.
        raise last_exc  # type: ignore[misc]

    try:
        data: dict[str, Any] = json.loads(body)
    except json.JSONDecodeError as exc:
        # Overpass sometimes returns an XML error page (e.g. duplicate_query,
        # rate limit, or server error).  Extract the message when possible.
        if "<strong" in body or "Error" in body:
            import re  # noqa: PLC0415

            match = re.search(r"<strong[^>]*>Error</strong>\s*:\s*([^<]+)", body)
            msg = match.group(1).strip() if match else body[:300]
            raise RuntimeError(f"Overpass returned an error: {msg}") from exc
        raise ValueError(f"Overpass returned invalid JSON: {exc}") from exc

    for remark in data.get("remarks", []):
        if "error" in remark.lower() or "exceeded" in remark.lower():
            raise RuntimeError(f"Overpass API remark: {remark}")

    n_elements = len(data.get("elements") or [])
    logger.debug("Overpass returned %d elements", n_elements)

    # Store in cache for future runs.
    if cache is not None and key is not None:
        _cache_store(cache, key, data)

    return data


# ---------------------------------------------------------------------------
# Tiling utilities
# ---------------------------------------------------------------------------


def split_bbox(
    bbox: list[float],
    nx: int,
    ny: int,
) -> list[list[float]]:
    """Split a bounding box into nx × ny evenly-sized tiles.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS 84.
    nx:
        Number of columns (longitude divisions).
    ny:
        Number of rows (latitude divisions).

    Returns
    -------
    List of ``[minLon, minLat, maxLon, maxLat]`` sub-bboxes, row-major order
    (bottom row first).
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    lon_step = (max_lon - min_lon) / nx
    lat_step = (max_lat - min_lat) / ny
    tiles: list[list[float]] = []
    for iy in range(ny):
        for ix in range(nx):
            tiles.append(
                [
                    min_lon + ix * lon_step,
                    min_lat + iy * lat_step,
                    min_lon + (ix + 1) * lon_step,
                    min_lat + (iy + 1) * lat_step,
                ]
            )
    return tiles


def merge_elements(lists: list[list[dict]]) -> list[dict]:
    """Merge and deduplicate Overpass element lists.

    Elements are deduplicated by ``(type, id)``.  The first occurrence of
    each element is kept (preserving embedded geometry).

    Parameters
    ----------
    lists:
        One or more lists of Overpass element dicts.

    Returns
    -------
    A single deduplicated list of elements.
    """
    seen: dict[tuple[str, int], dict] = {}
    for elements in lists:
        for el in elements:
            key = (el.get("type", ""), el.get("id", -1))
            if key not in seen:
                seen[key] = el
    return list(seen.values())


def fetch_overpass_tiled(
    query_fn: Callable[[list[float]], str],
    bbox: list[float],
    *,
    tiles: tuple[int, int] = (1, 1),
    url: str | None = None,
    timeout: int = 90,
    retries: int = 3,
) -> dict[str, Any]:
    """Fetch Overpass data by splitting the bbox into tiles.

    Splits *bbox* into ``tiles[0] × tiles[1]`` sub-bboxes, fires a separate
    Overpass query for each tile (using *query_fn* to build the query string),
    and merges the results, deduplicating elements by ``(type, id)``.

    Parameters
    ----------
    query_fn:
        Callable that takes a ``[minLon, minLat, maxLon, maxLat]`` bbox and
        returns an Overpass QL query string.
    bbox:
        Full bounding box to cover.
    tiles:
        ``(nx, ny)`` number of column / row divisions.  ``(1, 1)`` means a
        single query (no tiling).
    url:
        Overpass API endpoint URL.
    timeout:
        HTTP request timeout per tile request.
    retries:
        Maximum number of retry attempts per tile on transient errors.

    Returns
    -------
    Dict with ``"elements"`` key containing the merged, deduplicated list.
    """
    nx, ny = tiles
    url = resolve_overpass_url(url)
    if nx == 1 and ny == 1:
        return fetch_overpass(query_fn(bbox), url=url, timeout=timeout, retries=retries)

    tile_bboxes = split_bbox(bbox, nx, ny)
    print(f"  [Overpass] tiled fetch: {nx}x{ny} = {len(tile_bboxes)} tiles")
    logger.info(
        "Tiled Overpass fetch: %d × %d = %d tiles  bbox=%s",
        nx,
        ny,
        len(tile_bboxes),
        bbox,
    )

    all_element_lists: list[list[dict]] = []
    for i, tile_bbox in enumerate(tile_bboxes, 1):
        print(f"  [Overpass] tile {i}/{len(tile_bboxes)}  bbox={tile_bbox}")
        logger.info("Tile %d/%d  bbox=%s", i, len(tile_bboxes), tile_bbox)
        data = fetch_overpass(query_fn(tile_bbox), url=url, timeout=timeout, retries=retries)
        all_element_lists.append(data.get("elements") or [])

    merged = merge_elements(all_element_lists)
    logger.info("Tiled fetch complete: %d unique elements", len(merged))
    return {"elements": merged}
