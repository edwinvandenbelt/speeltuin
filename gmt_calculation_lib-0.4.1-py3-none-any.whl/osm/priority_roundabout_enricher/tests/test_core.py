"""Unit tests for priority_roundabout_enricher_core."""

from __future__ import annotations

from osm.priority_roundabout_enricher.core.priority_roundabout_enricher_core import (
    enrich_network_with_priority_and_roundabouts,
)


def _net_link(link_id, from_node, to_node, coords) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
        },
    }


def _osm_way(way_id, coords, tags) -> dict:
    return {
        "type": "way",
        "id": way_id,
        "geometry": [{"lon": c[0], "lat": c[1]} for c in coords],
        "tags": tags,
    }


def _sign(code, lon, lat) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": {"assetType": "trafficSign", "rvvCode": code},
    }


def test_empty_network_gets_defaults() -> None:
    fc = {"type": "FeatureCollection", "features": [_net_link("L1", "A", "B", [[0, 0], [1, 0]])]}
    result = enrich_network_with_priority_and_roundabouts(fc)
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is False
    assert props["roundaboutType"] == "none"
    assert props["priorityRoad"] is False
    assert props["priorityRoadSource"] == "none"


def test_osm_roundabout_tag_snaps() -> None:
    """A roundabout OSM way directly above the network link is snapped."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [_osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"junction": "roundabout"})]
    result = enrich_network_with_priority_and_roundabouts(fc, osm_elements=osm)
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is True
    assert props["roundaboutType"] == "roundabout"
    assert props["priorityRoadSource"] == "osm_roundabout"


def test_osm_priority_road_tag_snaps() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [_osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"priority_road": "designated"})]
    result = enrich_network_with_priority_and_roundabouts(fc, osm_elements=osm)
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "osm_priority_road"


def test_ndw_b1_sign_snaps() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    signs = [_sign("B1", 0.0, 0.0005)]
    result = enrich_network_with_priority_and_roundabouts(fc, traffic_sign_features=signs)
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "ndw_b1"


def test_ndw_b3_clears_priority() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    signs = [_sign("B3", 0.0, 0.0005)]
    result = enrich_network_with_priority_and_roundabouts(fc, traffic_sign_features=signs)
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is False
    assert props["priorityRoadSource"] == "ndw_b3_end"


def test_roundabout_wins_over_priority_tag() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [
        _osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"junction": "roundabout"}),
    ]
    signs = [_sign("B1", 0.0, 0.0005)]
    result = enrich_network_with_priority_and_roundabouts(
        fc, osm_elements=osm, traffic_sign_features=signs
    )
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is True
    assert props["priorityRoadSource"] == "osm_roundabout"
    assert props["priorityRoad"] is False


def _make_oneway_link(link_id, from_node, to_node, coords) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "mode": "CAR",
            "reverseLinkIds": [],
        },
    }


def test_geometry_roundabout_detects_circular_oneway_ring() -> None:
    """A closed ring of one-way CAR links is marked as roundabout by geometry."""
    import math

    m_per_deg = 111_000.0
    radius_m = 25.0
    radius_deg = radius_m / m_per_deg
    n = 4
    points = [
        [radius_deg * math.cos(2 * math.pi * i / n), radius_deg * math.sin(2 * math.pi * i / n)]
        for i in range(n + 1)
    ]
    features = [
        _make_oneway_link(i + 1, i, (i + 1) % n, [points[i], points[i + 1]]) for i in range(n)
    ]
    # Add an unrelated two-way CAR link to make sure it is ignored.
    features.append(
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [0.001, 0.0]]},
            "properties": {
                "linkId": 10,
                "fromNode": "X",
                "toNode": "Y",
                "mode": "CAR",
                "reverseLinkIds": [11],
            },
        }
    )

    fc = {"type": "FeatureCollection", "features": features}
    result = enrich_network_with_priority_and_roundabouts(fc)
    ring_props = [f["properties"] for f in result["features"][:4]]
    for props in ring_props:
        assert props["isRoundabout"] is True
        assert props["roundaboutType"] == "roundabout"
        assert props["priorityRoadSource"] == "geometry_roundabout"
    unrelated = result["features"][4]["properties"]
    assert unrelated["isRoundabout"] is False


def test_geometry_ignores_open_chain() -> None:
    """An open chain of one-way CAR links must not be marked as roundabout."""
    features = [
        _make_oneway_link(1, "A", "B", [[0.0, 0.0], [0.001, 0.0]]),
        _make_oneway_link(2, "B", "C", [[0.001, 0.0], [0.002, 0.0]]),
        _make_oneway_link(3, "C", "D", [[0.002, 0.0], [0.003, 0.0]]),
    ]
    fc = {"type": "FeatureCollection", "features": features}
    result = enrich_network_with_priority_and_roundabouts(fc)
    for f in result["features"]:
        assert f["properties"]["isRoundabout"] is False


def test_geometry_wins_over_osm_roundabout_tag() -> None:
    """Geometry classification overwrites an existing OSM roundabout tag."""
    import math

    m_per_deg = 111_000.0
    radius_m = 25.0
    radius_deg = radius_m / m_per_deg
    n = 4
    points = [
        [radius_deg * math.cos(2 * math.pi * i / n), radius_deg * math.sin(2 * math.pi * i / n)]
        for i in range(n + 1)
    ]
    features = [
        _make_oneway_link(i + 1, i, (i + 1) % n, [points[i], points[i + 1]]) for i in range(n)
    ]
    fc = {"type": "FeatureCollection", "features": features}
    osm = [_osm_way("W1", points[:2], {"junction": "roundabout"})]
    result = enrich_network_with_priority_and_roundabouts(fc, osm_elements=osm)
    for f in result["features"]:
        props = f["properties"]
        assert props["isRoundabout"] is True
        assert props["priorityRoadSource"] == "geometry_roundabout"
        assert props["roundaboutType"] == "roundabout"
