"""Unit tests for priority_roundabout_enricher_core."""

from __future__ import annotations

import pytest

from osm.priority_roundabout_enricher.core.priority_roundabout_enricher_core import (
    enrich_network_with_priority_and_roundabouts,
)


def _net_link(link_id, from_node, to_node, coords) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
        },
    }


def _osm_way(way_id, coords, tags) -> dict:
    return {
        "type": "way",
        "id": way_id,
        "geometry": [{"lon": c[0], "lat": c[1]} for c in coords],
        "tags": tags,
    }


def _sign(code, lon, lat) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": {"assetType": "trafficSign", "rvvCode": code},
    }


def test_empty_network_gets_defaults() -> None:
    fc = {"type": "FeatureCollection", "features": [_net_link("L1", "A", "B", [[0, 0], [1, 0]])]}
    result = enrich_network_with_priority_and_roundabouts(fc)
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is False
    assert props["roundaboutType"] == "none"
    assert props["priorityRoad"] is False
    assert props["priorityRoadSource"] == "none"


def test_osm_roundabout_tag_snaps() -> None:
    """A roundabout OSM way directly above the network link is snapped."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [_osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"junction": "roundabout"})]
    result = enrich_network_with_priority_and_roundabouts(fc, osm_elements=osm)
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is True
    assert props["roundaboutType"] == "roundabout"
    assert props["priorityRoadSource"] == "osm_roundabout"


def test_osm_priority_road_tag_snaps() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [_osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"priority_road": "designated"})]
    result = enrich_network_with_priority_and_roundabouts(fc, osm_elements=osm)
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "osm_priority_road"


def test_ndw_b1_sign_snaps() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    signs = [_sign("B1", 0.0, 0.0005)]
    result = enrich_network_with_priority_and_roundabouts(fc, traffic_sign_features=signs)
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "ndw_b1"


def test_ndw_b3_clears_priority() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    signs = [_sign("B3", 0.0, 0.0005)]
    result = enrich_network_with_priority_and_roundabouts(fc, traffic_sign_features=signs)
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is False
    assert props["priorityRoadSource"] == "ndw_b3_end"


def test_roundabout_wins_over_priority_tag() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [
        _osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"junction": "roundabout"}),
    ]
    signs = [_sign("B1", 0.0, 0.0005)]
    result = enrich_network_with_priority_and_roundabouts(
        fc, osm_elements=osm, traffic_sign_features=signs
    )
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is True
    assert props["priorityRoadSource"] == "osm_roundabout"
    assert props["priorityRoad"] is False
