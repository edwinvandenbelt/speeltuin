"""Pure-Python enrichment for roundabout and priority-road detection.

Adds per-link columns:

| Column | Type | Meaning |
|---|---|---|
| ``isRoundabout`` | bool | ``True`` when the link is part of a roundabout ring. |
| ``roundaboutType`` | str | ``"roundabout"``, ``"mini_roundabout"`` or ``"none"``. |
| ``priorityRoad`` | bool | ``True`` when the link is on a priority road. |
| ``priorityRoadSource`` | str | ``"osm_roundabout"`` (never priority) / ``"ndw_b1"`` / ``"osm_priority_road"`` / ``"osm_priority"`` / ``"none"``. |

Rotundabout detection is primarily tag-based.  For the OSM pipeline the raw
Overpass elements are inspected directly.  For the Dutch ``prepare`` pipeline
the NWB/Spectrum network has no OSM tags, so we use the fetched OSM road
elements and snap roundabout ways to the network by proximity.

Priority-road detection uses two sources:

* In the Netherlands: NDW traffic-sign features with ``rvvCode == "B1"``
  (voorrangsweg) are snapped to the nearest network link.
* Any country: OSM tags ``priority_road=designated`` or ``priority=yes`` on a
  road way.  Like roundabouts, OSM ways are snapped to the network when the
  network itself does not carry OSM tags.

The module has no I/O dependencies beyond the stdlib and the repo's shared
``geo`` helper; all geometry operations use the Shapely 2.x API.
"""

from __future__ import annotations

import logging
from collections import defaultdict
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable

logger = logging.getLogger(__name__)

#: Overpass tags that identify a roundabout link.
_ROUNABOUT_TAGS: dict[str, tuple[str, ...]] = {
    "junction": ("roundabout",),
    "highway": ("mini_roundabout",),
}

#: OSM tags that identify a priority road.  Directional suffixes (:forward/
#: :backward) are ignored because priority applies in both directions.
_PRIORITY_TAGS: dict[str, tuple[str, ...]] = {
    "priority_road": ("designated", "yes"),
    "priority": ("yes",),
}

#: Dutch NDW RVV codes that start/end a priority-road section.
_PRIORITY_SIGN_CODES: set[str] = {"B1"}
_END_PRIORITY_SIGN_CODES: set[str] = {"B3"}

#: Default snap distance in metres for OSM ways / signs to network links.
_DEFAULT_SNAP_M: float = 30.0


def _link_id(feature: dict) -> str | int | None:
    return (feature.get("properties") or {}).get("linkId")


def _to_node(feature: dict) -> str | int | None:
    return (feature.get("properties") or {}).get("toNode")


def _from_node(feature: dict) -> str | int | None:
    return (feature.get("properties") or {}).get("fromNode")


def _coords(feature: dict) -> list[list[float]]:
    geom = feature.get("geometry") or {}
    if geom.get("type") == "LineString":
        return geom.get("coordinates") or []
    return []


def _to_linestring(feature: dict):
    """Return a shapely LineString from a GeoJSON feature, or None."""
    try:
        from shapely.geometry import LineString

        coords = _coords(feature)
        if len(coords) >= 2:
            return LineString(coords)
    except Exception:
        pass
    return None


def _linestring_midpoint(ls) -> tuple[float, float]:
    p = ls.interpolate(0.5, normalized=True)
    return (p.x, p.y)


def _extract_osm_way_tags(elements: Iterable[dict]) -> dict[str | int, dict[str, str]]:
    """Return ``{way_id: tags}`` for all way elements."""
    result: dict[str | int, dict[str, str]] = {}
    for elem in elements:
        if elem.get("type") != "way":
            continue
        tags = elem.get("tags") or {}
        if tags:
            result[elem.get("id")] = tags
    return result


def _osm_way_geometry(elements: Iterable[dict]) -> dict[str | int, list[list[float]]]:
    """Return ``{way_id: [(lon, lat), ...]}`` for all way elements."""
    result: dict[str | int, list[list[float]]] = {}
    for elem in elements:
        if elem.get("type") != "way":
            continue
        geom = elem.get("geometry") or []
        pts = [[float(p["lon"]), float(p["lat"])] for p in geom if "lon" in p and "lat" in p]
        if pts:
            result[elem.get("id")] = pts
    return result


def _find_osm_roundabout_ways(elements: Iterable[dict]) -> list[tuple[str | int, str]]:
    """Return list of (way_id, roundabout_type) for OSM roundabout ways."""
    result: list[tuple[str | int, str]] = []
    for elem in elements:
        if elem.get("type") != "way":
            continue
        tags = elem.get("tags") or {}
        if tags.get("junction") in _ROUNABOUT_TAGS["junction"]:
            result.append((elem.get("id"), "roundabout"))
        elif tags.get("highway") in _ROUNABOUT_TAGS["highway"]:
            result.append((elem.get("id"), "mini_roundabout"))
    return result


def _find_osm_priority_ways(elements: Iterable[dict]) -> list[str | int]:
    """Return list of OSM way ids that are tagged as priority roads."""
    result: list[str | int] = []
    for elem in elements:
        if elem.get("type") != "way":
            continue
        tags = elem.get("tags") or {}
        for key, values in _PRIORITY_TAGS.items():
            base_key = key.split(":")[0]
            for k in tags:
                if k == base_key or k.startswith(f"{base_key}:"):
                    if tags[k] in values:
                        result.append(elem.get("id"))
                        break
    return result


def _prepare_link_index(feature: dict):
    """Pre-compute shapely geometry and midpoint for a network link."""
    from shapely.geometry import LineString

    coords = _coords(feature)
    if len(coords) < 2:
        return None
    ls = LineString(coords)
    return {
        "feature": feature,
        "line": ls,
        "mid": ls.interpolate(0.5, normalized=True),
        "length": ls.length,
    }


def _snap_point_to_link_index(point, prepared: list[dict], max_m: float):
    """Return the prepared link closest to *point* within *max_m*.

    Uses a cheap flat-earth distance in degrees, scaled by latitude.
    """
    from math import cos, radians

    best = None
    best_dist_m = float("inf")
    lon0, lat0 = point.x, point.y
    scale = cos(radians(lat0)) * 111_000.0 if lat0 is not None else 111_000.0
    for prep in prepared:
        dist_deg = prep["line"].distance(point)
        dist_m = dist_deg * scale
        if dist_m <= max_m and dist_m < best_dist_m:
            best = prep
            best_dist_m = dist_m
    return best


def _snap_way_to_network(
    way_coords: list[list[float]],
    prepared: list[dict],
    max_m: float,
) -> dict | None:
    """Snap a way to the network link whose midpoint is closest to the way."""
    from shapely.geometry import LineString

    if len(way_coords) < 2:
        return None
    way_ls = LineString(way_coords)
    best = None
    best_dist_m = float("inf")
    for prep in prepared:
        dist_deg = way_ls.distance(prep["mid"])
        lat = prep["mid"].y
        scale = 111_000.0
        try:
            from math import cos, radians

            scale = cos(radians(lat)) * 111_000.0
        except Exception:
            pass
        dist_m = dist_deg * scale
        if dist_m <= max_m and dist_m < best_dist_m:
            best = prep
            best_dist_m = dist_m
    return best


def _mark_priority_from_signs(
    network_fc: dict,
    sign_features: Iterable[dict],
    max_m: float = _DEFAULT_SNAP_M,
) -> None:
    """Snap B1/B3 signs to network links and mark priority sections."""
    from shapely.geometry import Point

    prepared = [_prepare_link_index(f) for f in network_fc.get("features") or []]
    prepared = [p for p in prepared if p is not None]
    if not prepared:
        return

    starts: list[tuple[dict, dict]] = []
    ends: list[tuple[dict, dict]] = []
    for sign in sign_features:
        props = sign.get("properties") or {}
        code = props.get("rvvCode") or ""
        if code not in _PRIORITY_SIGN_CODES | _END_PRIORITY_SIGN_CODES:
            continue
        geom = sign.get("geometry") or {}
        if geom.get("type") != "Point":
            continue
        coords = geom.get("coordinates") or []
        if len(coords) < 2:
            continue
        point = Point(coords[0], coords[1])
        link = _snap_point_to_link_index(point, prepared, max_m)
        if link is None:
            continue
        if code in _PRIORITY_SIGN_CODES:
            starts.append((link, sign))
        else:
            ends.append((link, sign))

    # Each B1 sign marks its snapped link as priority.  We intentionally keep
    # this local because linking sequential B1/B3 signs into continuous sections
    # would require route-graph traversal.  For our use-case a per-link flag is
    # sufficient; downstream models can propagate if needed.
    for link, _sign in starts:
        props = link["feature"].get("properties") or {}
        props["priorityRoad"] = True
        props["priorityRoadSource"] = "ndw_b1"

    # B3 (end of priority) clears the flag on its snapped link.
    for link, _sign in ends:
        props = link["feature"].get("properties") or {}
        # Only clear if it was set by a sign; do not overwrite OSM priority.
        if props.get("priorityRoadSource") in ("ndw_b1", None, "none"):
            props["priorityRoad"] = False
            props["priorityRoadSource"] = "ndw_b3_end"


def _mark_roundabouts_from_osm(
    network_fc: dict,
    osm_elements: Iterable[dict],
    max_m: float = _DEFAULT_SNAP_M,
) -> None:
    """Mark roundabout links based on OSM roundabout way geometries."""
    prepared = [_prepare_link_index(f) for f in network_fc.get("features") or []]
    prepared = [p for p in prepared if p is not None]
    if not prepared:
        return

    way_geom = _osm_way_geometry(osm_elements)
    for way_id, rtype in _find_osm_roundabout_ways(osm_elements):
        coords = way_geom.get(way_id)
        if not coords:
            continue
        link = _snap_way_to_network(coords, prepared, max_m)
        if link is None:
            continue
        props = link["feature"].get("properties") or {}
        props["isRoundabout"] = True
        props["roundaboutType"] = rtype
        # Roundabouts are never priority roads.
        props["priorityRoad"] = False
        props["priorityRoadSource"] = "osm_roundabout"


def _mark_priority_from_osm(
    network_fc: dict,
    osm_elements: Iterable[dict],
    max_m: float = _DEFAULT_SNAP_M,
) -> None:
    """Mark priority links based on OSM priority-road tag geometries."""
    prepared = [_prepare_link_index(f) for f in network_fc.get("features") or []]
    prepared = [p for p in prepared if p is not None]
    if not prepared:
        return

    way_geom = _osm_way_geometry(osm_elements)
    for way_id in _find_osm_priority_ways(osm_elements):
        coords = way_geom.get(way_id)
        if not coords:
            continue
        link = _snap_way_to_network(coords, prepared, max_m)
        if link is None:
            continue
        props = link["feature"].get("properties") or {}
        # Do not overwrite roundabout flag; but a priority flag is secondary.
        if not props.get("isRoundabout"):
            props["priorityRoad"] = True
            props["priorityRoadSource"] = "osm_priority_road"


def enrich_network_with_priority_and_roundabouts(
    network_fc: dict,
    *,
    osm_elements: Iterable[dict] | None = None,
    traffic_sign_features: Iterable[dict] | None = None,
    snap_m: float = _DEFAULT_SNAP_M,
) -> dict:
    """Add roundabout and priority-road columns to every link in *network_fc*.

    Parameters
    ----------
    network_fc:
        GeoJSON FeatureCollection of directed network links.
    osm_elements:
        Optional raw Overpass elements (ways, nodes, relations).
    traffic_sign_features:
        Optional traffic-sign point features with ``rvvCode`` property.
    snap_m:
        Maximum snap distance from an OSM way / sign to a network link.

    Returns
    -------
    dict
        The same *network_fc* instance with ``isRoundabout``, ``roundaboutType``,
        ``priorityRoad`` and ``priorityRoadSource`` on each link.
    """
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        props.setdefault("isRoundabout", False)
        props.setdefault("roundaboutType", "none")
        props.setdefault("priorityRoad", False)
        props.setdefault("priorityRoadSource", "none")

    # Order matters: signs (local, precise) override OSM priority tags, but a
    # roundabout classification always wins because roundabouts are never
    # priority roads.
    if traffic_sign_features:
        _mark_priority_from_signs(network_fc, traffic_sign_features, snap_m)

    if osm_elements:
        _mark_priority_from_osm(network_fc, osm_elements, snap_m)
        _mark_roundabouts_from_osm(network_fc, osm_elements, snap_m)

    return network_fc
