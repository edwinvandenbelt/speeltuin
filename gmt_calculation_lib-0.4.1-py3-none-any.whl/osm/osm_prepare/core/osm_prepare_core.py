"""
osm_prepare_core.py — OSM preparation pipeline orchestration.

Runs the full OSM pipeline for CAR mode entirely in-process.  Replaces
the Databricks-backed ``prepare`` pipeline with OSM/Overpass equivalents:

    zone_fetcher        →  osm_building_fetcher + building_zone_creator
                           + zone_population_estimator
    network_fetcher     →  osm_network_fetcher
    feedlink_fetcher    →  osm_feedlink_creator

Steps that do not depend on Databricks are reused unchanged:
    network_simplifier, network_cleaner, bidirectional_splitter,
    parallel_link_finder, matrix_builder.

Skipped steps (not applicable to the OSM pipeline):
    network_fuser       — only needed for multi-mode networks
    network_zone_joiner — expects Databricks-style AREA/STUDY/INFLUENCE
                          zone hierarchy; OSM zones are building polygons
    nvp_mapper          — Databricks-dependent

Pipeline execution
------------------
Two independent tracks run in parallel inside a ThreadPoolExecutor:

  Track A  osm_building_fetcher → building_zone_creator
                               → zone_population_estimator
  Track B  osm_network_fetcher → network_simplifier → network_cleaner
                               → bidirectional_splitter
                               → parallel_link_finder

After both tracks complete, feedlinks and the OD matrix are built
sequentially:

  osm_feedlink_creator(directed_network, zones)
  external_zone_creator(directed_network, zones, feedlinks, bbox)
  matrix_builder(directed_network, feedlinks, zones)          ← D1, no flows
  estimate_flow_from_routes(directed_network, routes_D1)      ← E, all-or-nothing
  matrix_builder(directed_network_with_flows, feedlinks, zones) ← D2, BPR costs

Note on Overpass rate limits
----------------------------
The pipeline issues up to three concurrent Overpass HTTP requests:
  • osm_building_fetcher (buildings + streets for block construction)
  • building_zone_creator (streets for city-block polygonisation)
  • osm_network_fetcher (road links)

For large bounding boxes or high-frequency runs, use a private Overpass
instance via the ``overpass_url`` parameter.

Final outputs
-------------
    {area_id}-NETWORK-CAR.parquet
    {area_id}-FEEDLINK-CAR.parquet
    {area_id}-ZONE-CAR.parquet
    {area_id}-ROUTES-CAR.parquet

Public API
----------
run_pipeline(min_lon, min_lat, max_lon, max_lat, out_dir, **kwargs) -> str
    Run the full pipeline and return the area UUID.
"""

from __future__ import annotations

import concurrent.futures
import json
import uuid
from pathlib import Path

from shared.geoparquet import to_geoparquet
from shared.overpass import DEFAULT_OVERPASS_URL

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_TARGET_FOOTPRINT_M2 = 5000.0
DEFAULT_MAX_ROUTES = 2
DEFAULT_OVERPASS_TIMEOUT = 90
DEFAULT_EXTERNAL_SHARE = 0.40
DEFAULT_MIN_DAILY_MOVEMENTS = 300.0
DEFAULT_HULL_TYPE = "concave"
DEFAULT_HULL_K = 3
DEFAULT_PEAK_HOUR_FRACTION = 0.10
DEFAULT_GISCO_URL = "https://gisco-services.ec.europa.eu"

# Product-type markers used to discover an existing area UUID from the
# output directory (identical to prepare_core._ID_MARKERS).
_ID_MARKERS = (
    "-NETWORK-",
    "-ROUTES-",
    "-ZONE-",
    "-FEEDLINK-",
)

# ---------------------------------------------------------------------------
# Area-ID helpers
# ---------------------------------------------------------------------------


def _discover_or_create_area_id(out_dir: Path, area_id: str | None = None) -> str:
    """Return the area UUID for *out_dir*.

    Priority
    --------
    1. Explicit *area_id* override.
    2. UUID prefix extracted from the first matching ``.parquet`` file in
       *out_dir* (re-run of an existing area).
    3. Fresh :func:`uuid.uuid4` (first run / empty directory).
    """
    if area_id:
        return area_id
    for f in sorted(out_dir.glob("*.parquet")):
        stem = f.stem
        for marker in _ID_MARKERS:
            idx = stem.find(marker)
            if idx > 0:
                return stem[:idx]
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Debug snapshot helper
# ---------------------------------------------------------------------------


def _snapshot(step_num: int, area_id: str, out_dir: Path, **named_fcs: dict) -> None:
    """Write named in-memory FeatureCollections to debug GeoJSON snapshots.

    Files are named ``STEP_{n}_{area_id}_{PRODUCT}.geojson`` and written to
    *out_dir*.  Only called when ``debug=True``.
    """
    for product, fc in named_fcs.items():
        if fc is None:
            print(f"  [debug] snapshot skipped — {product} is None")
            continue
        dst = out_dir / f"STEP_{step_num}_{area_id}_{product}.geojson"
        dst.write_text(json.dumps(fc, ensure_ascii=False), encoding="utf-8")
        n = len(fc.get("features") or [])
        print(f"  [debug] snapshot → {dst.name}  ({n} features)")


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


def run_pipeline(
    min_lon: float,
    min_lat: float,
    max_lon: float,
    max_lat: float,
    out_dir: Path,
    *,
    area_id: str | None = None,
    name: str | None = None,
    target_footprint_m2: float | None = None,
    max_routes: int = DEFAULT_MAX_ROUTES,
    overpass_url: str = DEFAULT_OVERPASS_URL,
    overpass_timeout: int = DEFAULT_OVERPASS_TIMEOUT,
    gisco_url: str = DEFAULT_GISCO_URL,
    external_share: float = DEFAULT_EXTERNAL_SHARE,
    min_daily_movements: float = DEFAULT_MIN_DAILY_MOVEMENTS,
    hull_type: str = DEFAULT_HULL_TYPE,
    hull_k: int = DEFAULT_HULL_K,
    peak_hour_fraction: float = DEFAULT_PEAK_HOUR_FRACTION,
    population: float | None = None,
    matrix_workers: int | None = None,
    refresh: bool = False,
    debug: bool = False,
    annotate_traffic_signals: bool = True,
    fetch_traffic_signs: bool = True,
    fetch_osm_assets: bool = True,
    add_elevation: bool = True,
    elevation_batch_size: int = 100,
    elevation_timeout: int = 30,
    elevation_retries: int = 8,
    elevation_pause: float = 2.0,
) -> str:
    """Run the full OSM preparation pipeline for CAR mode.

    Parameters
    ----------
    min_lon, min_lat, max_lon, max_lat:
        Bounding box in decimal degrees (WGS-84).
    out_dir:
        Output directory; created automatically when it does not exist.
    area_id:
        Optional UUID override.  When omitted the UUID is discovered from
        existing files in *out_dir*, or a fresh ``uuid4()`` is generated.
    name:
        Human-readable label for the area (e.g. ``"Deventer"``).  Stored in
        the ``"name"`` field of every output FeatureCollection's properties.
    target_footprint_m2:
        Target total building footprint per zone in m² (building_zone_creator).
        When ``None`` (the default) the value is auto-computed so that
        approximately 100 zones are created (total_footprint / 100).
    max_routes:
        Maximum k-shortest routes per OD pair (matrix_builder).  Default: 2.
    overpass_url:
        Overpass API endpoint.  Use a private instance for large areas.
    overpass_timeout:
        HTTP timeout in seconds for every Overpass request.
    gisco_url:
        GISCO services base URL used for reverse geocoding (zone names and
        population).  Default: ``https://gisco-services.ec.europa.eu``.
    external_share:
        Fraction of total zone production allocated to external (boundary-crossing) zones.
        Default: 0.40.
    min_daily_movements:
        Minimum daily traffic (``flow24hrs``, vehicles/24h) a boundary node needs
        on its incoming or outgoing direction to receive an external zone.
        Default: 150.
    hull_type:
        Network boundary detection: ``"concave"`` (default, follows the network
        shape) or ``"convex"``.
    hull_k:
        Neighbour count for the concave hull (higher = smoother boundary).
        Default: 3.  Ignored for the convex hull.
    peak_hour_fraction:
        Fraction of daily flow assigned to the peak hour for remaining-capacity calculation.
        Default: 0.10.
    population:
        Optional total population override for the area.  When set, skips the
        automatic LAU/NUTS population lookup and uses this value directly.
        Useful when the automatic estimate is inaccurate (e.g. a small town
        inside a large Kreis/département).
    matrix_workers:
        Number of worker processes for ``matrix_builder`` (D1 and D2).
        When ``None`` (the default) the count is auto-detected from available
        RAM via ``psutil`` (budget: 512 MB/worker), capping at
        ``os.cpu_count()``.  Set to ``1`` to disable parallelism entirely
        (useful for debugging or on memory-constrained machines).
    refresh:
        Re-run all steps even when the final output files already exist.
    debug:
        Write intermediate GeoJSON snapshots (``STEP_{n}_…``) to *out_dir*.

    annotate_traffic_signals:
        When ``True`` (default), query Overpass for ``highway=traffic_signals``
        nodes, annotate every link with ``trafficSignal`` and emit the signal
        locations into ``{area_id}-TRAFFIC-ASSETS.parquet``.  Default: ``True``.
    fetch_traffic_signs:
        When ``True`` (default), fetch OSM traffic-sign point features from
        Overpass and add them to ``{area_id}-TRAFFIC-ASSETS.parquet``.
        Default: ``True``.
    fetch_osm_assets:
        When ``True`` (default), fetch OSM traffic objects (pedestrian
        crossings, speed bumps, stop / give-way signs, mini-roundabouts) from
        Overpass and add them to ``{area_id}-TRAFFIC-ASSETS.parquet``.
        Default: ``True``.
    elevation_batch_size:
        Coordinates per Open-Meteo elevation request (capped at 100).
        Default: ``100``.
    elevation_timeout:
        HTTP request timeout in seconds per elevation batch.
        Default: ``30``.
    elevation_retries:
        Maximum retry attempts per elevation batch on transient HTTP errors
        such as 429.  Default: ``8``.
    elevation_pause:
        Seconds to wait between successive elevation batch requests (throttle).
        Increase this if you see frequent ``429 Too Many Requests`` responses.
        Default: ``2.0``.

    Returns
    -------
    str
        The area UUID used for this run.
    """
    bbox = [min_lon, min_lat, max_lon, max_lat]
    out_dir.mkdir(parents=True, exist_ok=True)
    area_id = _discover_or_create_area_id(out_dir, area_id)

    # Final output paths.
    buildings_path = out_dir / f"{area_id}-BUILDINGS.parquet"
    network_path = out_dir / f"{area_id}-NETWORK-CAR.parquet"
    feedlink_path = out_dir / f"{area_id}-FEEDLINK-CAR.parquet"
    zone_path = out_dir / f"{area_id}-ZONE-CAR.parquet"
    routes_path = out_dir / f"{area_id}-ROUTES-CAR.parquet"
    traffic_assets_path = out_dir / f"{area_id}-TRAFFIC-ASSETS.parquet"

    print()
    print("=" * 60)
    print(" OSM Prepare Pipeline")
    print(f" bbox       : {min_lon} {min_lat} {max_lon} {max_lat}")
    print(" mode       : CAR")
    print(f" area-id    : {area_id}")
    print(f" out        : {out_dir}")
    print(f" refresh    : {'yes' if refresh else 'no'}")
    print(f" debug      : {'yes' if debug else 'no'}")
    print("=" * 60)

    # ------------------------------------------------------------------
    # Early exit: all final outputs exist and refresh=False
    # ------------------------------------------------------------------
    if not refresh and all(
        p.exists() for p in [buildings_path, network_path, feedlink_path, zone_path, routes_path]
    ):
        print()
        print("All final outputs already exist — skipping pipeline (use --refresh to force).")
        return area_id

    # ==================================================================
    # PARALLEL TRACKS A + B
    # ==================================================================

    def _run_track_a() -> tuple[dict, dict, dict]:
        """Track A: buildings → zones → population.  Returns (zones_fc, a_stats)."""
        from osm.building_zone_creator.core.building_zone_creator_core import (
            create_zones,
        )
        from osm.osm_building_fetcher.core.osm_building_fetcher_core import (
            build_buildings,
        )
        from osm.zone_population_estimator.core.zone_population_estimator_core import (
            estimate_zone_population,
        )

        # A1 — osm_building_fetcher
        print("[A1] osm_building_fetcher ...")
        buildings_fc, bld_stats = build_buildings(
            bbox,
            overpass_url=overpass_url,
            timeout=overpass_timeout,
        )
        print(
            f"  {bld_stats.get('buildings', 0)} buildings fetched "
            f"(tiles={bld_stats.get('tiles', 1)})"
        )

        # A2 — building_zone_creator
        print("[A2] building_zone_creator ...")
        raw_zones_fc, zone_stats = create_zones(
            buildings_fc,
            bbox,
            area_id=area_id,
            overpass_url=overpass_url,
            overpass_timeout=overpass_timeout,
            target_footprint_m2=target_footprint_m2,
        )
        print(f"  {zone_stats.get('zones', len(raw_zones_fc.get('features') or []))} zones created")

        # A3 — zone_population_estimator
        print("[A3] zone_population_estimator ...")
        zones_fc, pop_stats = estimate_zone_population(
            raw_zones_fc, bbox, gisco_url=gisco_url, population_override=population
        )
        print(
            f"  population={pop_stats.get('totalPopulation', '?')}  "
            f"nutsCode={pop_stats.get('nutsCode', '?')}"
        )

        return zones_fc, raw_zones_fc, buildings_fc

    def _run_track_b_partial() -> dict:
        """Track B (partial): network fetch → simplify → clean.

        Returns the cleaned undirected network FeatureCollection.
        B4 (bidirectional_splitter) and B5 (parallel_link_finder) run after
        both parallel tracks complete.
        """
        from network_cleaner.core.network_cleaner_core import clean_network
        from network_simplifier.core.network_simplifier_core import (
            simplify_network,
        )
        from osm.osm_network_fetcher.core.osm_network_fetcher_core import (
            build_raw_network,
        )

        # B1 — osm_network_fetcher
        print("[B1] osm_network_fetcher (CAR) ...")
        raw_network_fc = build_raw_network(
            bbox,
            modes=["CAR"],
            overpass_url=overpass_url,
            timeout=overpass_timeout,
        )
        print(f"  {len(raw_network_fc.get('features') or []):,} raw links fetched")

        # B2 — network_simplifier
        print("[B2] network_simplifier ...")
        simplified_fc, simp_stats = simplify_network(raw_network_fc)
        print(
            f"  {simp_stats.get('final_links', '?')} links "
            f"(removed {simp_stats.get('removed_nodes', '?')} pass-through nodes)"
        )

        # B3 — network_cleaner
        print("[B3] network_cleaner ...")
        cleaned_fc, clean_stats = clean_network(simplified_fc)
        print(f"  {clean_stats.get('kept', '?')} kept, {clean_stats.get('removed', '?')} removed")

        return cleaned_fc

    print()
    print("[parallel] tracks A (zones) and B1-B3 (network fetch+clean) ...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        future_a = pool.submit(_run_track_a)
        future_b = pool.submit(_run_track_b_partial)

    zones_fc, _raw_zones_fc, buildings_fc = future_a.result()
    cleaned_fc = future_b.result()

    n_zones = len(zones_fc.get("features") or [])
    n_cleaned = len(cleaned_fc.get("features") or [])
    print(f"  Track A complete: {n_zones} zones")
    print(f"  Track B (B1-B3) complete: {n_cleaned:,} cleaned links")

    if debug:
        _snapshot(3, area_id, out_dir, ZONES=zones_fc)
        _snapshot(6, area_id, out_dir, CLEANED=cleaned_fc)

    # ==================================================================
    # B3/opt — elevation_annotator
    # Source-independent: runs on the UNDIRECTED cleaned network *before* the
    # split, so every graph node's elevation is fetched exactly once (the
    # splitter then propagates elevationFrom / elevationTo to the heen link and
    # swaps them on the reversed terug link).  Best-effort — a failed Open-Meteo
    # lookup logs a warning and leaves the fields as None.
    # ==================================================================
    if add_elevation:
        print()
        print("[B3/opt] elevation_annotator ...")
        try:
            from elevation_annotator.core.elevation_annotator_core import (
                add_elevation as _add_elevation,
            )

            cleaned_fc, _elev_stats = _add_elevation(
                cleaned_fc,
                batch_size=elevation_batch_size,
                timeout=elevation_timeout,
                retries=elevation_retries,
                pause=elevation_pause,
            )
            print(
                f"  elevation set on {_elev_stats['updated']}/{_elev_stats['links']} links "
                f"({_elev_stats['resolved']}/{_elev_stats['nodes']} nodes resolved)"
            )
        except Exception as exc:
            print(f"  WARNING: elevation annotation failed ({exc}); continuing without it.")

    # ==================================================================
    # B4 — bidirectional_splitter
    # ==================================================================
    print()
    print("[B4] bidirectional_splitter ...")

    from bidirectional_splitter.core.bidirectional_splitter_core import (
        post_process_features,
    )
    from bidirectional_splitter.domain.network import DIRECTED_LINK_PROPERTIES

    directed_features = post_process_features(cleaned_fc.get("features") or [])
    network_fc: dict = {
        "type": "FeatureCollection",
        "features": directed_features,
        "properties": {
            **(cleaned_fc.get("properties") or {}),
            "bbox": bbox,
            "area_id": area_id,
            "modes": ["CAR"],
            "modeLabel": "CAR",
        },
    }
    print(f"  {len(directed_features):,} directed links after split")

    # ==================================================================
    # B5 — parallel_link_finder
    # ==================================================================
    print()
    print("[B5] parallel_link_finder ...")

    from parallel_link_finder.core.parallel_link_finder_core import (
        find_parallel_links,
    )

    network_fc, parallel_stats = find_parallel_links(network_fc)
    print(
        f"  enriched={parallel_stats.get('features_enriched', '?')}  "
        f"skipped={parallel_stats.get('features_skipped', '?')}"
    )

    # ==================================================================
    # B5/opt+ — network conflict finder
    # Adds geometric-conflict columns to every directed link
    # (fromRightLinkId, fromLeftLinkId, oppositeLinkId, fromRightFlow,
    # fromLeftFlow, oppositeFlow, leftTurnRatio, rightTurnRatio). Runs on the
    # directed network before the OD matrix so counts remain link-based.
    # ==================================================================
    print()
    print("[B5/opt+] network_conflict_finder ...")
    from network_conflict_finder.core.network_conflict_finder_core import (
        enrich_network_with_conflicts,
    )

    network_fc = enrich_network_with_conflicts(network_fc)
    _conflict_count = sum(
        1
        for f in network_fc.get("features") or []
        if (f.get("properties") or {}).get("fromRightLinkId") is not None
        or (f.get("properties") or {}).get("fromLeftLinkId") is not None
        or (f.get("properties") or {}).get("oppositeLinkId") is not None
    )
    print(f"  {_conflict_count} links received conflict annotation")

    # ==================================================================
    # Inject final network metadata after B5 so it survives the parallel_link_finder
    # return value and is present in the written parquet file.
    # NOTE: fields are refreshed *after* the optional enrichment steps below,
    # so columns added by osm_asset_fetcher/buildings are still visible.
    network_fc.setdefault("properties", {}).update(
        {
            "bbox": bbox,
            "region": None,  # no holiday-region lookup for OSM pipelines
            "area_id": area_id,
            "name": name,
            "modes": ["CAR"],
            "modeLabel": "CAR",
            "source": "OSM",
        }
    )

    if debug:
        _snapshot(9, area_id, out_dir, NETWORK=network_fc)

    # ==================================================================
    # B5/opt — traffic assets (traffic signals + traffic signs)
    # Overpass-only (no NDW) — combined {area_id}-TRAFFIC-ASSETS.parquet.
    # ==================================================================
    _asset_features: list[dict] = []
    _assets_fc: dict = {}
    _osm_fc: dict | None = None
    _signs_fc: dict | None = None

    if annotate_traffic_signals:
        print()
        print("[B5/opt] traffic_signal_annotator ...")
        from traffic_signal_annotator.core.traffic_signal_annotator_core import (
            annotate_network,
            fetch_signal_coords,
            signals_to_features,
        )

        _signal_coords = fetch_signal_coords(bbox, timeout=overpass_timeout)
        network_fc, _sig_stats = annotate_network(network_fc, _signal_coords)
        print(f"  {_sig_stats['annotated']}/{_sig_stats['total']} links marked trafficSignal=True")
        _asset_features.extend(signals_to_features(_signal_coords))

    if fetch_traffic_signs:
        print()
        print("[B5/opt] traffic_sign_fetcher ...")
        from traffic_sign_fetcher.core.traffic_sign_fetcher_core import (
            fetch_sign_features,
        )

        # OSM pipeline: always use Overpass (no NDW dataset).
        _signs_fc, _sign_stats = fetch_sign_features(bbox, ndw_data=None, timeout=overpass_timeout)
        _asset_features.extend(_signs_fc.get("features") or [])
        print(
            f"  {_sign_stats['total']} traffic-sign assets added (source={_sign_stats['source']})"
        )

    if fetch_osm_assets:
        print()
        print("[B5/opt] osm_asset_fetcher ...")
        from osm_asset_fetcher.core.osm_asset_fetcher_core import (
            fetch_osm_assets as _fetch_osm_assets,
        )

        # No BGT in the OSM pipeline, so fetch all default kinds (incl. speedBump).
        # Pass network_fc for linkId/nodeId matching and asset-count enrichment.
        # The network is mutated in place with numPedestrianCrossings,
        # numCyclePaths, numRefugeAreas, numStoppingLanes, numGiveWays,
        # and numSpeedBumps.
        _osm_fc, _osm_stats = _fetch_osm_assets(
            bbox,
            timeout=overpass_timeout,
            network_fc=network_fc,
        )
        _asset_features.extend(_osm_fc.get("features") or [])
        print(
            f"  {_osm_stats['total']} OSM assets added "
            f"(counts={_osm_stats['counts']}, source={_osm_stats['source']})"
        )

    _write_traffic_assets = annotate_traffic_signals or fetch_traffic_signs or fetch_osm_assets
    if _write_traffic_assets:
        _assets_fc = {
            "type": "FeatureCollection",
            "features": _asset_features,
            "properties": {"area_id": area_id, "bbox": bbox, "source": "OSM"},
        }

    # ==================================================================
    # B5/opt++ — priority road and roundabout enrichment
    # Uses the fetched OSM elements and traffic-sign features to mark directed
    # links that lie on a roundabout ring or a priority road. Runs after all
    # asset fetches so the raw Overpass elements and sign features are available.
    # ==================================================================
    print()
    print("[B5/opt++] priority_roundabout_enricher ...")
    from osm.priority_roundabout_enricher.core.priority_roundabout_enricher_core import (
        enrich_network_with_priority_and_roundabouts,
    )

    _osm_elements_for_enricher: list[dict] = (_osm_fc or {}).get("properties", {}).get(
        "_elements"
    ) or []
    _sign_features_for_enricher: list[dict] = (_signs_fc or {}).get("features") or []

    _enriched = enrich_network_with_priority_and_roundabouts(
        network_fc,
        osm_elements=_osm_elements_for_enricher,
        traffic_sign_features=_sign_features_for_enricher,
    )
    network_fc = _enriched[0]
    _give_way_features = _enriched[1]
    _asset_features.extend(_give_way_features)
    _roundabout_count = sum(
        1
        for f in network_fc.get("features") or []
        if (f.get("properties") or {}).get("isRoundabout")
    )
    _priority_count = sum(
        1
        for f in network_fc.get("features") or []
        if (f.get("properties") or {}).get("priorityRoad")
    )
    print(
        f"  {_roundabout_count} roundabout links, {_priority_count} priority links, "
        f"{len(_give_way_features)} derived give-way markers"
    )

    # Refresh the canonical fields list after all enrichment steps have had a
    # chance to add columns (roadWidthM, conflict columns, POI areas, counts,
    # roundabouts, priority roads).
    network_fc["properties"]["fields"] = list(DIRECTED_LINK_PROPERTIES)

    # ==================================================================
    # B6 — per-link building motive ratios
    # ==================================================================
    print()
    print("[B6] assign_buildings_to_links ...")

    from osm.osm_building_fetcher.domain.street_linker import (
        assign_buildings_to_links,
    )

    _link_building_ratios = assign_buildings_to_links(buildings_fc, network_fc)
    for feat in network_fc.get("features") or []:
        lid = str((feat.get("properties") or {}).get("linkId", ""))
        ratio = _link_building_ratios.get(lid)
        if ratio:
            feat.setdefault("properties", {})["buildingMotifRatio"] = ratio
    print(f"  {len(_link_building_ratios):,} links enriched with buildingMotifRatio")

    if debug:
        _snapshot(9, area_id, out_dir, NETWORK=network_fc)

    # ==================================================================
    # C — osm_feedlink_creator
    # ==================================================================
    print()
    print("[C] osm_feedlink_creator ...")

    from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
        create_feedlinks,
    )

    feedlinks_fc, fl_stats = create_feedlinks(network_fc, zones_fc)
    print(
        f"  {fl_stats['total']} feedlinks "
        f"({fl_stats['zonesMatched']} matched inside, "
        f"{fl_stats['zonesFallback']} fallback)"
    )

    from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
        FEEDLINK_PROPERTIES,
    )

    _common_meta: dict = {
        "bbox": bbox,
        "region": None,  # no holiday-region lookup for OSM pipelines
        "area_id": area_id,
        "name": name,
        "modes": ["CAR"],
        "modeLabel": "CAR",
        "source": "OSM",
    }
    feedlinks_fc.setdefault("properties", {}).update(
        {
            **_common_meta,
            "fields": list(FEEDLINK_PROPERTIES),
        }
    )

    if debug:
        _snapshot(10, area_id, out_dir, FEEDLINKS=feedlinks_fc)

    # ==================================================================
    # C2 — external_zone_creator
    # ==================================================================
    print()
    print("[C2] external_zone_creator ...")

    from osm.external_zone_creator.core.external_zone_creator_core import (
        create_external_zones,
    )

    zones_fc, feedlinks_fc, ext_stats = create_external_zones(
        network_fc,
        zones_fc,
        feedlinks_fc,
        bbox,
        external_share=external_share,
        min_daily_movements=min_daily_movements,
        hull_type=hull_type,
        hull_k=hull_k,
        gisco_url=gisco_url,
    )
    print(
        f"  {ext_stats.get('externalZones', 0)} external zones, "
        f"{ext_stats.get('externalFeedlinks', 0)} feedlinks added "
        f"({ext_stats.get('boundaryNodes', 0)} boundary nodes, "
        f"{ext_stats.get('filteredNodes', 0)} filtered)"
    )

    if debug:
        _snapshot(11, area_id, out_dir, ZONES_EXT=zones_fc, FEEDLINKS_EXT=feedlinks_fc)

    # ==================================================================
    # D1 — matrix_builder (empty network — no flows yet)
    # ==================================================================
    print()
    print("[D1] matrix_builder (empty network) ...")

    from matrix_builder.core.matrix_builder_core import build_matrix

    routes_fc_1 = build_matrix(
        network_fc, feedlinks_fc, zones_fc, max_routes=max_routes, workers=matrix_workers
    )
    n_routes_1 = len(routes_fc_1.get("features") or [])
    print(f"  {n_routes_1:,} route features built")

    if debug:
        _snapshot(12, area_id, out_dir, ROUTES_1=routes_fc_1)

    # ==================================================================
    # E — estimate_flow_from_routes (all-or-nothing assignment)
    # ==================================================================
    print()
    print("[E] estimate_flow_from_routes ...")

    from osm.osm_flow_estimator.core.osm_flow_estimator_core import (
        estimate_flow_from_routes,
    )

    network_fc, flow_stats = estimate_flow_from_routes(
        network_fc, routes_fc_1, peak_hour_fraction=peak_hour_fraction
    )
    print(
        f"  {flow_stats.get('links_with_flow', 0):,} / "
        f"{flow_stats.get('links_total', 0):,} links assigned  "
        f"(total trips: {flow_stats.get('total_trips_assigned', 0):,.0f})"
    )

    if debug:
        _snapshot(13, area_id, out_dir, NETWORK_FLOWS=network_fc)

    # ==================================================================
    # D2 — matrix_builder (with BPR congestion-weighted costs)
    # ==================================================================
    print()
    print("[D2] matrix_builder (with flows / BPR congestion) ...")

    routes_fc = build_matrix(
        network_fc, feedlinks_fc, zones_fc, max_routes=max_routes, workers=matrix_workers
    )
    n_routes = len(routes_fc.get("features") or [])
    print(f"  {n_routes:,} route features built")

    if debug:
        _snapshot(14, area_id, out_dir, ROUTES=routes_fc)

    # ==================================================================
    # Write final outputs
    # ==================================================================

    # Inject common metadata into zones and routes before writing.
    zones_fc.setdefault("properties", {}).update(
        {
            **_common_meta,
            "fields": [
                "zoneId",
                "zoneClass",
                "zoneName",
                "nBuildings",
                "totalFootprintM2",
                "buildingTypes",
                "centroidLon",
                "centroidLat",
                "production",
                "municipalityName",
                "nutsCode",
            ],
        }
    )
    routes_fc.setdefault("properties", {}).update(_common_meta)

    network_path.write_bytes(to_geoparquet(network_fc))
    feedlink_path.write_bytes(to_geoparquet(feedlinks_fc))
    zone_path.write_bytes(to_geoparquet(zones_fc))
    routes_path.write_bytes(to_geoparquet(routes_fc))
    buildings_path.write_bytes(to_geoparquet(buildings_fc))
    if _write_traffic_assets:
        traffic_assets_path.write_bytes(to_geoparquet(_assets_fc))

    print()
    print("=" * 60)
    print(" OSM Pipeline complete.")
    print(f" Buildings: {buildings_path}")
    print(f" Network  : {network_path}")
    print(f" Feedlinks: {feedlink_path}")
    print(f" Zones    : {zone_path}")
    print(f" Routes   : {routes_path}")
    if _write_traffic_assets:
        print(f" Traffic assets: {traffic_assets_path}")
    print("=" * 60)

    return area_id
