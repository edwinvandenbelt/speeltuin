"""Unit tests for osm_asset_fetcher core (pure functions + stubbed Overpass)."""

from __future__ import annotations

import math

from osm_asset_fetcher.core.osm_asset_fetcher_core import (
    DEFAULT_KINDS,
    KIND_BIKE_GATE,
    KIND_BUS_SHELTER,
    KIND_BUS_STOP,
    KIND_CYCLE_PATH,
    KIND_FOOT_PATH,
    KIND_GIVE_WAY,
    KIND_INFO_BOARD,
    KIND_LANE_MARK_ARROW,
    KIND_MAILBOX,
    KIND_MAST,
    KIND_MINI_ROUNDABOUT,
    KIND_PEDESTRIAN_CROSSING,
    KIND_SPEED_BUMP,
    KIND_STOP_SIGN,
    KIND_STREET_LIGHT,
    KIND_TRASH_BIN,
    OSM_ASSET_QUERY_VER,
    classify_element,
    elements_to_asset_features,
    fetch_osm_assets,
    overpass_query_for_bbox,
)

_BBOX = [6.39, 52.14, 6.43, 52.17]


# ---------------------------------------------------------------------------
# classify_element
# ---------------------------------------------------------------------------


def test_classify_element_matches_each_kind() -> None:
    assert classify_element({"highway": "crossing"}, DEFAULT_KINDS) == KIND_PEDESTRIAN_CROSSING
    assert classify_element({"traffic_calming": "bump"}, DEFAULT_KINDS) == KIND_SPEED_BUMP
    assert classify_element({"highway": "stop"}, DEFAULT_KINDS) == KIND_STOP_SIGN
    assert classify_element({"highway": "give_way"}, DEFAULT_KINDS) == KIND_GIVE_WAY
    assert classify_element({"highway": "mini_roundabout"}, DEFAULT_KINDS) == KIND_MINI_ROUNDABOUT


def test_classify_element_matches_new_kinds() -> None:
    assert classify_element({"amenity": "post_box"}, DEFAULT_KINDS) == KIND_MAILBOX
    assert (
        classify_element({"amenity": "shelter", "shelter_type": "public_transport"}, DEFAULT_KINDS)
        == KIND_BUS_SHELTER
    )
    assert classify_element({"man_made": "mast"}, DEFAULT_KINDS) == KIND_MAST
    assert classify_element({"barrier": "cycle_barrier"}, DEFAULT_KINDS) == KIND_BIKE_GATE
    assert classify_element({"information": "board"}, DEFAULT_KINDS) == KIND_INFO_BOARD
    assert classify_element({"amenity": "waste_basket"}, DEFAULT_KINDS) == KIND_TRASH_BIN
    assert classify_element({"highway": "bus_stop"}, DEFAULT_KINDS) == KIND_BUS_STOP
    assert classify_element({"highway": "street_lamp"}, DEFAULT_KINDS) == KIND_STREET_LIGHT


def test_classify_element_bus_shelter_requires_both_tags() -> None:
    # A generic (non-PT) shelter must not be classified as a bus shelter.
    assert classify_element({"amenity": "shelter"}, DEFAULT_KINDS) is None
    assert (
        classify_element({"amenity": "shelter", "shelter_type": "picnic_shelter"}, DEFAULT_KINDS)
        is None
    )


def test_classify_element_returns_none_for_unmatched() -> None:
    assert classify_element({"highway": "residential"}, DEFAULT_KINDS) is None
    assert classify_element({}, DEFAULT_KINDS) is None


def test_classify_element_respects_requested_kinds() -> None:
    # speedBump excluded from the requested kinds -> not classified.
    assert classify_element({"traffic_calming": "hump"}, [KIND_PEDESTRIAN_CROSSING]) is None


# ---------------------------------------------------------------------------
# overpass_query_for_bbox
# ---------------------------------------------------------------------------


def test_overpass_query_uses_south_west_north_east_order() -> None:
    query = overpass_query_for_bbox(_BBOX, [KIND_STOP_SIGN], timeout=30)
    # Overpass order: south,west,north,east => minLat,minLon,maxLat,maxLon
    assert "52.14,6.39,52.17,6.43" in query
    assert '"highway"="stop"' in query
    assert "[timeout:30]" in query


def test_overpass_query_skips_unknown_kinds() -> None:
    query = overpass_query_for_bbox(_BBOX, ["notAKind", KIND_SPEED_BUMP])
    assert '"traffic_calming"' in query
    assert "notAKind" not in query


def test_overpass_query_includes_new_kind_filters() -> None:
    query = overpass_query_for_bbox(_BBOX, DEFAULT_KINDS)
    assert '"amenity"="post_box"' in query
    assert '"man_made"="mast"' in query
    assert '"barrier"="cycle_barrier"' in query
    assert '"information"="board"' in query
    assert '"amenity"="waste_basket"' in query
    assert '"highway"="bus_stop"' in query
    assert '"highway"="street_lamp"' in query
    # Bus shelter is a chained multi-tag selector (logical AND).
    assert 'node["amenity"="shelter"]["shelter_type"="public_transport"]' in query


def test_overpass_query_emits_way_selector_for_bus_shelter() -> None:
    query = overpass_query_for_bbox(_BBOX, DEFAULT_KINDS)
    # Bus shelters may be mapped as areas, so a way selector is emitted too.
    assert 'way["amenity"="shelter"]["shelter_type"="public_transport"]' in query
    # Way geometry is required to compute a centroid.
    assert "out geom;" in query
    # Node-only kinds must NOT emit a way selector.
    assert 'way["highway"="bus_stop"]' not in query
    assert 'way["highway"="street_lamp"]' not in query


def test_way_bus_shelter_reduced_to_centroid() -> None:
    elements = [
        {
            "type": "way",
            "id": 1551673111,
            "tags": {"amenity": "shelter", "shelter_type": "public_transport"},
            "geometry": [
                {"lat": 52.0, "lon": 6.0},
                {"lat": 52.0, "lon": 6.2},
                {"lat": 52.2, "lon": 6.2},
                {"lat": 52.2, "lon": 6.0},
                {"lat": 52.0, "lon": 6.0},
            ],
        },
        # A crossing way must still be dropped (not a way-capable kind).
        {"type": "way", "id": 2, "tags": {"highway": "crossing"}, "geometry": []},
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    assert len(feats) == 1
    assert feats[0]["properties"]["assetType"] == KIND_BUS_SHELTER
    assert feats[0]["properties"]["osm_id"] == 1551673111
    assert feats[0]["geometry"]["type"] == "Point"
    # Closing vertex dropped -> centroid of the 4 distinct corners.
    assert feats[0]["geometry"]["coordinates"] == [6.1, 52.1]


# ---------------------------------------------------------------------------
# elements_to_asset_features
# ---------------------------------------------------------------------------


def test_elements_to_asset_features_tags_and_filters() -> None:
    elements = [
        {"type": "node", "id": 1, "lat": 52.15, "lon": 6.40, "tags": {"highway": "crossing"}},
        {"type": "node", "id": 2, "lat": 52.15, "lon": 6.41, "tags": {"highway": "residential"}},
        {"type": "way", "id": 3, "tags": {"highway": "crossing"}},
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    assert len(feats) == 1
    assert feats[0]["geometry"] == {"type": "Point", "coordinates": [6.40, 52.15]}
    assert feats[0]["properties"]["assetType"] == KIND_PEDESTRIAN_CROSSING
    assert feats[0]["properties"]["osm_id"] == 1


def test_elements_to_asset_features_new_kinds() -> None:
    elements = [
        {"type": "node", "id": 10, "lat": 52.15, "lon": 6.40, "tags": {"amenity": "post_box"}},
        {
            "type": "node",
            "id": 11,
            "lat": 52.15,
            "lon": 6.41,
            "tags": {"amenity": "shelter", "shelter_type": "public_transport"},
        },
        {"type": "node", "id": 12, "lat": 52.15, "lon": 6.42, "tags": {"highway": "bus_stop"}},
        {"type": "node", "id": 14, "lat": 52.15, "lon": 6.44, "tags": {"highway": "street_lamp"}},
        {"type": "node", "id": 13, "lat": 52.15, "lon": 6.43, "tags": {"amenity": "shelter"}},
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    types = {f["properties"]["osm_id"]: f["properties"]["assetType"] for f in feats}
    assert types == {
        10: KIND_MAILBOX,
        11: KIND_BUS_SHELTER,
        12: KIND_BUS_STOP,
        14: KIND_STREET_LIGHT,
    }


# ---------------------------------------------------------------------------
# cycle- / foot-path line features (Verzoek 2)
# ---------------------------------------------------------------------------


def test_overpass_query_emits_way_only_selector_for_line_kinds() -> None:
    query = overpass_query_for_bbox(_BBOX, [KIND_CYCLE_PATH, KIND_FOOT_PATH])
    # Linear paths are OSM ways only -> a way selector, never a node selector.
    assert 'way["highway"="cycleway"]' in query
    assert 'way["highway"~"^(footway|path|pedestrian)$"]' in query
    assert 'node["highway"="cycleway"]' not in query
    assert 'node["highway"~"^(footway|path|pedestrian)$"]' not in query


def test_classify_element_matches_line_kinds() -> None:
    assert classify_element({"highway": "cycleway"}, DEFAULT_KINDS) == KIND_CYCLE_PATH
    assert classify_element({"highway": "footway"}, DEFAULT_KINDS) == KIND_FOOT_PATH
    assert classify_element({"highway": "path"}, DEFAULT_KINDS) == KIND_FOOT_PATH
    assert classify_element({"highway": "pedestrian"}, DEFAULT_KINDS) == KIND_FOOT_PATH


def test_cycle_path_way_becomes_linestring_with_attributes() -> None:
    elements = [
        {
            "type": "way",
            "id": 987654,
            "tags": {
                "highway": "cycleway",
                "width": "2,5 m",
                "oneway": "yes",
                "segregated": "no",
                "surface": "asphalt",
                "lit": "yes",
            },
            "geometry": [
                {"lat": 52.10, "lon": 6.40},
                {"lat": 52.11, "lon": 6.41},
                {"lat": 52.12, "lon": 6.42},
            ],
        }
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    assert len(feats) == 1
    feat = feats[0]
    assert feat["geometry"]["type"] == "LineString"
    assert feat["geometry"]["coordinates"] == [[6.40, 52.10], [6.41, 52.11], [6.42, 52.12]]
    props = feat["properties"]
    assert props["assetType"] == KIND_CYCLE_PATH
    assert props["osm_id"] == 987654
    assert props["pathType"] == "separated"
    assert props["width"] == 2.5
    assert props["oneway"] is True
    assert props["segregated"] is False
    assert props["surface"] == "asphalt"
    assert props["lit"] is True


def test_foot_path_way_derives_defaults_for_missing_attributes() -> None:
    elements = [
        {
            "type": "way",
            "id": 555,
            "tags": {"highway": "footway"},
            "geometry": [
                {"lat": 52.10, "lon": 6.40},
                {"lat": 52.11, "lon": 6.41},
            ],
        }
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    assert len(feats) == 1
    props = feats[0]["properties"]
    assert props["assetType"] == KIND_FOOT_PATH
    assert props["pathType"] == "separated"
    assert props["width"] is None
    assert props["oneway"] is False
    assert props["segregated"] is False
    assert props["surface"] is None
    assert props["lit"] is None


def test_cycleway_lane_derives_lane_path_type() -> None:
    elements = [
        {
            "type": "way",
            "id": 42,
            "tags": {"highway": "cycleway", "cycleway": "lane"},
            "geometry": [
                {"lat": 52.10, "lon": 6.40},
                {"lat": 52.11, "lon": 6.41},
            ],
        }
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    # highway=cycleway itself is standalone-separated; explicit highway wins.
    assert feats[0]["properties"]["pathType"] == "separated"


def test_line_kind_way_with_too_few_vertices_is_dropped() -> None:
    elements = [
        {
            "type": "way",
            "id": 7,
            "tags": {"highway": "cycleway"},
            "geometry": [{"lat": 52.10, "lon": 6.40}],
        }
    ]
    assert elements_to_asset_features(elements, DEFAULT_KINDS) == []


# ---------------------------------------------------------------------------
# fetch_osm_assets — stubbed Overpass client
# ---------------------------------------------------------------------------


def test_fetch_osm_assets_empty_kinds_skips() -> None:
    fc, stats = fetch_osm_assets(_BBOX, kinds=[])
    assert stats["source"] == "skipped"
    assert stats["total"] == 0
    assert fc["features"] == []


def test_fetch_osm_assets_counts_by_type(monkeypatch) -> None:
    def _fake_tiled(_query_fn, _bbox, **_kwargs) -> dict:
        return {
            "elements": [
                {"type": "node", "id": 1, "lat": 52.15, "lon": 6.40, "tags": {"highway": "stop"}},
                {"type": "node", "id": 2, "lat": 52.16, "lon": 6.41, "tags": {"highway": "stop"}},
                {
                    "type": "node",
                    "id": 3,
                    "lat": 52.16,
                    "lon": 6.42,
                    "tags": {"highway": "crossing"},
                },
            ]
        }

    monkeypatch.setattr("shared.overpass.fetch_overpass_tiled", _fake_tiled, raising=True)

    fc, stats = fetch_osm_assets(_BBOX, kinds=[KIND_STOP_SIGN, KIND_PEDESTRIAN_CROSSING])
    assert stats["source"] == "OSM"
    assert stats["total"] == 3
    assert stats["counts"][KIND_STOP_SIGN] == 2
    assert stats["counts"][KIND_PEDESTRIAN_CROSSING] == 1
    assert fc["properties"]["_qv"] == OSM_ASSET_QUERY_VER


# ---------------------------------------------------------------------------
# lane mark arrows
# ---------------------------------------------------------------------------


def _straight_way(turn_lanes_value: str, tag_key: str = "turn:lanes") -> dict:
    """Build a straight east-west way for lane mark arrow tests."""
    return {
        "type": "way",
        "id": 101,
        "tags": {tag_key: turn_lanes_value},
        "geometry": [
            {"lon": 6.400, "lat": 52.150},
            {"lon": 6.410, "lat": 52.150},
            {"lon": 6.420, "lat": 52.150},
        ],
    }


def test_lane_mark_arrow_forward_geometry() -> None:
    elements = [_straight_way("through|right")]
    feats = elements_to_asset_features(elements, [KIND_LANE_MARK_ARROW])
    assert len(feats) == 1
    feat = feats[0]
    assert feat["properties"]["assetType"] == KIND_LANE_MARK_ARROW
    assert feat["properties"]["direction"] == "forward"
    assert feat["properties"]["turn:lanes"] == "through|right"
    assert feat["properties"]["position_from_end_m"] == 5
    assert feat["properties"]["length_m"] == 2

    assert feat["geometry"]["type"] == "LineString"
    coords = feat["geometry"]["coordinates"]
    assert len(coords) == 2
    # LineString runs from 5 m before the toNode to 3 m before the toNode.
    # toNode is at (6.420, 52.150), so x decreases toward the start.
    assert coords[0][0] < coords[1][0] or math.isclose(coords[0][0], coords[1][0])
    # Y stays constant on an east-west line.
    assert math.isclose(coords[0][1], 52.150, rel_tol=1e-12)
    assert math.isclose(coords[1][1], 52.150, rel_tol=1e-12)


def test_lane_mark_arrow_backward_reverses_geometry() -> None:
    elements = [_straight_way("left|through", tag_key="turn:lanes:backward")]
    feats = elements_to_asset_features(elements, [KIND_LANE_MARK_ARROW])
    assert len(feats) == 1
    feat = feats[0]
    assert feat["properties"]["direction"] == "backward"
    # Raw value stored under turn:lanes regardless of source tag.
    assert feat["properties"]["turn:lanes"] == "left|through"

    coords = feat["geometry"]["coordinates"]
    # With reversed geometry, "toNode" for the backward direction is the first
    # original vertex at (6.400, 52.150).  The arrow must run toward it,
    # so x decreases along the feature.
    assert coords[1][0] < coords[0][0]


def test_lane_mark_arrow_network_match() -> None:
    from shapely.geometry import LineString, Point

    elements = [_straight_way("left|through|right")]
    network_fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {"linkId": "LINK-1", "toNode": "NODE-END"},
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[6.400, 52.150], [6.420, 52.150]],
                },
            }
        ],
    }
    # Verify the network link geometry covers the arrow position.
    arrow_feats = elements_to_asset_features(elements, [KIND_LANE_MARK_ARROW])
    midpoint = arrow_feats[0]["geometry"]["coordinates"][0]
    assert (
        LineString([[6.400, 52.150], [6.420, 52.150]]).distance(Point(midpoint[0], midpoint[1]))
        < 1e-6
    )

    feats = elements_to_asset_features(elements, [KIND_LANE_MARK_ARROW], network_fc=network_fc)
    assert len(feats) == 1
    assert feats[0]["properties"]["linkId"] == "LINK-1"
    assert feats[0]["properties"]["nodeId"] == "NODE-END"


def test_generic_point_assets_get_link_id() -> None:
    elements = [
        {"type": "node", "id": 1, "lat": 52.150, "lon": 6.410, "tags": {"highway": "crossing"}},
    ]
    network_fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {"linkId": "LINK-A", "toNode": "NODE-A"},
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[6.400, 52.150], [6.420, 52.150]],
                },
            }
        ],
    }
    feats = elements_to_asset_features(
        elements,
        [KIND_PEDESTRIAN_CROSSING],
        network_fc=network_fc,
    )
    assert len(feats) == 1
    props = feats[0]["properties"]
    assert props["assetType"] == KIND_PEDESTRIAN_CROSSING
    assert props["linkId"] == "LINK-A"
    assert props["nodeId"] == "NODE-A"


def test_network_enrichment_counts_by_link_id() -> None:
    from osm_asset_fetcher.core.domain.network_enrichment import (
        enrich_network_with_osm_assets,
    )

    asset_features = [
        {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0.0, 0.0]},
            "properties": {
                "assetType": "pedestrianCrossing",
                "linkId": "L1",
                "nodeId": "N1",
            },
        },
        {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0.0, 0.0]},
            "properties": {
                "assetType": "stoppingLane",
                "linkId": "L1",
                "nodeId": "N1",
            },
        },
        {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0.0, 0.0]},
            "properties": {
                "assetType": "speedBump",
                "linkId": "L2",
                "nodeId": "N2",
            },
        },
    ]
    network_fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {"linkId": "L1", "toNode": "N1"},
                "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
            },
            {
                "type": "Feature",
                "properties": {"linkId": "L2", "toNode": "N2"},
                "geometry": {"type": "LineString", "coordinates": [[2, 0], [3, 0]]},
            },
        ],
    }
    enriched = enrich_network_with_osm_assets(network_fc, asset_features)
    l1_props = enriched["features"][0]["properties"]
    l2_props = enriched["features"][1]["properties"]
    assert l1_props["numPedestrianCrossings"] == 1
    assert l1_props["numStoppingLanes"] == 1
    assert l2_props["numSpeedBumps"] == 1


# ---------------------------------------------------------------------------
# Speed-layer enrichment (cycle crossings + POI areas)
# ---------------------------------------------------------------------------


def test_cycle_crossings_detected_at_path_network_intersections() -> None:
    from osm_asset_fetcher.core.domain.network_enrichment import (
        enrich_network_with_pois_and_crossings,
    )

    # Car network: two orthogonal links, like a plus sign.
    network_fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {"linkId": "EW", "toNode": "E"},
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[0.0, 0.0], [0.0002, 0.0]],
                },
            },
            {
                "type": "Feature",
                "properties": {"linkId": "NS", "toNode": "N"},
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[0.0001, -0.0001], [0.0001, 0.0001]],
                },
            },
        ],
    }

    path_features = [
        {
            "type": "Feature",
            "geometry": {
                "type": "LineString",
                "coordinates": [[0.0001, -0.0001], [0.0001, 0.0001]],
            },
            "properties": {"assetType": "cyclePath"},
        }
    ]

    enriched = enrich_network_with_pois_and_crossings(
        network_fc, asset_features=path_features, poi_features=[], built_up_features=[]
    )
    props = {f["properties"]["linkId"]: f["properties"] for f in enriched["features"]}
    assert props["EW"]["numCycleCrossings"] >= 1
    assert props["NS"]["numCycleCrossings"] >= 1


def test_poi_area_computed_within_built_up_buffer() -> None:
    from osm_asset_fetcher.core.domain.network_enrichment import (
        enrich_network_with_pois_and_crossings,
    )

    built_up_features = [
        {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [-0.001, -0.001],
                        [0.001, -0.001],
                        [0.001, 0.001],
                        [-0.001, 0.001],
                        [-0.001, -0.001],
                    ]
                ],
            },
            "properties": {"landuse": "residential"},
        }
    ]

    poi_features = [
        {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [-0.0008, -0.0008],
                        [0.0008, -0.0008],
                        [0.0008, 0.0008],
                        [-0.0008, 0.0008],
                        [-0.0008, -0.0008],
                    ]
                ],
            },
            "properties": {"assetType": "school", "amenity": "school"},
        }
    ]

    network_fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {"linkId": "L1", "toNode": "N1"},
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[0.0, -0.0005], [0.0, 0.0005]],
                },
            }
        ],
    }

    enriched = enrich_network_with_pois_and_crossings(
        network_fc,
        asset_features=[],
        poi_features=poi_features,
        built_up_features=built_up_features,
    )
    props = enriched["features"][0]["properties"]
    assert props["areaSchoolsNearbyM2_bike"] > 0
    assert props["areaSchoolsNearbyM2_pedestrian"] > 0
    assert props["areaSchoolsNearbyM2_bike"] >= props["areaSchoolsNearbyM2_pedestrian"]


def test_poi_point_fallback_area_used_for_node_pois() -> None:
    from osm_asset_fetcher.core.domain.network_enrichment import (
        enrich_network_with_pois_and_crossings,
    )

    built_up_features = [
        {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [-0.001, -0.001],
                        [0.001, -0.001],
                        [0.001, 0.001],
                        [-0.001, 0.001],
                        [-0.001, -0.001],
                    ]
                ],
            },
            "properties": {"landuse": "residential"},
        }
    ]

    poi_features = [
        {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0.0, 0.0]},
            "properties": {"assetType": "shop", "shop": "supermarket"},
        }
    ]

    network_fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "properties": {"linkId": "L1", "toNode": "N1"},
                "geometry": {
                    "type": "LineString",
                    "coordinates": [[0.0, 0.0], [0.0, 0.0001]],
                },
            }
        ],
    }

    enriched = enrich_network_with_pois_and_crossings(
        network_fc,
        asset_features=[],
        poi_features=poi_features,
        built_up_features=built_up_features,
    )
    props = enriched["features"][0]["properties"]
    assert props["areaShopsNearbyM2_bike"] > 0
    assert props["areaShopsNearbyM2_pedestrian"] > 0


def test_extract_poi_features_classifies_schools_and_shops() -> None:
    from osm_asset_fetcher.core.domain.network_enrichment import extract_poi_features

    elements = [
        {"type": "node", "id": 1, "lat": 52.0, "lon": 6.0, "tags": {"amenity": "school"}},
        {"type": "node", "id": 2, "lat": 52.0, "lon": 6.001, "tags": {"shop": "supermarket"}},
        {"type": "node", "id": 3, "lat": 52.0, "lon": 6.002, "tags": {"amenity": "restaurant"}},
    ]
    features = extract_poi_features(elements)
    types = {f["properties"]["assetType"] for f in features}
    assert "school" in types
    assert "shop" in types
    assert "restaurant" not in types
    assert len(features) == 2


def test_extract_built_up_features_keeps_residential_commercial_retail() -> None:
    from osm_asset_fetcher.core.domain.network_enrichment import extract_built_up_features

    elements = [
        {
            "type": "way",
            "id": 10,
            "tags": {"landuse": "residential"},
            "geometry": [
                {"lat": 52.0, "lon": 6.0},
                {"lat": 52.001, "lon": 6.0},
                {"lat": 52.001, "lon": 6.001},
                {"lat": 52.0, "lon": 6.001},
                {"lat": 52.0, "lon": 6.0},
            ],
        },
        {"type": "way", "id": 11, "tags": {"landuse": "forest"}, "geometry": []},
    ]
    features = extract_built_up_features(elements)
    assert len(features) == 1
    assert features[0]["properties"]["landuse"] == "residential"
    assert features[0]["geometry"]["type"] == "Polygon"
