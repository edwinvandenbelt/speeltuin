"""Network enrichment helpers for OSM traffic assets.

This module provides a simple, ``linkId``-based way to add proximity counts to
network links.  It assumes every point asset has already been matched to its
nearest network link (see :mod:`geometry_matching`).  Linear assets
(``cyclePath``, ``footPath``) are counted against links they intersect within a
small buffer.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


# Counted asset types on the network.
_ASSET_COUNTERS: dict[str, str] = {
    "pedestrianCrossing": "numPedestrianCrossings",
    "refugeAreaCrossing": "numRefugeAreas",
    "refugeAreaFootway": "numRefugeAreas",
    "refugeAreaTraffic": "numRefugeAreas",
    "stoppingLane": "numStoppingLanes",
    "stopSign": "numGiveWays",
    "giveWay": "numGiveWays",
    "speedBump": "numSpeedBumps",
}


def _asset_counter_for(asset_type: str | None) -> str | None:
    """Return the network counter field for an asset type, if any."""
    if asset_type is None:
        return None
    return _ASSET_COUNTERS.get(asset_type)


def _link_index(network_fc: dict) -> dict[str, dict]:
    """Return a ``linkId -> link properties`` index."""
    idx: dict[str, dict] = {}
    for link in network_fc.get("features") or []:
        props = link.get("properties") or {}
        lid = props.get("linkId")
        if lid is not None:
            idx[str(lid)] = props
    return idx


def _count_linear_intersections(
    network_fc: dict,
    line_features: list[dict],
    buffer_m: float = 20.0,
) -> dict[str, int]:
    """Count how many line assets intersect each network link (within buffer).

    For now this keeps the existing shapely-based spatial check so that
    ``numCyclePaths`` still works for paths that cross a link rather than being
    snapped to a single ``linkId``.
    """
    try:
        from shapely.geometry import LineString
    except ImportError:
        logger.warning("shapely not available; skipping cycle/foot path enrichment")
        return {}

    counts: dict[str, int] = {}
    # metres -> rough degrees at mid-latitudes.
    buffer_deg = buffer_m / 111000.0

    network_links: list[tuple[dict, LineString]] = []
    for link in network_fc.get("features") or []:
        props = link.get("properties") or {}
        geom = link.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coords = [
            (float(c[0]), float(c[1])) for c in (geom.get("coordinates") or []) if len(c) >= 2
        ]
        if len(coords) < 2:
            continue
        try:
            network_links.append((props, LineString(coords)))
        except TypeError, ValueError:
            continue

    for feat in line_features:
        geom = feat.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coords = [
            (float(c[0]), float(c[1])) for c in (geom.get("coordinates") or []) if len(c) >= 2
        ]
        if len(coords) < 2:
            continue
        try:
            asset_line = LineString(coords).buffer(buffer_deg)
        except TypeError, ValueError:
            continue

        for link_props, link_line in network_links:
            if asset_line.intersects(link_line):
                lid = str(link_props.get("linkId", ""))
                counts[lid] = counts.get(lid, 0) + 1

    return counts


def enrich_network_with_osm_assets(
    network_fc: dict,
    asset_features: list[dict],
) -> dict:
    """Add asset-count columns to network links based on matched ``linkId`` s.

    Adds the following integer fields to every link feature (default 0):

    * ``numPedestrianCrossings``  — from ``assetType == "pedestrianCrossing"``
    * ``numRefugeAreas``          — from ``refugeArea*`` types
    * ``numStoppingLanes``        — from ``stoppingLane``
    * ``numGiveWays``             — from ``stopSign`` and ``giveWay``
    * ``numSpeedBumps``           — from ``speedBump``
    * ``numCyclePaths``           — from ``cyclePath`` LineStrings within 20 m

    Parameters
    ----------
    network_fc:
        Network FeatureCollection whose links have ``properties.linkId``.
    asset_features:
        Asset features produced by ``osm_asset_fetcher``.

    Returns
    -------
    dict
        *network_fc* with counts added to each link's properties.
    """
    link_props_by_id = _link_index(network_fc)

    # Ensure all counter fields exist and start at 0.
    counter_fields = [*set(_ASSET_COUNTERS.values()), "numCyclePaths"]
    for props in link_props_by_id.values():
        for field in counter_fields:
            props[field] = 0

    # Count point assets by linkId.
    for feat in asset_features:
        props = feat.get("properties") or {}
        asset_type = props.get("assetType")
        counter_field = _asset_counter_for(asset_type)
        if counter_field is None:
            continue
        lid = props.get("linkId")
        if lid is None:
            continue
        link_props = link_props_by_id.get(str(lid))
        if link_props is None:
            continue
        link_props[counter_field] += 1

    # Count linear assets (cycle paths) spatially.
    cycle_paths = [
        f for f in asset_features if (f.get("properties") or {}).get("assetType") == "cyclePath"
    ]
    if cycle_paths:
        cycle_counts = _count_linear_intersections(network_fc, cycle_paths)
        for lid, count in cycle_counts.items():
            link_props = link_props_by_id.get(lid)
            if link_props is not None:
                link_props["numCyclePaths"] += count

    enriched = 0
    for props in link_props_by_id.values():
        if any(props.get(f, 0) > 0 for f in counter_fields):
            enriched += 1

    logger.info(
        "Enriched %d/%d network links with OSM asset counts",
        enriched,
        len(link_props_by_id),
    )
    return network_fc
