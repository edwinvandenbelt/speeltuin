"""Pure-Python osm_asset_fetcher core — fetches traffic objects from OSM.

Fetches point-based traffic objects for a bounding box from the OpenStreetMap
Overpass API and returns them as a GeoJSON ``FeatureCollection``.  Every
feature is tagged ``properties.assetType`` (camelCase) so the result can be
merged into the combined ``{area_id}-TRAFFIC-ASSETS.parquet`` produced by the
prepare pipeline.

Unlike the Dutch BGT (which only covers the Netherlands and only usefully
registers speed bumps), OSM provides worldwide coverage of a range of traffic
objects encoded as node tags — most notably pedestrian crossings, stop /
give-way signs, mini-roundabouts and traffic-calming (speed) bumps.

Supported asset kinds
---------------------
Each *kind* maps an OSM tag match to an ``assetType`` value:

* ``pedestrianCrossing`` — ``highway=crossing``
* ``speedBump``          — ``traffic_calming=*`` (bump, hump, table, cushion …)
* ``stopSign``           — ``highway=stop``
* ``giveWay``            — ``highway=give_way``
* ``miniRoundabout``     — ``highway=mini_roundabout``
* ``mailbox``            — ``amenity=post_box``
* ``busShelter``         — ``amenity=shelter`` + ``shelter_type=public_transport``
  (node *or* way; ways are reduced to their centroid)
* ``mast``               — ``man_made=mast``
* ``bikeGate``           — ``barrier=cycle_barrier``
* ``infoBoard``          — ``information=board``
* ``trashBin``            — ``amenity=waste_basket``
* ``busStop``            — ``highway=bus_stop``
* ``streetLight``        — ``highway=street_lamp`` (lantaarnpaal / openbare
  verlichting; a public street-light point)
* ``cyclePath``          — ``highway=cycleway`` (OSM *way* → ``LineString``)
* ``footPath``           — ``highway=footway`` / ``path`` / ``pedestrian``
  (OSM *way* → ``LineString``)

Point kinds are emitted as ``Point`` features.  The linear kinds ``cyclePath``
and ``footPath`` are emitted as ``LineString`` features carrying the typed
attributes ``pathType`` (separated/lane/bus/shared), ``width`` (m), ``oneway``,
``segregated``, ``surface`` and ``lit`` alongside the raw OSM tags.

New Refuge & Stopping Lane kinds
---------------------------------

    * ``stoppingLane`` — ``turn:lanes*`` tags (left|through|right per lane)
      Emitted as ``Point`` features with lane index, turn direction, and
      linked network ``linkId`` + ``nodeId``.

    * ``laneMarkArrow`` — ``turn:lanes*`` tags.
      Emitted as short (2 m) longitudinal ``LineString`` features along the OSM
      way centerline (5 m to 3 m before the toNode), carrying the raw
      ``turn:lanes`` value and ``linkId`` + ``nodeId``.

    * ``refugeAreaCrossing`` — ``highway=crossing`` + ``crossing:island=yes``
  Emitted as ``Point`` features at crossing nodes with refuge islands.

* ``refugeAreaFootway`` — ``footway=traffic_island`` / ``cycleway=traffic_island``
  Emitted as ``Polygon`` features (LineString buffered by ~0.5m).

* ``refugeAreaTraffic`` — ``area:highway=traffic_island`` / ``traffic_calming=island``
  Emitted as ``Polygon`` (way) or ``Point`` (node) features for traffic-calming
  refuge islands.

The set of kinds fetched is configurable (see :func:`fetch_osm_assets`), so the
prepare pipeline can exclude ``speedBump`` in the Netherlands where BGT already
provides authoritative verkeersdrempels.

Public API
----------
classify_element(tags, kinds) -> str | None
    Return the assetType for an OSM element's tags, or None when it matches none
    of the requested kinds.
overpass_query_for_bbox(bbox, kinds, timeout) -> str
    Build an Overpass QL query for the requested kinds inside *bbox*.
elements_to_asset_features(elements, kinds, network_fc) -> list[dict]
    Convert raw Overpass elements to GeoJSON asset Feature dicts.
fetch_osm_assets(bbox, *, kinds, tiles, timeout, network_fc) -> tuple[dict, dict]
    High-level entry: fetch + classify + tag, return (fc, stats).
"""

from __future__ import annotations

import logging

from osm_asset_fetcher.core.domain.network_enrichment import (
    enrich_network_with_pois_and_crossings,
    extract_built_up_features,
    extract_poi_features,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached OSM asset output.
OSM_ASSET_QUERY_VER: int = 5

#: Default NxN tile grid for Overpass fetches.
OVERPASS_GRID: int = 3

#: Asset-type tags (camelCase) written on produced features.
KIND_PEDESTRIAN_CROSSING: str = "pedestrianCrossing"
KIND_SPEED_BUMP: str = "speedBump"
KIND_STOP_SIGN: str = "stopSign"
KIND_GIVE_WAY: str = "giveWay"
KIND_MINI_ROUNDABOUT: str = "miniRoundabout"
KIND_MAILBOX: str = "mailbox"
KIND_BUS_SHELTER: str = "busShelter"
KIND_MAST: str = "mast"
KIND_BIKE_GATE: str = "bikeGate"
KIND_INFO_BOARD: str = "infoBoard"
KIND_TRASH_BIN: str = "trashBin"
KIND_BUS_STOP: str = "busStop"
KIND_STREET_LIGHT: str = "streetLight"
KIND_CYCLE_PATH: str = "cyclePath"
KIND_FOOT_PATH: str = "footPath"
# New refuge and stopping lane kinds
KIND_STOPPING_LANE: str = "stoppingLane"
KIND_LANE_MARK_ARROW: str = "laneMarkArrow"
KIND_REFUGE_CROSSING: str = "refugeAreaCrossing"
KIND_REFUGE_FOOTWAY: str = "refugeAreaFootway"
KIND_REFUGE_TRAFFIC: str = "refugeAreaTraffic"

#: Mapping of assetType -> Overpass tag filter clause (the part inside the
#: ``node[...]`` selector).  A leading ``~`` value means "any value" for that
#: key (encoded as a key-only selector in the query).  Multi-tag matches chain
#: additional ``][`` bracket clauses inside the same selector (logical AND).
_KIND_TAG_FILTERS: dict[str, str] = {
    KIND_PEDESTRIAN_CROSSING: '"highway"="crossing"',
    KIND_SPEED_BUMP: '"traffic_calming"',
    KIND_STOP_SIGN: '"highway"="stop"',
    KIND_GIVE_WAY: '"highway"="give_way"',
    KIND_MINI_ROUNDABOUT: '"highway"="mini_roundabout"',
    KIND_MAILBOX: '"amenity"="post_box"',
    KIND_BUS_SHELTER: '"amenity"="shelter"]["shelter_type"="public_transport"',
    KIND_MAST: '"man_made"="mast"',
    KIND_BIKE_GATE: '"barrier"="cycle_barrier"',
    KIND_INFO_BOARD: '"information"="board"',
    KIND_TRASH_BIN: '"amenity"="waste_basket"',
    KIND_BUS_STOP: '"highway"="bus_stop"',
    KIND_STREET_LIGHT: '"highway"="street_lamp"',
    # Line-based paths (OSM ways) — matched as LineString features.
    KIND_CYCLE_PATH: '"highway"="cycleway"',
    KIND_FOOT_PATH: '"highway"~"^(footway|path|pedestrian)$"',
    # New refuge and stopping lane kinds (all are way-based).
    KIND_STOPPING_LANE: '"turn:lanes"|"turn:lanes:forward"|"turn:lanes:backward"',
    KIND_REFUGE_CROSSING: '"highway"="crossing"]["crossing:island"="yes"',
    KIND_REFUGE_FOOTWAY: '"footway"="traffic_island"|"cycleway"="traffic_island"',
    KIND_REFUGE_TRAFFIC: '"area:highway"="traffic_island"|"traffic_calming"="island"',
}

#: Default kinds fetched when the caller does not restrict them.
DEFAULT_KINDS: list[str] = [
    KIND_PEDESTRIAN_CROSSING,
    KIND_SPEED_BUMP,
    KIND_STOP_SIGN,
    KIND_GIVE_WAY,
    KIND_MINI_ROUNDABOUT,
    KIND_MAILBOX,
    KIND_BUS_SHELTER,
    KIND_MAST,
    KIND_BIKE_GATE,
    KIND_INFO_BOARD,
    KIND_TRASH_BIN,
    KIND_BUS_STOP,
    KIND_STREET_LIGHT,
    KIND_CYCLE_PATH,
    KIND_FOOT_PATH,
    # New refuge and stopping lane kinds
    KIND_STOPPING_LANE,
    KIND_LANE_MARK_ARROW,
    KIND_REFUGE_CROSSING,
    KIND_REFUGE_FOOTWAY,
    KIND_REFUGE_TRAFFIC,
]

#: Kinds that may also be mapped as OSM *ways* / areas (not just nodes).  For
#: these, the query emits an extra ``way[...]`` selector and matching ways are
#: reduced to a representative centroid ``Point`` feature.  Bus shelters (abris)
#: are commonly drawn as small building-like areas rather than single nodes.
#: Note: stoppingLane, refugeFootway, refugeTraffic need special handling and
#: are NOT reduced to centroids; see elements_to_asset_features().
_WAY_KINDS: frozenset[str] = frozenset({KIND_BUS_SHELTER})

#: Kinds that are inherently *linear* OSM ways (cycle- / foot-paths).  For these
#: the query emits only a ``way[...]`` selector and matching ways are emitted as
#: ``LineString`` features (not reduced to a centroid).
_LINE_KINDS: frozenset[str] = frozenset({KIND_CYCLE_PATH, KIND_FOOT_PATH})

#: Kinds that require special domain-module processing (not generic node/way handling).
#: These are processed via dedicated functions in the domain modules.
_SPECIAL_KINDS: frozenset[str] = frozenset(
    {
        KIND_STOPPING_LANE,
        KIND_LANE_MARK_ARROW,
        KIND_REFUGE_CROSSING,
        KIND_REFUGE_FOOTWAY,
        KIND_REFUGE_TRAFFIC,
    }
)


# ---------------------------------------------------------------------------
# Classification
# ---------------------------------------------------------------------------


def classify_element(tags: dict, kinds: list[str]) -> str | None:
    """Return the ``assetType`` for an OSM element's *tags*, or ``None``.

    The requested *kinds* are evaluated in order and the first match wins, so
    the caller controls precedence.  Only kinds present in *kinds* are ever
    returned.

    Parameters
    ----------
    tags:
        The ``tags`` dict of an Overpass node element.
    kinds:
        The list of assetType kinds to consider (see module constants).
    """
    for kind in kinds:
        if kind == KIND_PEDESTRIAN_CROSSING and tags.get("highway") == "crossing":
            return kind
        if kind == KIND_SPEED_BUMP and "traffic_calming" in tags:
            return kind
        if kind == KIND_STOP_SIGN and tags.get("highway") == "stop":
            return kind
        if kind == KIND_GIVE_WAY and tags.get("highway") == "give_way":
            return kind
        if kind == KIND_MINI_ROUNDABOUT and tags.get("highway") == "mini_roundabout":
            return kind
        if kind == KIND_MAILBOX and tags.get("amenity") == "post_box":
            return kind
        if (
            kind == KIND_BUS_SHELTER
            and tags.get("amenity") == "shelter"
            and tags.get("shelter_type") == "public_transport"
        ):
            return kind
        if kind == KIND_MAST and tags.get("man_made") == "mast":
            return kind
        if kind == KIND_BIKE_GATE and tags.get("barrier") == "cycle_barrier":
            return kind
        if kind == KIND_INFO_BOARD and tags.get("information") == "board":
            return kind
        if kind == KIND_TRASH_BIN and tags.get("amenity") == "waste_basket":
            return kind
        if kind == KIND_BUS_STOP and tags.get("highway") == "bus_stop":
            return kind
        if kind == KIND_STREET_LIGHT and tags.get("highway") == "street_lamp":
            return kind
        if kind == KIND_CYCLE_PATH and tags.get("highway") == "cycleway":
            return kind
        if kind == KIND_FOOT_PATH and tags.get("highway") in ("footway", "path", "pedestrian"):
            return kind
        # New refuge and stopping lane kinds.
        if (
            kind == KIND_REFUGE_CROSSING
            and tags.get("highway") == "crossing"
            and tags.get("crossing:island") == "yes"
        ):
            return kind
        if kind == KIND_REFUGE_FOOTWAY and tags.get("footway") == "traffic_island":
            return kind
        if kind == KIND_REFUGE_FOOTWAY and tags.get("cycleway") == "traffic_island":
            return kind
        if kind == KIND_REFUGE_TRAFFIC and tags.get("area:highway") == "traffic_island":
            return kind
        if kind == KIND_REFUGE_TRAFFIC and tags.get("traffic_calming") == "island":
            return kind
        if kind == KIND_STOPPING_LANE and any(
            k in tags for k in ("turn:lanes", "turn:lanes:forward", "turn:lanes:backward")
        ):
            return kind
    return None


# ---------------------------------------------------------------------------
# Overpass query + parsing
# ---------------------------------------------------------------------------


def overpass_query_for_bbox(
    bbox: list[float],
    kinds: list[str],
    timeout: int = 40,
) -> str:
    """Build an Overpass QL query for the requested *kinds* inside *bbox*.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    kinds:
        The list of assetType kinds to fetch.  Unknown kinds are ignored.
    timeout:
        Overpass server-side timeout in seconds.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    # Overpass uses (south, west, north, east) coordinate order.
    coord_str = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    clauses: list[str] = []
    for kind in kinds:
        tag_filter = _KIND_TAG_FILTERS.get(kind)
        if tag_filter is None:
            continue
        if kind in _LINE_KINDS:
            # Linear paths are OSM ways only — no node selector.
            clauses.append(f"way[{tag_filter}]({coord_str});")
            continue
        if kind in _SPECIAL_KINDS:
            # Special kinds require way fetches (handled by domain modules).
            # For refuge_crossing, also fetch node variant.
            if kind == KIND_REFUGE_CROSSING:
                clauses.append(f"node[{tag_filter}]({coord_str});")
            elif kind in (KIND_STOPPING_LANE, KIND_LANE_MARK_ARROW):
                # Both use turn:lanes* tags. Split into separate clauses (PBF parser limitation).
                clauses.append(f'way["turn:lanes"]({coord_str});')
                clauses.append(f'way["turn:lanes:forward"]({coord_str});')
                clauses.append(f'way["turn:lanes:backward"]({coord_str});')
            elif kind == KIND_REFUGE_FOOTWAY:
                # Split pipe-separated tags into separate clauses.
                clauses.append(f'way["footway"="traffic_island"]({coord_str});')
                clauses.append(f'way["cycleway"="traffic_island"]({coord_str});')
            elif kind == KIND_REFUGE_TRAFFIC:
                # Split pipe-separated tags into separate clauses.
                clauses.append(f'way["area:highway"="traffic_island"]({coord_str});')
                clauses.append(f'node["traffic_calming"="island"]({coord_str});')
            continue
        clauses.append(f"node[{tag_filter}]({coord_str});")
        if kind in _WAY_KINDS:
            clauses.append(f"way[{tag_filter}]({coord_str});")
    body = "\n  ".join(clauses)
    # ``out geom;`` includes node lat/lon *and* full way geometry, so way-based
    # kinds (e.g. bus shelters, refuge areas) can be processed client-side.
    return f"[out:json][timeout:{timeout}];\n(\n  {body}\n);\nout geom;"


def _way_centroid(geometry: list[dict]) -> tuple[float, float] | None:
    """Return the ``(lon, lat)`` centroid of an Overpass ``out geom;`` way.

    *geometry* is the list of ``{"lat": .., "lon": ..}`` vertices attached to a
    way element.  Returns ``None`` when there are no usable vertices.  For a
    closed ring the duplicated closing vertex is dropped so it does not bias the
    average.
    """
    pts = [(float(p["lon"]), float(p["lat"])) for p in geometry if "lat" in p and "lon" in p]
    if len(pts) >= 2 and pts[0] == pts[-1]:
        pts = pts[:-1]
    if not pts:
        return None
    lon = sum(p[0] for p in pts) / len(pts)
    lat = sum(p[1] for p in pts) / len(pts)
    return lon, lat


def _way_linestring(geometry: list[dict]) -> list[list[float]] | None:
    """Return the ``[[lon, lat], ...]`` vertex list of an ``out geom;`` way.

    Returns ``None`` when there are fewer than two usable vertices.
    """
    pts = [[float(p["lon"]), float(p["lat"])] for p in geometry if "lat" in p and "lon" in p]
    if len(pts) < 2:
        return None
    return pts


_TRUE_VALUES: frozenset[str] = frozenset({"yes", "true", "1"})
_FALSE_VALUES: frozenset[str] = frozenset({"no", "false", "0"})


def _parse_bool_tag(value: str | None) -> bool | None:
    """Parse an OSM yes/no-style tag to a bool, or ``None`` when unknown/absent."""
    if value is None:
        return None
    lc = value.strip().lower()
    if lc in _TRUE_VALUES:
        return True
    if lc in _FALSE_VALUES:
        return False
    return None


def _parse_width_m(value: str | None) -> float | None:
    """Parse an OSM ``width`` tag to metres, or ``None`` when non-numeric/absent."""
    if not value:
        return None
    import re

    m = re.match(r"^\s*(\d+(?:[.,]\d+)?)\s*(?:m(?:eters?)?)?\s*$", value, re.IGNORECASE)
    if not m:
        return None
    try:
        return float(m.group(1).replace(",", "."))
    except ValueError:
        return None


def _derive_path_type(tags: dict) -> str | None:
    """Derive the ``pathType`` enum (separated/lane/bus/shared) from OSM tags.

    Standalone ``highway=cycleway``/``footway``/``path`` count as ``separated``;
    otherwise the ``cycleway=*`` value drives the classification.
    """
    hw = tags.get("highway")
    if hw in ("cycleway", "footway", "path", "pedestrian"):
        return "separated"
    cw = (tags.get("cycleway") or "").strip().lower()
    if cw in ("track", "opposite_track", "separate"):
        return "separated"
    if cw in ("lane", "opposite_lane"):
        return "lane"
    if cw in ("share_busway", "shared_busway", "opposite_share_busway"):
        return "bus"
    if cw in ("shared_lane", "shared"):
        return "shared"
    return None


def _path_attributes(tags: dict) -> dict:
    """Build the typed cycle/foot-path attribute dict from raw OSM *tags*."""
    return {
        "pathType": _derive_path_type(tags),
        "width": _parse_width_m(tags.get("width")),
        "oneway": bool(_parse_bool_tag(tags.get("oneway"))),
        "segregated": bool(_parse_bool_tag(tags.get("segregated"))),
        "surface": tags.get("surface"),
        "lit": _parse_bool_tag(tags.get("lit")),
    }


def elements_to_asset_features(
    elements: list[dict],
    kinds: list[str],
    network_fc: dict | None = None,
) -> list[dict]:
    """Convert raw Overpass elements to GeoJSON asset Feature dicts.

    Each element is classified via :func:`classify_element`; elements that match
    none of the requested *kinds* are skipped.  Most features are emitted as
    ``Point`` features, but refuge footways are emitted as ``Polygon`` features,
    and linear paths remain as ``LineString``.

    Special handling for domain-specific kinds:
    - refugeAreaCrossing: node-based crossing refuge islands
    - refugeAreaFootway: way-based footway/cycleway traffic islands
    - refugeAreaTraffic: way/node-based traffic-calming islands
    - stoppingLane: way-based stopping lanes (turn:lanes)
    - laneMarkArrow: way-based lane mark arrows (turn:lanes)

    When *network_fc* is supplied, every point-based asset is spatially matched
    to the nearest network link and receives ``linkId`` / ``nodeId`` properties.

    Parameters
    ----------
    elements:
        Overpass elements.
    kinds:
        Requested asset kinds.
    network_fc:
        Optional network GeoJSON for ``linkId`` / ``nodeId`` matching of all
        point-based assets.
    """
    from osm_asset_fetcher.core.domain.geometry_matching import (
        match_features_to_network,
    )
    from osm_asset_fetcher.core.domain.lane_mark_arrows import (
        lane_mark_arrows_to_features,
    )
    from osm_asset_fetcher.core.domain.refuge_crossing import (
        crossing_refuge_features,
    )
    from osm_asset_fetcher.core.domain.refuge_footway import (
        footway_refuge_features,
    )
    from osm_asset_fetcher.core.domain.refuge_traffic import (
        traffic_refuge_features,
    )
    from osm_asset_fetcher.core.domain.stopping_lanes import (
        stopping_lanes_to_features,
    )

    features: list[dict] = []

    # Process special kinds via domain modules.
    if KIND_REFUGE_CROSSING in kinds:
        crossing_features = crossing_refuge_features(elements)
        features.extend(crossing_features)

    if KIND_REFUGE_FOOTWAY in kinds:
        footway_features = footway_refuge_features(elements)
        features.extend(footway_features)

    if KIND_REFUGE_TRAFFIC in kinds:
        traffic_features = traffic_refuge_features(elements)
        features.extend(traffic_features)

    if KIND_STOPPING_LANE in kinds:
        stopping_features = stopping_lanes_to_features(elements, network_fc=network_fc)
        features.extend(stopping_features)

    if KIND_LANE_MARK_ARROW in kinds:
        features.extend(lane_mark_arrows_to_features(elements, network_fc=network_fc))

    # Process generic kinds (existing node/way logic).
    generic_kinds = [k for k in kinds if k not in _SPECIAL_KINDS]

    for elem in elements:
        etype = elem.get("type")
        tags = elem.get("tags") or {}
        asset_type = classify_element(tags, generic_kinds)
        if asset_type is None:
            continue
        if etype == "way" and asset_type in _LINE_KINDS:
            line = _way_linestring(elem.get("geometry") or [])
            if line is None:
                continue
            props = {
                **tags,
                "osm_id": elem.get("id"),
                "assetType": asset_type,
                **_path_attributes(tags),
            }
            features.append(
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": line},
                    "properties": props,
                }
            )
            continue
        if etype == "node":
            lat = elem.get("lat")
            lon = elem.get("lon")
            if lat is None or lon is None:
                continue
            coords = [lon, lat]
        elif etype == "way" and asset_type in _WAY_KINDS:
            centroid = _way_centroid(elem.get("geometry") or [])
            if centroid is None:
                continue
            coords = [centroid[0], centroid[1]]
        else:
            continue
        props = {
            **tags,
            "osm_id": elem.get("id"),
            "assetType": asset_type,
            "linkId": None,
            "nodeId": None,
        }
        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": coords},
                "properties": props,
            }
        )

    # Match all point-based generic assets to the network when available.
    point_asset_types = set(generic_kinds) - _LINE_KINDS - _WAY_KINDS
    if network_fc is not None and point_asset_types:
        point_features = [
            f
            for f in features
            if (f.get("geometry") or {}).get("type") in ("Point", "LineString")
            and (f.get("properties") or {}).get("assetType") in point_asset_types
        ]
        point_features = match_features_to_network(point_features, network_fc)

    return features


# ---------------------------------------------------------------------------
# High-level entry point
# ---------------------------------------------------------------------------


def fetch_osm_assets(
    bbox: list[float],
    *,
    kinds: list[str] | None = None,
    tiles: int = OVERPASS_GRID,
    timeout: int = 40,
    osm_path: str | None = None,
    osm_workers: int | None = None,
    network_fc: dict | None = None,
) -> tuple[dict, dict]:
    """Fetch OSM traffic objects for *bbox* via the shared Overpass client.

    Uses the repository's shared :mod:`shared.overpass` client, which provides
    on-disk caching, retries and rate-limit handling.  The bbox is split into a
    ``tiles x tiles`` grid to keep individual requests small.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    kinds:
        The assetType kinds to fetch.  Defaults to :data:`DEFAULT_KINDS`.
    tiles:
        NxN Overpass tile grid.
    timeout:
        Overpass HTTP + server-side timeout in seconds.
    network_fc:
        Optional network FeatureCollection for linkId/nodeId matching of all
        point-based assets, and for network enrichment via
        :func:`enrich_network_with_osm_assets`.

    Returns
    -------
    fc:
        A GeoJSON ``FeatureCollection`` of OSM traffic-object features,
        each tagged ``properties.assetType``.
    stats:
        ``{"counts": dict[str, int], "total": int, "source": str}``.  ``counts``
        maps each assetType to the number of features produced.
    """
    from shared.overpass import fetch_overpass_tiled

    active_kinds = list(kinds) if kinds is not None else list(DEFAULT_KINDS)

    if not active_kinds:
        logger.info("No OSM asset kinds requested — skipping fetch.")
        return (
            {
                "type": "FeatureCollection",
                "features": [],
                "properties": {"_qv": OSM_ASSET_QUERY_VER, "source": "skipped"},
            },
            {"counts": {}, "total": 0, "source": "skipped"},
        )

    logger.info("Fetching OSM assets %s from Overpass (tiles=%dx%d).", active_kinds, tiles, tiles)
    response = fetch_overpass_tiled(
        lambda b: overpass_query_for_bbox(b, active_kinds, timeout=timeout),
        bbox,
        tiles=(tiles, tiles),
        timeout=timeout,
        osm_path=osm_path,
        osm_workers=osm_workers,
    )
    features = elements_to_asset_features(
        response.get("elements") or [],
        active_kinds,
        network_fc=network_fc,
    )

    counts: dict[str, int] = dict.fromkeys(active_kinds, 0)
    for feat in features:
        counts[feat["properties"]["assetType"]] += 1

    logger.info("Fetched %d OSM asset features (counts=%s).", len(features), counts)
    fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "_qv": OSM_ASSET_QUERY_VER,
            "source": "OSM",
            "_elements": response.get("elements") or [],
        },
    }

    if network_fc is not None:
        from osm_asset_fetcher.core.domain.network_enrichment import (
            enrich_network_with_osm_assets,
        )

        network_fc = enrich_network_with_osm_assets(network_fc, features)

        # Speed-layer extras: derived cycle crossings and POI-area columns.
        elements = response.get("elements") or []
        poi_features = extract_poi_features(elements)
        built_up_features = extract_built_up_features(elements)
        network_fc = enrich_network_with_pois_and_crossings(
            network_fc,
            asset_features=features,
            poi_features=poi_features,
            built_up_features=built_up_features,
        )

    stats = {"counts": counts, "total": len(features), "source": "OSM"}
    return fc, stats
