"""Building classification into simplified categories.

Maps OSM tags to one of six building types:
  school | house | hospital | recreational | shopping | other

Public API
----------
classify_building(tags) -> str
    Return the building type for a dict of OSM tags.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# building= tag sets
# ---------------------------------------------------------------------------

_SCHOOL_BUILDING: frozenset[str] = frozenset(
    {
        "school",
        "university",
        "college",
        "kindergarten",
    }
)

_HOUSE_BUILDING: frozenset[str] = frozenset(
    {
        "house",
        "residential",
        "apartments",
        "detached",
        "terrace",
        "semi_detached",
        "bungalow",
        "dormitory",
        "block_of_flats",
        "static_caravan",
        "cabin",
    }
)

_HOSPITAL_BUILDING: frozenset[str] = frozenset(
    {
        "hospital",
        "clinic",
    }
)

_RECREATIONAL_BUILDING: frozenset[str] = frozenset(
    {
        "sports_hall",
        "stadium",
        "sports_centre",
        "grandstand",
        "pavilion",
        "riding_hall",
        "swimming_pool",
        "gym",
    }
)

_SHOPPING_BUILDING: frozenset[str] = frozenset(
    {
        "retail",
        "supermarket",
        "shop",
        "kiosk",
        "commercial",
        "mall",
    }
)

# ---------------------------------------------------------------------------
# amenity= tag sets
# ---------------------------------------------------------------------------

_SCHOOL_AMENITY: frozenset[str] = frozenset(
    {
        "school",
        "university",
        "college",
        "kindergarten",
        "language_school",
        "driving_school",
        "music_school",
    }
)

_HOSPITAL_AMENITY: frozenset[str] = frozenset(
    {
        "hospital",
        "clinic",
        "doctors",
        "dentist",
        "pharmacy",
        "nursing_home",
        "social_facility",
    }
)

_RECREATIONAL_AMENITY: frozenset[str] = frozenset(
    {
        "theatre",
        "cinema",
        "arts_centre",
        "community_centre",
        "social_centre",
        "nightclub",
        "bar",
        "pub",
        "restaurant",
        "cafe",
        "fast_food",
        "stadium",
        "sports_centre",
        "swimming_pool",
    }
)

_SHOPPING_AMENITY: frozenset[str] = frozenset(
    {
        "marketplace",
        "car_wash",
        "fuel",
    }
)

# ---------------------------------------------------------------------------
# leisure= tag set
# ---------------------------------------------------------------------------

_RECREATIONAL_LEISURE: frozenset[str] = frozenset(
    {
        "sports_centre",
        "stadium",
        "swimming_pool",
        "fitness_centre",
        "dance",
        "horse_riding",
        "ice_rink",
        "pitch",
        "track",
        "recreation_ground",
        "theatre",
        "bowling_alley",
    }
)

# ---------------------------------------------------------------------------
# shop= — any non-empty shop tag → shopping
# ---------------------------------------------------------------------------


def classify_building(tags: dict[str, str]) -> str:
    """Classify a building based on its OSM tags.

    Checks in priority order:
    1. ``building=`` tag
    2. ``amenity=`` tag
    3. ``shop=`` tag (any value → shopping)
    4. ``leisure=`` tag

    Parameters
    ----------
    tags:
        Dict of OSM tag key/value pairs for the element.

    Returns
    -------
    str
        One of ``'school'``, ``'house'``, ``'hospital'``,
        ``'recreational'``, ``'shopping'``, ``'other'``.
    """
    building = tags.get("building", "").strip().lower()
    amenity = tags.get("amenity", "").strip().lower()
    shop = tags.get("shop", "").strip().lower()
    leisure = tags.get("leisure", "").strip().lower()

    # --- building= priority ---
    if building in _SCHOOL_BUILDING:
        return "school"
    if building in _HOSPITAL_BUILDING:
        return "hospital"
    if building in _RECREATIONAL_BUILDING:
        return "recreational"
    if building in _SHOPPING_BUILDING:
        return "shopping"
    if building in _HOUSE_BUILDING:
        return "house"

    # --- amenity= fallback ---
    if amenity in _SCHOOL_AMENITY:
        return "school"
    if amenity in _HOSPITAL_AMENITY:
        return "hospital"
    if amenity in _RECREATIONAL_AMENITY:
        return "recreational"
    if amenity in _SHOPPING_AMENITY:
        return "shopping"

    # --- shop= fallback (any value) ---
    if shop:
        return "shopping"

    # --- leisure= fallback ---
    if leisure in _RECREATIONAL_LEISURE:
        return "recreational"

    return "other"
