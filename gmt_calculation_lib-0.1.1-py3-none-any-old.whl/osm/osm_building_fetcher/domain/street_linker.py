"""Link buildings to streets using street-name matching or nearest-street lookup.

Strategy per building
---------------------
1. If the building has an ``addr:street`` tag and a street with that name
   exists in the street list → use that street (exact, case-insensitive match).
2. Otherwise → find the nearest street centroid using ``shared.kd_tree.KDTree2D``
   (or a linear search when numpy is unavailable).

Public API
----------
link_buildings_to_streets(buildings, streets) -> list[tuple[str | None, str | None]]
    Return ``(street_name, street_id)`` for every building (same order).
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _street_midpoints(
    streets: list[dict],
) -> list[tuple[float, float, str, str]]:
    """Return ``(lon, lat, name, street_id)`` for the mid-point of each street way."""
    result: list[tuple[float, float, str, str]] = []
    for el in streets:
        geom: list[dict] = el.get("geometry") or []
        if not geom:
            continue
        mid = geom[len(geom) // 2]
        name: str = (el.get("tags") or {}).get("name", "")
        result.append((float(mid["lon"]), float(mid["lat"]), name, f"osm_{el['id']}"))
    return result


def _building_centroid(element: dict) -> tuple[float, float] | None:
    """Return ``(lon, lat)`` centroid of a building element."""
    if element.get("type") == "node":
        lon = element.get("lon")
        lat = element.get("lat")
        if lon is None or lat is None:
            return None
        return float(lon), float(lat)
    geom: list[dict] = element.get("geometry") or []
    if not geom:
        return None
    lons = [float(p["lon"]) for p in geom]
    lats = [float(p["lat"]) for p in geom]
    return sum(lons) / len(lons), sum(lats) / len(lats)


def _nearest_linear(
    blon: float,
    blat: float,
    midpoints: list[tuple[float, float, str, str]],
) -> tuple[str | None, str | None]:
    """Return ``(name, street_id)`` of the nearest street using linear scan."""
    best_dist = math.inf
    best: tuple[str | None, str | None] = (None, None)
    for slon, slat, sname, sid in midpoints:
        dist = (slon - blon) ** 2 + (slat - blat) ** 2
        if dist < best_dist:
            best_dist = dist
            best = (sname or None, sid)
    return best


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def link_buildings_to_streets(
    buildings: list[dict],
    streets: list[dict],
) -> list[tuple[str | None, str | None]]:
    """Link each building to a street; return ``(street_name, street_id)`` per building.

    Parameters
    ----------
    buildings:
        List of Overpass building elements (``way`` or ``node``).
    streets:
        List of Overpass street elements (``way`` with ``highway`` tag).

    Returns
    -------
    list[tuple[str | None, str | None]]
        One entry per building in the same order.  Each entry is
        ``(street_name, street_id)`` where ``street_id`` is ``"osm_{way_id}"``.
        Both values are ``None`` when no streets are available.
    """
    if not streets or not buildings:
        return [(None, None)] * len(buildings)

    # Build name → (display_name, street_id) lookup (case-insensitive key)
    name_lookup: dict[str, tuple[str, str]] = {}
    for el in streets:
        name: str = (el.get("tags") or {}).get("name", "").strip()
        if name:
            name_lookup[name.lower()] = (name, f"osm_{el['id']}")

    midpoints = _street_midpoints(streets)

    # Try to build a KD-tree for fast nearest-street lookup
    _tree = None
    try:
        import numpy as np  # noqa: PLC0415
        from shared.kd_tree import KDTree2D  # noqa: PLC0415

        if midpoints:
            pts = np.array([[m[0], m[1]] for m in midpoints], dtype=float)
            _tree = KDTree2D(pts)
    except Exception:
        logger.debug("KDTree2D unavailable — falling back to linear nearest-street search")

    results: list[tuple[str | None, str | None]] = []

    for building in buildings:
        tags: dict[str, str] = building.get("tags") or {}
        addr_street = tags.get("addr:street", "").strip()

        # 1. Street-name match
        if addr_street and addr_street.lower() in name_lookup:
            display_name, sid = name_lookup[addr_street.lower()]
            results.append((display_name, sid))
            continue

        # 2. Nearest street
        centroid = _building_centroid(building)
        if centroid is None:
            results.append((addr_street or None, None))
            continue

        blon, blat = centroid

        if _tree is not None and midpoints:
            try:
                import numpy as np  # noqa: PLC0415

                dists, idxs = _tree.query(np.array([blon, blat]), k=1)
                idx = int(idxs[0] if hasattr(idxs, "__len__") else idxs)
                _, _, sname, sid = midpoints[idx]
                results.append((sname or addr_street or None, sid))
                continue
            except Exception:
                pass  # fall through to linear

        results.append(_nearest_linear(blon, blat, midpoints))

    return results
