"""Overpass QL query builders for the OSM building fetcher.

Public API
----------
build_buildings_and_streets_query(bbox, timeout) -> str
    Returns an Overpass QL query that fetches buildings (ways + nodes) and
    streets (ways with a highway tag) for the given bounding box.
"""

from __future__ import annotations

DEFAULT_TIMEOUT = 90


def build_buildings_and_streets_query(
    bbox: list[float],
    timeout: int = DEFAULT_TIMEOUT,
) -> str:
    """Build an Overpass QL query for buildings and streets in a bounding box.

    Parameters
    ----------
    bbox:
        [minLon, minLat, maxLon, maxLat]
    timeout:
        Overpass query timeout in seconds.

    Returns
    -------
    str
        Complete Overpass QL query string.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    bb = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    return (
        f"[out:json][timeout:{timeout}];\n"
        f"(\n"
        f'  way["building"]({bb});\n'
        f'  node["building"]({bb});\n'
        f'  way["highway"]({bb});\n'
        f");\n"
        f"out geom;\n"
    )
