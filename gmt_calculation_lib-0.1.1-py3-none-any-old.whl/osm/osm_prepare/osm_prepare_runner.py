"""Local debug runner for osm_prepare.

Runs the full OSM preparation pipeline for CAR mode entirely in-process:

    osm_building_fetcher → building_zone_creator → zone_population_estimator
    osm_network_fetcher  → network_simplifier → network_cleaner
                        → bidirectional_splitter → parallel_link_finder
    osm_feedlink_creator
    matrix_builder

Usage
-----
    python -m osm.osm_prepare.osm_prepare_runner \\
        --bbox 6.15 51.95 6.25 52.00 \\
        --output-folder ./output/

    # with optional overrides:
    python -m osm.osm_prepare.osm_prepare_runner \\
        --bbox 6.15 51.95 6.25 52.00 \\
        --output-folder ./output/ \\
        --area-id my-area \\
        --target-footprint-m2 3000 \\
        --max-routes 3 \\
        --overpass-url https://my-private-overpass/api/interpreter \\
        --overpass-timeout 120 \\
        --refresh \\
        --debug

Output (in --output-folder)
---------------------------
    {area_id}-NETWORK-CAR.parquet
    {area_id}-FEEDLINK-CAR.parquet
    {area_id}-ZONE-CAR.parquet
    {area_id}-ROUTES-CAR.parquet

    When --debug is given, intermediate GeoJSON snapshots are also written.

Prerequisites
-------------
* AWS credentials available in the environment or a tools/.env file (only
  needed for s3:// URIs).
* shapely >= 2.0, pyarrow, geopandas installed.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for osm_prepare — runs the full OSM preparation pipeline "
            "for CAR mode and writes four GeoParquet outputs."
        )
    )
    parser.add_argument(
        "--bbox",
        required=True,
        nargs=4,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        type=float,
        help="Bounding box in decimal degrees (WGS-84).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="DIR",
        help="Local output directory.  Created automatically when missing.",
    )
    parser.add_argument(
        "--area-id",
        default=None,
        help=(
            "Area identifier used in output filenames.  "
            "Auto-discovered from existing parquet files or generated as uuid4()."
        ),
    )
    parser.add_argument(
        "--target-footprint-m2",
        type=float,
        default=5000.0,
        help="Target total building footprint per zone in m² (default: 5000).",
    )
    parser.add_argument(
        "--max-routes",
        type=int,
        default=2,
        help="Maximum k-shortest routes per OD pair (default: 2).",
    )
    parser.add_argument(
        "--overpass-url",
        default=None,
        help=(
            "Overpass API endpoint URL. "
            "Defaults to the OVERPASS_URL environment variable, "
            "or https://overpass-api.de/api/interpreter."
        ),
    )
    parser.add_argument(
        "--overpass-timeout",
        type=int,
        default=90,
        help="HTTP timeout in seconds for every Overpass request (default: 90).",
    )
    parser.add_argument(
        "--no-ssl-verify",
        action="store_true",
        help=(
            "Disable SSL certificate verification for GISCO and Eurostat requests. "
            "Use this when behind a corporate proxy that intercepts HTTPS. "
            "Equivalent to setting SSL_VERIFY=false in the .env file."
        ),
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Re-run all steps even when the final output files already exist.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Write intermediate GeoJSON snapshots to --output-folder.",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env (auto-discover tools/.env if not specified)
    env_file_path: Path
    if args.env_file:
        env_file_path = Path(args.env_file)
    else:
        env_file_path = Path(__file__).resolve().parent.parent.parent.parent / "tools" / ".env"
    for k, v in _read_env_file(env_file_path).items():
        os.environ.setdefault(k, v)

    overpass_url: str = args.overpass_url or os.environ.get(
        "OVERPASS_URL", "https://overpass-api.de/api/interpreter"
    )

    # --no-ssl-verify flag takes precedence; falls back to SSL_VERIFY env var.
    if args.no_ssl_verify:
        os.environ["SSL_VERIFY"] = "false"

    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
        level=logging.INFO,
    )

    from osm.osm_prepare.core.osm_prepare_core import run_pipeline  # noqa: PLC0415

    min_lon, min_lat, max_lon, max_lat = args.bbox
    out_dir = Path(args.output_folder).resolve()

    area_id = run_pipeline(
        min_lon,
        min_lat,
        max_lon,
        max_lat,
        out_dir,
        area_id=args.area_id,
        target_footprint_m2=args.target_footprint_m2,
        max_routes=args.max_routes,
        overpass_url=overpass_url,
        overpass_timeout=args.overpass_timeout,
        refresh=args.refresh,
        debug=args.debug,
    )

    print()
    print(f"Area ID: {area_id}")
    print("Done.")


if __name__ == "__main__":
    main()
