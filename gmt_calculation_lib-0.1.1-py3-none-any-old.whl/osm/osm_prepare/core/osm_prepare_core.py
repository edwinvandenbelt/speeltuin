"""
osm_prepare_core.py — OSM preparation pipeline orchestration.

Runs the full OSM pipeline for CAR mode entirely in-process.  Replaces
the Databricks-backed ``prepare`` pipeline with OSM/Overpass equivalents:

    zone_fetcher        →  osm_building_fetcher + building_zone_creator
                           + zone_population_estimator
    network_fetcher     →  osm_network_fetcher
    feedlink_fetcher    →  osm_feedlink_creator

Steps that do not depend on Databricks are reused unchanged:
    network_simplifier, network_cleaner, bidirectional_splitter,
    parallel_link_finder, matrix_builder.

Skipped steps (not applicable to the OSM pipeline):
    network_fuser       — only needed for multi-mode networks
    network_zone_joiner — expects Databricks-style AREA/STUDY/INFLUENCE
                          zone hierarchy; OSM zones are building polygons
    nvp_mapper          — Databricks-dependent

Pipeline execution
------------------
Two independent tracks run in parallel inside a ThreadPoolExecutor:

  Track A  osm_building_fetcher → building_zone_creator
                               → zone_population_estimator
  Track B  osm_network_fetcher → network_simplifier → network_cleaner
                               → bidirectional_splitter
                               → parallel_link_finder

After both tracks complete, feedlinks and the OD matrix are built
sequentially:

  osm_feedlink_creator(directed_network, zones)
  matrix_builder(directed_network, feedlinks, zones)

Note on Overpass rate limits
----------------------------
The pipeline issues up to three concurrent Overpass HTTP requests:
  • osm_building_fetcher (buildings + streets for block construction)
  • building_zone_creator (streets for city-block polygonisation)
  • osm_network_fetcher (road links)

For large bounding boxes or high-frequency runs, use a private Overpass
instance via the ``overpass_url`` parameter.

Final outputs
-------------
    {area_id}-NETWORK-CAR.parquet
    {area_id}-FEEDLINK-CAR.parquet
    {area_id}-ZONE-CAR.parquet
    {area_id}-ROUTES-CAR.parquet

Public API
----------
run_pipeline(min_lon, min_lat, max_lon, max_lat, out_dir, **kwargs) -> str
    Run the full pipeline and return the area UUID.
"""

from __future__ import annotations

import concurrent.futures
import json
import uuid
from pathlib import Path

from shared.geoparquet import to_geoparquet
from shared.overpass import DEFAULT_OVERPASS_URL

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_TARGET_FOOTPRINT_M2 = 5000.0
DEFAULT_MAX_ROUTES = 2
DEFAULT_OVERPASS_TIMEOUT = 90

# Product-type markers used to discover an existing area UUID from the
# output directory (identical to prepare_core._ID_MARKERS).
_ID_MARKERS = (
    "-NETWORK-",
    "-ROUTES-",
    "-ZONE-",
    "-FEEDLINK-",
)

# ---------------------------------------------------------------------------
# Area-ID helpers
# ---------------------------------------------------------------------------


def _discover_or_create_area_id(out_dir: Path, area_id: str | None = None) -> str:
    """Return the area UUID for *out_dir*.

    Priority
    --------
    1. Explicit *area_id* override.
    2. UUID prefix extracted from the first matching ``.parquet`` file in
       *out_dir* (re-run of an existing area).
    3. Fresh :func:`uuid.uuid4` (first run / empty directory).
    """
    if area_id:
        return area_id
    for f in sorted(out_dir.glob("*.parquet")):
        stem = f.stem
        for marker in _ID_MARKERS:
            idx = stem.find(marker)
            if idx > 0:
                return stem[:idx]
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Debug snapshot helper
# ---------------------------------------------------------------------------


def _snapshot(step_num: int, area_id: str, out_dir: Path, **named_fcs: dict) -> None:
    """Write named in-memory FeatureCollections to debug GeoJSON snapshots.

    Files are named ``STEP_{n}_{area_id}_{PRODUCT}.geojson`` and written to
    *out_dir*.  Only called when ``debug=True``.
    """
    for product, fc in named_fcs.items():
        if fc is None:
            print(f"  [debug] snapshot skipped — {product} is None")
            continue
        dst = out_dir / f"STEP_{step_num}_{area_id}_{product}.geojson"
        dst.write_text(json.dumps(fc, ensure_ascii=False), encoding="utf-8")
        n = len((fc.get("features") or []))
        print(f"  [debug] snapshot → {dst.name}  ({n} features)")


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


def run_pipeline(
    min_lon: float,
    min_lat: float,
    max_lon: float,
    max_lat: float,
    out_dir: Path,
    *,
    area_id: str | None = None,
    target_footprint_m2: float = DEFAULT_TARGET_FOOTPRINT_M2,
    max_routes: int = DEFAULT_MAX_ROUTES,
    overpass_url: str = DEFAULT_OVERPASS_URL,
    overpass_timeout: int = DEFAULT_OVERPASS_TIMEOUT,
    refresh: bool = False,
    debug: bool = False,
) -> str:
    """Run the full OSM preparation pipeline for CAR mode.

    Parameters
    ----------
    min_lon, min_lat, max_lon, max_lat:
        Bounding box in decimal degrees (WGS-84).
    out_dir:
        Output directory; created automatically when it does not exist.
    area_id:
        Optional UUID override.  When omitted the UUID is discovered from
        existing files in *out_dir*, or a fresh ``uuid4()`` is generated.
    target_footprint_m2:
        Target total building footprint per zone in m² (building_zone_creator).
        Default: 5000.
    max_routes:
        Maximum k-shortest routes per OD pair (matrix_builder).  Default: 2.
    overpass_url:
        Overpass API endpoint.  Use a private instance for large areas.
    overpass_timeout:
        HTTP timeout in seconds for every Overpass request.
    refresh:
        Re-run all steps even when the final output files already exist.
    debug:
        Write intermediate GeoJSON snapshots (``STEP_{n}_…``) to *out_dir*.

    Returns
    -------
    str
        The area UUID used for this run.
    """
    bbox = [min_lon, min_lat, max_lon, max_lat]
    out_dir.mkdir(parents=True, exist_ok=True)
    area_id = _discover_or_create_area_id(out_dir, area_id)

    # Final output paths.
    network_path = out_dir / f"{area_id}-NETWORK-CAR.parquet"
    feedlink_path = out_dir / f"{area_id}-FEEDLINK-CAR.parquet"
    zone_path = out_dir / f"{area_id}-ZONE-CAR.parquet"
    routes_path = out_dir / f"{area_id}-ROUTES-CAR.parquet"

    print()
    print("=" * 60)
    print(" OSM Prepare Pipeline")
    print(f" bbox       : {min_lon} {min_lat} {max_lon} {max_lat}")
    print(f" mode       : CAR")
    print(f" area-id    : {area_id}")
    print(f" out        : {out_dir}")
    print(f" refresh    : {'yes' if refresh else 'no'}")
    print(f" debug      : {'yes' if debug else 'no'}")
    print("=" * 60)

    # ------------------------------------------------------------------
    # Early exit: all final outputs exist and refresh=False
    # ------------------------------------------------------------------
    if not refresh and all(
        p.exists() for p in [network_path, feedlink_path, zone_path, routes_path]
    ):
        print()
        print("All final outputs already exist — skipping pipeline (use --refresh to force).")
        return area_id

    # ==================================================================
    # PARALLEL TRACKS A + B
    # ==================================================================

    def _run_track_a() -> tuple[dict, dict]:
        """Track A: buildings → zones → population.  Returns (zones_fc, a_stats)."""
        from osm.osm_building_fetcher.core.osm_building_fetcher_core import (  # noqa: PLC0415
            build_buildings,
        )
        from osm.building_zone_creator.core.building_zone_creator_core import (  # noqa: PLC0415
            create_zones,
        )
        from osm.zone_population_estimator.core.zone_population_estimator_core import (  # noqa: PLC0415
            estimate_zone_population,
        )

        # A1 — osm_building_fetcher
        print("[A1] osm_building_fetcher ...")
        buildings_fc, bld_stats = build_buildings(
            bbox,
            overpass_url=overpass_url,
            timeout=overpass_timeout,
        )
        print(f"  {bld_stats.get('buildings', 0)} buildings fetched")

        # A2 — building_zone_creator
        print("[A2] building_zone_creator ...")
        raw_zones_fc, zone_stats = create_zones(
            buildings_fc,
            bbox,
            area_id=area_id,
            overpass_url=overpass_url,
            overpass_timeout=overpass_timeout,
            target_footprint_m2=target_footprint_m2,
        )
        print(f"  {zone_stats.get('zones', len(raw_zones_fc.get('features') or []))} zones created")

        # A3 — zone_population_estimator
        print("[A3] zone_population_estimator ...")
        zones_fc, pop_stats = estimate_zone_population(raw_zones_fc, bbox)
        print(
            f"  population={pop_stats.get('totalPopulation', '?')}  "
            f"nutsCode={pop_stats.get('nutsCode', '?')}"
        )

        return zones_fc, raw_zones_fc

    def _run_track_b() -> dict:
        """Track B: network fetch → simplify → clean → split → parallel links.

        Returns the directed, enriched network FeatureCollection.
        """
        from osm.osm_network_fetcher.core.osm_network_fetcher_core import (  # noqa: PLC0415
            build_raw_network,
        )
        from network_simplifier.core.network_simplifier_core import (  # noqa: PLC0415
            simplify_network,
        )
        from network_cleaner.core.network_cleaner_core import clean_network  # noqa: PLC0415
        from bidirectional_splitter.core.bidirectional_splitter_core import (  # noqa: PLC0415
            post_process_features,
        )
        from parallel_link_finder.core.parallel_link_finder_core import (  # noqa: PLC0415
            find_parallel_links,
        )

        # B1 — osm_network_fetcher
        print("[B1] osm_network_fetcher (CAR) ...")
        raw_network_fc = build_raw_network(
            bbox,
            modes=["CAR"],
            overpass_url=overpass_url,
            timeout=overpass_timeout,
        )
        print(f"  {len(raw_network_fc.get('features') or []):,} raw links fetched")

        # B2 — network_simplifier
        print("[B2] network_simplifier ...")
        simplified_fc, simp_stats = simplify_network(raw_network_fc)
        print(
            f"  {simp_stats.get('final_links', '?')} links "
            f"(removed {simp_stats.get('removed_nodes', '?')} pass-through nodes)"
        )

        # B3 — network_cleaner
        print("[B3] network_cleaner ...")
        cleaned_fc, clean_stats = clean_network(simplified_fc)
        print(f"  {clean_stats.get('kept', '?')} kept, {clean_stats.get('removed', '?')} removed")

        # B4 — bidirectional_splitter
        print("[B4] bidirectional_splitter ...")
        directed_features = post_process_features(cleaned_fc.get("features") or [])
        directed_fc: dict = {
            "type": "FeatureCollection",
            "features": directed_features,
            "properties": {
                **(cleaned_fc.get("properties") or {}),
                "bbox": bbox,
                "area_id": area_id,
                "modes": ["CAR"],
                "modeLabel": "CAR",
            },
        }
        print(f"  {len(directed_features):,} directed links after split")

        # B5 — parallel_link_finder
        print("[B5] parallel_link_finder ...")
        enriched_fc, parallel_stats = find_parallel_links(directed_fc)
        print(
            f"  enriched={parallel_stats.get('features_enriched', '?')}  "
            f"skipped={parallel_stats.get('features_skipped', '?')}"
        )

        return enriched_fc

    print()
    print("[parallel] tracks A (zones) and B (network) ...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        future_a = pool.submit(_run_track_a)
        future_b = pool.submit(_run_track_b)

    zones_fc, raw_zones_fc = future_a.result()
    network_fc = future_b.result()

    n_zones = len(zones_fc.get("features") or [])
    n_network = len(network_fc.get("features") or [])
    print(f"  Track A complete: {n_zones} zones")
    print(f"  Track B complete: {n_network:,} directed network links")

    if debug:
        _snapshot(3, area_id, out_dir, ZONES=zones_fc)
        _snapshot(8, area_id, out_dir, NETWORK=network_fc)

    # ==================================================================
    # C — osm_feedlink_creator
    # ==================================================================
    print()
    print("[C] osm_feedlink_creator ...")

    from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (  # noqa: PLC0415
        create_feedlinks,
    )

    feedlinks_fc, fl_stats = create_feedlinks(network_fc, zones_fc)
    print(
        f"  {fl_stats['total']} feedlinks "
        f"({fl_stats['zonesMatched']} matched inside, "
        f"{fl_stats['zonesFallback']} fallback)"
    )

    if debug:
        _snapshot(9, area_id, out_dir, FEEDLINKS=feedlinks_fc)

    # ==================================================================
    # D — matrix_builder
    # ==================================================================
    print()
    print("[D] matrix_builder ...")

    from matrix_builder.core.matrix_builder_core import build_matrix  # noqa: PLC0415

    routes_fc = build_matrix(network_fc, feedlinks_fc, zones_fc, max_routes=max_routes)
    n_routes = len(routes_fc.get("features") or [])
    print(f"  {n_routes:,} route features built")

    if debug:
        _snapshot(10, area_id, out_dir, ROUTES=routes_fc)

    # ==================================================================
    # Write final outputs
    # ==================================================================
    network_path.write_bytes(to_geoparquet(network_fc))
    feedlink_path.write_bytes(to_geoparquet(feedlinks_fc))
    zone_path.write_bytes(to_geoparquet(zones_fc))
    routes_path.write_bytes(to_geoparquet(routes_fc))

    print()
    print("=" * 60)
    print(" OSM Pipeline complete.")
    print(f" Network  : {network_path}")
    print(f" Feedlinks: {feedlink_path}")
    print(f" Zones    : {zone_path}")
    print(f" Routes   : {routes_path}")
    print("=" * 60)

    return area_id
