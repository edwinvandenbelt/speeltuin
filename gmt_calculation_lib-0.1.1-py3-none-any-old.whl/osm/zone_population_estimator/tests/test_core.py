"""Tests for zone_population_estimator domain modules and core.

Covers:
- gisco.find_nuts — parses NUTS code and level, raises on empty response
- gisco.reverse_geocode — parses name, returns empty dict on failure
- eurostat.fetch_population — parses SDMX JSON, picks most recent year,
  NUTS fallback, raises when no data at any level
- distributor.distribute_population — proportional, equal fallback, empty FC
- attraction.compute_attraction — default factors, custom factors, unknown type,
  house contributes zero
- estimate_zone_population (integration) — all external calls mocked
"""

from __future__ import annotations

import json
from unittest.mock import MagicMock, patch

import pytest

from osm.zone_population_estimator.domain.attraction import (
    DEFAULT_ATTRACTION_FACTORS,
    compute_attraction,
)
from osm.zone_population_estimator.domain.distributor import distribute_population


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _zone_feature(zone_id: str, building_types: dict) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 0]]]},
        "properties": {
            "zoneId": zone_id,
            "buildingTypes": building_types,
            "nBuildings": 5,
            "totalFootprintM2": sum(building_types.values()),
        },
    }


def _zones_fc(*zones) -> dict:
    return {"type": "FeatureCollection", "features": list(zones)}


def _gisco_nuts_response(nuts_code: str = "NL212", level: int = 3) -> bytes:
    return json.dumps([{"attributes": {"id": nuts_code, "stat_levl_code": level}}]).encode()


def _gisco_nominatim_response(name: str = "Deventer") -> bytes:
    return json.dumps({"name": name, "display_name": f"{name}, Netherlands"}).encode()


def _eurostat_response(pop: float, year: int = 2024) -> bytes:
    """Build a minimal Eurostat SDMX JSON response."""
    # time index: {"2020": 0, "2021": 1, ..., year: N}
    start_year = 2020
    years = list(range(start_year, year + 1))
    time_index = {str(y): i for i, y in enumerate(years)}
    latest_pos = len(years) - 1
    return json.dumps(
        {
            "value": {str(latest_pos): pop},
            "dimension": {
                "time": {
                    "category": {
                        "index": time_index,
                        "label": {str(y): str(y) for y in years},
                    }
                }
            },
        }
    ).encode()


# ---------------------------------------------------------------------------
# gisco.find_nuts
# ---------------------------------------------------------------------------


class TestFindNuts:
    def _call(self, response_bytes: bytes) -> dict:
        from osm.zone_population_estimator.domain.gisco import find_nuts  # noqa: PLC0415

        mock_resp = MagicMock()
        mock_resp.read.return_value = response_bytes
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            return find_nuts(6.16, 52.26)

    def test_returns_nuts_code(self) -> None:
        result = self._call(_gisco_nuts_response("NL212", 3))
        assert result["nuts_code"] == "NL212"

    def test_returns_nuts_level(self) -> None:
        result = self._call(_gisco_nuts_response("NL212", 3))
        assert result["nuts_level"] == 3

    def test_picks_highest_level_from_multiple(self) -> None:
        response = json.dumps(
            [
                {"attributes": {"id": "NL2", "stat_levl_code": 2}},
                {"attributes": {"id": "NL21", "stat_levl_code": 3}},
            ]
        ).encode()
        result = self._call(response)
        assert result["nuts_code"] == "NL21"

    def test_raises_on_empty_response(self) -> None:
        from osm.zone_population_estimator.domain.gisco import find_nuts  # noqa: PLC0415

        mock_resp = MagicMock()
        mock_resp.read.return_value = b"[]"
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            with pytest.raises(ValueError, match="no NUTS region"):
                find_nuts(0.0, 0.0)


# ---------------------------------------------------------------------------
# gisco.reverse_geocode
# ---------------------------------------------------------------------------


class TestReverseGeocode:
    def _call(self, response_bytes: bytes | None = None) -> dict:
        from osm.zone_population_estimator.domain.gisco import reverse_geocode  # noqa: PLC0415

        if response_bytes is None:
            # Simulate network failure
            with patch("urllib.request.urlopen", side_effect=OSError("timeout")):
                return reverse_geocode(6.16, 52.26)
        mock_resp = MagicMock()
        mock_resp.read.return_value = response_bytes
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            return reverse_geocode(6.16, 52.26)

    def test_returns_name(self) -> None:
        result = self._call(_gisco_nominatim_response("Deventer"))
        assert result["name"] == "Deventer"

    def test_returns_display_name(self) -> None:
        result = self._call(_gisco_nominatim_response("Deventer"))
        assert "Deventer" in result["display_name"]

    def test_returns_empty_dict_on_failure(self) -> None:
        result = self._call(None)
        assert result["name"] == ""
        assert result["display_name"] == ""


# ---------------------------------------------------------------------------
# eurostat.fetch_population
# ---------------------------------------------------------------------------


class TestFetchPopulation:
    def _urlopen(self, response_bytes: bytes):
        mock_resp = MagicMock()
        mock_resp.read.return_value = response_bytes
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        return mock_resp

    def test_returns_population(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import fetch_population  # noqa: PLC0415

        with patch(
            "urllib.request.urlopen", return_value=self._urlopen(_eurostat_response(161927.0, 2024))
        ):
            result = fetch_population("NL212")
        assert result["population"] == pytest.approx(161927.0)

    def test_returns_most_recent_year(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import fetch_population  # noqa: PLC0415

        with patch(
            "urllib.request.urlopen", return_value=self._urlopen(_eurostat_response(161927.0, 2024))
        ):
            result = fetch_population("NL212")
        assert result["year"] == 2024

    def test_returns_nuts_code(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import fetch_population  # noqa: PLC0415

        with patch(
            "urllib.request.urlopen", return_value=self._urlopen(_eurostat_response(161927.0, 2024))
        ):
            result = fetch_population("NL212")
        assert result["nuts_code"] == "NL212"

    def test_nuts_fallback_on_empty_value(self) -> None:
        """When NL212 has no values, fall back to NL21 (shorter code)."""
        from osm.zone_population_estimator.domain.eurostat import fetch_population  # noqa: PLC0415

        empty_response = json.dumps(
            {
                "value": {},
                "dimension": {
                    "time": {"category": {"index": {"2024": 0}, "label": {"2024": "2024"}}}
                },
            }
        ).encode()
        full_response = _eurostat_response(500000.0, 2024)

        responses = [empty_response, full_response]
        idx = [0]

        def side_effect(*_args, **_kwargs):
            resp = MagicMock()
            resp.read.return_value = responses[idx[0]]
            resp.__enter__ = lambda s: s
            resp.__exit__ = MagicMock(return_value=False)
            idx[0] += 1
            return resp

        with patch("urllib.request.urlopen", side_effect=side_effect):
            result = fetch_population("NL212")
        # Should have fallen back to NL21 (4-char code)
        assert result["population"] == pytest.approx(500000.0)
        assert result["nuts_code"] == "NL21"

    def test_raises_when_no_data_at_any_level(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import fetch_population  # noqa: PLC0415

        empty = json.dumps(
            {
                "value": {},
                "dimension": {"time": {"category": {"index": {}, "label": {}}}},
            }
        ).encode()
        mock_resp = MagicMock()
        mock_resp.read.return_value = empty
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            with pytest.raises(ValueError, match="No population data"):
                fetch_population("XX")


# ---------------------------------------------------------------------------
# distributor.distribute_population
# ---------------------------------------------------------------------------


class TestDistributePopulation:
    def test_proportional_to_house_m2(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"house": 200.0}),
            _zone_feature("z2", {"house": 800.0}),
        )
        result = distribute_population(zones_fc, 1000.0)
        assert result["z1"] == pytest.approx(200.0, rel=1e-3)
        assert result["z2"] == pytest.approx(800.0, rel=1e-3)

    def test_sum_equals_total_population(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"house": 300.0, "shopping": 100.0}),
            _zone_feature("z2", {"house": 700.0}),
        )
        result = distribute_population(zones_fc, 50000.0)
        assert sum(result.values()) == pytest.approx(50000.0, rel=1e-3)

    def test_zone_without_house_gets_zero(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"house": 500.0}),
            _zone_feature("z2", {"shopping": 200.0}),
        )
        result = distribute_population(zones_fc, 1000.0)
        assert result["z2"] == pytest.approx(0.0)

    def test_all_zones_no_house_equal_distribution(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"shopping": 100.0}),
            _zone_feature("z2", {"school": 200.0}),
        )
        result = distribute_population(zones_fc, 1000.0)
        assert result["z1"] == pytest.approx(500.0, rel=1e-3)
        assert result["z2"] == pytest.approx(500.0, rel=1e-3)

    def test_zero_population_gives_zeros(self) -> None:
        zones_fc = _zones_fc(_zone_feature("z1", {"house": 100.0}))
        result = distribute_population(zones_fc, 0.0)
        assert result["z1"] == 0.0

    def test_empty_fc_returns_empty(self) -> None:
        result = distribute_population({"type": "FeatureCollection", "features": []}, 1000.0)
        assert result == {}

    def test_single_zone_gets_all_population(self) -> None:
        zones_fc = _zones_fc(_zone_feature("z1", {"house": 500.0}))
        result = distribute_population(zones_fc, 9999.0)
        assert result["z1"] == pytest.approx(9999.0, rel=1e-3)


# ---------------------------------------------------------------------------
# attraction.compute_attraction
# ---------------------------------------------------------------------------


class TestComputeAttraction:
    def test_shopping_uses_default_factor(self) -> None:
        total, by_type = compute_attraction({"shopping": 100.0})
        assert total == pytest.approx(100.0 * DEFAULT_ATTRACTION_FACTORS["shopping"])
        assert "shopping" in by_type

    def test_house_contributes_zero(self) -> None:
        total, by_type = compute_attraction({"house": 1000.0})
        assert total == pytest.approx(0.0)
        assert "house" not in by_type  # zero entries omitted

    def test_custom_factor_overrides_default(self) -> None:
        total, _ = compute_attraction({"shopping": 100.0}, factors={"shopping": 0.20})
        assert total == pytest.approx(20.0)

    def test_unknown_type_uses_other_factor(self) -> None:
        total, by_type = compute_attraction({"warehouse": 100.0})
        assert total == pytest.approx(100.0 * DEFAULT_ATTRACTION_FACTORS["other"])
        assert "warehouse" in by_type

    def test_multiple_types_sum_correctly(self) -> None:
        types = {"school": 200.0, "shopping": 100.0, "hospital": 50.0}
        expected = (
            200.0 * DEFAULT_ATTRACTION_FACTORS["school"]
            + 100.0 * DEFAULT_ATTRACTION_FACTORS["shopping"]
            + 50.0 * DEFAULT_ATTRACTION_FACTORS["hospital"]
        )
        total, _ = compute_attraction(types)
        assert total == pytest.approx(expected, rel=1e-6)

    def test_empty_types_returns_zero(self) -> None:
        total, by_type = compute_attraction({})
        assert total == 0.0
        assert by_type == {}

    def test_attraction_by_type_excludes_zeros(self) -> None:
        total, by_type = compute_attraction({"house": 500.0, "shopping": 100.0})
        assert "house" not in by_type
        assert "shopping" in by_type


# ---------------------------------------------------------------------------
# estimate_zone_population (integration — all external calls mocked)
# ---------------------------------------------------------------------------


class TestEstimateZonePopulation:
    _BBOX = [6.143, 52.248, 6.184, 52.272]

    _ZONES_FC = _zones_fc(
        _zone_feature("z1", {"house": 300.0, "shopping": 100.0}),
        _zone_feature("z2", {"house": 700.0, "school": 200.0}),
    )

    def _call(self, **kwargs) -> tuple[dict, dict]:
        from osm.zone_population_estimator.core.zone_population_estimator_core import (  # noqa: PLC0415
            estimate_zone_population,
        )

        nuts_result = {"nuts_code": "NL212", "nuts_level": 3}
        place_result = {"name": "Deventer", "display_name": "Deventer, Netherlands"}
        pop_result = {"population": 161927.0, "year": 2024, "nuts_code": "NL212"}

        with (
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.find_nuts",
                return_value=nuts_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.reverse_geocode",
                return_value=place_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.fetch_population",
                return_value=pop_result,
            ),
        ):
            return estimate_zone_population(self._ZONES_FC, self._BBOX, **kwargs)

    def test_returns_feature_collection(self) -> None:
        fc, _ = self._call()
        assert fc["type"] == "FeatureCollection"

    def test_stats_total_matches_zone_count(self) -> None:
        fc, stats = self._call()
        assert stats["total"] == len(fc["features"])

    def test_stats_contains_nuts_code(self) -> None:
        _, stats = self._call()
        assert stats["nutsCode"] == "NL212"

    def test_stats_contains_municipality_name(self) -> None:
        _, stats = self._call()
        assert stats["municipalityName"] == "Deventer"

    def test_stats_contains_population(self) -> None:
        _, stats = self._call()
        assert stats["totalPopulation"] == pytest.approx(161927.0)

    def test_production_present_on_each_zone(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert "production" in feat["properties"]

    def test_attraction_present_on_each_zone(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert "attraction" in feat["properties"]

    def test_attraction_by_type_present(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert "attractionByType" in feat["properties"]

    def test_total_production_equals_total_population(self) -> None:
        fc, stats = self._call()
        total_prod = sum(f["properties"]["production"] for f in fc["features"])
        assert total_prod == pytest.approx(stats["totalPopulation"], rel=1e-3)

    def test_production_proportional_to_house_m2(self) -> None:
        fc, stats = self._call()
        # z1 has 300m² house, z2 has 700m²: z1 gets 30%, z2 gets 70%
        props_by_id = {f["properties"]["zoneId"]: f["properties"] for f in fc["features"]}
        total_pop = stats["totalPopulation"]
        assert props_by_id["z1"]["production"] == pytest.approx(total_pop * 0.3, rel=1e-3)
        assert props_by_id["z2"]["production"] == pytest.approx(total_pop * 0.7, rel=1e-3)

    def test_nuts_code_on_zone_properties(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert feat["properties"]["nutsCode"] == "NL212"

    def test_municipality_name_on_zone_properties(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert feat["properties"]["municipalityName"] == "Deventer"

    def test_custom_attraction_factors_applied(self) -> None:
        fc, _ = self._call(attraction_factors={"shopping": 0.20})
        z1_props = next(
            f["properties"] for f in fc["features"] if f["properties"]["zoneId"] == "z1"
        )
        # z1 has 100m² shopping × 0.20 = 20.0
        assert z1_props["attractionByType"].get("shopping", 0.0) == pytest.approx(20.0)

    def test_fc_properties_contain_nuts_code(self) -> None:
        fc, _ = self._call()
        assert fc.get("properties", {}).get("nutsCode") == "NL212"
