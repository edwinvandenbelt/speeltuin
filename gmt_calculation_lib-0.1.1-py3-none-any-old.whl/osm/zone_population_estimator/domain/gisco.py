"""GISCO REST API helpers.

Fetches the NUTS3 region code and municipality name for a given WGS-84
coordinate using two public GISCO endpoints:

1. ``find_nuts(lon, lat)`` — reverse-geocodes a point to the NUTS3 region
   it falls within.
   Endpoint: ``{base_url}/nuts/find-nuts.py?x={lon}&y={lat}&format=json``
   Example response::

       [{"attributes": {"id": "NL212", "stat_levl_code": 3, ...}}]

2. ``reverse_geocode(lon, lat)`` — resolves a point to a human-readable
   place name via the GISCO Nominatim service.
   Endpoint: ``{base_url}/nominatim/reverse?lat={lat}&lon={lon}&zoom=10&format=jsonv2``

Public API
----------
find_nuts(lon, lat, *, base_url, timeout) -> dict
    Return ``{"nuts_code": str, "nuts_level": int}``.
reverse_geocode(lon, lat, *, base_url, timeout) -> dict
    Return ``{"name": str, "display_name": str}``.
"""

from __future__ import annotations

import json
import logging
import os
import ssl
import urllib.parse
import urllib.request

logger = logging.getLogger(__name__)

_DEFAULT_GISCO_URL = "https://gisco-services.ec.europa.eu"
_DEFAULT_TIMEOUT = 30


def _ssl_context() -> ssl.SSLContext | None:
    """Return an unverified SSL context when SSL_VERIFY=false, else None (default verification)."""
    if os.environ.get("SSL_VERIFY", "true").strip().lower() == "false":
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    return None


def find_nuts(
    lon: float,
    lat: float,
    *,
    base_url: str = _DEFAULT_GISCO_URL,
    timeout: int = _DEFAULT_TIMEOUT,
) -> dict:
    """Return the NUTS3 code for a WGS-84 point.

    Parameters
    ----------
    lon, lat:
        WGS-84 longitude / latitude.
    base_url:
        GISCO base URL (override in tests or for a mirror).
    timeout:
        HTTP timeout in seconds.

    Returns
    -------
    dict
        ``{"nuts_code": str, "nuts_level": int}``
        ``nuts_level`` is 3 when a NUTS3 region is found; may be 2 or 1 as a
        fallback.  Raises ``ValueError`` when no NUTS region is returned.
    """
    url = f"{base_url.rstrip('/')}/nuts/find-nuts.py?x={lon}&y={lat}&format=json"
    logger.debug("GISCO NUTS lookup: %s", url)
    with urllib.request.urlopen(url, timeout=timeout, context=_ssl_context()) as resp:  # noqa: S310
        data: list[dict] = json.loads(resp.read().decode())

    if not data:
        raise ValueError(f"GISCO returned no NUTS region for lon={lon} lat={lat}")

    # Prefer the highest NUTS level (most detailed)
    best = max(data, key=lambda item: item.get("attributes", {}).get("stat_levl_code", 0))
    attrs = best.get("attributes", {})
    nuts_code: str = attrs.get("id") or attrs.get("OBJECTID") or ""
    if not nuts_code:
        raise ValueError(f"GISCO NUTS response missing 'id' field: {best}")

    result = {
        "nuts_code": nuts_code,
        "nuts_level": int(attrs.get("stat_levl_code", 3)),
    }
    logger.info("NUTS lookup → %s (level %d)", result["nuts_code"], result["nuts_level"])
    return result


def reverse_geocode(
    lon: float,
    lat: float,
    *,
    base_url: str = _DEFAULT_GISCO_URL,
    timeout: int = _DEFAULT_TIMEOUT,
) -> dict:
    """Return a human-readable place name for a WGS-84 point.

    Parameters
    ----------
    lon, lat:
        WGS-84 longitude / latitude.
    base_url:
        GISCO base URL.
    timeout:
        HTTP timeout in seconds.

    Returns
    -------
    dict
        ``{"name": str, "display_name": str}``
        ``name`` is the local name (e.g. ``"Deventer"``).
        Returns ``{"name": "", "display_name": ""}`` on failure rather than
        raising, so that a failed geocode does not abort the entire run.
    """
    params = urllib.parse.urlencode({"lat": lat, "lon": lon, "zoom": 10, "format": "jsonv2"})
    url = f"{base_url.rstrip('/')}/nominatim/reverse?{params}"
    logger.debug("GISCO Nominatim reverse geocode: %s", url)
    try:
        with urllib.request.urlopen(url, timeout=timeout, context=_ssl_context()) as resp:  # noqa: S310
            data: dict = json.loads(resp.read().decode())
        return {
            "name": data.get("name") or data.get("display_name", "").split(",")[0].strip(),
            "display_name": data.get("display_name", ""),
        }
    except Exception as exc:  # noqa: BLE001
        logger.warning("Reverse geocode failed for lon=%s lat=%s: %s", lon, lat, exc)
        return {"name": "", "display_name": ""}
