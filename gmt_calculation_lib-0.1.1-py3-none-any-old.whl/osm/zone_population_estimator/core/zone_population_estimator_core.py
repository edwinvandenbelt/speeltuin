"""Pure-Python zone_population_estimator core — no I/O, no boto3.

Enriches a building-zones GeoJSON FeatureCollection (output of
``building_zone_creator``) with:

- **production**: estimated number of residents allocated to each zone,
  distributed proportionally to the ``house`` building-type footprint (m²).
- **attraction**: estimated daily person-movements attracted to each zone,
  derived from non-residential building-type footprints × conversion factors.
- **attractionByType**: per-type breakdown of the attraction figure.

Population totals are looked up from the Eurostat DEMO_R_GIND3 dataset
(NUTS3 regional data) via the public Eurostat Statistics API.  The NUTS3
code is resolved from the bbox centroid using the GISCO reverse-geocode API.

Public API
----------
estimate_zone_population(zones_fc, bbox, *, gisco_url, eurostat_url,
                         gisco_timeout, eurostat_timeout,
                         attraction_factors) -> tuple[dict, dict]
    Returns (enriched_fc, stats).
    stats: {"total": int, "totalPopulation": float, "nutsCode": str,
            "municipalityName": str, "year": int}
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from osm.zone_population_estimator.domain.attraction import (  # noqa: E402
    DEFAULT_ATTRACTION_FACTORS,
    compute_attraction,
)
from osm.zone_population_estimator.domain.distributor import distribute_population  # noqa: E402
from osm.zone_population_estimator.domain.eurostat import fetch_population  # noqa: E402
from osm.zone_population_estimator.domain.gisco import find_nuts, reverse_geocode  # noqa: E402

_DEFAULT_GISCO_URL = "https://gisco-services.ec.europa.eu"
_DEFAULT_EUROSTAT_URL = "https://ec.europa.eu/eurostat/api/dissemination"
_DEFAULT_TIMEOUT = 30


def estimate_zone_population(
    zones_fc: dict,
    bbox: list[float],
    *,
    gisco_url: str = _DEFAULT_GISCO_URL,
    eurostat_url: str = _DEFAULT_EUROSTAT_URL,
    gisco_timeout: int = _DEFAULT_TIMEOUT,
    eurostat_timeout: int = _DEFAULT_TIMEOUT,
    attraction_factors: dict[str, float] | None = None,
) -> tuple[dict, dict]:
    """Enrich a zones FeatureCollection with production and attraction.

    Parameters
    ----------
    zones_fc:
        GeoJSON FeatureCollection produced by ``building_zone_creator``.
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84 — used to resolve the
        NUTS3 region for population lookup.
    gisco_url:
        GISCO REST API base URL.
    eurostat_url:
        Eurostat SDMX API base URL.
    gisco_timeout:
        HTTP timeout in seconds for GISCO calls.
    eurostat_timeout:
        HTTP timeout in seconds for Eurostat calls.
    attraction_factors:
        Optional override dict ``{building_type: trips_per_m2_per_day}``.
        Merged with (and overrides) ``DEFAULT_ATTRACTION_FACTORS``.

    Returns
    -------
    enriched_fc:
        The same FeatureCollection with extra properties per zone:
        ``production``, ``attraction``, ``attractionByType``,
        ``totalPopulation``, ``municipalityName``, ``nutsCode``.
    stats:
        ``{"total": int, "totalPopulation": float, "nutsCode": str,
           "municipalityName": str, "year": int}``
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    centre_lon = (min_lon + max_lon) / 2.0
    centre_lat = (min_lat + max_lat) / 2.0

    # ── 1. Resolve NUTS3 region ──────────────────────────────────────────────
    logger.info("Resolving NUTS region for centroid lon=%.4f lat=%.4f", centre_lon, centre_lat)
    nuts_info = find_nuts(centre_lon, centre_lat, base_url=gisco_url, timeout=gisco_timeout)
    nuts_code: str = nuts_info["nuts_code"]

    place_info = reverse_geocode(centre_lon, centre_lat, base_url=gisco_url, timeout=gisco_timeout)
    municipality_name: str = place_info.get("name", "")

    # ── 2. Fetch population from Eurostat ────────────────────────────────────
    logger.info("Fetching population for NUTS code %s", nuts_code)
    pop_info = fetch_population(nuts_code, base_url=eurostat_url, timeout=eurostat_timeout)
    total_population: float = pop_info["population"]
    pop_year: int = pop_info["year"]
    actual_nuts_code: str = pop_info["nuts_code"]  # may differ after fallback
    logger.info("Population %s: %.0f (year %d)", actual_nuts_code, total_population, pop_year)

    # ── 3. Distribute production ─────────────────────────────────────────────
    production_by_zone = distribute_population(zones_fc, total_population)

    # ── 4. Compute attraction per zone + enrich features ────────────────────
    features: list[dict] = zones_fc.get("features") or []
    enriched_features: list[dict] = []

    for feat in features:
        props: dict = dict(feat.get("properties") or {})
        zone_id: str = props.get("zoneId", "")

        building_types_m2: dict[str, float] = {
            k: float(v) for k, v in (props.get("buildingTypes") or {}).items()
        }
        attraction, attraction_by_type = compute_attraction(
            building_types_m2, factors=attraction_factors
        )

        props["production"] = round(production_by_zone.get(zone_id, 0.0), 2)
        props["attraction"] = attraction
        props["attractionByType"] = attraction_by_type
        props["totalPopulation"] = total_population
        props["municipalityName"] = municipality_name
        props["nutsCode"] = actual_nuts_code

        enriched_features.append(
            {
                "type": "Feature",
                "geometry": feat.get("geometry"),
                "properties": props,
            }
        )

    enriched_fc: dict = {
        "type": "FeatureCollection",
        "features": enriched_features,
        "properties": {
            **(zones_fc.get("properties") or {}),
            "nutsCode": actual_nuts_code,
            "municipalityName": municipality_name,
            "totalPopulation": total_population,
            "populationYear": pop_year,
        },
    }
    stats: dict = {
        "total": len(enriched_features),
        "totalPopulation": total_population,
        "nutsCode": actual_nuts_code,
        "municipalityName": municipality_name,
        "year": pop_year,
    }
    logger.info(
        "estimate_zone_population complete: %d zones enriched, pop=%.0f",
        len(enriched_features),
        total_population,
    )
    return enriched_fc, stats
