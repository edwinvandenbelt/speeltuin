"""Pure-Python building_zone_creator core — no I/O, no boto3.

Creates building zones from a GeoJSON FeatureCollection of buildings
(as produced by osm_building_fetcher).  Street geometry is fetched from
Overpass, used to divide the bounding box into city-block polygons, and
then blocks are greedily merged until each zone's total building footprint
reaches ``target_footprint_m2``.

Public API
----------
create_zones(buildings_fc, bbox, *, overpass_url, overpass_timeout, target_footprint_m2)
    -> tuple[dict, dict]
    Returns (zones_feature_collection, stats).
    stats: {"total": int, "blocks": int, "zones": int, "assigned_buildings": int}
"""

from __future__ import annotations

import logging
import uuid

logger = logging.getLogger(__name__)

from shared.overpass import DEFAULT_OVERPASS_URL, fetch_overpass  # noqa: E402

from osm.building_zone_creator.domain.block_builder import build_blocks
from osm.building_zone_creator.domain.building_assigner import assign_buildings_to_blocks
from osm.building_zone_creator.domain.footprint import building_footprint_m2
from osm.building_zone_creator.domain.merger import greedy_merge
from osm.building_zone_creator.domain.overpass import build_streets_query

_DEFAULT_OVERPASS_URL = DEFAULT_OVERPASS_URL
_DEFAULT_TARGET_FOOTPRINT_M2 = 5_000.0
_DEFAULT_TIMEOUT = 90


def create_zones(
    buildings_fc: dict,
    bbox: list[float],
    *,
    area_id: str | None = None,
    overpass_url: str = _DEFAULT_OVERPASS_URL,
    overpass_timeout: int = _DEFAULT_TIMEOUT,
    target_footprint_m2: float = _DEFAULT_TARGET_FOOTPRINT_M2,
) -> tuple[dict, dict]:
    """Create building zones for a bounding box from a buildings FeatureCollection.

    Parameters
    ----------
    buildings_fc:
        GeoJSON FeatureCollection of buildings (output of osm_building_fetcher).
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    area_id:
        Optional string prepended to zone IDs (``{area_id}_{index}``).
        Defaults to a random UUID prefix when not provided.
    overpass_url:
        Overpass API endpoint URL.
    overpass_timeout:
        Overpass query timeout in seconds.
    target_footprint_m2:
        Target total building footprint per zone in m².  Blocks are merged
        until their combined footprint reaches this threshold.

    Returns
    -------
    fc:
        GeoJSON FeatureCollection of zone polygons.  Each Feature has
        properties: ``zoneId``, ``nBuildings``, ``totalFootprintM2``,
        ``buildingTypes`` (object with counts per type), ``centroidLon``,
        ``centroidLat``.
    stats:
        ``{"total": int, "blocks": int, "zones": int, "assigned_buildings": int}``
    """
    features: list[dict] = buildings_fc.get("features") or []
    min_lon, min_lat, max_lon, max_lat = bbox
    ref_lat = (min_lat + max_lat) / 2.0

    prefix = area_id or str(uuid.uuid4())[:8]

    # ── 1. Fetch streets via Overpass ────────────────────────────────────────
    query = build_streets_query(bbox, timeout=overpass_timeout)
    logger.info(
        "Fetching streets via Overpass  bbox=%s  url=%s",
        bbox,
        overpass_url,
    )
    data = fetch_overpass(query, url=overpass_url, timeout=overpass_timeout)
    streets: list[dict] = data.get("elements") or []
    logger.info("Overpass returned %d street elements", len(streets))

    # ── 2. Build city-block polygons ─────────────────────────────────────────
    blocks = build_blocks(streets, bbox)
    logger.info("Built %d city blocks", len(blocks))

    # ── 3. Pre-compute building footprints and assign to blocks ─────────────
    block_buildings: dict[int, list[int]] = {i: [] for i in range(len(blocks))}
    block_footprints: dict[int, float] = {i: 0.0 for i in range(len(blocks))}

    if features:
        assignments = assign_buildings_to_blocks(features, blocks)
        for feat_idx, block_idx in enumerate(assignments):
            if block_idx < 0:
                continue
            fp = building_footprint_m2(features[feat_idx], ref_lat=ref_lat)
            block_buildings[block_idx].append(feat_idx)
            block_footprints[block_idx] = block_footprints.get(block_idx, 0.0) + fp
        assigned = sum(1 for b in assignments if b >= 0)
    else:
        assigned = 0

    # ── 4. Greedy-merge blocks into zones ────────────────────────────────────
    zones = greedy_merge(blocks, block_buildings, block_footprints, target_footprint_m2)
    logger.info("Greedy merge produced %d zones from %d blocks", len(zones), len(blocks))

    # ── 5. Build output FeatureCollection ────────────────────────────────────
    zone_features: list[dict] = []
    for i, zone in enumerate(zones):
        geom = zone["geom"]
        b_indices: list[int] = zone["building_indices"]
        total_fp: float = zone["total_footprint"]

        # Footprint m² per building type
        type_counts: dict[str, float] = {}
        for bi in b_indices:
            btype = (features[bi].get("properties") or {}).get("buildingType", "other")
            fp_bi = building_footprint_m2(features[bi], ref_lat=ref_lat)
            type_counts[btype] = round(type_counts.get(btype, 0.0) + fp_bi, 1)

        # Centroid
        try:
            centroid = geom.centroid
            centroid_lon = round(centroid.x, 6)
            centroid_lat = round(centroid.y, 6)
        except Exception:
            centroid_lon = round((min_lon + max_lon) / 2, 6)
            centroid_lat = round((min_lat + max_lat) / 2, 6)

        # Geometry → GeoJSON
        try:
            from shapely.geometry import mapping  # noqa: PLC0415

            geom_json = mapping(geom)
        except Exception:
            geom_json = {"type": "Polygon", "coordinates": []}

        zone_features.append(
            {
                "type": "Feature",
                "geometry": geom_json,
                "properties": {
                    "zoneId": f"{prefix}_{i}",
                    "nBuildings": len(b_indices),
                    "totalFootprintM2": round(total_fp, 1),
                    "buildingTypes": type_counts,
                    "centroidLon": centroid_lon,
                    "centroidLat": centroid_lat,
                },
            }
        )

    fc: dict = {
        "type": "FeatureCollection",
        "features": zone_features,
        "properties": {
            "bbox": bbox,
            "areaId": prefix,
            "targetFootprintM2": target_footprint_m2,
            "overpassUrl": overpass_url,
        },
    }
    stats: dict = {
        "total": len(zone_features),
        "blocks": len(blocks),
        "zones": len(zones),
        "assigned_buildings": assigned,
    }
    logger.info(
        "create_zones complete: %d zones  %d assigned buildings",
        len(zone_features),
        assigned,
    )
    return fc, stats
