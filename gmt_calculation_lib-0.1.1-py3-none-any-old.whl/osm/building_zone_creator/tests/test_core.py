"""Tests for building_zone_creator domain modules and core.

Covers:
- overpass.build_streets_query — Overpass QL correctness
- footprint.polygon_area_m2 — shoelace formula
- footprint.building_footprint_m2 — polygon, point, default
- block_builder.build_blocks — polygonize with simple grids, no-street fallback
- building_assigner.assign_buildings_to_blocks — PIP, fallback, empty blocks
- merger.greedy_merge — merge smallest block, stop at target, isolated block
- create_zones (integration) — mocked Overpass, two-block case
"""

from __future__ import annotations

import math
from unittest.mock import patch

import pytest

from osm.building_zone_creator.domain.overpass import build_streets_query
from osm.building_zone_creator.domain.footprint import building_footprint_m2, polygon_area_m2

# ---------------------------------------------------------------------------
# shapely guard — skip spatial tests if shapely is not installed
# ---------------------------------------------------------------------------
shapely = pytest.importorskip("shapely", reason="shapely not installed")
from shapely.geometry import LineString, Polygon, box  # noqa: E402

from osm.building_zone_creator.domain.block_builder import build_blocks  # noqa: E402
from osm.building_zone_creator.domain.building_assigner import assign_buildings_to_blocks  # noqa: E402
from osm.building_zone_creator.domain.merger import greedy_merge  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _poly_feature(coords: list[list[float]], btype: str = "house") -> dict:
    """Build a minimal GeoJSON Feature with a Polygon geometry."""
    ring = list(coords)
    if ring[0] != ring[-1]:
        ring.append(ring[0])
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {"buildingType": btype},
    }


def _point_feature(lon: float, lat: float, btype: str = "other") -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": {"buildingType": btype},
    }


def _street_element(coords: list[tuple[float, float]]) -> dict:
    """Minimal Overpass street element with geometry list."""
    return {
        "type": "way",
        "id": 1,
        "tags": {"highway": "residential"},
        "geometry": [{"lon": lon, "lat": lat} for lon, lat in coords],
    }


# ---------------------------------------------------------------------------
# build_streets_query
# ---------------------------------------------------------------------------


class TestBuildStreetsQuery:
    def test_json_output(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "[out:json]" in q

    def test_bbox_order_is_lat_lon(self) -> None:
        q = build_streets_query([6.143, 52.248, 6.184, 52.272])
        assert "52.248,6.143,52.272,6.184" in q

    def test_highway_filter_present(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert '"highway"' in q

    def test_custom_timeout(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1], timeout=120)
        assert "[timeout:120]" in q

    def test_out_geom(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "out geom" in q

    def test_excludes_footway(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "footway" not in q

    def test_includes_residential(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "residential" in q


# ---------------------------------------------------------------------------
# polygon_area_m2
# ---------------------------------------------------------------------------


class TestPolygonAreaM2:
    def test_unit_square_approx(self) -> None:
        # 1° × 1° square near equator ≈ 111_320² m²
        coords = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]
        area = polygon_area_m2(coords, ref_lat=0.0)
        assert area == pytest.approx(111_320.0**2, rel=0.01)

    def test_smaller_square(self) -> None:
        # 0.1° × 0.1° square
        coords = [[0.0, 0.0], [0.1, 0.0], [0.1, 0.1], [0.0, 0.1]]
        area = polygon_area_m2(coords, ref_lat=0.0)
        assert area == pytest.approx((0.1 * 111_320) ** 2, rel=0.01)

    def test_degenerate_less_than_three_points(self) -> None:
        assert polygon_area_m2([[0.0, 0.0], [1.0, 1.0]], ref_lat=52.0) == 0.0

    def test_longitude_scaling_at_52_degrees(self) -> None:
        # At 52°N, 1° lon ≈ cos(52°) * 111_320 m
        coords = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]
        area = polygon_area_m2(coords, ref_lat=52.0)
        expected = 111_320.0 * math.cos(math.radians(52.0)) * 111_320.0
        assert area == pytest.approx(expected, rel=0.01)

    def test_closed_polygon_same_as_open(self) -> None:
        coords_open = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]
        coords_closed = coords_open + [[0.0, 0.0]]
        area_open = polygon_area_m2(coords_open, ref_lat=0.0)
        area_closed = polygon_area_m2(coords_closed, ref_lat=0.0)
        assert area_open == pytest.approx(area_closed, rel=1e-9)


# ---------------------------------------------------------------------------
# building_footprint_m2
# ---------------------------------------------------------------------------


class TestBuildingFootprintM2:
    def test_polygon_feature(self) -> None:
        feat = _poly_feature([[0.0, 0.0], [0.01, 0.0], [0.01, 0.01], [0.0, 0.01]])
        area = building_footprint_m2(feat, ref_lat=52.0)
        assert area > 0.0

    def test_point_feature_returns_default(self) -> None:
        from osm.building_zone_creator.domain.footprint import _DEFAULT_FOOTPRINT_M2

        feat = _point_feature(6.15, 52.25)
        area = building_footprint_m2(feat, ref_lat=52.0)
        assert area == _DEFAULT_FOOTPRINT_M2

    def test_degenerate_polygon_returns_default(self) -> None:
        from osm.building_zone_creator.domain.footprint import _DEFAULT_FOOTPRINT_M2

        feat = _poly_feature([[0.0, 0.0], [0.0, 0.0]])
        area = building_footprint_m2(feat, ref_lat=52.0)
        assert area == _DEFAULT_FOOTPRINT_M2

    def test_missing_geometry_returns_default(self) -> None:
        from osm.building_zone_creator.domain.footprint import _DEFAULT_FOOTPRINT_M2

        feat = {"type": "Feature", "geometry": None, "properties": {}}
        area = building_footprint_m2(feat, ref_lat=52.0)
        assert area == _DEFAULT_FOOTPRINT_M2


# ---------------------------------------------------------------------------
# build_blocks
# ---------------------------------------------------------------------------


class TestBuildBlocks:
    _BBOX = [0.0, 0.0, 2.0, 2.0]

    def _cross_streets(self) -> list[dict]:
        """Two crossing roads at (1,0)-(1,2) and (0,1)-(2,1) → 4 blocks."""
        return [
            _street_element([(1.0, 0.0), (1.0, 2.0)]),
            _street_element([(0.0, 1.0), (2.0, 1.0)]),
        ]

    def test_cross_streets_produce_four_blocks(self) -> None:
        blocks = build_blocks(self._cross_streets(), self._BBOX)
        assert len(blocks) == 4

    def test_all_blocks_are_polygons(self) -> None:
        blocks = build_blocks(self._cross_streets(), self._BBOX)
        for b in blocks:
            assert b.geom_type == "Polygon"

    def test_no_streets_returns_single_bbox_block(self) -> None:
        blocks = build_blocks([], self._BBOX)
        assert len(blocks) == 1
        assert blocks[0].geom_type == "Polygon"

    def test_blocks_union_covers_bbox(self) -> None:
        from shapely.ops import unary_union  # noqa: PLC0415

        blocks = build_blocks(self._cross_streets(), self._BBOX)
        bbox_poly = box(*self._BBOX)
        union = unary_union(blocks)
        assert union.area == pytest.approx(bbox_poly.area, rel=1e-6)

    def test_blocks_clipped_within_bbox(self) -> None:
        bbox_poly = box(*self._BBOX)
        blocks = build_blocks(self._cross_streets(), self._BBOX)
        for b in blocks:
            assert b.within(bbox_poly.buffer(1e-9))

    def test_single_street_produces_two_blocks(self) -> None:
        # One vertical road through the middle → 2 blocks
        streets = [_street_element([(1.0, 0.0), (1.0, 2.0)])]
        blocks = build_blocks(streets, self._BBOX)
        assert len(blocks) == 2


# ---------------------------------------------------------------------------
# assign_buildings_to_blocks
# ---------------------------------------------------------------------------


class TestAssignBuildingsToBlocks:
    def _two_blocks(self) -> list:
        """Left block [0,0]–[1,2] and right block [1,0]–[2,2]."""
        return [
            Polygon([(0, 0), (1, 0), (1, 2), (0, 2), (0, 0)]),
            Polygon([(1, 0), (2, 0), (2, 2), (1, 2), (1, 0)]),
        ]

    def test_left_building_assigned_to_block_0(self) -> None:
        blocks = self._two_blocks()
        feat = _point_feature(0.25, 1.0)
        result = assign_buildings_to_blocks([feat], blocks)
        assert result[0] == 0

    def test_right_building_assigned_to_block_1(self) -> None:
        blocks = self._two_blocks()
        feat = _point_feature(1.75, 1.0)
        result = assign_buildings_to_blocks([feat], blocks)
        assert result[0] == 1

    def test_empty_buildings_returns_empty(self) -> None:
        result = assign_buildings_to_blocks([], self._two_blocks())
        assert result == []

    def test_empty_blocks_returns_minus_one(self) -> None:
        feat = _point_feature(0.5, 0.5)
        result = assign_buildings_to_blocks([feat], [])
        assert result == [-1]

    def test_polygon_building_uses_centroid(self) -> None:
        blocks = self._two_blocks()
        # Centroid of this polygon is at (0.5, 1.0) — in block 0
        feat = _poly_feature([[0.1, 0.5], [0.9, 0.5], [0.9, 1.5], [0.1, 1.5]])
        result = assign_buildings_to_blocks([feat], blocks)
        assert result[0] == 0

    def test_multiple_buildings(self) -> None:
        blocks = self._two_blocks()
        feats = [_point_feature(0.5, 1.0), _point_feature(1.5, 1.0)]
        result = assign_buildings_to_blocks(feats, blocks)
        assert result == [0, 1]


# ---------------------------------------------------------------------------
# greedy_merge
# ---------------------------------------------------------------------------


class TestGreedyMerge:
    def _four_blocks(self) -> list:
        """2×2 grid of 1×1 squares."""
        return [
            box(0, 0, 1, 1),
            box(1, 0, 2, 1),
            box(0, 1, 1, 2),
            box(1, 1, 2, 2),
        ]

    def test_no_blocks_returns_empty(self) -> None:
        result = greedy_merge([], {}, {}, 100.0)
        assert result == []

    def test_all_blocks_above_target_not_merged(self) -> None:
        blocks = self._four_blocks()
        fp = {i: 200.0 for i in range(4)}
        zones = greedy_merge(blocks, {}, fp, target_m2=100.0)
        assert len(zones) == 4

    def test_smallest_block_merged_with_neighbour(self) -> None:
        blocks = self._four_blocks()
        # Block 0 has 0 footprint → should merge with smallest-combined neighbour
        fp = {0: 0.0, 1: 50.0, 2: 50.0, 3: 200.0}
        zones = greedy_merge(blocks, {i: [] for i in range(4)}, fp, target_m2=100.0)
        # There should be fewer zones than blocks (some merging happened)
        assert len(zones) < 4

    def test_merged_zone_has_combined_footprint(self) -> None:
        blocks = [box(0, 0, 1, 1), box(1, 0, 2, 1)]
        fp = {0: 30.0, 1: 30.0}
        bi = {0: [0], 1: [1]}
        zones = greedy_merge(blocks, bi, fp, target_m2=1000.0)
        # Both blocks should be merged into one zone
        assert len(zones) == 1
        assert zones[0]["total_footprint"] == pytest.approx(60.0)

    def test_merged_zone_contains_all_buildings(self) -> None:
        blocks = [box(0, 0, 1, 1), box(1, 0, 2, 1)]
        fp = {0: 30.0, 1: 30.0}
        bi = {0: [0, 1], 1: [2]}
        zones = greedy_merge(blocks, bi, fp, target_m2=1000.0)
        assert len(zones) == 1
        assert set(zones[0]["building_indices"]) == {0, 1, 2}

    def test_isolated_block_stays_isolated(self) -> None:
        # Two non-adjacent blocks (far apart)
        blocks = [box(0, 0, 1, 1), box(10, 10, 11, 11)]
        fp = {0: 10.0, 1: 10.0}
        zones = greedy_merge(blocks, {0: [], 1: []}, fp, target_m2=1000.0)
        assert len(zones) == 2

    def test_zone_geom_is_union_of_merged_blocks(self) -> None:
        blocks = [box(0, 0, 1, 1), box(1, 0, 2, 1)]
        fp = {0: 10.0, 1: 10.0}
        zones = greedy_merge(blocks, {}, fp, target_m2=1000.0)
        assert len(zones) == 1
        # Area of merged zone should equal sum of both blocks
        assert zones[0]["geom"].area == pytest.approx(2.0, rel=1e-6)


# ---------------------------------------------------------------------------
# create_zones (integration — Overpass mocked)
# ---------------------------------------------------------------------------


class TestCreateZones:
    _BBOX = [0.0, 0.0, 2.0, 2.0]

    _MOCK_STREETS = [
        {
            "type": "way",
            "id": 1,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 1.0, "lat": 0.0}, {"lon": 1.0, "lat": 2.0}],
        }
    ]

    _BUILDINGS_FC: dict = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [0.5, 1.0]},
                "properties": {"buildingType": "house"},
            },
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [1.5, 1.0]},
                "properties": {"buildingType": "school"},
            },
        ],
    }

    def _call(self, target: float = 1_000_000.0) -> tuple[dict, dict]:
        from osm.building_zone_creator.core.building_zone_creator_core import create_zones  # noqa: PLC0415

        mock_data = {"elements": self._MOCK_STREETS}
        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = mock_data
            return create_zones(
                self._BUILDINGS_FC,
                self._BBOX,
                area_id="test",
                target_footprint_m2=target,
            )

    def test_returns_feature_collection(self) -> None:
        fc, _ = self._call()
        assert fc["type"] == "FeatureCollection"

    def test_stats_total_matches_feature_count(self) -> None:
        fc, stats = self._call()
        assert stats["total"] == len(fc["features"])

    def test_zones_created(self) -> None:
        _, stats = self._call()
        assert stats["zones"] >= 1

    def test_blocks_at_least_two_from_one_road(self) -> None:
        _, stats = self._call()
        assert stats["blocks"] >= 2

    def test_both_buildings_assigned(self) -> None:
        _, stats = self._call()
        assert stats["assigned_buildings"] == 2

    def test_zone_properties_present(self) -> None:
        fc, _ = self._call()
        feat = fc["features"][0]
        props = feat["properties"]
        assert "zoneId" in props
        assert "nBuildings" in props
        assert "totalFootprintM2" in props
        assert "buildingTypes" in props
        assert "centroidLon" in props
        assert "centroidLat" in props

    def test_building_types_are_m2_floats(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            for val in feat["properties"]["buildingTypes"].values():
                assert isinstance(val, float)
                assert val >= 0.0

    def test_zone_id_prefix_matches_area_id(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert feat["properties"]["zoneId"].startswith("test_")

    def test_zone_geometry_is_polygon(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert feat["geometry"]["type"] in ("Polygon", "MultiPolygon")

    def test_large_target_produces_fewer_zones(self) -> None:
        _, stats_large = self._call(target=1_000_000.0)
        _, stats_small = self._call(target=1.0)
        assert stats_large["zones"] <= stats_small["zones"]

    def test_empty_buildings_still_produces_zones(self) -> None:
        from osm.building_zone_creator.core.building_zone_creator_core import create_zones  # noqa: PLC0415

        empty_fc: dict = {"type": "FeatureCollection", "features": []}
        mock_data = {"elements": self._MOCK_STREETS}
        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = mock_data
            fc, stats = create_zones(empty_fc, self._BBOX, area_id="test")
        assert fc["type"] == "FeatureCollection"
        assert stats["zones"] >= 1
        assert stats["assigned_buildings"] == 0
