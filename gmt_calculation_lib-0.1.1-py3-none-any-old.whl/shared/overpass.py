"""Overpass API client — puur stdlib (urllib), geen extra dependencies.

Used by osm_network_fetcher and osm_zone_fetcher to query the Overpass API.

Public API
----------
fetch_overpass(query, *, url, timeout) -> dict
    Send an Overpass QL query and return the parsed JSON response.
split_bbox(bbox, nx, ny) -> list[list[float]]
    Split a bounding box into nx × ny sub-bboxes (tiles).
merge_elements(lists) -> list[dict]
    Merge and deduplicate Overpass element lists by (type, id).
fetch_overpass_tiled(query_fn, bbox, *, tiles, url, timeout) -> dict
    Fetch Overpass data in tiles and return a merged response.
"""

from __future__ import annotations

import json
import logging
import os
import urllib.error
import urllib.parse
import urllib.request
from typing import Any, Callable

logger = logging.getLogger(__name__)

_OVERPASS_URL_FALLBACK = "https://overpass-api.de/api/interpreter"
DEFAULT_OVERPASS_URL: str = os.environ.get("OVERPASS_URL", _OVERPASS_URL_FALLBACK)


def fetch_overpass(
    query: str,
    *,
    url: str = DEFAULT_OVERPASS_URL,
    timeout: int = 90,
) -> dict[str, Any]:
    """Send an Overpass QL query and return the parsed JSON response.

    Parameters
    ----------
    query:
        Overpass QL query string.
    url:
        Overpass API endpoint URL.  Defaults to the public instance.
    timeout:
        HTTP request timeout in seconds.

    Returns
    -------
    Parsed JSON response dict.

    Raises
    ------
    urllib.error.URLError:
        On network / DNS errors.
    urllib.error.HTTPError:
        On HTTP 4xx / 5xx responses.
    ValueError:
        If the response body is not valid JSON.
    RuntimeError:
        If Overpass returns a ``remark`` element containing an error or
        ``exceeded`` (rate-limit hit).
    """
    encoded = urllib.parse.urlencode({"data": query}).encode("utf-8")
    req = urllib.request.Request(url, data=encoded, method="POST")
    req.add_header("Content-Type", "application/x-www-form-urlencoded")
    req.add_header("User-Agent", "gmt-calculation-lib/1.0")
    req.add_header("Accept", "application/json")

    logger.debug("Overpass POST %s  (%d bytes)", url, len(encoded))
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
        body = resp.read().decode("utf-8")

    try:
        data: dict[str, Any] = json.loads(body)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Overpass returned invalid JSON: {exc}") from exc

    for remark in data.get("remarks", []):
        if "error" in remark.lower() or "exceeded" in remark.lower():
            raise RuntimeError(f"Overpass API remark: {remark}")

    n_elements = len(data.get("elements") or [])
    logger.debug("Overpass returned %d elements", n_elements)
    return data


# ---------------------------------------------------------------------------
# Tiling utilities
# ---------------------------------------------------------------------------


def split_bbox(
    bbox: list[float],
    nx: int,
    ny: int,
) -> list[list[float]]:
    """Split a bounding box into nx × ny evenly-sized tiles.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS 84.
    nx:
        Number of columns (longitude divisions).
    ny:
        Number of rows (latitude divisions).

    Returns
    -------
    List of ``[minLon, minLat, maxLon, maxLat]`` sub-bboxes, row-major order
    (bottom row first).
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    lon_step = (max_lon - min_lon) / nx
    lat_step = (max_lat - min_lat) / ny
    tiles: list[list[float]] = []
    for iy in range(ny):
        for ix in range(nx):
            tiles.append(
                [
                    min_lon + ix * lon_step,
                    min_lat + iy * lat_step,
                    min_lon + (ix + 1) * lon_step,
                    min_lat + (iy + 1) * lat_step,
                ]
            )
    return tiles


def merge_elements(lists: list[list[dict]]) -> list[dict]:
    """Merge and deduplicate Overpass element lists.

    Elements are deduplicated by ``(type, id)``.  The first occurrence of
    each element is kept (preserving embedded geometry).

    Parameters
    ----------
    lists:
        One or more lists of Overpass element dicts.

    Returns
    -------
    A single deduplicated list of elements.
    """
    seen: dict[tuple[str, int], dict] = {}
    for elements in lists:
        for el in elements:
            key = (el.get("type", ""), el.get("id", -1))
            if key not in seen:
                seen[key] = el
    return list(seen.values())


def fetch_overpass_tiled(
    query_fn: Callable[[list[float]], str],
    bbox: list[float],
    *,
    tiles: tuple[int, int] = (1, 1),
    url: str = DEFAULT_OVERPASS_URL,
    timeout: int = 90,
) -> dict[str, Any]:
    """Fetch Overpass data by splitting the bbox into tiles.

    Splits *bbox* into ``tiles[0] × tiles[1]`` sub-bboxes, fires a separate
    Overpass query for each tile (using *query_fn* to build the query string),
    and merges the results, deduplicating elements by ``(type, id)``.

    Parameters
    ----------
    query_fn:
        Callable that takes a ``[minLon, minLat, maxLon, maxLat]`` bbox and
        returns an Overpass QL query string.
    bbox:
        Full bounding box to cover.
    tiles:
        ``(nx, ny)`` number of column / row divisions.  ``(1, 1)`` means a
        single query (no tiling).
    url:
        Overpass API endpoint URL.
    timeout:
        HTTP request timeout per tile request.

    Returns
    -------
    Dict with ``"elements"`` key containing the merged, deduplicated list.
    """
    nx, ny = tiles
    if nx == 1 and ny == 1:
        return fetch_overpass(query_fn(bbox), url=url, timeout=timeout)

    tile_bboxes = split_bbox(bbox, nx, ny)
    logger.info(
        "Tiled Overpass fetch: %d × %d = %d tiles  bbox=%s",
        nx,
        ny,
        len(tile_bboxes),
        bbox,
    )

    all_element_lists: list[list[dict]] = []
    for i, tile_bbox in enumerate(tile_bboxes, 1):
        logger.info("Tile %d/%d  bbox=%s", i, len(tile_bboxes), tile_bbox)
        data = fetch_overpass(query_fn(tile_bbox), url=url, timeout=timeout)
        all_element_lists.append(data.get("elements") or [])

    merged = merge_elements(all_element_lists)
    logger.info("Tiled fetch complete: %d unique elements", len(merged))
    return {"elements": merged}
