"""Unit tests for priority_roundabout_enricher_core."""

from __future__ import annotations

from gmt_network_enrichment.osm.priority_roundabout_enricher.core.priority_roundabout_enricher_core import (
    enrich_network_with_priority_and_roundabouts,
)


def _net_link(link_id, from_node, to_node, coords) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
        },
    }


def _osm_way(way_id, coords, tags) -> dict:
    return {
        "type": "way",
        "id": way_id,
        "geometry": [{"lon": c[0], "lat": c[1]} for c in coords],
        "tags": tags,
    }


def _sign(code, lon, lat, *, road_section_id=None, driving_direction=None) -> dict:
    props = {"assetType": "trafficSign", "rvvCode": code}
    if road_section_id is not None:
        props["roadSectionId"] = road_section_id
    if driving_direction is not None:
        props["drivingDirection"] = driving_direction
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": props,
    }


def _directed_net_link(
    link_id, from_node, to_node, coords, wvk_ids=None, reverse_link_ids=None
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "mode": "CAR",
            "wvkIds": list(wvk_ids or []),
            "reverseLinkIds": list(reverse_link_ids or []),
        },
    }


def test_empty_network_gets_defaults() -> None:
    fc = {"type": "FeatureCollection", "features": [_net_link("L1", "A", "B", [[0, 0], [1, 0]])]}
    result, _give_ways = enrich_network_with_priority_and_roundabouts(fc)
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is False
    assert props["roundaboutType"] == "none"
    assert props["priorityRoad"] is False
    assert props["priorityRoadSource"] == "none"


def test_osm_roundabout_tag_with_d1_snaps() -> None:
    """A roundabout OSM way plus a D1 sign marks the link as roundabout and priority."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [_osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"junction": "roundabout"})]
    signs = [_sign("D1", 0.0, 0.0005)]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, osm_elements=osm, traffic_sign_features=signs
    )
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is True
    assert props["roundaboutType"] == "roundabout"
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "osm_roundabout"


def test_osm_priority_road_tag_snaps() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [_osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"priority_road": "designated"})]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(fc, osm_elements=osm)
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "osm_priority_road"


def test_ndw_b1_sign_snaps() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    signs = [_sign("B1", 0.0, 0.0005)]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "ndw_b1"


def test_ndw_b3_still_priority() -> None:
    """A B3 sign is on the priority road itself, so the link stays priority."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    signs = [_sign("B3", 0.0, 0.0005)]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "ndw_b3"


def test_roundabout_wins_over_priority_tag() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [
        _osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"junction": "roundabout"}),
    ]
    signs = [
        _sign("B1", 0.0, 0.0005),
        _sign("D1", 0.0, 0.0005),
    ]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, osm_elements=osm, traffic_sign_features=signs
    )
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is True
    assert props["priorityRoadSource"] == "osm_roundabout"
    assert props["priorityRoad"] is True


def _make_oneway_link(link_id, from_node, to_node, coords) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "mode": "CAR",
            "reverseLinkIds": [],
        },
    }


def test_geometry_roundabout_without_d1_is_not_roundabout() -> None:
    """A circular ring without a D1 sign is not marked as roundabout."""
    import math

    m_per_deg = 111_000.0
    radius_m = 25.0
    radius_deg = radius_m / m_per_deg
    n = 4
    points = [
        [radius_deg * math.cos(2 * math.pi * i / n), radius_deg * math.sin(2 * math.pi * i / n)]
        for i in range(n + 1)
    ]
    features = [
        _make_oneway_link(i + 1, i, (i + 1) % n, [points[i], points[i + 1]]) for i in range(n)
    ]

    fc = {"type": "FeatureCollection", "features": features}
    result, _give_ways = enrich_network_with_priority_and_roundabouts(fc)
    for f in result["features"]:
        assert f["properties"]["isRoundabout"] is False


def test_geometry_roundabout_with_d1_is_marked() -> None:
    """A circular ring with an NDW D1 sign is marked as roundabout and priority."""
    import math

    m_per_deg = 111_000.0
    radius_m = 25.0
    radius_deg = radius_m / m_per_deg
    n = 4
    points = [
        [radius_deg * math.cos(2 * math.pi * i / n), radius_deg * math.sin(2 * math.pi * i / n)]
        for i in range(n + 1)
    ]
    features = [
        _make_oneway_link(i + 1, i, (i + 1) % n, [points[i], points[i + 1]]) for i in range(n)
    ]
    # Add an unrelated two-way CAR link to make sure it is ignored.
    features.append(
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [0.001, 0.0]]},
            "properties": {
                "linkId": 10,
                "fromNode": "X",
                "toNode": "Y",
                "mode": "CAR",
                "reverseLinkIds": [11],
            },
        }
    )

    # D1 sign in the centre of the ring.
    signs = [_sign("D1", 0.0, 0.0)]
    fc = {"type": "FeatureCollection", "features": features}
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    ring_props = [f["properties"] for f in result["features"][:4]]
    for props in ring_props:
        assert props["isRoundabout"] is True
        assert props["roundaboutType"] == "roundabout"
        assert props["priorityRoad"] is True
        assert props["priorityRoadSource"] == "geometry_roundabout"
    unrelated = result["features"][4]["properties"]
    assert unrelated["isRoundabout"] is False


def test_geometry_ignores_open_chain() -> None:
    """An open chain of one-way CAR links must not be marked as roundabout."""
    features = [
        _make_oneway_link(1, "A", "B", [[0.0, 0.0], [0.001, 0.0]]),
        _make_oneway_link(2, "B", "C", [[0.001, 0.0], [0.002, 0.0]]),
        _make_oneway_link(3, "C", "D", [[0.002, 0.0], [0.003, 0.0]]),
    ]
    fc = {"type": "FeatureCollection", "features": features}
    result, _give_ways = enrich_network_with_priority_and_roundabouts(fc)
    for f in result["features"]:
        assert f["properties"]["isRoundabout"] is False


def test_geometry_wins_over_osm_roundabout_tag() -> None:
    """Geometry classification overwrites an OSM roundabout tag when a D1 is present."""
    import math

    m_per_deg = 111_000.0
    radius_m = 25.0
    radius_deg = radius_m / m_per_deg
    n = 4
    points = [
        [radius_deg * math.cos(2 * math.pi * i / n), radius_deg * math.sin(2 * math.pi * i / n)]
        for i in range(n + 1)
    ]
    features = [
        _make_oneway_link(i + 1, i, (i + 1) % n, [points[i], points[i + 1]]) for i in range(n)
    ]
    fc = {"type": "FeatureCollection", "features": features}
    osm = [_osm_way("W1", points[:2], {"junction": "roundabout"})]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(fc, osm_elements=osm)
    for f in result["features"]:
        props = f["properties"]
        assert props["isRoundabout"] is True
        assert props["priorityRoad"] is True
        assert props["priorityRoadSource"] == "geometry_roundabout"
        assert props["roundaboutType"] == "roundabout"


def test_sign_cluster_marks_links_without_ring_topology() -> None:
    """A tight group of >= 3 D1 signs marks nearby one-way links, no ring needed."""
    import math

    m_per_deg = 111_000.0
    radius_m = 25.0
    radius_deg = radius_m / m_per_deg
    stub_deg = 2.0 / m_per_deg
    n = 4
    centers = [
        [radius_deg * math.cos(2 * math.pi * i / n), radius_deg * math.sin(2 * math.pi * i / n)]
        for i in range(n)
    ]
    # Each link is a short, isolated stub near one of 4 compass points around the
    # circle — endpoints never connect between links, so no ring can be chained.
    features = [
        _make_oneway_link(
            i + 1, f"N{i}a", f"N{i}b", [centers[i], [centers[i][0] + stub_deg, centers[i][1]]]
        )
        for i in range(n)
    ]
    signs = [_sign("D1", c[0], c[1]) for c in centers]
    fc = {"type": "FeatureCollection", "features": features}
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    for f in result["features"]:
        props = f["properties"]
        assert props["isRoundabout"] is True
        assert props["roundaboutType"] == "roundabout"
        assert props["priorityRoad"] is True
        assert props["priorityRoadSource"] == "ndw_d1_cluster"


def test_sign_cluster_below_min_not_marked() -> None:
    """Only 2 D1 signs (below the default minimum of 3) do not trigger marking."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _make_oneway_link(1, "A", "B", [[0.0, 0.0], [0.0001, 0.0]]),
            _make_oneway_link(2, "C", "D", [[0.0, 0.0002], [0.0001, 0.0002]]),
        ],
    }
    signs = [_sign("D1", 0.0, 0.0), _sign("D1", 0.0, 0.0002)]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    for f in result["features"]:
        assert f["properties"]["isRoundabout"] is False
        assert f["properties"]["priorityRoadSource"] != "ndw_d1_cluster"


def test_sign_cluster_wide_spacing_does_not_chain() -> None:
    """D1 signs spaced farther apart than cluster_gap_m never chain into one cluster."""
    # ~100m between consecutive signs, well beyond the default 60m cluster_gap_m.
    lat_step = 100.0 / 111_000.0
    fc = {
        "type": "FeatureCollection",
        "features": [
            _make_oneway_link(1, "A", "B", [[0.0, 0.0], [0.0001, 0.0]]),
            _make_oneway_link(2, "C", "D", [[0.0, lat_step], [0.0001, lat_step]]),
            _make_oneway_link(3, "E", "F", [[0.0, 2 * lat_step], [0.0001, 2 * lat_step]]),
        ],
    }
    signs = [
        _sign("D1", 0.0, 0.0),
        _sign("D1", 0.0, lat_step),
        _sign("D1", 0.0, 2 * lat_step),
    ]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    for f in result["features"]:
        assert f["properties"]["isRoundabout"] is False


def test_sign_cluster_ignores_unrelated_through_road_and_twoway_link() -> None:
    """A through-road and a two-way link near the cluster are not marked."""
    import math

    m_per_deg = 111_000.0
    radius_m = 25.0
    radius_deg = radius_m / m_per_deg
    stub_deg = 2.0 / m_per_deg
    n = 4
    centers = [
        [radius_deg * math.cos(2 * math.pi * i / n), radius_deg * math.sin(2 * math.pi * i / n)]
        for i in range(n)
    ]
    features = [
        _make_oneway_link(
            i + 1, f"N{i}a", f"N{i}b", [centers[i], [centers[i][0] + stub_deg, centers[i][1]]]
        )
        for i in range(n)
    ]
    # One-way through-road: both endpoints far (~1.1km) outside the cluster region.
    features.append(_make_oneway_link(5, "X", "Y", [[-0.01, 0.0], [0.01, 0.0]]))
    # Two-way CAR link with both endpoints well inside the cluster region.
    features.append(
        {
            "type": "Feature",
            "geometry": {
                "type": "LineString",
                "coordinates": [[0.0001, 0.0001], [0.0001, -0.0001]],
            },
            "properties": {
                "linkId": 6,
                "fromNode": "P",
                "toNode": "Q",
                "mode": "CAR",
                "reverseLinkIds": [-6],
            },
        }
    )
    signs = [_sign("D1", c[0], c[1]) for c in centers]
    fc = {"type": "FeatureCollection", "features": features}
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    through_road = next(f for f in result["features"] if f["properties"]["linkId"] == 5)
    twoway_link = next(f for f in result["features"] if f["properties"]["linkId"] == 6)
    assert through_road["properties"]["isRoundabout"] is False
    assert twoway_link["properties"]["isRoundabout"] is False


def test_sign_cluster_defers_to_geometry_ring_when_both_present() -> None:
    """When both the cluster and the geometry-ring path find the same ring, geometry wins."""
    import math

    m_per_deg = 111_000.0
    radius_m = 25.0
    radius_deg = radius_m / m_per_deg
    n = 4
    points = [
        [radius_deg * math.cos(2 * math.pi * i / n), radius_deg * math.sin(2 * math.pi * i / n)]
        for i in range(n + 1)
    ]
    features = [
        _make_oneway_link(i + 1, i, (i + 1) % n, [points[i], points[i + 1]]) for i in range(n)
    ]
    # 3 D1 signs around the ring's vertices, close enough to chain into one cluster
    # whose region also covers the whole ring, so both paths independently qualify.
    signs = [_sign("D1", *points[i]) for i in range(3)]
    fc = {"type": "FeatureCollection", "features": features}
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    for f in result["features"]:
        props = f["properties"]
        assert props["isRoundabout"] is True
        assert props["priorityRoadSource"] == "geometry_roundabout"


def test_sign_cluster_defers_to_osm_tag_when_both_present() -> None:
    """When both the cluster path and an OSM roundabout tag match, OSM tag wins."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _make_oneway_link(1, "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [_osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"junction": "roundabout"})]
    # 3 D1 signs spread along the link so the cluster's region covers both endpoints.
    signs = [
        _sign("D1", 0.0, 0.0001),
        _sign("D1", 0.0, 0.0005),
        _sign("D1", 0.0, 0.0009),
    ]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, osm_elements=osm, traffic_sign_features=signs
    )
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is True
    assert props["priorityRoadSource"] == "osm_roundabout"


def test_osm_roundabout_tag_without_d1_is_not_roundabout() -> None:
    """An OSM roundabout tag alone no longer marks links as roundabout."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    osm = [_osm_way("W1", [[0.0, 0.0], [0.0, 0.001]], {"junction": "roundabout"})]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(fc, osm_elements=osm)
    props = result["features"][0]["properties"]
    assert props["isRoundabout"] is False
    assert props["roundaboutType"] == "none"


def test_ndw_b1_matches_road_section_id() -> None:
    """Exact roadSectionId match marks the right link and its opposite."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(
                1, "A", "B", [[0.0, 0.0], [0.0, 0.001]], wvk_ids=["WVK_1"], reverse_link_ids=[-1]
            ),
            _directed_net_link(
                -1, "B", "A", [[0.0, 0.001], [0.0, 0.0]], wvk_ids=["WVK_1"], reverse_link_ids=[1]
            ),
        ],
    }
    # Sign placed on the heen link.
    signs = [_sign("B1", 0.0, 0.0005, road_section_id="WVK_1", driving_direction="H")]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    heen_props = result["features"][0]["properties"]
    terug_props = result["features"][1]["properties"]
    assert heen_props["priorityRoad"] is True
    assert heen_props["priorityRoadSource"] == "ndw_b1"
    assert terug_props["priorityRoad"] is True
    assert terug_props["priorityRoadSource"] == "ndw_b1_opposite"


def test_ndw_b1_road_section_id_direction_terug() -> None:
    """Exact roadSectionId match honours drivingDirection == 'T' and mirrors."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(
                1, "A", "B", [[0.0, 0.0], [0.0, 0.001]], wvk_ids=["WVK_1"], reverse_link_ids=[-1]
            ),
            _directed_net_link(
                -1, "B", "A", [[0.0, 0.001], [0.0, 0.0]], wvk_ids=["WVK_1"], reverse_link_ids=[1]
            ),
        ],
    }
    signs = [_sign("B1", 0.0, 0.0005, road_section_id="WVK_1", driving_direction="T")]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    heen_props = result["features"][0]["properties"]
    terug_props = result["features"][1]["properties"]
    assert terug_props["priorityRoad"] is True
    assert terug_props["priorityRoadSource"] == "ndw_b1"
    assert heen_props["priorityRoad"] is True
    assert heen_props["priorityRoadSource"] == "ndw_b1_opposite"


def test_ndw_b1_road_section_id_takes_priority_over_distance() -> None:
    """An exact roadSectionId match wins even if a different link is closer."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(
                1, "A", "B", [[0.0, 0.0], [0.0, 0.001]], wvk_ids=["WVK_1"], reverse_link_ids=[-1]
            ),
            # Closer link with a different WVK_ID; sign geometry sits right above it.
            _directed_net_link(
                2, "C", "D", [[0.0, 0.0], [0.0, 0.0001]], wvk_ids=["WVK_2"], reverse_link_ids=[-2]
            ),
        ],
    }
    # Sign placed on the further link but physically above the closer link.
    signs = [_sign("B1", 0.0, 0.00005, road_section_id="WVK_1", driving_direction="H")]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    matched_props = result["features"][0]["properties"]
    closer_props = result["features"][1]["properties"]
    assert matched_props["priorityRoad"] is True
    assert matched_props["priorityRoadSource"] == "ndw_b1"
    assert closer_props["priorityRoad"] is False


def test_ndw_b1_unknown_road_section_id_falls_back_to_distance() -> None:
    """Unknown roadSectionId falls back to distance snapping."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(
                1, "A", "B", [[0.0, 0.0], [0.0, 0.001]], wvk_ids=["WVK_1"], reverse_link_ids=[-1]
            ),
        ],
    }
    signs = [_sign("B1", 0.0, 0.0005, road_section_id="UNKNOWN", driving_direction="H")]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "ndw_b1"


def test_ndw_b1_missing_road_section_id_falls_back_to_distance() -> None:
    """Missing roadSectionId falls back to distance snapping."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _net_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    signs = [_sign("B1", 0.0, 0.0005)]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    props = result["features"][0]["properties"]
    assert props["priorityRoad"] is True
    assert props["priorityRoadSource"] == "ndw_b1"


def test_derived_give_way_at_priority_road_junction() -> None:
    """A non-priority link whose toNode leads into a priority link gets a giveWay marker."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [0.0, 0.001]]},
                "properties": {
                    "linkId": 1,
                    "fromNode": "A",
                    "toNode": "B",
                    "mode": "CAR",
                    "priorityRoad": False,
                    "priorityRoadSource": "none",
                },
            },
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.0, 0.001], [0.001, 0.001]]},
                "properties": {
                    "linkId": 2,
                    "fromNode": "B",
                    "toNode": "C",
                    "mode": "CAR",
                    "priorityRoad": True,
                    "priorityRoadSource": "ndw_b1",
                },
            },
        ],
    }
    result, give_ways = enrich_network_with_priority_and_roundabouts(fc)
    assert len(give_ways) == 1
    assert give_ways[0]["properties"]["assetType"] == "giveWay"
    assert give_ways[0]["properties"]["linkId"] == 1
    assert give_ways[0]["properties"]["nodeId"] == "B"
    assert give_ways[0]["geometry"]["type"] == "LineString"
    assert len(give_ways[0]["geometry"]["coordinates"]) == 2
    # numGiveWays is stricter: it requires priority both in and out of the node.
    assert result["features"][0]["properties"]["numGiveWays"] == 0
    assert result["features"][1]["properties"]["numGiveWays"] == 0


def test_num_give_ways_requires_double_priority_junction() -> None:
    """A non-priority link only gets numGiveWays when priority both in and out."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [0.0, 0.001]]},
                "properties": {
                    "linkId": 1,
                    "fromNode": "A",
                    "toNode": "B",
                    "mode": "CAR",
                    "priorityRoad": False,
                    "priorityRoadSource": "none",
                },
            },
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.0, 0.001], [0.001, 0.001]]},
                "properties": {
                    "linkId": 2,
                    "fromNode": "B",
                    "toNode": "C",
                    "mode": "CAR",
                    "priorityRoad": True,
                    "priorityRoadSource": "ndw_b1",
                },
            },
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.001, 0.002], [0.0, 0.001]]},
                "properties": {
                    "linkId": 3,
                    "fromNode": "D",
                    "toNode": "B",
                    "mode": "CAR",
                    "priorityRoad": True,
                    "priorityRoadSource": "ndw_b1",
                },
            },
        ],
    }
    result, _give_ways = enrich_network_with_priority_and_roundabouts(fc)
    assert result["features"][0]["properties"]["numGiveWays"] == 1
    assert result["features"][1]["properties"]["numGiveWays"] == 0
    assert result["features"][2]["properties"]["numGiveWays"] == 0


def test_num_give_ways_b3_ends_priority() -> None:
    """A priority link carrying a B3 sign gets numGiveWays at its end."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(
                1, "A", "B", [[0.0, 0.0], [0.0, 0.001]], wvk_ids=["WVK_1"], reverse_link_ids=[-1]
            ),
        ],
    }
    signs = [_sign("B3", 0.0, 0.0005, road_section_id="WVK_1", driving_direction="H")]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    assert result["features"][0]["properties"]["numGiveWays"] == 1


def test_num_give_ways_priority_link_without_b3_gets_zero() -> None:
    """A normal priority link without a B3 sign does not get numGiveWays."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(
                1, "A", "B", [[0.0, 0.0], [0.0, 0.001]], wvk_ids=["WVK_1"], reverse_link_ids=[-1]
            ),
        ],
    }
    signs = [_sign("B1", 0.0, 0.0005, road_section_id="WVK_1", driving_direction="H")]
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    assert result["features"][0]["properties"]["numGiveWays"] == 0


def test_num_give_ways_roundabout_gets_zero() -> None:
    """Roundabout links never get numGiveWays."""
    import math

    m_per_deg = 111_000.0
    radius_m = 25.0
    radius_deg = radius_m / m_per_deg
    n = 4
    points = [
        [radius_deg * math.cos(2 * math.pi * i / n), radius_deg * math.sin(2 * math.pi * i / n)]
        for i in range(n + 1)
    ]
    features = [
        _make_oneway_link(i + 1, i, (i + 1) % n, [points[i], points[i + 1]]) for i in range(n)
    ]
    signs = [_sign("D1", 0.0, 0.0)]
    fc = {"type": "FeatureCollection", "features": features}
    result, _give_ways = enrich_network_with_priority_and_roundabouts(
        fc, traffic_sign_features=signs
    )
    for f in result["features"]:
        assert f["properties"]["numGiveWays"] == 0
