"""
Integration tests with real fixture data.

Run with:  pytest tests/test_real_data.py -v
"""

from __future__ import annotations

import datetime
import json
from pathlib import Path

from flow_scaler.core.flow_scaler_core import (
    Params,
    applyIndices,
    filterNetwork,
    load_purpose_index,
    resolve_indexes_by_mode,
)

PURPOSE_INDEX = [
    {"key": "work|CAR|1|8|Medium|Cloudy Light", "index": 2.0},
    {"key": "education|CAR|1|8|Medium|Cloudy Light", "index": 1.5},
    {"key": "shopping|CAR|1|8|Medium|Cloudy Light", "index": 0.8},
    {"key": "recreational|CAR|1|8|Medium|Cloudy Light", "index": 0.5},
    {"key": "unknown|CAR|1|8|Medium|Cloudy Light", "index": 1.0},
]

FIXTURES_DIR = Path(__file__).parent / "fixtures"


class TestResponseStructure:
    def test_type_is_feature_collection(self):
        with open(FIXTURES_DIR / "network.geojson") as f:
            network = json.load(f)

            bbox: list[float] | None = None
            params = Params(
                mode="CAR",
                dt=datetime.datetime(2025, 1, 13, 8, 0, tzinfo=datetime.UTC),
                temperature="Medium",
                weather="Cloudy Light",
                regio="",
                purpose="work",
            )

            filtered = filterNetwork(network, bbox, 1, 1)
            filtered.params = params

            raw_heen: dict = filtered.features[0]["properties"].get("flow_heen") or {}
            raw_terug: dict = filtered.features[0]["properties"].get("flow_terug") or {}
            org_flow = raw_heen["work"] + raw_terug["work"]

            filtered.features[0]["properties"].pop("trip_lengths", None)

            purpose_index = load_purpose_index(PURPOSE_INDEX)
            indexes_by_mode = resolve_indexes_by_mode(params, filtered, purpose_index)

            result = applyIndices(filtered, indexes_by_mode)

            result_flow = result["features"][0]["properties"]["flow"]

            assert org_flow == result_flow / 2.0

    def test_type_is_feature_collection2(self):
        with open(FIXTURES_DIR / "deventer-car.json") as f:
            network = json.load(f)

            bbox: list[float] | None = None
            params = Params(
                mode="CAR",
                dt=datetime.datetime(2025, 1, 13, 8, 0, tzinfo=datetime.UTC),
                temperature="Medium",
                weather="Cloudy Light",
                regio="",
                purpose="work",
            )

            filtered = filterNetwork(network, bbox, 1, 1)
            filtered.params = params

            props0 = filtered.features[0]["properties"]
            raw_flow_dict: dict = props0.get("flowsPerMotive") or {}
            if raw_flow_dict:
                org_flow_work = raw_flow_dict.get("work", 0.0)
            else:
                raw_heen: dict = props0.get("flow_heen") or {}
                raw_terug: dict = props0.get("flow_terug") or {}
                org_flow_work = raw_heen.get("work", 0.0) + raw_terug.get("work", 0.0)

            filtered.features[0]["properties"].pop("trip_lengths", None)

            purpose_index = load_purpose_index(PURPOSE_INDEX)
            indexes_by_mode = resolve_indexes_by_mode(params, filtered, purpose_index)

            result = applyIndices(filtered, indexes_by_mode)

            result_flow = result["features"][0]["properties"]["flow"]

            assert abs(org_flow_work - result_flow / 2.0) < 1e-9, (
                f"Expected org_flow_work={org_flow_work} == result_flow/2={result_flow / 2.0}"
            )
