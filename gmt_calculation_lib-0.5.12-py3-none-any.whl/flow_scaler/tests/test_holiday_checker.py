"""
Tests for flow_scaler.flow_scaler_core.is_holiday_period().

Run with:  pytest src/flow_scaler/tests/ -v
"""

from __future__ import annotations

import datetime

import pytest

import flow_scaler.core.flow_scaler_core as _checker
from flow_scaler.core.flow_scaler_core import is_holiday_period

# ---------------------------------------------------------------------------
# In-memory test fixture data  (mirrors real CSV column names)
# ---------------------------------------------------------------------------

_TEST_ROWS: list[dict[str, str]] = [
    # Week 1 – midden: BIKE trip_index below threshold; CAR just above
    {
        "regio": "midden",
        "weeknr": "1",
        "trip_mode": "BIKE",
        "vakantie_am": "",
        "vakantie_weeknr": "",
        "avg_trips_per_day": "2.14",
        "avg_trips_non_vacation": "2.636",
        "trip_index": "0.8118",
    },
    {
        "regio": "midden",
        "weeknr": "1",
        "trip_mode": "CAR",
        "vakantie_am": "",
        "vakantie_weeknr": "",
        "avg_trips_per_day": "2.86",
        "avg_trips_non_vacation": "3.349",
        "trip_index": "0.8540",
    },
    # Week 9 – midden: voorjaarsvakantie; trip_index above threshold
    {
        "regio": "midden",
        "weeknr": "9",
        "trip_mode": "BIKE",
        "vakantie_am": "voorjaarsvakantie",
        "vakantie_weeknr": "1",
        "avg_trips_per_day": "2.504",
        "avg_trips_non_vacation": "2.636",
        "trip_index": "0.9499",
    },
    {
        "regio": "midden",
        "weeknr": "9",
        "trip_mode": "CAR",
        "vakantie_am": "voorjaarsvakantie",
        "vakantie_weeknr": "1",
        "avg_trips_per_day": "3.194",
        "avg_trips_non_vacation": "3.349",
        "trip_index": "0.9538",
    },
    # Week 10 – midden: no holiday, trip_index well above threshold
    {
        "regio": "midden",
        "weeknr": "10",
        "trip_mode": "BIKE",
        "vakantie_am": "",
        "vakantie_weeknr": "",
        "avg_trips_per_day": "2.661",
        "avg_trips_non_vacation": "2.636",
        "trip_index": "1.0093",
    },
    # Week 1 – noord: BIKE below threshold; CAR above threshold
    {
        "regio": "noord",
        "weeknr": "1",
        "trip_mode": "BIKE",
        "vakantie_am": "",
        "vakantie_weeknr": "",
        "avg_trips_per_day": "2.10",
        "avg_trips_non_vacation": "2.50",
        "trip_index": "0.84",
    },
    {
        "regio": "noord",
        "weeknr": "1",
        "trip_mode": "CAR",
        "vakantie_am": "",
        "vakantie_weeknr": "",
        "avg_trips_per_day": "2.90",
        "avg_trips_non_vacation": "3.00",
        "trip_index": "0.96",
    },
]

# ---------------------------------------------------------------------------
# Shared fixture: replace _load_csv so no S3 / filesystem access is needed
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def _patch_load_csv(monkeypatch):
    """Inject in-memory rows and clear the module cache around each test."""
    _checker._clear_csv_cache()
    monkeypatch.setattr(_checker, "_load_csv", lambda _bucket, _key: list(_TEST_ROWS))
    yield
    _checker._clear_csv_cache()


# ---------------------------------------------------------------------------
# Date helpers
#   2025-01-01 (Wednesday) → ISO week 1
#   2025-02-24 (Monday)    → ISO week 9
#   2025-03-03 (Monday)    → ISO week 10
#   2025-01-27 (Monday)    → ISO week 5  (not present in fixture → unknown)
# ---------------------------------------------------------------------------

_W1 = datetime.date(2025, 1, 1)
_W9 = datetime.date(2025, 2, 24)
_W10 = datetime.date(2025, 3, 3)
_W5 = datetime.date(2025, 1, 27)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestIsHolidayPeriod:
    # --- trip_index threshold ---

    def test_trip_index_below_threshold_returns_true(self):
        """midden BIKE week 1: trip_index=0.8118 < 0.85, no holiday → True."""
        assert is_holiday_period("midden", "BIKE", _W1) is True

    def test_trip_index_at_threshold_returns_false(self):
        """midden CAR week 1: trip_index=0.854 >= 0.85, no holiday → False."""
        assert is_holiday_period("midden", "CAR", _W1) is False

    # --- vakantie_naam ---

    def test_vakantie_naam_returns_true(self):
        """midden BIKE week 9: has holiday name → True regardless of trip_index."""
        assert is_holiday_period("midden", "BIKE", _W9) is True

    def test_vakantie_naam_overrides_high_trip_index(self):
        """midden CAR week 9: trip_index=0.9538 >= 0.85 but has holiday → True."""
        assert is_holiday_period("midden", "CAR", _W9) is True

    def test_no_condition_met_returns_false(self):
        """midden BIKE week 10: no holiday, trip_index=1.009 → False."""
        assert is_holiday_period("midden", "BIKE", _W10) is False

    # --- case insensitivity ---

    def test_regio_is_case_insensitive(self):
        """Upper-case regio should match the same row."""
        assert is_holiday_period("MIDDEN", "BIKE", _W1) is True

    def test_mode_is_case_insensitive(self):
        """Lower-case mode should match the same row."""
        assert is_holiday_period("midden", "bike", _W1) is True

    # --- no matching row ---

    def test_unknown_regio_returns_false(self):
        """No row for unknown regio → False."""
        assert is_holiday_period("west", "BIKE", _W1) is False

    def test_unknown_mode_returns_false(self):
        """No row for unknown mode → False."""
        assert is_holiday_period("midden", "TRAM", _W1) is False

    def test_week_not_in_csv_returns_false(self):
        """No row for a week absent from the CSV → False."""
        assert is_holiday_period("midden", "BIKE", _W5) is False

    # --- different region ---

    def test_different_regio_low_trip_index(self):
        """noord BIKE week 1: trip_index=0.84 < 0.85 → True."""
        assert is_holiday_period("noord", "BIKE", _W1) is True

    def test_different_regio_high_trip_index(self):
        """noord CAR week 1: trip_index=0.96, no holiday → False."""
        assert is_holiday_period("noord", "CAR", _W1) is False

    # --- date type ---

    def test_datetime_object_is_accepted(self):
        """datetime.datetime (a date subclass) is a valid argument."""
        dt = datetime.datetime(2025, 1, 1, 12, 0, 0)  # noqa: DTZ001  # naive input under test
        assert is_holiday_period("midden", "BIKE", dt) is True
