"""Tests for prepare.core.traffic_asset_sources."""

from __future__ import annotations

from typing import cast

import pytest
from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

from prepare.core import traffic_asset_sources as tas

_BBOX = [6.0, 52.0, 6.1, 52.1]


def _pt(asset_type: str, **props) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [6.05, 52.05]},
        "properties": {"assetType": asset_type, **props},
    }


def _write(path, features, props=None):
    fc = {"type": "FeatureCollection", "features": features, "properties": props or {}}
    path.write_bytes(to_geoparquet(fc))


def _read(path) -> dict:
    return cast(dict, from_geoparquet(path.read_bytes()))


@pytest.fixture
def fake_fetch(monkeypatch):
    """Replace the network fetches with canned per-source results."""
    results: dict[str, list[dict] | Exception] = {}

    def _fake(src, _bbox, **_kw):
        res = results[src]
        if isinstance(res, Exception):
            raise res
        return [dict(f, properties=dict(f["properties"])) for f in res], "test"

    monkeypatch.setattr(tas, "_fetch_source", _fake)
    return results


class TestSourcesForAssetTypes:
    def test_categories_nl(self):
        assert tas.sources_for_asset_types(["trashBin", "footPath"], in_nl=True) == {"osm"}
        assert tas.sources_for_asset_types(["bridge", "bak"], in_nl=True) == {"bgt"}
        assert tas.sources_for_asset_types(["speedBump"], in_nl=True) == {"bgt"}

    def test_abroad_has_no_bgt(self):
        assert tas.sources_for_asset_types(["speedBump"], in_nl=False) == {"osm"}
        assert tas.sources_for_asset_types(["bridge"], in_nl=False) == set()

    def test_npr_parking_nl_only(self):
        assert tas.sources_for_asset_types(["parkingFacility"], in_nl=True) == {"npr_parking"}
        assert tas.sources_for_asset_types(["parkingFacility"], in_nl=False) == set()

    def test_unknown_types_need_nothing(self):
        assert tas.sources_for_asset_types(["viaduct", "culvert"], in_nl=True) == set()

    def test_none_means_all(self):
        assert tas.sources_for_asset_types(None, in_nl=False) == {
            "osm",
            "signs",
            "signals",
            "parking",
        }


class TestReadSources:
    def test_missing_file(self, tmp_path):
        assert tas.read_sources(tmp_path / "nope.parquet") == {}

    def test_register_from_footer(self, tmp_path):
        p = tmp_path / "TA.parquet"
        _write(p, [_pt("trashBin")], {"sources": {"osm": {"count": 1}}})
        assert tas.read_sources(p) == {"osm": {"count": 1}}

    def test_legacy_inference(self, tmp_path):
        p = tmp_path / "TA.parquet"
        _write(
            p,
            [
                _pt("trashBin", osm_id=1),
                _pt("speedBump", osm_id=2),
                _pt("speedBump"),
                _pt("bridge"),
                _pt("trafficSign"),
                _pt("trafficSignal"),
            ],
        )
        reg = tas.read_sources(p)
        assert {k: v["count"] for k, v in reg.items()} == {
            "osm": 2,
            "bgt": 2,
            "signs": 1,
            "signals": 1,
        }
        assert all(v["legacy"] for v in reg.values())


class TestAddTrafficAssetSources:
    def test_creates_file_and_registers_zero_count(self, tmp_path, fake_fetch):
        p = tmp_path / "TA.parquet"
        fake_fetch["osm"] = [_pt("trashBin"), _pt("footPath")]
        fake_fetch["signals"] = []
        reg = tas.add_traffic_asset_sources(
            p, area_id="A", bbox=_BBOX, sources=["osm", "signals"], in_nl=True
        )
        assert reg["osm"]["count"] == 2
        assert reg["signals"]["count"] == 0
        fc = _read(p)
        assert fc["properties"]["sources"].keys() == {"osm", "signals"}
        assert {f["properties"]["src"] for f in fc["features"]} == {"osm"}

    def test_merge_replaces_only_own_source(self, tmp_path, fake_fetch):
        p = tmp_path / "TA.parquet"
        _write(
            p,
            [_pt("trashBin", src="osm"), _pt("trafficSign", src="signs")],
            {"sources": {"osm": {"count": 1}, "signs": {"count": 1}}},
        )
        fake_fetch["osm"] = [_pt("mailbox"), _pt("mailbox")]
        tas.add_traffic_asset_sources(p, area_id="A", bbox=_BBOX, sources=["osm"], in_nl=True)
        fc = _read(p)
        types = sorted(f["properties"]["assetType"] for f in fc["features"])
        assert types == ["mailbox", "mailbox", "trafficSign"]
        assert fc["properties"]["sources"]["osm"]["count"] == 2
        assert fc["properties"]["sources"]["signs"]["count"] == 1

    def test_bgt_replaces_osm_speed_bumps(self, tmp_path, fake_fetch):
        p = tmp_path / "TA.parquet"
        _write(p, [_pt("speedBump", osm_id=5), _pt("trashBin", osm_id=6)])  # legacy file
        fake_fetch["bgt"] = [_pt("speedBump"), _pt("bridge")]
        reg = tas.add_traffic_asset_sources(p, area_id="A", bbox=_BBOX, sources=["bgt"], in_nl=True)
        fc = _read(p)
        by_src = sorted(
            (f["properties"]["src"], f["properties"]["assetType"]) for f in fc["features"]
        )
        assert by_src == [("bgt", "bridge"), ("bgt", "speedBump"), ("osm", "trashBin")]
        assert reg["osm"]["count"] == 1

    def test_failed_source_not_registered_but_others_written(self, tmp_path, fake_fetch):
        p = tmp_path / "TA.parquet"
        fake_fetch["osm"] = RuntimeError("overpass down")
        fake_fetch["signs"] = [_pt("trafficSign")]
        with pytest.raises(RuntimeError):
            tas.add_traffic_asset_sources(
                p, area_id="A", bbox=_BBOX, sources=["osm", "signs"], in_nl=True
            )
        assert set(tas.read_sources(p)) == {"signs"}

    @pytest.mark.usefixtures("fake_fetch")
    def test_bgt_skipped_abroad(self, tmp_path):
        p = tmp_path / "TA.parquet"
        reg = tas.add_traffic_asset_sources(
            p, area_id="A", bbox=_BBOX, sources=["bgt"], in_nl=False
        )
        assert reg == {}
        assert not p.exists()

    def test_npr_parking_added(self, tmp_path, fake_fetch):
        p = tmp_path / "TA.parquet"
        fake_fetch["npr_parking"] = [_pt("parkingFacility")]
        reg = tas.add_traffic_asset_sources(
            p, area_id="A", bbox=_BBOX, sources=["npr_parking"], in_nl=True
        )
        assert reg["npr_parking"]["count"] == 1
        fc = _read(p)
        assert {f["properties"]["src"] for f in fc["features"]} == {"npr_parking"}

    @pytest.mark.usefixtures("fake_fetch")
    def test_npr_parking_skipped_abroad(self, tmp_path):
        p = tmp_path / "TA.parquet"
        reg = tas.add_traffic_asset_sources(
            p, area_id="A", bbox=_BBOX, sources=["npr_parking"], in_nl=False
        )
        assert reg == {}
        assert not p.exists()
