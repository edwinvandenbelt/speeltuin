"""Tests for zone_population_estimator domain modules and core.

Covers:
- gisco.find_nuts — parses NUTS code and level, raises on empty response
- gisco.reverse_geocode — parses name, returns empty dict on failure
- eurostat.fetch_population — parses SDMX JSON, picks most recent year,
  NUTS fallback, raises when no data at any level
- distributor.distribute_population — proportional, equal fallback, empty FC
- attraction.compute_attraction — default factors, custom factors, unknown type,
  house contributes zero
- estimate_zone_population (integration) — all external calls mocked
"""

from __future__ import annotations

import json
from typing import ClassVar
from unittest.mock import MagicMock, patch

import pytest

from osm.zone_population_estimator.domain.attraction import (
    DEFAULT_ATTRACTION_FACTORS,
    compute_attraction,
)
from osm.zone_population_estimator.domain.distributor import distribute_population

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _zone_feature(zone_id: str, building_types: dict) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 0]]]},
        "properties": {
            "zoneId": zone_id,
            "buildingByType": building_types,
            "nBuildings": 5,
            "totalFootprintM2": sum(building_types.values()),
        },
    }


def _zone_feature_with_parking(zone_id: str, building_types: dict, parking_capacity: int) -> dict:
    feat = _zone_feature(zone_id, building_types)
    feat["properties"]["parkingCapacity"] = parking_capacity
    return feat


def _zones_fc(*zones) -> dict:
    return {"type": "FeatureCollection", "features": list(zones)}


def _gisco_nuts_response(nuts_code: str = "NL212", level: int = 3) -> bytes:
    return json.dumps([{"attributes": {"id": nuts_code, "stat_levl_code": level}}]).encode()


def _gisco_nominatim_response(name: str = "Deventer") -> bytes:
    return json.dumps({"name": name, "display_name": f"{name}, Netherlands"}).encode()


def _eurostat_response(pop: float, year: int = 2024) -> bytes:
    """Build a minimal Eurostat SDMX JSON response."""
    # time index: {"2020": 0, "2021": 1, ..., year: N}
    start_year = 2020
    years = list(range(start_year, year + 1))
    time_index = {str(y): i for i, y in enumerate(years)}
    latest_pos = len(years) - 1
    return json.dumps(
        {
            "value": {str(latest_pos): pop},
            "dimension": {
                "time": {
                    "category": {
                        "index": time_index,
                        "label": {str(y): str(y) for y in years},
                    }
                }
            },
        }
    ).encode()


# ---------------------------------------------------------------------------
# gisco.find_nuts
# ---------------------------------------------------------------------------


class TestFindNuts:
    def _call(self, response_bytes: bytes) -> dict:
        from osm.zone_population_estimator.domain.gisco import find_nuts

        mock_resp = MagicMock()
        mock_resp.read.return_value = response_bytes
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            return find_nuts(6.16, 52.26)

    def test_returns_nuts_code(self) -> None:
        result = self._call(_gisco_nuts_response("NL212", 3))
        assert result["nuts_code"] == "NL212"

    def test_returns_nuts_level(self) -> None:
        result = self._call(_gisco_nuts_response("NL212", 3))
        assert result["nuts_level"] == 3

    def test_picks_highest_level_from_multiple(self) -> None:
        response = json.dumps(
            [
                {"attributes": {"id": "NL2", "stat_levl_code": 2}},
                {"attributes": {"id": "NL21", "stat_levl_code": 3}},
            ]
        ).encode()
        result = self._call(response)
        assert result["nuts_code"] == "NL21"

    def test_raises_on_empty_response(self) -> None:
        from osm.zone_population_estimator.domain.gisco import find_nuts

        mock_resp = MagicMock()
        mock_resp.read.return_value = b"[]"
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with (
            patch("urllib.request.urlopen", return_value=mock_resp),
            pytest.raises(ValueError, match="no NUTS region"),
        ):
            find_nuts(0.0, 0.0)


# ---------------------------------------------------------------------------
# gisco.reverse_geocode
# ---------------------------------------------------------------------------


class TestReverseGeocode:
    def _call(self, response_bytes: bytes | None = None) -> dict:
        from osm.zone_population_estimator.domain.gisco import reverse_geocode

        if response_bytes is None:
            # Simulate network failure
            with patch("urllib.request.urlopen", side_effect=OSError("timeout")):
                return reverse_geocode(6.16, 52.26)
        mock_resp = MagicMock()
        mock_resp.read.return_value = response_bytes
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            return reverse_geocode(6.16, 52.26)

    def test_returns_name(self) -> None:
        result = self._call(_gisco_nominatim_response("Deventer"))
        assert result["name"] == "Deventer"

    def test_returns_display_name(self) -> None:
        result = self._call(_gisco_nominatim_response("Deventer"))
        assert "Deventer" in result["display_name"]

    def test_returns_empty_dict_on_failure(self) -> None:
        result = self._call(None)
        assert result["name"] == ""
        assert result["display_name"] == ""


# ---------------------------------------------------------------------------
# eurostat.fetch_population
# ---------------------------------------------------------------------------


class TestFetchPopulation:
    def _urlopen(self, response_bytes: bytes):
        mock_resp = MagicMock()
        mock_resp.read.return_value = response_bytes
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        return mock_resp

    def test_returns_population(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import fetch_population

        with patch(
            "urllib.request.urlopen", return_value=self._urlopen(_eurostat_response(161927.0, 2024))
        ):
            result = fetch_population("NL212")
        assert result["population"] == pytest.approx(161927.0)

    def test_returns_most_recent_year(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import fetch_population

        with patch(
            "urllib.request.urlopen", return_value=self._urlopen(_eurostat_response(161927.0, 2024))
        ):
            result = fetch_population("NL212")
        assert result["year"] == 2024

    def test_returns_nuts_code(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import fetch_population

        with patch(
            "urllib.request.urlopen", return_value=self._urlopen(_eurostat_response(161927.0, 2024))
        ):
            result = fetch_population("NL212")
        assert result["nuts_code"] == "NL212"

    def test_nuts_fallback_on_empty_value(self) -> None:
        """When NL212 has no values, fall back to NL21 (shorter code)."""
        from osm.zone_population_estimator.domain.eurostat import fetch_population

        empty_response = json.dumps(
            {
                "value": {},
                "dimension": {
                    "time": {"category": {"index": {"2024": 0}, "label": {"2024": "2024"}}}
                },
            }
        ).encode()
        full_response = _eurostat_response(500000.0, 2024)

        responses = [empty_response, full_response]
        idx = [0]

        def side_effect(*_args, **_kwargs):
            resp = MagicMock()
            resp.read.return_value = responses[idx[0]]
            resp.__enter__ = lambda s: s
            resp.__exit__ = MagicMock(return_value=False)
            idx[0] += 1
            return resp

        with patch("urllib.request.urlopen", side_effect=side_effect):
            result = fetch_population("NL212")
        # Should have fallen back to NL21 (4-char code)
        assert result["population"] == pytest.approx(500000.0)
        assert result["nuts_code"] == "NL21"

    def test_raises_when_no_data_at_any_level(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import fetch_population

        empty = json.dumps(
            {
                "value": {},
                "dimension": {"time": {"category": {"index": {}, "label": {}}}},
            }
        ).encode()
        mock_resp = MagicMock()
        mock_resp.read.return_value = empty
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with (
            patch("urllib.request.urlopen", return_value=mock_resp),
            pytest.raises(ValueError, match="No population data"),
        ):
            fetch_population("XX")


# ---------------------------------------------------------------------------
# distributor.distribute_population
# ---------------------------------------------------------------------------


class TestDistributePopulation:
    def test_proportional_to_house_m2(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"house": 200.0}),
            _zone_feature("z2", {"house": 800.0}),
        )
        result = distribute_population(zones_fc, 1000.0)
        assert result["z1"] == pytest.approx(200.0, rel=1e-3)
        assert result["z2"] == pytest.approx(800.0, rel=1e-3)

    def test_sum_equals_total_population(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"house": 300.0, "shopping": 100.0}),
            _zone_feature("z2", {"house": 700.0}),
        )
        result = distribute_population(zones_fc, 50000.0)
        assert sum(result.values()) == pytest.approx(50000.0, rel=1e-3)

    def test_zone_without_house_gets_zero(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"house": 500.0}),
            _zone_feature("z2", {"shopping": 200.0}),
        )
        result = distribute_population(zones_fc, 1000.0)
        assert result["z2"] == pytest.approx(0.0)

    def test_all_zones_no_house_equal_distribution(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"shopping": 100.0}),
            _zone_feature("z2", {"school": 200.0}),
        )
        result = distribute_population(zones_fc, 1000.0)
        assert result["z1"] == pytest.approx(500.0, rel=1e-3)
        assert result["z2"] == pytest.approx(500.0, rel=1e-3)

    def test_zero_population_gives_zeros(self) -> None:
        zones_fc = _zones_fc(_zone_feature("z1", {"house": 100.0}))
        result = distribute_population(zones_fc, 0.0)
        assert result["z1"] == 0.0

    def test_empty_fc_returns_empty(self) -> None:
        result = distribute_population({"type": "FeatureCollection", "features": []}, 1000.0)
        assert result == {}

    def test_single_zone_gets_all_population(self) -> None:
        zones_fc = _zones_fc(_zone_feature("z1", {"house": 500.0}))
        result = distribute_population(zones_fc, 9999.0)
        assert result["z1"] == pytest.approx(9999.0, rel=1e-3)


# ---------------------------------------------------------------------------
# attraction.compute_attraction
# ---------------------------------------------------------------------------


class TestComputeAttraction:
    def test_shopping_uses_default_factor(self) -> None:
        total, by_type = compute_attraction({"shopping": 100.0})
        assert total == pytest.approx(100.0 * DEFAULT_ATTRACTION_FACTORS["shopping"])
        assert "shopping" in by_type

    def test_house_contributes_zero(self) -> None:
        total, by_type = compute_attraction({"house": 1000.0})
        assert total == pytest.approx(0.0)
        assert "house" not in by_type  # zero entries omitted

    def test_custom_factor_overrides_default(self) -> None:
        total, _ = compute_attraction({"shopping": 100.0}, factors={"shopping": 0.20})
        assert total == pytest.approx(20.0)

    def test_unknown_type_uses_other_factor(self) -> None:
        total, by_type = compute_attraction({"warehouse": 100.0})
        assert total == pytest.approx(100.0 * DEFAULT_ATTRACTION_FACTORS["other"])
        assert "warehouse" in by_type

    def test_multiple_types_sum_correctly(self) -> None:
        types = {"school": 200.0, "shopping": 100.0, "hospital": 50.0}
        expected = (
            200.0 * DEFAULT_ATTRACTION_FACTORS["school"]
            + 100.0 * DEFAULT_ATTRACTION_FACTORS["shopping"]
            + 50.0 * DEFAULT_ATTRACTION_FACTORS["hospital"]
        )
        total, _ = compute_attraction(types)
        assert total == pytest.approx(expected, rel=1e-6)

    def test_empty_types_returns_zero(self) -> None:
        total, by_type = compute_attraction({})
        assert total == 0.0
        assert by_type == {}

    def test_attraction_by_type_excludes_zeros(self) -> None:
        _total, by_type = compute_attraction({"house": 500.0, "shopping": 100.0})
        assert "house" not in by_type
        assert "shopping" in by_type

    def test_work_uses_default_factor(self) -> None:
        total, by_type = compute_attraction({"work": 100.0})
        assert total == pytest.approx(100.0 * DEFAULT_ATTRACTION_FACTORS["work"])
        assert "work" in by_type

    def test_work_factor_greater_than_other(self) -> None:
        assert DEFAULT_ATTRACTION_FACTORS["work"] > DEFAULT_ATTRACTION_FACTORS["other"]

    def test_work_factor_less_than_shopping(self) -> None:
        assert DEFAULT_ATTRACTION_FACTORS["work"] < DEFAULT_ATTRACTION_FACTORS["shopping"]


# ---------------------------------------------------------------------------
# gisco.find_lau
# ---------------------------------------------------------------------------


def _gisco_lau_response(
    lau_id: str = "NL_GM0150",
    lau_name: str = "Deventer",
    pop_year: int = 2021,
    population: int | None = 99000,
) -> bytes:
    attrs: dict = {
        "GISCO_ID": lau_id,
        "LAU_NAME": lau_name,
    }
    if population is not None:
        attrs[f"POP_{pop_year}"] = population
    return json.dumps([{"attributes": attrs}]).encode()


class TestFindLau:
    def _call(self, response_bytes: bytes | None = None, *, fail: bool = False) -> dict | None:
        from osm.zone_population_estimator.domain.gisco import find_lau

        if fail:
            with patch("urllib.request.urlopen", side_effect=OSError("timeout")):
                return find_lau(6.16, 52.26)
        mock_resp = MagicMock()
        mock_resp.read.return_value = response_bytes
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        with patch("urllib.request.urlopen", return_value=mock_resp):
            return find_lau(6.16, 52.26)

    def test_returns_lau_id(self) -> None:
        result = self._call(_gisco_lau_response("NL_GM0150", "Deventer", 2021, 99000))
        assert result is not None
        assert result["lau_id"] == "NL_GM0150"

    def test_returns_lau_name(self) -> None:
        result = self._call(_gisco_lau_response("NL_GM0150", "Deventer", 2021, 99000))
        assert result is not None
        assert result["lau_name"] == "Deventer"

    def test_returns_population_and_year(self) -> None:
        result = self._call(_gisco_lau_response("NL_GM0150", "Deventer", 2021, 99000))
        assert result is not None
        assert result["population"] == pytest.approx(99000.0)
        assert result["pop_year"] == 2021

    def test_returns_none_population_when_field_absent(self) -> None:
        result = self._call(_gisco_lau_response(population=None))
        assert result is not None
        assert result["population"] is None
        assert result["pop_year"] is None

    def test_picks_latest_pop_year(self) -> None:
        # Provide both POP_2020 and POP_2022 — should pick 2022
        attrs = {"GISCO_ID": "X", "LAU_NAME": "X", "POP_2020": 1000, "POP_2022": 2000}
        resp = json.dumps([{"attributes": attrs}]).encode()
        result = self._call(resp)
        assert result is not None
        assert result["population"] == pytest.approx(2000.0)
        assert result["pop_year"] == 2022

    def test_returns_none_on_http_error(self) -> None:
        result = self._call(fail=True)
        assert result is None

    def test_returns_none_on_empty_response(self) -> None:
        result = self._call(b"[]")
        assert result is None


# ---------------------------------------------------------------------------
# eurostat.fetch_nuts_area_km2
# ---------------------------------------------------------------------------


def _eurostat_area_response(area_km2: float, year: int = 2021) -> bytes:
    """Build a minimal Eurostat REG_AREA3 SDMX JSON response."""
    return json.dumps(
        {
            "value": {"0": area_km2},
            "dimension": {
                "time": {
                    "category": {
                        "index": {str(year): 0},
                        "label": {str(year): str(year)},
                    }
                }
            },
        }
    ).encode()


class TestFetchNutsAreaKm2:
    def _urlopen(self, response_bytes: bytes):
        mock_resp = MagicMock()
        mock_resp.read.return_value = response_bytes
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)
        return mock_resp

    def test_returns_area(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import (
            fetch_nuts_area_km2,
        )

        with patch(
            "urllib.request.urlopen",
            return_value=self._urlopen(_eurostat_area_response(1420.5, 2021)),
        ):
            result = fetch_nuts_area_km2("DEA34")
        assert result == pytest.approx(1420.5)

    def test_returns_none_on_empty_values(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import (
            fetch_nuts_area_km2,
        )

        empty = json.dumps(
            {
                "value": {},
                "dimension": {"time": {"category": {"index": {}, "label": {}}}},
            }
        ).encode()
        with patch("urllib.request.urlopen", return_value=self._urlopen(empty)):
            result = fetch_nuts_area_km2("DEA34")
        assert result is None

    def test_returns_none_on_http_error(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import (
            fetch_nuts_area_km2,
        )

        with patch("urllib.request.urlopen", side_effect=OSError("connection refused")):
            result = fetch_nuts_area_km2("DEA34")
        assert result is None

    def test_picks_most_recent_year(self) -> None:
        from osm.zone_population_estimator.domain.eurostat import (
            fetch_nuts_area_km2,
        )

        resp = json.dumps(
            {
                "value": {"0": 1000.0, "1": 1420.5},
                "dimension": {
                    "time": {
                        "category": {
                            "index": {"2019": 0, "2021": 1},
                            "label": {"2019": "2019", "2021": "2021"},
                        }
                    }
                },
            }
        ).encode()
        with patch("urllib.request.urlopen", return_value=self._urlopen(resp)):
            result = fetch_nuts_area_km2("DEA34")
        assert result == pytest.approx(1420.5)


# ---------------------------------------------------------------------------
# _compute_bbox_area_km2
# ---------------------------------------------------------------------------


class TestComputeBboxAreaKm2:
    def test_reasonable_value_for_deventer(self) -> None:
        from osm.zone_population_estimator.core.zone_population_estimator_core import (
            _compute_bbox_area_km2,
        )

        # Deventer centrum bbox — roughly 4 km × 3 km ≈ ~12 km²
        area = _compute_bbox_area_km2([6.143, 52.248, 6.184, 52.272])
        assert 5.0 < area < 25.0

    def test_larger_bbox_gives_larger_area(self) -> None:
        from osm.zone_population_estimator.core.zone_population_estimator_core import (
            _compute_bbox_area_km2,
        )

        small = _compute_bbox_area_km2([6.0, 52.0, 6.1, 52.1])
        large = _compute_bbox_area_km2([6.0, 52.0, 6.2, 52.2])
        assert large > small


# ---------------------------------------------------------------------------
# estimate_zone_population (integration — all external calls mocked)
# ---------------------------------------------------------------------------


class TestEstimateZonePopulation:
    _BBOX: ClassVar[list[float]] = [6.143, 52.248, 6.184, 52.272]

    _ZONES_FC = _zones_fc(
        _zone_feature("z1", {"house": 300.0, "shopping": 100.0}),
        _zone_feature("z2", {"house": 700.0, "school": 200.0}),
    )

    # Default mocks: LAU returns None (no population) so NUTS3+area-weighting path is used.
    def _call(
        self,
        *,
        lau_result: dict | None = None,
        nuts3_area_km2: float | None = 1000.0,
        **kwargs,
    ) -> tuple[dict, dict]:
        from osm.zone_population_estimator.core.zone_population_estimator_core import (
            estimate_zone_population,
        )

        nuts_result = {"nuts_code": "NL212", "nuts_level": 3}
        place_result = {"name": "Deventer", "display_name": "Deventer, Netherlands"}
        pop_result = {"population": 161927.0, "year": 2024, "nuts_code": "NL212"}

        with (
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.find_nuts",
                return_value=nuts_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.reverse_geocode",
                return_value=place_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.find_lau",
                return_value=lau_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.fetch_population",
                return_value=pop_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.fetch_nuts_area_km2",
                return_value=nuts3_area_km2,
            ),
        ):
            return estimate_zone_population(self._ZONES_FC, self._BBOX, **kwargs)

    # ------------------------------------------------------------------
    # Basic structure
    # ------------------------------------------------------------------

    def test_returns_feature_collection(self) -> None:
        fc, _ = self._call()
        assert fc["type"] == "FeatureCollection"

    def test_stats_total_matches_zone_count(self) -> None:
        fc, stats = self._call()
        assert stats["total"] == len(fc["features"])

    def test_stats_contains_nuts_code(self) -> None:
        _, stats = self._call()
        assert stats["nutsCode"] == "NL212"

    def test_stats_contains_municipality_name(self) -> None:
        _, stats = self._call()
        assert stats["municipalityName"] == "Deventer"

    def test_production_present_on_each_zone(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert "production" in feat["properties"]

    def test_attraction_present_on_each_zone(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert "attraction" in feat["properties"]

    def test_building_by_type_preserved_on_zone(self) -> None:
        # buildingByType (m² per type) comes from building_zone_creator and must
        # pass through zone_population_estimator unchanged.
        fc, _ = self._call()
        for feat in fc["features"]:
            assert "buildingByType" in feat["properties"]

    def test_attraction_by_type_present_and_normalised(self) -> None:
        # attractionByType must be present; its values must sum to the zone's
        # total attraction (within rounding tolerance).
        fc, _ = self._call()
        for feat in fc["features"]:
            props = feat["properties"]
            assert "attractionByType" in props, (
                f"attractionByType missing on zone {props.get('zoneId')}"
            )
            abt = props["attractionByType"]
            assert isinstance(abt, dict)
            if abt:
                assert sum(abt.values()) == pytest.approx(props["attraction"], abs=0.05), (
                    f"attractionByType sum mismatch on zone {props.get('zoneId')}: "
                    f"{sum(abt.values())} != {props['attraction']}"
                )

    def test_total_production_equals_total_population(self) -> None:
        fc, stats = self._call()
        total_prod = sum(f["properties"]["production"] for f in fc["features"])
        assert total_prod == pytest.approx(stats["totalPopulation"], rel=1e-3)

    def test_production_proportional_to_house_m2(self) -> None:
        fc, stats = self._call()
        props_by_id = {f["properties"]["zoneId"]: f["properties"] for f in fc["features"]}
        total_pop = stats["totalPopulation"]
        assert props_by_id["z1"]["production"] == pytest.approx(total_pop * 0.3, rel=1e-3)
        assert props_by_id["z2"]["production"] == pytest.approx(total_pop * 0.7, rel=1e-3)

    def test_nuts_code_on_zone_properties(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert feat["properties"]["nutsCode"] == "NL212"

    def test_municipality_name_on_zone_properties(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert feat["properties"]["municipalityName"] == "Deventer"

    def test_custom_attraction_factors_applied(self) -> None:
        # z1 heeft 100 m² shopping; met factor 0.20 → attraction = 20.0
        fc, _ = self._call(attraction_factors={"shopping": 0.20})
        z1_props = next(
            f["properties"] for f in fc["features"] if f["properties"]["zoneId"] == "z1"
        )
        assert z1_props["attraction"] == pytest.approx(20.0, rel=1e-3)

    def test_fc_properties_contain_nuts_code(self) -> None:
        fc, _ = self._call()
        assert fc.get("properties", {}).get("nutsCode") == "NL212"

    # ------------------------------------------------------------------
    # Population source: LAU path
    # ------------------------------------------------------------------

    def test_lau_population_used_when_available(self) -> None:
        lau = {
            "lau_id": "NL_GM0150",
            "lau_name": "Deventer",
            "population": 99000.0,
            "pop_year": 2021,
        }
        _, stats = self._call(lau_result=lau)
        assert stats["totalPopulation"] == pytest.approx(99000.0)
        assert stats["populationSource"] == "LAU"

    def test_lau_population_zero_falls_through(self) -> None:
        lau = {"lau_id": "X", "lau_name": "X", "population": 0.0, "pop_year": 2021}
        _, stats = self._call(lau_result=lau)
        # Zero population falls through to NUTS-3 path
        assert stats["populationSource"] != "LAU"

    def test_lau_none_falls_through_to_nuts(self) -> None:
        _, stats = self._call(lau_result=None)
        assert stats["populationSource"] in ("NUTS3_AREA_WEIGHTED", "NUTS3")

    # ------------------------------------------------------------------
    # Population source: area-weighted NUTS-3 path
    # ------------------------------------------------------------------

    def test_area_weighted_when_nuts3_area_available(self) -> None:
        # bbox ~12 km², nuts3 ~1000 km² → ratio ~0.012 → pop ~1943
        _, stats = self._call(lau_result=None, nuts3_area_km2=1000.0)
        assert stats["populationSource"] == "NUTS3_AREA_WEIGHTED"
        assert stats["totalPopulation"] < 161927.0  # must be less than full Kreis population

    def test_area_weighted_population_bounded_by_nuts3(self) -> None:
        # Even if bbox larger than NUTS-3 (ratio > 1.0), cap at NUTS-3 total
        _, stats = self._call(lau_result=None, nuts3_area_km2=1.0)  # tiny NUTS-3 area
        assert stats["totalPopulation"] == pytest.approx(161927.0)

    def test_plain_nuts3_when_area_unavailable(self) -> None:
        _, stats = self._call(lau_result=None, nuts3_area_km2=None)
        assert stats["populationSource"] == "NUTS3"
        assert stats["totalPopulation"] == pytest.approx(161927.0)

    # ------------------------------------------------------------------
    # Stats dict structure
    # ------------------------------------------------------------------

    def test_stats_has_population_source(self) -> None:
        _, stats = self._call()
        assert "populationSource" in stats

    def test_stats_has_year(self) -> None:
        _, stats = self._call(lau_result=None)
        # NUTS-3 path sets year from Eurostat response
        assert stats["year"] == 2024

    def test_stats_year_is_lau_year_when_lau_used(self) -> None:
        lau = {"lau_id": "X", "lau_name": "X", "population": 50000.0, "pop_year": 2021}
        _, stats = self._call(lau_result=lau)
        assert stats["year"] == 2021


# ---------------------------------------------------------------------------
# _dominant_type_label
# ---------------------------------------------------------------------------


class TestDominantTypeLabel:
    def _call(self, building_types: dict) -> str:
        from osm.zone_population_estimator.core.zone_population_estimator_core import (
            _dominant_type_label,
        )

        return _dominant_type_label(building_types)

    def test_house_dominant_gives_residential(self) -> None:
        assert self._call({"house": 500.0, "shopping": 100.0}) == "Residential Area"

    def test_commercial_dominant_gives_commercial(self) -> None:
        assert self._call({"retail": 300.0, "house": 50.0}) == "Commercial Area"

    def test_industrial_dominant_gives_industrial(self) -> None:
        assert self._call({"warehouse": 1000.0}) == "Industrial Area"

    def test_school_dominant_gives_education(self) -> None:
        assert self._call({"school": 400.0, "house": 100.0}) == "Education Area"

    def test_office_dominant_gives_office(self) -> None:
        assert self._call({"office": 200.0}) == "Office Area"

    def test_unknown_type_gives_mixed(self) -> None:
        assert self._call({"barn": 999.0}) == "Mixed Area"

    def test_empty_dict_gives_mixed(self) -> None:
        assert self._call({}) == "Mixed Area"


# ---------------------------------------------------------------------------
# zoneName on enriched zones
# ---------------------------------------------------------------------------


class TestZoneNameEnrichment:
    """Verify that estimate_zone_population writes 'zoneName' on every zone."""

    _BBOX: ClassVar[list[float]] = [6.143, 52.248, 6.184, 52.272]

    def _call(self, zones_fc: dict) -> dict:
        from osm.zone_population_estimator.core.zone_population_estimator_core import (
            estimate_zone_population,
        )

        nuts_result = {"nuts_code": "NL212", "nuts_level": 3}
        place_result = {"name": "Deventer", "display_name": "Deventer, Netherlands"}
        pop_result = {"population": 100000.0, "year": 2024, "nuts_code": "NL212"}

        with (
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.find_nuts",
                return_value=nuts_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.reverse_geocode",
                return_value=place_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.find_lau",
                return_value=None,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.fetch_population",
                return_value=pop_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.fetch_nuts_area_km2",
                return_value=None,
            ),
        ):
            fc, _ = estimate_zone_population(zones_fc, self._BBOX)
        return fc

    def test_zone_name_present_on_every_feature(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"house": 300.0}),
            _zone_feature("z2", {"retail": 200.0}),
        )
        fc = self._call(zones_fc)
        for feat in fc["features"]:
            assert "zoneName" in feat["properties"]
            assert feat["properties"]["zoneName"] != ""

    def test_zone_name_contains_municipality(self) -> None:
        zones_fc = _zones_fc(_zone_feature("z1", {"house": 300.0}))
        fc = self._call(zones_fc)
        assert "Deventer" in fc["features"][0]["properties"]["zoneName"]

    def test_zone_name_contains_type_label(self) -> None:
        zones_fc = _zones_fc(_zone_feature("z1", {"house": 300.0}))
        fc = self._call(zones_fc)
        assert "Residential Area" in fc["features"][0]["properties"]["zoneName"]

    def test_zone_name_contains_compass(self) -> None:
        zones_fc = _zones_fc(_zone_feature("z1", {"house": 300.0}))
        fc = self._call(zones_fc)
        name = fc["features"][0]["properties"]["zoneName"]
        # Must end with "(XX)" where XX is a compass point
        assert name[-1] == ")"
        assert "(" in name

    def test_duplicate_zone_names_disambiguated(self) -> None:
        # Two zones with the same building type whose centroids fall in the
        # same compass direction (using default centre) will get the same raw name.
        # _zone_feature does not include centroidLon/Lat so the core falls back to
        # the bbox centre for both → same bearing → same compass → same raw name.
        zones_fc = _zones_fc(
            _zone_feature("z1", {"house": 300.0}),
            _zone_feature("z2", {"house": 400.0}),
        )
        fc = self._call(zones_fc)
        names = [f["properties"]["zoneName"] for f in fc["features"]]
        assert len(set(names)) == len(names), f"Duplicate zone names: {names}"


# ---------------------------------------------------------------------------
# parking_trips_factor
# ---------------------------------------------------------------------------


class TestParkingTripsFactor:
    """Verify that parkingCapacity × parking_trips_factor is added to both
    production and attraction."""

    _BBOX: ClassVar[list[float]] = [6.143, 52.248, 6.184, 52.272]

    def _call(self, zones_fc: dict, **kwargs) -> tuple[dict, dict]:
        from osm.zone_population_estimator.core.zone_population_estimator_core import (
            estimate_zone_population,
        )

        nuts_result = {"nuts_code": "NL212", "nuts_level": 3}
        place_result = {"name": "Deventer", "display_name": "Deventer, Netherlands"}
        pop_result = {"population": 1000.0, "year": 2024, "nuts_code": "NL212"}

        with (
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.find_nuts",
                return_value=nuts_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.reverse_geocode",
                return_value=place_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.find_lau",
                return_value=None,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.fetch_population",
                return_value=pop_result,
            ),
            patch(
                "osm.zone_population_estimator.core.zone_population_estimator_core.fetch_nuts_area_km2",
                return_value=None,
            ),
        ):
            return estimate_zone_population(zones_fc, self._BBOX, **kwargs)

    def test_parking_contribution_added_to_attraction(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature_with_parking("z1", {"house": 100.0}, parking_capacity=100)
        )
        fc, _ = self._call(zones_fc, parking_trips_factor=2.0)
        z1 = fc["features"][0]["properties"]
        # Attraction from house is 0; parking adds 100 × 2.0 = 200
        assert z1["attraction"] == pytest.approx(200.0, rel=1e-3)

    def test_parking_contribution_added_to_production(self) -> None:
        # All population (1000) goes to z1 (only house zone); parking adds 100 × 2.0 = 200
        zones_fc = _zones_fc(
            _zone_feature_with_parking("z1", {"house": 100.0}, parking_capacity=100)
        )
        fc, _ = self._call(zones_fc, parking_trips_factor=2.0)
        z1 = fc["features"][0]["properties"]
        assert z1["production"] == pytest.approx(1000.0 + 200.0, rel=1e-3)

    def test_default_parking_trips_factor_is_1_5(self) -> None:
        zones_fc = _zones_fc(_zone_feature_with_parking("z1", {}, parking_capacity=100))
        fc, _ = self._call(zones_fc)  # default factor
        z1 = fc["features"][0]["properties"]
        assert z1["attraction"] == pytest.approx(100 * 1.5, rel=1e-3)

    def test_zero_parking_capacity_adds_nothing(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature("z1", {"shopping": 100.0})  # no parkingCapacity key
        )
        fc, _ = self._call(zones_fc, parking_trips_factor=2.0)
        z1 = fc["features"][0]["properties"]
        from osm.zone_population_estimator.domain.attraction import (
            compute_attraction,
        )

        expected_attraction, _ = compute_attraction({"shopping": 100.0})
        assert z1["attraction"] == pytest.approx(expected_attraction, rel=1e-6)

    def test_zero_parking_trips_factor_adds_nothing(self) -> None:
        zones_fc = _zones_fc(
            _zone_feature_with_parking("z1", {"shopping": 100.0}, parking_capacity=200)
        )
        fc_no_parking, _ = self._call(zones_fc, parking_trips_factor=0.0)
        z1 = fc_no_parking["features"][0]["properties"]
        from osm.zone_population_estimator.domain.attraction import (
            compute_attraction,
        )

        expected_attraction, _ = compute_attraction({"shopping": 100.0})
        assert z1["attraction"] == pytest.approx(expected_attraction, rel=1e-6)
