# Databricks notebook source
# ---------------------------------------------------------------------------
# zone_population_estimator_nb.py — Databricks notebook for zone_population_estimator.
#
# This notebook:
#   1. Reads widget parameters (zones_uri, bbox, output_folder, …).
#   2. Loads the building-zones GeoParquet from S3 (or local path).
#   3. Resolves NUTS3 region via GISCO and fetches population via Eurostat.
#   4. Computes production and attraction per zone.
#   5. Writes enriched GeoParquet to S3 (or local).
#   6. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import contextlib
import json
import logging
from datetime import UTC, datetime
from typing import cast

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("zone_population_estimator_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
with contextlib.suppress(Exception):
    dbutils.widgets.removeAll()  # noqa: F821

dbutils.widgets.text(  # noqa: F821
    "zones_uri",
    "",
    "Full URI of the input building-zones GeoParquet (s3://bucket/key or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "bbox",
    "6.143,52.248,6.184,52.272",
    "Bounding box: minLon,minLat,maxLon,maxLat (comma-separated)",
)
dbutils.widgets.text(  # noqa: F821
    "output_folder",
    "",
    "Output folder: s3://bucket/prefix/ or local path",
)
dbutils.widgets.text(  # noqa: F821
    "area_id",
    "zones-population",
    "Area identifier — used in output filename ({area_id}-ZONES-POPULATION.parquet)",
)
dbutils.widgets.text(  # noqa: F821
    "attraction_factors",
    "{}",
    'JSON object overriding attraction factors, e.g. {"shopping": 0.15}',
)
dbutils.widgets.text(  # noqa: F821
    "gisco_url",
    "https://gisco-services.ec.europa.eu",
    "GISCO REST API base URL",
)
dbutils.widgets.text(  # noqa: F821
    "eurostat_url",
    "https://ec.europa.eu/eurostat/api/dissemination",
    "Eurostat Statistics API base URL",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

ZONES_URI = dbutils.widgets.get("zones_uri").strip()  # noqa: F821
if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty.")

_raw_bbox = dbutils.widgets.get("bbox").strip()  # noqa: F821
if not _raw_bbox:
    raise ValueError("Widget 'bbox' is empty.")
try:
    BBOX: list[float] = [float(v.strip()) for v in _raw_bbox.split(",")]
    if len(BBOX) != 4:
        raise ValueError(f"Expected 4 values, got {len(BBOX)}")
except ValueError as _exc:
    raise ValueError(f"Widget 'bbox' must be 'minLon,minLat,maxLon,maxLat': {_exc}") from _exc

OUTPUT_FOLDER = dbutils.widgets.get("output_folder").strip()  # noqa: F821
if not OUTPUT_FOLDER:
    raise ValueError("Widget 'output_folder' is empty.")

AREA_ID = dbutils.widgets.get("area_id").strip() or "zones-population"  # noqa: F821

_raw_factors = dbutils.widgets.get("attraction_factors").strip() or "{}"  # noqa: F821
try:
    ATTRACTION_FACTORS: dict = json.loads(_raw_factors)
except json.JSONDecodeError as _exc:
    raise ValueError(f"Widget 'attraction_factors' is not valid JSON: {_exc}") from _exc

GISCO_URL = dbutils.widgets.get("gisco_url").strip()  # noqa: F821
if not GISCO_URL:
    GISCO_URL = "https://gisco-services.ec.europa.eu"

EUROSTAT_URL = dbutils.widgets.get("eurostat_url").strip()  # noqa: F821
if not EUROSTAT_URL:
    EUROSTAT_URL = "https://ec.europa.eu/eurostat/api/dissemination"

logger.info(
    "zones_uri=%s  bbox=%s  area_id=%s  output_folder=%s",
    ZONES_URI,
    BBOX,
    AREA_ID,
    OUTPUT_FOLDER,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402


def _get_s3(bucket: str, key: str) -> bytes:
    body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
    logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
    return cast(bytes, body)


def _put_s3(bucket: str, key: str, data: bytes) -> None:
    boto3.client("s3").put_object(
        Bucket=bucket,
        Key=key,
        Body=data,
        ContentType="application/octet-stream",
    )
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        parts = uri[5:].split("/", 1)
        bucket, key = parts[0], parts[1] if len(parts) > 1 else ""
        return _get_s3(bucket, key)
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    import os

    if uri.startswith("s3://"):
        parts = uri[5:].split("/", 1)
        bucket, key = parts[0], parts[1] if len(parts) > 1 else ""
        _put_s3(bucket, key, data)
    else:
        os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
        with open(uri, "wb") as _fh:
            _fh.write(data)
        logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Zone Population Estimator
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from gmt_shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402

from osm.zone_population_estimator.core.zone_population_estimator_core import (  # noqa: E402
    estimate_zone_population,
)

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")
print(f"zones_uri     : {ZONES_URI}")
print(f"bbox          : {BBOX}")
print(f"area_id       : {AREA_ID}")
print(f"output_folder : {OUTPUT_FOLDER}")
print()

_zones_bytes = _read_uri(ZONES_URI)
_zones_fc = from_geoparquet(_zones_bytes)
_n_zones = len(_zones_fc.get("features") or [])
print(f"{_n_zones} zone features loaded")

_fc, _stats = estimate_zone_population(
    _zones_fc,
    BBOX,
    gisco_url=GISCO_URL,
    eurostat_url=EUROSTAT_URL,
    attraction_factors=ATTRACTION_FACTORS or None,
)

_parquet_bytes = to_geoparquet(_fc)
_out_uri = f"{OUTPUT_FOLDER.rstrip('/')}/{AREA_ID}-ZONES-POPULATION.parquet"
_write_uri(_out_uri, _parquet_bytes)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 64
print(_SEP)
print(f"Zone Population Estimator complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  area_id          : {AREA_ID}")
print(f"  bbox             : {BBOX}")
print(f"  output           : {_out_uri}")
print(f"  zones enriched   : {_stats['total']}")
print(f"  municipality     : {_stats['municipalityName']}")
print(f"  NUTS code        : {_stats['nutsCode']}")
print(f"  population       : {_stats['totalPopulation']:.0f}  (year {_stats['year']})")
print(_SEP)
