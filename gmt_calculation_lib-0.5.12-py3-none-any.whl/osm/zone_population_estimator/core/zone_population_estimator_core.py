"""Pure-Python zone_population_estimator core — no I/O, no boto3.

Enriches a building-zones GeoJSON FeatureCollection (output of
``building_zone_creator``) with:

- **production**: estimated number of residents allocated to each zone,
  distributed proportionally to the ``house`` building-type footprint (m²).
- **attraction**: estimated daily person-movements attracted to each zone,
  derived from non-residential building-type footprints × conversion factors.
- **attractionByType**: per-type breakdown of the attraction figure.

Population resolution — three-tier strategy
-------------------------------------------
1. **LAU (municipality) lookup via GISCO** — ``find_lau`` queries the GISCO
   LAU endpoint for the bbox centroid.  When the response contains a
   ``POP_YYYY`` field the municipality population is used directly.
   Best accuracy; relies on GISCO LAU data being available for the country.

2. **Area-weighted NUTS-3** — when LAU population is unavailable, the NUTS-3
   regional population (Eurostat ``DEMO_R_GIND3``) is scaled by the ratio of
   the bbox area to the NUTS-3 land area (Eurostat ``REG_AREA3``).  Assumes
   uniform population density across the region; much better than using the
   full Kreis/département population for a small town.

3. **Plain NUTS-3 total** — ultimate fallback when the Eurostat area dataset
   is also unavailable.

Public API
----------
estimate_zone_population(zones_fc, bbox, *, gisco_url, eurostat_url,
                         gisco_timeout, eurostat_timeout,
                         attraction_factors) -> tuple[dict, dict]
    Returns (enriched_fc, stats).
    stats: {"total": int, "totalPopulation": float, "nutsCode": str,
            "municipalityName": str, "year": int | None,
            "populationSource": str}
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)

from gmt_shared.geo_utils import _bearing_deg, _compass_8_label_en  # noqa: E402

from osm.zone_population_estimator.domain.attraction import (  # noqa: E402
    compute_attraction,
)
from osm.zone_population_estimator.domain.distributor import distribute_population  # noqa: E402
from osm.zone_population_estimator.domain.eurostat import (  # noqa: E402
    fetch_nuts_area_km2,
    fetch_population,
)
from osm.zone_population_estimator.domain.gisco import (  # noqa: E402
    find_lau,
    find_nuts,
    reverse_geocode,
)

_DEFAULT_GISCO_URL = "https://gisco-services.ec.europa.eu"
_DEFAULT_EUROSTAT_URL = "https://ec.europa.eu/eurostat/api/dissemination"
_DEFAULT_TIMEOUT = 30


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _compute_bbox_area_km2(bbox: list[float]) -> float:
    """Estimate bounding-box area in km² using a flat-Earth approximation.

    Accurate to ~0.5 % for bounding boxes up to ~200 km across.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    mid_lat_rad = math.radians((min_lat + max_lat) / 2.0)
    km_per_deg_lat = 111.320
    km_per_deg_lon = 111.320 * math.cos(mid_lat_rad)
    return abs(max_lon - min_lon) * km_per_deg_lon * abs(max_lat - min_lat) * km_per_deg_lat


# Mapping from OSM building-type keys (or key prefixes) to an English display
# label.  Listed in priority order: first match wins.
_TYPE_LABEL_MAP: list[tuple[frozenset[str], str]] = [
    (
        frozenset(
            {
                "house",
                "residential",
                "apartments",
                "terrace",
                "detached",
                "semidetached_house",
                "bungalow",
            }
        ),
        "Residential Area",
    ),
    (
        frozenset({"commercial", "retail", "supermarket", "shop", "kiosk", "mall"}),
        "Commercial Area",
    ),
    (frozenset({"industrial", "warehouse", "factory", "storage_tank"}), "Industrial Area"),
    (frozenset({"work"}), "Work Area"),
    (frozenset({"school", "university", "college", "kindergarten"}), "Education Area"),
    (frozenset({"office", "government", "civic"}), "Office Area"),
]


def _dominant_type_label(building_types: dict[str, float]) -> str:
    """Return an English area label based on the dominant building-type footprint.

    *building_types* maps OSM building-type key → footprint m².  The type with
    the largest footprint area determines the label.  Falls back to
    ``"Mixed Area"`` when the dict is empty or no key matches.
    """
    if not building_types:
        return "Mixed Area"
    dominant = max(building_types, key=lambda k: building_types[k])
    for key_set, label in _TYPE_LABEL_MAP:
        if dominant in key_set:
            return label
    return "Mixed Area"


def _zone_display_name(
    municipality: str,
    type_label: str,
    compass: str,
) -> str:
    """Compose the raw zone display name before deduplication."""
    prefix = f"{municipality} – " if municipality else ""
    return f"{prefix}{type_label} ({compass})"


def _deduplicate_names(names: list[str]) -> list[str]:
    """Add numeric suffixes to duplicate names so every entry is unique.

    The first occurrence keeps its original name; subsequent duplicates get
    `` 2``, `` 3``, etc.  Only applies when there actually are duplicates.
    """
    seen: dict[str, int] = {}
    result: list[str] = []
    for name in names:
        count = seen.get(name, 0) + 1
        seen[name] = count
        result.append(name if count == 1 else f"{name} {count}")
    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def estimate_zone_population(
    zones_fc: dict,
    bbox: list[float],
    *,
    gisco_url: str = _DEFAULT_GISCO_URL,
    eurostat_url: str = _DEFAULT_EUROSTAT_URL,
    gisco_timeout: int = _DEFAULT_TIMEOUT,
    eurostat_timeout: int = _DEFAULT_TIMEOUT,
    attraction_factors: dict[str, float] | None = None,
    population_override: float | None = None,
    parking_trips_factor: float = 1.5,
) -> tuple[dict, dict]:
    """Enrich a zones FeatureCollection with production and attraction.

    Parameters
    ----------
    zones_fc:
        GeoJSON FeatureCollection produced by ``building_zone_creator``.
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84 — used to resolve the
        population for the area.
    gisco_url:
        GISCO REST API base URL.
    eurostat_url:
        Eurostat SDMX API base URL.
    gisco_timeout:
        HTTP timeout in seconds for GISCO calls.
    eurostat_timeout:
        HTTP timeout in seconds for Eurostat calls.
    attraction_factors:
        Optional override dict ``{building_type: trips_per_m2_per_day}``.
        Merged with (and overrides) ``DEFAULT_ATTRACTION_FACTORS``.
    population_override:
        When set, skip all population API calls and use this value directly
        as the total population for the area.  Useful when the automatic
        LAU/NUTS lookup returns an inaccurate regional figure.
    parking_trips_factor:
        Number of trips per parking space per day added to both
        ``production`` and ``attraction`` for each zone.  Defaults to
        ``1.5``.  Applied on top of the building-type attraction model using
        the zone's ``parkingCapacity`` field (set by
        ``building_zone_creator``).

    Returns
    -------
    enriched_fc:
        The same FeatureCollection with extra properties per zone:
        ``production``, ``attraction``, ``totalPopulation``,
        ``municipalityName``, ``nutsCode``, ``zoneName``.
    stats:
        ``{"total": int, "totalPopulation": float, "nutsCode": str,
           "municipalityName": str, "year": int | None,
           "populationSource": str}``
        ``populationSource`` is one of ``"OVERRIDE"``, ``"LAU"``,
        ``"NUTS3_AREA_WEIGHTED"``, or ``"NUTS3"``.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    centre_lon = (min_lon + max_lon) / 2.0
    centre_lat = (min_lat + max_lat) / 2.0

    # ── 1. Resolve NUTS3 region + municipality name ──────────────────────────
    logger.info("Resolving NUTS region for centroid lon=%.4f lat=%.4f", centre_lon, centre_lat)
    nuts_info = find_nuts(centre_lon, centre_lat, base_url=gisco_url, timeout=gisco_timeout)
    nuts_code: str = nuts_info["nuts_code"]

    place_info = reverse_geocode(centre_lon, centre_lat, base_url=gisco_url, timeout=gisco_timeout)
    municipality_name: str = place_info.get("name", "")

    # ── 2. Resolve population (three-tier strategy) ──────────────────────────
    total_population: float
    pop_year: int | None
    population_source: str

    # Tier 0: explicit override
    if population_override is not None and population_override > 0:
        total_population = population_override
        pop_year = None
        population_source = "OVERRIDE"
        logger.info("Using population override: %.0f", total_population)

    # Tier 1: LAU municipality population
    else:
        lau_info = find_lau(centre_lon, centre_lat, base_url=gisco_url, timeout=gisco_timeout)
        lau_population = (lau_info or {}).get("population")

        if lau_population and lau_population > 0:
            total_population = lau_population
            pop_year = (lau_info or {}).get("pop_year")
            population_source = "LAU"
            logger.info(
                "Using LAU population %.0f (year %s) for %s",
                total_population,
                pop_year,
                (lau_info or {}).get("lau_name", ""),
            )
        else:
            # Tier 2 / 3: NUTS-3 with optional area weighting
            logger.info("Fetching population for NUTS code %s", nuts_code)
            pop_info = fetch_population(nuts_code, base_url=eurostat_url, timeout=eurostat_timeout)
            nuts3_population: float = pop_info["population"]
            pop_year = pop_info["year"]
            actual_nuts_code: str = pop_info["nuts_code"]
            nuts_code = actual_nuts_code  # update after potential fallback
            logger.info(
                "Population %s: %.0f (year %d)", actual_nuts_code, nuts3_population, pop_year
            )

            # Tier 2: area-weighted NUTS-3
            nuts3_area_km2 = fetch_nuts_area_km2(
                nuts_code, base_url=eurostat_url, timeout=eurostat_timeout
            )
            bbox_area_km2 = _compute_bbox_area_km2(bbox)

            if nuts3_area_km2 is not None and nuts3_area_km2 > 0:
                ratio = min(1.0, bbox_area_km2 / nuts3_area_km2)
                total_population = nuts3_population * ratio
                population_source = "NUTS3_AREA_WEIGHTED"
                logger.info(
                    "Area-weighted: bbox=%.1f km² / nuts3=%.1f km² → ratio=%.4f → pop=%.0f",
                    bbox_area_km2,
                    nuts3_area_km2,
                    ratio,
                    total_population,
                )
            else:
                # Tier 3: plain NUTS-3 total
                total_population = nuts3_population
                population_source = "NUTS3"
                logger.info(
                    "Using full NUTS-3 population %.0f (area data unavailable)", total_population
                )

    # ── 3. Distribute production ─────────────────────────────────────────────
    production_by_zone = distribute_population(zones_fc, total_population)

    # ── 4. Compute attraction per zone + enrich features ────────────────────
    features: list[dict] = zones_fc.get("features") or []

    # Pre-compute raw zone names (before deduplication) so we can run a single
    # deduplication pass before writing them into the feature properties.
    centre_lon = (bbox[0] + bbox[2]) / 2.0
    centre_lat = (bbox[1] + bbox[3]) / 2.0
    raw_names: list[str] = []
    zone_building_types: list[dict] = []

    for feat in features:
        props = feat.get("properties") or {}
        building_by_type_m2: dict[str, float] = {
            k: float(v) for k, v in (props.get("buildingByType") or {}).items()
        }
        zone_building_types.append(building_by_type_m2)

        lon = float(props.get("centroidLon") or centre_lon)
        lat = float(props.get("centroidLat") or centre_lat)
        bearing = _bearing_deg(centre_lon, centre_lat, lon, lat)
        compass = _compass_8_label_en(bearing)
        type_label = _dominant_type_label(building_by_type_m2)
        raw_names.append(_zone_display_name(municipality_name, type_label, compass))

    zone_names = _deduplicate_names(raw_names)

    enriched_features: list[dict] = []

    for feat, building_by_type_m2, zone_name in zip(
        features, zone_building_types, zone_names, strict=False
    ):
        props = dict(feat.get("properties") or {})
        zone_id: str = props.get("zoneId", "")

        attraction, attraction_by_type = compute_attraction(
            building_by_type_m2, factors=attraction_factors
        )

        # Parking contribution: capacity × factor adds to both production and
        # attraction symmetrically (park-and-ride and station parking generate
        # trips in both directions).
        parking_capacity: int = props.get("parkingCapacity") or 0
        parking_trips = round(parking_capacity * parking_trips_factor, 2)

        props["production"] = round(production_by_zone.get(zone_id, 0.0) + parking_trips, 2)
        props["attraction"] = round(attraction + parking_trips, 2)
        props["attractionByType"] = {k: round(v, 4) for k, v in attraction_by_type.items()}
        props["totalPopulation"] = total_population
        props["municipalityName"] = municipality_name
        props["nutsCode"] = nuts_code
        props["zoneName"] = zone_name

        enriched_features.append(
            {
                "type": "Feature",
                "geometry": feat.get("geometry"),
                "properties": props,
            }
        )

    enriched_fc: dict = {
        "type": "FeatureCollection",
        "features": enriched_features,
        "properties": {
            **(zones_fc.get("properties") or {}),
            "nutsCode": nuts_code,
            "municipalityName": municipality_name,
            "totalPopulation": total_population,
            "populationYear": pop_year,
            "populationSource": population_source,
        },
    }
    stats: dict = {
        "total": len(enriched_features),
        "totalPopulation": total_population,
        "nutsCode": nuts_code,
        "municipalityName": municipality_name,
        "year": pop_year,
        "populationSource": population_source,
    }
    logger.info(
        "estimate_zone_population complete: %d zones enriched, pop=%.0f (source=%s)",
        len(enriched_features),
        total_population,
        population_source,
    )
    return enriched_fc, stats
