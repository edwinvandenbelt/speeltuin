"""Local debug runner for building_zone_creator.

Reads a buildings GeoParquet (output of osm_building_fetcher), fetches streets
from Overpass, creates building zones, and writes the result as GeoParquet.

Usage
-----
    python -m building_zone_creator.building_zone_creator_runner \\
        --buildings-uri s3://my-bucket/deventer-BUILDINGS.parquet \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder ./out/ \\
        --area-id deventer-centrum

    python src/building_zone_creator/building_zone_creator_runner.py \\
        --buildings-uri ./deventer-BUILDINGS.parquet \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder ./out/ \\
        --target-footprint-m2 5000

Prerequisites
-------------
* AWS credentials available in the environment or a tools/.env file (only needed
  for s3:// URIs).
* shapely >= 2.0 installed in the Python environment.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import cast

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return cast(bytes, get_bytes_s3(bucket, key))
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        print(f"Written {len(data):,} bytes → s3://{bucket}/{key}")
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for building_zone_creator — creates building zones "
            "from a buildings GeoParquet."
        )
    )
    parser.add_argument(
        "--buildings-uri",
        required=True,
        metavar="URI",
        help="Full URI of the input buildings GeoParquet (s3:// or local path).",
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        required=True,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box: minLon minLat maxLon maxLat",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder (s3://bucket/prefix/ or local directory).",
    )
    parser.add_argument(
        "--area-id",
        default=None,
        help="Area identifier used in the output filename (default: 'zones').",
    )
    parser.add_argument(
        "--target-footprint-m2",
        type=float,
        default=5000.0,
        help="Target total building footprint per zone in m² (default: 5000).",
    )
    parser.add_argument(
        "--overpass-url",
        default=None,
        help=(
            "Overpass API endpoint URL. "
            "Defaults to the OVERPASS_URL environment variable, "
            "or https://overpass-api.de/api/interpreter."
        ),
    )
    parser.add_argument(
        "--overpass-timeout",
        type=int,
        default=90,
        help="Overpass query timeout in seconds (default: 90).",
    )
    parser.add_argument(
        "--osm-path",
        dest="osm_path",
        default=None,
        metavar="PATH",
        help=(
            "Path to a local .osm.pbf extract to read instead of querying the "
            "Overpass HTTP API. Falls back to the OSM_PBF_PATH environment "
            "variable / .env when omitted."
        ),
    )
    parser.add_argument(
        "--osm-workers",
        dest="osm_workers",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Worker processes for reading the local .osm.pbf extract. Defaults "
            "to the OSM_PBF_WORKERS environment variable / CPU count (capped at 8)."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env (auto-discover tools/.env if not specified)
    env_file_path: Path
    if args.env_file:
        env_file_path = Path(args.env_file)
    else:
        env_file_path = Path(__file__).resolve().parent.parent.parent / "tools" / ".env"
    for k, v in _read_env_file(env_file_path).items():
        os.environ.setdefault(k, v)

    overpass_url: str = args.overpass_url or os.environ.get(
        "OVERPASS_URL", "https://overpass-api.de/api/interpreter"
    )

    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
        level=logging.INFO,
    )

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from osm.building_zone_creator.core.building_zone_creator_core import (
        create_zones,
    )

    bbox: list[float] = args.bbox
    area_id: str = args.area_id or "zones"
    output_folder: str = args.output_folder.rstrip("/")

    print(f"Reading buildings : {args.buildings_uri}")
    buildings_fc = from_geoparquet(_read_uri(args.buildings_uri))
    n_buildings = len(buildings_fc.get("features") or [])
    print(f"  {n_buildings} building features loaded")

    print(f"Creating zones  bbox={bbox}  target={args.target_footprint_m2} m²")
    fc, stats = create_zones(
        buildings_fc,
        bbox,
        area_id=area_id,
        overpass_url=overpass_url,
        overpass_timeout=args.overpass_timeout,
        target_footprint_m2=args.target_footprint_m2,
        osm_path=args.osm_path,
        osm_workers=args.osm_workers,
    )
    print(f"Stats : {stats}")

    parquet_bytes = to_geoparquet(fc)
    out_uri = f"{output_folder}/{area_id}-BUILDING-ZONES.parquet"
    _write_uri(out_uri, parquet_bytes)
    print("Done.")


if __name__ == "__main__":
    main()
