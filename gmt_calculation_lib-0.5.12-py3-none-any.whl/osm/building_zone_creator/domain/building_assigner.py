"""Assign buildings to blocks using point-in-polygon tests.

Each building's centroid is tested against the list of block polygons.
A spatial index (shapely STRtree) is used for fast candidate filtering.
Buildings whose centroid lies outside all blocks (e.g. exactly on a road
edge) are assigned to the nearest block as a fallback.

Requires ``shapely >= 2.0``.

Public API
----------
assign_buildings_to_blocks(buildings, blocks) -> list[int]
    Return a block index for every building feature (same order).
    The fallback nearest-block assignment ensures no building returns -1
    when at least one block exists.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

try:
    from shapely import STRtree
    from shapely.geometry import Point

    _HAS_SHAPELY = True
except ImportError:
    _HAS_SHAPELY = False


def _centroid_point(feature: dict):
    """Return a shapely Point for the centroid of a GeoJSON Feature, or None."""
    geom: dict = feature.get("geometry") or {}
    gtype = geom.get("type", "")
    if gtype == "Point":
        c = geom.get("coordinates", [])
        if len(c) >= 2:
            return Point(float(c[0]), float(c[1]))
    elif gtype == "Polygon":
        coords = geom.get("coordinates", [[]])[0]
        if coords:
            lons = [float(c[0]) for c in coords]
            lats = [float(c[1]) for c in coords]
            return Point(sum(lons) / len(lons), sum(lats) / len(lats))
    return None


def assign_buildings_to_blocks(
    buildings: list[dict],
    blocks: list,
) -> list[int]:
    """Assign each building GeoJSON Feature to a block polygon index.

    Parameters
    ----------
    buildings:
        List of GeoJSON Feature dicts (as produced by ``osm_building_fetcher``).
    blocks:
        List of shapely ``Polygon`` objects (as produced by
        ``block_builder.build_blocks``).

    Returns
    -------
    list[int]
        Block index for each building (same order as ``buildings``).
        When ``blocks`` is empty every entry is ``-1``.
        When a building centroid falls outside all blocks (e.g. on an edge)
        the nearest block index is used as a fallback.
    """
    if not _HAS_SHAPELY:
        raise ImportError(
            "shapely >= 2.0 is required for building_zone_creator. "
            "Install it with: pip install shapely"
        )

    if not blocks:
        return [-1] * len(buildings)

    tree = STRtree(blocks)
    results: list[int] = []

    for feature in buildings:
        pt = _centroid_point(feature)
        if pt is None:
            results.append(0)  # degenerate fallback
            continue

        # Fast spatial query for candidate polygons whose bboxes contain pt
        candidates = tree.query(pt)

        found = -1
        for idx in candidates:
            try:
                if blocks[int(idx)].contains(pt):
                    found = int(idx)
                    break
            except Exception:  # noqa: S112  # skip invalid block geometry
                continue

        if found == -1:
            # Fallback: nearest block centroid (rare — building on road edge)
            try:
                nearest_idx = int(tree.nearest(pt))
                found = nearest_idx
            except Exception:
                found = 0

        results.append(found)

    return results
