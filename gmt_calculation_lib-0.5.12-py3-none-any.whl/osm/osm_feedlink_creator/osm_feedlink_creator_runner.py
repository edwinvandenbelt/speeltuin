"""Local debug runner for osm_feedlink_creator.

Reads a directed network GeoParquet (output of osm_network_fetcher /
bidirectional_splitter) and a zones GeoParquet (output of
building_zone_creator), creates feedlinks, and writes the result as
GeoParquet.

Usage
-----
    python -m osm.osm_feedlink_creator.osm_feedlink_creator_runner \\
        --network-uri ./deventer-NETWORK-CAR.parquet \\
        --zones-uri   ./deventer-BUILDING-ZONES.parquet \\
        --output-folder ./output/ \\
        --area-id deventer-centrum

    # or with S3 URIs:
    python -m osm.osm_feedlink_creator.osm_feedlink_creator_runner \\
        --network-uri s3://my-bucket/deventer-NETWORK-CAR.parquet \\
        --zones-uri   s3://my-bucket/deventer-BUILDING-ZONES.parquet \\
        --output-folder s3://my-bucket/out/ \\
        --area-id deventer-centrum

Output
------
``{output_folder}/{area_id}-FEEDLINKS.parquet``

Prerequisites
-------------
* AWS credentials available in the environment or a tools/.env file (only
  needed for s3:// URIs).
* shapely >= 2.0 installed (used by shared.geoparquet).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from typing import cast

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return cast(bytes, get_bytes_s3(bucket, key))
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        print(f"Written {len(data):,} bytes → s3://{bucket}/{key}")
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for osm_feedlink_creator — connects zone centroids "
            "to the most important network node inside each zone."
        )
    )
    parser.add_argument(
        "--network-uri",
        required=True,
        metavar="URI",
        help="Full URI of the directed network GeoParquet (s3:// or local path).",
    )
    parser.add_argument(
        "--zones-uri",
        required=True,
        metavar="URI",
        help="Full URI of the building zones GeoParquet (s3:// or local path).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder (s3://bucket/prefix/ or local directory).",
    )
    parser.add_argument(
        "--area-id",
        default=None,
        help="Area identifier used in the output filename (default: 'feedlinks').",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env (auto-discover tools/.env if not specified)
    env_file_path: Path
    if args.env_file:
        env_file_path = Path(args.env_file)
    else:
        env_file_path = Path(__file__).resolve().parent.parent.parent.parent / "tools" / ".env"
    for k, v in _read_env_file(env_file_path).items():
        os.environ.setdefault(k, v)

    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
        level=logging.INFO,
    )

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
        create_feedlinks,
    )

    area_id: str = args.area_id or "feedlinks"
    output_folder: str = args.output_folder.rstrip("/")

    print(f"Reading network  : {args.network_uri}")
    network_fc = from_geoparquet(_read_uri(args.network_uri))
    n_links = len(network_fc.get("features") or [])
    print(f"  {n_links} network link features loaded")

    print(f"Reading zones    : {args.zones_uri}")
    zones_fc = from_geoparquet(_read_uri(args.zones_uri))
    n_zones = len(zones_fc.get("features") or [])
    print(f"  {n_zones} zone features loaded")

    print("Creating feedlinks…")
    fc, stats = create_feedlinks(network_fc, zones_fc)
    print(f"Stats : {stats}")

    parquet_bytes = to_geoparquet(fc)
    out_uri = f"{output_folder}/{area_id}-FEEDLINKS.parquet"
    _write_uri(out_uri, parquet_bytes)
    print("Done.")


if __name__ == "__main__":
    main()
