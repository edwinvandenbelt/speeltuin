# Databricks notebook source
# ---------------------------------------------------------------------------
# osm_prepare_nb.py — Databricks notebook for osm_prepare.
#
# This notebook:
#   1. Reads widget parameters (bbox, output_uri, area_id, debug).
#   2. Calls run_pipeline — which runs the full OSM pipeline in-process:
#        Track A: buildings → zones → population
#        Track B: network → simplify → clean → split → parallel links
#        Then: feedlinks → OD matrix
#   3. Prints a summary with the four output URIs.
#
# Output files (written to output_uri/)
# ─────────────────────────────────────
#   {area_id}-NETWORK-CAR.parquet
#   {area_id}-FEEDLINK-CAR.parquet
#   {area_id}-ZONE-CAR.parquet
#   {area_id}-ROUTES-CAR.parquet
# ---------------------------------------------------------------------------

# COMMAND ----------
import contextlib
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("osm_prepare_nb")

# COMMAND ----------
# MAGIC %pip install boto3 shapely pyarrow geopandas requests

# COMMAND ----------
# Widget declarations
with contextlib.suppress(Exception):
    dbutils.widgets.removeAll()  # noqa: F821

dbutils.widgets.text(  # noqa: F821
    "bbox",
    "6.15,51.95,6.25,52.00",
    "Bounding box: min_lon,min_lat,max_lon,max_lat",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri",
    "",
    "Output folder URI (s3://bucket/prefix/ or /dbfs/... path)",
)
dbutils.widgets.text(  # noqa: F821
    "area_id",
    "",
    "Area ID (leave blank to auto-discover or generate uuid4)",
)
dbutils.widgets.text(  # noqa: F821
    "name",
    "",
    "Human-readable area name (e.g. Deventer) — stored in output metadata",
)
dbutils.widgets.text(  # noqa: F821
    "population",
    "",
    "Population override (leave blank for automatic LAU/NUTS lookup)",
)
dbutils.widgets.text(  # noqa: F821
    "target_footprint_m2",
    "5000",
    "Target building footprint per zone in m²",
)
dbutils.widgets.text(  # noqa: F821
    "max_routes",
    "2",
    "Maximum k-shortest routes per OD pair",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_url",
    "https://overpass-api.de/api/interpreter",
    "Overpass API endpoint URL",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_timeout",
    "90",
    "Overpass HTTP timeout in seconds",
)
dbutils.widgets.text(  # noqa: F821
    "external_share",
    "0.40",
    "Fraction of zone production for external (boundary-crossing) zones",
)
dbutils.widgets.text(  # noqa: F821
    "peak_hour_fraction",
    "0.10",
    "Fraction of daily flow assigned to peak hour for capacity calculation",
)
dbutils.widgets.dropdown(  # noqa: F821
    "refresh",
    "false",
    ["false", "true"],
    "Re-run even if outputs already exist",
)
dbutils.widgets.dropdown(  # noqa: F821
    "debug",
    "false",
    ["false", "true"],
    "Write intermediate GeoJSON snapshots",
)
dbutils.widgets.dropdown(  # noqa: F821
    "annotate_traffic_signals",
    "true",
    ["true", "false"],
    "Annotate + fetch traffic signals",
)
dbutils.widgets.dropdown(  # noqa: F821
    "fetch_traffic_signs",
    "true",
    ["true", "false"],
    "Fetch OSM traffic signs",
)
dbutils.widgets.dropdown(  # noqa: F821
    "fetch_osm_assets",
    "true",
    ["true", "false"],
    "Fetch OSM traffic objects",
)
dbutils.widgets.dropdown(  # noqa: F821
    "add_elevation",
    "true",
    ["true", "false"],
    "Add elevationFrom / elevationTo",
)
dbutils.widgets.text(  # noqa: F821
    "elevation_batch_size",
    "100",
    "Elevation batch size (max 100)",
)
dbutils.widgets.text(  # noqa: F821
    "elevation_timeout",
    "30",
    "Elevation HTTP timeout (s)",
)
dbutils.widgets.text(  # noqa: F821
    "elevation_retries",
    "8",
    "Elevation retries per batch",
)
dbutils.widgets.text(  # noqa: F821
    "elevation_pause",
    "2.0",
    "Elevation pause between batches (s)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from pathlib import Path  # noqa: E402

from osm.osm_prepare.core.osm_prepare_core import run_pipeline  # noqa: E402

# COMMAND ----------
# ── Widget read + validation ────────────────────────────────────────────────

_bbox_raw = dbutils.widgets.get("bbox").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()  # noqa: F821
AREA_ID = dbutils.widgets.get("area_id").strip() or None  # noqa: F821
NAME = dbutils.widgets.get("name").strip() or None  # noqa: F821
_pop_raw = dbutils.widgets.get("population").strip()  # noqa: F821
POPULATION: float | None = float(_pop_raw) if _pop_raw else None
TARGET_FOOTPRINT_M2 = float(dbutils.widgets.get("target_footprint_m2").strip() or "5000")  # noqa: F821
MAX_ROUTES = int(dbutils.widgets.get("max_routes").strip() or "2")  # noqa: F821
OVERPASS_URL = dbutils.widgets.get("overpass_url").strip()  # noqa: F821
OVERPASS_TIMEOUT = int(dbutils.widgets.get("overpass_timeout").strip() or "90")  # noqa: F821
EXTERNAL_SHARE = float(dbutils.widgets.get("external_share").strip() or "0.40")  # noqa: F821
PEAK_HOUR_FRACTION = float(dbutils.widgets.get("peak_hour_fraction").strip() or "0.10")  # noqa: F821
REFRESH = dbutils.widgets.get("refresh").strip().lower() == "true"  # noqa: F821
DEBUG = dbutils.widgets.get("debug").strip().lower() == "true"  # noqa: F821
ANNOTATE_TRAFFIC_SIGNALS = (
    dbutils.widgets.get("annotate_traffic_signals").strip().lower() == "true"  # noqa: F821
)
FETCH_TRAFFIC_SIGNS = dbutils.widgets.get("fetch_traffic_signs").strip().lower() == "true"  # noqa: F821
FETCH_OSM_ASSETS = dbutils.widgets.get("fetch_osm_assets").strip().lower() == "true"  # noqa: F821
ADD_ELEVATION = dbutils.widgets.get("add_elevation").strip().lower() == "true"  # noqa: F821
ELEVATION_BATCH_SIZE = int(dbutils.widgets.get("elevation_batch_size").strip() or "100")  # noqa: F821
ELEVATION_TIMEOUT = int(dbutils.widgets.get("elevation_timeout").strip() or "30")  # noqa: F821
ELEVATION_RETRIES = int(dbutils.widgets.get("elevation_retries").strip() or "8")  # noqa: F821
ELEVATION_PAUSE = float(dbutils.widgets.get("elevation_pause").strip() or "2.0")  # noqa: F821

if not _bbox_raw:
    raise ValueError("Widget 'bbox' is empty.  Provide min_lon,min_lat,max_lon,max_lat.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")

_bbox_parts = [float(v.strip()) for v in _bbox_raw.split(",")]
if len(_bbox_parts) != 4:
    raise ValueError(f"Widget 'bbox' must have exactly 4 values; got: {_bbox_raw!r}")

MIN_LON, MIN_LAT, MAX_LON, MAX_LAT = _bbox_parts

logger.info(
    "bbox=[%.4f, %.4f, %.4f, %.4f]  output_uri=%s  area_id=%s",
    MIN_LON,
    MIN_LAT,
    MAX_LON,
    MAX_LAT,
    OUTPUT_URI,
    AREA_ID,
)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run OsmPrepare pipeline
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ──────────────────────────────────────────────────────────

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")
print(f"Bbox      : [{MIN_LON}, {MIN_LAT}, {MAX_LON}, {MAX_LAT}]")
print(f"Output    : {OUTPUT_URI}")
print(f"Area ID   : {AREA_ID or '(auto-discover)'}")
print(f"Refresh   : {REFRESH}")
print(f"Debug     : {DEBUG}")
print()

# The pipeline writes to a local Path; map OUTPUT_URI to /dbfs/... or tmp
_out_dir = Path(OUTPUT_URI.removeprefix("file://"))
_out_dir.mkdir(parents=True, exist_ok=True)

area_id = run_pipeline(
    MIN_LON,
    MIN_LAT,
    MAX_LON,
    MAX_LAT,
    _out_dir,
    area_id=AREA_ID,
    name=NAME,
    target_footprint_m2=TARGET_FOOTPRINT_M2,
    max_routes=MAX_ROUTES,
    overpass_url=OVERPASS_URL,
    overpass_timeout=OVERPASS_TIMEOUT,
    external_share=EXTERNAL_SHARE,
    peak_hour_fraction=PEAK_HOUR_FRACTION,
    population=POPULATION,
    refresh=REFRESH,
    debug=DEBUG,
    annotate_traffic_signals=ANNOTATE_TRAFFIC_SIGNALS,
    fetch_traffic_signs=FETCH_TRAFFIC_SIGNS,
    fetch_osm_assets=FETCH_OSM_ASSETS,
    add_elevation=ADD_ELEVATION,
    elevation_batch_size=ELEVATION_BATCH_SIZE,
    elevation_timeout=ELEVATION_TIMEOUT,
    elevation_retries=ELEVATION_RETRIES,
    elevation_pause=ELEVATION_PAUSE,
)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ─────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"OsmPrepare complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Area ID   : {area_id}")
print(f"  Network   : {_out_dir / f'{area_id}-NETWORK-CAR.parquet'}")
print(f"  Feedlinks : {_out_dir / f'{area_id}-FEEDLINK-CAR.parquet'}")
print(f"  Zones     : {_out_dir / f'{area_id}-ZONE-CAR.parquet'}")
print(f"  Routes    : {_out_dir / f'{area_id}-ROUTES-CAR.parquet'}")
print(_SEP)
