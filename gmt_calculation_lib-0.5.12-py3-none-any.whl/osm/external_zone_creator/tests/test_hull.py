"""Tests for the convex/concave hull helpers."""

from __future__ import annotations

from osm.external_zone_creator.domain.hull import (
    concave_hull,
    convex_hull,
    hull_vertices,
)


def _as_set(points):
    return {(round(p[0], 6), round(p[1], 6)) for p in points}


class TestConvexHull:
    def test_square_corners(self):
        pts = [[0, 0], [1, 0], [1, 1], [0, 1]]
        ring = convex_hull(pts)
        assert ring[0] == ring[-1]  # closed
        assert _as_set(ring[:-1]) == _as_set(pts)

    def test_interior_point_excluded(self):
        pts = [[0, 0], [2, 0], [2, 2], [0, 2], [1, 1]]
        ring = convex_hull(pts)
        assert (1.0, 1.0) not in _as_set(ring)

    def test_too_few_points(self):
        assert convex_hull([[0, 0], [1, 1]]) == []


class TestConcaveHull:
    def test_encloses_all_points(self):
        # Random-ish scattered points.
        pts = [
            [0, 0],
            [1, 0],
            [2, 0],
            [2, 1],
            [2, 2],
            [1, 2],
            [0, 2],
            [0, 1],
            [1, 1],
        ]
        verts = hull_vertices(pts, hull_type="concave", k=3)
        # Interior point (1,1) must not be a hull vertex.
        assert (1.0, 1.0) not in _as_set(verts)
        # All vertices are input points.
        assert _as_set(verts).issubset(_as_set(pts))

    def test_convex_pointset_keeps_collinear_boundary(self):
        # All 8 points lie on the square boundary (4 corners + 4 edge midpoints).
        # The convex hull drops the collinear midpoints; the concave hull keeps
        # them (they are genuine boundary nodes) — this is the desired behaviour.
        pts = [[0, 0], [4, 0], [4, 4], [0, 4], [2, 0], [4, 2], [2, 4], [0, 2]]
        convex = _as_set(hull_vertices(pts, hull_type="convex"))
        concave = _as_set(hull_vertices(pts, hull_type="concave", k=3))
        assert convex == _as_set([[0, 0], [4, 0], [4, 4], [0, 4]])
        assert concave == _as_set(pts)

    def test_concavity_is_followed(self):
        # Rectangle [0,4]x[0,3] with a wide, deep rectangular notch cut into the
        # TOP (x in [1,3], y in [1,3]).  The notch mouth (width 2) is wider than
        # the point spacing, so the concave hull carves it out while the convex
        # hull bridges it.
        from gmt_shared.geo import point_in_polygon

        def frange(a, b, step):
            n = round((b - a) / step)
            return [round(a + i * step, 3) for i in range(n + 1)]

        pts: list[list[float]] = [[x, 0.0] for x in frange(0, 4, 0.5)]  # bottom
        pts.extend([4.0, y] for y in frange(0, 3, 0.5))  # right wall
        pts.extend([0.0, y] for y in frange(0, 3, 0.5))  # left wall
        pts.extend([x, 3.0] for x in frange(0, 1, 0.5))  # top-left segment
        pts.extend([x, 3.0] for x in frange(3, 4, 0.5))  # top-right segment
        pts.extend([1.0, y] for y in frange(1, 3, 0.5))  # notch left wall
        pts.extend([3.0, y] for y in frange(1, 3, 0.5))  # notch right wall
        pts.extend([x, 1.0] for x in frange(1, 3, 0.5))  # notch floor

        convex_ring = convex_hull(pts)
        concave_ring = concave_hull(pts, k=3)

        notch_centre = (2.0, 2.4)  # inside the cut-out notch
        assert point_in_polygon(notch_centre[0], notch_centre[1], convex_ring)
        assert not point_in_polygon(notch_centre[0], notch_centre[1], concave_ring)

    def test_all_points_inside_returned_ring(self):
        # Grid of points; every point must lie inside-or-on the concave hull.
        pts = [[float(x), float(y)] for x in range(5) for y in range(5)]
        ring = concave_hull(pts, k=3)
        from gmt_shared.geo import point_in_polygon

        def _on_segment(p, a, b):
            cross = (b[0] - a[0]) * (p[1] - a[1]) - (b[1] - a[1]) * (p[0] - a[0])
            if abs(cross) > 1e-9:
                return False
            return (
                min(a[0], b[0]) - 1e-9 <= p[0] <= max(a[0], b[0]) + 1e-9
                and min(a[1], b[1]) - 1e-9 <= p[1] <= max(a[1], b[1]) + 1e-9
            )

        for p in pts:
            on_edge = any(_on_segment(p, ring[i - 1], ring[i]) for i in range(1, len(ring)))
            assert on_edge or point_in_polygon(p[0], p[1], ring)
