"""Building classification into simplified categories.

Maps OSM tags to one of eight building types:
  school | house | hospital | recreational | shopping | work | parking | other

Mapping table
-------------
The table below shows the authoritative mapping from OSM tags to motieven.
The m² of each building is later aggregated per motief per zone/link.

building= tag  (specific — cannot be overridden by use tags)
  parking      → parking   (incl. garage, garages, carport)
  school       → school    (incl. university, college, kindergarten)
  hospital     → hospital  (incl. clinic)
  hotel / hostel / motel / guest_house            → recreational
  church / chapel / cathedral / mosque / synagogue
    / temple / shrine / place_of_worship          → recreational
  sports_hall / stadium / sports_centre
    / grandstand / pavilion / riding_hall
    / swimming_pool / gym / theatre / cinema
    / community_centre / social_centre             → recreational
  retail / supermarket / shop / kiosk
    / commercial / mall                           → shopping
  office / industrial / warehouse / factory
    / manufacture / storage_tank / barn
    / farm_auxiliary / greenhouse / digester
    / civic / public / government
    / fire_station / police
    / train_station / transportation / service    → work

building= tag  (generic — overridable by use tags)
  yes / house / residential / apartments
    / detached / terrace / semi_detached
    / bungalow / dormitory / block_of_flats
    / static_caravan / cabin / farm              → house (default)
    … but if the element also carries a use tag  → see use-tag priority

Use tags checked after specific building= and before generic building=
  amenity=parking  /  park_ride=*               → parking
  amenity ∈ school set                           → school
  amenity ∈ hospital set                         → hospital
  amenity ∈ recreational set
    (restaurant / cafe / fast_food / bar / pub
     / nightclub / theatre / cinema / arts_centre
     / community_centre / social_centre
     / stadium / sports_centre / swimming_pool)  → recreational
  tourism ∈ recreational set
    (hotel / hostel / motel / guest_house
     / chalet / museum / gallery / attraction
     / theme_park / aquarium / zoo / viewpoint)  → recreational
  amenity ∈ shopping set
    (marketplace / car_wash / fuel)              → shopping
  shop=*   (any value)                           → shopping
  office=* (any value)                           → work
  leisure ∈ recreational set                     → recreational

For buildings tagged ``building=yes`` or any generic residential type, the
classifier checks use tags first.  The spatial containment analysis in
``osm_building_fetcher_core`` may additionally supply ``contained_poi_tags``
(tags of POI nodes found inside the building polygon) to further refine the
classification via :func:`classify_building_with_pois`.

Public API
----------
classify_building(tags) -> str
    Return the building type for a dict of OSM tags.
classify_building_with_pois(building_tags, contained_poi_tags) -> str
    Like classify_building but also considers POI nodes inside the polygon.
is_parking_element(tags) -> bool
    Return True if an OSM element represents a parking facility or P+R,
    even when it has no ``building=`` tag.
is_work_element(tags) -> bool
    Return True if an OSM element represents an office or industrial
    facility even when it has no ``building=`` tag.
is_poi_node(tags) -> bool
    Return True if a node should be fetched as a standalone POI (no building
    tag required) for containment analysis.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# building= tag sets — SPECIFIC (cannot be overridden by use tags)
# ---------------------------------------------------------------------------

_PARKING_BUILDING: frozenset[str] = frozenset(
    {
        "parking",
        "garage",
        "garages",
        "carport",
    }
)

_SCHOOL_BUILDING: frozenset[str] = frozenset(
    {
        "school",
        "university",
        "college",
        "kindergarten",
    }
)

_HOSPITAL_BUILDING: frozenset[str] = frozenset(
    {
        "hospital",
        "clinic",
    }
)

_RECREATIONAL_BUILDING: frozenset[str] = frozenset(
    {
        # accommodation
        "hotel",
        "hostel",
        "motel",
        "guest_house",
        # religion / culture
        "church",
        "chapel",
        "cathedral",
        "mosque",
        "synagogue",
        "temple",
        "shrine",
        "place_of_worship",
        # sport
        "sports_hall",
        "stadium",
        "sports_centre",
        "grandstand",
        "pavilion",
        "riding_hall",
        "swimming_pool",
        "gym",
        # culture / entertainment
        "theatre",
        "cinema",
        "community_centre",
        "social_centre",
    }
)

_SHOPPING_BUILDING: frozenset[str] = frozenset(
    {
        "retail",
        "supermarket",
        "shop",
        "kiosk",
        "commercial",
        "mall",
    }
)

_WORK_BUILDING: frozenset[str] = frozenset(
    {
        # industry / logistics
        "office",
        "industrial",
        "warehouse",
        "factory",
        "manufacture",
        "storage_tank",
        "barn",
        "farm_auxiliary",
        "greenhouse",
        "digester",
        # public services / infrastructure
        "civic",
        "public",
        "government",
        "fire_station",
        "police",
        "train_station",
        "transportation",
        "service",
    }
)

# ---------------------------------------------------------------------------
# building= tag sets — GENERIC (overridable by use tags below)
# ---------------------------------------------------------------------------

_GENERIC_RESIDENTIAL_BUILDING: frozenset[str] = frozenset(
    {
        "yes",
        "house",
        "residential",
        "apartments",
        "detached",
        "terrace",
        "semi_detached",
        "bungalow",
        "dormitory",
        "block_of_flats",
        "static_caravan",
        "cabin",
        "farm",
    }
)

# ---------------------------------------------------------------------------
# amenity= tag sets
# ---------------------------------------------------------------------------

_SCHOOL_AMENITY: frozenset[str] = frozenset(
    {
        "school",
        "university",
        "college",
        "kindergarten",
        "language_school",
        "driving_school",
        "music_school",
    }
)

_HOSPITAL_AMENITY: frozenset[str] = frozenset(
    {
        "hospital",
        "clinic",
        "doctors",
        "dentist",
        "pharmacy",
        "nursing_home",
        "social_facility",
    }
)

_RECREATIONAL_AMENITY: frozenset[str] = frozenset(
    {
        # horeca
        "restaurant",
        "cafe",
        "fast_food",
        "bar",
        "pub",
        "nightclub",
        "biergarten",
        "food_court",
        "ice_cream",
        # culture / entertainment
        "theatre",
        "cinema",
        "arts_centre",
        "community_centre",
        "social_centre",
        "events_venue",
        # sport
        "stadium",
        "sports_centre",
        "swimming_pool",
    }
)

_SHOPPING_AMENITY: frozenset[str] = frozenset(
    {
        "marketplace",
        "car_wash",
        "fuel",
    }
)

# ---------------------------------------------------------------------------
# tourism= tag set → recreational
# ---------------------------------------------------------------------------

_RECREATIONAL_TOURISM: frozenset[str] = frozenset(
    {
        # accommodation
        "hotel",
        "hostel",
        "motel",
        "guest_house",
        "chalet",
        "apartment",
        # attractions
        "museum",
        "gallery",
        "attraction",
        "theme_park",
        "aquarium",
        "zoo",
        "viewpoint",
    }
)

# ---------------------------------------------------------------------------
# leisure= tag set → recreational
# ---------------------------------------------------------------------------

_RECREATIONAL_LEISURE: frozenset[str] = frozenset(
    {
        "sports_centre",
        "stadium",
        "swimming_pool",
        "fitness_centre",
        "dance",
        "horse_riding",
        "ice_rink",
        "pitch",
        "track",
        "recreation_ground",
        "theatre",
        "bowling_alley",
        "amusement_arcade",
        "escape_game",
        "trampoline_park",
        "miniature_golf",
    }
)

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _classify_use_tags(tags: dict[str, str]) -> str | None:
    """Classify based purely on use tags (amenity/tourism/shop/office/leisure).

    Returns ``None`` when no recognisable use tag is present.
    This is intentionally separate so it can be called both for same-element
    use tags and for POI tags found *inside* a generic building polygon.
    """
    amenity = tags.get("amenity", "").strip().lower()
    tourism = tags.get("tourism", "").strip().lower()
    shop = tags.get("shop", "").strip().lower()
    office = tags.get("office", "").strip().lower()
    leisure = tags.get("leisure", "").strip().lower()
    park_ride = tags.get("park_ride", "").strip().lower()

    if amenity == "parking":
        return "parking"
    if park_ride:
        return "parking"
    if amenity in _SCHOOL_AMENITY:
        return "school"
    if amenity in _HOSPITAL_AMENITY:
        return "hospital"
    if amenity in _RECREATIONAL_AMENITY:
        return "recreational"
    if tourism in _RECREATIONAL_TOURISM:
        return "recreational"
    if amenity in _SHOPPING_AMENITY:
        return "shopping"
    if shop:
        return "shopping"
    if office:
        return "work"
    if leisure in _RECREATIONAL_LEISURE:
        return "recreational"
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def classify_building(tags: dict[str, str]) -> str:
    """Classify a building based on its OSM tags.

    Priority order
    --------------
    1. ``building=`` in a *specific* set (parking / school / hospital /
       recreational / shopping / work) — these are never overridden.
    2. Use tags on the *same element* (amenity / tourism / shop / office /
       leisure / park_ride) — these override generic structural building= tags.
    3. ``building=`` in the *generic residential* set → ``'house'``.
    4. Fallback → ``'other'``.

    Parameters
    ----------
    tags:
        Dict of OSM tag key/value pairs for the element.

    Returns
    -------
    str
        One of ``'school'``, ``'house'``, ``'hospital'``,
        ``'recreational'``, ``'shopping'``, ``'work'``,
        ``'parking'``, or ``'other'``.
    """
    building = tags.get("building", "").strip().lower()

    # ── 1. Specific building= types ─────────────────────────────────────────
    if building in _PARKING_BUILDING:
        return "parking"
    if building in _SCHOOL_BUILDING:
        return "school"
    if building in _HOSPITAL_BUILDING:
        return "hospital"
    if building in _RECREATIONAL_BUILDING:
        return "recreational"
    if building in _SHOPPING_BUILDING:
        return "shopping"
    if building in _WORK_BUILDING:
        return "work"

    # ── 2. Use tags (override generic structural tags) ───────────────────────
    use_type = _classify_use_tags(tags)
    if use_type is not None:
        return use_type

    # ── 3. Generic residential building= → house ────────────────────────────
    if building in _GENERIC_RESIDENTIAL_BUILDING:
        return "house"

    return "other"


def classify_building_with_pois(
    building_tags: dict[str, str],
    contained_poi_tags: list[dict[str, str]],
) -> str:
    """Classify a building, using POI nodes inside the polygon as extra context.

    For buildings with a *specific* ``building=`` tag the classification is
    authoritative and is returned immediately without checking POIs.

    For buildings with a *generic* ``building=`` tag (``yes``, ``house``,
    ``residential``, …) the POI nodes inside the polygon are checked.  The
    most prominent use found among the POIs takes precedence:
    priority order is parking > school > hospital > recreational >
    shopping > work > house.

    Parameters
    ----------
    building_tags:
        OSM tags of the building element itself.
    contained_poi_tags:
        List of tag dicts for POI nodes found spatially inside the building
        polygon (typically nodes with ``amenity``, ``shop``, ``tourism``,
        ``office``, or ``leisure`` tags but no ``building=`` tag of their own).

    Returns
    -------
    str
        One of the eight building-type strings.
    """
    building = building_tags.get("building", "").strip().lower()

    # Specific building= → authoritative, ignore POIs
    if building in _PARKING_BUILDING:
        return "parking"
    if building in _SCHOOL_BUILDING:
        return "school"
    if building in _HOSPITAL_BUILDING:
        return "hospital"
    if building in _RECREATIONAL_BUILDING:
        return "recreational"
    if building in _SHOPPING_BUILDING:
        return "shopping"
    if building in _WORK_BUILDING:
        return "work"

    # Use tags on the building element itself
    use_type = _classify_use_tags(building_tags)
    if use_type is not None:
        return use_type

    # No specific classification → check contained POIs
    if contained_poi_tags:
        # Rank POI types by priority (most specific / least-common wins)
        priority_order = ("parking", "school", "hospital", "recreational", "shopping", "work")
        poi_types: list[str] = []
        for poi_tags in contained_poi_tags:
            t = _classify_use_tags(poi_tags)
            if t is not None and t != "other":
                poi_types.append(t)

        for priority_type in priority_order:
            if priority_type in poi_types:
                return priority_type

    # Generic residential default
    if building in _GENERIC_RESIDENTIAL_BUILDING:
        return "house"

    return "other"


def is_parking_element(tags: dict[str, str]) -> bool:
    """Return True if an OSM element is a parking facility or P+R.

    Used to include surface parking lots and P+R nodes that carry no
    ``building`` tag in the buildings pipeline.

    Parameters
    ----------
    tags:
        Dict of OSM tag key/value pairs for the element.
    """
    amenity = tags.get("amenity", "").strip().lower()
    park_ride = tags.get("park_ride", "").strip().lower()
    building = tags.get("building", "").strip().lower()
    return amenity == "parking" or bool(park_ride) or building in _PARKING_BUILDING


def is_work_element(tags: dict[str, str]) -> bool:
    """Return True if an OSM element is an office or industrial facility.

    Used to include work-related elements that carry no ``building`` tag
    (e.g. ``office=*`` nodes) in the buildings pipeline.

    Parameters
    ----------
    tags:
        Dict of OSM tag key/value pairs for the element.
    """
    office = tags.get("office", "").strip().lower()
    building = tags.get("building", "").strip().lower()
    return bool(office) or building in _WORK_BUILDING


def is_poi_node(tags: dict[str, str]) -> bool:
    """Return True if a *node* should be treated as a standalone POI.

    POI nodes are fetched alongside buildings so that the containment
    analyser can find the actual use of generic ``building=yes`` or
    ``building=house`` polygons.  A node qualifies when it carries at
    least one use tag (amenity / shop / tourism / office / leisure) but
    does *not* have its own ``building=`` tag (those are handled as
    building elements).

    Parameters
    ----------
    tags:
        Dict of OSM tag key/value pairs for the element.
    """
    if tags.get("building"):
        return False
    return bool(
        tags.get("amenity")
        or tags.get("shop")
        or tags.get("tourism")
        or tags.get("office")
        or tags.get("leisure")
    )
