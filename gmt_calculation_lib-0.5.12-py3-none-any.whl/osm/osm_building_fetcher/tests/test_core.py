"""Tests for osm_building_fetcher domain modules and core.

Covers:
- classify_building — all 8 types (including parking) + edge cases
- classify_building_with_pois — POI containment overrides generic buildings
- is_parking_element — amenity=parking, park_ride, building=parking
- is_work_element — office=*, building=office/industrial/…
- is_poi_node — standalone amenity/shop/tourism/leisure nodes
- element_centroid — node and way elements
- element_to_feature — geometry, properties mapping, OSM tag prefix, parkingCapacity
- build_buildings_and_streets_query — Overpass QL output (parking + POI filters)
- link_buildings_to_streets — name match, nearest fallback, no streets
- find_pois_in_building — point-in-polygon containment
- build_buildings — integration with mocked Overpass response
"""

from __future__ import annotations

from typing import ClassVar, cast
from unittest.mock import patch

import pytest

from osm_building_fetcher.domain.classifier import (
    classify_building,
    classify_building_with_pois,
    is_parking_element,
    is_poi_node,
    is_work_element,
)
from osm_building_fetcher.domain.geometry import element_centroid, element_to_feature
from osm_building_fetcher.domain.overpass import build_buildings_and_streets_query
from osm_building_fetcher.domain.street_linker import link_buildings_to_streets

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _way(eid: int, tags: dict, geom: list[dict] | None = None) -> dict:
    return {
        "type": "way",
        "id": eid,
        "tags": tags,
        "geometry": geom
        or [
            {"lon": 6.10, "lat": 52.25},
            {"lon": 6.11, "lat": 52.25},
            {"lon": 6.11, "lat": 52.26},
            {"lon": 6.10, "lat": 52.26},
            {"lon": 6.10, "lat": 52.25},
        ],
    }


def _node(eid: int, tags: dict, lon: float = 6.15, lat: float = 52.26) -> dict:
    return {"type": "node", "id": eid, "tags": tags, "lon": lon, "lat": lat}


def _street(eid: int, name: str, lon: float = 6.12, lat: float = 52.25) -> dict:
    return {
        "type": "way",
        "id": eid,
        "tags": {"highway": "residential", "name": name},
        "geometry": [
            {"lon": lon, "lat": lat},
            {"lon": lon + 0.001, "lat": lat},
        ],
    }


# ---------------------------------------------------------------------------
# classify_building
# ---------------------------------------------------------------------------


class TestClassifyBuilding:
    def test_school_via_building_tag(self) -> None:
        assert classify_building({"building": "school"}) == "school"

    def test_school_via_university(self) -> None:
        assert classify_building({"building": "university"}) == "school"

    def test_school_via_amenity(self) -> None:
        assert classify_building({"building": "yes", "amenity": "kindergarten"}) == "school"

    def test_house_via_building_tag(self) -> None:
        assert classify_building({"building": "house"}) == "house"

    def test_house_apartments(self) -> None:
        assert classify_building({"building": "apartments"}) == "house"

    def test_hospital_via_building_tag(self) -> None:
        assert classify_building({"building": "hospital"}) == "hospital"

    def test_hospital_via_amenity(self) -> None:
        assert classify_building({"building": "yes", "amenity": "clinic"}) == "hospital"

    def test_recreational_via_building_tag(self) -> None:
        assert classify_building({"building": "sports_hall"}) == "recreational"

    def test_recreational_via_leisure(self) -> None:
        assert classify_building({"building": "yes", "leisure": "sports_centre"}) == "recreational"

    def test_recreational_via_amenity_theatre(self) -> None:
        assert classify_building({"building": "yes", "amenity": "theatre"}) == "recreational"

    def test_shopping_via_building_tag(self) -> None:
        assert classify_building({"building": "retail"}) == "shopping"

    def test_shopping_via_shop_tag(self) -> None:
        assert classify_building({"building": "yes", "shop": "bakery"}) == "shopping"

    def test_shopping_via_supermarket(self) -> None:
        assert classify_building({"building": "supermarket"}) == "shopping"

    def test_building_yes_alone_defaults_to_house(self) -> None:
        # building=yes without any use tag → generic residential default
        assert classify_building({"building": "yes"}) == "house"

    def test_other_for_empty_tags(self) -> None:
        assert classify_building({}) == "other"

    def test_use_tag_overrides_generic_building(self) -> None:
        # amenity=school overrides generic building=house (use tag takes priority)
        assert classify_building({"building": "house", "amenity": "school"}) == "school"

    def test_use_tag_does_not_override_specific_building(self) -> None:
        # building=school is a specific tag; amenity=fast_food cannot override it
        assert classify_building({"building": "school", "amenity": "fast_food"}) == "school"

    def test_hotel_building_is_recreational(self) -> None:
        assert classify_building({"building": "hotel"}) == "recreational"

    def test_church_building_is_recreational(self) -> None:
        assert classify_building({"building": "church"}) == "recreational"

    def test_mosque_building_is_recreational(self) -> None:
        assert classify_building({"building": "mosque"}) == "recreational"

    def test_civic_building_is_work(self) -> None:
        assert classify_building({"building": "civic"}) == "work"

    def test_government_building_is_work(self) -> None:
        assert classify_building({"building": "government"}) == "work"

    def test_tourism_hotel_is_recreational(self) -> None:
        assert classify_building({"building": "yes", "tourism": "hotel"}) == "recreational"

    def test_tourism_museum_is_recreational(self) -> None:
        assert classify_building({"tourism": "museum"}) == "recreational"

    def test_fast_food_on_house_building_is_recreational(self) -> None:
        # building=house with amenity=fast_food → actual use is recreational
        assert classify_building({"building": "house", "amenity": "fast_food"}) == "recreational"

    def test_shop_on_yes_building_is_shopping(self) -> None:
        assert classify_building({"building": "yes", "shop": "bakery"}) == "shopping"

    def test_case_insensitive_tags(self) -> None:
        # The classifier lowercases the tag value, so 'HOUSE' → 'house' → matches
        assert classify_building({"building": "HOUSE"}) == "house"

    # --- parking ---
    def test_parking_via_building_parking(self) -> None:
        assert classify_building({"building": "parking"}) == "parking"

    def test_parking_via_building_garage(self) -> None:
        assert classify_building({"building": "garage"}) == "parking"

    def test_parking_via_building_garages(self) -> None:
        assert classify_building({"building": "garages"}) == "parking"

    def test_parking_via_amenity_parking(self) -> None:
        assert classify_building({"amenity": "parking"}) == "parking"

    def test_parking_via_park_ride(self) -> None:
        assert classify_building({"park_ride": "yes"}) == "parking"

    def test_parking_building_tag_beats_amenity(self) -> None:
        # building=parking is already parking, extra amenity tag irrelevant
        assert classify_building({"building": "parking", "amenity": "school"}) == "parking"

    # --- work ---
    def test_work_via_building_office(self) -> None:
        assert classify_building({"building": "office"}) == "work"

    def test_work_via_building_industrial(self) -> None:
        assert classify_building({"building": "industrial"}) == "work"

    def test_work_via_building_warehouse(self) -> None:
        assert classify_building({"building": "warehouse"}) == "work"

    def test_work_via_building_factory(self) -> None:
        assert classify_building({"building": "factory"}) == "work"

    def test_work_via_office_tag(self) -> None:
        assert classify_building({"office": "yes"}) == "work"

    def test_work_via_office_company(self) -> None:
        assert classify_building({"office": "company"}) == "work"

    def test_work_office_tag_beats_amenity_school(self) -> None:
        # office= is checked after amenity=, but a bare office tag with no
        # special amenity should still classify as work
        assert classify_building({"office": "government"}) == "work"


# ---------------------------------------------------------------------------
# classify_building_with_pois
# ---------------------------------------------------------------------------


class TestClassifyBuildingWithPois:
    def test_specific_building_tag_ignores_pois(self) -> None:
        # building=school is specific → not overridden by any POI
        pois = [{"amenity": "fast_food"}]
        assert classify_building_with_pois({"building": "school"}, pois) == "school"

    def test_yes_building_with_fast_food_poi_is_recreational(self) -> None:
        pois = [{"amenity": "fast_food"}]
        assert classify_building_with_pois({"building": "yes"}, pois) == "recreational"

    def test_house_building_with_shop_poi_is_shopping(self) -> None:
        pois = [{"shop": "bakery"}]
        assert classify_building_with_pois({"building": "house"}, pois) == "shopping"

    def test_yes_building_with_hotel_tourism_poi_is_recreational(self) -> None:
        pois = [{"tourism": "hotel"}]
        assert classify_building_with_pois({"building": "yes"}, pois) == "recreational"

    def test_yes_building_with_office_poi_is_work(self) -> None:
        pois = [{"office": "company"}]
        assert classify_building_with_pois({"building": "yes"}, pois) == "work"

    def test_yes_building_no_pois_defaults_to_house(self) -> None:
        assert classify_building_with_pois({"building": "yes"}, []) == "house"

    def test_house_building_no_pois_is_house(self) -> None:
        assert classify_building_with_pois({"building": "house"}, []) == "house"

    def test_priority_parking_over_shopping(self) -> None:
        # Multiple POIs: parking takes highest priority
        pois = [{"shop": "bakery"}, {"amenity": "parking"}]
        assert classify_building_with_pois({"building": "yes"}, pois) == "parking"

    def test_use_tag_on_building_element_itself(self) -> None:
        # amenity on the building element itself works without POIs
        result = classify_building_with_pois({"building": "yes", "amenity": "restaurant"}, [])
        assert result == "recreational"


# ---------------------------------------------------------------------------
# is_poi_node
# ---------------------------------------------------------------------------


class TestIsPoisNode:
    def test_amenity_node_is_poi(self) -> None:
        assert is_poi_node({"amenity": "fast_food"}) is True

    def test_shop_node_is_poi(self) -> None:
        assert is_poi_node({"shop": "bakery"}) is True

    def test_tourism_node_is_poi(self) -> None:
        assert is_poi_node({"tourism": "hotel"}) is True

    def test_leisure_node_is_poi(self) -> None:
        assert is_poi_node({"leisure": "sports_centre"}) is True

    def test_office_node_is_poi(self) -> None:
        assert is_poi_node({"office": "company"}) is True

    def test_node_with_building_tag_is_not_poi(self) -> None:
        # Has a building= tag → treated as building element, not POI
        assert is_poi_node({"amenity": "fast_food", "building": "yes"}) is False

    def test_node_with_only_name_is_not_poi(self) -> None:
        assert is_poi_node({"name": "Something"}) is False

    def test_empty_tags_is_not_poi(self) -> None:
        assert is_poi_node({}) is False


# ---------------------------------------------------------------------------
# is_parking_element
# ---------------------------------------------------------------------------


class TestIsParkingElement:
    def test_amenity_parking(self) -> None:
        assert is_parking_element({"amenity": "parking"}) is True

    def test_park_ride_yes(self) -> None:
        assert is_parking_element({"park_ride": "yes"}) is True

    def test_park_ride_bus(self) -> None:
        assert is_parking_element({"park_ride": "bus"}) is True

    def test_building_parking(self) -> None:
        assert is_parking_element({"building": "parking"}) is True

    def test_building_garage(self) -> None:
        assert is_parking_element({"building": "garage"}) is True

    def test_building_house_is_not_parking(self) -> None:
        assert is_parking_element({"building": "house"}) is False

    def test_empty_tags_is_not_parking(self) -> None:
        assert is_parking_element({}) is False

    def test_amenity_school_is_not_parking(self) -> None:
        assert is_parking_element({"amenity": "school"}) is False


# ---------------------------------------------------------------------------
# is_work_element
# ---------------------------------------------------------------------------


class TestIsWorkElement:
    def test_office_tag_yes(self) -> None:
        assert is_work_element({"office": "yes"}) is True

    def test_office_tag_company(self) -> None:
        assert is_work_element({"office": "company"}) is True

    def test_building_office(self) -> None:
        assert is_work_element({"building": "office"}) is True

    def test_building_industrial(self) -> None:
        assert is_work_element({"building": "industrial"}) is True

    def test_building_warehouse(self) -> None:
        assert is_work_element({"building": "warehouse"}) is True

    def test_building_house_is_not_work(self) -> None:
        assert is_work_element({"building": "house"}) is False

    def test_empty_tags_is_not_work(self) -> None:
        assert is_work_element({}) is False

    def test_amenity_school_is_not_work(self) -> None:
        assert is_work_element({"amenity": "school"}) is False


# ---------------------------------------------------------------------------
# element_centroid
# ---------------------------------------------------------------------------


class TestElementCentroid:
    def test_node_centroid(self) -> None:
        node = _node(1, {}, lon=6.15, lat=52.26)
        result = element_centroid(node)
        assert result is not None
        assert result == pytest.approx((6.15, 52.26))

    def test_way_centroid(self) -> None:
        way = _way(
            2,
            {},
            geom=[
                {"lon": 0.0, "lat": 0.0},
                {"lon": 2.0, "lat": 0.0},
                {"lon": 2.0, "lat": 2.0},
                {"lon": 0.0, "lat": 2.0},
            ],
        )
        result = element_centroid(way)
        assert result is not None
        assert result == pytest.approx((1.0, 1.0))

    def test_node_missing_coords(self) -> None:
        node = {"type": "node", "id": 3, "tags": {}}
        assert element_centroid(node) is None

    def test_way_no_geometry(self) -> None:
        way = {"type": "way", "id": 4, "tags": {}, "geometry": []}
        assert element_centroid(way) is None


# ---------------------------------------------------------------------------
# element_to_feature
# ---------------------------------------------------------------------------


class TestElementToFeature:
    def test_node_becomes_point(self) -> None:
        node = _node(10, {"building": "house", "addr:street": "Hoofdstraat"})
        feat = element_to_feature(node, "house", "Hoofdstraat", "osm_99")
        assert feat["geometry"]["type"] == "Point"
        assert feat["geometry"]["coordinates"] == pytest.approx([6.15, 52.26])

    def test_way_becomes_polygon(self) -> None:
        way = _way(20, {"building": "school"})
        feat = element_to_feature(way, "school", "Schoolstraat", "osm_88")
        assert feat["geometry"]["type"] == "Polygon"
        # Ring should be closed
        ring = feat["geometry"]["coordinates"][0]
        assert ring[0] == ring[-1]

    def test_properties_populated(self) -> None:
        node = _node(11, {"building": "retail", "name": "AH"})
        feat = element_to_feature(node, "shopping", "Winkelstraat", "osm_77")
        props = feat["properties"]
        assert props["buildingId"] == "osm_11"
        assert props["buildingType"] == "shopping"
        assert props["streetName"] == "Winkelstraat"
        assert props["streetId"] == "osm_77"

    def test_osm_tags_prefixed(self) -> None:
        node = _node(12, {"building": "house", "addr:housenumber": "5a"})
        feat = element_to_feature(node, "house", None, None)
        props = feat["properties"]
        assert "tag_building" in props
        assert props["tag_building"] == "house"
        assert props["tag_addr:housenumber"] == "5a"

    def test_none_street_preserved(self) -> None:
        node = _node(13, {"building": "yes"})
        feat = element_to_feature(node, "other", None, None)
        assert feat["properties"]["streetName"] is None
        assert feat["properties"]["streetId"] is None

    def test_polygon_ring_auto_closed(self) -> None:
        # Geometry without closing vertex should be closed automatically
        way = _way(
            30,
            {"building": "yes"},
            geom=[
                {"lon": 1.0, "lat": 1.0},
                {"lon": 2.0, "lat": 1.0},
                {"lon": 2.0, "lat": 2.0},
            ],
        )
        feat = element_to_feature(way, "other", None, None)
        ring = feat["geometry"]["coordinates"][0]
        assert ring[0] == ring[-1]

    def test_feature_type(self) -> None:
        node = _node(14, {"building": "hospital"})
        feat = element_to_feature(node, "hospital", None, None)
        assert feat["type"] == "Feature"


# ---------------------------------------------------------------------------
# build_buildings_and_streets_query
# ---------------------------------------------------------------------------


class TestBuildBuildingsAndStreetsQuery:
    def test_contains_building_way_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'way["building"]' in q

    def test_contains_building_node_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'node["building"]' in q

    def test_contains_highway_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'way["highway"]' in q

    def test_bbox_order_is_lat_lon(self) -> None:
        # Overpass expects south,west,north,east
        q = build_buildings_and_streets_query([6.143, 52.248, 6.184, 52.272])
        assert "52.248,6.143,52.272,6.184" in q

    def test_json_output_format(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "[out:json]" in q

    def test_custom_timeout(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1], timeout=120)
        assert "[timeout:120]" in q

    def test_out_geom(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "out geom" in q

    def test_contains_office_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'way["office"]' in q

    def test_contains_office_node_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'node["office"]' in q

    def test_contains_poi_amenity_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'node["amenity"][!"building"]' in q

    def test_contains_poi_shop_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'node["shop"][!"building"]' in q

    def test_contains_poi_tourism_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'node["tourism"][!"building"]' in q

    def test_contains_poi_leisure_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'node["leisure"][!"building"]' in q


# ---------------------------------------------------------------------------
# find_pois_in_building
# ---------------------------------------------------------------------------


class TestFindPoisInBuilding:
    def _square_way(self, lon0: float, lat0: float, lon1: float, lat1: float) -> dict:
        """Helper: create a way element forming a closed rectangle."""
        return {
            "type": "way",
            "id": 9000,
            "tags": {"building": "yes"},
            "geometry": [
                {"lon": lon0, "lat": lat0},
                {"lon": lon1, "lat": lat0},
                {"lon": lon1, "lat": lat1},
                {"lon": lon0, "lat": lat1},
                {"lon": lon0, "lat": lat0},
            ],
        }

    def _poi(self, lon: float, lat: float, tags: dict) -> dict:
        return {"type": "node", "id": 9001, "tags": tags, "lon": lon, "lat": lat}

    def test_poi_inside_polygon_found(self) -> None:
        from osm_building_fetcher.domain.containment import find_pois_in_building

        building = self._square_way(6.10, 52.25, 6.12, 52.27)
        poi = self._poi(6.11, 52.26, {"amenity": "fast_food"})
        result = find_pois_in_building(building, [poi])
        assert result == [{"amenity": "fast_food"}]

    def test_poi_outside_polygon_not_found(self) -> None:
        from osm_building_fetcher.domain.containment import find_pois_in_building

        building = self._square_way(6.10, 52.25, 6.12, 52.27)
        poi = self._poi(6.20, 52.35, {"amenity": "fast_food"})
        result = find_pois_in_building(building, [poi])
        assert result == []

    def test_node_element_returns_empty(self) -> None:
        from osm_building_fetcher.domain.containment import find_pois_in_building

        # Node buildings (not way polygons) always return empty
        building = {
            "type": "node",
            "id": 9002,
            "tags": {"building": "yes"},
            "lon": 6.11,
            "lat": 52.26,
        }
        poi = self._poi(6.11, 52.26, {"shop": "bakery"})
        result = find_pois_in_building(building, [poi])
        assert result == []

    def test_empty_poi_list_returns_empty(self) -> None:
        from osm_building_fetcher.domain.containment import find_pois_in_building

        building = self._square_way(6.10, 52.25, 6.12, 52.27)
        assert find_pois_in_building(building, []) == []


# ---------------------------------------------------------------------------
# link_buildings_to_streets
# ---------------------------------------------------------------------------


class TestLinkBuildingsToStreets:
    def test_no_streets_returns_none(self) -> None:
        buildings = [_way(1, {"building": "house"})]
        result = link_buildings_to_streets(buildings, [])
        assert result == [(None, None)]

    def test_name_match(self) -> None:
        building = _way(1, {"building": "house", "addr:street": "Hoofdstraat"})
        street = _street(100, "Hoofdstraat")
        result = link_buildings_to_streets([building], [street])
        assert result[0][0] == "Hoofdstraat"
        assert result[0][1] == "osm_100"

    def test_name_match_case_insensitive(self) -> None:
        building = _way(1, {"building": "house", "addr:street": "hoofdstraat"})
        street = _street(100, "Hoofdstraat")
        result = link_buildings_to_streets([building], [street])
        assert result[0][1] == "osm_100"

    def test_nearest_fallback_when_no_addr_street(self) -> None:
        building = _node(1, {"building": "house"}, lon=6.120, lat=52.250)
        near_street = _street(200, "Dichtbijstraat", lon=6.121, lat=52.250)
        far_street = _street(201, "Verrestraat", lon=6.200, lat=52.300)
        result = link_buildings_to_streets([building], [near_street, far_street])
        assert result[0][1] == "osm_200"

    def test_nearest_fallback_when_addr_street_not_found(self) -> None:
        building = _way(1, {"building": "house", "addr:street": "Onbekendstraat"})
        street = _street(300, "Hoofdstraat", lon=6.105, lat=52.250)
        result = link_buildings_to_streets([building], [street])
        # Falls back to nearest
        assert result[0][1] == "osm_300"

    def test_empty_buildings_returns_empty(self) -> None:
        result = link_buildings_to_streets([], [_street(1, "A")])
        assert result == []

    def test_multiple_buildings(self) -> None:
        b1 = _node(1, {"building": "house", "addr:street": "Astraat"}, lon=6.10, lat=52.25)
        b2 = _node(2, {"building": "school", "addr:street": "Bstraat"}, lon=6.20, lat=52.30)
        s1 = _street(10, "Astraat", lon=6.10, lat=52.25)
        s2 = _street(11, "Bstraat", lon=6.20, lat=52.30)
        result = link_buildings_to_streets([b1, b2], [s1, s2])
        assert result[0][1] == "osm_10"
        assert result[1][1] == "osm_11"

    def test_street_without_name_returns_none_name(self) -> None:
        building = _node(1, {"building": "house"}, lon=6.10, lat=52.25)
        nameless = {
            "type": "way",
            "id": 500,
            "tags": {"highway": "residential"},
            "geometry": [
                {"lon": 6.10, "lat": 52.25},
                {"lon": 6.101, "lat": 52.25},
            ],
        }
        result = link_buildings_to_streets([building], [nameless])
        assert result[0][1] == "osm_500"
        assert result[0][0] is None


# ---------------------------------------------------------------------------
# build_buildings (integration — Overpass mocked)
# ---------------------------------------------------------------------------


class TestBuildBuildings:
    """Integration tests for build_buildings() with a mocked Overpass call."""

    _MOCK_ELEMENTS: ClassVar[list[dict]] = [
        {
            "type": "way",
            "id": 1001,
            "tags": {"building": "house", "addr:street": "Teststraat"},
            "geometry": [
                {"lon": 6.15, "lat": 52.25},
                {"lon": 6.16, "lat": 52.25},
                {"lon": 6.16, "lat": 52.26},
                {"lon": 6.15, "lat": 52.26},
                {"lon": 6.15, "lat": 52.25},
            ],
        },
        {
            "type": "way",
            "id": 1002,
            "tags": {"building": "school"},
            "geometry": [
                {"lon": 6.17, "lat": 52.27},
                {"lon": 6.18, "lat": 52.27},
                {"lon": 6.18, "lat": 52.28},
                {"lon": 6.17, "lat": 52.28},
                {"lon": 6.17, "lat": 52.27},
            ],
        },
        {
            "type": "node",
            "id": 2001,
            "tags": {"building": "yes", "shop": "bakery"},
            "lon": 6.155,
            "lat": 52.255,
        },
        {
            "type": "way",
            "id": 3001,
            "tags": {"highway": "residential", "name": "Teststraat"},
            "geometry": [
                {"lon": 6.14, "lat": 52.25},
                {"lon": 6.17, "lat": 52.25},
            ],
        },
    ]

    def _call(self, elements: list[dict] | None = None) -> tuple[dict, dict]:
        from osm_building_fetcher.core.osm_building_fetcher_core import (
            build_buildings,
        )

        mock_data = {"elements": self._MOCK_ELEMENTS if elements is None else elements}
        with patch(
            "osm_building_fetcher.core.osm_building_fetcher_core.fetch_overpass_tiled"
        ) as mock_fp:
            mock_fp.return_value = mock_data
            return cast(tuple[dict, dict], build_buildings([6.14, 52.24, 6.19, 52.29]))

    def test_returns_feature_collection(self) -> None:
        fc, _ = self._call()
        assert fc["type"] == "FeatureCollection"

    def test_stats_total_matches_feature_count(self) -> None:
        fc, stats = self._call()
        assert stats["total"] == len(fc["features"])

    def test_correct_building_count(self) -> None:
        _, stats = self._call()
        # 2 way-buildings + 1 node-building = 3
        assert stats["buildings"] == 3

    def test_correct_street_count(self) -> None:
        _, stats = self._call()
        assert stats["streets"] == 1

    def test_building_types_in_stats(self) -> None:
        _, stats = self._call()
        assert "house" in stats["by_type"]
        assert "school" in stats["by_type"]
        assert "shopping" in stats["by_type"]

    def test_street_name_linked_by_addr_street(self) -> None:
        fc, _ = self._call()
        house = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_1001")
        assert house["properties"]["streetName"] == "Teststraat"
        assert house["properties"]["streetId"] == "osm_3001"

    def test_building_id_format(self) -> None:
        fc, _ = self._call()
        ids = {f["properties"]["buildingId"] for f in fc["features"]}
        assert "osm_1001" in ids
        assert "osm_1002" in ids
        assert "osm_2001" in ids

    def test_osm_tags_present_in_feature(self) -> None:
        fc, _ = self._call()
        house = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_1001")
        assert house["properties"]["tag_building"] == "house"
        assert house["properties"]["tag_addr:street"] == "Teststraat"

    def test_node_building_has_point_geometry(self) -> None:
        fc, _ = self._call()
        node_feat = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_2001")
        assert node_feat["geometry"]["type"] == "Point"

    def test_way_building_has_polygon_geometry(self) -> None:
        fc, _ = self._call()
        way_feat = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_1001")
        assert way_feat["geometry"]["type"] == "Polygon"

    def test_empty_overpass_response(self) -> None:
        fc, stats = self._call(elements=[])
        assert fc["features"] == []
        assert stats["total"] == 0

    def test_by_type_counts_correct(self) -> None:
        _, stats = self._call()
        assert stats["by_type"].get("house", 0) == 1
        assert stats["by_type"].get("school", 0) == 1
        assert stats["by_type"].get("shopping", 0) == 1

    def test_parking_element_without_building_tag_included(self) -> None:
        """A surface parking lot (amenity=parking, no building tag) must appear."""
        surface_lot = {
            "type": "way",
            "id": 5001,
            "tags": {"amenity": "parking", "capacity": "40"},
            "geometry": [
                {"lon": 6.151, "lat": 52.251},
                {"lon": 6.153, "lat": 52.251},
                {"lon": 6.153, "lat": 52.253},
                {"lon": 6.151, "lat": 52.253},
                {"lon": 6.151, "lat": 52.251},
            ],
        }
        elements = [*list(self._MOCK_ELEMENTS), surface_lot]
        fc, stats = self._call(elements)
        ids = {f["properties"]["buildingId"] for f in fc["features"]}
        assert "osm_5001" in ids
        assert stats["by_type"].get("parking", 0) >= 1

    def test_parking_element_has_parking_capacity(self) -> None:
        """parkingCapacity is set from the OSM capacity tag."""
        parking_node = {
            "type": "node",
            "id": 6001,
            "tags": {"amenity": "parking", "capacity": "80"},
            "lon": 6.155,
            "lat": 52.256,
        }
        elements = [*list(self._MOCK_ELEMENTS), parking_node]
        fc, _stats = self._call(elements)
        feat = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_6001")
        assert feat["properties"]["parkingCapacity"] == 80

    def test_non_parking_building_has_zero_parking_capacity(self) -> None:
        fc, _ = self._call()
        house = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_1001")
        assert house["properties"]["parkingCapacity"] == 0

    def test_work_element_without_building_tag_included(self) -> None:
        """An office node (office=yes, no building tag) must appear in output."""
        office_node = {
            "type": "node",
            "id": 7001,
            "tags": {"office": "company"},
            "lon": 6.160,
            "lat": 52.260,
        }
        elements = [*list(self._MOCK_ELEMENTS), office_node]
        fc, stats = self._call(elements)
        ids = {f["properties"]["buildingId"] for f in fc["features"]}
        assert "osm_7001" in ids
        assert stats["by_type"].get("work", 0) >= 1

    def test_work_building_classified_correctly(self) -> None:
        """A way with building=industrial is classified as 'work'."""
        industrial = {
            "type": "way",
            "id": 7002,
            "tags": {"building": "industrial"},
            "geometry": [
                {"lon": 6.161, "lat": 52.261},
                {"lon": 6.163, "lat": 52.261},
                {"lon": 6.163, "lat": 52.263},
                {"lon": 6.161, "lat": 52.263},
                {"lon": 6.161, "lat": 52.261},
            ],
        }
        elements = [*list(self._MOCK_ELEMENTS), industrial]
        fc, stats = self._call(elements)
        feat = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_7002")
        assert feat["properties"]["buildingType"] == "work"
        assert stats["by_type"].get("work", 0) >= 1

    def test_single_use_building_has_floor_fraction_one(self) -> None:
        fc, _ = self._call()
        house = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_1001")
        assert house["properties"]["floorFraction"] == pytest.approx(1.0)

    def test_mixed_use_building_produces_two_features(self) -> None:
        """A building=house polygon with a restaurant POI node inside → 2 features."""
        # House polygon that contains the restaurant node
        house_way = {
            "type": "way",
            "id": 8001,
            "tags": {"building": "house"},
            "geometry": [
                {"lon": 6.200, "lat": 52.300},
                {"lon": 6.202, "lat": 52.300},
                {"lon": 6.202, "lat": 52.302},
                {"lon": 6.200, "lat": 52.302},
                {"lon": 6.200, "lat": 52.300},
            ],
        }
        # Restaurant node inside the polygon
        restaurant_node = {
            "type": "node",
            "id": 8002,
            "tags": {"amenity": "restaurant"},
            "lon": 6.201,
            "lat": 52.301,
        }
        elements = [house_way, restaurant_node]
        fc, stats = self._call(elements)
        ids = [f["properties"]["buildingId"] for f in fc["features"]]
        assert "osm_8001_recreational" in ids
        assert "osm_8001_house" in ids
        assert stats["by_type"].get("recreational", 0) == 1
        assert stats["by_type"].get("house", 0) == 1

    def test_mixed_use_building_floor_fractions_default_two_levels(self) -> None:
        """Without building:levels, fractions default to 0.5 / 0.5."""
        house_way = {
            "type": "way",
            "id": 8003,
            "tags": {"building": "house"},
            "geometry": [
                {"lon": 6.210, "lat": 52.310},
                {"lon": 6.212, "lat": 52.310},
                {"lon": 6.212, "lat": 52.312},
                {"lon": 6.210, "lat": 52.312},
                {"lon": 6.210, "lat": 52.310},
            ],
        }
        shop_node = {
            "type": "node",
            "id": 8004,
            "tags": {"shop": "bakery"},
            "lon": 6.211,
            "lat": 52.311,
        }
        fc, _ = self._call([house_way, shop_node])
        feats = {f["properties"]["buildingId"]: f for f in fc["features"]}
        assert feats["osm_8003_shopping"]["properties"]["floorFraction"] == pytest.approx(0.5)
        assert feats["osm_8003_house"]["properties"]["floorFraction"] == pytest.approx(0.5)

    def test_mixed_use_building_with_levels_tag(self) -> None:
        """building:levels=4 → poi fraction=0.25, house fraction=0.75."""
        house_way = {
            "type": "way",
            "id": 8005,
            "tags": {"building": "house", "building:levels": "4"},
            "geometry": [
                {"lon": 6.220, "lat": 52.320},
                {"lon": 6.222, "lat": 52.320},
                {"lon": 6.222, "lat": 52.322},
                {"lon": 6.220, "lat": 52.322},
                {"lon": 6.220, "lat": 52.320},
            ],
        }
        bar_node = {
            "type": "node",
            "id": 8006,
            "tags": {"amenity": "bar"},
            "lon": 6.221,
            "lat": 52.321,
        }
        fc, _ = self._call([house_way, bar_node])
        feats = {f["properties"]["buildingId"]: f for f in fc["features"]}
        assert feats["osm_8005_recreational"]["properties"]["floorFraction"] == pytest.approx(0.25)
        assert feats["osm_8005_house"]["properties"]["floorFraction"] == pytest.approx(0.75)

    def test_mixed_use_single_floor_only_poi_feature(self) -> None:
        """building:levels=1 → only the POI feature, no house feature."""
        house_way = {
            "type": "way",
            "id": 8007,
            "tags": {"building": "house", "building:levels": "1"},
            "geometry": [
                {"lon": 6.230, "lat": 52.330},
                {"lon": 6.232, "lat": 52.330},
                {"lon": 6.232, "lat": 52.332},
                {"lon": 6.230, "lat": 52.332},
                {"lon": 6.230, "lat": 52.330},
            ],
        }
        shop_node = {
            "type": "node",
            "id": 8008,
            "tags": {"shop": "clothing"},
            "lon": 6.231,
            "lat": 52.331,
        }
        fc, _ = self._call([house_way, shop_node])
        ids = [f["properties"]["buildingId"] for f in fc["features"]]
        assert "osm_8007_shopping" in ids
        assert "osm_8007_house" not in ids

    def test_poi_outside_building_no_split(self) -> None:
        """A POI node clearly outside the building polygon must not trigger a split."""
        house_way = {
            "type": "way",
            "id": 8009,
            "tags": {"building": "house"},
            "geometry": [
                {"lon": 6.240, "lat": 52.340},
                {"lon": 6.242, "lat": 52.340},
                {"lon": 6.242, "lat": 52.342},
                {"lon": 6.240, "lat": 52.342},
                {"lon": 6.240, "lat": 52.340},
            ],
        }
        outside_node = {
            "type": "node",
            "id": 8010,
            "tags": {"amenity": "restaurant"},
            "lon": 6.300,
            "lat": 52.400,
        }
        fc, stats = self._call([house_way, outside_node])
        ids = [f["properties"]["buildingId"] for f in fc["features"]]
        # No split: just the single house feature (osm_8009, not osm_8009_house)
        assert "osm_8009" in ids
        assert "osm_8009_house" not in ids
        assert stats["by_type"].get("house", 0) == 1


# ---------------------------------------------------------------------------
# Tiled Overpass fetching
# ---------------------------------------------------------------------------


class TestBuildBuildingsTiling:
    """build_buildings must fetch via the shared tiled Overpass client."""

    def test_default_grid_is_5x5(self) -> None:
        from osm_building_fetcher.core.osm_building_fetcher_core import (
            OVERPASS_GRID,
            build_buildings,
        )

        with patch(
            "osm_building_fetcher.core.osm_building_fetcher_core.fetch_overpass_tiled"
        ) as mock_tiled:
            mock_tiled.return_value = {"elements": []}
            _, stats = build_buildings([6.14, 52.24, 6.19, 52.29])

        assert OVERPASS_GRID == 5
        _, kwargs = mock_tiled.call_args
        assert kwargs["tiles"] == (5, 5)
        # tiles count reported in stats = grid**2
        assert stats["tiles"] == 25

    def test_tiles_param_forwarded(self) -> None:
        from osm_building_fetcher.core.osm_building_fetcher_core import (
            build_buildings,
        )

        with patch(
            "osm_building_fetcher.core.osm_building_fetcher_core.fetch_overpass_tiled"
        ) as mock_tiled:
            mock_tiled.return_value = {"elements": []}
            _, stats = build_buildings([6.14, 52.24, 6.19, 52.29], tiles=2)

        _, kwargs = mock_tiled.call_args
        assert kwargs["tiles"] == (2, 2)
        assert stats["tiles"] == 4

    def test_merged_tile_elements_processed_once(self) -> None:
        """Elements returned by the tiled client (already deduped) are processed."""
        from osm_building_fetcher.core.osm_building_fetcher_core import (
            build_buildings,
        )

        merged = {
            "elements": [
                {
                    "type": "way",
                    "id": 4242,
                    "tags": {"building": "school"},
                    "geometry": [
                        {"lon": 6.15, "lat": 52.25},
                        {"lon": 6.16, "lat": 52.25},
                        {"lon": 6.16, "lat": 52.26},
                        {"lon": 6.15, "lat": 52.26},
                        {"lon": 6.15, "lat": 52.25},
                    ],
                }
            ]
        }
        with patch(
            "osm_building_fetcher.core.osm_building_fetcher_core.fetch_overpass_tiled"
        ) as mock_tiled:
            mock_tiled.return_value = merged
            fc, stats = build_buildings([6.14, 52.24, 6.19, 52.29])

        assert stats["buildings"] == 1
        assert fc["features"][0]["properties"]["buildingId"] == "osm_4242"


# ---------------------------------------------------------------------------
# _building_levels — regression guard for the except-tuple fix
# ---------------------------------------------------------------------------


class TestBuildingLevels:
    def test_absent_defaults_to_two(self) -> None:
        from osm_building_fetcher.core.osm_building_fetcher_core import (
            _building_levels,
        )

        assert _building_levels({}) == 2

    def test_valid_value(self) -> None:
        from osm_building_fetcher.core.osm_building_fetcher_core import (
            _building_levels,
        )

        assert _building_levels({"building:levels": "5"}) == 5

    def test_invalid_value_defaults_to_two(self) -> None:
        from osm_building_fetcher.core.osm_building_fetcher_core import (
            _building_levels,
        )

        # Non-numeric string must not raise (guards the except (ValueError, TypeError) fix).
        assert _building_levels({"building:levels": "ground"}) == 2
