"""OSM highway-tag filter functions per transport mode.

Determines whether a given OSM way (by its tag dict) is eligible for inclusion
in a specific transport-mode network.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Highway value sets per mode
# ---------------------------------------------------------------------------

_CAR_HIGHWAY_TYPES: frozenset[str] = frozenset(
    {
        "motorway",
        "motorway_link",
        "trunk",
        "trunk_link",
        "primary",
        "primary_link",
        "secondary",
        "secondary_link",
        "tertiary",
        "tertiary_link",
        "unclassified",
        "residential",
        "living_street",
        "service",
    }
)

# Cycleway and similar: always included for BIKE regardless of other tags
_BIKE_STANDALONE_TYPES: frozenset[str] = frozenset(
    {
        "cycleway",
    }
)

# Path / track: included for BIKE only when bicycle=yes|designated
_BIKE_CONDITIONAL_TYPES: frozenset[str] = frozenset(
    {
        "path",
        "track",
    }
)

_PEDESTRIAN_HIGHWAY_TYPES: frozenset[str] = frozenset(
    {
        "footway",
        "path",
        "pedestrian",
        "steps",
        "track",
    }
)


def is_car_way(tags: dict[str, str]) -> bool:
    """Return True if this OSM way should be included in the CAR network."""
    return tags.get("highway", "") in _CAR_HIGHWAY_TYPES


def is_bike_way(tags: dict[str, str]) -> bool:
    """Return True if this OSM way should be included in the BIKE network.

    Includes:
    - Standalone cycleways (``highway=cycleway``)
    - Paths / tracks where ``bicycle=yes|designated``
    - CAR roads unless ``bicycle=no`` or ``access=no`` with no bicycle exception
    """
    hw = tags.get("highway", "")
    bicycle = tags.get("bicycle", "").lower()
    access = tags.get("access", "").lower()

    if hw in _BIKE_STANDALONE_TYPES:
        return True

    if hw in _BIKE_CONDITIONAL_TYPES:
        return bicycle in ("yes", "designated")

    if hw in _CAR_HIGHWAY_TYPES:
        if bicycle == "no":
            return False
        return not (access == "no" and bicycle not in ("yes", "designated", "permissive"))

    return False


def is_pedestrian_way(tags: dict[str, str]) -> bool:
    """Return True if this OSM way should be included in the PEDESTRIAN network."""
    hw = tags.get("highway", "")
    foot = tags.get("foot", "").lower()

    if hw == "path":
        return foot != "no"
    if hw == "track":
        # Only if foot explicitly allowed (or untagged — conservative inclusion)
        return foot in ("yes", "designated", "permissive", "")
    return hw in _PEDESTRIAN_HIGHWAY_TYPES


def is_way_for_mode(tags: dict[str, str], mode: str) -> bool:
    """Return True if the way is eligible for *mode*.

    Parameters
    ----------
    tags:
        OSM tag dict (``way["tags"]``).
    mode:
        One of ``"CAR"``, ``"BIKE"``, ``"PEDESTRIAN"``.

    Raises
    ------
    ValueError:
        If *mode* is not one of the supported values.
    """
    if mode == "CAR":
        return is_car_way(tags)
    if mode == "BIKE":
        return is_bike_way(tags)
    if mode == "PEDESTRIAN":
        return is_pedestrian_way(tags)
    raise ValueError(f"Unknown mode: {mode!r}. Expected one of CAR, BIKE, PEDESTRIAN.")
