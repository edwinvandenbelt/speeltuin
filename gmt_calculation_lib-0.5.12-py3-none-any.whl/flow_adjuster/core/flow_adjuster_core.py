"""
flow_adjuster_core.py — Selected-link flow injection for the GMT adjustment pipeline.

Pure functions; no I/O, no boto3.

Typical use
-----------
A caller passes one or more *flow adjustments* — each specifying a directed
link ID and a target 24-hour flow value (absolute, delta-plus, or delta-minus).
``apply_flow_adjustments`` distributes the flow delta over the OD pairs that
currently use the link (proportionally to their share of the existing link
flow) and returns updated routes, zones, and a mini OD FeatureCollection
suitable for ``_compute_link_flow_delta`` in the adjust pipeline.
"""

from __future__ import annotations

import copy

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _pair_key(props: dict) -> tuple[str, str, str, str]:
    """Return a 4-tuple that uniquely identifies an OD pair in the ROUTES file."""
    return (
        str(props.get("fromZoneId") or ""),
        str(props.get("toZoneId") or ""),
        str(props.get("fromType") or "zone"),
        str(props.get("toType") or "zone"),
    )


def _parse_value(raw: str, current: float) -> float:
    """Apply an absolute or delta value string to *current*.

    ``"+50"`` / ``"-20"`` → delta; plain numeric → absolute override.
    Mirrors :func:`adjust.core.adjust_core._parse_value`.
    """
    raw = raw.strip()
    if raw.startswith("+"):
        return current + float(raw[1:])
    if raw.startswith("-"):
        return current - float(raw[1:])
    return float(raw)


# ---------------------------------------------------------------------------
# Selected-link analysis
# ---------------------------------------------------------------------------


def selected_link_trips(
    routes_fc: dict,
    link_id: str,
    zone_production: dict[str, float],
) -> tuple[dict[tuple[str, str, str, str], float], float]:
    """Compute the absolute trips that currently pass through *link_id* per OD pair.

    Parameters
    ----------
    routes_fc:
        ROUTES GeoJSON FeatureCollection (fraction convention):
        ``route.trips × originProduction`` = absolute trips on that route.
    link_id:
        The directed link ID to analyse.
    zone_production:
        Mapping ``{zoneId: production}`` from the ZONE FeatureCollection.
        Used as a fallback when ``originProduction`` is absent on a feature.

    Returns
    -------
    (trips_via_link, total_on_link)
        *trips_via_link* maps ``(fromZoneId, toZoneId, fromType, toType)`` to
        the absolute number of trips that traverse *link_id* from that pair.
        *total_on_link* is the sum of all per-pair values (the routes-derived
        current total flow on the link).
    """
    trips_via: dict[tuple[str, str, str, str], float] = {}
    total = 0.0

    for feat in routes_fc.get("features") or []:
        p = feat.get("properties") or {}
        from_id = str(p.get("fromZoneId") or "")
        from_type = str(p.get("fromType") or "zone")

        # Origin production: prefer cached originProduction on the feature; fall
        # back to zones_fc lookup.  For node-type origins the route.trips are
        # already in absolute trip units so the scale factor is 1.
        if from_type == "zone":
            origin_prod = float(p.get("originProduction") or 0.0) or zone_production.get(
                from_id, 0.0
            )
        else:
            origin_prod = 1.0

        # Sum trips of routes that include link_id in their linkPath
        via_frac = sum(
            float(r.get("trips") or 0.0)
            for r in (p.get("routes") or [])
            if link_id in (r.get("linkPath") or [])
        )

        if via_frac <= 0.0:
            continue

        via_abs = via_frac * origin_prod
        key = _pair_key(p)
        trips_via[key] = trips_via.get(key, 0.0) + via_abs
        total += via_abs

    return trips_via, total


# ---------------------------------------------------------------------------
# Flow adjustment
# ---------------------------------------------------------------------------


def apply_flow_adjustments(
    network_fc: dict,
    routes_fc: dict,
    zones_fc: dict,
    flow_adjustments: list[dict],
) -> tuple[dict, dict, dict, list[dict]]:
    """Apply link flow adjustments via selected-link distribution.

    For each entry in *flow_adjustments* the algorithm is:

    1. Look up the current ``flow24hrs`` on the target link.
    2. Compute ``flow_delta = target_flow − current_flow``.
    3. Run a selected-link analysis to find every OD pair that currently sends
       trips through the link and its share of the total link flow.
    4. For each affected pair distribute ``flow_delta × share`` extra trips
       **only to routes that pass through the link** (routes not using the link
       are unchanged).  This guarantees that exactly ``flow_delta`` extra trips
       end up on the target link.
    5. Update ``tripFraction = sum(new route.trips)`` for affected pairs.
    6. Accumulate zone ``production`` / ``attraction`` deltas for all affected
       origin and destination zones.

    The returned *od_delta_fc* follows the normalized-fraction convention
    expected by ``_compute_link_flow_delta`` as an *extra_od_fc* argument:
    ``route.trips × originProduction`` = absolute trips after the adjustment.
    This propagates the flow change to **all** links on the affected routes,
    not only to the target link.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection.  Used to look up ``flow24hrs`` and
        to resolve ``fromNode`` / ``toNode`` entries to a ``linkId``.
    routes_fc:
        ROUTES GeoJSON FeatureCollection (fraction convention).
    zones_fc:
        ZONE GeoJSON FeatureCollection.
    flow_adjustments:
        List of adjustment entries.  Each entry must contain:

        * ``"linkId"`` **or** ``"fromNode"`` + ``"toNode"``
        * ``"flow"``: ``"+500"``, ``"-200"``, or an absolute numeric string.

    Returns
    -------
    (updated_routes_fc, updated_zones_fc, od_delta_fc, stats)
        *updated_routes_fc* — full ROUTES FC with scaled fractions for all
        affected pairs; all other pairs are unchanged.
        *updated_zones_fc* — ZONE FC with adjusted ``production`` /
        ``attraction`` for affected zones; unchanged zones are passed through.
        *od_delta_fc* — mini FeatureCollection containing only the modified
        pair features (for ``_compute_link_flow_delta``).
        *stats* — list of per-adjustment dicts with keys ``linkId``,
        ``flow_before``, ``flow_after``, ``flow_delta``, ``affected_pairs``,
        and optionally ``warning``.
    """
    # ------------------------------------------------------------------
    # Build link lookup indices
    # ------------------------------------------------------------------
    link_by_id: dict[str, dict] = {}
    link_id_by_edge: dict[tuple[str, str], str] = {}
    for feat in network_fc.get("features") or []:
        p = feat.get("properties") or {}
        lid = str(p.get("linkId") or "").strip()
        fn = str(p.get("fromNode") or "").strip()
        tn = str(p.get("toNode") or "").strip()
        if lid:
            link_by_id[lid] = feat
        if fn and tn and lid:
            link_id_by_edge[(fn, tn)] = lid

    # ------------------------------------------------------------------
    # Zone production / attraction (read-only; deltas accumulated separately)
    # ------------------------------------------------------------------
    zone_production: dict[str, float] = {}
    zone_attraction: dict[str, float] = {}
    for feat in zones_fc.get("features") or []:
        p = feat.get("properties") or {}
        zid = str(p.get("zoneId") or "")
        zone_production[zid] = float(p.get("production") or 0.0)
        zone_attraction[zid] = float(p.get("attraction") or 0.0)

    # ------------------------------------------------------------------
    # Mutable working copies of affected routes (keyed by pair_key)
    # Multiple adjustments on the same pair compose correctly.
    # ------------------------------------------------------------------
    routes_index: dict[tuple[str, str, str, str], int] = {}
    working_routes: list[dict] = [copy.deepcopy(f) for f in (routes_fc.get("features") or [])]
    for i, feat in enumerate(working_routes):
        routes_index[_pair_key(feat.get("properties") or {})] = i

    # Accumulated zone deltas across all adjustments in the batch
    production_delta: dict[str, float] = {}
    attraction_delta: dict[str, float] = {}

    # Track which pair keys were modified (for od_delta_fc output)
    modified_keys: set[tuple[str, str, str, str]] = set()

    stats: list[dict] = []

    # ------------------------------------------------------------------
    # Process each flow adjustment entry
    # ------------------------------------------------------------------
    for entry in flow_adjustments:
        link_id = str(entry.get("linkId") or "").strip()
        from_n = str(entry.get("fromNode") or "").strip()
        to_n = str(entry.get("toNode") or "").strip()
        flow_str = str(entry.get("flow") or "").strip()

        # Resolve linkId from fromNode/toNode when not given directly
        if not link_id and from_n and to_n:
            link_id = link_id_by_edge.get((from_n, to_n), "")
        if not link_id:
            raise ValueError(
                f"Flow adjustment: cannot resolve a linkId from entry {entry!r}. "
                "Provide 'linkId' or both 'fromNode' and 'toNode'."
            )

        link_feat = link_by_id.get(link_id)
        if link_feat is None:
            raise ValueError(f"Flow adjustment: linkId {link_id!r} not found in the network.")

        link_props = link_feat.get("properties") or {}
        # Use flow24hrs as the authoritative 24-hour source; fall back to flow.
        current_flow = float(link_props.get("flow24hrs") or link_props.get("flow") or 0.0)
        target_flow = max(_parse_value(flow_str, current_flow), 0.0)
        flow_delta = target_flow - current_flow

        if flow_delta == 0.0:
            stats.append(
                {
                    "linkId": link_id,
                    "flow_before": current_flow,
                    "flow_after": target_flow,
                    "flow_delta": 0.0,
                    "affected_pairs": 0,
                }
            )
            continue

        # Build effective production map (include deltas already applied in
        # this batch so that a second adjustment on the same origin is correct).
        effective_prod = {
            zid: zone_production[zid] + production_delta.get(zid, 0.0) for zid in zone_production
        }

        trips_via, total_on_link = selected_link_trips(routes_fc, link_id, effective_prod)

        if total_on_link <= 0.0:
            stats.append(
                {
                    "linkId": link_id,
                    "flow_before": current_flow,
                    "flow_after": target_flow,
                    "flow_delta": flow_delta,
                    "affected_pairs": 0,
                    "warning": (
                        "No routes currently pass through this link; "
                        "the flow delta cannot be distributed over OD pairs."
                    ),
                }
            )
            continue

        n_affected = 0

        for key, via_abs in trips_via.items():
            idx = routes_index.get(key)
            if idx is None:
                continue

            feat = working_routes[idx]
            p = feat.get("properties") or {}
            from_id = str(p.get("fromZoneId") or "")
            to_id = str(p.get("toZoneId") or "")
            from_type = str(p.get("fromType") or "zone")
            to_type = str(p.get("toType") or "zone")
            origin_prod = float(p.get("originProduction") or 0.0)

            # Share of total link flow that this pair contributes
            share = via_abs / total_on_link

            # Absolute trip change for this OD pair
            delta_t = flow_delta * share

            if origin_prod <= 0.0:
                # Cannot scale fractions without a production denominator; skip.
                continue

            # via_frac: the fraction of originProduction that passes through link_id
            # (= sum of route.trips for routes that include link_id)
            via_frac = via_abs / origin_prod

            # delta_t in fraction units (for scaling route.trips)
            delta_t_frac = delta_t / origin_prod

            # ----------------------------------------------------------
            # Scale only the routes that pass through the target link.
            # Routes that do NOT use the link are left unchanged.
            # This ensures exactly delta_t extra trips land on the link.
            # ----------------------------------------------------------
            new_routes: list[dict] = []
            for r in p.get("routes") or []:
                r_trips = float(r.get("trips") or 0.0)
                if link_id in (r.get("linkPath") or []):
                    # Distribute delta proportional to this route's current
                    # share of the via-routes flow.
                    delta_r = delta_t_frac * (r_trips / via_frac) if via_frac > 0.0 else 0.0
                    new_r_trips = max(r_trips + delta_r, 0.0)
                else:
                    new_r_trips = r_trips

                new_routes.append({**r, "trips": round(new_r_trips, 6)})

            # Recompute tripFraction as the sum of all route.trips
            new_trip_frac = sum(float(r.get("trips") or 0.0) for r in new_routes)

            working_routes[idx] = {
                **feat,
                "properties": {
                    **p,
                    "tripFraction": round(new_trip_frac, 6),
                    "routes": new_routes,
                },
            }
            modified_keys.add(key)

            # Accumulate zone demand deltas
            if from_type == "zone" and from_id:
                production_delta[from_id] = production_delta.get(from_id, 0.0) + delta_t
            if to_type == "zone" and to_id:
                attraction_delta[to_id] = attraction_delta.get(to_id, 0.0) + delta_t

            n_affected += 1

        stats.append(
            {
                "linkId": link_id,
                "flow_before": current_flow,
                "flow_after": target_flow,
                "flow_delta": flow_delta,
                "affected_pairs": n_affected,
            }
        )

    # ------------------------------------------------------------------
    # Build output: updated ROUTES FC
    # ------------------------------------------------------------------
    updated_routes_fc: dict = {**routes_fc, "features": working_routes}

    # ------------------------------------------------------------------
    # Build output: od_delta_fc (only modified pairs)
    # Used by _compute_link_flow_delta as an extra_od_fc to apply the
    # correct before/after flow delta to the network links.
    # ------------------------------------------------------------------
    od_delta_features = [
        working_routes[routes_index[k]] for k in modified_keys if k in routes_index
    ]
    od_delta_fc: dict = {
        "type": "FeatureCollection",
        "features": od_delta_features,
        "properties": dict(routes_fc.get("properties") or {}),
    }

    # ------------------------------------------------------------------
    # Build output: updated ZONE FC
    # ------------------------------------------------------------------
    if production_delta or attraction_delta:
        updated_zone_features: list[dict] = []
        for feat in zones_fc.get("features") or []:
            p = feat.get("properties") or {}
            zid = str(p.get("zoneId") or "")
            dp = production_delta.get(zid, 0.0)
            da = attraction_delta.get(zid, 0.0)
            if dp == 0.0 and da == 0.0:
                updated_zone_features.append(feat)
                continue
            new_p = dict(p)
            if dp != 0.0:
                new_p["production"] = max(float(p.get("production") or 0.0) + dp, 0.0)
            if da != 0.0:
                new_p["attraction"] = max(float(p.get("attraction") or 0.0) + da, 0.0)
            updated_zone_features.append({**feat, "properties": new_p})
        updated_zones_fc: dict = {**zones_fc, "features": updated_zone_features}
    else:
        updated_zones_fc = zones_fc

    return updated_routes_fc, updated_zones_fc, od_delta_fc, stats
