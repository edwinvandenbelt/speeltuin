"""Local debug runner for compare_networks.

Calls compare_networks_core.compare_networks() directly — no Lambda handler involved.

Usage
-----
    python -m compare_networks.compare_networks_runner \\
        --network1  s3://gmp-networks/network/area-NETWORK-CAR.parquet \\
        --network2  s3://gmp-networks/network/area-NETWORK-CAR-v2.parquet \\
        --fields    speed flow24hrs \\
        [--output   s3://gmp-networks/compare/area-diff.parquet] \\
        [--as-bandwidths] \\
        [--bandwidth-scale 0.5 0.1]

    # Local files (print to stdout when --output is omitted):
    python -m compare_networks.compare_networks_runner \\
        --network1  /tmp/area-NETWORK-CAR.parquet \\
        --network2  /tmp/area-NETWORK-CAR-v2.parquet \\
        --fields    speed flow24hrs

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path
from typing import cast

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return cast(bytes, get_bytes_s3(bucket, key))
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for compare_networks (calls core directly)."
    )
    parser.add_argument("--network1", required=True, help="URI for network 1.")
    parser.add_argument("--network2", required=True, help="URI for network 2.")
    parser.add_argument("--fields", nargs="+", required=True, help="Property names to compare.")
    parser.add_argument(
        "--output",
        default="",
        help="Output URI (omit to print result GeoJSON to stdout).",
    )
    parser.add_argument(
        "--as-bandwidths",
        action="store_true",
        help="Render differences as polygon band geometries.",
    )
    parser.add_argument(
        "--bandwidth-scale",
        type=float,
        nargs="+",
        default=[1.0],
        help="Scale factor(s) for bandwidth polygons, one per field (default: 1.0).",
    )
    parser.add_argument(
        "--exclude-unchanged",
        action="store_true",
        help="Omit features where all compared fields are unchanged (deltaPlus = deltaMin = 0).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from compare_networks.core.compare_networks_core import compare_networks

    print(f"Reading network1 : {args.network1}")
    fc1 = from_geoparquet(_read_uri(args.network1))

    print(f"Reading network2 : {args.network2}")
    fc2 = from_geoparquet(_read_uri(args.network2))

    print(f"Comparing fields : {args.fields}")
    result_fc = compare_networks(
        fc1,
        fc2,
        fields=args.fields,
        as_bandwidths=args.as_bandwidths,
        bandwidth_scale=args.bandwidth_scale
        if len(args.bandwidth_scale) > 1
        else args.bandwidth_scale[0],
        exclude_unchanged=args.exclude_unchanged,
    )

    n_features = len(result_fc.get("features", []))
    print(f"Result features  : {n_features}")

    if args.output:
        print(f"Writing          : {args.output}")
        _write_uri(args.output, to_geoparquet(result_fc))
    else:
        sys.stdout.write(json.dumps(result_fc, ensure_ascii=False, indent=2))
        sys.stdout.write("\n")


if __name__ == "__main__":
    main()
