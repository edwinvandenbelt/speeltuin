"""Tests for compare_networks core logic."""

from __future__ import annotations

import pytest

from compare_networks.core.compare_networks_core import compare_networks
from compare_networks.domain.comparison import _match_props

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _feat(link_id: str, **props) -> dict:
    return {
        "type": "Feature",
        "id": link_id,
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
        "properties": {"linkId": link_id, **props},
    }


def _fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features)}


# ---------------------------------------------------------------------------
# _match_props — delta clamping and field names
# ---------------------------------------------------------------------------


class TestMatchProps:
    def test_growth(self):
        f1 = _feat("1", flow=5.0)
        f2 = _feat("1", flow=10.0)
        props = _match_props(f1, f2, ["flow"])
        assert props["flow_min"] == 5.0
        assert props["flow_delta_plus"] == 5.0
        assert props["flow_delta_min"] == 0.0

    def test_reduction(self):
        f1 = _feat("1", flow=10.0)
        f2 = _feat("1", flow=4.0)
        props = _match_props(f1, f2, ["flow"])
        assert props["flow_min"] == 4.0
        assert props["flow_delta_plus"] == 0.0
        assert props["flow_delta_min"] == 6.0

    def test_no_change(self):
        f1 = _feat("1", flow=7.0)
        f2 = _feat("1", flow=7.0)
        props = _match_props(f1, f2, ["flow"])
        assert "flow_min" not in props
        assert "flow_delta_plus" not in props
        assert "flow_delta_min" not in props
        assert "flow" not in props

    def test_delta_plus_never_negative(self):
        f1 = _feat("1", flow=100.0)
        f2 = _feat("1", flow=1.0)
        props = _match_props(f1, f2, ["flow"])
        assert props["flow_delta_plus"] == 0.0
        assert props["flow_delta_min"] == 99.0

    def test_delta_min_never_negative(self):
        f1 = _feat("1", flow=1.0)
        f2 = _feat("1", flow=100.0)
        props = _match_props(f1, f2, ["flow"])
        assert props["flow_delta_min"] == 0.0
        assert props["flow_delta_plus"] == 99.0

    def test_recalculated_field_growth(self):
        # flow = flow_min + flow_delta_plus = 5 + 5 = 10
        f1 = _feat("1", flow=5.0)
        f2 = _feat("1", flow=10.0)
        props = _match_props(f1, f2, ["flow"])
        assert props["flow"] == pytest.approx(10.0)

    def test_recalculated_field_reduction(self):
        # flow = flow_min + flow_delta_plus = 4 + 0 = 4
        f1 = _feat("1", flow=10.0)
        f2 = _feat("1", flow=4.0)
        props = _match_props(f1, f2, ["flow"])
        assert props["flow"] == pytest.approx(4.0)

    def test_recalculated_field_no_change(self):
        # When v1 == v2 all derived props are absent.
        f1 = _feat("1", flow=7.0)
        f2 = _feat("1", flow=7.0)
        props = _match_props(f1, f2, ["flow"])
        assert "flow" not in props

    def test_integer_inputs(self):
        f1 = _feat("1", flow=3)
        f2 = _feat("1", flow=8)
        props = _match_props(f1, f2, ["flow"])
        assert props["flow_delta_plus"] == 5.0
        assert props["flow_delta_min"] == 0.0

    def test_non_numeric_field(self):
        f1 = _feat("1", flow="fast")
        f2 = _feat("1", flow="slow")
        props = _match_props(f1, f2, ["flow"])
        assert props["flow_min"] is None
        assert props["flow_delta_plus"] is None
        assert props["flow_delta_min"] is None

    def test_missing_field(self):
        f1 = _feat("1")
        f2 = _feat("1")
        props = _match_props(f1, f2, ["flow"])
        assert props["flow_min"] is None
        assert props["flow_delta_plus"] is None
        assert props["flow_delta_min"] is None

    def test_match_type_set(self):
        f1 = _feat("1", flow=1.0)
        f2 = _feat("1", flow=2.0)
        props = _match_props(f1, f2, ["flow"])
        assert props["matchType"] == "match"

    def test_min_is_minimum_of_both(self):
        f1 = _feat("1", flow=3.0)
        f2 = _feat("1", flow=9.0)
        props = _match_props(f1, f2, ["flow"])
        assert props["flow_min"] == 3.0

    def test_multiple_fields(self):
        f1 = _feat("1", flow=10.0, speed=50.0)
        f2 = _feat("1", flow=15.0, speed=40.0)
        props = _match_props(f1, f2, ["flow", "speed"])
        assert props["flow_delta_plus"] == 5.0
        assert props["flow_delta_min"] == 0.0
        assert props["speed_delta_plus"] == 0.0
        assert props["speed_delta_min"] == 10.0

    def test_no_camel_case_keys(self):
        f1 = _feat("1", flow=5.0)
        f2 = _feat("1", flow=10.0)
        props = _match_props(f1, f2, ["flow"])
        assert "flow_deltaPlus" not in props
        assert "flow_deltaMin" not in props
        assert "flow_delta_plus" in props
        assert "flow_delta_min" in props


# ---------------------------------------------------------------------------
# compare_networks — exclude_unchanged
# ---------------------------------------------------------------------------


class TestExcludeUnchanged:
    def test_unchanged_feature_filtered(self):
        fc1 = _fc(_feat("1", flow=5.0))
        fc2 = _fc(_feat("1", flow=5.0))
        result = compare_networks(fc1, fc2, fields=["flow"], exclude_unchanged=True)
        assert result["features"] == []

    def test_unchanged_feature_kept_by_default(self):
        fc1 = _fc(_feat("1", flow=5.0))
        fc2 = _fc(_feat("1", flow=5.0))
        result = compare_networks(fc1, fc2, fields=["flow"], exclude_unchanged=False)
        assert len(result["features"]) == 1

    def test_changed_feature_kept(self):
        fc1 = _fc(_feat("1", flow=5.0))
        fc2 = _fc(_feat("1", flow=10.0))
        result = compare_networks(fc1, fc2, fields=["flow"], exclude_unchanged=True)
        assert len(result["features"]) == 1

    def test_mixed_changed_and_unchanged(self):
        fc1 = _fc(_feat("1", flow=5.0), _feat("2", flow=5.0))
        fc2 = _fc(_feat("1", flow=5.0), _feat("2", flow=8.0))
        result = compare_networks(fc1, fc2, fields=["flow"], exclude_unchanged=True)
        assert len(result["features"]) == 1
        assert result["features"][0]["id"] == "2"

    def test_added_always_kept(self):
        fc1 = _fc()
        fc2 = _fc(_feat("1", flow=5.0))
        result = compare_networks(fc1, fc2, fields=["flow"], exclude_unchanged=True)
        assert len(result["features"]) == 1
        assert result["features"][0]["properties"]["matchType"] == "added"

    def test_removed_always_kept(self):
        fc1 = _fc(_feat("1", flow=5.0))
        fc2 = _fc()
        result = compare_networks(fc1, fc2, fields=["flow"], exclude_unchanged=True)
        assert len(result["features"]) == 1
        assert result["features"][0]["properties"]["matchType"] == "removed"

    def test_multi_field_partial_change_kept(self):
        fc1 = _fc(_feat("1", flow=5.0, speed=50.0))
        fc2 = _fc(_feat("1", flow=5.0, speed=60.0))
        result = compare_networks(fc1, fc2, fields=["flow", "speed"], exclude_unchanged=True)
        assert len(result["features"]) == 1

    def test_multi_field_all_unchanged_filtered(self):
        fc1 = _fc(_feat("1", flow=5.0, speed=50.0))
        fc2 = _fc(_feat("1", flow=5.0, speed=50.0))
        result = compare_networks(fc1, fc2, fields=["flow", "speed"], exclude_unchanged=True)
        assert result["features"] == []


# ---------------------------------------------------------------------------
# compare_networks — general
# ---------------------------------------------------------------------------


class TestCompareNetworks:
    def test_returns_feature_collection(self):
        result = compare_networks(_fc(), _fc(), fields=["flow"])
        assert result["type"] == "FeatureCollection"
        assert isinstance(result["features"], list)

    def test_invalid_fc1_raises(self):
        with pytest.raises(ValueError, match="network1"):
            compare_networks({"type": "Feature"}, _fc(), fields=["flow"])

    def test_invalid_fc2_raises(self):
        with pytest.raises(ValueError, match="network2"):
            compare_networks(_fc(), {"type": "Feature"}, fields=["flow"])

    def test_empty_fields_raises(self):
        with pytest.raises(ValueError, match="fields"):
            compare_networks(_fc(), _fc(), fields=[])

    def test_matched_feature_has_correct_deltas(self):
        fc1 = _fc(_feat("1", flow=5.0))
        fc2 = _fc(_feat("1", flow=12.0))
        result = compare_networks(fc1, fc2, fields=["flow"])
        p = result["features"][0]["properties"]
        assert p["flow_min"] == 5.0
        assert p["flow_delta_plus"] == 7.0
        assert p["flow_delta_min"] == 0.0
        assert p["matchType"] == "match"

    def test_unmatched_in_fc1_is_removed(self):
        fc1 = _fc(_feat("1", flow=5.0))
        fc2 = _fc()
        result = compare_networks(fc1, fc2, fields=["flow"])
        assert result["features"][0]["properties"]["matchType"] == "removed"

    def test_unmatched_in_fc2_is_added(self):
        fc1 = _fc()
        fc2 = _fc(_feat("1", flow=5.0))
        result = compare_networks(fc1, fc2, fields=["flow"])
        assert result["features"][0]["properties"]["matchType"] == "added"


# ---------------------------------------------------------------------------
# compare_networks — as_bandwidths geometry
# ---------------------------------------------------------------------------


class TestBandWidths:
    """Verify that as_bandwidths=True produces Polygon features with correct offsets."""

    def _bw_features(self, f1_flow, f2_flow, scale=1.0):
        fc1 = _fc(_feat("1", flow=float(f1_flow)))
        fc2 = _fc(_feat("1", flow=float(f2_flow)))
        result = compare_networks(
            fc1, fc2, fields=["flow"], as_bandwidths=True, bandwidth_scale=scale
        )
        return result["features"]

    def test_growth_produces_match_and_added_polygons(self):
        feats = self._bw_features(5.0, 10.0)
        types = {f["properties"]["matchType"] for f in feats}
        assert "matched" in types
        assert "increase" in types
        assert "reduction" not in types

    def test_reduction_produces_match_and_removed_polygons(self):
        feats = self._bw_features(10.0, 4.0)
        types = {f["properties"]["matchType"] for f in feats}
        assert "matched" in types
        assert "reduction" in types
        assert "increase" not in types

    def test_output_geometry_is_polygon(self):
        for feat in self._bw_features(5.0, 10.0):
            assert feat["geometry"]["type"] == "Polygon"

    def test_added_band_starts_at_flow_min_offset(self):
        """The inner edge of the 'increase' polygon must equal the outer edge of 'matched'."""
        feats = self._bw_features(5.0, 10.0, scale=1.0)
        match_feat = next(f for f in feats if f["properties"]["matchType"] == "matched")
        added_feat = next(f for f in feats if f["properties"]["matchType"] == "increase")
        # _offset_polygon builds: inner[0..n-1] + reversed(outer)[0..n-1] + close
        # outer of match (at d_outer=w_match) is ring[n:2n] reversed.
        # inner of added (at d_inner=w_match) is ring[0:n].
        match_ring = match_feat["geometry"]["coordinates"][0]
        added_ring = added_feat["geometry"]["coordinates"][0]
        n = (len(match_ring) - 1) // 2
        match_outer = list(reversed(match_ring[n : 2 * n]))
        added_inner = added_ring[:n]
        for mv, av in zip(match_outer, added_inner, strict=False):
            assert mv == pytest.approx(av, abs=1e-9)

    def test_removed_band_starts_at_flow_min_offset(self):
        """Same disposition check for the 'reduction' band."""
        feats = self._bw_features(10.0, 4.0, scale=1.0)
        match_feat = next(f for f in feats if f["properties"]["matchType"] == "matched")
        removed_feat = next(f for f in feats if f["properties"]["matchType"] == "reduction")
        match_ring = match_feat["geometry"]["coordinates"][0]
        removed_ring = removed_feat["geometry"]["coordinates"][0]
        n = (len(match_ring) - 1) // 2
        match_outer = list(reversed(match_ring[n : 2 * n]))
        removed_inner = removed_ring[:n]
        for mv, rv in zip(match_outer, removed_inner, strict=False):
            assert mv == pytest.approx(rv, abs=1e-9)

    def test_band_width_property_reflects_scale(self):
        feats = self._bw_features(5.0, 10.0, scale=2.0)
        match_feat = next(f for f in feats if f["properties"]["matchType"] == "matched")
        assert match_feat["properties"]["bandWidth"] == pytest.approx(10.0)  # 5.0 * 2

    def test_no_change_emits_only_match_band(self):
        feats = self._bw_features(7.0, 7.0)
        types = [f["properties"]["matchType"] for f in feats]
        assert types == ["matched"]

    def test_added_link_emits_single_polygon(self):
        fc1 = _fc()
        fc2 = _fc(_feat("1", flow=8.0))
        result = compare_networks(
            fc1, fc2, fields=["flow"], as_bandwidths=True, bandwidth_scale=1.0
        )
        feats = result["features"]
        assert len(feats) == 1
        assert feats[0]["properties"]["matchType"] == "increase"
        assert feats[0]["geometry"]["type"] == "Polygon"

    def test_removed_link_emits_single_polygon(self):
        fc1 = _fc(_feat("1", flow=8.0))
        fc2 = _fc()
        result = compare_networks(
            fc1, fc2, fields=["flow"], as_bandwidths=True, bandwidth_scale=1.0
        )
        feats = result["features"]
        assert len(feats) == 1
        assert feats[0]["properties"]["matchType"] == "reduction"
        assert feats[0]["geometry"]["type"] == "Polygon"

    def test_band_properties_contain_flow_values(self):
        """Every band polygon must carry the field value and prefixed delta props."""
        feats = self._bw_features(5.0, 10.0)
        for feat in feats:
            p = feat["properties"]
            assert "flow" in p
            assert "flowDeltaPlus" in p
            assert "flowDeltaMin" in p

    def test_matched_band_flow_equals_flow_min(self):
        feats = self._bw_features(5.0, 10.0)
        matched = next(f for f in feats if f["properties"]["matchType"] == "matched")
        assert matched["properties"]["flow"] == pytest.approx(5.0)

    def test_reduction_band_flow_equals_delta_min(self):
        feats = self._bw_features(10.0, 4.0)
        reduction = next(f for f in feats if f["properties"]["matchType"] == "reduction")
        assert reduction["properties"]["flow"] == pytest.approx(6.0)
        assert reduction["properties"]["flowDeltaMin"] == pytest.approx(6.0)
        assert reduction["properties"]["flowDeltaPlus"] == pytest.approx(0.0)

    def test_increase_band_flow_equals_delta_plus(self):
        feats = self._bw_features(5.0, 10.0)
        increase = next(f for f in feats if f["properties"]["matchType"] == "increase")
        assert increase["properties"]["flow"] == pytest.approx(5.0)
        assert increase["properties"]["flowDeltaPlus"] == pytest.approx(5.0)
        assert increase["properties"]["flowDeltaMin"] == pytest.approx(0.0)

    def test_no_field_property_in_bands(self):
        """The generic 'field' label must not appear — the field name is used directly."""
        feats = self._bw_features(5.0, 10.0)
        for feat in feats:
            assert "field" not in feat["properties"]

    def test_multi_field_emits_bands_per_field(self):
        """With two compared fields, reduction/increase features are emitted per field."""
        fc1 = _fc(_feat("1", flow=10.0, speed=50.0))
        fc2 = _fc(_feat("1", flow=15.0, speed=40.0))
        result = compare_networks(
            fc1,
            fc2,
            fields=["flow", "speed"],
            as_bandwidths=True,
            bandwidth_scale=1.0,
        )
        feats = result["features"]
        flow_increase = [
            f
            for f in feats
            if f["properties"]["matchType"] == "increase" and "flow" in f["properties"]
        ]
        speed_reduction = [
            f
            for f in feats
            if f["properties"]["matchType"] == "reduction" and "speed" in f["properties"]
        ]
        assert len(flow_increase) == 1
        assert len(speed_reduction) == 1
        assert flow_increase[0]["properties"]["flow"] == pytest.approx(5.0)
        assert speed_reduction[0]["properties"]["speed"] == pytest.approx(10.0)

    def test_per_field_bandwidth_scale_list(self):
        """A per-field scale list produces different bandWidths for each field."""
        fc1 = _fc(_feat("1", flow=10.0, speed=10.0))
        fc2 = _fc(_feat("1", flow=10.0, speed=10.0))  # no change → only matched bands
        result = compare_networks(
            fc1,
            fc2,
            fields=["flow", "speed"],
            as_bandwidths=True,
            bandwidth_scale=[2.0, 5.0],
        )
        feats = result["features"]
        flow_band = next(
            f for f in feats if "flow" in f["properties"] and "speed" not in f["properties"]
        )
        speed_band = next(
            f for f in feats if "speed" in f["properties"] and "flow" not in f["properties"]
        )
        assert flow_band["properties"]["bandWidth"] == pytest.approx(20.0)  # 10 * 2
        assert speed_band["properties"]["bandWidth"] == pytest.approx(50.0)  # 10 * 5

    def test_bandwidth_scale_length_mismatch_raises(self):
        fc1 = _fc(_feat("1", flow=5.0))
        fc2 = _fc(_feat("1", flow=10.0))
        with pytest.raises(ValueError, match="bandwidth_scale"):
            compare_networks(
                fc1, fc2, fields=["flow"], as_bandwidths=True, bandwidth_scale=[1.0, 2.0]
            )

    def test_exclude_unchanged_keeps_match_band_for_changed_link(self):
        """When a link changes, exclude_unchanged must NOT drop the matched (flow_min) band."""
        fc1 = _fc(_feat("1", flow=5.0))
        fc2 = _fc(_feat("1", flow=10.0))
        result = compare_networks(
            fc1,
            fc2,
            fields=["flow"],
            as_bandwidths=True,
            bandwidth_scale=1.0,
            exclude_unchanged=True,
        )
        types = {f["properties"]["matchType"] for f in result["features"]}
        assert "matched" in types
        assert "increase" in types

    def test_exclude_unchanged_drops_truly_unchanged_link(self):
        """A link with no change at all must be absent when exclude_unchanged=True."""
        fc1 = _fc(_feat("1", flow=7.0))
        fc2 = _fc(_feat("1", flow=7.0))
        result = compare_networks(
            fc1,
            fc2,
            fields=["flow"],
            as_bandwidths=True,
            bandwidth_scale=1.0,
            exclude_unchanged=True,
        )
        assert result["features"] == []


# ---------------------------------------------------------------------------
# compare_networks — passthrough properties
# ---------------------------------------------------------------------------


class TestPassthroughProps:
    """Non-compared properties are copied to every band; nulled when they differ."""

    def _match(self, f1_props: dict, f2_props: dict, fields=("flow",)):
        fc1 = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "id": "1",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
                    "properties": {"linkId": "1", **f1_props},
                },
            ],
        }
        fc2 = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "id": "1",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
                    "properties": {"linkId": "1", **f2_props},
                },
            ],
        }
        return compare_networks(
            fc1, fc2, fields=list(fields), as_bandwidths=True, bandwidth_scale=1.0
        )

    def test_equal_prop_copied_to_all_bands(self):
        result = self._match({"flow": 5.0, "name": "A"}, {"flow": 10.0, "name": "A"})
        for feat in result["features"]:
            assert feat["properties"]["name"] == "A"

    def test_differing_prop_is_none_in_all_bands(self):
        result = self._match({"flow": 5.0, "name": "A"}, {"flow": 10.0, "name": "B"})
        for feat in result["features"]:
            # All bands carry the value from network 1 for passthrough props.
            assert feat["properties"]["name"] == "A"

    def test_prop_only_on_one_side_is_none(self):
        result = self._match({"flow": 5.0, "category": "X"}, {"flow": 10.0})
        for feat in result["features"]:
            # Property only in network 1 → its value is present on all bands.
            assert feat["properties"]["category"] == "X"

    def test_passthrough_in_linestring_mode(self):
        """In non-bandwidth mode, equal props are present and differing props are None."""
        fc1 = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "id": "1",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
                    "properties": {"linkId": "1", "flow": 5.0, "name": "A", "cat": "X"},
                },
            ],
        }
        fc2 = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "id": "1",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
                    "properties": {"linkId": "1", "flow": 10.0, "name": "A", "cat": "Y"},
                },
            ],
        }
        result = compare_networks(fc1, fc2, fields=["flow"])
        p = result["features"][0]["properties"]
        assert p["name"] == "A"
        assert p["cat"] == "X"  # differing prop → value from network 1

    def test_added_link_passthrough_all_props(self):
        """For a fully-added link all original properties pass through unchanged."""
        fc1 = {"type": "FeatureCollection", "features": []}
        fc2 = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "id": "1",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
                    "properties": {"linkId": "1", "flow": 8.0, "name": "new"},
                },
            ],
        }
        result = compare_networks(
            fc1, fc2, fields=["flow"], as_bandwidths=True, bandwidth_scale=1.0
        )
        assert result["features"][0]["properties"]["name"] == "new"


# ---------------------------------------------------------------------------
# compare_networks — root-level properties merge
# ---------------------------------------------------------------------------


class TestFCPropertiesMerge:
    def test_shared_props_hoisted(self):
        fc1 = _fc(_feat("1", flow=1.0))
        fc2 = _fc(_feat("1", flow=2.0))
        fc1["properties"] = {"region": "west", "version": "1"}
        fc2["properties"] = {"region": "west", "version": "2"}
        result = compare_networks(fc1, fc2, fields=["flow"])
        p = result["properties"]
        assert p["region"] == "west"  # equal → hoisted
        assert "version" not in p  # differs → not hoisted

    def test_both_originals_present(self):
        fc1 = _fc(_feat("1", flow=1.0))
        fc2 = _fc(_feat("1", flow=2.0))
        fc1["properties"] = {"a": 1}
        fc2["properties"] = {"a": 1, "b": 2}
        result = compare_networks(fc1, fc2, fields=["flow"])
        p = result["properties"]
        assert p["network1"] == {"a": 1}
        assert p["network2"] == {"a": 1, "b": 2}

    def test_no_input_properties_gives_empty_sub_objects(self):
        result = compare_networks(_fc(), _fc(), fields=["flow"])
        p = result["properties"]
        assert p["network1"] == {}
        assert p["network2"] == {}
