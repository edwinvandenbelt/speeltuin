"""Request models for the compare_networks Lambda."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field
from pydantic.alias_generators import to_camel


class HandlerInput(BaseModel):
    """Validated input for the compare_networks handler.

    External JSON uses camelCase (e.g. ``asBandwidths``); Python code uses
    snake_case (e.g. ``as_bandwidths``).  Pydantic populates fields from the
    camelCase keys in the incoming JSON body via ``alias_generator=to_camel``.
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        extra="ignore",
    )

    network1: str = Field(
        ..., description="S3 URI (s3://bucket/key) or local path for the baseline network GeoJSON."
    )
    network2: str = Field(
        ...,
        description="S3 URI (s3://bucket/key) or local path for the comparison network GeoJSON.",
    )
    fields: list[str] = Field(..., min_length=1, description="Property names to compare.")
    as_bandwidths: bool = Field(False, description="Emit polygon bands instead of lines.")
    bandwidth_scale: float | list[float] = Field(
        1.0,
        description=(
            "Metres of band width per field unit, one value per entry in 'fields'. "
            "A single float is applied to all fields. Only used when as_bandwidths is true."
        ),
    )
    exclude_unchanged: bool = Field(
        False, description="Omit features with no change in any compared field."
    )
    output_file: str | None = Field(
        None,
        description=(
            "S3 URI (s3://bucket/key) or local path for the output GeoJSON. "
            "When omitted the result is returned inline."
        ),
    )
