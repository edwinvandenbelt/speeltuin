# Databricks notebook source
# compare_networks_nb — Databricks notebook wrapper for compare_networks_core
#
# Compares two GeoJSON network FeatureCollections and writes a diff
# FeatureCollection to a file reference (s3://bucket/key or local path).
#
# Prerequisites
# -------------
# Run the widget-registration cell once per session to set all widget values.
# The core module (compare_networks_core.py) must be on sys.path — see the
# sys.path cell below.

# COMMAND ----------

# %pip install boto3

# COMMAND ----------

_GMT_CORE_SRC = "/Workspace/Shared/gmt"  # adjust if you used a custom path
import sys  # noqa: E402
from typing import cast  # noqa: E402

sys.path.insert(0, _GMT_CORE_SRC)

# COMMAND ----------

dbutils.widgets.text("network1", "", "Network 1 — s3://bucket/key or local path")  # noqa: F821
dbutils.widgets.text("network2", "", "Network 2 — s3://bucket/key or local path")  # noqa: F821
dbutils.widgets.text("fields", "speed,flow24hrs", "Fields to compare (comma-separated)")  # noqa: F821
dbutils.widgets.text(  # noqa: F821
    "output_file", "", "Output file — s3://bucket/key or local path (blank = print)"
)
dbutils.widgets.dropdown("as_bandwidths", "false", ["false", "true"], "As bandwidth polygons")  # noqa: F821
dbutils.widgets.text(  # noqa: F821
    "bandwidth_scale", "1.0", "Bandwidth scale (metres per field-unit, comma-separated per field)"
)
dbutils.widgets.dropdown("log_level", "INFO", ["DEBUG", "INFO", "WARNING", "ERROR"], "Log level")  # noqa: F821

# COMMAND ----------

import json  # noqa: E402
import logging  # noqa: E402

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("compare_networks_nb")
logger.setLevel(getattr(logging, dbutils.widgets.get("log_level").upper(), logging.INFO))  # noqa: F821

network1 = dbutils.widgets.get("network1").strip()  # noqa: F821
network2 = dbutils.widgets.get("network2").strip()  # noqa: F821
fields_raw = dbutils.widgets.get("fields").strip()  # noqa: F821
output_file = dbutils.widgets.get("output_file").strip()  # noqa: F821
as_bandwidths = dbutils.widgets.get("as_bandwidths").strip().lower() == "true"  # noqa: F821
bandwidth_scale_raw = dbutils.widgets.get("bandwidth_scale").strip() or "1.0"  # noqa: F821
_bw_parts = [float(x.strip()) for x in bandwidth_scale_raw.split(",") if x.strip()]
bandwidth_scale = _bw_parts[0] if len(_bw_parts) == 1 else _bw_parts

fields = [f.strip() for f in fields_raw.split(",") if f.strip()]

logger.info(
    "compare_networks network1=%s network2=%s fields=%s",
    network1,
    network2,
    fields,
)

# COMMAND ----------

from pathlib import Path  # noqa: E402

import boto3  # noqa: E402


def _read_network(uri: str) -> dict:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        obj = boto3.client("s3").get_object(Bucket=bucket, Key=key)
        return cast(dict, json.loads(obj["Body"].read()))
    return cast(dict, json.loads(Path(uri).read_bytes()))


fc1 = _read_network(network1)
fc2 = _read_network(network2)
logger.info(
    "Loaded network1 (%d features) and network2 (%d features)",
    len(fc1.get("features") or []),
    len(fc2.get("features") or []),
)

# COMMAND ----------

from compare_networks.core.compare_networks_core import compare_networks  # noqa: E402

result_fc = compare_networks(fc1, fc2, fields, as_bandwidths, bandwidth_scale)
features = result_fc.get("features") or []
matched = sum(1 for f in features if f.get("properties", {}).get("matchType") == "match")
added = sum(1 for f in features if f.get("properties", {}).get("matchType") == "added")
removed = sum(1 for f in features if f.get("properties", {}).get("matchType") == "removed")
logger.info("Result: matched=%d  added=%d  removed=%d", matched, added, removed)

# COMMAND ----------

payload = json.dumps(result_fc, ensure_ascii=False).encode("utf-8")
if output_file.startswith("s3://"):
    bucket, key = output_file[5:].split("/", 1)
    boto3.client("s3").put_object(
        Bucket=bucket, Key=key, Body=payload, ContentType="application/json"
    )
    logger.info("Written %s (%d bytes)", output_file, len(payload))
elif output_file:
    out_path = Path(output_file)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(payload)
    logger.info("Written local file %s (%d bytes)", out_path, len(payload))
else:
    print(payload[:2000].decode("utf-8"))
    logger.info("No output destination specified — printed first 2000 bytes above")

print(f"matched={matched}  added={added}  removed={removed}")
