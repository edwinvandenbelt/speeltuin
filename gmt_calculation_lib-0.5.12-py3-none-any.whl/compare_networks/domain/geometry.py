"""Perpendicular-offset polygon geometry for compare_networks bandwidth visualisation."""

from __future__ import annotations

import math

# Approximate metres per degree of latitude (constant worldwide).
_M_PER_DEG_LAT: float = 111_320.0


def _metres_per_deg_lon(lat_deg: float) -> float:
    """Return the approximate metres per degree of longitude at *lat_deg*."""
    return _M_PER_DEG_LAT * math.cos(math.radians(lat_deg))


def _right_perp_unit(dx: float, dy: float) -> tuple[float, float]:
    """Return the right-perpendicular unit vector of segment (dx, dy)."""
    length = math.hypot(dx, dy)
    if length == 0:
        return (0.0, 0.0)
    return (dy / length, -dx / length)


def _vertex_offset_directions(
    coords: list, m_lat: float, m_lon: float
) -> list[tuple[float, float]]:
    """Compute the right-offset unit vector at every vertex of a LineString.

    Segment directions are converted to a local metric space (metres) before
    computing perpendiculars so that the result is independent of the aspect
    ratio between latitude and longitude degrees.
    """
    n = len(coords)
    directions: list[tuple[float, float]] = []
    for i in range(n):
        if n == 1:
            directions.append((0.0, 0.0))
            continue
        perps: list[tuple[float, float]] = []
        if i > 0:
            # Convert degree delta to metres for correct perpendicular computation.
            dx = (coords[i][0] - coords[i - 1][0]) * m_lon
            dy = (coords[i][1] - coords[i - 1][1]) * m_lat
            perps.append(_right_perp_unit(dx, dy))
        if i < n - 1:
            dx = (coords[i + 1][0] - coords[i][0]) * m_lon
            dy = (coords[i + 1][1] - coords[i][1]) * m_lat
            perps.append(_right_perp_unit(dx, dy))
        ux = sum(p[0] for p in perps) / len(perps)
        uy = sum(p[1] for p in perps) / len(perps)
        mag = math.hypot(ux, uy)
        if mag == 0:
            directions.append((0.0, 0.0))
        else:
            directions.append((ux / mag, uy / mag))
    return directions


def _offset_polygon_from_dirs(
    coords: list,
    dirs: list[tuple[float, float]],
    m_lat: float,
    m_lon: float,
    d_inner_m: float,
    d_outer_m: float,
) -> dict:
    """Build a GeoJSON Polygon band using pre-computed per-vertex offset directions.

    *dirs*, *m_lat*, and *m_lon* are computed once per feature by the caller and
    reused across multiple band calls, avoiding redundant trigonometry.
    """
    inner = [
        [
            coords[i][0] + dirs[i][0] * d_inner_m / m_lon,
            coords[i][1] + dirs[i][1] * d_inner_m / m_lat,
        ]
        for i in range(len(coords))
    ]
    outer = [
        [
            coords[i][0] + dirs[i][0] * d_outer_m / m_lon,
            coords[i][1] + dirs[i][1] * d_outer_m / m_lat,
        ]
        for i in range(len(coords))
    ]
    ring = inner + list(reversed(outer))
    ring.append(ring[0])
    return {"type": "Polygon", "coordinates": [ring]}


def _offset_polygon(coords: list, d_inner_m: float, d_outer_m: float) -> dict:
    """Build a GeoJSON Polygon band between right-offsets *d_inner_m* and *d_outer_m*.

    Offset distances are in **metres**.  The polygon vertices are in the original
    geographic (lon, lat) coordinate space.

    For callers that emit multiple bands for the same feature, prefer
    :func:`_offset_polygon_from_dirs` to avoid recomputing the vertex directions.
    """
    lat_centre = sum(c[1] for c in coords) / len(coords)
    m_lat = _M_PER_DEG_LAT
    m_lon = _metres_per_deg_lon(lat_centre)
    dirs = _vertex_offset_directions(coords, m_lat, m_lon)
    return _offset_polygon_from_dirs(coords, dirs, m_lat, m_lon, d_inner_m, d_outer_m)


def _band_width(value: object, scale: float) -> float:
    """Return ``max(0, value * scale)`` or 0.0 for non-numeric values."""
    return max(0.0, float(value) * scale) if isinstance(value, (int, float)) else 0.0


def _bandwidth_features(
    feature: dict,
    match_props: dict,
    fields: list[str],
    bandwidth_scales: list[float],
) -> list[dict]:
    """Return polygon band features for a 'match' link (one triplet per field).

    For each field three bands may be emitted (stacked right of the geometry):
    - ``matchType="matched"``  — the unchanged floor (flow_min), width = field_min * scale
    - ``matchType="increase"`` — the growth delta, width = delta_plus * scale
    - ``matchType="reduction"``— the shrink delta, width = delta_min * scale

    The *increase* and *reduction* bands both start at the outer edge of the
    *matched* band so they are properly dispositioned by the flow_min width.
    Separate polygon features are emitted for every compared field.

    *bandwidth_scales* is a per-field list of **metres per field unit**.

    Vertex offset directions and metric-space conversion factors are computed
    once per feature and shared across all band calls.
    """
    geom = feature.get("geometry")
    if not geom or geom.get("type") != "LineString":
        return [{"type": "Feature", "geometry": geom, "properties": match_props}]

    coords = geom["coordinates"]

    # Compute metric factors and vertex directions once for all bands of this feature.
    lat_centre = sum(c[1] for c in coords) / len(coords)
    m_lat = _M_PER_DEG_LAT
    m_lon = _metres_per_deg_lon(lat_centre)
    dirs = _vertex_offset_directions(coords, m_lat, m_lon)

    out: list[dict] = []
    cumulative_offset = 0.0

    # Collect the passthrough props once: everything from match_props that is
    # not a field-specific derived key and not matchType.
    field_derived = {
        key for f in fields for key in (f, f"{f}_min", f"{f}_delta_plus", f"{f}_delta_min")
    }
    passthrough = {
        k: v for k, v in match_props.items() if k not in field_derived and k != "matchType"
    }

    for field, scale in zip(fields, bandwidth_scales, strict=False):
        f_min = match_props.get(f"{field}_min")
        f_delta_plus = match_props.get(f"{field}_delta_plus")
        f_delta_min = match_props.get(f"{field}_delta_min")

        # When the field was unchanged, derived keys are absent.  Fall back to
        # the original feature's value so the matched band still gets its width.
        if f_min is None and f_delta_plus is None and f_delta_min is None:
            raw = (feature.get("properties") or {}).get(field)
            f_min = float(raw) if isinstance(raw, (int, float)) else None

        w_match = _band_width(f_min, scale)
        w_added = _band_width(f_delta_plus, scale)
        w_removed = _band_width(f_delta_min, scale)

        # Shared base properties carried by every band of this field.
        # Only include delta props when the field actually changed.
        base: dict = {**passthrough}
        if f_delta_plus is not None or f_delta_min is not None:
            base[f"{field}DeltaPlus"] = f_delta_plus
            base[f"{field}DeltaMin"] = f_delta_min

        # "matched" band — represents the unchanged flow_min floor.
        if w_match > 0:
            poly = _offset_polygon_from_dirs(
                coords, dirs, m_lat, m_lon, cumulative_offset, cumulative_offset + w_match
            )
            out.append(
                {
                    "type": "Feature",
                    "geometry": poly,
                    "properties": {
                        **base,
                        "matchType": "matched",
                        "bandWidth": w_match,
                        field: f_min,
                    },
                }
            )

        # "increase" and "reduction" both start at the outer edge of the matched band.
        add_start = cumulative_offset + w_match

        if w_added > 0:
            poly = _offset_polygon_from_dirs(
                coords, dirs, m_lat, m_lon, add_start, add_start + w_added
            )
            out.append(
                {
                    "type": "Feature",
                    "geometry": poly,
                    "properties": {
                        **base,
                        "matchType": "increase",
                        "bandWidth": w_added,
                        field: f_delta_plus,
                    },
                }
            )

        if w_removed > 0:
            poly = _offset_polygon_from_dirs(
                coords, dirs, m_lat, m_lon, add_start, add_start + w_removed
            )
            out.append(
                {
                    "type": "Feature",
                    "geometry": poly,
                    "properties": {
                        **base,
                        "matchType": "reduction",
                        "bandWidth": w_removed,
                        field: f_delta_min,
                    },
                }
            )

        cumulative_offset += w_match + max(w_added, w_removed)

    return out or [{"type": "Feature", "geometry": geom, "properties": match_props}]


def _single_band_features(
    feature: dict,
    props: dict,
    fields: list[str],
    bandwidth_scales: list[float],
    match_type: str,
) -> list[dict]:
    """Return polygon band features for a fully-added or fully-removed link.

    *match_type* should be ``"increase"`` (link only in network2) or
    ``"reduction"`` (link only in network1).  A separate polygon is emitted
    per field.

    *bandwidth_scales* is a per-field list of **metres per field unit**.

    Vertex offset directions and metric-space conversion factors are computed
    once per feature and shared across all band calls.
    """
    geom = feature.get("geometry")
    if not geom or geom.get("type") != "LineString":
        return [{"type": "Feature", "geometry": geom, "properties": props}]

    coords = geom["coordinates"]

    # Compute metric factors and vertex directions once for all bands of this feature.
    lat_centre = sum(c[1] for c in coords) / len(coords)
    m_lat = _M_PER_DEG_LAT
    m_lon = _metres_per_deg_lon(lat_centre)
    dirs = _vertex_offset_directions(coords, m_lat, m_lon)

    out: list[dict] = []
    cumulative_offset = 0.0
    fprops = feature.get("properties") or {}

    # All original properties pass through unchanged (no comparison partner exists).
    field_set = set(fields)
    passthrough = {k: v for k, v in fprops.items() if k not in field_set}

    for field, scale in zip(fields, bandwidth_scales, strict=False):
        v = fprops.get(field)
        width = _band_width(v, scale)
        if width > 0:
            poly = _offset_polygon_from_dirs(
                coords, dirs, m_lat, m_lon, cumulative_offset, cumulative_offset + width
            )
            delta_plus = v if match_type == "increase" else 0
            delta_min = v if match_type == "reduction" else 0
            out.append(
                {
                    "type": "Feature",
                    "geometry": poly,
                    "properties": {
                        **passthrough,
                        "matchType": match_type,
                        "bandWidth": width,
                        field: v,
                        f"{field}DeltaPlus": delta_plus,
                        f"{field}DeltaMin": delta_min,
                    },
                }
            )
        cumulative_offset += width

    return out or [{"type": "Feature", "geometry": geom, "properties": props}]
