"""Unit tests for adjust.core.adjust_core — pure helper functions only."""

from __future__ import annotations

import itertools
import json
import tempfile
from pathlib import Path

import pytest
from gmt_shared.uri import mem_clear, mem_put

from adjust.core.adjust_core import (
    _apply_flow_delta,
    _apply_od_adjustments,
    _compute_link_flow_delta,
    _detect_mode,
    _discover_area_id,
    _evaporate_unroutable_pairs,
    _explode_ring_n_way,
    _find_pairs_using_links,
    _get_closed_link_ids,
    _load_changes,
    _normalize_od_fc_to_fractions,
    _redistribute_routes,
    _restore_origin_productions,
    _routes_mode_from_path,
    _scale_zone_properties,
    _split_changes,
    _validate_od_adjustments,
    apply_link_adjustments,
    apply_od_adjustments,
    apply_zone_explosions,
)

# ---------------------------------------------------------------------------
# _discover_area_id
# ---------------------------------------------------------------------------


class TestDiscoverAreaId:
    def test_discovers_from_clean_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "test-uuid-1234-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_area_id(folder) == "test-uuid-1234"

    def test_raises_when_no_network_file(self):
        with tempfile.TemporaryDirectory() as tmp, pytest.raises(FileNotFoundError):
            _discover_area_id(Path(tmp))

    def test_prefers_clean_over_raw(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "my-uuid-5678-NETWORK-RAW-CAR.parquet").write_bytes(b"")
            (folder / "my-uuid-5678-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_area_id(folder) == "my-uuid-5678"

    def test_falls_back_to_raw_when_no_clean(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "my-uuid-5678-NETWORK-RAW-CAR.parquet").write_bytes(b"")
            assert _discover_area_id(folder) == "my-uuid-5678"


# ---------------------------------------------------------------------------
# _detect_mode
# ---------------------------------------------------------------------------


class TestDetectMode:
    def test_detects_car(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-CAR.parquet").write_bytes(b"")
            assert _detect_mode(folder, area_id) == "CAR"

    def test_detects_bike(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-BIKE.parquet").write_bytes(b"")
            assert _detect_mode(folder, area_id) == "BIKE"

    def test_raises_when_no_network_file(self):
        with tempfile.TemporaryDirectory() as tmp, pytest.raises(FileNotFoundError):
            _detect_mode(Path(tmp), "missing-id")

    def test_ignores_non_mode_files(self):
        """Files like {id}-NETWORK-RAW-CAR.parquet must not be matched."""
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-RAW-CAR.parquet").write_bytes(b"")
            (folder / f"{area_id}-NETWORK-CAR.parquet").write_bytes(b"")
            assert _detect_mode(folder, area_id) == "CAR"


# ---------------------------------------------------------------------------
# _discover_area_id — mem:// store
# ---------------------------------------------------------------------------


class TestDiscoverAreaIdMem:
    def teardown_method(self):
        mem_clear()

    def test_discovers_from_clean_network(self):
        mem_put("mem://testfolder/my-uuid-1111-NETWORK-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder") == "my-uuid-1111"

    def test_raises_when_store_empty(self):
        with pytest.raises(FileNotFoundError):
            _discover_area_id("mem://empty")

    def test_prefers_clean_over_raw(self):
        mem_put("mem://testfolder/my-uuid-5678-NETWORK-RAW-CAR.parquet", b"")
        mem_put("mem://testfolder/my-uuid-5678-NETWORK-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder") == "my-uuid-5678"

    def test_falls_back_to_raw_when_no_clean(self):
        mem_put("mem://testfolder/my-uuid-5678-NETWORK-RAW-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder") == "my-uuid-5678"

    def test_trailing_slash_in_folder_ignored(self):
        mem_put("mem://testfolder/my-uuid-9999-NETWORK-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder/") == "my-uuid-9999"


# ---------------------------------------------------------------------------
# _detect_mode — mem:// store
# ---------------------------------------------------------------------------


class TestDetectModeMem:
    def teardown_method(self):
        mem_clear()

    def test_detects_car(self):
        mem_put("mem://testfolder/abc-123-NETWORK-CAR.parquet", b"")
        assert _detect_mode("mem://testfolder", "abc-123") == "CAR"

    def test_detects_bike(self):
        mem_put("mem://testfolder/abc-123-NETWORK-BIKE.parquet", b"")
        assert _detect_mode("mem://testfolder", "abc-123") == "BIKE"

    def test_raises_when_not_found(self):
        with pytest.raises(FileNotFoundError):
            _detect_mode("mem://testfolder", "missing-id")

    def test_ignores_raw_variants(self):
        mem_put("mem://testfolder/abc-123-NETWORK-RAW-CAR.parquet", b"")
        mem_put("mem://testfolder/abc-123-NETWORK-CAR.parquet", b"")
        assert _detect_mode("mem://testfolder", "abc-123") == "CAR"


# ---------------------------------------------------------------------------
# _routes_mode_from_path
# ---------------------------------------------------------------------------


class TestRoutesModeFromPath:
    def test_car_routes_returns_car(self):
        assert _routes_mode_from_path("abc-123-ROUTES-CAR.parquet", "MIXED") == "CAR"

    def test_bike_routes_returns_bike(self):
        assert _routes_mode_from_path("abc-123-ROUTES-BIKE.parquet", "MIXED") == "BIKE"

    def test_mixed_routes_returns_mixed(self):
        assert _routes_mode_from_path("abc-123-ROUTES-MIXED.parquet", "CAR") == "MIXED"

    def test_car_routes_in_mixed_network_uses_car(self):
        """Core bug scenario: CAR routes file + MIXED network → output mode must be CAR."""
        assert _routes_mode_from_path("uuid-ROUTES-CAR.parquet", fallback="MIXED") == "CAR"

    def test_unknown_filename_falls_back(self):
        assert _routes_mode_from_path("my_custom_routes.parquet", fallback="CAR") == "CAR"

    def test_path_object_accepted(self):
        from pathlib import Path

        assert _routes_mode_from_path(Path("abc-ROUTES-BIKE.parquet"), fallback="CAR") == "BIKE"

    def test_full_absolute_path_works(self):
        assert _routes_mode_from_path("/data/area/abc-ROUTES-CAR.parquet", "MIXED") == "CAR"


# ---------------------------------------------------------------------------
# _load_changes
# ---------------------------------------------------------------------------


class TestLoadChanges:
    def test_parses_inline_json(self):
        changes = '[{"nodeId": "123", "production": "+100"}]'
        result = _load_changes(changes)
        assert result == [{"nodeId": "123", "production": "+100"}]

    def test_reads_from_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "changes.json"
            data = [{"zoneId": "z1", "attraction": "200"}]
            path.write_text(json.dumps(data), encoding="utf-8")
            assert _load_changes(str(path)) == data

    def test_empty_array(self):
        assert _load_changes("[]") == []

    def test_raises_on_invalid_json(self):
        with pytest.raises(json.JSONDecodeError):
            _load_changes("{not valid json}")


# ---------------------------------------------------------------------------
# apply_link_adjustments
# ---------------------------------------------------------------------------


def _net_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _link(link_id, from_node, to_node, speed, capacity, lanes=1, flow=50.0):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "speed": speed,
            "capacity": capacity,
            "lanes": lanes,
            "flow": flow,
            "flow24hrs": flow,
            "flowsPerDaypart": {"mrh": flow * 0.2, "erh": flow * 0.1},
            "flowsPerMotive": {"work": flow * 0.8, "other": flow * 0.2},
        },
    }


class TestApplyLinkAdjustments:
    def test_capacity_zero_preserves_flow(self):
        """Closing a link (capacity=0) must NOT reset flow fields.

        Flow adjustment is handled by _apply_flow_delta in the pipeline;
        apply_link_adjustments only changes capacity/speed.
        """
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        adjusted_fc, affected = apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 0}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 0.0
        assert props["flow"] == pytest.approx(70.5)
        assert props["flow24hrs"] == pytest.approx(70.5)
        assert affected == [("1", "2")]

    def test_partial_capacity_preserves_flow(self):
        """Reducing capacity (but not to zero) must NOT reset flows."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        adjusted_fc, _ = apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 300}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 300.0
        assert props["flow"] == pytest.approx(70.5)

    def test_speed_zero_preserves_flow(self):
        """Setting speed=0 (results in capacity=0) must NOT reset flow fields."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=35.0))
        adjusted_fc, _ = apply_link_adjustments(fc, [{"linkId": "LK1", "speed": 0}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 0.0
        assert props["flow"] == pytest.approx(35.0)

    def test_original_network_not_mutated(self):
        """apply_link_adjustments must return a deep copy; original must be unchanged."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 0}])
        assert fc["features"][0]["properties"]["flow"] == pytest.approx(70.5)
        assert fc["features"][0]["properties"]["capacity"] == 500.0


# ---------------------------------------------------------------------------
# _compute_link_flow_delta
# ---------------------------------------------------------------------------


def _routes_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _zones_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _zone(zone_id, production):
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {"zoneId": zone_id, "production": production},
    }


def _od_feature(
    from_id, to_id, routes, *, from_type="zone", to_type="zone", origin_production=None
):
    """Minimal OD FeatureCollection feature.

    Pass *origin_production* to set ``originProduction`` on the feature
    (required for ``od_fc_new`` inputs that use the normalized fraction
    convention: actual trips = ``route.trips × originProduction``).
    """
    props = {
        "fromZoneId": from_id,
        "toZoneId": to_id,
        "fromType": from_type,
        "toType": to_type,
        "tripFraction": sum(r.get("trips", 0) for r in routes),
        "routes": routes,
    }
    if origin_production is not None:
        props["originProduction"] = origin_production
    return {"type": "Feature", "geometry": None, "properties": props}


def _route(trips, *link_ids):
    return {"trips": trips, "linkPath": list(link_ids)}


class TestComputeLinkFlowDelta:
    def test_re_routed_pair_scales_by_production(self):
        """route.trips is a fraction; actual flow = route.trips * origin production."""
        # Zone Z1 has production=100; route.trips=0.1 → 10 actual trips
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A", "B")]))
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "B", "C")]))
        od_new = _routes_fc()

        delta = _compute_link_flow_delta(old_routes, recomputed, od_new, zones)

        assert delta["A"] == pytest.approx((10.0, 0.0))  # removed from A
        assert delta["B"] == pytest.approx((10.0, 10.0))  # same share on B
        assert delta["C"] == pytest.approx((0.0, 10.0))  # added to C

    def test_new_zone_adjustment_pair_has_zero_before(self):
        """Newly added OD pairs have flow_before=0 for all their links.

        od_fc_new uses the normalized fraction convention after
        ``_normalize_od_fc_to_fractions``: route.trips is a fraction and
        originProduction holds the absolute value.
        """
        zones = _zones_fc(_zone("Z3", 200.0), _zone("Z4", 80.0))
        od_new = _routes_fc(
            _od_feature("Z3", "Z4", [_route(1.0, "X", "Y")], origin_production=10.0)
        )

        delta = _compute_link_flow_delta(_routes_fc(), _routes_fc(), od_new, zones)

        assert delta["X"] == pytest.approx((0.0, 10.0))
        assert delta["Y"] == pytest.approx((0.0, 10.0))

    def test_unaffected_pair_not_in_delta(self):
        """Pairs not in recomputed_fc must not contribute to the delta."""
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z3", 100.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")]),
            _od_feature("Z3", "Z4", [_route(0.1, "B")]),
        )
        # Only Z1→Z2 is re-routed
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "C")]))

        delta = _compute_link_flow_delta(old_routes, recomputed, _routes_fc(), zones)

        assert "A" in delta
        assert "B" not in delta

    def test_empty_inputs_return_empty_delta(self):
        empty = _routes_fc()
        delta = _compute_link_flow_delta(empty, empty, empty, _zones_fc())
        assert delta == {}

    def test_node_type_origin_uses_factor_one(self):
        """For node-type origins in od_fc_new, actual trips = route.trips × originProduction."""
        zones = _zones_fc()  # no zone data — node adjustments bypass zone lookup
        od_new = _routes_fc(
            _od_feature(
                "NODE_42", "Z1", [_route(1.0, "X")], from_type="node", origin_production=5.0
            )
        )

        delta = _compute_link_flow_delta(_routes_fc(), _routes_fc(), od_new, zones)

        assert delta["X"] == pytest.approx((0.0, 5.0))

    def test_od_replacement_subtracts_old_flows(self):
        """When od_fc_new replaces an existing base pair, old flows are flow_before.

        The old pair (from base ROUTES) uses the fraction convention: trips × production.
        The new od_fc_new pair uses the normalized fraction convention: route.trips ×
        originProduction — yielding the same 10 absolute trips.
        """
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A", "B")])  # fraction: 0.1 × 100 = 10 trips
        )
        # New routes for same pair — normalized fraction: route.trips=1.0 × originProduction=10.0.
        od_new = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "B", "C")], origin_production=10.0)
        )

        delta = _compute_link_flow_delta(old_routes, _routes_fc(), od_new, zones)

        assert delta["A"] == pytest.approx((10.0, 0.0))  # old link removed
        assert delta["B"] == pytest.approx((10.0, 10.0))  # same trips, no net change
        assert delta["C"] == pytest.approx((0.0, 10.0))  # new link added

    def test_tombstone_in_od_removes_old_flows(self):
        """A tombstone (routes=[]) replacing an existing pair zeroes out its links."""
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "X", "Y")])  # 10 trips on X, Y
        )
        tombstone = _routes_fc(
            _od_feature("Z1", "Z2", [])  # trips=0, replaces old pair
        )

        delta = _compute_link_flow_delta(old_routes, _routes_fc(), tombstone, zones)

        assert delta["X"] == pytest.approx((10.0, 0.0))  # fully removed
        assert delta["Y"] == pytest.approx((10.0, 0.0))

    def test_relative_adjustment_adds_without_removing_old_flow(self):
        """A relative delta ("+191"-style) must not wipe the pair's existing flow.

        Unlike an absolute/tombstone replacement, od_fc_new for a relative node
        adjustment represents only the incremental change — the pair's old flow
        must be left untouched and the new flow simply added on top.
        """
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A", "B")])  # fraction: 0.1 × 100 = 10 trips
        )
        # Incremental routes for the same pair, representing only the added production.
        od_new = _routes_fc(_od_feature("Z1", "Z2", [_route(1.0, "B", "C")], origin_production=5.0))

        delta = _compute_link_flow_delta(
            old_routes, _routes_fc(), od_new, zones, relative_origin_ids={"Z1"}
        )

        assert "A" not in delta  # old flow untouched — not subtracted
        assert delta["B"] == pytest.approx((0.0, 5.0))  # only the incremental trips added
        assert delta["C"] == pytest.approx((0.0, 5.0))

    def test_relative_origin_ids_default_preserves_replacement_behavior(self):
        """Without relative_origin_ids, replacement semantics are unchanged (regression guard)."""
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A", "B")]))
        od_new = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "B", "C")], origin_production=10.0)
        )

        delta = _compute_link_flow_delta(old_routes, _routes_fc(), od_new, zones)

        assert delta["A"] == pytest.approx((10.0, 0.0))


# ---------------------------------------------------------------------------
# _apply_flow_delta
# ---------------------------------------------------------------------------


class TestApplyFlowDelta:
    def test_positive_delta_increases_flow(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        delta = {"LK1": (0.0, 10.0)}  # +10 new trips
        adj, report = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        assert props["flow"] == pytest.approx(110.0)
        assert props["flow24hrs"] == pytest.approx(110.0)
        assert len(report) == 1
        assert report[0]["flow_delta"] == pytest.approx(10.0)

    def test_negative_delta_decreases_flow(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        delta = {"LK1": (10.0, 0.0)}  # 10 trips removed
        adj, _report = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        assert props["flow"] == pytest.approx(90.0)

    def test_flow_clamped_to_zero(self):
        """Flow must never go negative."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=5.0))
        delta = {"LK1": (20.0, 0.0)}  # remove 20 trips from a link with only 5
        adj, _ = _apply_flow_delta(fc, delta)

        assert adj["features"][0]["properties"]["flow"] == pytest.approx(0.0)

    def test_sub_dicts_scaled_proportionally(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        # flow 100 → 110 (+10%), all sub-values should scale by 1.1
        delta = {"LK1": (0.0, 10.0)}
        adj, _ = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        # Original: mrh=20, erh=10, work=80, other=20
        assert props["flowsPerDaypart"]["mrh"] == pytest.approx(22.0)
        assert props["flowsPerDaypart"]["erh"] == pytest.approx(11.0)
        assert props["flowsPerMotive"]["work"] == pytest.approx(88.0)
        assert props["flowsPerMotive"]["other"] == pytest.approx(22.0)

    def test_zero_delta_link_not_in_report(self):
        """Links with flow_before == flow_after must not appear in the report."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=50.0))
        delta = {"LK1": (5.0, 5.0)}  # no change
        _, report = _apply_flow_delta(fc, delta)
        assert report == []

    def test_original_network_not_mutated(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=50.0))
        delta = {"LK1": (0.0, 20.0)}
        _apply_flow_delta(fc, delta)
        assert fc["features"][0]["properties"]["flow"] == pytest.approx(50.0)


# ---------------------------------------------------------------------------
# _get_closed_link_ids
# ---------------------------------------------------------------------------


def _net_link(link_id: str, capacity: float) -> dict:
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {"linkId": link_id, "capacity": capacity},
    }


class TestGetClosedLinkIds:
    def test_returns_only_zero_capacity_links(self):
        fc = {
            "type": "FeatureCollection",
            "features": [
                _net_link("A", 0.0),
                _net_link("B", 100.0),
                _net_link("C", 0.0),
            ],
        }
        result = _get_closed_link_ids(fc, {"A", "B", "C"})
        assert result == {"A", "C"}

    def test_ignores_links_not_in_affected_set(self):
        fc = {
            "type": "FeatureCollection",
            "features": [
                _net_link("A", 0.0),
                _net_link("B", 0.0),
            ],
        }
        result = _get_closed_link_ids(fc, {"A"})
        assert result == {"A"}

    def test_empty_when_no_zero_capacity(self):
        fc = {"type": "FeatureCollection", "features": [_net_link("A", 50.0)]}
        assert _get_closed_link_ids(fc, {"A"}) == set()

    def test_empty_network(self):
        assert _get_closed_link_ids({"type": "FeatureCollection", "features": []}, {"A"}) == set()


# ---------------------------------------------------------------------------
# _redistribute_routes
# ---------------------------------------------------------------------------

_AFFECTED = {"LK_CLOSED"}
_CLOSED = {"LK_CLOSED"}


class TestRedistributeRoutes:
    # ------------------------------------------------------------------
    # N=2, B=1 → all flow to remaining route; trips sum == tripFraction
    # ------------------------------------------------------------------
    def test_n2_b1_all_to_remaining(self):
        # production=100, tripFraction=0.3+0.2=0.5 → total_trips=50 ≥ 2
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.3, "LK_CLOSED"),
                _route(0.2, "LK_OTHER"),
            ],
        )
        tf = feat["properties"]["tripFraction"]
        redist_fc, _, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert recompute == []
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert len(result_routes) == 1
        assert result_routes[0]["trips"] == pytest.approx(tf)

    # ------------------------------------------------------------------
    # N=3, B=1 → proportional redistribution to 2 remaining; sum preserved
    # ------------------------------------------------------------------
    def test_n3_b1_proportional(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_CLOSED"),
                _route(0.1, "LK_A"),
                _route(0.3, "LK_B"),
            ],
        )
        tf = feat["properties"]["tripFraction"]
        redist_fc, _, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert recompute == []
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert len(result_routes) == 2
        assert sum(r["trips"] for r in result_routes) == pytest.approx(tf)

    # ------------------------------------------------------------------
    # N=3, B=2 → only 1 remaining, N≠2 → re-route
    # ------------------------------------------------------------------
    def test_n3_b2_needs_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_CLOSED"),
                _route(0.1, "LK_OTHER"),
            ],
        )
        redist_fc, _, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert redist_fc["features"] == []
        assert len(recompute) == 1
        assert recompute[0]["fromId"] == "Z1"

    # ------------------------------------------------------------------
    # N=4, B=2 → 2 remaining ≥ 2 → local redistribution
    # ------------------------------------------------------------------
    def test_n4_b2_proportional(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_A"),
                _route(0.2, "LK_B"),
            ],
        )
        tf = feat["properties"]["tripFraction"]
        redist_fc, _, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert recompute == []
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert len(result_routes) == 2
        assert sum(r["trips"] for r in result_routes) == pytest.approx(tf)

    # ------------------------------------------------------------------
    # N=4, B=3 → only 1 remaining, N≠2 → re-route
    # ------------------------------------------------------------------
    def test_n4_b3_needs_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_OTHER"),
            ],
        )
        redist_fc, _, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert redist_fc["features"] == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # N=1, B=1 → 0 remaining → re-route
    # ------------------------------------------------------------------
    def test_n1_b1_needs_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.3, "LK_CLOSED"),
            ],
        )
        redist_fc, _, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert redist_fc["features"] == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # Evaporation: total trips below threshold → routes=[], not re-routed
    # ------------------------------------------------------------------
    def test_evaporated_below_min_trips(self):
        # production=10, tripFraction=0.1 → total_trips=1.0 < default 2.0
        zones = _zones_fc(_zone("Z1", 10.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.1, "LK_CLOSED"),
            ],
        )
        redist_fc, _, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert recompute == []
        assert len(redist_fc["features"]) == 1
        assert redist_fc["features"][0]["properties"]["routes"] == []

    # ------------------------------------------------------------------
    # Non-closed adjusted link → pair must go to recompute (speed tweak)
    # ------------------------------------------------------------------
    def test_non_closed_adjusted_link_to_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_SPEED"),
                _route(0.2, "LK_OTHER"),
            ],
        )
        redist_fc, _, recompute = _redistribute_routes(_routes_fc(feat), {"LK_SPEED"}, set(), zones)
        assert redist_fc["features"] == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # tripFraction invariant: sum(new_trips) == tripFraction after redistribution
    # ------------------------------------------------------------------
    def test_tripfraction_preserved_after_redistribution(self):
        zones = _zones_fc(_zone("Z1", 200.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.3, "LK_CLOSED"),
                _route(0.4, "LK_A"),
                _route(0.2, "LK_B"),
            ],
        )
        tf = feat["properties"]["tripFraction"]
        redist_fc, _, _ = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert sum(r["trips"] for r in result_routes) == pytest.approx(tf)

    # ------------------------------------------------------------------
    # Routes with nodePath → handed to detour splicing, not re-routed
    # ------------------------------------------------------------------
    def test_closed_pair_with_node_paths_goes_to_splice(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        routes = [
            {**_route(0.2, "LK_CLOSED"), "nodePath": ["Z_Z1", "1", "2", "Z_Z2"]},
            {**_route(0.1, "LK_OTHER"), "nodePath": ["Z_Z1", "3", "Z_Z2"]},
        ]
        feat = _od_feature("Z1", "Z2", routes)
        redist_fc, splice, recompute = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        assert redist_fc["features"] == []
        assert recompute == []
        assert splice == [feat]

    def test_evaporation_takes_precedence_over_splice(self):
        zones = _zones_fc(_zone("Z1", 10.0))
        routes = [{**_route(0.1, "LK_CLOSED"), "nodePath": ["Z_Z1", "1", "Z_Z2"]}]
        feat = _od_feature("Z1", "Z2", routes)
        redist_fc, splice, recompute = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        assert splice == []
        assert recompute == []
        assert redist_fc["features"][0]["properties"]["routes"] == []

    def test_non_closed_adjustment_still_fully_rerouted_with_node_paths(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        routes = [{**_route(0.2, "LK_SPEED"), "nodePath": ["Z_Z1", "1", "Z_Z2"]}]
        feat = _od_feature("Z1", "Z2", routes)
        _, splice, recompute = _redistribute_routes(_routes_fc(feat), {"LK_SPEED"}, set(), zones)
        assert splice == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # Non-closed adjustment, >=2 known routes with nodePath → cheap recost
    # path (splice_detours_for_blocked_routes), not full re-routing.
    # ------------------------------------------------------------------
    def test_non_closed_adjustment_with_multiple_node_paths_goes_to_splice(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        routes = [
            {**_route(0.2, "LK_SPEED"), "nodePath": ["Z_Z1", "1", "2", "Z_Z2"]},
            {**_route(0.1, "LK_OTHER"), "nodePath": ["Z_Z1", "3", "Z_Z2"]},
        ]
        feat = _od_feature("Z1", "Z2", routes)
        redist_fc, splice, recompute = _redistribute_routes(
            _routes_fc(feat), {"LK_SPEED"}, set(), zones
        )
        assert redist_fc["features"] == []
        assert recompute == []
        assert splice == [feat]

    def test_non_closed_single_route_with_node_path_still_fully_rerouted(self):
        # Single known route, no fallback to redistribute/recost onto —
        # still needs full re-routing even though it has a nodePath.
        zones = _zones_fc(_zone("Z1", 100.0))
        routes = [{**_route(0.2, "LK_SPEED"), "nodePath": ["Z_Z1", "1", "2", "Z_Z2"]}]
        feat = _od_feature("Z1", "Z2", routes)
        redist_fc, splice, recompute = _redistribute_routes(
            _routes_fc(feat), {"LK_SPEED"}, set(), zones
        )
        assert redist_fc["features"] == []
        assert splice == []
        assert len(recompute) == 1


# ---------------------------------------------------------------------------
# _normalize_od_fc_to_fractions
# ---------------------------------------------------------------------------


class TestNormalizeOdFcToFractions:
    def test_single_origin_single_route_sets_origin_production(self):
        """Single origin with one route: trips become 1.0, originProduction = total."""
        od = _routes_fc(_od_feature("Z1", "Z2", [_route(42.0, "A")]))
        result = _normalize_od_fc_to_fractions(od)
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(42.0)
        assert props["routes"][0]["trips"] == pytest.approx(1.0)
        assert props["tripFraction"] == pytest.approx(1.0)

    def test_single_origin_multiple_routes_splits_proportionally(self):
        """Two routes: trips normalized by total; Σ route.trips == 1.0."""
        od = _routes_fc(_od_feature("Z1", "Z2", [_route(30.0, "A"), _route(20.0, "B")]))
        result = _normalize_od_fc_to_fractions(od)
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(50.0)
        assert props["routes"][0]["trips"] == pytest.approx(0.6)
        assert props["routes"][1]["trips"] == pytest.approx(0.4)
        assert sum(r["trips"] for r in props["routes"]) == pytest.approx(1.0)

    def test_multiple_pairs_same_origin_normalized_together(self):
        """Two OD pairs from Z1: total=10, each pair's route.trips normalized by 10."""
        od = _routes_fc(
            _od_feature("Z1", "Z2", [_route(6.0, "A")]),
            _od_feature("Z1", "Z3", [_route(4.0, "B")]),
        )
        result = _normalize_od_fc_to_fractions(od)
        for feat in result["features"]:
            assert feat["properties"]["originProduction"] == pytest.approx(10.0)
        trips_sum = sum(
            r["trips"] for feat in result["features"] for r in feat["properties"]["routes"]
        )
        assert trips_sum == pytest.approx(1.0)

    def test_multiple_origins_normalized_independently(self):
        """Z1 (total=100) and Z2 (total=50) are each normalized to Σ=1.0."""
        od = _routes_fc(
            _od_feature("Z1", "Z2", [_route(100.0, "A")]),
            _od_feature("Z2", "Z3", [_route(50.0, "B")]),
        )
        result = _normalize_od_fc_to_fractions(od)
        feats = result["features"]
        assert feats[0]["properties"]["originProduction"] == pytest.approx(100.0)
        assert feats[0]["properties"]["routes"][0]["trips"] == pytest.approx(1.0)
        assert feats[1]["properties"]["originProduction"] == pytest.approx(50.0)
        assert feats[1]["properties"]["routes"][0]["trips"] == pytest.approx(1.0)

    def test_zero_total_trips_left_unchanged(self):
        """Feature with no routes (zero total) is left as-is without originProduction."""
        od = _routes_fc(_od_feature("Z1", "Z2", []))
        result = _normalize_od_fc_to_fractions(od)
        props = result["features"][0]["properties"]
        assert props.get("originProduction", 0.0) == pytest.approx(0.0)

    def test_trips_sum_to_one_per_origin_zone(self):
        """Invariant: Σ route.trips per origin zone ≈ 1.0 after normalization."""
        od = _routes_fc(
            _od_feature("Z1", "Z2", [_route(300.0, "A"), _route(200.0, "B")]),
            _od_feature("Z1", "Z3", [_route(100.0, "C")]),
            _od_feature("Z2", "Z4", [_route(75.0, "D")]),
        )
        result = _normalize_od_fc_to_fractions(od)
        origin_sums: dict[str, float] = {}
        for feat in result["features"]:
            props = feat["properties"]
            from_id = props["fromZoneId"]
            for route in props["routes"]:
                origin_sums[from_id] = origin_sums.get(from_id, 0.0) + route["trips"]
        for from_id, total in origin_sums.items():
            assert total == pytest.approx(1.0), f"Origin {from_id}: Σ route.trips = {total}"


# ---------------------------------------------------------------------------
# _restore_origin_productions
# ---------------------------------------------------------------------------


class TestRestoreOriginProductions:
    def test_restores_zero_origin_production_from_base(self):
        """A recomputed feature with originProduction=0 gets the base value."""
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0))
        base = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=500.0))
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"]["originProduction"] == pytest.approx(500.0)

    def test_does_not_overwrite_nonzero_origin_production(self):
        """A recomputed feature with originProduction > 0 is left unchanged."""
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=200.0)
        )
        base = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=999.0))
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"]["originProduction"] == pytest.approx(200.0)

    def test_no_match_in_base_leaves_feature_unchanged(self):
        """A key not present in base leaves originProduction at 0.0."""
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0))
        base = _routes_fc(_od_feature("Z9", "Z8", [_route(0.1, "A")], origin_production=777.0))
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"].get("originProduction", 0.0) == pytest.approx(
            0.0
        )

    def test_base_with_zero_production_not_restored(self):
        """If base feature also has originProduction=0.0, recomputed stays at 0.0."""
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0))
        base = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0))
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"].get("originProduction", 0.0) == pytest.approx(
            0.0
        )


# ---------------------------------------------------------------------------
# _evaporate_unroutable_pairs
# ---------------------------------------------------------------------------


class TestEvaporateUnroutablePairs:
    def test_pair_missing_from_recomputed_is_evaporated(self):
        """A pair sent to recompute but not present in the result is tombstoned."""
        base = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.4, "A", "B")], origin_production=1000.0)
        )
        pairs_to_recompute = [
            {
                "fromId": "Z1",
                "toId": "Z2",
                "fromType": "zone",
                "toType": "zone",
                "tripFraction": 0.4,
            }
        ]
        full_recomputed_fc = _routes_fc()  # recompute_routes_for_pairs found nothing

        evaporated = _evaporate_unroutable_pairs(pairs_to_recompute, full_recomputed_fc, base)

        assert len(evaporated) == 1
        assert evaporated[0]["properties"]["fromZoneId"] == "Z1"
        assert evaporated[0]["properties"]["toZoneId"] == "Z2"
        assert evaporated[0]["properties"]["routes"] == []
        # Other properties (e.g. originProduction) are preserved from the base feature.
        assert evaporated[0]["properties"]["originProduction"] == pytest.approx(1000.0)

    def test_pair_present_in_recomputed_is_not_evaporated(self):
        """A pair that was successfully re-routed must not be tombstoned."""
        base = _routes_fc(_od_feature("Z1", "Z2", [_route(0.4, "A", "B")]))
        pairs_to_recompute = [
            {
                "fromId": "Z1",
                "toId": "Z2",
                "fromType": "zone",
                "toType": "zone",
                "tripFraction": 0.4,
            }
        ]
        full_recomputed_fc = _routes_fc(_od_feature("Z1", "Z2", [_route(0.4, "C", "D")]))

        evaporated = _evaporate_unroutable_pairs(pairs_to_recompute, full_recomputed_fc, base)

        assert evaporated == []

    def test_pair_with_no_base_match_is_skipped(self):
        """A pair with no matching feature in the base ROUTES file yields nothing."""
        base = _routes_fc(_od_feature("Z9", "Z8", [_route(0.4, "A", "B")]))
        pairs_to_recompute = [
            {
                "fromId": "Z1",
                "toId": "Z2",
                "fromType": "zone",
                "toType": "zone",
                "tripFraction": 0.4,
            }
        ]
        full_recomputed_fc = _routes_fc()

        evaporated = _evaporate_unroutable_pairs(pairs_to_recompute, full_recomputed_fc, base)

        assert evaporated == []

    def test_multiple_pairs_mixed_outcome(self):
        """Only the pairs missing from the recomputed set are evaporated."""
        base = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.4, "A")]),
            _od_feature("Z3", "Z4", [_route(0.2, "B")]),
        )
        pairs_to_recompute = [
            {
                "fromId": "Z1",
                "toId": "Z2",
                "fromType": "zone",
                "toType": "zone",
                "tripFraction": 0.4,
            },
            {
                "fromId": "Z3",
                "toId": "Z4",
                "fromType": "zone",
                "toType": "zone",
                "tripFraction": 0.2,
            },
        ]
        full_recomputed_fc = _routes_fc(_od_feature("Z1", "Z2", [_route(0.4, "C")]))

        evaporated = _evaporate_unroutable_pairs(pairs_to_recompute, full_recomputed_fc, base)

        assert len(evaporated) == 1
        assert evaporated[0]["properties"]["fromZoneId"] == "Z3"
        assert evaporated[0]["properties"]["toZoneId"] == "Z4"


# ---------------------------------------------------------------------------
# _split_changes — OD entries
# ---------------------------------------------------------------------------


class TestSplitChangesOd:
    def test_od_entry_goes_to_od_bucket(self):
        changes = [{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5}]
        node, link, od, _flow, _explode = _split_changes(changes)
        assert od == changes
        assert node == []
        assert link == []

    def test_node_and_od_entries_split_correctly(self):
        node_entry = {"nodeId": "123", "production": "+100"}
        od_entry = {"fromZoneId": "Z1", "toZoneId": "Z2", "motifRatio": {"work": 1.0}}
        node, link, od, _flow, _explode = _split_changes([node_entry, od_entry])
        assert node == [node_entry]
        assert od == [od_entry]
        assert link == []

    def test_od_entry_without_tripfraction_or_motif_raises(self):
        with pytest.raises(ValueError, match="motifRatio"):
            _split_changes([{"fromZoneId": "Z1", "toZoneId": "Z2"}])

    def test_link_entry_not_confused_with_od(self):
        link_entry = {"linkId": "L1", "capacity": 0}
        _, link, od, _flow, _ = _split_changes([link_entry])
        assert link == [link_entry]
        assert od == []


# ---------------------------------------------------------------------------
# _split_changes — flow entries
# ---------------------------------------------------------------------------


class TestSplitChangesFlow:
    def test_flow_entry_with_link_id_goes_to_flow_bucket(self):
        entry = {"linkId": "L1", "flow": "+500"}
        node, link, _od, flow, _ = _split_changes([entry])
        assert flow == [entry]
        assert link == []
        assert node == []

    def test_flow_entry_with_from_to_node_goes_to_flow_bucket(self):
        entry = {"fromNode": "A", "toNode": "B", "flow": "2000"}
        _, link, _, flow, _ = _split_changes([entry])
        assert flow == [entry]
        assert link == []

    def test_flow_entry_not_confused_with_capacity_entry(self):
        cap_entry = {"linkId": "L1", "capacity": 1500}
        _, link, _, flow, _ = _split_changes([cap_entry])
        assert link == [cap_entry]
        assert flow == []

    def test_mixed_flow_and_capacity_entries_split_correctly(self):
        flow_entry = {"linkId": "L1", "flow": "+200"}
        cap_entry = {"linkId": "L2", "capacity": 1000}
        _, link, _, flow, _ = _split_changes([flow_entry, cap_entry])
        assert flow == [flow_entry]
        assert link == [cap_entry]

    def test_link_entry_without_capacity_speed_or_flow_raises(self):
        with pytest.raises(ValueError, match="'flow'"):
            _split_changes([{"linkId": "L1"}])


# ---------------------------------------------------------------------------
# _validate_od_adjustments
# ---------------------------------------------------------------------------


class TestValidateOdAdjustments:
    def test_valid_tripfraction_only(self):
        _validate_od_adjustments([{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5}])

    def test_valid_motif_only(self):
        _validate_od_adjustments(
            [
                {
                    "fromZoneId": "Z1",
                    "toZoneId": "Z2",
                    "motifRatio": {"work": 0.6, "shopping": 0.4},
                }
            ]
        )

    def test_valid_tripfraction_and_motif(self):
        _validate_od_adjustments(
            [
                {
                    "fromZoneId": "Z1",
                    "toZoneId": "Z2",
                    "tripFraction": 0.3,
                    "motifRatio": {"work": 1.0},
                }
            ]
        )

    def test_negative_tripfraction_raises(self):
        with pytest.raises(ValueError, match="tripFraction.*>= 0"):
            _validate_od_adjustments([{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": -1}])

    def test_motif_not_summing_to_one_raises(self):
        with pytest.raises(ValueError, match="sum to 1.0"):
            _validate_od_adjustments(
                [
                    {
                        "fromZoneId": "Z1",
                        "toZoneId": "Z2",
                        "motifRatio": {"work": 0.3, "shopping": 0.3},
                    }
                ]
            )

    def test_motif_sum_within_tolerance_ok(self):
        _validate_od_adjustments(
            [
                {
                    "fromZoneId": "Z1",
                    "toZoneId": "Z2",
                    "motifRatio": {"work": 0.995, "other": 0.005},
                }
            ]
        )

    def test_motif_negative_value_raises(self):
        with pytest.raises(ValueError, match=">= 0"):
            _validate_od_adjustments(
                [
                    {
                        "fromZoneId": "Z1",
                        "toZoneId": "Z2",
                        "motifRatio": {"work": 1.2, "other": -0.2},
                    }
                ]
            )

    def test_empty_from_zone_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            _validate_od_adjustments([{"fromZoneId": "", "toZoneId": "Z2", "tripFraction": 0.1}])


# ---------------------------------------------------------------------------
# _apply_od_adjustments  (legacy private function — old absolute-trips convention)
# ---------------------------------------------------------------------------


def _od_feature_with_motif(from_id, to_id, routes, *, origin_production=100.0, motif_ratio=None):
    props = {
        "fromZoneId": from_id,
        "toZoneId": to_id,
        "fromType": "zone",
        "toType": "zone",
        "tripFraction": sum(r.get("trips", 0) for r in routes),
        "originProduction": origin_production,
        "routes": routes,
    }
    if motif_ratio is not None:
        props["motifRatio"] = motif_ratio
    return {"type": "Feature", "geometry": None, "properties": props}


class TestApplyOdAdjustmentsLegacy:
    """Tests for the private _apply_od_adjustments (absolute-trips convention)."""

    def _base_routes(self):
        return _routes_fc(
            _od_feature_with_motif(
                "Z1",
                "Z2",
                [_route(0.7, "A", "B"), _route(0.3, "B", "C")],
                origin_production=200.0,
                motif_ratio={"work": 0.8, "other": 0.2},
            ),
            _od_feature_with_motif(
                "Z1",
                "Z3",
                [_route(1.0, "D", "E")],
                origin_production=80.0,
            ),
        )

    def test_trips_rescales_origin_production(self):
        result = _apply_od_adjustments(
            [{"origin": "Z1", "destination": "Z2", "trips": 50.0}],
            self._base_routes(),
        )
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(50.0)
        assert props["tripFraction"] == pytest.approx(1.0)

    def test_trips_preserves_relative_route_split(self):
        result = _apply_od_adjustments(
            [{"origin": "Z1", "destination": "Z2", "trips": 100.0}],
            self._base_routes(),
        )
        routes = result["features"][0]["properties"]["routes"]
        assert len(routes) == 2
        assert routes[0]["trips"] == pytest.approx(0.7, abs=1e-4)
        assert routes[1]["trips"] == pytest.approx(0.3, abs=1e-4)

    def test_trips_only_preserves_existing_motif_ratio(self):
        result = _apply_od_adjustments(
            [{"origin": "Z1", "destination": "Z2", "trips": 100.0}],
            self._base_routes(),
        )
        ratio = result["features"][0]["properties"].get("motifRatio")
        assert ratio == {"work": 0.8, "other": 0.2}

    def test_motif_ratio_only_leaves_volume_unchanged(self):
        result = _apply_od_adjustments(
            [{"origin": "Z1", "destination": "Z2", "motifRatio": {"shopping": 1.0}}],
            self._base_routes(),
        )
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(200.0)
        assert props["routes"][0]["trips"] == pytest.approx(0.7)
        assert props["routes"][1]["trips"] == pytest.approx(0.3)
        assert props["motifRatio"] == {"shopping": 1.0}

    def test_trips_and_motif_updates_both(self):
        result = _apply_od_adjustments(
            [
                {
                    "origin": "Z1",
                    "destination": "Z2",
                    "trips": 30.0,
                    "motifRatio": {"recreational": 0.5, "shopping": 0.5},
                }
            ],
            self._base_routes(),
        )
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(30.0)
        assert props["motifRatio"]["recreational"] == pytest.approx(0.5)
        assert props["motifRatio"]["shopping"] == pytest.approx(0.5)

    def test_nonexistent_pair_raises(self):
        with pytest.raises(ValueError, match="not found in the base ROUTES"):
            _apply_od_adjustments(
                [{"origin": "Z9", "destination": "Z8", "trips": 10}],
                self._base_routes(),
            )

    def test_multiple_entries_produce_multiple_features(self):
        result = _apply_od_adjustments(
            [
                {"origin": "Z1", "destination": "Z2", "trips": 50.0},
                {"origin": "Z1", "destination": "Z3", "trips": 20.0},
            ],
            self._base_routes(),
        )
        assert len(result["features"]) == 2
        prods = {
            f["properties"]["toZoneId"]: f["properties"]["originProduction"]
            for f in result["features"]
        }
        assert prods["Z2"] == pytest.approx(50.0)
        assert prods["Z3"] == pytest.approx(20.0)


# ---------------------------------------------------------------------------
# apply_od_adjustments  (public function — tripFraction convention)
# ---------------------------------------------------------------------------


class TestApplyOdAdjustments:
    """Tests for the public apply_od_adjustments (tripFraction convention)."""

    def _base_routes(self):
        # tripFraction = sum(route.trips) = 1.0 in fraction convention
        return _routes_fc(
            _od_feature_with_motif(
                "Z1",
                "Z2",
                [_route(0.7, "A", "B"), _route(0.3, "B", "C")],
                origin_production=200.0,
                motif_ratio={"work": 0.8, "other": 0.2},
            ),
            _od_feature_with_motif(
                "Z1",
                "Z3",
                [_route(1.0, "D", "E")],
                origin_production=80.0,
            ),
        )

    def test_tripfraction_scales_routes_proportionally(self):
        # old tripFraction = 1.0 (sum of route.trips), new = 0.5 → scale = 0.5
        result = apply_od_adjustments(
            self._base_routes(),
            [{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5}],
        )
        props = result["features"][0]["properties"]
        assert props["tripFraction"] == pytest.approx(0.5)
        assert props["originProduction"] == pytest.approx(200.0)  # preserved
        routes = props["routes"]
        assert routes[0]["trips"] == pytest.approx(0.35, abs=1e-4)
        assert routes[1]["trips"] == pytest.approx(0.15, abs=1e-4)

    def test_tripfraction_preserves_existing_motif_ratio(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5}],
        )
        ratio = result["features"][0]["properties"].get("motifRatio")
        assert ratio == {"work": 0.8, "other": 0.2}

    def test_motif_ratio_only_leaves_volume_unchanged(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [{"fromZoneId": "Z1", "toZoneId": "Z2", "motifRatio": {"shopping": 1.0}}],
        )
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(200.0)
        assert props["tripFraction"] == pytest.approx(1.0)
        assert props["routes"][0]["trips"] == pytest.approx(0.7)
        assert props["routes"][1]["trips"] == pytest.approx(0.3)
        assert props["motifRatio"] == {"shopping": 1.0}

    def test_tripfraction_and_motif_updates_both(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [
                {
                    "fromZoneId": "Z1",
                    "toZoneId": "Z2",
                    "tripFraction": 0.4,
                    "motifRatio": {"recreational": 0.5, "shopping": 0.5},
                }
            ],
        )
        props = result["features"][0]["properties"]
        assert props["tripFraction"] == pytest.approx(0.4)
        assert props["originProduction"] == pytest.approx(200.0)
        assert props["motifRatio"]["recreational"] == pytest.approx(0.5)

    def test_nonexistent_pair_raises(self):
        with pytest.raises(ValueError, match="not found in the base ROUTES"):
            apply_od_adjustments(
                self._base_routes(),
                [{"fromZoneId": "Z9", "toZoneId": "Z8", "tripFraction": 0.1}],
            )

    def test_multiple_entries_produce_multiple_features(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [
                {"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5},
                {"fromZoneId": "Z1", "toZoneId": "Z3", "tripFraction": 0.2},
            ],
        )
        assert len(result["features"]) == 2
        fracs = {
            f["properties"]["toZoneId"]: f["properties"]["tripFraction"] for f in result["features"]
        }
        assert fracs["Z2"] == pytest.approx(0.5)
        assert fracs["Z3"] == pytest.approx(0.2)

    def test_zero_tripfraction_zeroes_routes(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.0}],
        )
        props = result["features"][0]["properties"]
        assert props["tripFraction"] == pytest.approx(0.0)
        # routes scaled by 0
        for r in props["routes"]:
            assert r["trips"] == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# _compute_link_flow_delta — OD adjustment path (extra_od_fcs)
# ---------------------------------------------------------------------------


class TestComputeLinkFlowDeltaOdAdjust:
    def test_od_adjust_increases_link_flow(self):
        zones = _zones_fc(_zone("Z1", 0.0), _zone("Z2", 0.0))
        base_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A", "B")], origin_production=100.0)
        )
        od_adjust_fc = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A", "B")], origin_production=200.0)
        )
        delta = _compute_link_flow_delta(
            base_routes, _routes_fc(), _routes_fc(), zones, od_adjust_fc
        )
        assert delta["A"] == pytest.approx((100.0, 200.0))
        assert delta["B"] == pytest.approx((100.0, 200.0))

    def test_od_adjust_motif_only_produces_zero_delta(self):
        zones = _zones_fc(_zone("Z1", 0.0), _zone("Z2", 0.0))
        base_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A")], origin_production=100.0)
        )
        od_adjust_fc = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A")], origin_production=100.0)
        )
        delta = _compute_link_flow_delta(
            base_routes, _routes_fc(), _routes_fc(), zones, od_adjust_fc
        )
        if "A" in delta:
            fb, fa = delta["A"]
            assert fa - fb == pytest.approx(0.0, abs=1e-6)

    def test_od_adjust_zero_trips_removes_flow(self):
        zones = _zones_fc(_zone("Z1", 0.0), _zone("Z2", 0.0))
        base_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A", "B")], origin_production=150.0)
        )
        od_adjust_fc = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A", "B")], origin_production=0.0)
        )
        delta = _compute_link_flow_delta(
            base_routes, _routes_fc(), _routes_fc(), zones, od_adjust_fc
        )
        assert delta["A"] == pytest.approx((150.0, 0.0))


# ---------------------------------------------------------------------------
# _find_pairs_using_links — orphan link detection
# ---------------------------------------------------------------------------


class TestFindPairsUsingLinks:
    """_find_pairs_using_links underlies the orphan-link re-routing in step [3d/7]."""

    def _routes(self, *features):
        return {"type": "FeatureCollection", "features": list(features)}

    def _pair(self, from_id, to_id, *link_ids):
        return {
            "type": "Feature",
            "geometry": None,
            "properties": {
                "fromZoneId": from_id,
                "toZoneId": to_id,
                "fromType": "zone",
                "toType": "zone",
                "tripFraction": 0.5,
                "originProduction": 100.0,
                "routes": [{"trips": 0.5, "linkPath": list(link_ids)}],
            },
        }

    def test_finds_pair_using_orphan_link(self):
        routes_fc = self._routes(self._pair("Z1", "Z2", "old_link_1", "old_link_2"))
        result = _find_pairs_using_links(routes_fc, {"old_link_1"})
        assert len(result) == 1
        assert result[0]["fromId"] == "Z1"
        assert result[0]["toId"] == "Z2"

    def test_ignores_pair_not_using_orphan_link(self):
        routes_fc = self._routes(self._pair("Z1", "Z2", "live_link_A", "live_link_B"))
        result = _find_pairs_using_links(routes_fc, {"old_link_1"})
        assert result == []

    def test_finds_pair_when_only_one_route_uses_orphan(self):
        pair = {
            "type": "Feature",
            "geometry": None,
            "properties": {
                "fromZoneId": "Z1",
                "toZoneId": "Z2",
                "fromType": "zone",
                "toType": "zone",
                "tripFraction": 0.5,
                "originProduction": 100.0,
                "routes": [
                    {"trips": 0.3, "linkPath": ["old_link_1"]},
                    {"trips": 0.2, "linkPath": ["live_link_B"]},
                ],
            },
        }
        result = _find_pairs_using_links(self._routes(pair), {"old_link_1"})
        assert len(result) == 1

    def test_multiple_pairs_only_affected_returned(self):
        routes_fc = self._routes(
            self._pair("Z1", "Z2", "old_link_1"),
            self._pair("Z2", "Z3", "live_link_A"),
            self._pair("Z3", "Z4", "old_link_1", "live_link_B"),
        )
        result = _find_pairs_using_links(routes_fc, {"old_link_1"})
        assert len(result) == 2
        ids = {(r["fromId"], r["toId"]) for r in result}
        assert ("Z1", "Z2") in ids
        assert ("Z3", "Z4") in ids

    def test_empty_orphan_set_returns_nothing(self):
        routes_fc = self._routes(self._pair("Z1", "Z2", "link_X"))
        assert _find_pairs_using_links(routes_fc, set()) == []

    def test_empty_routes_fc_returns_nothing(self):
        assert (
            _find_pairs_using_links({"type": "FeatureCollection", "features": []}, {"old_link"})
            == []
        )


# ---------------------------------------------------------------------------
# _split_changes — zone-explode entries
# ---------------------------------------------------------------------------


class TestSplitChangesZoneExplode:
    def test_explode_entry_goes_to_explode_bucket(self):
        entry = {"zoneId": "Z1", "explodeInto": 3}
        node, link, _od, _flow, explode = _split_changes([entry])
        assert explode == [entry]
        assert node == []
        assert link == []

    def test_explode_entry_not_confused_with_node_adjustment(self):
        node_entry = {"zoneId": "Z1", "production": "+100"}
        explode_entry = {"zoneId": "Z2", "explodeInto": 2}
        node, _link, _od, _flow, explode = _split_changes([node_entry, explode_entry])
        assert node == [node_entry]
        assert explode == [explode_entry]

    def test_explode_entry_without_zone_id_raises(self):
        with pytest.raises(ValueError, match="zoneId"):
            _split_changes([{"explodeInto": 2}])

    def test_explode_entry_with_non_integer_count_raises(self):
        with pytest.raises(ValueError, match="explodeInto"):
            _split_changes([{"zoneId": "Z1", "explodeInto": "lots"}])

    def test_explode_entry_with_count_below_two_raises(self):
        with pytest.raises(ValueError, match="explodeInto"):
            _split_changes([{"zoneId": "Z1", "explodeInto": 1}])

    def test_explode_entry_accepts_numeric_string_count(self):
        _node, _link, _od, _flow, explode = _split_changes([{"zoneId": "Z1", "explodeInto": "4"}])
        assert explode == [{"zoneId": "Z1", "explodeInto": "4"}]


# ---------------------------------------------------------------------------
# _explode_ring_n_way / apply_zone_explosions
# ---------------------------------------------------------------------------


def _square_ring(x0, y0, x1, y1):
    """Closed rectangular ring from (x0, y0) to (x1, y1)."""
    return [[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]]


_road_ids = itertools.count(1)


def _road(*coords, from_node=None, to_node=None, link_id=None, length=100.0):
    idx = next(_road_ids)
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [list(c) for c in coords]},
        "properties": {
            "linkId": link_id or f"L{idx}",
            "fromNode": from_node or f"N{idx}a",
            "toNode": to_node or f"N{idx}b",
            "length": length,
        },
    }


def _feedlink(zone_id, from_node, to_node, **extra):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [0.0, 0.0]]},
        "properties": {"zoneId": zone_id, "fromNode": from_node, "toNode": to_node, **extra},
    }


def _zone_feature(zone_id, ring, *, zone_class="STUDY", production=1000.0, attraction=400.0):
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {
            "zoneId": zone_id,
            "zoneClass": zone_class,
            "production": production,
            "attraction": attraction,
            "inwoners": 500.0,
            "centroidLon": None,
            "centroidLat": None,
            "fromNodeProportions": {"n1": 1.0},
            "toNodeProportions": {"n1": 1.0},
            "gid": 42.0,
        },
    }


class TestExplodeRingNWay:
    def test_two_way_split_with_single_crossing_road(self):
        ring = _square_ring(0, 0, 10, 10)
        # Vertical road crossing the full height of the square, extended well
        # beyond it so the chord-cut always finds two boundary crossings.
        road = [[5, -5], [5, 15]]
        pieces = _explode_ring_n_way(ring, [road], 2)
        assert pieces is not None
        assert len(pieces) == 2
        for piece in pieces:
            assert piece[0] == piece[-1]  # closed ring
            assert len(piece) >= 4

    def test_no_candidate_roads_returns_none(self):
        ring = _square_ring(0, 0, 10, 10)
        assert _explode_ring_n_way(ring, [], 2) is None

    def test_three_way_split_with_two_distinct_roads(self):
        ring = _square_ring(0, 0, 10, 10)
        road_a = [[3, -5], [3, 15]]  # splits off a left strip (x < 3)
        road_b = [[5, 5], [8, 5]]  # fully inside the right piece (x in 3..10)
        pieces = _explode_ring_n_way(ring, [road_a, road_b], 3)
        assert pieces is not None
        assert len(pieces) == 3

    def test_insufficient_roads_returns_fewer_pieces_than_requested(self):
        ring = _square_ring(0, 0, 10, 10)
        road = [[5, -5], [5, 15]]
        # Only one usable split line — cannot reach 3 pieces.
        pieces = _explode_ring_n_way(ring, [road], 3)
        assert pieces is not None
        assert len(pieces) == 2


class TestScaleZoneProperties:
    def test_scales_numeric_fields_and_resets_identity_fields(self):
        props = {
            "zoneId": "PARENT",
            "zoneClass": "STUDY",
            "production": 1000.0,
            "attraction": 400.0,
            "inwoners": 500.0,
            "centroidLon": 5.0,
            "centroidLat": 52.0,
            "fromNodeProportions": {"n1": 1.0},
            "toNodeProportions": {"n1": 1.0},
            "gid": 7.0,
        }
        out = _scale_zone_properties(props, 0.25, "CHILD-1", "PARENT")
        assert out["zoneId"] == "CHILD-1"
        assert out["parentZoneId"] == "PARENT"
        assert out["zoneClass"] == "STUDY"  # non-scaled, copied as-is
        assert out["production"] == pytest.approx(250.0)
        assert out["attraction"] == pytest.approx(100.0)
        assert out["inwoners"] == pytest.approx(125.0)
        assert out["fromNodeProportions"] == {}
        assert out["toNodeProportions"] == {}
        assert out["gid"] is None
        assert out["centroidLon"] == 5.0  # caller overwrites after split


class TestApplyZoneExplosions:
    def test_splits_zone_and_preserves_total_production(self):
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring, production=1000.0, attraction=400.0)
        other_zone = _zone_feature("Z2", _square_ring(20, 0, 30, 10))
        zones_fc = {"type": "FeatureCollection", "features": [zone, other_zone]}
        network_fc = {
            "type": "FeatureCollection",
            "features": [_road([5, -5], [5, 15])],
        }

        feedlinks_fc = {"type": "FeatureCollection", "features": []}
        zones_out, _feedlinks_out, node_adjustments = apply_zone_explosions(
            zones_fc, network_fc, [{"zoneId": "Z1", "explodeInto": 2}], feedlinks_fc, "CAR"
        )

        out_features = zones_out["features"]
        # Original zone Z1 removed, Z2 untouched, 2 new sub-zones added.
        zone_ids = [f["properties"]["zoneId"] for f in out_features]
        assert "Z1" not in zone_ids
        assert "Z2" in zone_ids
        assert len(zone_ids) == 3

        children = [f for f in out_features if f["properties"].get("parentZoneId") == "Z1"]
        assert len(children) == 2
        total_production = sum(f["properties"]["production"] for f in children)
        total_attraction = sum(f["properties"]["attraction"] for f in children)
        assert total_production == pytest.approx(1000.0)
        assert total_attraction == pytest.approx(400.0)
        for child in children:
            assert child["properties"]["zoneId"] != "Z1"
            assert child["geometry"]["type"] == "Polygon"

        # node_adjustments: one absolute production+attraction entry per child,
        # plus one zero/zero tombstone for the exploded parent zone.
        assert len(node_adjustments) == 3
        tombstone = next(e for e in node_adjustments if e["zoneId"] == "Z1")
        assert tombstone == {"zoneId": "Z1", "production": "0", "attraction": "0"}
        child_entries = [e for e in node_adjustments if e["zoneId"] != "Z1"]
        assert len(child_entries) == 2
        assert sum(float(e["production"]) for e in child_entries) == pytest.approx(1000.0)

    def test_boundary_zone_cannot_be_exploded(self):
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("B1", ring, zone_class="BOUNDARY")
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        network_fc = {"type": "FeatureCollection", "features": [_road([5, -5], [5, 15])]}

        empty_fl = {"type": "FeatureCollection", "features": []}
        with pytest.raises(ValueError, match="BOUNDARY"):
            apply_zone_explosions(
                zones_fc, network_fc, [{"zoneId": "B1", "explodeInto": 2}], empty_fl, "CAR"
            )

    def test_unknown_zone_id_raises(self):
        zones_fc = {"type": "FeatureCollection", "features": []}
        network_fc = {"type": "FeatureCollection", "features": []}
        empty_fl = {"type": "FeatureCollection", "features": []}
        with pytest.raises(ValueError, match="not found"):
            apply_zone_explosions(
                zones_fc, network_fc, [{"zoneId": "GHOST", "explodeInto": 2}], empty_fl, "CAR"
            )

    def test_too_few_roads_falls_back_to_straight_cuts(self):
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring)
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        # Only one road (two blocks), but 3 sub-zones were requested.
        network_fc = {"type": "FeatureCollection", "features": [_road([5, -5], [5, 15])]}
        empty_fl = {"type": "FeatureCollection", "features": []}

        zones_out, _, _ = apply_zone_explosions(
            zones_fc, network_fc, [{"zoneId": "Z1", "explodeInto": 3}], empty_fl, "CAR"
        )
        children = [f for f in zones_out["features"] if f["properties"].get("parentZoneId") == "Z1"]
        assert len(children) == 3
        assert sum(f["properties"]["production"] for f in children) == 1000

    def test_invalid_geometry_raises(self):
        zone = _zone_feature("Z1", _square_ring(0, 0, 10, 10))
        zone["geometry"] = {"type": "Point", "coordinates": [0, 0]}
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        network_fc = {"type": "FeatureCollection", "features": []}
        empty_fl = {"type": "FeatureCollection", "features": []}

        with pytest.raises(ValueError, match="no valid polygon geometry"):
            apply_zone_explosions(
                zones_fc, network_fc, [{"zoneId": "Z1", "explodeInto": 2}], empty_fl, "CAR"
            )

    def test_ids_names_and_whole_numbers(self):
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring, production=1000.4, attraction=401.0)
        zone["properties"]["zoneName"] = "Centrum"
        zone["properties"]["huishoudens"] = 7
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        network_fc = {
            "type": "FeatureCollection",
            "features": [_road([3.3, -5], [3.3, 15]), _road([6.6, -5], [6.6, 15])],
        }
        empty_fl = {"type": "FeatureCollection", "features": []}

        zones_out, _, node_adjustments = apply_zone_explosions(
            zones_fc, network_fc, [{"zoneId": "Z1", "explodeInto": 3}], empty_fl, "CAR"
        )
        children = [f for f in zones_out["features"] if f["properties"].get("parentZoneId") == "Z1"]
        props = sorted((c["properties"] for c in children), key=lambda p: p["zoneId"])
        assert [p["zoneId"] for p in props] == ["Z1-1", "Z1-2", "Z1-3"]
        assert sorted(p["zoneName"] for p in props) == ["Centrum (1)", "Centrum (2)", "Centrum (3)"]
        for p in props:
            assert isinstance(p["production"], int)
            assert isinstance(p["attraction"], int)
            assert isinstance(p["huishoudens"], int)
            assert isinstance(p["inwoners"], float)  # float props keep plain scaling
        assert sum(p["production"] for p in props) == 1000
        assert sum(p["attraction"] for p in props) == 401
        assert sum(p["huishoudens"] for p in props) == 7
        child_entries = [e for e in node_adjustments if e["zoneId"] != "Z1"]
        assert all(e["production"].isdigit() for e in child_entries)


def _building(lon, lat, floor_fraction=None):
    props = {} if floor_fraction is None else {"floorFraction": floor_fraction}
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": props,
    }


class TestApplyZoneExplosionsWithBuildings:
    """apply_zone_explosions(..., buildings_fc=...) — building-m²-weighted split."""

    def test_weights_by_building_sqm_instead_of_road_length(self):
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring, production=1000.0, attraction=400.0)
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        network_fc = {"type": "FeatureCollection", "features": [_road([5, -5], [5, 15])]}
        # Three buildings concentrated on the left half (x < 5), one on the right.
        buildings_fc = {
            "type": "FeatureCollection",
            "features": [_building(1, 1), _building(2, 2), _building(3, 3), _building(9, 9)],
        }

        empty_fl = {"type": "FeatureCollection", "features": []}
        zones_out, _feedlinks_out, node_adjustments = apply_zone_explosions(
            zones_fc,
            network_fc,
            [{"zoneId": "Z1", "explodeInto": 2}],
            empty_fl,
            "CAR",
            buildings_fc,
        )

        children = [f for f in zones_out["features"] if f["properties"].get("parentZoneId") == "Z1"]
        assert len(children) == 2
        # Total production/attraction must still be fully preserved.
        assert sum(f["properties"]["production"] for f in children) == pytest.approx(1000.0)
        assert sum(f["properties"]["attraction"] for f in children) == pytest.approx(400.0)
        # The piece with 3 buildings (75% of the 4 default-footprint buildings)
        # must get a proportionally larger production share than a 50/50 split.
        productions = sorted(f["properties"]["production"] for f in children)
        assert productions[-1] == pytest.approx(750.0)
        assert productions[0] == pytest.approx(250.0)
        assert len(node_adjustments) == 3  # 2 children + 1 tombstone

    def test_buildings_fc_none_falls_back_to_road_length(self):
        """Regression guard: omitting buildings_fc preserves the original behavior."""
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring, production=1000.0, attraction=400.0)
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        network_fc = {"type": "FeatureCollection", "features": [_road([5, -5], [5, 15])]}

        empty_fl = {"type": "FeatureCollection", "features": []}
        zones_out, _, _ = apply_zone_explosions(
            zones_fc, network_fc, [{"zoneId": "Z1", "explodeInto": 2}], empty_fl, "CAR"
        )
        children = [f for f in zones_out["features"] if f["properties"].get("parentZoneId") == "Z1"]
        # A symmetric road split with no buildings data falls back to an even,
        # road-length-based 50/50 split.
        productions = sorted(f["properties"]["production"] for f in children)
        assert productions == pytest.approx([500.0, 500.0])

    def test_zone_with_no_buildings_inside_still_splits_evenly(self):
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring, production=1000.0, attraction=400.0)
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        network_fc = {"type": "FeatureCollection", "features": [_road([5, -5], [5, 15])]}
        empty_buildings_fc = {"type": "FeatureCollection", "features": []}

        empty_fl = {"type": "FeatureCollection", "features": []}
        zones_out, _, _ = apply_zone_explosions(
            zones_fc,
            network_fc,
            [{"zoneId": "Z1", "explodeInto": 2}],
            empty_fl,
            "CAR",
            empty_buildings_fc,
        )
        children = [f for f in zones_out["features"] if f["properties"].get("parentZoneId") == "Z1"]
        productions = sorted(f["properties"]["production"] for f in children)
        assert productions == pytest.approx([500.0, 500.0])

    def test_too_few_roads_with_buildings_fc_still_splits(self):
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring)
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        network_fc = {"type": "FeatureCollection", "features": [_road([5, -5], [5, 15])]}
        buildings_fc = {"type": "FeatureCollection", "features": [_building(1, 1)]}
        empty_fl = {"type": "FeatureCollection", "features": []}

        zones_out, _, _ = apply_zone_explosions(
            zones_fc,
            network_fc,
            [{"zoneId": "Z1", "explodeInto": 3}],
            empty_fl,
            "CAR",
            buildings_fc,
        )
        children = [f for f in zones_out["features"] if f["properties"].get("parentZoneId") == "Z1"]
        assert len(children) == 3


class TestApplyZoneExplosionsFeedlinks:
    """apply_zone_explosions(..., feedlinks_fc, mode) — feedlink add/cleanup."""

    def _network(self):
        # Main cut line (x=5, crosses the whole square so the chord-cut can
        # find two boundary crossings), plus one connector road per resulting
        # half: one endpoint strictly inside that half, the other strictly
        # outside — a single clean boundary crossing, which is what actually
        # produces a non-degenerate boundary node (both a feedlink AND a
        # populated node-proportion entry; a road crossing a ring's boundary
        # *twice*, like the cut line itself, clips to a fromNode==toNode
        # self-loop that contributes a feedlink but no proportions).
        return {
            "type": "FeatureCollection",
            "features": [
                _road([5, -5], [5, 15]),  # the split chord itself
                _road([2, 5], [2, -5]),  # left (x<5) piece -> outside
                _road([8, 5], [8, 15]),  # right (x>5) piece -> outside
            ],
        }

    def test_new_sub_zones_get_feedlinks_and_proportions(self):
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring, production=1000.0, attraction=400.0)
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        network = self._network()
        left_node = network["features"][1]["properties"]["fromNode"]  # at (2, 5)
        right_node = network["features"][2]["properties"]["fromNode"]  # at (8, 5)
        # Parent feedlinks attached to real network nodes, zone end = str(gid).
        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": [
                _feedlink("Z1", "42", left_node, feedlinkId=1, capacity=1000.0),
                _feedlink("Z1", right_node, "42", feedlinkId=2, capacity=400.0),
            ],
        }

        zones_out, feedlinks_out, _ = apply_zone_explosions(
            zones_fc, network, [{"zoneId": "Z1", "explodeInto": 2}], feedlinks_fc, "CAR"
        )

        children = [f for f in zones_out["features"] if f["properties"].get("parentZoneId") == "Z1"]
        assert len(children) == 2
        by_id = {c["properties"]["zoneId"]: c["properties"] for c in children}
        node_ids = {
            str(f["properties"][k]) for f in network["features"] for k in ("fromNode", "toNode")
        }
        fls = [f["properties"] for f in feedlinks_out["features"]]

        # The original zone's feedlinks are gone.
        assert all(f["zoneId"] != "Z1" for f in fls)
        # Unique feedlink ids.
        assert len({f["feedlinkId"] for f in fls}) == len(fls)
        for cid, cprops in by_id.items():
            own = [f for f in fls if f["zoneId"] == cid]
            prod = [f for f in own if f["fromNode"] == cid and f["toNode"] in node_ids]
            attr = [f for f in own if f["toNode"] == cid and f["fromNode"] in node_ids]
            # Each sub-zone is attached to real network nodes in both directions.
            assert prod
            assert attr
            assert len(prod) + len(attr) == len(own)
            assert sum(f["capacity"] for f in prod) == pytest.approx(cprops["production"])
            assert sum(f["capacity"] for f in attr) == pytest.approx(cprops["attraction"])

        # The parent's feedlinks moved to the sub-zone containing their node.
        left = next(cid for cid, p in by_id.items() if p["centroidLon"] < 5)
        right = next(cid for cid, p in by_id.items() if p["centroidLon"] > 5)
        assert any(f["zoneId"] == left and f["toNode"] == left_node for f in fls)
        assert any(f["zoneId"] == right and f["fromNode"] == right_node for f in fls)

        # Proportions are recomputed, not left as the stale {} placeholder.
        for child in children:
            props = child["properties"]
            assert props["fromNodeProportions"] != {} or props["toNodeProportions"] != {}

    def test_sibling_zone_is_untouched(self):
        """Regression guard: exploding a zone must not
        read or modify any zone other than the ones being exploded."""
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring, production=1000.0, attraction=400.0)
        sibling = _zone_feature("SIB", _square_ring(20, 0, 30, 10))
        sibling["properties"]["fromNodeProportions"] = {"keep": 1.0}
        sibling["properties"]["toNodeProportions"] = {"keep": 1.0}
        zones_fc = {"type": "FeatureCollection", "features": [zone, sibling]}

        sibling_fl = _feedlink("SIB", "s1", "s2")
        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": [_feedlink("Z1", "n1", "n2"), sibling_fl],
        }

        zones_out, feedlinks_out, _ = apply_zone_explosions(
            zones_fc, self._network(), [{"zoneId": "Z1", "explodeInto": 2}], feedlinks_fc, "CAR"
        )

        sibling_out = next(f for f in zones_out["features"] if f["properties"]["zoneId"] == "SIB")
        assert sibling_out == sibling

        sibling_feedlinks_out = [
            f for f in feedlinks_out["features"] if f["properties"].get("zoneId") == "SIB"
        ]
        assert sibling_feedlinks_out == [sibling_fl]

    def test_build_feedlinks_fallback_without_parent_feedlinks(self):
        """Sub-zones that inherit no parent feedlink get build_feedlinks's
        offline centroid fallback, attached to real network nodes, using a
        synthetic gid that is never written back onto the zone."""
        ring = _square_ring(0, 0, 10, 10)
        zone = _zone_feature("Z1", ring, production=1000.0, attraction=400.0)
        zones_fc = {"type": "FeatureCollection", "features": [zone]}
        network = self._network()
        empty_fl = {"type": "FeatureCollection", "features": []}

        zones_out, feedlinks_out, _ = apply_zone_explosions(
            zones_fc, network, [{"zoneId": "Z1", "explodeInto": 2}], empty_fl, "CAR"
        )

        children = [f for f in zones_out["features"] if f["properties"].get("parentZoneId") == "Z1"]
        node_ids = {
            str(f["properties"][k]) for f in network["features"] for k in ("fromNode", "toNode")
        }
        fls = [f["properties"] for f in feedlinks_out["features"]]
        assert len(children) == 2
        for child in children:
            cid = child["properties"]["zoneId"]
            assert child["properties"]["gid"] is None
            assert any(f["fromNode"] == cid and f["toNode"] in node_ids for f in fls)
            assert any(f["toNode"] == cid and f["fromNode"] in node_ids for f in fls)
