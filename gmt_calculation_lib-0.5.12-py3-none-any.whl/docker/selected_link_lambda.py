"""SelectedLink Lambda handler — thin I/O wrapper around selected_link_core.

Reads a routes GeoJSON and a network GeoJSON, filters to all routes that pass
through a given link, and returns the result.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "routesUri":  "s3://bucket/key or local path",  // required
        "networkUri": "s3://bucket/key or local path",  // required
        "linkId":     "12345",                          // required
        "outputUri":  "s3://bucket/key or local path"   // optional (inline if omitted)
    }
}

Response (200)
--------------
When outputUri is provided:
    { "statusCode": 200, "status": "successful", "outputUri": "...", "routes": int }
When outputUri is omitted, the FeatureCollection is returned inline.
"""

from __future__ import annotations

import json
import logging
import os
import traceback
from typing import cast

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return cast(bytes, get_bytes_s3(bucket, key))
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from gmt_routing.selected_link.core.selected_link_core import (
            compute_selected_link,
        )
        from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

        inputs: dict = event.get("inputs", {})

        routes_uri: str = inputs.get("routesUri", "")
        network_uri: str = inputs.get("networkUri", "")
        link_id: str = inputs.get("linkId", "")
        if not routes_uri:
            raise ValueError("inputs.routesUri is required.")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not link_id:
            raise ValueError("inputs.linkId is required.")
        output_uri: str = inputs.get("outputUri", "")

        logger.info("Reading routes   : %s", routes_uri)
        routes_fc = from_geoparquet(_read_uri(routes_uri))

        logger.info("Reading network  : %s", network_uri)
        network_fc = from_geoparquet(_read_uri(network_uri))

        result_fc = compute_selected_link(routes_fc, network_fc, link_id)

        n_routes = len(result_fc.get("features", []))

        if output_uri:
            logger.info("Writing output   : %s", output_uri)
            _write_uri(output_uri, to_geoparquet(result_fc))
            logger.info("Invocation complete [request_id=%s]", request_id)
            return {
                "statusCode": 200,
                "status": "successful",
                "outputUri": output_uri,
                "routes": n_routes,
            }

        # Inline response
        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "routes": n_routes,
            **result_fc,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id,
            exc,
            traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
