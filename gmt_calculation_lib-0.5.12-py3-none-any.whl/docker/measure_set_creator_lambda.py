"""MeasureSetCreator handler — thin I/O wrapper around measure_set_creator_core.

Reads a network file (GeoParquet/GeoJSON) and a single layer of an uploaded
GeoPackage, then returns one "maatregelset" (measure set) per polygon feature
in that layer: a named list of `adjust`-compatible link-closure changes
(``{"linkId": ..., "capacity": "0"}``) for every network link fully covered by
that polygon.  The result is always returned inline — this module never
writes to an output URI.

Environment variables
---------------------
LOG_LEVEL  - DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "networkUri":    "s3://bucket/key or local path",  // required
        "geopackageUri": "s3://bucket/key or local path",  // required
        "layerName":     "Afsluitingen 2027",               // required
        "fieldName":     "naam"                             // required
    }
}

Response (200)
--------------
{
    "statusCode": 200,
    "status": "successful",
    "measureSets": [
        {"name": "Afsluitingen 2027, Hoofdstraat", "changes": [{"linkId": 123, "capacity": "0"}]},
        ...
    ]
}
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import traceback
from typing import cast

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return cast(bytes, get_bytes_s3(bucket, key))
    with open(uri, "rb") as fh:
        return fh.read()


def _read_network_fc(uri: str) -> dict:
    from gmt_shared.geoparquet import from_geoparquet

    raw = _read_uri(uri)
    if uri.endswith(".parquet"):
        return cast(dict, from_geoparquet(raw))
    return cast(dict, json.loads(raw))


def _read_geopackage_layer(uri: str, layer_name: str) -> list[dict]:
    import geopandas as gpd

    raw = _read_uri(uri)
    with tempfile.NamedTemporaryFile(suffix=".gpkg", delete=False) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name

    try:
        gdf = gpd.read_file(tmp_path, layer=layer_name)
        if gdf.crs is not None and str(gdf.crs).upper() not in ("EPSG:4326", "WGS84"):
            gdf = gdf.to_crs(4326)
        return list(gdf.__geo_interface__["features"])
    finally:
        os.unlink(tmp_path)


def handler(event: dict, context: object) -> dict:
    """Handler entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from measure_set_creator.core.measure_set_creator_core import (
            create_measure_sets,
        )

        inputs: dict = event.get("inputs", {})

        network_uri: str = inputs.get("networkUri", "")
        geopackage_uri: str = inputs.get("geopackageUri", "")
        layer_name: str = inputs.get("layerName", "")
        field_name: str = inputs.get("fieldName", "")

        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not geopackage_uri:
            raise ValueError("inputs.geopackageUri is required.")
        if not layer_name:
            raise ValueError("inputs.layerName is required.")
        if not field_name:
            raise ValueError("inputs.fieldName is required.")

        logger.info("Reading network     : %s", network_uri)
        network_fc = _read_network_fc(network_uri)

        logger.info("Reading geopackage  : %s (layer=%s)", geopackage_uri, layer_name)
        layer_features = _read_geopackage_layer(geopackage_uri, layer_name)

        measure_sets = create_measure_sets(network_fc, layer_features, layer_name, field_name)

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "measureSets": measure_sets,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id,
            exc,
            traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
