"""GeoJsonFilter Lambda handler — thin I/O wrapper around geojson_filter_core.

Reads a GeoJSON FeatureCollection, filters features by an expression, and writes
the result.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "networkUri": "s3://bucket/key or local path",  // required
        "expr":       "speed > 50",                     // required
        "outputUri":  "s3://bucket/key or local path"   // optional (default: overwrite)
    }
}

Response (200)
--------------
{
    "statusCode":      200,
    "status":          "successful",
    "outputUri":       "...",
    "inputFeatures":   int,
    "outputFeatures":  int,
    "removedFeatures": int
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback
from typing import cast

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return cast(bytes, get_bytes_s3(bucket, key))
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from gmt_shared.geoparquet import from_geoparquet, to_geoparquet
        from gmt_utils.geojson_filter.core.geojson_filter_core import filter_geojson

        inputs: dict = event.get("inputs", {})

        network_uri: str = inputs.get("networkUri", "")
        expr: str = inputs.get("expr", "")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not expr:
            raise ValueError("inputs.expr is required.")
        output_uri: str = inputs.get("outputUri", "") or network_uri

        logger.info("Reading network : %s", network_uri)
        network_fc = from_geoparquet(_read_uri(network_uri))

        result_fc, stats = filter_geojson(network_fc, expr)

        logger.info("Writing output  : %s", output_uri)
        _write_uri(output_uri, to_geoparquet(result_fc))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "outputUri": output_uri,
            **stats,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id,
            exc,
            traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
