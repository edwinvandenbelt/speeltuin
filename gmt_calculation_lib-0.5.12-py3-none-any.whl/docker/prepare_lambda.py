"""Prepare Lambda handler — thin I/O wrapper around prepare_core.

Runs the full GMT preparation pipeline (zone_fetcher → network_fetcher →
simplifier → cleaner → feedlink_fetcher → fuser → splitter →
parallel_link_finder → zone_joiner → matrix_builder) for a bounding box and
one or more transport modes, then uploads the resulting GeoParquet files to an
S3 prefix, a local folder, or any URI scheme supported by shared.uri.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)
DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID, DATABRICKS_CLIENT_ID,
DATABRICKS_CLIENT_SECRET — Databricks credentials.

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "minLon":        float,         // required — western bbox boundary
        "minLat":        float,         // required — southern bbox boundary
        "maxLon":        float,         // required — eastern bbox boundary
        "maxLat":        float,         // required — northern bbox boundary
        "outputFolder":  "s3://b/pfx",  // required — destination URI/path
        "modes":         ["CAR"],       // optional (default: ["CAR"])
        "name":          "area",        // optional (default: "area")
        "catalog":       "spectrum",    // optional
        "schema":        "2023_01",     // optional
        "refresh":       false,         // optional — re-run even if outputs exist
        "debug":         false,         // optional — write step-snapshot files
        "excludeZones":  ["Z001"],      // optional — zone IDs to exclude
        "maxRoutes":     2,             // optional — k-shortest routes
        "nvpTable":      null,          // optional — Databricks NVP table
        "nvpYear":       null,          // optional — NVP location_year filter
        "areaId":        null,          // optional — pin area UUID
        "modeLabel":     null,          // optional — output filename label
        "annotateTrafficSignals": false, // optional — default false (extra enrichment)
        "fetchTrafficSigns":      false, // optional — default false (extra enrichment)
        "fetchBgtAssets":         false, // optional — default false (extra enrichment)
        "fetchOsmAssets":         false, // optional — default false (extra enrichment)
        "fetchParkingAreas":      false, // optional — default false (extra enrichment)
        "fetchBuildings":         true,  // optional — default true (always linked to the network)
        "fetchVegetation":        false, // optional — default false (extra enrichment)
        "addElevation":           false, // optional — default false (extra enrichment)
        "ndwDataUri":    null           // optional — pre-provisioned NDW dataset URI
    }
}

Response (200 / direct invocation)
------------------------------------
{
    "statusCode":    200,
    "status":        "successful",
    "areaId":        str,
    "outputFolder":  str,
    "filesWritten":  [str, ...]
}
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import traceback
from pathlib import Path

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    # ------------------------------------------------------------------
    # Direct invocation
    # ------------------------------------------------------------------
    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Prepare invocation start [request_id=%s]", request_id)

    local_dir: Path | None = None
    try:
        from gmt_shared.uri import join_uri, write_uri

        from prepare.core.prepare_core import run_pipeline

        inputs: dict = event.get("inputs", {})
        if not inputs:
            raise ValueError(
                "No inputs provided. Make sure the request body has the form "
                '{"inputs": {"minLon": ..., "outputDir": ..., ...}}'
            )

        # Required bounding box
        min_lon: float = float(inputs["minLon"])
        min_lat: float = float(inputs["minLat"])
        max_lon: float = float(inputs["maxLon"])
        max_lat: float = float(inputs["maxLat"])

        output_folder: str = inputs.get("outputDir", "") or ""
        if not output_folder:
            raise ValueError("inputs.outputDir is required.")

        # Optional parameters
        modes: list[str] = list(inputs.get("modes") or ["CAR"])
        name: str = str(inputs.get("name") or "area")
        catalog: str = str(inputs.get("catalog") or "spectrum")
        schema: str = str(inputs.get("schema") or "2023_01")
        study_fallback: str = str(inputs.get("studyFallback") or "centroid")
        refresh: bool = bool(inputs.get("refresh", False))
        debug: bool = bool(inputs.get("debug", False))
        exclude_zones: list[str] | None = (
            list(inputs["excludeZones"]) if inputs.get("excludeZones") else None
        )
        max_routes: int = int(inputs.get("maxRoutes", 2))
        nvp_table: str | None = inputs.get("nvpTable") or None
        nvp_year: int | None = int(inputs["nvpYear"]) if inputs.get("nvpYear") is not None else None
        area_id_hint: str | None = inputs.get("areaId") or None
        mode_label: str | None = inputs.get("modeLabel") or None
        annotate_traffic_signals: bool = bool(inputs.get("annotateTrafficSignals", False))
        fetch_traffic_signs: bool = bool(inputs.get("fetchTrafficSigns", False))
        ndw_data_uri: str | None = inputs.get("ndwDataUri") or None
        fetch_bgt_assets: bool = bool(inputs.get("fetchBgtAssets", False))
        bgt_url: str | None = inputs.get("bgtUrl") or None
        fetch_osm_assets: bool = bool(inputs.get("fetchOsmAssets", False))
        fetch_parking_areas: bool = bool(inputs.get("fetchParkingAreas", False))
        fetch_buildings: bool = bool(inputs.get("fetchBuildings", True))
        fetch_vegetation: bool = bool(inputs.get("fetchVegetation", False))
        add_elevation: bool = bool(inputs.get("addElevation", False))

        # Create a local temp directory for the pipeline output
        # /tmp is the only writable location in AWS Lambda.
        local_dir = Path(f"/tmp/prepare-{request_id}")  # noqa: S108
        local_dir.mkdir(parents=True, exist_ok=True)

        logger.info(
            "Running prepare pipeline: bbox=[%s,%s,%s,%s] modes=%s outdir=%s",
            min_lon,
            min_lat,
            max_lon,
            max_lat,
            modes,
            local_dir,
        )

        result_area_id: str = run_pipeline(
            min_lon=min_lon,
            min_lat=min_lat,
            max_lon=max_lon,
            max_lat=max_lat,
            modes=modes,
            name=name,
            out_dir=local_dir,
            mode_label=mode_label,
            catalog=catalog,
            schema=schema,
            study_fallback=study_fallback,
            refresh=refresh,
            debug=debug,
            exclude_zones=exclude_zones,
            max_routes=max_routes,
            nvp_table=nvp_table,
            nvp_year=nvp_year,
            area_id=area_id_hint,
            annotate_traffic_signals=annotate_traffic_signals,
            fetch_traffic_signs=fetch_traffic_signs,
            ndw_data_uri=ndw_data_uri,
            fetch_bgt_assets=fetch_bgt_assets,
            bgt_url=bgt_url,
            fetch_osm_assets=fetch_osm_assets,
            fetch_parking_areas=fetch_parking_areas,
            fetch_buildings=fetch_buildings,
            fetch_vegetation=fetch_vegetation,
            add_elevation=add_elevation,
        )

        # Upload / copy output files to outputFolder (skip STEP_ debug snapshots)
        _output_extensions = {".parquet", ".csv"}
        uploaded: list[str] = []
        for f in sorted(local_dir.iterdir()):
            if f.suffix in _output_extensions and not f.name.startswith("STEP_"):
                dest_uri = join_uri(output_folder, f.name)
                logger.info("Writing %s → %s", f.name, dest_uri)
                ct = "application/vnd.apache.parquet" if f.suffix == ".parquet" else "text/csv"
                write_uri(dest_uri, f.read_bytes(), content_type=ct)
                uploaded.append(f.name)

        logger.info(
            "Prepare pipeline complete [request_id=%s] areaId=%s files=%d",
            request_id,
            result_area_id,
            len(uploaded),
        )
        return {
            "statusCode": 200,
            "status": "successful",
            "areaId": result_area_id,
            "outputDir": output_folder,
            "filesWritten": uploaded,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id,
            exc,
            traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
    finally:
        # Always clean up the temp dir to avoid filling /tmp
        if local_dir is not None and local_dir.exists():
            try:
                shutil.rmtree(local_dir)
            except Exception:
                logger.warning("Failed to remove temp dir %s", local_dir)
