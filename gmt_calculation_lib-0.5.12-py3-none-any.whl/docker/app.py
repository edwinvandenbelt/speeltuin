"""GMT Calculation Server — OGC API Processes HTTP interface.

All routes are mounted under /v1/ to avoid conflicts with the existing
Java Spring Boot service on the same ALB.

Environment variables
---------------------
BASE_URL       – Public base URL (default: http://localhost:8080)
JOBS_BUCKET    – S3 bucket name for async job state storage
LOG_LEVEL      – DEBUG / INFO / WARNING / ERROR (default: INFO)
ARTIFACTS_DIR  – Path to the static artifacts directory
                 (default: /app/artifacts/static)
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from pathlib import Path
from typing import cast

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse

from docker import jobs as _jobs
from docker import worker as _worker
from docker.dispatcher import DISPATCH

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "INFO").upper(), logging.INFO)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)

_BASE_URL = os.environ.get("BASE_URL", "http://localhost:8080").rstrip("/")
_ARTIFACTS_DIR = Path(os.environ.get("ARTIFACTS_DIR", "/app/artifacts/static"))

app = FastAPI(
    title="GMT Calculation Service",
    version="0.1.0",
    docs_url="/v1/docs",
    openapi_url="/v1/openapi.json",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _load_static(name: str) -> dict:
    """Load a static JSON file, substituting {{BASE_URL}} with the actual base URL."""
    path = _ARTIFACTS_DIR / name
    if not path.exists():
        return {}
    text = path.read_text(encoding="utf-8").replace("{{BASE_URL}}", _BASE_URL)
    return cast(dict, json.loads(text))


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------


@app.get("/v1/health", tags=["internal"])
async def health() -> dict:
    """Liveness probe used by the ALB target-group health check."""
    return {"status": "UP"}


# ---------------------------------------------------------------------------
# OGC Landing page
# ---------------------------------------------------------------------------


@app.get("/v1/", tags=["OGC API"])
async def landing() -> JSONResponse:
    data = _load_static("landing.json")
    if not data:
        data = {
            "title": "GMT Calculation Service",
            "description": "OGC API Processes — GMT network scaling calculations.",
            "links": [
                {
                    "rel": "self",
                    "type": "application/json",
                    "href": f"{_BASE_URL}/v1/",
                    "title": "This document",
                },
                {
                    "rel": "conformance",
                    "type": "application/json",
                    "href": f"{_BASE_URL}/v1/conformance",
                    "title": "Conformance classes",
                },
                {
                    "rel": "http://www.opengis.net/def/rel/ogc/1.0/processes",
                    "type": "application/json",
                    "href": f"{_BASE_URL}/v1/processes",
                    "title": "Available processes",
                },
                {
                    "rel": "http://www.opengis.net/def/rel/ogc/1.0/job-list",
                    "type": "application/json",
                    "href": f"{_BASE_URL}/v1/jobs",
                    "title": "Active jobs",
                },
            ],
        }
    return JSONResponse(data)


# ---------------------------------------------------------------------------
# Conformance
# ---------------------------------------------------------------------------


@app.get("/v1/conformance", tags=["OGC API"])
async def conformance() -> JSONResponse:
    data = _load_static("conformance.json")
    if not data:
        data = {
            "conformsTo": [
                "http://www.opengis.net/spec/ogcapi-processes-1/1.0/conf/core",
                "http://www.opengis.net/spec/ogcapi-processes-1/1.0/conf/json",
                "http://www.opengis.net/spec/ogcapi-processes-1/1.0/conf/oas30",
            ]
        }
    return JSONResponse(data)


# ---------------------------------------------------------------------------
# Processes
# ---------------------------------------------------------------------------


@app.get("/v1/processes", tags=["OGC API Processes"])
async def list_processes() -> JSONResponse:
    """List all available processes (OGC API Processes §7.9)."""
    data = _load_static("processes.json")
    if data.get("processes"):
        # Filter to only processes that exist in the dispatcher (omit stalled/legacy entries)
        data["processes"] = [p for p in data["processes"] if p.get("id") in DISPATCH]
    else:
        data = {
            "processes": [
                {
                    "id": pid,
                    "version": "1.0.0",
                    "jobControlOptions": ["async-execute" if info["is_async"] else "sync-execute"],
                    "links": [
                        {
                            "rel": "self",
                            "type": "application/json",
                            "href": f"{_BASE_URL}/v1/processes/{pid}",
                        }
                    ],
                }
                for pid, info in DISPATCH.items()
            ],
            "links": [
                {
                    "rel": "self",
                    "type": "application/json",
                    "href": f"{_BASE_URL}/v1/processes",
                    "title": "This document",
                }
            ],
        }
    return JSONResponse(data)


@app.get("/v1/processes/{process_id}", tags=["OGC API Processes"])
async def describe_process(process_id: str) -> JSONResponse:
    """Describe a single process (OGC API Processes §7.10)."""
    if process_id not in DISPATCH:
        raise HTTPException(status_code=404, detail=f"Process '{process_id}' not found.")

    # Per-process file takes precedence
    proc_path = _ARTIFACTS_DIR / "processes" / f"{process_id}.json"
    if proc_path.exists():
        text = proc_path.read_text(encoding="utf-8").replace("{{BASE_URL}}", _BASE_URL)
        return JSONResponse(json.loads(text))

    # Fall back to processes.json summary
    data = _load_static("processes.json")
    for proc in data.get("processes") or []:
        if proc.get("id") == process_id:
            return JSONResponse(proc)

    # Minimal stub
    info = DISPATCH[process_id]
    return JSONResponse(
        {
            "id": process_id,
            "version": "1.0.0",
            "jobControlOptions": ["async-execute" if info["is_async"] else "sync-execute"],
            "links": [
                {
                    "rel": "self",
                    "type": "application/json",
                    "href": f"{_BASE_URL}/v1/processes/{process_id}",
                    "title": "Process description",
                },
                {
                    "rel": "http://www.opengis.net/def/rel/ogc/1.0/execute",
                    "type": "application/json",
                    "href": f"{_BASE_URL}/v1/processes/{process_id}/execution",
                    "title": "Execute this process",
                },
            ],
        }
    )


@app.post("/v1/processes/{process_id}/execution", tags=["OGC API Processes"])
async def execute_process(process_id: str, request: Request) -> JSONResponse:
    """Execute a process synchronously (200) or asynchronously (202)."""
    if process_id not in DISPATCH:
        raise HTTPException(status_code=404, detail=f"Process '{process_id}' not found.")

    # Parse request body — inputs live under "inputs" key per OGC API Processes spec
    try:
        body: dict = await request.json()
    except Exception:
        body = {}
    inputs: dict = body.get("inputs") or {}

    info = DISPATCH[process_id]
    is_async: bool = info["is_async"]
    handler = info["handler"]

    if is_async:
        job_id = str(uuid.uuid4())
        status = _jobs.create_job(job_id, process_id, _BASE_URL)
        _worker.submit_job(job_id, handler, inputs)
        return JSONResponse(
            status,
            status_code=202,
            headers={"Location": f"{_BASE_URL}/v1/jobs/{job_id}"},
        )

    # Synchronous execution — call the Lambda handler directly
    result: dict = handler({"inputs": inputs}, None)
    status_code: int = result.get("statusCode", 500)
    # Omit the internal statusCode field from the HTTP response body
    body_out = {k: v for k, v in result.items() if k != "statusCode"}
    return JSONResponse(body_out, status_code=status_code)


# ---------------------------------------------------------------------------
# Jobs
# ---------------------------------------------------------------------------


@app.get("/v1/jobs", tags=["OGC API Jobs"])
async def list_jobs_route() -> JSONResponse:
    """List all jobs (OGC API Processes §11.2)."""
    job_list = _jobs.list_jobs()
    return JSONResponse(
        {
            "jobs": job_list,
            "links": [
                {
                    "rel": "self",
                    "type": "application/json",
                    "href": f"{_BASE_URL}/v1/jobs",
                    "title": "This document",
                }
            ],
        }
    )


@app.get("/v1/jobs/{job_id}", tags=["OGC API Jobs"])
async def get_job_route(job_id: str) -> JSONResponse:
    """Get the status of a single job (OGC API Processes §11.3)."""
    job = _jobs.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")
    return JSONResponse(job)


@app.get("/v1/jobs/{job_id}/results", tags=["OGC API Jobs"])
async def get_job_results(job_id: str) -> JSONResponse:
    """Retrieve the results of a successful job (OGC API Processes §11.5)."""
    job = _jobs.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")

    job_status = job.get("status")
    if job_status == "dismissed":
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' was dismissed.")
    if job_status != "successful":
        raise HTTPException(
            status_code=400,
            detail=f"Job '{job_id}' is not yet successful (status: {job_status}).",
        )

    results = job.get("results") or {}
    # Omit internal statusCode from results
    results = {k: v for k, v in results.items() if k != "statusCode"}
    return JSONResponse(results)


@app.delete("/v1/jobs/{job_id}", tags=["OGC API Jobs"])
async def dismiss_job(job_id: str) -> JSONResponse:
    """Dismiss a job (OGC API Processes §11.4)."""
    job = _jobs.get_job(job_id)
    if job is None:
        raise HTTPException(status_code=404, detail=f"Job '{job_id}' not found.")

    _jobs.update_job(job_id, "dismissed", message="Job dismissed by client.")
    return JSONResponse({"jobID": job_id, "status": "dismissed"})
