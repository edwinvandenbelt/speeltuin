"""Local debug runner for measure_set_creator.

Reads a network file (GeoParquet/GeoJSON) and a GeoPackage layer, calls
measure_set_creator_core.create_measure_sets() directly — no Lambda handler
involved — and prints the resulting measure sets as JSON (or writes them to
an output URI when --output is given).

Usage
-----
    python -m measure_set_creator.measure_set_creator_runner \\
        --network      s3://gmp-networks/network/area-NETWORK-CAR.parquet \\
        --geopackage   s3://gmp-uploads/measures/lochem-maatregelen.gpkg \\
        --layer-name   "Afsluitingen 2027" \\
        --field-name   naam \\
        [--output      s3://gmp-networks/measures/area-measure-sets.json]

    # Local files (print result JSON to stdout when --output is omitted):
    python -m measure_set_creator.measure_set_creator_runner \\
        --network      /tmp/area-NETWORK-CAR.parquet \\
        --geopackage   /tmp/maatregelen.gpkg \\
        --layer-name   "Afsluitingen 2027" \\
        --field-name   naam

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
* geopandas (with a GDAL/pyogrio backend) for reading the GeoPackage.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import tempfile
from pathlib import Path
from typing import cast

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return cast(bytes, get_bytes_s3(bucket, key))
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


def _read_network_fc(uri: str) -> dict:
    """Read a network file as a GeoJSON FeatureCollection.

    Supports GeoParquet (``.parquet``) and GeoJSON (``.geojson``/``.json``).
    """
    from gmt_shared.geoparquet import from_geoparquet

    raw = _read_uri(uri)
    if uri.endswith(".parquet"):
        return cast(dict, from_geoparquet(raw))
    return cast(dict, json.loads(raw))


def _read_geopackage_layer(uri: str, layer_name: str) -> list[dict]:
    """Read a single layer of a GeoPackage as WGS-84 GeoJSON features."""
    import geopandas as gpd

    raw = _read_uri(uri)
    with tempfile.NamedTemporaryFile(suffix=".gpkg", delete=False) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name

    try:
        gdf = gpd.read_file(tmp_path, layer=layer_name)
        if gdf.crs is not None and str(gdf.crs).upper() not in ("EPSG:4326", "WGS84"):
            gdf = gdf.to_crs(4326)
        return list(gdf.__geo_interface__["features"])
    finally:
        os.unlink(tmp_path)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for measure_set_creator (calls core directly)."
    )
    parser.add_argument(
        "--network", required=True, help="URI for the network file (GeoParquet or GeoJSON)."
    )
    parser.add_argument("--geopackage", required=True, help="URI for the uploaded GeoPackage.")
    parser.add_argument(
        "--layer-name", required=True, help="Name of the layer within the GeoPackage."
    )
    parser.add_argument(
        "--field-name",
        required=True,
        help="Property name whose value forms part of each measure-set name.",
    )
    parser.add_argument(
        "--output",
        default="",
        help="Output URI (omit to print the resulting measure sets as JSON to stdout).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from measure_set_creator.core.measure_set_creator_core import (
        create_measure_sets,
    )

    print(f"Reading network     : {args.network}")
    network_fc = _read_network_fc(args.network)

    print(f"Reading geopackage  : {args.geopackage}  (layer={args.layer_name})")
    layer_features = _read_geopackage_layer(args.geopackage, args.layer_name)
    print(f"Layer features      : {len(layer_features)}")

    measure_sets = create_measure_sets(network_fc, layer_features, args.layer_name, args.field_name)
    print(f"Measure sets built  : {len(measure_sets)}")

    payload = json.dumps(measure_sets, ensure_ascii=False, indent=2).encode("utf-8")

    if args.output:
        print(f"Writing             : {args.output}")
        _write_uri(args.output, payload)
    else:
        sys.stdout.write(payload.decode("utf-8"))
        sys.stdout.write("\n")


if __name__ == "__main__":
    main()
