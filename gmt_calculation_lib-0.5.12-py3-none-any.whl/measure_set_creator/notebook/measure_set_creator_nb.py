# Databricks notebook source
# measure_set_creator_nb — Databricks notebook wrapper for measure_set_creator_core
#
# Reads a network file and a single layer of a user-uploaded GeoPackage, and
# derives one road-closure measure set per polygon feature in that layer.
# The result is always printed / returned inline — this module never writes
# to an output file.
#
# Prerequisites
# -------------
# Run the widget-registration cell once per session to set all widget values.
# The core module (measure_set_creator_core.py) must be on sys.path — see the
# sys.path cell below.

# COMMAND ----------

# %pip install boto3 geopandas

# COMMAND ----------

_GMT_CORE_SRC = "/Workspace/Shared/gmt"  # adjust if you used a custom path
import sys  # noqa: E402
from typing import cast  # noqa: E402

sys.path.insert(0, _GMT_CORE_SRC)

# COMMAND ----------

dbutils.widgets.text(  # noqa: F821
    "network_uri", "", "Network file — s3://bucket/key or local path (GeoParquet or GeoJSON)"
)
dbutils.widgets.text("geopackage_uri", "", "GeoPackage — s3://bucket/key or local path")  # noqa: F821
dbutils.widgets.text("layer_name", "", "Layer name within the GeoPackage")  # noqa: F821
dbutils.widgets.text(  # noqa: F821
    "field_name", "", "Property name whose value forms part of every measure-set name"
)
dbutils.widgets.dropdown("log_level", "INFO", ["DEBUG", "INFO", "WARNING", "ERROR"], "Log level")  # noqa: F821

# COMMAND ----------

import json  # noqa: E402
import logging  # noqa: E402
import os  # noqa: E402
import tempfile  # noqa: E402

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("measure_set_creator_nb")
logger.setLevel(getattr(logging, dbutils.widgets.get("log_level").upper(), logging.INFO))  # noqa: F821

network_uri = dbutils.widgets.get("network_uri").strip()  # noqa: F821
geopackage_uri = dbutils.widgets.get("geopackage_uri").strip()  # noqa: F821
layer_name = dbutils.widgets.get("layer_name").strip()  # noqa: F821
field_name = dbutils.widgets.get("field_name").strip()  # noqa: F821

if not network_uri:
    raise ValueError("Widget 'network_uri' is empty.")
if not geopackage_uri:
    raise ValueError("Widget 'geopackage_uri' is empty.")
if not layer_name:
    raise ValueError("Widget 'layer_name' is empty.")
if not field_name:
    raise ValueError("Widget 'field_name' is empty.")

logger.info(
    "measure_set_creator network_uri=%s geopackage_uri=%s layer_name=%s field_name=%s",
    network_uri,
    geopackage_uri,
    layer_name,
    field_name,
)

# COMMAND ----------

from pathlib import Path  # noqa: E402

import boto3  # noqa: E402
import geopandas as gpd  # noqa: E402


def _read_bytes(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        return cast(bytes, boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read())
    return Path(uri).read_bytes()


def _read_network(uri: str) -> dict:
    raw = _read_bytes(uri)
    if uri.endswith(".parquet"):
        from gmt_shared.geoparquet import from_geoparquet

        return cast(dict, from_geoparquet(raw))
    return cast(dict, json.loads(raw))


def _read_geopackage_layer(uri: str, layer: str) -> list:
    raw = _read_bytes(uri)
    with tempfile.NamedTemporaryFile(suffix=".gpkg", delete=False) as tmp:
        tmp.write(raw)
        tmp_path = tmp.name
    try:
        gdf = gpd.read_file(tmp_path, layer=layer)
        if gdf.crs is not None and str(gdf.crs).upper() not in ("EPSG:4326", "WGS84"):
            gdf = gdf.to_crs(4326)
        return list(gdf.__geo_interface__["features"])
    finally:
        os.unlink(tmp_path)


network_fc = _read_network(network_uri)
layer_features = _read_geopackage_layer(geopackage_uri, layer_name)
logger.info(
    "Loaded network (%d features) and layer '%s' (%d features)",
    len(network_fc.get("features") or []),
    layer_name,
    len(layer_features),
)

# COMMAND ----------

from measure_set_creator.core.measure_set_creator_core import create_measure_sets  # noqa: E402

measure_sets = create_measure_sets(network_fc, layer_features, layer_name, field_name)
logger.info("Built %d measure set(s)", len(measure_sets))

# COMMAND ----------

payload = json.dumps(measure_sets, ensure_ascii=False, indent=2)
print(payload)
print(f"measureSets={len(measure_sets)}")
