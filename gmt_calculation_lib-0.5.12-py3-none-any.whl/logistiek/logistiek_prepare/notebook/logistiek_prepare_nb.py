# Databricks notebook source
# ---------------------------------------------------------------------------
# logistiek_prepare_nb.py — Databricks notebook for logistiek_prepare.
#
# This notebook:
#   1. Reads widget parameters (bbox, date, output_uri, area_id, ...).
#   2. Calls run_pipeline — the logistics (Bridgestone) pipeline in-process:
#        Spectrum zones → logistics network (NWB wegvakken + probe traces of
#        one day) → clean → split → parallel links → road attributes
#        → feedlinks (zone centroids) → zone joiner → OD matrix
#   3. Prints a summary with the four output URIs.
#
# Output files (written to output_uri/)
# ─────────────────────────────────────
#   {area_id}-NETWORK-CAR.parquet
#   {area_id}-FEEDLINK-CAR.parquet
#   {area_id}-ZONE-CAR.parquet
#   {area_id}-ROUTES-CAR.parquet
# ---------------------------------------------------------------------------

# COMMAND ----------
import contextlib
import logging
from datetime import UTC, datetime
from typing import cast

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("logistiek_prepare_nb")

# COMMAND ----------
# Widget declarations
with contextlib.suppress(Exception):
    dbutils.widgets.removeAll()  # noqa: F821

dbutils.widgets.text(  # noqa: F821
    "bbox",
    "5.60,52.02,5.70,52.06",
    "Bounding box: min_lon,min_lat,max_lon,max_lat (Netherlands only)",
)
dbutils.widgets.text("date", "", "Day of the probe traces (YYYY-MM-DD)")  # noqa: F821
dbutils.widgets.text(  # noqa: F821
    "output_uri",
    "",
    "Output folder URI (/dbfs/... or /Volumes/... path)",
)
dbutils.widgets.text(  # noqa: F821
    "area_id",
    "",
    "Area ID (leave blank to auto-discover or generate uuid4)",
)
dbutils.widgets.text("name", "", "Human-readable area name — stored in output metadata")  # noqa: F821
dbutils.widgets.text("catalog", "spectrum", "Spectrum catalog (zones)")  # noqa: F821
dbutils.widgets.text("schema", "2024_01", "Spectrum schema (zones)")  # noqa: F821
dbutils.widgets.text(  # noqa: F821
    "logistiek_catalog", "logistiek_bridgestone", "Catalog of the logistics tables"
)
dbutils.widgets.text("logistiek_schema", "silver", "Schema of the logistics tables")  # noqa: F821
dbutils.widgets.text("pae_per_truck", "2.0", "PAE per probe vehicle")  # noqa: F821
dbutils.widgets.text(  # noqa: F821
    "expansion_factor", "1.0", "Scale factor from probe sample to all freight traffic"
)
dbutils.widgets.text("max_routes", "2", "Maximum k-shortest routes per OD pair")  # noqa: F821
dbutils.widgets.dropdown(  # noqa: F821
    "enrich_road_attributes", "true", ["true", "false"], "Add OSM road attributes"
)
dbutils.widgets.dropdown(  # noqa: F821
    "add_elevation", "false", ["false", "true"], "Add elevationFrom / elevationTo"
)
dbutils.widgets.dropdown(  # noqa: F821
    "refresh", "false", ["false", "true"], "Re-run even if outputs already exist"
)
dbutils.widgets.dropdown(  # noqa: F821
    "debug", "false", ["false", "true"], "Write intermediate GeoJSON snapshots"
)
dbutils.widgets.text("LOG_LEVEL", "INFO", "Log level (DEBUG / INFO / WARNING / ERROR)")  # noqa: F821

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from pathlib import Path  # noqa: E402

from logistiek.logistiek_prepare.core.logistiek_prepare_core import run_pipeline  # noqa: E402

# COMMAND ----------
# ── Widget read + validation ────────────────────────────────────────────────


def _flag(name: str) -> bool:
    return cast(bool, dbutils.widgets.get(name).strip().lower() == "true")  # noqa: F821


def _text(name: str) -> str:
    return cast(str, dbutils.widgets.get(name).strip())  # noqa: F821


_bbox_raw = _text("bbox")
TRACE_DATE = _text("date")
OUTPUT_URI = _text("output_uri")
AREA_ID = _text("area_id") or None
NAME = _text("name") or None
CATALOG = _text("catalog") or "spectrum"
SCHEMA = _text("schema") or "2024_01"
LOGISTIEK_CATALOG = _text("logistiek_catalog") or "logistiek_bridgestone"
LOGISTIEK_SCHEMA = _text("logistiek_schema") or "silver"
PAE_PER_TRUCK = float(_text("pae_per_truck") or "2.0")
EXPANSION_FACTOR = float(_text("expansion_factor") or "1.0")
MAX_ROUTES = int(_text("max_routes") or "2")
ENRICH_ROAD_ATTRIBUTES = _flag("enrich_road_attributes")
ADD_ELEVATION = _flag("add_elevation")
REFRESH = _flag("refresh")
DEBUG = _flag("debug")

if not _bbox_raw:
    raise ValueError("Widget 'bbox' is empty.  Provide min_lon,min_lat,max_lon,max_lat.")
if not TRACE_DATE:
    raise ValueError("Widget 'date' is empty.  Provide the probe-trace day as YYYY-MM-DD.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")

_bbox_parts = [float(v.strip()) for v in _bbox_raw.split(",")]
if len(_bbox_parts) != 4:
    raise ValueError(f"Widget 'bbox' must have exactly 4 values; got: {_bbox_raw!r}")
MIN_LON, MIN_LAT, MAX_LON, MAX_LAT = _bbox_parts

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run LogistiekPrepare pipeline
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell**.

# COMMAND ----------
# ── Main execution ──────────────────────────────────────────────────────────

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")
print(f"Bbox      : [{MIN_LON}, {MIN_LAT}, {MAX_LON}, {MAX_LAT}]")
print(f"Date      : {TRACE_DATE}")
print(f"Output    : {OUTPUT_URI}")
print()

_out_dir = Path(OUTPUT_URI.removeprefix("file://"))
_out_dir.mkdir(parents=True, exist_ok=True)

area_id = run_pipeline(
    MIN_LON,
    MIN_LAT,
    MAX_LON,
    MAX_LAT,
    _out_dir,
    trace_date=TRACE_DATE,
    area_id=AREA_ID,
    name=NAME,
    zone_catalog=CATALOG,
    zone_schema=SCHEMA,
    logistiek_catalog=LOGISTIEK_CATALOG,
    logistiek_schema=LOGISTIEK_SCHEMA,
    pae_per_truck=PAE_PER_TRUCK,
    expansion_factor=EXPANSION_FACTOR,
    max_routes=MAX_ROUTES,
    enrich_road_attributes=ENRICH_ROAD_ATTRIBUTES,
    add_elevation=ADD_ELEVATION,
    refresh=REFRESH,
    debug=DEBUG,
)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ─────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"LogistiekPrepare complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Area ID   : {area_id}")
print(f"  Network   : {_out_dir / f'{area_id}-NETWORK-CAR.parquet'}")
print(f"  Feedlinks : {_out_dir / f'{area_id}-FEEDLINK-CAR.parquet'}")
print(f"  Zones     : {_out_dir / f'{area_id}-ZONE-CAR.parquet'}")
print(f"  Routes    : {_out_dir / f'{area_id}-ROUTES-CAR.parquet'}")
print(_SEP)
