# Databricks notebook source
# ---------------------------------------------------------------------------
# matrix_builder_nb.py — Databricks notebook interface for OD matrix building.
#
# This notebook:
#   1. Reads widget parameters (network_uri, feedlinks_uri, zones_uri, output_uri,
#      max_routes, workers).
#   2. Reads all three input GeoJSON files (s3:// or local path).
#   3. Calls build_matrix (parallelised Yen's k-shortest routing for all zones).
#   4. Writes the resulting OD GeoJSON to output_uri.
#   5. Prints a summary of OD pairs produced.
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("matrix_builder_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "network_uri",
    "",
    "Full URI of the network GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(
    "feedlinks_uri",
    "",
    "Full URI of the feedlinks GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(
    "zones_uri",
    "",
    "Full URI of the zones GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(
    "output_uri",
    "",
    "Full URI for the output OD matrix GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(
    "max_routes",
    "3",
    "Maximum k-shortest routes per OD pair (default 3)",
)
dbutils.widgets.text(
    "workers",
    "",
    "Number of parallel worker processes (leave blank for os.cpu_count())",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_routing.matrix_builder.core.matrix_builder_core import build_matrix

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

NETWORK_URI = dbutils.widgets.get("network_uri").strip()
FEEDLINKS_URI = dbutils.widgets.get("feedlinks_uri").strip()
ZONES_URI = dbutils.widgets.get("zones_uri").strip()
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()
MAX_ROUTES = int(dbutils.widgets.get("max_routes").strip() or "3")
_workers_raw = dbutils.widgets.get("workers").strip()
WORKERS = int(_workers_raw) if _workers_raw else None

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")
if not FEEDLINKS_URI:
    raise ValueError("Widget 'feedlinks_uri' is empty.")
if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")

logger.info(
    "network_uri=%s  feedlinks_uri=%s  zones_uri=%s  output_uri=%s  max_routes=%d  workers=%s",
    NETWORK_URI,
    FEEDLINKS_URI,
    ZONES_URI,
    OUTPUT_URI,
    MAX_ROUTES,
    WORKERS,
)

# COMMAND ----------
# ── S3 helpers ────────────────────────────────────────────────────────────────

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body: bytes = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Matrix Builder
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
print(f"Starting  {_t_start.isoformat()}")
print(f"max_routes={MAX_ROUTES}  workers={WORKERS}")
print()

_network_fc = json.loads(_read_uri(NETWORK_URI))
_feedlinks_fc = json.loads(_read_uri(FEEDLINKS_URI))
_zones_fc = json.loads(_read_uri(ZONES_URI))

_od_fc = build_matrix(
    _network_fc,
    _feedlinks_fc,
    _zones_fc,
    max_routes=MAX_ROUTES,
    workers=WORKERS,
)

_payload = json.dumps(_od_fc, ensure_ascii=False).encode("utf-8")
_write_uri(OUTPUT_URI, _payload)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("Done in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60
_n_pairs = len(_od_fc.get("features") or [])

print(_SEP)
print(f"Matrix builder complete — {_total_elapsed:.1f}s total")
print(_SEP)
print()
print(f"  OD pairs produced : {_n_pairs}")
print(f"  max_routes        : {MAX_ROUTES}")
print(f"  workers           : {WORKERS}")
print(f"  Output URI        : {OUTPUT_URI}")
print()
print(_SEP)
