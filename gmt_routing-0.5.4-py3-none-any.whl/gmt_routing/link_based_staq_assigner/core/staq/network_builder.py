"""
Network builder for the Link-Based STAQ algorithm.

Parses an NDJSON-style list of network elements (links + centroids) and
constructs a Network with:
  - Road links and feedlink centroid connectors (all treated as regular links)
  - Nodes inferred from link endpoints (including zone virtual nodes from feedlinks)
  - Auto-generated turns (all combinations allowed; no bans)
  - Opposite-link references (via reverseLinkIds when present, geometric fallback otherwise)
"""

from __future__ import annotations

import logging
from collections import defaultdict

from .domain import Centroid, Link, Network, Node, Turn

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Turn-id helper (mirrors TurnUtil.generateTurnId)
# ---------------------------------------------------------------------------


def _turn_id(from_link_idx: int, to_link_idx: int) -> int:
    """Pack (from_link_idx, to_link_idx) into a single 64-bit int."""
    return (from_link_idx << 32) | (to_link_idx & 0xFFFF_FFFF)


# ---------------------------------------------------------------------------
# Main builder function
# ---------------------------------------------------------------------------


def build_network(elements: list[dict]) -> Network:
    """
    Parse a list of NDJSON-style dicts with ``dataType`` in {"link", "centroid"}
    and build a :class:`Network`.

    Link properties expected:
        id, fromNodeId, toNodeId, lengthInMeters, speedInKilometersPerHour,
        capacity, [speedAtCapacityInKilometersPerHour], [preload]

    Centroid properties expected:
        nodeId, zoneIndex   (1-based zone index)
    """
    link_dtos = [e["properties"] for e in elements if e["dataType"] == "link"]
    centroid_dtos = [e["properties"] for e in elements if e["dataType"] == "centroid"]

    # ---- Step 1: build node-id → node-index mapping (insertion order) ----
    # Zone virtual nodes (feedlink endpoints) are discovered here alongside
    # real road nodes — no separate virtual-node creation is needed later.
    node_id_to_index: dict[str, int] = {}
    for dto in link_dtos:
        for nid in (dto["fromNodeId"], dto["toNodeId"]):
            if nid not in node_id_to_index:
                node_id_to_index[nid] = len(node_id_to_index)

    # ---- Step 2: create Node objects ----
    nodes: list[Node] = [Node(i) for i in range(len(node_id_to_index))]

    # ---- Step 3: create real links ----
    links: list[Link] = []
    link_id_to_link: dict[str, Link] = {}

    for dto in link_dtos:
        idx = len(links)
        # Feedlinks are tagged as virtual by parse_feedlinks_as_links.  We use zero-length
        # connector constants so they contribute zero generalised cost — matching the
        # original Java STAQ model's zero-length virtual connectors.
        is_virtual = bool(dto.get("isVirtual", False))
        speed_at_cap: float | None
        if is_virtual:
            length_m = Link.VIRTUAL_LINK_LENGTH_M
            speed_kmh = Link.VIRTUAL_LINK_SPEED_KMH
            speed_at_cap = Link.VIRTUAL_LINK_SPEED_AT_CAP_KMH
            capacity = Link.VIRTUAL_LINK_CAPACITY
        else:
            length_m = float(dto["lengthInMeters"])
            speed_kmh = float(dto["speedInKilometersPerHour"])
            speed_at_cap = (
                float(dto["speedAtCapacityInKilometersPerHour"])
                if "speedAtCapacityInKilometersPerHour" in dto
                else None
            )
            capacity = float(dto["capacity"])
        lnk = Link(
            index=idx,
            external_id=str(dto["id"]),
            from_node_index=node_id_to_index[dto["fromNodeId"]],
            to_node_index=node_id_to_index[dto["toNodeId"]],
            length_m=length_m,
            speed_kmh=speed_kmh,
            speed_at_cap_kmh=speed_at_cap,
            capacity=capacity,
            preload=float(dto["preload"]) if "preload" in dto else None,
            is_virtual=is_virtual,
        )
        links.append(lnk)
        link_id_to_link[str(dto["id"])] = lnk

    # ---- Step 4: assign opposite links ----
    # Primary: use reverseLinkIds from the DTO when present (explicit, O(n))
    for lnk, dto in zip(links, link_dtos):
        for rev_id in dto.get("reverseLinkIds", []):
            rev = link_id_to_link.get(str(rev_id))
            if rev is not None and lnk.opposite_link is None:
                lnk.opposite_link = rev
                rev.opposite_link = lnk

    # Fallback: geometric inference for any real link still without an opposite
    _assign_opposite_links(links)

    # ---- Step 5: register centroids ----
    # Zone virtual nodes were already discovered in step 1 as endpoints of
    # feedlinks.  No new nodes or connector links need to be created here —
    # we simply look up each centroid nodeId and record its zone index.
    centroids: dict[int, Centroid] = {}

    for dto in centroid_dtos:
        node_idx = node_id_to_index.get(dto["nodeId"])
        if node_idx is None:
            logger.warning(
                "Centroid nodeId %r not found in network links — skipping centroid",
                dto["nodeId"],
            )
            continue
        zone_idx = int(dto["zoneIndex"])
        centroids[node_idx] = Centroid(zone_index_1based=zone_idx, node_index=node_idx)

    # ---- Step 6: build adjacency: for each node, list of outgoing links ----
    to_links_per_node: dict[int, list[Link]] = defaultdict(list)
    for lnk in links:
        to_links_per_node[lnk.from_node_index].append(lnk)

    # ---- Step 7: auto-generate turns (all combinations; no bans) ----
    turns: dict[int, Turn] = {}

    for from_link in links:
        via_node_idx = from_link.to_node_index
        for to_link in to_links_per_node.get(via_node_idx, []):
            tid = _turn_id(from_link.index, to_link.index)
            if tid not in turns:
                turns[tid] = Turn(turn_id=tid, from_link=from_link, to_link=to_link)

    # ---- Step 8: connect links and turns to nodes ----
    _connect_links_and_turns_to_nodes(nodes, links, turns)

    return Network(links=links, nodes=nodes, turns=turns, centroids=centroids)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _assign_opposite_links(links: list[Link]) -> None:
    """
    For every pair of real links A→B and B→A (with matching node indices),
    set each as the other's opposite_link.  Only real (non-virtual) links
    can be opposites of each other here; virtual connector pairs are handled
    separately in the centroid builder.
    """
    # index by (from, to) for quick lookup
    pair_to_link: dict[tuple[int, int], Link] = {}
    for lnk in links:
        if not lnk.is_virtual:
            pair_to_link[(lnk.from_node_index, lnk.to_node_index)] = lnk

    for lnk in links:
        if not lnk.is_virtual and lnk.opposite_link is None:
            rev_key = (lnk.to_node_index, lnk.from_node_index)
            rev = pair_to_link.get(rev_key)
            if rev is not None:
                lnk.opposite_link = rev
                rev.opposite_link = lnk


def _connect_links_and_turns_to_nodes(
    nodes: list[Node],
    links: list[Link],
    turns: dict[int, Turn],
) -> None:
    """
    Populate node.from_links, node.to_links, and node.turns.

    Java definition:
      - fromLinks (entering the node):  link.to_node_index == node.index
      - toLinks   (leaving the node):   link.from_node_index == node.index
      - turns for a node: turns whose fromLink enters that node
                          i.e.  turn.from_link.to_node_index == node.index
    """
    from_links_per_node: dict[int, list[Link]] = defaultdict(list)
    to_links_per_node: dict[int, list[Link]] = defaultdict(list)
    turns_per_node: dict[int, list[Turn]] = defaultdict(list)

    for lnk in links:
        from_links_per_node[lnk.to_node_index].append(lnk)  # link enters node at to_node
        to_links_per_node[lnk.from_node_index].append(lnk)  # link leaves node at from_node

    for turn in turns.values():
        via_node_idx = turn.from_link.to_node_index
        turns_per_node[via_node_idx].append(turn)

    for node in nodes:
        node.from_links = from_links_per_node.get(node.index, [])
        node.to_links = to_links_per_node.get(node.index, [])
        node.turns = turns_per_node.get(node.index, [])
