"""Unit tests for bottleneck_detector_core."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from gmt_routing.bottleneck_detector.core.bottleneck_detector_core import (
    _build_undirected_adjacency,
    _component_sizes_after_removal,
    _find_undirected_bridges,
    _zone_side_membership,
    assess_bottleneck_impact,
    bottleneck_edge_set,
    detect_bottlenecks,
    find_bridge_edges,
)

# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------


def _net_feature(from_node, to_node, link_id, speed=50.0, length=100.0, capacity=500.0):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "fromNode": from_node,
            "toNode": to_node,
            "linkId": link_id,
            "speed": speed,
            "length": length,
            "capacity": capacity,
            "flowsPerDaypart": {},
        },
    }


def _make_fc(features):
    return {"type": "FeatureCollection", "features": features}


def _barbell_network(bidirectional_bridge=False):
    """Two triangles (1-2-3 and 4-5-6) joined by a single bridge link 3->4.

    With *bidirectional_bridge*, a reverse link 4->3 is added too, so the
    bridge becomes a dual-carriageway pair collapsing to one undirected edge.
    """
    features = [
        _net_feature("1", "2", "L12"),
        _net_feature("2", "3", "L23"),
        _net_feature("3", "1", "L31"),
        _net_feature("3", "4", "L34"),
        _net_feature("4", "5", "L45"),
        _net_feature("5", "6", "L56"),
        _net_feature("6", "4", "L64"),
    ]
    if bidirectional_bridge:
        features.append(_net_feature("4", "3", "L43"))
    return _make_fc(features)


def _ring_network():
    """A simple cycle 1-2-3-4-1 -- no bridges anywhere."""
    return _make_fc(
        [
            _net_feature("1", "2", "L12"),
            _net_feature("2", "3", "L23"),
            _net_feature("3", "4", "L34"),
            _net_feature("4", "1", "L41"),
        ]
    )


def _barbell_adjacency(bidirectional_bridge: bool = False) -> dict:
    network_fc = _barbell_network(bidirectional_bridge)
    adj: dict = {}
    for feat in network_fc["features"]:
        props = feat["properties"]
        adj.setdefault(props["fromNode"], []).append((props["toNode"], 1.0, 10.0, 100.0, 100.0))
    return adj


# ---------------------------------------------------------------------------
# Tests: _build_undirected_adjacency
# ---------------------------------------------------------------------------


class TestBuildUndirectedAdjacency:
    def test_dual_carriageway_collapses_to_one_undirected_edge(self):
        adj = _barbell_adjacency(bidirectional_bridge=True)
        undirected_adj, edge_id_to_pair, edge_id_to_directed = _build_undirected_adjacency(adj)

        bridge_edge_ids = [eid for eid, pair in edge_id_to_pair.items() if {"3", "4"} == set(pair)]
        assert len(bridge_edge_ids) == 1
        edge_id = bridge_edge_ids[0]
        assert set(edge_id_to_directed[edge_id]) == {("3", "4"), ("4", "3")}
        # Both "3" and "4" must list exactly one undirected neighbour entry
        # for this edge_id (not two), confirming the collapse.
        assert sum(1 for _, eid in undirected_adj["3"] if eid == edge_id) == 1
        assert sum(1 for _, eid in undirected_adj["4"] if eid == edge_id) == 1

    def test_one_way_edge_has_single_directed_entry(self):
        adj = _barbell_adjacency(bidirectional_bridge=False)
        _undirected_adj, edge_id_to_pair, edge_id_to_directed = _build_undirected_adjacency(adj)

        bridge_edge_ids = [eid for eid, pair in edge_id_to_pair.items() if {"3", "4"} == set(pair)]
        assert len(bridge_edge_ids) == 1
        assert edge_id_to_directed[bridge_edge_ids[0]] == [("3", "4")]


# ---------------------------------------------------------------------------
# Tests: _find_undirected_bridges / find_bridge_edges
# ---------------------------------------------------------------------------


class TestFindUndirectedBridges:
    def test_single_bridge_in_barbell_graph(self):
        adj = _barbell_adjacency(bidirectional_bridge=False)
        undirected_adj, edge_id_to_pair, _ = _build_undirected_adjacency(adj)
        bridge_ids = _find_undirected_bridges(undirected_adj)

        bridge_pairs = {frozenset(edge_id_to_pair[eid]) for eid in bridge_ids}
        assert bridge_pairs == {frozenset({"3", "4"})}

    def test_no_bridges_in_a_cycle(self) -> None:
        network_fc = _ring_network()
        adj: dict = {}
        for feat in network_fc["features"]:
            props = feat["properties"]
            adj.setdefault(props["fromNode"], []).append((props["toNode"], 1.0, 10.0, 100.0, 100.0))
        undirected_adj, _, _ = _build_undirected_adjacency(adj)
        assert _find_undirected_bridges(undirected_adj) == []

    def test_dual_carriageway_bridge_still_detected_as_one_bridge(self):
        adj = _barbell_adjacency(bidirectional_bridge=True)
        undirected_adj, edge_id_to_pair, _ = _build_undirected_adjacency(adj)
        bridge_ids = _find_undirected_bridges(undirected_adj)

        bridge_pairs = {frozenset(edge_id_to_pair[eid]) for eid in bridge_ids}
        assert bridge_pairs == {frozenset({"3", "4"})}


class TestFindBridgeEdges:
    def test_one_way_bridge_reported_with_single_direction(self):
        adj = _barbell_adjacency(bidirectional_bridge=False)
        bridges = find_bridge_edges(adj)
        assert len(bridges) == 1
        assert bridges[0]["directed_edges"] == [("3", "4")]

    def test_bridge_reported_with_both_directions_for_dual_carriageway(self):
        adj = _barbell_adjacency(bidirectional_bridge=True)
        bridges = find_bridge_edges(adj)
        assert len(bridges) == 1
        assert set(bridges[0]["directed_edges"]) == {("3", "4"), ("4", "3")}

    def test_side_partition_sizes(self):
        adj = _barbell_adjacency(bidirectional_bridge=False)
        bridges = find_bridge_edges(adj)
        assert len(bridges) == 1
        side_a, side_b = bridges[0]["side_a_nodes"], bridges[0]["side_b_nodes"]
        assert {side_a, side_b} == {frozenset({"1", "2", "3"}), frozenset({"4", "5", "6"})}

    def test_no_bridges_returns_empty_list(self) -> None:
        network_fc = _ring_network()
        adj: dict = {}
        for feat in network_fc["features"]:
            props = feat["properties"]
            adj.setdefault(props["fromNode"], []).append((props["toNode"], 1.0, 10.0, 100.0, 100.0))
        assert find_bridge_edges(adj) == []


class TestComponentSizesAfterRemoval:
    def test_barbell_split_excludes_removed_edge(self):
        adj = _barbell_adjacency(bidirectional_bridge=False)
        undirected_adj, edge_id_to_pair, _ = _build_undirected_adjacency(adj)
        bridge_id = next(eid for eid, pair in edge_id_to_pair.items() if set(pair) == {"3", "4"})
        side_a, side_b = _component_sizes_after_removal(undirected_adj, bridge_id, "3", "4")
        assert side_a == {"1", "2", "3"}
        assert side_b == {"4", "5", "6"}


# ---------------------------------------------------------------------------
# Tests: _zone_side_membership / assess_bottleneck_impact
# ---------------------------------------------------------------------------


class TestZoneSideMembership:
    def test_returns_zone_ids_on_the_given_side(self):
        zone_node_ids = {"ZA": "1", "ZB": "4", "ZC": "5"}
        side_nodes = frozenset({"4", "5", "6"})
        assert _zone_side_membership(zone_node_ids, side_nodes) == {"ZB", "ZC"}


class TestAssessBottleneckImpact:
    _BRIDGES = [
        {
            "directed_edges": [("3", "4")],
            "side_a_nodes": frozenset({"1", "2", "3"}),
            "side_b_nodes": frozenset({"4", "5", "6"}),
        }
    ]
    _ZONE_NODE_IDS = {"ZA": "1", "ZB": "4"}

    def test_cut_off_zone_pairs_counted_both_directions(self):
        result = assess_bottleneck_impact(self._BRIDGES, self._ZONE_NODE_IDS)
        assert result[0]["cut_off_zone_pair_count"] == 2
        assert set(result[0]["cut_off_zone_pairs"]) == {("ZA", "ZB"), ("ZB", "ZA")}

    def test_estimated_trips_at_risk_uses_production_times_attraction(self):
        productions = {"ZA": 100.0, "ZB": 50.0}
        attractions = {"ZA": 20.0, "ZB": 80.0}
        result = assess_bottleneck_impact(
            self._BRIDGES, self._ZONE_NODE_IDS, productions, attractions
        )
        # ZA->ZB: 100*80 = 8000; ZB->ZA: 50*20 = 1000 -> total 9000
        assert result[0]["estimated_trips_at_risk"] == 9000.0

    def test_no_zone_data_leaves_impact_fields_empty_but_does_not_error(self):
        result = assess_bottleneck_impact(self._BRIDGES, {})
        assert result[0]["cut_off_zone_pair_count"] == 0
        assert result[0]["cut_off_zone_pairs"] == []
        assert result[0]["estimated_trips_at_risk"] == 0.0


# ---------------------------------------------------------------------------
# Tests: detect_bottlenecks / bottleneck_edge_set
# ---------------------------------------------------------------------------


class TestDetectBottlenecks:
    def test_geojson_feature_collection_shape(self):
        result = detect_bottlenecks(_barbell_network())
        assert result["type"] == "FeatureCollection"
        assert len(result["features"]) == 1
        feat = result["features"][0]
        assert feat["type"] == "Feature"
        assert feat["geometry"] is not None

    def test_properties_include_link_id(self):
        result = detect_bottlenecks(_barbell_network())
        props = result["features"][0]["properties"]
        assert props["linkId"] == "L34"
        assert props["fromNode"] == "3"
        assert props["toNode"] == "4"
        assert props["directedEdges"] == [["3", "4"]]

    def test_dual_carriageway_bridge_reports_both_link_ids(self):
        result = detect_bottlenecks(_barbell_network(bidirectional_bridge=True))
        assert len(result["features"]) == 1
        props = result["features"][0]["properties"]
        assert props["linkId"] is None
        assert set(props["linkIds"]) == {"L34", "L43"}
        assert result["features"][0]["geometry"]["type"] == "MultiLineString"

    def test_no_bridges_returns_empty_feature_collection(self):
        result = detect_bottlenecks(_ring_network())
        assert result["type"] == "FeatureCollection"
        assert result["features"] == []


class TestBottleneckEdgeSet:
    def test_flattens_single_direction_bridge(self):
        bottleneck_fc = detect_bottlenecks(_barbell_network())
        assert bottleneck_edge_set(bottleneck_fc) == {("3", "4")}

    def test_flattens_bidirectional_bridge_to_two_tuples(self):
        bottleneck_fc = detect_bottlenecks(_barbell_network(bidirectional_bridge=True))
        assert bottleneck_edge_set(bottleneck_fc) == {("3", "4"), ("4", "3")}

    def test_empty_feature_collection_yields_empty_set(self):
        assert bottleneck_edge_set({"type": "FeatureCollection", "features": []}) == set()
