# Databricks notebook source
# ---------------------------------------------------------------------------
# od_support_matrices_creator_nb.py — Databricks notebook for OD support matrices creator.
#
# This notebook:
#   1. Reads widget parameters (network_uri, feedlink_uri, zone_uri,
#      output_csv_uri, output_geojson_uri).
#   2. Reads the three input GeoJSON files (s3:// or local path).
#   3. Builds the graph and runs Dijkstra from every zone (pure core, no Spark).
#   4. Writes the output CSV and/or GeoJSON files to the specified URIs.
#   5. Prints a summary of the computed matrix.
#
# No Databricks SQL dependency — operates on pre-computed GeoJSON files only.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s - %(message)s")
logger = logging.getLogger("od_support_matrices_creator_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "network_uri",
    "",
    "Full URI of the network GeoJSON file (s3:// or local path)",
)
dbutils.widgets.text(
    "feedlink_uri",
    "",
    "Full URI of the feedlinks GeoJSON file (s3:// or local path)",
)
dbutils.widgets.text(
    "zone_uri",
    "",
    "Full URI of the zones GeoJSON file (s3:// or local path)",
)
dbutils.widgets.text(
    "output_csv_uri",
    "",
    "Full URI for output CSV (leave blank to skip)",
)
dbutils.widgets.text(
    "output_geojson_uri",
    "",
    "Full URI for output GeoJSON (leave blank to skip)",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_routing.od_support_matrices_creator.core.od_support_matrices_creator_core import (
    build_graph,
    compute_matrix,
    extract_zone_centroids,
    extract_zone_ids,
    records_to_csv,
    records_to_geojson,
)

# COMMAND ----------
# Widget read + validation

NETWORK_URI = dbutils.widgets.get("network_uri").strip()
FEEDLINK_URI = dbutils.widgets.get("feedlink_uri").strip()
ZONE_URI = dbutils.widgets.get("zone_uri").strip()
OUTPUT_CSV_URI = dbutils.widgets.get("output_csv_uri").strip()
OUTPUT_GEOJSON_URI = dbutils.widgets.get("output_geojson_uri").strip()

for _param_name, _param_val in [
    ("network_uri", NETWORK_URI),
    ("feedlink_uri", FEEDLINK_URI),
    ("zone_uri", ZONE_URI),
]:
    if not _param_val:
        raise ValueError(f"Widget '{_param_name}' is required but was left empty.")

logger.info(
    "network_uri=%s feedlink_uri=%s zone_uri=%s output_csv=%s output_geojson=%s",
    NETWORK_URI,
    FEEDLINK_URI,
    ZONE_URI,
    OUTPUT_CSV_URI or "(skip)",
    OUTPUT_GEOJSON_URI or "(skip)",
)

# COMMAND ----------
# S3 / local I/O helpers

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body: bytes = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType=content_type,
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Travel Time Matrix
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# Main execution

_t_start = datetime.now(timezone.utc)

print(f"Starting      : {_t_start.isoformat()}")
print(f"Network URI   : {NETWORK_URI}")
print(f"Feedlink URI  : {FEEDLINK_URI}")
print(f"Zone URI      : {ZONE_URI}")
print(f"Output CSV    : {OUTPUT_CSV_URI or '(skip)'}")
print(f"Output GeoJSON: {OUTPUT_GEOJSON_URI or '(skip)'}")
print()

logger.info("Reading input files ...")
_network_fc = json.loads(_read_uri(NETWORK_URI))
_feedlink_fc = json.loads(_read_uri(FEEDLINK_URI))
_zone_fc = json.loads(_read_uri(ZONE_URI))

logger.info("Building graph ...")
_adj, _zone_node_ids, _zone_centroids = build_graph(_network_fc, _feedlink_fc)
_zone_centroids.update(extract_zone_centroids(_zone_fc))
_zone_ids = extract_zone_ids(_zone_fc)

logger.info("Computing matrix for %d zones (%d pairs) ...", len(_zone_ids), len(_zone_ids) ** 2)
_records = compute_matrix(_zone_ids, _zone_node_ids, _zone_centroids, _adj)

if OUTPUT_CSV_URI:
    logger.info("Writing CSV -> %s", OUTPUT_CSV_URI)
    _csv_bytes = records_to_csv(_records).encode("utf-8")
    _write_uri(OUTPUT_CSV_URI, _csv_bytes, "text/csv")

if OUTPUT_GEOJSON_URI:
    logger.info("Writing GeoJSON -> %s", OUTPUT_GEOJSON_URI)
    _geojson_bytes = json.dumps(
        records_to_geojson(_records, _zone_centroids), ensure_ascii=False
    ).encode("utf-8")
    _write_uri(OUTPUT_GEOJSON_URI, _geojson_bytes, "application/geo+json")

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# Results summary

_SEP = "-" * 60
_n_reachable = sum(1 for r in _records if r["travelTime"] is not None)
_n_diagonal = len(_zone_ids)
_n_pairs = len(_records)

print(_SEP)
print(f"Travel time matrix complete - {_total_elapsed:.1f}s total")
print(_SEP)
print(f"  Zones      : {len(_zone_ids)}")
print(f"  Pairs      : {_n_pairs}")
print(f"  Reachable  : {_n_reachable} (incl. {_n_diagonal} diagonal zeros)")
print(f"  Unreachable: {_n_pairs - _n_reachable}")
if OUTPUT_CSV_URI:
    print(f"  CSV        : {OUTPUT_CSV_URI}")
if OUTPUT_GEOJSON_URI:
    print(f"  GeoJSON    : {OUTPUT_GEOJSON_URI}")
print(_SEP)
