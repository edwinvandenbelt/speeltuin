"""Local debug runner for osm_prepare.

Runs the full OSM preparation pipeline for CAR mode entirely in-process:

    osm_building_fetcher → building_zone_creator → zone_population_estimator
    osm_network_fetcher  → network_simplifier → network_cleaner
                        → bidirectional_splitter → parallel_link_finder
    osm_feedlink_creator
    matrix_builder

Usage
-----
    python -m osm.osm_prepare.osm_prepare_runner \\
        --bbox 6.15 51.95 6.25 52.00 \\
        --output-folder ./output/

    # with optional overrides:
    python -m osm.osm_prepare.osm_prepare_runner \\
        --bbox 6.15 51.95 6.25 52.00 \\
        --output-folder ./output/ \\
        --area-id my-area \\
        --target-footprint-m2 3000 \\
        --max-routes 3 \\
        --matrix-workers 4 \\
        --overpass-url https://my-private-overpass/api/interpreter \\
        --overpass-timeout 120 \\
        --refresh \\
        --debug

Output (in --output-folder)
---------------------------
    {area_id}-BUILDINGS.parquet
    {area_id}-NETWORK-CAR.parquet
    {area_id}-FEEDLINK-CAR.parquet
    {area_id}-ZONE-CAR.parquet
    {area_id}-ROUTES-CAR.parquet

    When --debug is given, intermediate GeoJSON snapshots are also written.

Prerequisites
-------------
* AWS credentials available in the environment or a tools/.env file (only
  needed for s3:// URIs).
* shapely >= 2.0, pyarrow, geopandas installed.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for osm_prepare — runs the full OSM preparation pipeline "
            "for CAR mode and writes four GeoParquet outputs."
        )
    )
    parser.add_argument(
        "--bbox",
        required=True,
        nargs="+",
        metavar="COORD",
        help=(
            "Bounding box in decimal degrees (WGS-84): MIN_LON MIN_LAT MAX_LON MAX_LAT. "
            "Accepts four space-separated values (--bbox 6.15 51.95 6.25 52.00) "
            "or a single comma-separated string (--bbox 6.15,51.95,6.25,52.00)."
        ),
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="DIR",
        help="Local output directory.  Created automatically when missing.",
    )
    parser.add_argument(
        "--area-id",
        default=None,
        help=(
            "Area identifier used in output filenames.  "
            "Auto-discovered from existing parquet files or generated as uuid4()."
        ),
    )
    parser.add_argument(
        "--name",
        default=None,
        help="Human-readable area name (e.g. 'Deventer').  Stored in output file metadata.",
    )
    parser.add_argument(
        "--target-footprint-m2",
        type=float,
        default=None,
        help=(
            "Target total building footprint per zone in m². "
            "When omitted the value is auto-computed so that approximately "
            "100 zones are created (total_footprint / 100)."
        ),
    )
    parser.add_argument(
        "--max-routes",
        type=int,
        default=2,
        help="Maximum k-shortest routes per OD pair (default: 2).",
    )
    parser.add_argument(
        "--overpass-url",
        default=None,
        help=(
            "Overpass API endpoint URL. "
            "Defaults to the OVERPASS_URL environment variable, "
            "or https://overpass-api.de/api/interpreter."
        ),
    )
    parser.add_argument(
        "--overpass-timeout",
        type=int,
        default=90,
        help="HTTP timeout in seconds for every Overpass request (default: 90).",
    )
    parser.add_argument(
        "--population",
        type=float,
        default=None,
        dest="population",
        help=(
            "Total population override for the area. "
            "Skips the automatic LAU/NUTS lookup when set. "
            "Useful when the automatic estimate is inaccurate."
        ),
    )
    parser.add_argument(
        "--no-ssl-verify",
        action="store_true",
        help=(
            "Disable SSL certificate verification for GISCO and Eurostat requests. "
            "Use this when behind a corporate proxy that intercepts HTTPS. "
            "Equivalent to setting SSL_VERIFY=false in the .env file."
        ),
    )
    parser.add_argument(
        "--external-share",
        type=float,
        default=0.40,
        dest="external_share",
        help=(
            "Fraction of total zone production allocated to external (boundary-crossing) zones. "
            "Default: 0.40."
        ),
    )
    parser.add_argument(
        "--peak-hour-fraction",
        type=float,
        default=0.10,
        dest="peak_hour_fraction",
        help=(
            "Fraction of daily flow assigned to the peak hour for remaining-capacity calculation. "
            "Default: 0.10."
        ),
    )
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Re-run all steps even when the final output files already exist.",
    )
    parser.add_argument(
        "--matrix-workers",
        type=int,
        default=None,
        dest="matrix_workers",
        help=(
            "Number of worker processes for the OD matrix builder (D1 and D2). "
            "Default: auto-detected from available RAM (budget 512 MB/worker). "
            "Set to 1 to disable parallelism entirely."
        ),
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Write intermediate GeoJSON snapshots to --output-folder.",
    )
    parser.add_argument(
        "--annotate-traffic-signals",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Query Overpass for OSM traffic-signal nodes, annotate every link with "
            "trafficSignal, and add signal point assets to the TRAFFIC-ASSETS parquet. "
            "Default: enabled (use --no-annotate-traffic-signals to disable)."
        ),
    )
    parser.add_argument(
        "--fetch-traffic-signs",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Fetch OSM traffic-sign point assets from Overpass and add them to the "
            "TRAFFIC-ASSETS parquet. "
            "Default: enabled (use --no-fetch-traffic-signs to disable)."
        ),
    )
    parser.add_argument(
        "--fetch-osm-assets",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Fetch OSM traffic objects (crossings, speed bumps, stop/give-way signs, "
            "mini-roundabouts) from Overpass and add them to the TRAFFIC-ASSETS parquet. "
            "Default: enabled (use --no-fetch-osm-assets to disable)."
        ),
    )
    parser.add_argument(
        "--elevation",
        dest="add_elevation",
        action=argparse.BooleanOptionalAction,
        default=True,
        help=(
            "Look up terrain elevation for every directed link endpoint from the "
            "Open-Meteo elevation API and set elevationFrom / elevationTo (metres above "
            "sea level) on each link. Best-effort: failures are logged and the pipeline "
            "continues. Default: enabled (use --no-elevation to disable)."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env (auto-discover tools/.env if not specified)
    env_file_path: Path
    if args.env_file:
        env_file_path = Path(args.env_file)
    else:
        env_file_path = Path(__file__).resolve().parent.parent.parent.parent / "tools" / ".env"
    for k, v in _read_env_file(env_file_path).items():
        os.environ.setdefault(k, v)

    overpass_url: str = args.overpass_url or os.environ.get(
        "OVERPASS_URL", "https://overpass-api.de/api/interpreter"
    )

    # --no-ssl-verify flag takes precedence; falls back to SSL_VERIFY env var.
    if args.no_ssl_verify:
        os.environ["SSL_VERIFY"] = "false"

    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
        level=logging.INFO,
    )

    from osm.osm_prepare.core.osm_prepare_core import run_pipeline  # noqa: PLC0415

    # Normalise bbox: accept either four space-separated tokens or one
    # comma-separated string (e.g. "3.67,51.02,3.76,51.08").
    raw_bbox: list[str] = args.bbox
    if len(raw_bbox) == 1:
        raw_bbox = raw_bbox[0].split(",")
    if len(raw_bbox) != 4:
        import sys  # noqa: PLC0415

        print(
            f"error: --bbox expects exactly 4 coordinates, got {len(raw_bbox)}",
            file=sys.stderr,
        )
        sys.exit(2)
    try:
        min_lon, min_lat, max_lon, max_lat = (float(v) for v in raw_bbox)
    except ValueError as exc:
        import sys  # noqa: PLC0415

        print(f"error: --bbox values must be numbers: {exc}", file=sys.stderr)
        sys.exit(2)

    out_dir = Path(args.output_folder).resolve()

    area_id = run_pipeline(
        min_lon,
        min_lat,
        max_lon,
        max_lat,
        out_dir,
        area_id=args.area_id,
        name=args.name,
        target_footprint_m2=args.target_footprint_m2,
        max_routes=args.max_routes,
        overpass_url=overpass_url,
        overpass_timeout=args.overpass_timeout,
        external_share=args.external_share,
        peak_hour_fraction=args.peak_hour_fraction,
        population=args.population,
        matrix_workers=args.matrix_workers,
        refresh=args.refresh,
        debug=args.debug,
        annotate_traffic_signals=args.annotate_traffic_signals,
        fetch_traffic_signs=args.fetch_traffic_signs,
        fetch_osm_assets=args.fetch_osm_assets,
        add_elevation=args.add_elevation,
    )

    print()
    print(f"Area ID: {area_id}")
    print("Done.")


if __name__ == "__main__":
    main()
