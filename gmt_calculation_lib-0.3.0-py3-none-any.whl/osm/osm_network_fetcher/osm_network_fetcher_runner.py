"""Local debug runner for osm_network_fetcher.

Fetches a road network from the Overpass API for a bounding box and writes
a NETWORK-RAW GeoJSON FeatureCollection to disk or S3.

Usage
-----
    # Fetch CAR + BIKE network for Deventer centrum:
    python -m osm_network_fetcher.osm_network_fetcher_runner \\
        --modes CAR BIKE \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder ./out/ \\
        --area-id deventer-centrum

    # With a custom Overpass endpoint:
    python -m osm_network_fetcher.osm_network_fetcher_runner \\
        --modes CAR BIKE PEDESTRIAN \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder s3://gmp-networks/network/ \\
        --area-id deventer-centrum \\
        --overpass-url https://overpass.kumi.systems/api/interpreter

Output files
------------
``{output_folder}{area_id}-NETWORK-RAW-{MODE}.parquet`` — one file per mode.

Prerequisites
-------------
* AWS credentials (only needed for s3:// output URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from uuid import uuid4


# ---------------------------------------------------------------------------
# sys.path bootstrap  (allows running as a script without install)
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):  # noqa: PLR2004
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for osm_network_fetcher — fetches a road network from "
            "the Overpass API and writes NETWORK-RAW GeoJSON files."
        )
    )
    parser.add_argument(
        "--modes",
        nargs="+",
        required=True,
        metavar="MODE",
        help="One or more transport modes: CAR, BIKE, PEDESTRIAN.",
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        required=True,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box in WGS 84.",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help=(
            "Output folder URI (s3://bucket/prefix/ or local directory). "
            "Output files are named {area_id}-NETWORK-RAW-{MODE}.parquet."
        ),
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help="Area identifier for output file naming (UUID generated if absent).",
    )
    parser.add_argument(
        "--name", default=None, help="Human-readable area name stored in FC properties (optional)."
    )
    parser.add_argument(
        "--overpass-url",
        default=None,
        metavar="URL",
        help=(
            "Overpass API endpoint URL. "
            "Defaults to the OVERPASS_URL environment variable, "
            "or https://overpass-api.de/api/interpreter."
        ),
    )
    parser.add_argument(
        "--overpass-timeout",
        type=int,
        default=90,
        metavar="SEC",
        help="Overpass request timeout in seconds (default: 90).",
    )
    parser.add_argument(
        "--osm-path",
        dest="osm_path",
        default=None,
        metavar="PATH",
        help=(
            "Path to a local .osm.pbf extract to read instead of querying the "
            "Overpass HTTP API. Falls back to the OSM_PBF_PATH environment "
            "variable / .env when omitted."
        ),
    )
    parser.add_argument(
        "--osm-workers",
        dest="osm_workers",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Worker processes for reading the local .osm.pbf extract. Defaults "
            "to the OSM_PBF_WORKERS environment variable / CPU count (capped at 8)."
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for AWS credentials.")
    parser.add_argument(
        "--no-elevation",
        dest="elevation",
        action="store_false",
        help=(
            "Disable Open-Meteo terrain-elevation gradients (keep only sparse "
            "OSM incline tags). Elevation gradients are computed by default."
        ),
    )
    parser.add_argument(
        "--elevation-url",
        dest="elevation_url",
        default=None,
        metavar="URL",
        help="Override the Open-Meteo elevation endpoint (default: public instance).",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    overpass_url: str = args.overpass_url or os.environ.get(
        "OVERPASS_URL", "https://overpass-api.de/api/interpreter"
    )

    from osm.osm_network_fetcher.core.osm_network_fetcher_core import (  # noqa: PLC0415
        VALID_MODES,
        apply_elevation_gradient,
        ways_to_features,
    )
    from osm.osm_network_fetcher.domain.network import LINK_PROPERTIES  # noqa: PLC0415
    from osm.osm_network_fetcher.domain.overpass import build_network_query  # noqa: PLC0415
    from shared.geoparquet import to_geoparquet  # noqa: PLC0415
    from shared.overpass import fetch_overpass  # noqa: PLC0415

    modes = [m.upper() for m in args.modes]
    invalid = [m for m in modes if m not in VALID_MODES]
    if invalid:
        parser.error(f"Unknown mode(s): {invalid!r}. Valid: {sorted(VALID_MODES)}")

    area_id = args.area_id or str(uuid4())
    bbox: list[float] = args.bbox
    output_folder = args.output_folder.rstrip("/") + "/"
    fields = list(LINK_PROPERTIES)

    print(f"Area ID        : {area_id}")
    print(f"BBox           : {bbox}")
    print(f"Modes          : {modes}")
    print(f"Overpass URL   : {overpass_url}")

    # Fetch all ways in one Overpass call (more efficient than one call per mode)
    query = build_network_query(bbox, modes)
    print("\nQuerying Overpass API …")
    data = fetch_overpass(
        query,
        url=overpass_url,
        timeout=args.overpass_timeout,
        osm_path=args.osm_path,
        osm_workers=args.osm_workers,
    )
    elements: list[dict] = data.get("elements") or []
    print(f"Overpass elements: {len(elements)}")

    all_mode_fcs: list[dict] = []

    for mode in modes:
        features = ways_to_features(elements, mode)
        print(f"\nMode {mode}: {len(features)} features")

        if args.elevation and features:
            print("  Fetching terrain elevation (Open-Meteo) …")
            try:
                n = apply_elevation_gradient(features, elevation_url=args.elevation_url)
                print(f"  Elevation gradient set on {n}/{len(features)} links")
            except Exception as exc:  # noqa: BLE001
                print(f"  Elevation step failed, keeping OSM incline: {exc}")

        fc: dict = {
            "type": "FeatureCollection",
            "crs": {"type": "name", "properties": {"name": "EPSG:4326"}},
            "features": features,
            "properties": {
                "modes": [mode],
                "fields": fields,
                "origin": "osm",
                "bbox": bbox,
                "area_id": area_id,
                **({"name": args.name} if args.name else {}),
            },
        }
        all_mode_fcs.append(fc)

        out_uri = f"{output_folder}{area_id}-NETWORK-RAW-{mode}.parquet"
        print(f"Writing        : {out_uri}")
        _write_uri(out_uri, to_geoparquet(fc))

    # When multiple modes were requested, write a combined MIXED parquet as
    # input for network_fuser / bidirectional_splitter.
    if len(all_mode_fcs) > 1:
        mixed_features = [f for fc in all_mode_fcs for f in fc["features"]]
        mixed_fc: dict = {
            "type": "FeatureCollection",
            "crs": {"type": "name", "properties": {"name": "EPSG:4326"}},
            "features": mixed_features,
            "properties": {
                "modes": modes,
                "fields": fields,
                "modeLabel": "MIXED",
                "origin": "osm",
                "bbox": bbox,
                "area_id": area_id,
                **({"name": args.name} if args.name else {}),
            },
        }
        mixed_uri = f"{output_folder}{area_id}-NETWORK-RAW-MIXED.parquet"
        print(f"\nMIXED ({len(mixed_features)} features): {mixed_uri}")
        _write_uri(mixed_uri, to_geoparquet(mixed_fc))

    print("\nDone.")


if __name__ == "__main__":
    main()
