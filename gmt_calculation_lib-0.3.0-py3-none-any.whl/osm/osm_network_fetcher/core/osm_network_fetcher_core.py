"""Pure-Python OSM network fetcher core — no I/O beyond Overpass HTTP.

Fetches a road network from the Overpass API for a bounding box and converts
OSM ways into the NETWORK-RAW LINK_PROPERTIES schema so that the downstream
``bidirectional_splitter`` and subsequent pipeline steps work unchanged.

Public API
----------
build_raw_network(bbox, modes, *, overpass_url, timeout) -> dict
    Fetch OSM ways and produce a merged NETWORK-RAW FeatureCollection.
ways_to_features(elements, mode) -> list[dict]
    Convert Overpass elements to LINK_PROPERTIES features for one mode.
LINK_PROPERTIES: tuple[str, ...]
    Ordered property keys for every NETWORK-RAW feature.
"""

from __future__ import annotations

import datetime
import logging

from osm.osm_network_fetcher.domain.network import (  # noqa: F401
    LINK_PROPERTIES,
    gradient_from_elevation,
    ways_to_features,
)
from osm.osm_network_fetcher.domain.overpass import (  # noqa: F401
    VALID_MODES,
    build_network_query,
)
from osm.osm_network_fetcher.domain.way_splitter import (  # noqa: F401
    haversine_m,
    segment_length_m,
    split_all_ways,
)
from shared.elevation import fetch_elevations
from shared.overpass import DEFAULT_OVERPASS_URL, fetch_overpass  # noqa: F401

logger = logging.getLogger(__name__)


def _coord_key(lon: float, lat: float) -> tuple[float, float]:
    """Round a ``(lon, lat)`` to a stable dedupe key (6 decimals ~= 0.1 m)."""
    return (round(lon, 6), round(lat, 6))


def apply_elevation_gradient(
    features: list[dict],
    *,
    elevation_url: str | None = None,
    batch_size: int = 100,
    timeout: int = 30,
) -> int:
    """Fill ``gradient_heen`` / ``gradient_terug`` from Open-Meteo elevations.

    Collects every unique link endpoint (network node) across *features*,
    fetches its terrain elevation from Open-Meteo in batches, then sets the
    per-link gradient from the elevation difference between the link's two
    endpoints divided by its horizontal length.  Elevation-derived gradients
    take precedence; links the API cannot resolve keep any OSM ``incline``
    gradient already present.

    Mutates *features* in place and returns the number of links updated.
    """
    if not features:
        return 0

    # 1. Collect unique endpoint coordinates (the graph nodes).
    order: list[tuple[float, float]] = []
    index: dict[tuple[float, float], int] = {}
    for feat in features:
        coords = feat.get("geometry", {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        for lon, lat in (coords[0], coords[-1]):
            key = _coord_key(lon, lat)
            if key not in index:
                index[key] = len(order)
                order.append((lat, lon))  # Open-Meteo wants (lat, lon)

    if not order:
        return 0

    logger.info("Fetching elevation for %d unique network nodes", len(order))
    elevations = fetch_elevations(order, url=elevation_url, batch_size=batch_size, timeout=timeout)
    elev_by_key: dict[tuple[float, float], float | None] = {
        _coord_key(lon, lat): elevations[i] for i, (lat, lon) in enumerate(order)
    }

    # 2. Derive per-link gradient from endpoint elevations.
    updated = 0
    for feat in features:
        coords = feat.get("geometry", {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        props = feat.setdefault("properties", {})
        elev_from = elev_by_key.get(_coord_key(coords[0][0], coords[0][1]))
        elev_to = elev_by_key.get(_coord_key(coords[-1][0], coords[-1][1]))
        grad = gradient_from_elevation(elev_from, elev_to, props.get("length"))
        if grad is None:
            continue
        props["gradient_heen"] = grad
        props["gradient_terug"] = -grad
        updated += 1

    logger.info("Elevation gradient set on %d/%d links", updated, len(features))
    return updated


def build_raw_network(
    bbox: list[float],
    modes: list[str],
    *,
    overpass_url: str = DEFAULT_OVERPASS_URL,
    timeout: int = 90,
    osm_path: str | None = None,
    osm_workers: int | None = None,
    elevation: bool = True,
    elevation_url: str | None = None,
) -> dict:
    """Fetch OSM ways via Overpass API and produce a NETWORK-RAW FeatureCollection.

    The output is schema-compatible with ``network_fetcher.rows_to_feature_collection``
    and can be passed directly to ``bidirectional_splitter.post_process_features``.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS 84.
    modes:
        Subset of ``["CAR", "BIKE", "PEDESTRIAN"]``.
    overpass_url:
        Overpass API endpoint URL.
    timeout:
        HTTP request timeout in seconds.
    elevation:
        When ``True`` (default), derive per-link gradients from Open-Meteo
        terrain elevation, overriding sparse OSM ``incline`` tags.
    elevation_url:
        Override for the Open-Meteo elevation endpoint (defaults to the public
        instance / ``ELEVATION_URL`` env var).

    Returns
    -------
    GeoJSON FeatureCollection dict.  The ``"properties"`` dict contains:
    - ``"modes"``:   list of mode strings
    - ``"fields"``:  list of LINK_PROPERTIES keys
    - ``"origin"``:  ``"osm"``
    - ``"bbox"``:    the input bbox
    - ``"created"``: ISO-8601 UTC timestamp

    Raises
    ------
    ValueError:
        If *modes* contains unsupported values or is empty.
    urllib.error.URLError / RuntimeError:
        On Overpass API errors.
    """
    modes_upper = [m.upper() for m in modes]
    invalid = [m for m in modes_upper if m not in VALID_MODES]
    if invalid:
        raise ValueError(f"Unsupported modes: {invalid!r}. Valid modes: {sorted(VALID_MODES)}")

    query = build_network_query(bbox, modes_upper)
    logger.info("Fetching OSM network  bbox=%s  modes=%s", bbox, modes_upper)
    data = fetch_overpass(
        query, url=overpass_url, timeout=timeout, osm_path=osm_path, osm_workers=osm_workers
    )
    elements: list[dict] = data.get("elements") or []
    logger.info("Overpass returned %d elements", len(elements))

    all_features: list[dict] = []
    for mode in modes_upper:
        features = ways_to_features(elements, mode)
        logger.info("Mode %-12s → %d features", mode, len(features))
        all_features.extend(features)

    # Derive per-link gradients from terrain elevation (Open-Meteo).  OSM
    # ``incline`` tags are sparse, so this fills the gap for most links.  On any
    # elevation-API failure we log and fall back to whatever OSM incline set.
    if elevation and all_features:
        try:
            apply_elevation_gradient(all_features, elevation_url=elevation_url)
        except Exception as exc:  # noqa: BLE001
            logger.warning("Elevation gradient step failed, keeping OSM incline: %s", exc)

    return {
        "type": "FeatureCollection",
        "crs": {
            "type": "name",
            "properties": {"name": "EPSG:4326"},
        },
        "features": all_features,
        "properties": {
            "modes": modes_upper,
            "fields": list(LINK_PROPERTIES),
            "origin": "osm",
            "bbox": bbox,
            "created": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        },
    }
