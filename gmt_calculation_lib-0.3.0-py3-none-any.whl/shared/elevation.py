"""Open-Meteo elevation API client — pure stdlib (urllib), no extra deps.

Used by ``elevation_annotator`` to look up the terrain elevation of every
directed network link endpoint, which it writes back as ``elevationFrom`` /
``elevationTo`` (metres above sea level).

The Open-Meteo elevation endpoint accepts batched coordinates via repeated
``latitude`` / ``longitude`` query values and returns a parallel ``elevation``
array (metres above sea level, ~90 m SRTM/Copernicus DEM resolution):

    GET https://api.open-meteo.com/v1/elevation?latitude=52.09,52.09&longitude=5.12,5.13
    -> {"elevation": [7.0, 8.0]}

A single request is limited to 100 coordinates, so :func:`fetch_elevations`
transparently splits larger inputs into batches.

Public API
----------
resolve_elevation_url(url) -> str
    Resolve the effective endpoint (arg > ``ELEVATION_URL`` env > default).
build_elevation_url(coords, base_url) -> str
    Build a single request URL for up to 100 ``(lat, lon)`` coordinates.
fetch_elevations(coords, *, url, batch_size, timeout, retries) -> list[float | None]
    Fetch elevations for a list of ``(lat, lon)`` coordinates, batched.
"""

from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.parse
import urllib.request

logger = logging.getLogger(__name__)

_ELEVATION_URL_FALLBACK = "https://api.open-meteo.com/v1/elevation"

#: Maximum number of coordinates Open-Meteo accepts in a single request.
MAX_BATCH_SIZE = 100


def resolve_elevation_url(url: str | None = None) -> str:
    """Resolve the effective Open-Meteo elevation endpoint at call time.

    Resolution order: an explicit non-empty *url*, then the ``ELEVATION_URL``
    environment variable, then the public Open-Meteo instance.  Resolving
    lazily means a ``.env`` file loaded after import is still honoured.
    """
    if url and url.strip():
        return url.strip()
    env_url = os.environ.get("ELEVATION_URL", "").strip()
    return env_url or _ELEVATION_URL_FALLBACK


def build_elevation_url(
    coords: list[tuple[float, float]],
    base_url: str | None = None,
) -> str:
    """Build an Open-Meteo elevation request URL for *coords*.

    Parameters
    ----------
    coords:
        List of ``(lat, lon)`` tuples in WGS 84.  Must not exceed
        :data:`MAX_BATCH_SIZE` entries.
    base_url:
        Endpoint URL; defaults to the resolved Open-Meteo instance.

    Returns
    -------
    A fully-formed GET URL string.

    Raises
    ------
    ValueError:
        If *coords* is empty or exceeds :data:`MAX_BATCH_SIZE`.
    """
    if not coords:
        raise ValueError("coords must not be empty")
    if len(coords) > MAX_BATCH_SIZE:
        raise ValueError(f"coords exceeds max batch size ({len(coords)} > {MAX_BATCH_SIZE})")
    url = resolve_elevation_url(base_url)
    lat_str = ",".join(_fmt(lat) for lat, _ in coords)
    lon_str = ",".join(_fmt(lon) for _, lon in coords)
    query = urllib.parse.urlencode({"latitude": lat_str, "longitude": lon_str})
    return f"{url}?{query}"


def _fmt(value: float) -> str:
    """Format a coordinate to a compact, stable string (6 decimals ~= 0.1 m)."""
    return f"{value:.6f}"


def _fetch_batch(
    coords: list[tuple[float, float]],
    *,
    url: str | None,
    timeout: int,
    retries: int,
) -> list[float | None]:
    """Fetch elevations for a single batch (<= MAX_BATCH_SIZE coords)."""
    request_url = build_elevation_url(coords, url)
    last_exc: Exception | None = None
    body: str = ""
    for attempt in range(retries):
        if attempt > 0:
            wait = 2**attempt
            logger.warning(
                "Elevation retry %d/%d after %.0fs (last error: %s)",
                attempt,
                retries - 1,
                wait,
                last_exc,
            )
            time.sleep(wait)
        try:
            req = urllib.request.Request(request_url, method="GET")  # noqa: S310
            req.add_header("User-Agent", "gmt-calculation-lib/1.0")
            req.add_header("Accept", "application/json")
            with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
                if resp.status in (429, 500, 502, 503, 504):
                    raise urllib.error.HTTPError(
                        request_url, resp.status, resp.reason, resp.headers, None
                    )
                body = resp.read().decode("utf-8")
            break
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504):
                last_exc = exc
                continue
            raise
        except urllib.error.URLError as exc:
            last_exc = exc
            continue
    else:
        raise last_exc  # type: ignore[misc]

    try:
        data = json.loads(body)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Elevation API returned invalid JSON: {exc}") from exc

    elevations = data.get("elevation")
    if not isinstance(elevations, list) or len(elevations) != len(coords):
        raise RuntimeError(
            f"Elevation API returned {len(elevations) if isinstance(elevations, list) else 'no'} "
            f"values for {len(coords)} coordinates"
        )
    return [float(e) if e is not None else None for e in elevations]


def fetch_elevations(
    coords: list[tuple[float, float]],
    *,
    url: str | None = None,
    batch_size: int = MAX_BATCH_SIZE,
    timeout: int = 30,
    retries: int = 3,
) -> list[float | None]:
    """Fetch terrain elevations for a list of ``(lat, lon)`` coordinates.

    The input is split into batches of at most *batch_size* (capped at
    :data:`MAX_BATCH_SIZE`) and each batch is fetched with retries on transient
    errors.  The returned list is parallel to *coords*; entries the API could
    not resolve are ``None``.

    Parameters
    ----------
    coords:
        List of ``(lat, lon)`` tuples in WGS 84.
    url:
        Endpoint URL; defaults to the resolved Open-Meteo instance.
    batch_size:
        Coordinates per request (<= :data:`MAX_BATCH_SIZE`).
    timeout:
        HTTP request timeout in seconds per batch.
    retries:
        Maximum retry attempts per batch on transient errors.

    Returns
    -------
    List of elevations (metres), parallel to *coords*; ``None`` where unknown.
    """
    if not coords:
        return []
    step = max(1, min(batch_size, MAX_BATCH_SIZE))
    out: list[float | None] = []
    n_batches = (len(coords) + step - 1) // step
    for i in range(0, len(coords), step):
        batch = coords[i : i + step]
        logger.info(
            "Elevation batch %d/%d  (%d coords)",
            i // step + 1,
            n_batches,
            len(batch),
        )
        out.extend(_fetch_batch(batch, url=url, timeout=timeout, retries=retries))
    return out
