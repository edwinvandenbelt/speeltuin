"""Unit tests for osm_asset_fetcher core (pure functions + stubbed Overpass)."""

from __future__ import annotations

from osm_asset_fetcher.core.osm_asset_fetcher_core import (
    DEFAULT_KINDS,
    KIND_BIKE_GATE,
    KIND_BUS_SHELTER,
    KIND_BUS_STOP,
    KIND_CYCLE_PATH,
    KIND_FOOT_PATH,
    KIND_GIVE_WAY,
    KIND_INFO_BOARD,
    KIND_MAILBOX,
    KIND_MAST,
    KIND_MINI_ROUNDABOUT,
    KIND_PEDESTRIAN_CROSSING,
    KIND_SPEED_BUMP,
    KIND_STOP_SIGN,
    KIND_STREET_LIGHT,
    KIND_TRASH_BIN,
    OSM_ASSET_QUERY_VER,
    classify_element,
    elements_to_asset_features,
    fetch_osm_assets,
    overpass_query_for_bbox,
)

_BBOX = [6.39, 52.14, 6.43, 52.17]


# ---------------------------------------------------------------------------
# classify_element
# ---------------------------------------------------------------------------


def test_classify_element_matches_each_kind() -> None:
    assert classify_element({"highway": "crossing"}, DEFAULT_KINDS) == KIND_PEDESTRIAN_CROSSING
    assert classify_element({"traffic_calming": "bump"}, DEFAULT_KINDS) == KIND_SPEED_BUMP
    assert classify_element({"highway": "stop"}, DEFAULT_KINDS) == KIND_STOP_SIGN
    assert classify_element({"highway": "give_way"}, DEFAULT_KINDS) == KIND_GIVE_WAY
    assert classify_element({"highway": "mini_roundabout"}, DEFAULT_KINDS) == KIND_MINI_ROUNDABOUT


def test_classify_element_matches_new_kinds() -> None:
    assert classify_element({"amenity": "post_box"}, DEFAULT_KINDS) == KIND_MAILBOX
    assert (
        classify_element({"amenity": "shelter", "shelter_type": "public_transport"}, DEFAULT_KINDS)
        == KIND_BUS_SHELTER
    )
    assert classify_element({"man_made": "mast"}, DEFAULT_KINDS) == KIND_MAST
    assert classify_element({"barrier": "cycle_barrier"}, DEFAULT_KINDS) == KIND_BIKE_GATE
    assert classify_element({"information": "board"}, DEFAULT_KINDS) == KIND_INFO_BOARD
    assert classify_element({"amenity": "waste_basket"}, DEFAULT_KINDS) == KIND_TRASH_BIN
    assert classify_element({"highway": "bus_stop"}, DEFAULT_KINDS) == KIND_BUS_STOP
    assert classify_element({"highway": "street_lamp"}, DEFAULT_KINDS) == KIND_STREET_LIGHT


def test_classify_element_bus_shelter_requires_both_tags() -> None:
    # A generic (non-PT) shelter must not be classified as a bus shelter.
    assert classify_element({"amenity": "shelter"}, DEFAULT_KINDS) is None
    assert (
        classify_element({"amenity": "shelter", "shelter_type": "picnic_shelter"}, DEFAULT_KINDS)
        is None
    )


def test_classify_element_returns_none_for_unmatched() -> None:
    assert classify_element({"highway": "residential"}, DEFAULT_KINDS) is None
    assert classify_element({}, DEFAULT_KINDS) is None


def test_classify_element_respects_requested_kinds() -> None:
    # speedBump excluded from the requested kinds -> not classified.
    assert classify_element({"traffic_calming": "hump"}, [KIND_PEDESTRIAN_CROSSING]) is None


# ---------------------------------------------------------------------------
# overpass_query_for_bbox
# ---------------------------------------------------------------------------


def test_overpass_query_uses_south_west_north_east_order() -> None:
    query = overpass_query_for_bbox(_BBOX, [KIND_STOP_SIGN], timeout=30)
    # Overpass order: south,west,north,east => minLat,minLon,maxLat,maxLon
    assert "52.14,6.39,52.17,6.43" in query
    assert '"highway"="stop"' in query
    assert "[timeout:30]" in query


def test_overpass_query_skips_unknown_kinds() -> None:
    query = overpass_query_for_bbox(_BBOX, ["notAKind", KIND_SPEED_BUMP])
    assert '"traffic_calming"' in query
    assert "notAKind" not in query


def test_overpass_query_includes_new_kind_filters() -> None:
    query = overpass_query_for_bbox(_BBOX, DEFAULT_KINDS)
    assert '"amenity"="post_box"' in query
    assert '"man_made"="mast"' in query
    assert '"barrier"="cycle_barrier"' in query
    assert '"information"="board"' in query
    assert '"amenity"="waste_basket"' in query
    assert '"highway"="bus_stop"' in query
    assert '"highway"="street_lamp"' in query
    # Bus shelter is a chained multi-tag selector (logical AND).
    assert 'node["amenity"="shelter"]["shelter_type"="public_transport"]' in query


def test_overpass_query_emits_way_selector_for_bus_shelter() -> None:
    query = overpass_query_for_bbox(_BBOX, DEFAULT_KINDS)
    # Bus shelters may be mapped as areas, so a way selector is emitted too.
    assert 'way["amenity"="shelter"]["shelter_type"="public_transport"]' in query
    # Way geometry is required to compute a centroid.
    assert "out geom;" in query
    # Node-only kinds must NOT emit a way selector.
    assert 'way["highway"="bus_stop"]' not in query
    assert 'way["highway"="street_lamp"]' not in query


def test_way_bus_shelter_reduced_to_centroid() -> None:
    elements = [
        {
            "type": "way",
            "id": 1551673111,
            "tags": {"amenity": "shelter", "shelter_type": "public_transport"},
            "geometry": [
                {"lat": 52.0, "lon": 6.0},
                {"lat": 52.0, "lon": 6.2},
                {"lat": 52.2, "lon": 6.2},
                {"lat": 52.2, "lon": 6.0},
                {"lat": 52.0, "lon": 6.0},
            ],
        },
        # A crossing way must still be dropped (not a way-capable kind).
        {"type": "way", "id": 2, "tags": {"highway": "crossing"}, "geometry": []},
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    assert len(feats) == 1
    assert feats[0]["properties"]["assetType"] == KIND_BUS_SHELTER
    assert feats[0]["properties"]["osm_id"] == 1551673111
    assert feats[0]["geometry"]["type"] == "Point"
    # Closing vertex dropped -> centroid of the 4 distinct corners.
    assert feats[0]["geometry"]["coordinates"] == [6.1, 52.1]


# ---------------------------------------------------------------------------
# elements_to_asset_features
# ---------------------------------------------------------------------------


def test_elements_to_asset_features_tags_and_filters() -> None:
    elements = [
        {"type": "node", "id": 1, "lat": 52.15, "lon": 6.40, "tags": {"highway": "crossing"}},
        {"type": "node", "id": 2, "lat": 52.15, "lon": 6.41, "tags": {"highway": "residential"}},
        {"type": "way", "id": 3, "tags": {"highway": "crossing"}},
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    assert len(feats) == 1
    assert feats[0]["geometry"] == {"type": "Point", "coordinates": [6.40, 52.15]}
    assert feats[0]["properties"]["assetType"] == KIND_PEDESTRIAN_CROSSING
    assert feats[0]["properties"]["osm_id"] == 1


def test_elements_to_asset_features_new_kinds() -> None:
    elements = [
        {"type": "node", "id": 10, "lat": 52.15, "lon": 6.40, "tags": {"amenity": "post_box"}},
        {
            "type": "node",
            "id": 11,
            "lat": 52.15,
            "lon": 6.41,
            "tags": {"amenity": "shelter", "shelter_type": "public_transport"},
        },
        {"type": "node", "id": 12, "lat": 52.15, "lon": 6.42, "tags": {"highway": "bus_stop"}},
        {"type": "node", "id": 14, "lat": 52.15, "lon": 6.44, "tags": {"highway": "street_lamp"}},
        {"type": "node", "id": 13, "lat": 52.15, "lon": 6.43, "tags": {"amenity": "shelter"}},
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    types = {f["properties"]["osm_id"]: f["properties"]["assetType"] for f in feats}
    assert types == {
        10: KIND_MAILBOX,
        11: KIND_BUS_SHELTER,
        12: KIND_BUS_STOP,
        14: KIND_STREET_LIGHT,
    }


# ---------------------------------------------------------------------------
# cycle- / foot-path line features (Verzoek 2)
# ---------------------------------------------------------------------------


def test_overpass_query_emits_way_only_selector_for_line_kinds() -> None:
    query = overpass_query_for_bbox(_BBOX, [KIND_CYCLE_PATH, KIND_FOOT_PATH])
    # Linear paths are OSM ways only -> a way selector, never a node selector.
    assert 'way["highway"="cycleway"]' in query
    assert 'way["highway"~"^(footway|path|pedestrian)$"]' in query
    assert 'node["highway"="cycleway"]' not in query
    assert 'node["highway"~"^(footway|path|pedestrian)$"]' not in query


def test_classify_element_matches_line_kinds() -> None:
    assert classify_element({"highway": "cycleway"}, DEFAULT_KINDS) == KIND_CYCLE_PATH
    assert classify_element({"highway": "footway"}, DEFAULT_KINDS) == KIND_FOOT_PATH
    assert classify_element({"highway": "path"}, DEFAULT_KINDS) == KIND_FOOT_PATH
    assert classify_element({"highway": "pedestrian"}, DEFAULT_KINDS) == KIND_FOOT_PATH


def test_cycle_path_way_becomes_linestring_with_attributes() -> None:
    elements = [
        {
            "type": "way",
            "id": 987654,
            "tags": {
                "highway": "cycleway",
                "width": "2,5 m",
                "oneway": "yes",
                "segregated": "no",
                "surface": "asphalt",
                "lit": "yes",
            },
            "geometry": [
                {"lat": 52.10, "lon": 6.40},
                {"lat": 52.11, "lon": 6.41},
                {"lat": 52.12, "lon": 6.42},
            ],
        }
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    assert len(feats) == 1
    feat = feats[0]
    assert feat["geometry"]["type"] == "LineString"
    assert feat["geometry"]["coordinates"] == [[6.40, 52.10], [6.41, 52.11], [6.42, 52.12]]
    props = feat["properties"]
    assert props["assetType"] == KIND_CYCLE_PATH
    assert props["osm_id"] == 987654
    assert props["pathType"] == "separated"
    assert props["width"] == 2.5
    assert props["oneway"] is True
    assert props["segregated"] is False
    assert props["surface"] == "asphalt"
    assert props["lit"] is True


def test_foot_path_way_derives_defaults_for_missing_attributes() -> None:
    elements = [
        {
            "type": "way",
            "id": 555,
            "tags": {"highway": "footway"},
            "geometry": [
                {"lat": 52.10, "lon": 6.40},
                {"lat": 52.11, "lon": 6.41},
            ],
        }
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    assert len(feats) == 1
    props = feats[0]["properties"]
    assert props["assetType"] == KIND_FOOT_PATH
    assert props["pathType"] == "separated"
    assert props["width"] is None
    assert props["oneway"] is False
    assert props["segregated"] is False
    assert props["surface"] is None
    assert props["lit"] is None


def test_cycleway_lane_derives_lane_path_type() -> None:
    elements = [
        {
            "type": "way",
            "id": 42,
            "tags": {"highway": "cycleway", "cycleway": "lane"},
            "geometry": [
                {"lat": 52.10, "lon": 6.40},
                {"lat": 52.11, "lon": 6.41},
            ],
        }
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    # highway=cycleway itself is standalone-separated; explicit highway wins.
    assert feats[0]["properties"]["pathType"] == "separated"


def test_line_kind_way_with_too_few_vertices_is_dropped() -> None:
    elements = [
        {
            "type": "way",
            "id": 7,
            "tags": {"highway": "cycleway"},
            "geometry": [{"lat": 52.10, "lon": 6.40}],
        }
    ]
    assert elements_to_asset_features(elements, DEFAULT_KINDS) == []


# ---------------------------------------------------------------------------
# fetch_osm_assets — stubbed Overpass client
# ---------------------------------------------------------------------------


def test_fetch_osm_assets_empty_kinds_skips() -> None:
    fc, stats = fetch_osm_assets(_BBOX, kinds=[])
    assert stats["source"] == "skipped"
    assert stats["total"] == 0
    assert fc["features"] == []


def test_fetch_osm_assets_counts_by_type(monkeypatch) -> None:
    def _fake_tiled(_query_fn, _bbox, **_kwargs) -> dict:
        return {
            "elements": [
                {"type": "node", "id": 1, "lat": 52.15, "lon": 6.40, "tags": {"highway": "stop"}},
                {"type": "node", "id": 2, "lat": 52.16, "lon": 6.41, "tags": {"highway": "stop"}},
                {
                    "type": "node",
                    "id": 3,
                    "lat": 52.16,
                    "lon": 6.42,
                    "tags": {"highway": "crossing"},
                },
            ]
        }

    monkeypatch.setattr("shared.overpass.fetch_overpass_tiled", _fake_tiled, raising=True)

    fc, stats = fetch_osm_assets(_BBOX, kinds=[KIND_STOP_SIGN, KIND_PEDESTRIAN_CROSSING])
    assert stats["source"] == "OSM"
    assert stats["total"] == 3
    assert stats["counts"][KIND_STOP_SIGN] == 2
    assert stats["counts"][KIND_PEDESTRIAN_CROSSING] == 1
    assert fc["properties"]["_qv"] == OSM_ASSET_QUERY_VER
