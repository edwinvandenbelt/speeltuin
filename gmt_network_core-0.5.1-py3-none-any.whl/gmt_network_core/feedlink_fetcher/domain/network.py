"""Network GeoJSON parser for feedlink_fetcher — extracts node positions."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def parse_network_geojson(fc: dict) -> tuple[dict, set]:
    """Parse a network FeatureCollection into node lookup tables.

    Parameters
    ----------
    fc:
        GeoJSON FeatureCollection of directed network link features.

    Returns
    -------
    tuple[dict, set]
        ``(node_positions, all_node_ids)`` where *node_positions* maps
        ``node_id → (lon, lat)`` and *all_node_ids* is the complete set of
        node IDs seen in the network.
    """
    features = fc.get("features") or []
    node_positions: dict = {}

    for feat in features:
        props = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords:
            continue
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is not None:
            node_positions.setdefault(from_node, (coords[0][0], coords[0][1]))
        if to_node is not None:
            node_positions.setdefault(to_node, (coords[-1][0], coords[-1][1]))

    all_node_ids = set(node_positions.keys())
    logger.info("Parsed network: %d features, %d nodes", len(features), len(all_node_ids))
    return node_positions, all_node_ids
