# Databricks notebook source
# ---------------------------------------------------------------------------
# feedlink_fetcher_nb.py — Databricks notebook for feedlink_fetcher.
#
# This notebook:
#   1. Reads widget parameters (zones_uri, network_uri, output_folder, mode, …).
#   2. Loads zones (zone_fetcher output) and network GeoJSON from full URIs.
#   3. Queries the voedingslinks table via spark.sql() using the SQL string
#      built by feedlink_fetcher.core.feedlink_fetcher_core.build_voedingslinks_sql().
#   4. Calls feedlink_fetcher.core.feedlink_fetcher_core.build_feedlinks() — pure Python.
#   5. Writes output to output_folder:
#        {area_id}-FEEDLINK-{mode}.geojson
#
# Requirements (Databricks cluster):
#   pip install boto3   (only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text("zones_uri", "", "Full URI of the zones GeoJSON (zone_fetcher output)")
dbutils.widgets.text("network_uri", "", "Full URI of the directed network GeoJSON")
dbutils.widgets.text("output_folder", "", "Output folder: s3://bucket/prefix  or  /dbfs/path")
dbutils.widgets.text("area_id", "", "Area identifier (resolved from network when blank)")
dbutils.widgets.text("mode", "CAR", "Transport mode")
dbutils.widgets.text("catalog", "spectrum", "Unity Catalog name")
dbutils.widgets.text("schema", "2024_01", "Schema / dataset version")

# COMMAND ----------
ZONES_URI = dbutils.widgets.get("zones_uri").strip()
NETWORK_URI = dbutils.widgets.get("network_uri").strip()
OUT_FOLDER = dbutils.widgets.get("output_folder").strip()
AREA_ID = dbutils.widgets.get("area_id").strip()
MODE = dbutils.widgets.get("mode").strip().upper()
CATALOG = dbutils.widgets.get("catalog").strip()
SCHEMA = dbutils.widgets.get("schema").strip()

if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' must not be empty.")
if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' must not be empty.")
if not OUT_FOLDER:
    raise ValueError("Widget 'output_folder' must not be empty.")

# COMMAND ----------
from gmt_shared.output_path import build_output_path

from gmt_network_core.feedlink_fetcher.core.feedlink_fetcher_core import (
    VOEDINGSLINKS_TABLE,
    build_feedlinks,
    build_voedingslinks_sql,
    parse_network_geojson,
)

# COMMAND ----------


def _read_bytes(uri: str) -> bytes:
    if uri.startswith("s3://"):
        import boto3

        bucket, _, key = uri[5:].partition("/")
        return boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_bytes(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        import boto3

        bucket, _, key = uri[5:].partition("/")
        boto3.client("s3").put_object(Bucket=bucket, Key=key, Body=data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)


# COMMAND ----------
zones_fc = json.loads(_read_bytes(ZONES_URI))
network_fc = json.loads(_read_bytes(NETWORK_URI))

area_id = AREA_ID or (network_fc.get("properties") or {}).get("area_id")
if not area_id:
    import uuid

    area_id = str(uuid.uuid4())
    logger.warning("area_id auto-generated: %s", area_id)

node_positions, all_node_ids = parse_network_geojson(network_fc)

# COMMAND ----------
table_name = VOEDINGSLINKS_TABLE.get(MODE)
vl_rows = []
if table_name:
    gids = [
        int(feat["properties"]["gid"])
        for feat in zones_fc.get("features") or []
        if (feat.get("properties") or {}).get("zoneClass") != "AREA"
        and (feat.get("properties") or {}).get("gid") is not None
    ]
    sql = build_voedingslinks_sql(CATALOG, SCHEMA, table_name, gids)
    logger.info("Querying voedingslinks: table=%s  gids=%d", table_name, len(gids))
    rows = spark.sql(sql).collect()
    col_names = [f.name for f in spark.sql(sql).schema.fields]
    vl_rows = [dict(zip(col_names, row, strict=False)) for row in rows]
    logger.info("Voedingslinks rows: %d", len(vl_rows))
else:
    logger.info("No voedingslinks table for mode %s — skipping.", MODE)

# COMMAND ----------
feedlinks_fc = build_feedlinks(zones_fc, node_positions, all_node_ids, vl_rows, MODE)
feedlinks_fc.setdefault("properties", {})["area_id"] = area_id
logger.info("Feedlinks produced: %d", len(feedlinks_fc["features"]))

out_uri = build_output_path(OUT_FOLDER, area_id, "FEEDLINK", MODE)
_write_bytes(out_uri, json.dumps(feedlinks_fc, ensure_ascii=False).encode("utf-8"))
logger.info("Written: %s", out_uri)
