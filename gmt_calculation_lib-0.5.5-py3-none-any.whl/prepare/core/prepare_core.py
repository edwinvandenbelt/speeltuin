"""
prepare_core.py — GMT preparation pipeline orchestration logic.

Contains the full 10-step pipeline (zone_fetcher → matrix_builder) plus all
supporting helpers.  Import and call ``run_pipeline`` from a local runner,
notebook, or Lambda handler.

All steps execute in-process (no subprocess).  Only the four final outputs are
written to disk:

  {area_id}-NETWORK-{modeLabel}.parquet
  {area_id}-FEEDLINK-{modeLabel}.parquet
  {area_id}-ZONE-{mode}.parquet         (one file per mode — never MIXED)
  {area_id}-ROUTES-{mode}.parquet       (one file per mode — never MIXED)

Resume / checkpointing
----------------------
Each stage output is persisted as a compact GeoParquet checkpoint under
``<out_dir>/_checkpoints/``.  If a run crashes, re-running it resumes from the
last completed stage instead of recomputing everything (see
``_CheckpointStore``).  The checkpoint directory is removed automatically once
the pipeline completes successfully, so only the real outputs remain.  Passing
``refresh=True`` wipes any existing checkpoints and recomputes from scratch.

For PEDESTRIAN mode (single mode only) the pipeline ends after step 7
(parallel_link_finder) and writes:

  {area_id}-NETWORK-PEDESTRIAN.parquet
  {area_id}-ZONE-PEDESTRIAN.parquet

Multimodal networks
-------------------
Pass a list of two or more modes together with an external label:

  run_pipeline(..., modes=["CAR", "BIKE"], mode_label="MIXED")

Each road segment in the combined network retains its own ``"mode"`` property
(``"CAR"`` or ``"BIKE"``).  The FeatureCollection-level ``"modes"`` list and
the ``"modeLabel"`` property identify the combination.  PEDESTRIAN cannot be
combined with other modes.  The external label must not contain a hyphen
(the adjust pipeline uses hyphens to distinguish derived artefacts).

Intermediate results are kept in memory and optionally snapshotted as
``STEP_{n}_…`` files when *debug=True*.
"""

from __future__ import annotations

import concurrent.futures
import contextlib
import csv
import io
import json
import os
import shutil
import sys
import threading
import time
import uuid
from dataclasses import dataclass, field
from pathlib import Path

from gmt_shared.geo import is_bbox_fully_in_netherlands
from gmt_shared.geo import is_netherlands as _is_netherlands
from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

# ---------------------------------------------------------------------------
# Repo-root paths
# ---------------------------------------------------------------------------

_CORE_FILE = Path(__file__).resolve()
_REPO_ROOT = _CORE_FILE.parent.parent.parent.parent  # src/prepare/core/ -> repo root
ARTIFACTS = _REPO_ROOT / "artifacts"

# ---------------------------------------------------------------------------
# Step constants
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# PT mode set
# ---------------------------------------------------------------------------

_PT_MODES = {"BUS", "TRAM", "METRO", "TRAIN"}

# ---------------------------------------------------------------------------
# UUID helpers
# ---------------------------------------------------------------------------

# Product-type markers that separate the area-id prefix from the rest of a
# filename.  Listed in rough "most likely to be present" order.
_ID_MARKERS = (
    "-NETWORK-",
    "-ROUTES-",
    "-ZONE-",
    "-FEEDLINK-",
    "-ZONES.",
    "-SIMPLIFIED-NODES-",
)


def _discover_or_create_area_id(out_dir: Path, area_id: str | None = None) -> str:
    """Return the area UUID to use for *out_dir*.

    Priority
    --------
    1. Explicit *area_id* override (passed by the caller / ``--area-id`` CLI arg).
    2. UUID prefix of the first ``.parquet`` file in *out_dir* whose stem
       contains a known product-type marker (re-run of an existing area).
    3. Fresh :func:`uuid.uuid4` (first run / empty folder).

    No sidecar file is read or written.
    """
    if area_id:
        return area_id
    for f in sorted(out_dir.glob("*.parquet")):
        stem = f.stem
        for marker in _ID_MARKERS:
            idx = stem.find(marker)
            if idx > 0:
                return stem[:idx]
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Debug snapshot helper
# ---------------------------------------------------------------------------


def _snapshot(step_num: int, area_id: str, out_dir: Path, **named_fcs: dict) -> None:
    """Write named in-memory FeatureCollections to ``STEP_{n}_{area_id}_{PRODUCT}.geojson``."""
    for product, fc in named_fcs.items():
        if fc is None:
            print(f"  [debug] snapshot skipped — {product} is None")
            continue
        dst = out_dir / f"STEP_{step_num}_{area_id}_{product}.geojson"
        dst.write_text(json.dumps(fc, ensure_ascii=False), encoding="utf-8")
        n = len(fc.get("features") or [])
        print(f"  [debug] snapshot -> {dst.name}  ({n} features)")


# ---------------------------------------------------------------------------
# Checkpoint / resume helper
# ---------------------------------------------------------------------------


class _CheckpointStore:
    """Persist per-stage FeatureCollections so a crashed run can resume.

    Each stage output is stored as a GeoParquet file under
    ``<out_dir>/_checkpoints/``.  On a restart the pipeline loads any stage
    whose checkpoint already exists instead of recomputing it; only the stages
    after the last completed one are re-run.

    * ``refresh=True`` wipes any existing checkpoints up front and disables
      loading, so everything is recomputed from scratch.
    * :meth:`clear` removes the whole checkpoint directory — call it once the
      pipeline has completed successfully so only the real outputs remain.

    Writes are atomic (temp file + ``os.replace``) so a crash mid-write can
    never leave a half-written checkpoint that would be picked up on resume.
    """

    _DIRNAME = "_checkpoints"

    def __init__(self, out_dir: Path, *, refresh: bool) -> None:
        self.dir = out_dir / self._DIRNAME
        self.refresh = refresh
        if refresh:
            self.clear()
        self.dir.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        return self.dir / f"{key}.parquet"

    def load(self, key: str) -> dict | None:
        """Return the checkpointed FeatureCollection for *key*, or ``None``."""
        if self.refresh:
            return None
        path = self._path(key)
        if not path.exists():
            return None
        try:
            fc = from_geoparquet(path.read_bytes())
        except Exception as exc:
            print(f"  [resume] ignoring unreadable checkpoint '{key}': {exc}")
            return None
        print(f"  [resume] loaded checkpoint '{key}' ({len(fc.get('features') or [])} features)")
        return fc

    def save(self, key: str, fc: dict) -> None:
        """Atomically persist *fc* under *key*."""
        tmp = self.dir / f"{key}.parquet.tmp"
        tmp.write_bytes(to_geoparquet(fc))
        tmp.replace(self._path(key))

    def clear(self) -> None:
        """Remove the entire checkpoint directory (no-op if absent)."""
        shutil.rmtree(self.dir, ignore_errors=True)


def _resolve_osm_flags(
    *,
    no_dt: bool,
    annotate_traffic_signals: bool,
    fetch_traffic_signs: bool,
    fetch_osm_assets: bool,
    fetch_buildings: bool,
    fetch_vegetation: bool,
    fetch_parking_areas: bool,
    fetch_bgt_assets: bool,
    ndw_available: bool,
) -> dict[str, bool]:
    """Resolve the effective stage-5 fetch flags given the ``no_dt`` switch.

    When *no_dt* is ``False`` all incoming flags pass through unchanged.  When
    *no_dt* is ``True`` every digital-twin enrichment source is disabled — both
    the OSM/Overpass-dependent sources and the BGT/PDOK sources:

    * ``annotate_traffic_signals`` -> off   (pure OSM Overpass)
    * ``fetch_osm_assets``         -> off   (pure OSM Overpass)
    * ``fetch_buildings``          -> off   (pure OSM Overpass)
    * ``fetch_vegetation``         -> off   (pure OSM Overpass)
    * ``fetch_bgt_assets``         -> off   (BGT/PDOK)
    * ``fetch_traffic_signs``      -> only kept on when NDW data is available
      (the Overpass fallback is suppressed)
    * ``fetch_parking_areas``      -> off   (both the OSM and BGT legs are
      digital-twin sources, so parking is skipped entirely)

    Returns a dict with the resolved booleans plus ``parking_use_osm``.
    """
    if not no_dt:
        return {
            "annotate_traffic_signals": annotate_traffic_signals,
            "fetch_traffic_signs": fetch_traffic_signs,
            "fetch_osm_assets": fetch_osm_assets,
            "fetch_buildings": fetch_buildings,
            "fetch_vegetation": fetch_vegetation,
            "fetch_parking_areas": fetch_parking_areas,
            "fetch_bgt_assets": fetch_bgt_assets,
            "parking_use_osm": True,
        }
    return {
        "annotate_traffic_signals": False,
        "fetch_traffic_signs": fetch_traffic_signs and ndw_available,
        "fetch_osm_assets": False,
        "fetch_buildings": False,
        "fetch_vegetation": False,
        "fetch_parking_areas": False,
        "fetch_bgt_assets": False,
        "parking_use_osm": False,
    }


def _stage_fc(store: _CheckpointStore, key: str, produce) -> dict:
    """Return the checkpointed FeatureCollection for *key* or compute + save it.

    *produce* is a zero-argument callable that runs the stage and returns the
    resulting FeatureCollection.  It is only called on a cache miss.
    """
    cached = store.load(key)
    if cached is not None:
        return cached
    fc = produce()
    store.save(key, fc)
    return fc


# ---------------------------------------------------------------------------
# Mode-filter helper
# ---------------------------------------------------------------------------


def _filter_fc_by_mode(fc: dict, mode: str) -> dict:
    """Return a shallow copy of *fc* containing only features with ``mode == mode``.

    Used by the matrix-builder step to build a per-mode routing graph from a
    combined (MIXED) network FeatureCollection.  Features whose ``mode`` property
    is absent or does not match are excluded.
    """
    features = [
        f for f in (fc.get("features") or []) if (f.get("properties") or {}).get("mode") == mode
    ]
    return {**fc, "features": features}


# ---------------------------------------------------------------------------
# Zone-fetcher geometry helpers
# ---------------------------------------------------------------------------


def _bbox_polygon_geom(min_lon: float, min_lat: float, max_lon: float, max_lat: float) -> dict:
    """Return a GeoJSON Polygon geometry dict for the given bounding box."""
    return {
        "type": "Polygon",
        "coordinates": [
            [
                [min_lon, min_lat],
                [max_lon, min_lat],
                [max_lon, max_lat],
                [min_lon, max_lat],
                [min_lon, min_lat],
            ]
        ],
    }


def _extract_area_polygon_json(zones_fc: dict) -> str:
    """Return the GeoJSON geometry string of the AREA feature in *zones_fc*.

    Raises ``ValueError`` when no AREA feature is found.
    """
    for feature in zones_fc.get("features", []):
        if (feature.get("properties") or {}).get("zoneClass") == "AREA":
            return json.dumps(feature["geometry"])
    raise ValueError("No AREA feature found in zones FeatureCollection")


def _collect_lon_lats(geometry: dict | None) -> list[tuple[float, float]]:
    """Recursively collect all ``(lon, lat)`` pairs from a GeoJSON geometry."""
    if not geometry:
        return []
    gtype = geometry.get("type", "")
    coords = geometry.get("coordinates")
    if gtype == "Point":
        return [(coords[0], coords[1])] if coords else []
    if gtype in ("MultiPoint", "LineString"):
        return [(p[0], p[1]) for p in coords] if coords else []
    if gtype in ("MultiLineString", "Polygon"):
        return [(p[0], p[1]) for ring in (coords or []) for p in ring]
    if gtype == "MultiPolygon":
        return [(p[0], p[1]) for poly in (coords or []) for ring in poly for p in ring]
    if gtype == "GeometryCollection":
        result: list[tuple[float, float]] = []
        for g in geometry.get("geometries", []):
            result.extend(_collect_lon_lats(g))
        return result
    return []


def _zones_union_bbox(zones_fc: dict | None, fallback_bbox: list[float]) -> list[float]:
    """Return a bbox covering *fallback_bbox* plus the AREA zone geometry (if any).

    The ``AREA`` feature in *zones_fc* is the convex hull of every STUDY +
    INFLUENCE zone geometry (see ``zone_fetcher``).  Some fetches — currently
    OSM buildings — use this expanded bbox instead of the original pipeline
    bbox, so that features falling inside an INFLUENCE zone that pokes
    outside the original (rectangular) bbox are not missed.

    The result is always the *union* of ``fallback_bbox`` and the AREA
    geometry's own bbox — it never shrinks below ``fallback_bbox``.  Falls
    back to ``fallback_bbox`` unchanged when *zones_fc* is ``None``, has no
    ``AREA`` feature, or that feature has no usable geometry (e.g. in
    ``--only-dt`` mode, where zones may not have been (re-)fetched).
    """
    min_lon, min_lat, max_lon, max_lat = fallback_bbox
    if not zones_fc:
        return fallback_bbox

    area_geom: dict | None = None
    for feature in zones_fc.get("features") or []:
        if (feature.get("properties") or {}).get("zoneClass") == "AREA":
            area_geom = feature.get("geometry")
            break
    if not area_geom:
        return fallback_bbox

    points = _collect_lon_lats(area_geom)
    if not points:
        return fallback_bbox

    lons = [p[0] for p in points]
    lats = [p[1] for p in points]
    return [
        min(min_lon, *lons),
        min(min_lat, *lats),
        max(max_lon, *lons),
        max(max_lat, *lats),
    ]


def _make_pedestrian_stub_zones(
    area_id: str,
    min_lon: float,
    min_lat: float,
    max_lon: float,
    max_lat: float,
) -> dict:
    """Return a minimal ZONES FeatureCollection with only an AREA feature (bbox polygon).

    This satisfies :func:`_extract_area_polygon_json` so that the
    network_fetcher polygon argument can be derived without a real
    Databricks zone query.
    """
    fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": _bbox_polygon_geom(min_lon, min_lat, max_lon, max_lat),
                "properties": {
                    "zoneId": area_id,
                    "zoneClass": "AREA",
                    "zoneName": "Area",
                },
            }
        ],
        "properties": {"areaId": area_id},
    }
    print("  [pedestrian] stub zones created (AREA bbox only)")
    return fc


def _make_pedestrian_zones(
    network_fc: dict,
    area_id: str,
    min_lon: float,
    min_lat: float,
    max_lon: float,
    max_lat: float,
) -> dict:
    """Derive pedestrian zones from the cleaned network nodes.

    Each unique node (``fromNode`` / ``toNode``) in the directed network
    becomes one ``NODE``-class zone feature.  Production is the sum of
    ``flow`` on outgoing links; attraction is the sum of ``flow`` on
    incoming links.  The AREA feature (bbox polygon) is included so that
    downstream steps can still find it.
    """
    features = network_fc.get("features") or []

    node_pos: dict[str, tuple[float, float]] = {}
    node_prod: dict[str, float] = {}
    node_attr: dict[str, float] = {}

    for feat in features:
        props = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords:
            continue

        from_node = str(props.get("fromNode") or "")
        to_node = str(props.get("toNode") or "")
        flow = float(props.get("flow") or 0.0)

        if from_node:
            lon, lat = float(coords[0][0]), float(coords[0][1])
            node_pos.setdefault(from_node, (lon, lat))
            node_prod[from_node] = node_prod.get(from_node, 0.0) + flow

        if to_node and len(coords) >= 2:
            lon, lat = float(coords[-1][0]), float(coords[-1][1])
            node_pos.setdefault(to_node, (lon, lat))
            node_attr[to_node] = node_attr.get(to_node, 0.0) + flow

    zone_features: list[dict] = [
        {
            "type": "Feature",
            "geometry": _bbox_polygon_geom(min_lon, min_lat, max_lon, max_lat),
            "properties": {
                "zoneId": area_id,
                "zoneClass": "AREA",
                "zoneName": "Area",
            },
        }
    ]

    for node_id, (lon, lat) in sorted(node_pos.items()):
        production = round(node_prod.get(node_id, 0.0), 4)
        attraction = round(node_attr.get(node_id, 0.0), 4)
        zone_features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [lon, lat]},
                "properties": {
                    "zoneId": node_id,
                    "zoneClass": "NODE",
                    "zoneName": f"node_{node_id}",
                    "centroidLon": lon,
                    "centroidLat": lat,
                    "production": production,
                    "attraction": attraction,
                },
            }
        )

    out_fc = {
        "type": "FeatureCollection",
        "features": zone_features,
        "properties": {"areaId": area_id},
    }
    n_nodes = len(zone_features) - 1
    print(f"  [pedestrian] {n_nodes} node zones derived")
    return out_fc


# ---------------------------------------------------------------------------
# Deduplication helpers (originally in network_zone_joiner_runner.py)
# ---------------------------------------------------------------------------


def _dedup_zone_features(features: list[dict]) -> list[dict]:
    """Return *features* with duplicates removed by ``zoneId`` (first occurrence wins).

    When both an AREA zone and individual STUDY/INFLUENCE zones are processed,
    every non-AREA zone appears in *all_zone_features* twice: once inside the AREA
    zone's ``zone_fc`` and once from its own result tuple.  This function keeps
    the first occurrence of each ``zoneId``.
    """
    seen: dict[str, dict] = {}
    for feat in features:
        zid = (feat.get("properties") or {}).get("zoneId") or ""
        if zid not in seen:
            seen[zid] = feat
    return list(seen.values())


def _dedup_net_features(features: list[dict]) -> list[dict]:
    """Return *features* with duplicates removed by ``(linkId, fromNode, toNode)``.

    Links that fall inside an individual zone's polygon are also present in the
    AREA zone's clipped network.  This function keeps the first occurrence of
    each ``(linkId, fromNode, toNode)`` triple, which is the AREA zone's version
    (the most complete clip).
    """
    seen: set[tuple] = set()
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        key = (
            str(props.get("linkId") or props.get("spectrumId") or ""),
            str(props.get("fromNode") or ""),
            str(props.get("toNode") or ""),
        )
        if key not in seen:
            seen.add(key)
            result.append(feat)
    return result


# Spectrum schema for which the real HB (home-based, car) OD matrix table
# exists.  For any other schema the pipeline falls back to the fully synthetic
# OD methodology.
_HB_MATRIX_SCHEMA = "2023_01"


def _fetch_hb_matrix(catalog: str, schema: str, zones_fc: dict) -> dict[tuple[str, str], float]:
    """Fetch the real Spectrum HB (home-based, car) OD matrix for the study area.

    Builds the set of inner zone gids (STUDY / INFLUENCE, i.e. ``zoneClass``
    other than ``AREA``) from *zones_fc*, queries the HB matrix table in the
    same ``catalog`` / ``schema`` as the network and zone data, and maps the raw
    ``from_zone_gid`` / ``to_zone_gid`` pairs onto ``(fromZoneId, toZoneId)``
    string keys with summed ``ritten`` as absolute trips.

    The HB matrix table only exists for the ``2023_01`` Spectrum schema.  For any
    other *schema* the real HB matrix is unavailable and this function returns an
    empty dict so the OD matrix falls back to the fully synthetic methodology.

    Degrades gracefully: returns an empty dict (with a warning) when the schema
    is not ``2023_01``, when there are no inner gids, or when the HB table cannot
    be queried.  In that case the OD matrix stays fully synthetic.
    """
    if schema != _HB_MATRIX_SCHEMA:
        print(
            f"  [hb_matrix] schema {schema!r} != {_HB_MATRIX_SCHEMA!r} — "
            "OD matrix stays fully synthetic (real HB matrix only available for "
            f"{_HB_MATRIX_SCHEMA})"
        )
        return {}

    features = zones_fc.get("features") or []
    gid_to_zone_id: dict[int, str] = {}
    for feat in features:
        props = feat.get("properties") or {}
        if props.get("zoneClass") == "AREA":
            continue
        gid = props.get("gid")
        zone_id = props.get("zoneId")
        if gid is None or not zone_id:
            continue
        gid_to_zone_id[int(gid)] = str(zone_id)

    if not gid_to_zone_id:
        print("  [hb_matrix] no inner zone gids — OD matrix stays fully synthetic")
        return {}

    from gmt_routing.matrix_builder.domain.hb_sql import build_hb_od_sql
    from gmt_shared.databricks_sql import connect_from_env

    inner_gids = set(gid_to_zone_id)
    sql = build_hb_od_sql(catalog, schema, inner_gids)
    try:
        with connect_from_env() as conn, conn.cursor() as cur:
            cur.execute(sql)
            cols = [d[0] for d in cur.description]
            rows = cur.fetchall()
    except Exception as exc:
        print(f"  [hb_matrix] query failed ({exc}); OD matrix stays fully synthetic")
        return {}

    hb_od: dict[tuple[str, str], float] = {}
    for row in rows:
        r = dict(zip(cols, row, strict=False))
        f_gid = r.get("from_zone_gid")
        t_gid = r.get("to_zone_gid")
        trips = r.get("trips")
        if f_gid is None or t_gid is None or trips is None:
            continue
        from_zone_id = gid_to_zone_id.get(int(f_gid))
        to_zone_id = gid_to_zone_id.get(int(t_gid))
        if from_zone_id is None or to_zone_id is None:
            continue
        key = (from_zone_id, to_zone_id)
        hb_od[key] = hb_od.get(key, 0.0) + float(trips)

    print(f"  [hb_matrix] {len(hb_od)} internal OD pair(s) fetched from Spectrum HB")
    return hb_od


# ---------------------------------------------------------------------------
# NVP CSV writer (originally in nvp_mapper_runner.py)
# ---------------------------------------------------------------------------
def _write_nvp_csv(match_rows: list, output_path: Path) -> None:
    """Write NVP match rows to a CSV file.

    Columns: linkId, nvpLinkIds, nvpTripIds.
    List values (nvpLinkIds, nvpTripIds) are serialised as pipe-separated strings.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["linkId", "nvpLinkIds", "nvpTripIds"])
        for row in match_rows:
            writer.writerow(
                [
                    row["linkId"],
                    "|".join(row["nvpLinkIds"]),
                    "|".join(row["nvpTripIds"]),
                ]
            )
    print(f"  Written {len(match_rows):,} NVP rows -> {output_path.name}")


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


def _validate_modes(modes: list[str], mode_label: str) -> None:
    """Validate *modes* and *mode_label* for :func:`run_pipeline`.

    Raises
    ------
    ValueError
        - *modes* is empty.
        - Any mode is not a recognised transport mode.
        - ``"PEDESTRIAN"`` is combined with other modes.
        - *mode_label* contains a hyphen (breaks ``_detect_mode()`` in the
          adjust pipeline, which rejects mode labels that contain hyphens).
    """
    from gmt_network_core.network_fetcher.domain.sql import VALID_MODES

    if not modes:
        raise ValueError("At least one transport mode must be specified.")

    invalid = [m for m in modes if m not in VALID_MODES]
    if invalid:
        raise ValueError(
            f"Unsupported mode(s): {', '.join(repr(m) for m in invalid)}. "
            f"Valid modes: {', '.join(sorted(VALID_MODES))}."
        )

    if len(modes) > 1 and "PEDESTRIAN" in modes:
        raise ValueError(
            "PEDESTRIAN cannot be combined with other modes — it uses a different "
            "network schema and has no feedlinks or OD matrix."
        )

    if "-" in mode_label:
        raise ValueError(
            f"mode_label {mode_label!r} must not contain hyphens.  "
            "The adjust pipeline identifies the mode label as the part after "
            "'-NETWORK-' in the filename and rejects any value that contains a hyphen."
        )


@dataclass
class _Stage05Assets:
    """Results of the network-independent stage-5 fetches.

    Every field is populated by :func:`_fetch_stage05_assets` (which performs no
    network mutation) and later consumed by :func:`_apply_stage05`.  ``logs``
    holds the captured per-fetcher output lines so they can be replayed in a
    deterministic order after the concurrent fetch phase completes.
    """

    signal_coords: list[tuple[float, float]] = field(default_factory=list)
    signal_ran: bool = False
    sign_features: list[dict] = field(default_factory=list)
    sign_ran: bool = False
    bgt_features: list[dict] = field(default_factory=list)
    bgt_ran: bool = False
    osm_elements: list[dict] = field(default_factory=list)
    osm_features: list[dict] = field(default_factory=list)
    osm_ran: bool = False
    osm_kinds: list[str] | None = None
    parking_features: list[dict] = field(default_factory=list)
    parking_ran: bool = False
    derived_give_way_features: list[dict] = field(default_factory=list)
    buildings_fc: dict | None = None
    buildings_stats: dict = field(default_factory=dict)
    buildings_ran: bool = False
    vegetation_fc: dict | None = None
    vegetation_stats: dict = field(default_factory=dict)
    vegetation_ran: bool = False
    logs: dict[str, str] = field(default_factory=dict)

    @property
    def any_traffic_asset(self) -> bool:
        """Whether any contributor to the combined traffic-assets parquet ran."""
        return self.signal_ran or self.sign_ran or self.bgt_ran or self.osm_ran or self.parking_ran


class _ThreadRoutedStdout:
    """A ``sys.stdout`` proxy that routes writes per originating thread.

    Threads that :meth:`register` a buffer have their ``print`` output captured
    into that buffer; every other thread (the main pipeline thread, the per-mode
    Databricks tracks) writes through to the wrapped stream unchanged.  This lets
    the concurrent stage-5 fetches run silently and have their output replayed in
    a deterministic order afterwards, instead of interleaving into the
    ``[parallel] per-mode tracks`` section.
    """

    def __init__(self, target) -> None:
        self._target = target
        self._buffers: dict[int, io.StringIO] = {}
        self._lock = threading.Lock()

    def register(self) -> io.StringIO:
        buf = io.StringIO()
        with self._lock:
            self._buffers[threading.get_ident()] = buf
        return buf

    def unregister(self) -> None:
        with self._lock:
            self._buffers.pop(threading.get_ident(), None)

    def write(self, s: str) -> int:
        buf = self._buffers.get(threading.get_ident())
        if buf is not None:
            return buf.write(s)
        return self._target.write(s)

    def flush(self) -> None:
        self._target.flush()

    def __getattr__(self, name):  # delegate isatty/encoding/etc. to the real stream
        return getattr(self._target, name)


@contextlib.contextmanager
def _progress_heartbeat(label: str, interval: float = 20.0):
    """Print a periodic "still running" line while a slow blocking call runs.

    The local-PBF Overpass backend has no internal progress reporting, so a
    long scan otherwise leaves the console silent for minutes.  This starts a
    daemon thread that prints an elapsed-time line every *interval* seconds
    until the wrapped block finishes; fast calls (shorter than *interval*)
    produce no output at all.
    """
    _stop = threading.Event()
    _t0 = time.perf_counter()

    def _tick() -> None:
        while not _stop.wait(interval):
            print(f"  {label} ... nog bezig ({time.perf_counter() - _t0:.0f}s)", flush=True)

    _thread = threading.Thread(target=_tick, daemon=True)
    _thread.start()
    try:
        yield
    finally:
        _stop.set()
        _thread.join(timeout=1.0)


def _prewarm_osm_session(osm_path: str | None, osm_workers: int | None) -> None:
    """Build the shared local-PBF session once before concurrent OSM fetches.

    When several stage-5 fetchers run in parallel against the same ``.osm.pbf``
    a cold session cache would let each thread trigger its own full scan (the
    :func:`shared._osm_session.get_session` lock is released before the scan).
    Pre-building the session serialises that one expensive pass so every fetcher
    subsequently answers from memory.  Best-effort: any failure is ignored and
    the first real fetch will build the session as before.
    """
    if not osm_path:
        return
    try:
        from shared import _osm_pbf_scan as scan
        from shared import _osm_session as session

        if not session.sessions_enabled():
            return
        n_workers = (
            scan._default_workers()
            if osm_workers is None
            else scan.resolve_workers(str(osm_workers), os.cpu_count())
        )
        with _progress_heartbeat("[osm-session]"):
            session.get_session(Path(osm_path), workers=n_workers)
    except Exception as _exc:
        print(f"  [osm-session] pre-warm failed ({_exc}); continuing.")


def _fetch_stage05_assets(
    *,
    bbox: list[float],
    annotate_traffic_signals: bool,
    fetch_traffic_signs: bool,
    fetch_bgt_assets: bool,
    fetch_osm_assets: bool,
    fetch_parking_areas: bool,
    fetch_buildings: bool,
    fetch_vegetation: bool,
    parking_use_osm: bool,
    ndw_data_uri: str | None,
    bgt_url: str | None,
    signal_overpass_timeout: int,
    osm_path: str | None = None,
    osm_workers: int | None = None,
    zones_fc: dict | None = None,
) -> _Stage05Assets:
    """Run all network-independent stage-5 fetches concurrently.

    Fetches traffic-signal coordinates (OSM), traffic signs (NDW/OSM), BGT
    assets (PDOK), OSM traffic objects, parking areas, OSM buildings, and OSM
    vegetation.  None of these depend on the processed network, so the whole
    batch can overlap the (slow) Databricks network phase.  Each fetch is
    fail-safe: a failure is captured as a warning in :attr:`_Stage05Assets.logs`
    and leaves that contribution empty.  Signal annotation, feature assembly and
    all parquet writes are deferred to :func:`_apply_stage05`.

    *zones_fc*, when supplied, is used only by the OSM buildings fetch: the
    query bbox for buildings is expanded to also cover the ``AREA`` zone
    geometry (the union of all STUDY + INFLUENCE zones), so that buildings
    inside an INFLUENCE zone extending beyond the original *bbox* are not
    missed.  All other fetches in this function continue to use *bbox*
    unchanged.  See :func:`_zones_union_bbox`.
    """
    assets = _Stage05Assets()

    # Serialise the single expensive local-PBF scan before fanning out.
    _prewarm_osm_session(osm_path, osm_workers)

    def _fetch_signals() -> None:
        from gmt_network_enrichment.traffic_signal_annotator.core.traffic_signal_annotator_core import (
            fetch_signal_coords,
        )

        try:
            assets.signal_coords = fetch_signal_coords(
                bbox, timeout=signal_overpass_timeout, osm_path=osm_path, osm_workers=osm_workers
            )
            print(f"  {len(assets.signal_coords)} traffic-signal nodes fetched from Overpass")
        except Exception as exc:
            print(
                f"  WARNING: traffic_signal_annotator failed ({exc}); "
                f"continuing without traffic-signal annotation."
            )

    def _fetch_signs() -> None:
        from gmt_network_enrichment.traffic_sign_fetcher.core.traffic_sign_fetcher_core import (
            fetch_sign_features,
            is_netherlands,
        )

        try:
            _ndw_data: dict | None = None
            if ndw_data_uri and is_netherlands(bbox):
                from gmt_shared.uri import read_uri

                print(f"  loading pre-provisioned NDW dataset: {ndw_data_uri}")
                _ndw_data = json.loads(read_uri(ndw_data_uri))

            _signs_fc, _sign_stats = fetch_sign_features(
                bbox,
                ndw_data=_ndw_data,
                timeout=signal_overpass_timeout,
                osm_path=osm_path,
                osm_workers=osm_workers,
            )
            assets.sign_features = _signs_fc.get("features") or []
            print(
                f"  {len(assets.sign_features)} traffic-sign assets added "
                f"(source={_sign_stats['source']})"
            )
        except Exception as exc:
            print(
                f"  WARNING: traffic_sign_fetcher failed ({exc}); "
                f"continuing without traffic-sign assets."
            )

    def _fetch_bgt() -> None:
        from gmt_network_enrichment.bgt_fetcher.core.bgt_fetcher_core import (
            fetch_bgt_assets as _fetch_bgt_assets,
        )

        try:
            # PDOK BGT wegdeel pagination can be slow; give it a generous timeout
            # (the shared fetcher already retries with exponential backoff).
            _ogc_timeout = max(signal_overpass_timeout, 180)
            _bgt_fc, _bgt_stats = _fetch_bgt_assets(bbox, url=bgt_url, timeout=_ogc_timeout)
            assets.bgt_features = _bgt_fc.get("features") or []
            print(
                f"  {len(assets.bgt_features)} BGT assets added "
                f"(speedBump={_bgt_stats['speedBump']}, "
                f"screen={_bgt_stats['screen']}, "
                f"bridge={_bgt_stats['bridge']}, "
                f"tunnel={_bgt_stats['tunnel']}, "
                f"bak={_bgt_stats['bak']}, "
                f"source={_bgt_stats['source']})"
            )
        except Exception as exc:
            print(f"  WARNING: bgt_fetcher failed ({exc}); continuing without BGT assets.")

    def _fetch_osm() -> None:
        from gmt_network_enrichment.osm_asset_fetcher.core.osm_asset_fetcher_core import (
            KIND_SPEED_BUMP,
        )
        from gmt_network_enrichment.osm_asset_fetcher.core.osm_asset_fetcher_core import (
            fetch_osm_assets as _fetch_osm_assets,
        )

        # BGT already provides speed bumps for the Netherlands, so exclude them
        # here when BGT ran to avoid duplicate features.
        _osm_kinds = None
        if fetch_bgt_assets:
            from gmt_network_enrichment.osm_asset_fetcher.core.osm_asset_fetcher_core import (
                DEFAULT_KINDS,
            )

            _osm_kinds = [k for k in DEFAULT_KINDS if k != KIND_SPEED_BUMP]

        try:
            print("  [osm-assets] fetching point assets via Overpass ...", flush=True)
            _t0 = time.perf_counter()
            with _progress_heartbeat("[osm-assets]"):
                _osm_fc, _osm_stats = _fetch_osm_assets(
                    bbox,
                    kinds=_osm_kinds,
                    timeout=signal_overpass_timeout,
                    osm_path=osm_path,
                    osm_workers=osm_workers,
                )
            # Raw elements are kept so linkId/nodeId matching and network
            # enrichment can be done once the processed network is available.
            assets.osm_elements = _osm_fc.get("properties", {}).get("_elements") or []
            assets.osm_features = _osm_fc.get("features") or []
            assets.osm_kinds = _osm_kinds
            print(
                f"  [osm-assets] {len(assets.osm_features)} OSM assets added "
                f"(counts={_osm_stats['counts']}, source={_osm_stats['source']}) "
                f"in {time.perf_counter() - _t0:.1f}s",
                flush=True,
            )
        except Exception as exc:
            print(
                f"  [osm-assets] WARNING: osm_asset_fetcher failed ({exc}); continuing.", flush=True
            )

    def _fetch_parking() -> None:
        from gmt_network_enrichment.parking_area_fetcher.core.parking_area_fetcher_core import (
            fetch_parking_areas as _fetch_parking_areas,
        )

        try:
            print("  [parking] fetching parking areas (BGT + OSM) ...", flush=True)
            _t0 = time.perf_counter()
            # BGT wegdeel pagination (parking-NL leg) can be slow; use a generous
            # timeout matching the bgt_fetcher step.
            with _progress_heartbeat("[parking]"):
                _park_fc, _park_stats = _fetch_parking_areas(
                    bbox,
                    timeout=max(signal_overpass_timeout, 180),
                    use_osm=parking_use_osm,
                    osm_path=osm_path,
                    osm_workers=osm_workers,
                )
            assets.parking_features = _park_fc.get("features") or []
            print(
                f"  [parking] {len(assets.parking_features)} parking areas added "
                f"(bgt={_park_stats['bgt']}, osm={_park_stats['osm']}, "
                f"source={_park_stats['source']}) in {time.perf_counter() - _t0:.1f}s",
                flush=True,
            )
        except Exception as exc:
            print(
                f"  [parking] WARNING: parking_area_fetcher failed ({exc}); continuing.",
                flush=True,
            )

    def _fetch_buildings_task() -> None:
        from osm.osm_building_fetcher.core.osm_building_fetcher_core import (
            build_buildings,
        )

        try:
            _buildings_bbox = _zones_union_bbox(zones_fc, bbox)
            if _buildings_bbox != bbox:
                print(
                    "  [buildings] bbox uitgebreid met invloedsgebied-zones "
                    f"({bbox} -> {_buildings_bbox})",
                    flush=True,
                )
            print("  [buildings] fetching buildings + streets via Overpass ...", flush=True)
            _t0 = time.perf_counter()
            with _progress_heartbeat("[buildings]"):
                assets.buildings_fc, assets.buildings_stats = build_buildings(
                    _buildings_bbox,
                    timeout=signal_overpass_timeout,
                    osm_path=osm_path,
                    osm_workers=osm_workers,
                )
            _bstats = assets.buildings_stats or {}
            print(
                f"  [buildings] {_bstats.get('total', 0)} building features "
                f"({_bstats.get('buildings', 0)} buildings, {_bstats.get('streets', 0)} streets, "
                f"{_bstats.get('tiles', 0)} tiles) in {time.perf_counter() - _t0:.1f}s",
                flush=True,
            )
        except Exception as exc:
            print(
                f"  [buildings] WARNING: osm_building_fetcher failed ({exc}); "
                f"continuing without a buildings file.",
                flush=True,
            )

    def _fetch_vegetation_task() -> None:
        from osm.osm_vegetation_fetcher.core.osm_vegetation_fetcher_core import (
            build_vegetation,
        )

        try:
            print("  [vegetation] fetching vegetation via Overpass ...", flush=True)
            _t0 = time.perf_counter()
            with _progress_heartbeat("[vegetation]"):
                assets.vegetation_fc, assets.vegetation_stats = build_vegetation(
                    bbox,
                    timeout=signal_overpass_timeout,
                    osm_path=osm_path,
                    osm_workers=osm_workers,
                )
            _vstats = assets.vegetation_stats or {}
            print(
                f"  [vegetation] {_vstats.get('total', 0)} vegetation features "
                f"({_vstats.get('points', 0)} points, {_vstats.get('areas', 0)} areas, "
                f"{_vstats.get('lines', 0)} lines, {_vstats.get('tiles', 0)} tiles) "
                f"in {time.perf_counter() - _t0:.1f}s",
                flush=True,
            )
        except Exception as exc:
            print(
                f"  [vegetation] WARNING: osm_vegetation_fetcher failed ({exc}); "
                f"continuing without a vegetation file.",
                flush=True,
            )

    # (task, enabled-flag, ran-attribute, log-section) — only enabled fetches run.
    _tasks: list[tuple] = [
        (_fetch_signals, annotate_traffic_signals, "signal_ran", "signals"),
        (_fetch_signs, fetch_traffic_signs, "sign_ran", "signs"),
        (_fetch_bgt, fetch_bgt_assets, "bgt_ran", "bgt"),
        (_fetch_osm, fetch_osm_assets, "osm_ran", "osm"),
        (_fetch_parking, fetch_parking_areas, "parking_ran", "parking"),
        (_fetch_buildings_task, fetch_buildings, "buildings_ran", "buildings"),
        (_fetch_vegetation_task, fetch_vegetation, "vegetation_ran", "vegetation"),
    ]
    _active = [(fn, ran_attr, section) for fn, enabled, ran_attr, section in _tasks if enabled]
    for _fn, _ran_attr, _section in _active:
        setattr(assets, _ran_attr, True)

    # The Overpass-backed fetches each materialise a large ``out geom`` response
    # plus parsed features and shapely geometry.  Running all four at once (on
    # top of the concurrent per-mode Databricks phase) is what drives the prepare
    # subprocess into out-of-memory territory, so they are run strictly one at a
    # time.  The cheap fetches (traffic signals/signs, BGT) stay concurrent.
    _heavy_sections = frozenset({"osm", "parking", "buildings", "vegetation"})
    _light = [(fn, section) for fn, _ran, section in _active if section not in _heavy_sections]
    _heavy = [(fn, section) for fn, _ran, section in _active if section in _heavy_sections]

    if _active:
        # Capture each fetch's stdout into its own buffer so the concurrent
        # output does not interleave into the Databricks per-mode section; it is
        # replayed in a fixed order by :func:`_apply_stage05`.
        _proxy = _ThreadRoutedStdout(sys.stdout)

        def _capture(fn, section):
            def _wrapped() -> None:
                buf = _proxy.register()
                try:
                    fn()
                finally:
                    assets.logs[section] = buf.getvalue()
                    _proxy.unregister()

            return _wrapped

        _prev_stdout = sys.stdout
        sys.stdout = _proxy
        try:
            # Light fetches run concurrently and are captured for deterministic
            # replay.  The heavy Overpass fetches run sequentially in this thread
            # (only one resident at a time) and are intentionally NOT captured, so
            # their progress logging streams live to the console/job-log while the
            # long-running fetch is in flight instead of only appearing at the end.
            _light_pool: concurrent.futures.ThreadPoolExecutor | None = None
            _light_futs: list = []
            if _light:
                _light_pool = concurrent.futures.ThreadPoolExecutor(max_workers=len(_light))
                _light_futs = [_light_pool.submit(_capture(fn, section)) for fn, section in _light]
            try:
                for fn, _section in _heavy:
                    fn()  # streams live; one Overpass workload at a time
            finally:
                if _light_pool is not None:
                    for _f in concurrent.futures.as_completed(_light_futs):
                        _f.result()  # tasks swallow their own errors; re-raise real bugs
                    _light_pool.shutdown(wait=True)
        finally:
            sys.stdout = _prev_stdout

    return assets


def _apply_stage05(
    network_fc: dict,
    assets: _Stage05Assets,
    *,
    bbox: list[float],
    area_id: str,
    out_dir: Path,
    debug: bool,
    traffic_assets_path: Path,
    buildings_path: Path,
    vegetation_path: Path,
    signal_tolerance_m: float,
) -> dict:
    """Apply pre-fetched stage-5 *assets* to *network_fc* and write outputs.

    Performs the network-dependent work — signal annotation — plus deterministic,
    fixed-order assembly of the combined traffic-assets feature list and all
    parquet writes (traffic assets, buildings, vegetation).  Captured fetch logs
    are replayed here so the console output matches the original sequential order
    regardless of the concurrent fetch ordering.  Returns the (possibly
    signal-annotated) network; the caller persists it.
    """

    def _flush(section: str) -> None:
        text = assets.logs.get(section, "")
        if text:
            print(text, end="")

    _asset_features: list[dict] = []

    # ── traffic signals (network-dependent annotation) ───────────────────────
    if assets.signal_ran:
        print()
        print("[4/opt] traffic_signal_annotator ...")
        _flush("signals")
        if assets.signal_coords:
            from gmt_network_enrichment.traffic_signal_annotator.core.traffic_signal_annotator_core import (
                annotate_network,
                signals_to_features,
            )

            network_fc, _sig_stats = annotate_network(
                network_fc, assets.signal_coords, tolerance_m=signal_tolerance_m
            )
            print(
                f"  {_sig_stats['annotated']}/{_sig_stats['total']} links marked trafficSignal=True"
            )
            _signal_features = signals_to_features(assets.signal_coords)
            _asset_features.extend(_signal_features)
            print(f"  {len(_signal_features)} traffic-signal assets added")
            if debug:
                _snapshot(5, area_id, out_dir, NETWORK_SIGNALS=network_fc)

    # ── traffic signs ────────────────────────────────────────────────────────
    if assets.sign_ran:
        print()
        print("[4/opt] traffic_sign_fetcher ...")
        _flush("signs")
        _asset_features.extend(assets.sign_features)

    # ── BGT assets ───────────────────────────────────────────────────────────
    if assets.bgt_ran:
        print()
        print("[4/opt] bgt_fetcher ...")
        _flush("bgt")
        # BGT speed bumps are authoritative in the Netherlands and are not
        # fetched from OSM.  They need to be matched to the network so that
        # numSpeedBumps can be populated on the links.
        if network_fc.get("features"):
            from gmt_network_enrichment.osm_asset_fetcher.core.domain.geometry_matching import (
                match_features_to_network_with_fallback,
            )
            from gmt_network_enrichment.osm_asset_fetcher.core.domain.network_enrichment import (
                enrich_network_with_osm_assets,
            )

            _bgt_speed_bumps = [
                f
                for f in (assets.bgt_features or [])
                if (f.get("properties") or {}).get("assetType") == "speedBump"
            ]
            if _bgt_speed_bumps:
                _matched = match_features_to_network_with_fallback(_bgt_speed_bumps, network_fc)
                network_fc = enrich_network_with_osm_assets(network_fc, _matched)
                _matched_count = sum(
                    1 for f in _matched if (f.get("properties") or {}).get("linkId") is not None
                )
                print(
                    f"  {_matched_count}/{len(_bgt_speed_bumps)} BGT speed bumps matched to network"
                )
        _asset_features.extend(assets.bgt_features)

    # ── OSM traffic assets ───────────────────────────────────────────────────
    if assets.osm_ran:
        print()
        print("[4/opt] osm_asset_fetcher ...")
        _flush("osm")
        # Re-derive features with linkId/nodeId matching and network enrichment
        # now that the processed network is available.
        if assets.osm_elements and network_fc.get("features"):
            from gmt_network_enrichment.osm_asset_fetcher.core.domain.network_enrichment import (
                enrich_network_with_osm_assets,
                enrich_network_with_pois_and_crossings,
                extract_built_up_features,
                extract_poi_features,
            )
            from gmt_network_enrichment.osm_asset_fetcher.core.osm_asset_fetcher_core import (
                elements_to_asset_features,
            )

            assets.osm_features = elements_to_asset_features(
                assets.osm_elements,
                assets.osm_kinds or [],
                network_fc=network_fc,
            )
            network_fc = enrich_network_with_osm_assets(network_fc, assets.osm_features)

            # Also add POI/built-up-area proximity columns (schools, hospitals,
            # recreation, shops) for bike and pedestrian buffers. These use the
            # stored raw Overpass elements so the OSM query is not re-executed.
            poi_features = extract_poi_features(assets.osm_elements)
            built_up_features = extract_built_up_features(assets.osm_elements)
            network_fc = enrich_network_with_pois_and_crossings(
                network_fc,
                asset_features=assets.osm_features,
                poi_features=poi_features,
                built_up_features=built_up_features,
            )
            print(
                "  POI-area enrichment: "
                f"{len(poi_features)} POIs, {len(built_up_features)} built-up polygons"
            )
        _asset_features.extend(assets.osm_features)

    # ── Derived give-way markers (from priorityRoad graph) ───────────────────
    _give_way_features = getattr(assets, "derived_give_way_features", [])
    if _give_way_features:
        _asset_features.extend(_give_way_features)
        # Increment numGiveWays for the owning links so the counter matches the
        # number of generated markers.
        from gmt_network_enrichment.osm_asset_fetcher.core.domain.network_enrichment import (
            enrich_network_with_osm_assets,
        )

        network_fc = enrich_network_with_osm_assets(network_fc, _give_way_features)
        print(f"  {len(_give_way_features)} derived give-way markers added")

    # ── parking areas ────────────────────────────────────────────────────────
    if assets.parking_ran:
        print()
        print("[4/opt] parking_area_fetcher ...")
        _flush("parking")
        _asset_features.extend(assets.parking_features)

    # Write the combined traffic-assets parquet when any contributor ran.
    if assets.any_traffic_asset:
        _assets_fc = {
            "type": "FeatureCollection",
            "features": _asset_features,
            "properties": {"area_id": area_id, "bbox": bbox},
        }
        traffic_assets_path.write_bytes(to_geoparquet(_assets_fc))
        print(f"  {len(_asset_features)} traffic assets -> {traffic_assets_path.name}")
        if debug:
            _snapshot(5, area_id, out_dir, TRAFFIC_ASSETS=_assets_fc)

    # ── OSM buildings (mode-independent, separate parquet) ───────────────────
    if assets.buildings_ran:
        print()
        print("[4/opt] osm_building_fetcher ...")
        _flush("buildings")
        if assets.buildings_fc is not None:
            buildings_path.write_bytes(to_geoparquet(assets.buildings_fc))
            _bld_stats = assets.buildings_stats
            print(
                f"  {_bld_stats.get('buildings', 0)} buildings "
                f"(tiles={_bld_stats.get('tiles', 1)}, "
                f"by_type={_bld_stats.get('by_type', {})}) "
                f"-> {buildings_path.name}"
            )
            if debug:
                _snapshot(5, area_id, out_dir, BUILDINGS=assets.buildings_fc)

    # ── OSM vegetation (mode-independent, separate parquet) ──────────────────
    if assets.vegetation_ran:
        print()
        print("[4/opt] osm_vegetation_fetcher ...")
        _flush("vegetation")
        if assets.vegetation_fc is not None:
            vegetation_path.write_bytes(to_geoparquet(assets.vegetation_fc))
            _veg_stats = assets.vegetation_stats
            print(
                f"  {_veg_stats.get('total', 0)} vegetation features "
                f"(points={_veg_stats.get('points', 0)}, "
                f"lines={_veg_stats.get('lines', 0)}, "
                f"areas={_veg_stats.get('areas', 0)}, "
                f"capped={_veg_stats.get('capped', False)}) "
                f"-> {vegetation_path.name}"
            )
            if debug:
                _snapshot(5, area_id, out_dir, VEGETATION=assets.vegetation_fc)

    return network_fc


def _run_stage05_enrichment(
    network_fc: dict,
    *,
    bbox: list[float],
    area_id: str,
    out_dir: Path,
    debug: bool,
    traffic_assets_path: Path,
    buildings_path: Path,
    vegetation_path: Path,
    annotate_traffic_signals: bool,
    fetch_traffic_signs: bool,
    fetch_bgt_assets: bool,
    fetch_osm_assets: bool,
    fetch_parking_areas: bool,
    fetch_buildings: bool,
    fetch_vegetation: bool,
    parking_use_osm: bool,
    ndw_data_uri: str | None,
    bgt_url: str | None,
    signal_tolerance_m: float,
    signal_overpass_timeout: int,
    ckpt: _CheckpointStore,
    use_checkpoint: bool,
    osm_path: str | None = None,
    osm_workers: int | None = None,
    prefetched: _Stage05Assets | None = None,
    zones_fc: dict | None = None,
) -> tuple[dict, _Stage05Assets]:
    """Run the stage-5 traffic-asset + buildings enrichment on *network_fc*.

    Thin wrapper preserved for callers/tests: it resolves the checkpoint, fetches
    the network-independent assets (unless *prefetched* is supplied by an earlier
    overlapping fetch) via :func:`_fetch_stage05_assets`, then applies them with
    :func:`_apply_stage05`.

    When *use_checkpoint* is ``True`` a previously completed enrichment is loaded
    from the ``05_network_annotated`` checkpoint instead of being recomputed.
    Returns the (possibly signal-annotated) network and the populated
    ``_Stage05Assets`` instance; the caller is responsible for persisting the
    network.

    *zones_fc*, when supplied, is forwarded to :func:`_fetch_stage05_assets` so
    the OSM buildings fetch can expand its query bbox to cover the AREA zone
    geometry.  Ignored when *prefetched* is supplied (the expansion already
    happened at prefetch time, if at all).
    """
    _annotated_cached = ckpt.load("05_network_annotated") if use_checkpoint else None
    if _annotated_cached is not None:
        print()
        print("[4/opt] traffic assets + buildings ... [resume] already completed")
        return _annotated_cached, _Stage05Assets()

    assets = prefetched
    if assets is None:
        assets = _fetch_stage05_assets(
            bbox=bbox,
            annotate_traffic_signals=annotate_traffic_signals,
            fetch_traffic_signs=fetch_traffic_signs,
            fetch_bgt_assets=fetch_bgt_assets,
            fetch_osm_assets=fetch_osm_assets,
            fetch_parking_areas=fetch_parking_areas,
            fetch_buildings=fetch_buildings,
            fetch_vegetation=fetch_vegetation,
            parking_use_osm=parking_use_osm,
            ndw_data_uri=ndw_data_uri,
            bgt_url=bgt_url,
            signal_overpass_timeout=signal_overpass_timeout,
            osm_path=osm_path,
            osm_workers=osm_workers,
            zones_fc=zones_fc,
        )

    network_fc = _apply_stage05(
        network_fc,
        assets,
        bbox=bbox,
        area_id=area_id,
        out_dir=out_dir,
        debug=debug,
        traffic_assets_path=traffic_assets_path,
        buildings_path=buildings_path,
        vegetation_path=vegetation_path,
        signal_tolerance_m=signal_tolerance_m,
    )
    return network_fc, assets


def _apply_building_link_ratios(
    network_fc: dict,
    assets: _Stage05Assets,
    *,
    buildings_path: Path,
) -> dict:
    """Merge per-link building motive ratios into *network_fc*, when available.

    Mirrors ``osm_prepare_core.py``'s B6 step (``assign_buildings_to_links``).
    Buildings are fetched in stage 5 (``fetch_buildings``), but
    :func:`_run_stage05_enrichment` returns an empty ``_Stage05Assets`` when
    that stage was resumed from the ``"05_network_annotated"`` checkpoint, so
    this falls back to reading the already-written *buildings_path* in that
    case. No-op (returns *network_fc* unchanged) when no buildings
    FeatureCollection is available at all, e.g. when a direct caller passed
    ``fetch_buildings=False``.
    """
    buildings_fc = assets.buildings_fc
    if buildings_fc is None and buildings_path.exists():
        buildings_fc = from_geoparquet(buildings_path.read_bytes())
    if buildings_fc is None:
        return network_fc

    print()
    print("[4/opt+++] assign_buildings_to_links ...")
    from osm.osm_building_fetcher.domain.street_linker import assign_buildings_to_links

    link_ratios = assign_buildings_to_links(buildings_fc, network_fc)
    for feat in network_fc.get("features") or []:
        lid = str((feat.get("properties") or {}).get("linkId", ""))
        ratio = link_ratios.get(lid)
        if ratio:
            feat.setdefault("properties", {})["buildingMotifRatio"] = ratio
    print(f"  {len(link_ratios):,} links enriched with buildingMotifRatio")
    return network_fc


def run_pipeline(
    min_lon: float,
    min_lat: float,
    max_lon: float,
    max_lat: float,
    modes: list[str],
    name: str,
    out_dir: Path,
    *,
    mode_label: str | None = None,
    catalog: str | None = None,
    schema: str | None = None,
    study_fallback: str = "centroid",
    refresh: bool,
    debug: bool,
    exclude_zones: list[str] | None = None,
    max_routes: int = 2,
    nvp_table: str | None = None,
    nvp_year: int | None = None,
    area_id: str | None = None,
    w_mrh: float = 2.0,
    w_erh: float = 2.0,
    w_rest: float = 20.0,
    export_geojson: bool = False,
    annotate_traffic_signals: bool = False,
    fetch_traffic_signs: bool = False,
    fetch_bgt_assets: bool = False,
    fetch_osm_assets: bool = False,
    fetch_parking_areas: bool = False,
    fetch_buildings: bool = True,
    fetch_vegetation: bool = False,
    add_elevation: bool = False,
    elevation_batch_size: int = 100,
    elevation_timeout: int = 30,
    elevation_retries: int = 8,
    elevation_pause: float = 2.0,
    no_dt: bool = False,
    only_dt: bool = False,
    ndw_data_uri: str | None = None,
    bgt_url: str | None = None,
    signal_tolerance_m: float = 15.0,
    signal_overpass_timeout: int = 60,
    network_max_speed_kmh: float | None = None,
    network_max_flow: float | None = None,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> str:
    """Run the full GMT preparation pipeline entirely in-process.

    Area dispatch: when *bbox* does not lie entirely within the Netherlands
    (checked via ``gmt_shared.geo.is_bbox_fully_in_netherlands``), this
    delegates to the OSM-based pipeline
    (``osm.osm_prepare.core.osm_prepare_core.run_pipeline``) instead of the
    Databricks/Spectrum path below, with a simplified preset (no traffic
    signals/signs/assets/elevation/priority-roundabout enrichment — only
    network, zones, buildings and OD/routes).  The OSM pipeline only supports
    CAR mode, so a non-NL bbox combined with any other mode raises
    ``ValueError``.  *catalog*/*schema* are ignored (and may be omitted) in
    this case, since no Databricks connection is made.

    Per-mode steps (network_fetcher, network_simplifier, network_cleaner,
    feedlink_fetcher) run in parallel using a ``ThreadPoolExecutor`` — one
    thread per requested mode.  Cross-mode steps (network_fuser,
    bidirectional_splitter, parallel_link_finder, network_zone_joiner) run
    sequentially afterward, followed by a second parallel round of
    matrix_builder (one per mode).

    Parameters
    ----------
    min_lon, min_lat, max_lon, max_lat:
        Bounding box in decimal degrees (WGS-84).
    modes:
        One or more transport modes, e.g. ``["CAR"]`` or ``["CAR", "BIKE"]``.
        All modes must be recognised (see ``VALID_MODES``).  ``"PEDESTRIAN"``
        cannot be combined with other modes.  Only ``["CAR"]`` is supported
        when *bbox* falls outside the Netherlands (see "Area dispatch" above).
    name:
        Human-readable area name passed to network_fetcher.
    out_dir:
        Output directory; created automatically if it does not exist.
    mode_label:
        External name used in output filenames, e.g. ``"MIXED"``.  Defaults to
        ``"MIXED"`` when more than one mode is given, or ``modes[0]`` for a
        single mode.  Must not contain a hyphen.
    catalog:
        Databricks Unity Catalog name.  Required when *bbox* falls entirely
        within the Netherlands (the Spectrum/Databricks path is taken);
        ignored — and may be omitted — otherwise, since the bbox is then
        delegated to the OSM-based pipeline instead.  Default: ``None``.
    schema:
        Databricks schema / dataset version.  Same conditional requirement as
        *catalog*.  Default: ``None``.
    study_fallback:
        STUDY-zone fallback methodology passed to ``zone_fetcher.build_fetch_zones_sql``,
        used when no zone reaches the 80% bbox-overlap threshold: ``"centroid"``
        (default, zone containing the bbox centre) or ``"max_overlap"`` (zone with the
        largest overlap ratio, falling back to centroid-containment only when no zone
        intersects the bbox at all). Ignored for ``"PEDESTRIAN"`` (which uses a stub
        zone, not zone_fetcher).
    refresh:
        Re-run all steps even when the final output files already exist.
    debug:
        Write in-memory FeatureCollections after each step to
        ``STEP_{n}_…`` snapshot files.
    exclude_zones:
        Optional list of ``zoneId`` strings to exclude from the zone fetch.
    max_routes:
        Maximum number of k-shortest routes per OD pair produced by
        matrix_builder.  Default is ``2``.
    nvp_table:
        Fully qualified Databricks NVP table name.  When provided (together
        with *nvp_year*) an optional step runs ``nvp_mapper`` to produce
        a ``{area_id}-NVP-ROUTES-{m}.csv`` for each eligible mode
        (``"CAR"`` and ``"BIKE"``).  Silently skipped for other modes.
    nvp_year:
        NVP ``location_year`` value to filter on (e.g. ``2025``).  Required
        when *nvp_table* is set.
    area_id:
        Optional area UUID override.  When omitted the UUID is discovered from
        existing files in *out_dir*, or a fresh ``uuid4()`` is generated for a
        new area.
    w_mrh:
        ETM hour-weight for ochtendspits passed to network_fetcher.  Default: 2.0.
    w_erh:
        ETM hour-weight for avondspits passed to network_fetcher.  Default: 2.0.
    w_rest:
        ETM hour-weight for restdag passed to network_fetcher.  Default: 20.0.
    export_geojson:
        When ``True``, write an additional ``.geojson`` file next to the
        network parquet after the pipeline completes.
    annotate_traffic_signals:
        When ``True``, query Overpass for ``highway=traffic_signals``
        nodes and set a ``trafficSignal`` boolean property on every network
        link.  The signal locations are also emitted as point features into the
        combined ``{area_id}-TRAFFIC-ASSETS.parquet``.  Requires internet
        access.  Off by default — ``prepare`` is only responsible for the
        network/zones/OD core; run the standalone ``traffic_signal_annotator``
        module separately when this enrichment is needed.  Default: ``False``.
    fetch_traffic_signs:
        When ``True``, fetch traffic-sign point features (NDW when the
        bbox lies in the Netherlands and *ndw_data_uri* is set, otherwise OSM
        Overpass) and add them to ``{area_id}-TRAFFIC-ASSETS.parquet``.
        Off by default, same rationale as *annotate_traffic_signals*.
        Default: ``False``.
    ndw_data_uri:
        URI of the pre-provisioned NDW traffic-signs GeoJSON dataset (never
        downloaded by the pipeline).  Used only when *fetch_traffic_signs* is
        ``True`` and the bbox centroid lies in the Netherlands.  Default:
        ``None`` (falls back to Overpass).
    fetch_bgt_assets:
        When ``True``, fetch BGT speed-bump polygons
        (verkeersdrempels) from the PDOK OGC API Features service and add
        them to ``{area_id}-TRAFFIC-ASSETS.parquet``.  BGT only covers the
        Netherlands, so this is skipped for bounding boxes outside NL.
        Off by default, same rationale as *annotate_traffic_signals*.
        Default: ``False``.
    fetch_osm_assets:
        When ``True``, fetch OSM traffic objects (pedestrian
        crossings, stop / give-way signs, mini-roundabouts, and — outside the
        BGT coverage — speed bumps) from Overpass and add them to
        ``{area_id}-TRAFFIC-ASSETS.parquet``.  When *fetch_bgt_assets* is also
        ``True`` the speed-bump kind is excluded here to avoid duplicating the
        BGT verkeersdrempels.  Off by default, same rationale as
        *annotate_traffic_signals*.  Default: ``False``.
    fetch_parking_areas:
        When ``True``, fetch parking-area polygons (BGT in the Netherlands,
        OSM Overpass elsewhere) and add them to
        ``{area_id}-TRAFFIC-ASSETS.parquet``.  Off by default, same rationale
        as *annotate_traffic_signals*.  Default: ``False``.
    fetch_buildings:
        When ``True`` (default), fetch OSM building footprints and write
        them to ``{area_id}-BUILDINGS.parquet``.  Unlike the other stage-5
        toggles this stays on by default: ``prepare`` always links buildings
        to the network (``buildingMotifRatio``, see below), so buildings must
        be available.  Default: ``True``.
    fetch_vegetation:
        When ``True``, fetch OSM vegetation (trees, tree rows,
        shrubs, and wood / forest / scrub / grass areas) from Overpass and
        write them to ``{area_id}-VEGETATION.parquet``.  Vegetation is
        non-essential and best-effort: any failure is logged and the pipeline
        continues.  Off by default, same rationale as *annotate_traffic_signals*.
        Default: ``False``.
    add_elevation:
        When ``True``, look up terrain elevation for every network
        node from the Open-Meteo elevation API (once per unique node, before the
        bidirectional split) and set ``elevationFrom`` / ``elevationTo`` (metres
        above sea level) on every network link.  Source-independent and
        best-effort: any failure is logged and the pipeline continues.  Requires
        internet access.  Off by default, same rationale as
        *annotate_traffic_signals*.  Default: ``False``.
    elevation_batch_size:
        Coordinates per Open-Meteo elevation request (capped at 100).
        Default: ``100``.
    elevation_timeout:
        HTTP request timeout in seconds per elevation batch.
        Default: ``30``.
    elevation_retries:
        Maximum retry attempts per elevation batch on transient HTTP errors
        such as 429.  Default: ``8``.
    elevation_pause:
        Seconds to wait between successive elevation batch requests (throttle).
        Increase this if you see frequent ``429 Too Many Requests`` responses.
        Default: ``2.0``.
    no_dt:
        When ``True``, skip every digital-twin enrichment source: traffic-signal
        annotation, OSM traffic objects, OSM buildings, BGT/PDOK assets and
        parking areas are disabled; traffic signs fall back to NDW-only (no
        Overpass).  The full Databricks pipeline is unaffected.  Mutually
        exclusive with *only_dt*.  Default: ``False``.
    only_dt:
        When ``True``, skip every Databricks stage and re-run only the stage-5
        traffic-asset + buildings enrichment on the existing
        ``{area_id}-NETWORK-{modeLabel}.parquet`` (which must already exist).
        Rewrites the network (trafficSignal), TRAFFIC-ASSETS and BUILDINGS;
        zones/feedlinks/routes are left untouched.  Mutually exclusive with
        *no_dt*.  Default: ``False``.
    bgt_url:
        OGC API Features base URL for the BGT service.  Used only when
        *fetch_bgt_assets* is ``True``.  Default: ``None`` (falls back to the
        ``PDOK_BGT_URL`` env var or the public PDOK BGT endpoint).
    signal_tolerance_m:
        Maximum distance in metres from a link's toNode endpoint to the
        nearest OSM traffic-signal node to be considered signalised.
        Default: ``15.0``.
    signal_overpass_timeout:
        HTTP + server-side timeout in seconds for the Overpass API request.
        Default: ``60``.
    network_max_speed_kmh:
        When set, exclude network links whose maximum design speed
        (``max(max_snelheid_heen, max_snelheid_terug)``) exceeds this value
        (km/h).  Use e.g. ``90`` to remove motorways.  Default: ``None``
        (no speed filter).
    network_max_flow:
        When set, exclude network links whose total 24-hr ETM flow
        (sum of all heen + terug flow values) exceeds this value.
        Default: ``None`` (no flow filter).

    Returns
    -------
    str
        The area UUID used for this run.
    """
    # Normalise and validate
    modes = [m.strip().upper() for m in modes]
    if mode_label is None:
        mode_label = "MIXED" if len(modes) > 1 else modes[0]
    else:
        mode_label = mode_label.strip().upper()
    _validate_modes(modes, mode_label)

    if no_dt and only_dt:
        raise ValueError("no_dt and only_dt are mutually exclusive — pass at most one.")

    _is_pedestrian = modes == ["PEDESTRIAN"]
    out_dir.mkdir(parents=True, exist_ok=True)
    area_id = _discover_or_create_area_id(out_dir, area_id)

    # Final output paths (the only files written to disk)
    network_path = out_dir / f"{area_id}-NETWORK-{mode_label}.parquet"
    feedlinks_path = out_dir / f"{area_id}-FEEDLINK-{mode_label}.parquet"
    # Zones use the same mode_label as network/feedlinks — they are not mode-specific.
    zone_path: Path = out_dir / f"{area_id}-ZONE-{mode_label}.parquet"
    routes_paths: dict[str, Path] = {m: out_dir / f"{area_id}-ROUTES-{m}.parquet" for m in modes}
    # Combined traffic-assets output (traffic signals + traffic signs).
    traffic_assets_path: Path = out_dir / f"{area_id}-TRAFFIC-ASSETS.parquet"
    # OSM buildings output (footprints + use classification).
    buildings_path: Path = out_dir / f"{area_id}-BUILDINGS.parquet"

    # OSM vegetation output (trees, shrubs, wood/forest/scrub/grass).
    vegetation_path: Path = out_dir / f"{area_id}-VEGETATION.parquet"

    bbox = [min_lon, min_lat, max_lon, max_lat]

    # ------------------------------------------------------------------
    # Area dispatch: bbox outside the Netherlands delegates to the OSM-based
    # pipeline instead of the Databricks/Spectrum path below. See the "Area
    # dispatch" note in this function's docstring.
    # ------------------------------------------------------------------
    if not is_bbox_fully_in_netherlands(bbox):
        if modes != ["CAR"]:
            raise ValueError(
                "Areas outside the Netherlands are prepared via the OSM pipeline, which "
                f"only supports CAR mode; got modes={modes!r}."
            )
        print()
        print("Bounding box is not fully within the Netherlands — delegating to osm_prepare.")
        from osm.osm_prepare.core.osm_prepare_core import run_pipeline as _run_osm_pipeline

        return _run_osm_pipeline(
            min_lon,
            min_lat,
            max_lon,
            max_lat,
            out_dir,
            area_id=area_id,
            name=name,
            max_routes=max_routes,
            refresh=refresh,
            debug=debug,
            annotate_traffic_signals=False,
            fetch_traffic_signs=False,
            fetch_osm_assets=False,
            add_elevation=False,
            enrich_priority_roundabouts=False,
        )

    if catalog is None or schema is None:
        raise ValueError("catalog and schema are required for areas inside the Netherlands.")

    print()
    print("============================================================")
    print(" GMT Pipeline (in-process)")
    print(f" bbox       : {min_lon} {min_lat} {max_lon} {max_lat}")
    print(f" modes      : {', '.join(modes)}")
    print(f" mode-label : {mode_label}")
    print(f" name       : {name}")
    print(f" area-id    : {area_id}")
    print(f" out        : {out_dir}")
    print(f" refresh    : {'yes' if refresh else 'no (skipping when final outputs exist)'}")
    print(f" debug      : {'yes (snapshots enabled)' if debug else 'no'}")
    if no_dt:
        print(" dt         : disabled (--no-dt: skipping all OSM/Overpass + BGT sources)")
    if only_dt:
        print(" dt         : only (--only-dt: enrichment on existing network)")
    print("============================================================")

    # ------------------------------------------------------------------
    # Early exit: all final outputs exist and refresh=False
    # ------------------------------------------------------------------
    if not refresh and not only_dt:
        finals = (
            [network_path, zone_path]
            if _is_pedestrian
            else [network_path, feedlinks_path, zone_path, *routes_paths.values()]
        )
        if all(f.exists() for f in finals):
            print()
            print("All final outputs already exist — skipping pipeline (use --refresh to force).")
            return area_id

    # Checkpoint store — persists each stage so a crashed run can resume without
    # recomputing completed stages.  Wiped up front when refresh=True and cleared
    # on successful completion (only the real outputs remain).
    _ckpt = _CheckpointStore(out_dir, refresh=refresh)

    # ------------------------------------------------------------------
    # --only-dt: enrich an existing area with OSM/BGT/asset information only.
    # Skips every Databricks stage (zones, network, feedlinks, joiner,
    # matrix) and re-runs only the stage-5 traffic-asset + buildings
    # enrichment on the existing NETWORK parquet.
    # ------------------------------------------------------------------
    if only_dt:
        if not network_path.exists():
            raise FileNotFoundError(
                f"--only-dt requires an existing network file: {network_path} not found. "
                f"Run the full pipeline first to produce it."
            )
        print()
        print(f"[only-dt] loading existing network: {network_path.name}")
        network_fc = from_geoparquet(network_path.read_bytes())
        print(f"  {len(network_fc.get('features') or [])} network features loaded")

        _osm_flags = _resolve_osm_flags(
            no_dt=False,
            annotate_traffic_signals=annotate_traffic_signals,
            fetch_traffic_signs=fetch_traffic_signs,
            fetch_osm_assets=fetch_osm_assets,
            fetch_buildings=fetch_buildings,
            fetch_vegetation=fetch_vegetation,
            fetch_parking_areas=fetch_parking_areas,
            fetch_bgt_assets=fetch_bgt_assets,
            ndw_available=bool(ndw_data_uri) and _is_netherlands(bbox),
        )

        # Best-effort: load the zones file (if it already exists from an earlier
        # full run) so the OSM buildings fetch can still expand its bbox to cover
        # the AREA zone geometry.  --only-dt does not (re-)fetch zones itself.
        _only_dt_zones_fc: dict | None = None
        if zone_path.exists():
            try:
                _only_dt_zones_fc = from_geoparquet(zone_path.read_bytes())
            except Exception as exc:
                print(
                    f"  WARNING: could not load existing zones file for bbox expansion "
                    f"({exc}); buildings fetch will use the plain bbox.",
                )

        network_fc = _run_stage05_enrichment(
            network_fc,
            bbox=bbox,
            area_id=area_id,
            out_dir=out_dir,
            debug=debug,
            traffic_assets_path=traffic_assets_path,
            buildings_path=buildings_path,
            vegetation_path=vegetation_path,
            annotate_traffic_signals=_osm_flags["annotate_traffic_signals"],
            fetch_traffic_signs=_osm_flags["fetch_traffic_signs"],
            fetch_bgt_assets=_osm_flags["fetch_bgt_assets"],
            fetch_osm_assets=_osm_flags["fetch_osm_assets"],
            fetch_parking_areas=_osm_flags["fetch_parking_areas"],
            fetch_buildings=_osm_flags["fetch_buildings"],
            fetch_vegetation=_osm_flags["fetch_vegetation"],
            parking_use_osm=_osm_flags["parking_use_osm"],
            ndw_data_uri=ndw_data_uri,
            bgt_url=bgt_url,
            signal_tolerance_m=signal_tolerance_m,
            signal_overpass_timeout=signal_overpass_timeout,
            ckpt=_ckpt,
            use_checkpoint=False,
            osm_path=osm_path,
            osm_workers=osm_workers,
            zones_fc=_only_dt_zones_fc,
        )
        # Persist the (possibly signal-annotated) network back to disk.
        # _run_stage05_enrichment returns (network_fc, assets); only the network
        # is needed for the --only-dt output.
        if isinstance(network_fc, tuple):
            network_fc = network_fc[0]
        network_path.write_bytes(to_geoparquet(network_fc))

        print()
        print("============================================================")
        print(" Digital-twin enrichment complete (--only-dt).")
        print(f" Network        : {network_path}")
        if traffic_assets_path.exists():
            print(f" Traffic assets : {traffic_assets_path}")
        if buildings_path.exists():
            print(f" Buildings      : {buildings_path}")
        if vegetation_path.exists():
            print(f" Vegetation     : {vegetation_path}")
        print("============================================================")
        _ckpt.clear()
        return area_id

    # Shared Databricks connector — called per-thread inside per-mode tracks.
    from gmt_shared.databricks_sql import connect_from_env

    # ======================================================================
    # STEP 1 — zone_fetcher  (sequential, shared across all modes)
    # ======================================================================
    print()
    print("[1] zone_fetcher ...")
    _cached_zones = _ckpt.load("00_zones")
    if _cached_zones is not None:
        zones_fc = _cached_zones
    else:
        if _is_pedestrian:
            zones_fc = _make_pedestrian_stub_zones(area_id, min_lon, min_lat, max_lon, max_lat)
        else:
            from gmt_zone_core.zone_fetcher.domain.sql import (
                bbox_to_polygon_json,
                build_fetch_zones_sql,
            )
            from gmt_zone_core.zone_fetcher.domain.zone import (
                rows_to_feature_collection as _zones_rows_to_fc,
            )

            _zf_polygon = bbox_to_polygon_json(bbox)
            _zf_sql = build_fetch_zones_sql(catalog, schema, study_fallback=study_fallback)
            with connect_from_env() as conn, conn.cursor() as cur:
                cur.execute(_zf_sql, (_zf_polygon,))
                _zf_cols = [d[0] for d in cur.description]
                _zf_rows = cur.fetchall()
            zones_fc = _zones_rows_to_fc(
                _zf_rows,
                _zf_cols,
                area_id,
                bbox,
                exclude_zone_ids=set(exclude_zones) if exclude_zones else None,
            )
            zones_fc.setdefault("properties", {}).update({"name": name, "source": "Spectrum"})
            print(f"  {len(zones_fc.get('features') or [])} zone features fetched")
        _ckpt.save("00_zones", zones_fc)

    if debug:
        _snapshot(1, area_id, out_dir, ZONES=zones_fc)

    # Shared inputs derived from zones_fc — all read-only for the mode threads.
    _area_polygon_json = _extract_area_polygon_json(zones_fc)
    if _area_polygon_json == "null":
        # No zone geometry found (studyCount=0, convex hull is None).
        # Fall back to the input bbox polygon so that the network_fetcher
        # can still clip the network to the requested area.
        from gmt_zone_core.zone_fetcher.domain.sql import bbox_to_polygon_json

        _area_polygon_json = bbox_to_polygon_json(bbox)
        print(
            "  [warning] No zone geometries found (studyCount=0) — "
            "using input bbox as area polygon for network_fetcher."
        )

    from gmt_shared.region import determine_region

    _region: str | None = None
    _holiday_path = ARTIFACTS / "indices" / "holiday_regions.geojson"
    if _holiday_path.exists():
        _hfc = json.loads(_holiday_path.read_text(encoding="utf-8"))
        _region = determine_region(bbox, _hfc.get("features") or [])

    # gids used by feedlink_fetcher — derived once, shared across threads.
    _gids: list[int] = [
        int(feat["properties"]["gid"])
        for feat in (zones_fc.get("features") or [])
        if (feat.get("properties") or {}).get("zoneClass") != "AREA"
        and (feat.get("properties") or {}).get("gid") is not None
    ]

    # ======================================================================
    # PER-MODE PARALLEL TRACKS
    # Each track: network_fetcher → network_simplifier → network_cleaner →
    #             feedlink_fetcher
    # Returns: (mode, network_fc, feedlink_features)
    # ======================================================================
    def _run_mode_track(
        mode: str,
    ) -> tuple[str, dict, list[dict]]:
        from gmt_network_core.network_cleaner.core.network_cleaner_core import clean_network
        from gmt_network_core.network_fetcher.core.network_fetcher_core import (
            build_intersection_sql,
            get_pt_params,
        )
        from gmt_network_core.network_fetcher.core.network_fetcher_core import (
            rows_to_feature_collection as _net_rows_to_fc,
        )
        from gmt_network_core.network_simplifier.core.network_simplifier_core import (
            simplify_network,
        )

        # ── network_fetcher ──────────────────────────────────────────────
        print(f"  [{mode}] network_fetcher ...")
        _net_sql = build_intersection_sql(
            mode, catalog, schema, weights={"mrh": w_mrh, "erh": w_erh, "rest": w_rest}
        )
        with connect_from_env() as _conn, _conn.cursor() as _cur:
            if mode in _PT_MODES:
                _link_mode, _modaliteit = get_pt_params(mode)
                _cur.execute(_net_sql, (_link_mode, _area_polygon_json, _modaliteit, mode))
            else:
                _cur.execute(_net_sql, (_area_polygon_json,))
            _net_cols = [d[0] for d in _cur.description]
            _net_rows = _cur.fetchall()
        _net_fc = _net_rows_to_fc(_net_rows, _net_cols, mode)
        print(f"  [{mode}] {len(_net_fc.get('features') or []):,} links fetched")

        # ── WKD Wegbreedtes enrichment (NL only) ─────────────────────────
        if _is_netherlands(bbox):
            print(f"  [{mode}] wkd_fetcher ...")
            from gmt_network_enrichment.wkd_fetcher.core.wkd_fetcher_core import (
                apply_wkd_road_widths,
                fetch_wkd_road_widths,
            )

            _wkd_catalog = "nwb"
            _wkd_schema = "2026_01_jaarlijks"
            with connect_from_env() as _wkd_conn, _wkd_conn.cursor() as _wkd_cur:
                _wkd_lookup = fetch_wkd_road_widths(
                    _wkd_cur,
                    _area_polygon_json,
                    _net_fc,
                    catalog=_wkd_catalog,
                    schema=_wkd_schema,
                )
            _net_fc = apply_wkd_road_widths(_net_fc, _wkd_lookup)

        # ── network link filter (speed / flow) ───────────────────────────
        if network_max_speed_kmh is not None or network_max_flow is not None:
            from gmt_network_core.network_fetcher.core.network_fetcher_core import (
                filter_network_fc,
            )

            _net_fc, _filter_stats = filter_network_fc(
                _net_fc,
                max_speed_kmh=network_max_speed_kmh,
                max_flow=network_max_flow,
            )
            print(
                f"  [{mode}] filter: -{_filter_stats['removed_speed']} speed,"
                f" -{_filter_stats['removed_flow']} flow"
                f" -> {_filter_stats['kept']} links remaining"
            )

        # ── network_simplifier ───────────────────────────────────────────
        print(f"  [{mode}] network_simplifier ...")
        _net_fc, _simplify_stats = simplify_network(_net_fc)
        print(f"  [{mode}] {len(_net_fc.get('features') or [])} links after simplification")

        # ── network_cleaner ──────────────────────────────────────────────
        print(f"  [{mode}] network_cleaner ...")
        _net_fc, _clean_stats = clean_network(_net_fc)
        print(f"  [{mode}] {_clean_stats['kept']} kept, {_clean_stats['removed']} removed")

        # ── feedlink_fetcher  (skipped for PEDESTRIAN) ───────────────────
        _feedlink_features: list[dict] = []
        if not _is_pedestrian:
            from gmt_network_core.feedlink_fetcher.core.feedlink_fetcher_core import (
                VOEDINGSLINKS_TABLE,
                build_feedlinks,
                build_voedingslinks_sql,
                parse_network_geojson,
            )

            print(f"  [{mode}] feedlink_fetcher ...")
            _node_positions, _all_node_ids = parse_network_geojson(_net_fc)
            _vl_table = VOEDINGSLINKS_TABLE.get(mode)
            _fl_rows: list[dict] = []
            if _vl_table:
                _fl_sql = build_voedingslinks_sql(catalog, schema, _vl_table, _gids)
                with connect_from_env() as _conn, _conn.cursor() as _cur:
                    _cur.execute(_fl_sql)
                    _fl_cols = [d[0] for d in _cur.description]
                    _fl_rows = [dict(zip(_fl_cols, row, strict=False)) for row in _cur.fetchall()]
                print(f"  [{mode}] {len(_fl_rows)} voedingslinks rows fetched")
            else:
                print(f"  [{mode}] no voedingslinks table — feedlinks from zone centroids only")
            _fl_fc = build_feedlinks(
                zones_fc,
                _node_positions,
                _all_node_ids,
                _fl_rows,
                mode,
            )
            _feedlink_features = _fl_fc.get("features") or []

        return mode, _net_fc, _feedlink_features

    # ------------------------------------------------------------------
    # Stage-5 asset prefetch — overlap with the Databricks network phase.
    # Every stage-5 fetch depends only on the bbox, so start them now on a
    # background thread and collect the results after step 4.  This hides the
    # entire (network-bound) fetch latency behind the per-mode Databricks
    # tracks.  Skipped when a completed enrichment checkpoint already exists.
    # ------------------------------------------------------------------
    _osm_flags = _resolve_osm_flags(
        no_dt=no_dt,
        annotate_traffic_signals=annotate_traffic_signals,
        fetch_traffic_signs=fetch_traffic_signs,
        fetch_osm_assets=fetch_osm_assets,
        fetch_buildings=fetch_buildings,
        fetch_vegetation=fetch_vegetation,
        fetch_parking_areas=fetch_parking_areas,
        fetch_bgt_assets=fetch_bgt_assets,
        ndw_available=bool(ndw_data_uri) and _is_netherlands(bbox),
    )
    _stage05_executor: concurrent.futures.ThreadPoolExecutor | None = None
    _stage05_future: concurrent.futures.Future | None = None
    _stage05_started_at = 0.0
    _stage05_enabled = (
        _osm_flags["annotate_traffic_signals"]
        or _osm_flags["fetch_traffic_signs"]
        or _osm_flags["fetch_bgt_assets"]
        or _osm_flags["fetch_osm_assets"]
        or _osm_flags["fetch_parking_areas"]
        or _osm_flags["fetch_buildings"]
        or _osm_flags["fetch_vegetation"]
    )
    if _stage05_enabled and _ckpt.load("05_network_annotated") is None:
        _stage05_sources = [
            name
            for name, on in (
                ("traffic_signals", _osm_flags["annotate_traffic_signals"]),
                ("traffic_signs", _osm_flags["fetch_traffic_signs"]),
                ("bgt_assets", _osm_flags["fetch_bgt_assets"]),
                ("osm_assets", _osm_flags["fetch_osm_assets"]),
                ("parking_areas", _osm_flags["fetch_parking_areas"]),
                ("buildings", _osm_flags["fetch_buildings"]),
                ("vegetation", _osm_flags["fetch_vegetation"]),
            )
            if on
        ]
        print()
        print(
            "[5] stage-5 OSM/BGT fetch GESTART op achtergrond "
            "(draait parallel met de per-mode tracks / parallel_link_finder): "
            + ", ".join(_stage05_sources)
        )
        if osm_path:
            print(f"    bron: lokale PBF {osm_path} (osm_workers={osm_workers})")
        else:
            print("    bron: Overpass HTTP-API")
        _stage05_started_at = time.monotonic()
        _stage05_executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
        _stage05_future = _stage05_executor.submit(
            _fetch_stage05_assets,
            bbox=bbox,
            annotate_traffic_signals=_osm_flags["annotate_traffic_signals"],
            fetch_traffic_signs=_osm_flags["fetch_traffic_signs"],
            fetch_bgt_assets=_osm_flags["fetch_bgt_assets"],
            fetch_osm_assets=_osm_flags["fetch_osm_assets"],
            fetch_parking_areas=_osm_flags["fetch_parking_areas"],
            fetch_buildings=_osm_flags["fetch_buildings"],
            fetch_vegetation=_osm_flags["fetch_vegetation"],
            parking_use_osm=_osm_flags["parking_use_osm"],
            ndw_data_uri=ndw_data_uri,
            bgt_url=bgt_url,
            signal_overpass_timeout=signal_overpass_timeout,
            osm_path=osm_path,
            osm_workers=osm_workers,
            zones_fc=zones_fc,
        )

    # Run all mode tracks in parallel (single mode = no overhead, still correct).
    print()
    print(f"[parallel] per-mode tracks ({', '.join(modes)}) ...")
    _net_raw_cached = _ckpt.load("01_network_raw")
    _fl_raw_cached = _ckpt.load("01_feedlinks_raw")
    if _net_raw_cached is not None and _fl_raw_cached is not None:
        network_fc = _net_raw_cached
        _all_feedlink_features = _fl_raw_cached.get("features") or []
        print(
            f"  [resume] {len(network_fc.get('features') or []):,} network links, "
            f"{len(_all_feedlink_features)} feedlinks"
        )
    else:
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(modes)) as _pool:
            _futures = {m: _pool.submit(_run_mode_track, m) for m in modes}
        # Collect in mode-insertion order; futures are already done after the with-block.
        _track_results: dict[str, tuple] = {m: _futures[m].result() for m in modes}

        # Unpack per-mode results.
        _mode_fcs: list[dict] = [_track_results[m][1] for m in modes]
        _all_feedlink_features = [feat for m in modes for feat in _track_results[m][2]]

        # Merge per-mode networks into a single FeatureCollection.
        from gmt_network_core.network_fetcher.core.network_fetcher_core import (
            merge_network_feature_collections,
        )

        network_fc = merge_network_feature_collections(_mode_fcs)
        network_fc.setdefault("properties", {}).update(
            {
                "bbox": bbox,
                "region": _region,
                "area_id": area_id,
                "name": name,
                "modeLabel": mode_label,
                "source": "Spectrum",
            }
        )
        print(f"  {len(network_fc.get('features') or []):,} network links total")
        _ckpt.save("01_network_raw", network_fc)
        _ckpt.save(
            "01_feedlinks_raw",
            {
                "type": "FeatureCollection",
                "features": _all_feedlink_features,
                "properties": {"area_id": area_id},
            },
        )

    if debug:
        _snapshot(2, area_id, out_dir, NETWORK_RAW=network_fc)

    # ======================================================================
    # STEP 2 — network_fuser (multi-mode only)
    # Must run BEFORE bidirectional_splitter so that undirected link pairs
    # are trivially available and reverseLinkIds is not yet needed.
    # The splitter applies its own per-direction lateral displacement after.
    # ======================================================================
    if len(modes) > 1:
        print()
        print("[2] network_fuser ...")

        _fused_cached = _ckpt.load("02_network_fused")
        if _fused_cached is not None:
            network_fc = _fused_cached
        else:
            from gmt_network_core.network_fuser.core.network_fuser_core import fuse_networks

            network_fc, _node_map, _link_pairs, _fuser_stats = fuse_networks(network_fc)
            print(
                f"  car_links={_fuser_stats['car_links']}  "
                f"bike_eligible={_fuser_stats['bike_eligible']}  "
                f"link_pairs={_fuser_stats['link_pairs']}  "
                f"(reversed={_fuser_stats['reverse_matches']}  "
                f"fused={_fuser_stats['fused_bike']})  "
                f"skipped_wegtype={_fuser_stats['skipped_wegtype']}"
            )
            _ckpt.save("02_network_fused", network_fc)

        if debug:
            _snapshot(3, area_id, out_dir, NETWORK_FUSED=network_fc)
    else:
        print()
        print("[2] network_fuser ... SKIPPED (single mode)")

    # ======================================================================
    # STEP 2/opt — elevation_annotator
    # Source-independent: runs on the UNDIRECTED network *before* the split, so
    # every graph node's elevation is fetched exactly once (the splitter then
    # propagates elevationFrom / elevationTo to the heen link and swaps them on
    # the reversed terug link).  Best-effort — a failed Open-Meteo lookup logs a
    # warning and leaves the fields as None.
    # ======================================================================
    if add_elevation:
        print()
        print("[2/opt] elevation_annotator ...")

        _elev_cached = _ckpt.load("02_network_elevation")
        if _elev_cached is not None:
            network_fc = _elev_cached
        else:
            try:
                from gmt_network_enrichment.elevation_annotator.core.elevation_annotator_core import (
                    add_elevation as _add_elevation,
                )

                network_fc, _elev_stats = _add_elevation(
                    network_fc,
                    batch_size=elevation_batch_size,
                    timeout=elevation_timeout,
                    retries=elevation_retries,
                    pause=elevation_pause,
                )
                print(
                    f"  elevation set on {_elev_stats['updated']}/{_elev_stats['links']} links "
                    f"({_elev_stats['resolved']}/{_elev_stats['nodes']} nodes resolved)"
                )
                _ckpt.save("02_network_elevation", network_fc)
            except Exception as exc:
                print(f"  WARNING: elevation annotation failed ({exc}); continuing without it.")

    # ======================================================================
    # STEP 3 — bidirectional_splitter
    # ======================================================================
    print()
    print("[3] bidirectional_splitter ...")

    _split_cached = _ckpt.load("03_network_split")
    if _split_cached is not None:
        network_fc = _split_cached
    else:
        from gmt_network_core.bidirectional_splitter.core.bidirectional_splitter_core import (
            post_process_features,
        )
        from gmt_network_core.bidirectional_splitter.domain.network import (
            DIRECTED_LINK_PROPERTIES,
        )

        _split_features = post_process_features(network_fc.get("features") or [])
        network_fc = {
            "type": "FeatureCollection",
            "features": _split_features,
            "properties": network_fc.get("properties") or {},
        }
        network_fc["properties"]["fields"] = list(DIRECTED_LINK_PROPERTIES)
        print(f"  {len(_split_features)} links after bidirectional split")
        _ckpt.save("03_network_split", network_fc)

    if debug:
        _snapshot(4, area_id, out_dir, NETWORK_SPLIT=network_fc)

    # ======================================================================
    # STEP 4 — parallel_link_finder
    # Run per mode so that CAR links are only matched against other CAR links,
    # and BIKE links only against BIKE links.  Running on the combined network
    # would cause the KD-tree to assign cross-mode matches (a CAR link stealing
    # the mapping slot from the nearest BIKE link) even when the mode filter in
    # the core rejects the final pairing.
    # ======================================================================
    print()
    print("[4] parallel_link_finder ...")

    _parallel_cached = _ckpt.load("04_network_parallel")
    if _parallel_cached is not None:
        network_fc = _parallel_cached
    else:
        from gmt_network_core.parallel_link_finder.core.parallel_link_finder_core import (
            find_parallel_links,
        )

        _enriched_features: list[dict] = []
        for _m in modes:
            _mode_fc = _filter_fc_by_mode(network_fc, _m)
            _mode_enriched, _parallel_stats = find_parallel_links(_mode_fc)
            _enriched_features.extend(_mode_enriched.get("features") or [])
            print(
                f"  [{_m}] enriched={_parallel_stats['features_enriched']}  "
                f"skipped={_parallel_stats['features_skipped']}"
            )
        network_fc = {**network_fc, "features": _enriched_features}
        _ckpt.save("04_network_parallel", network_fc)

    if debug:
        _snapshot(5, area_id, out_dir, NETWORK=network_fc)

    # ======================================================================
    # STEP 4/opt — traffic assets (traffic signals + traffic signs)
    #
    # Two independent modules contribute point features to a single combined
    # {area_id}-TRAFFIC-ASSETS.parquet:
    #   * traffic_signal_annotator — sets a trafficSignal boolean on every
    #     network link AND emits the signal locations as point assets.
    #   * traffic_sign_fetcher     — fetches traffic-sign point assets from NDW
    #     (in NL, pre-provisioned) or OSM Overpass (elsewhere).
    # Each contributor is default-on and can be disabled independently.
    # ======================================================================
    # ``_osm_flags`` was resolved before the Databricks phase so the stage-5
    # fetch could overlap it.  Collect the prefetched assets here (if any); the
    # fetch already ran concurrently with the network tracks.
    _prefetched: _Stage05Assets | None = None
    if _stage05_future is not None:
        try:
            _prefetched = _stage05_future.result()
            print(
                f"[5] stage-5 OSM/BGT fetch KLAAR ({time.monotonic() - _stage05_started_at:.1f}s)"
            )
        except Exception as exc:
            print(f"  WARNING: stage-5 prefetch failed ({exc}); refetching synchronously.")
            _prefetched = None
        finally:
            if _stage05_executor is not None:
                _stage05_executor.shutdown(wait=True)
    network_fc, _stage05_assets = _run_stage05_enrichment(
        network_fc,
        bbox=bbox,
        area_id=area_id,
        out_dir=out_dir,
        debug=debug,
        traffic_assets_path=traffic_assets_path,
        buildings_path=buildings_path,
        vegetation_path=vegetation_path,
        annotate_traffic_signals=_osm_flags["annotate_traffic_signals"],
        fetch_traffic_signs=_osm_flags["fetch_traffic_signs"],
        fetch_bgt_assets=_osm_flags["fetch_bgt_assets"],
        fetch_osm_assets=_osm_flags["fetch_osm_assets"],
        fetch_parking_areas=_osm_flags["fetch_parking_areas"],
        fetch_buildings=_osm_flags["fetch_buildings"],
        fetch_vegetation=_osm_flags["fetch_vegetation"],
        parking_use_osm=_osm_flags["parking_use_osm"],
        ndw_data_uri=ndw_data_uri,
        bgt_url=bgt_url,
        signal_tolerance_m=signal_tolerance_m,
        signal_overpass_timeout=signal_overpass_timeout,
        ckpt=_ckpt,
        use_checkpoint=True,
        osm_path=osm_path,
        osm_workers=osm_workers,
        prefetched=_prefetched,
        zones_fc=zones_fc,
    )

    # Checkpoint the annotated network so a later crash does not re-fetch the
    # (slow) traffic-sign / BGT / OSM / parking / building sources.
    _ckpt.save("05_network_annotated", network_fc)

    # ======================================================================
    # STEP 4/opt+ — network_conflict_finder
    # Adds geometric-conflict columns (fromRightLinkId, fromLeftLinkId,
    # oppositeLinkId, fromRightFlow, fromLeftFlow, oppositeFlow, leftTurnRatio,
    # rightTurnRatio) based only on the directed link geometry. Runs on the
    # directed network before the zone joiner so counts remain link-based and
    # independent of zone clips.
    # ======================================================================
    _conflict_cached = _ckpt.load("04b_network_conflicts")
    if _conflict_cached is not None:
        network_fc = _conflict_cached
        print()
        print("[4/opt+] network_conflict_finder ... [resume] already completed")
    else:
        print()
        print("[4/opt+] network_conflict_finder ...")
        from gmt_network_core.network_conflict_finder.core.network_conflict_finder_core import (
            enrich_network_with_conflicts,
        )

        network_fc = enrich_network_with_conflicts(network_fc)
        _conflict_count = sum(
            1
            for f in network_fc.get("features") or []
            if (f.get("properties") or {}).get("fromRightLinkId") is not None
            or (f.get("properties") or {}).get("fromLeftLinkId") is not None
            or (f.get("properties") or {}).get("oppositeLinkId") is not None
        )
        print(f"  {_conflict_count} links received conflict annotation")
        _ckpt.save("04b_network_conflicts", network_fc)

    if debug:
        _snapshot(5, area_id, out_dir, NETWORK_CONFLICTS=network_fc)

    # ======================================================================
    # STEP 4/opt++ — priority road and roundabout enrichment
    # Uses the fetched OSM elements and NDW/OSM traffic-sign features to mark
    # directed links that are part of a roundabout ring or a priority road.
    # ======================================================================
    _priority_cached = _ckpt.load("04c_network_priority")
    if _priority_cached is not None:
        network_fc = _priority_cached
        print()
        print("[4/opt++] priority_roundabout_enricher ... [resume] already completed")
    else:
        print()
        print("[4/opt++] priority_roundabout_enricher ...")
        from gmt_network_enrichment.osm.priority_roundabout_enricher.core.priority_roundabout_enricher_core import (
            enrich_network_with_priority_and_roundabouts,
        )

        _osm_elements_for_enricher: list[dict] = (
            _stage05_assets.osm_elements if _stage05_assets.osm_ran else []
        )
        _sign_features_for_enricher: list[dict] = (
            _stage05_assets.sign_features if _stage05_assets.sign_ran else []
        )
        _enriched = enrich_network_with_priority_and_roundabouts(
            network_fc,
            osm_elements=_osm_elements_for_enricher or None,
            traffic_sign_features=_sign_features_for_enricher or None,
        )
        network_fc = _enriched[0]
        _stage05_assets.derived_give_way_features = _enriched[1]
        _roundabout_count = sum(
            1
            for f in network_fc.get("features") or []
            if (f.get("properties") or {}).get("isRoundabout")
        )
        _priority_count = sum(
            1
            for f in network_fc.get("features") or []
            if (f.get("properties") or {}).get("priorityRoad")
        )
        _give_way_count = len(_stage05_assets.derived_give_way_features)
        print(
            f"  {_roundabout_count} roundabout links, {_priority_count} priority links, "
            f"{_give_way_count} derived give-way markers"
        )
        _ckpt.save("04c_network_priority", network_fc)

    if debug:
        _snapshot(5, area_id, out_dir, NETWORK_PRIORITY=network_fc)

    # ======================================================================
    # STEP 4/opt+++ — per-link building motive ratios
    # ======================================================================
    network_fc = _apply_building_link_ratios(
        network_fc, _stage05_assets, buildings_path=buildings_path
    )

    if debug:
        _snapshot(5, area_id, out_dir, NETWORK_BUILDING_LINKS=network_fc)

    # ======================================================================
    # PEDESTRIAN early exit — derive node zones, write network + zones
    # ======================================================================
    if _is_pedestrian:
        print()
        print("[pedestrian] node-zone derivation ...")
        zones_fc = _make_pedestrian_zones(network_fc, area_id, min_lon, min_lat, max_lon, max_lat)
        zones_fc.setdefault("properties", {})["source"] = "Spectrum"
        if debug:
            _snapshot(6, area_id, out_dir, ZONES_PEDESTRIAN=zones_fc)

        network_path.write_bytes(to_geoparquet(network_fc))
        zone_path.write_bytes(to_geoparquet(zones_fc))

        if export_geojson:
            from gmt_utils.parquet_exporter.core.parquet_exporter_core import (
                export_to_geojson,
            )

            _ped_geojson_path = network_path.with_suffix(".geojson")
            _ped_geojson_path.write_text(export_to_geojson(network_fc), encoding="utf-8")

        print()
        print("============================================================")
        print(" Pipeline complete (PEDESTRIAN — network cutout only).")
        print(f" Network : {network_path}")
        if export_geojson:
            print(f" GeoJSON : {network_path.with_suffix('.geojson')}")
        print(f" Zones   : {zone_path}")
        if traffic_assets_path.exists():
            print(f" Traffic assets : {traffic_assets_path}")
        if buildings_path.exists():
            print(f" Buildings : {buildings_path}")
        if vegetation_path.exists():
            print(f" Vegetation : {vegetation_path}")
        print("============================================================")
        _ckpt.clear()
        return area_id

    # ======================================================================
    # STEP 4/opt — nvp_mapper  (per eligible mode, sequential)
    # ======================================================================
    _nvp_eligible = [m for m in modes if m in ("CAR", "BIKE")]
    if nvp_table is not None and nvp_year is not None and _nvp_eligible:
        from gmt_utils.nvp_mapper.core.nvp_mapper_core import map_nvp_trips
        from gmt_utils.nvp_mapper.domain.sql import fetch_nvp

        _nvp_bbox = (network_fc.get("properties") or {}).get("bbox") or bbox
        _nvp_min_lon, _nvp_min_lat, _nvp_max_lon, _nvp_max_lat = (float(v) for v in _nvp_bbox)
        _nvp_polygon = json.dumps(
            _bbox_polygon_geom(_nvp_min_lon, _nvp_min_lat, _nvp_max_lon, _nvp_max_lat)
        )

        for _nvp_m in _nvp_eligible:
            print()
            print(f"[4/opt] nvp_mapper ({_nvp_m}) ...")
            _nvp_conn = connect_from_env()
            _nvp_links, _nvp_vertlengths, _nvp_vertxys, _nvp_vertdxys, _linktrips1 = fetch_nvp(
                _nvp_conn.cursor(), nvp_table, _nvp_polygon, _nvp_m, nvp_year
            )
            _nvp_conn.close()

            _nvp_stats, _match_rows = map_nvp_trips(
                network_fc,
                nvp_links=_nvp_links,
                nvp_vertlengths=_nvp_vertlengths,
                nvp_vertxys=_nvp_vertxys,
                nvp_vertdxys=_nvp_vertdxys,
                linktrips1=_linktrips1,
            )
            _write_nvp_csv(_match_rows, out_dir / f"{area_id}-NVP-ROUTES-{_nvp_m}.csv")
            print(
                f"  matched {_nvp_stats.get('matched_links', '?')} / "
                f"{_nvp_stats.get('spectrum_links', '?')} links"
            )

    # ======================================================================
    # STEP 5 — network_zone_joiner
    # ======================================================================
    print()
    print("[5] network_zone_joiner ...")

    _joined_net_cached = _ckpt.load("06_network_joined")
    _joined_zone_cached = _ckpt.load("06_zone_joined")
    _joined_fl_cached = _ckpt.load("06_feedlinks_joined")
    if (
        _joined_net_cached is not None
        and _joined_zone_cached is not None
        and _joined_fl_cached is not None
    ):
        network_fc = _joined_net_cached
        zone_fc = _joined_zone_cached
        feedlinks_fc = _joined_fl_cached
        print(
            f"  Joined (resumed): {len(network_fc.get('features') or [])} net links, "
            f"{len(zone_fc.get('features') or [])} zones, "
            f"{len(feedlinks_fc.get('features') or [])} feedlinks"
        )
    else:
        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": _all_feedlink_features,
            "properties": {"area_id": area_id},
        }
        print(f"  {len(_all_feedlink_features)} feedlinks total")

        from gmt_network_core.network_zone_joiner.core.network_zone_joiner_core import (
            join_zones_to_network,
        )

        _joiner_zones = zones_fc

        results = join_zones_to_network(
            _joiner_zones,
            network_fc,
            zone_classes={"AREA"},
            feedlinks_fc=feedlinks_fc,
            adjust_boundary_demands=False,
        )

        _all_net_feats: list[dict] = []
        _all_zone_feats: list[dict] = []
        _all_fl_feats: list[dict] = []

        for _zone_feat, _clipped_net_fc, _zone_fc_result, _ext_fl_fc in results:
            _all_net_feats.extend(_clipped_net_fc.get("features") or [])
            _all_zone_feats.extend(_zone_fc_result.get("features") or [])
            _all_fl_feats.extend(_ext_fl_fc.get("features") or [])

        _deduped_zones = _dedup_zone_features(_all_zone_feats)
        if len(_deduped_zones) < len(_all_zone_feats):
            print(
                f"  Deduplication: removed {len(_all_zone_feats) - len(_deduped_zones)} "
                f"duplicate zone feature(s)"
            )

        _deduped_net = _dedup_net_features(_all_net_feats)
        if len(_deduped_net) < len(_all_net_feats):
            print(
                f"  Deduplication: removed {len(_all_net_feats) - len(_deduped_net)} "
                f"duplicate network link(s)"
            )

        network_fc = {**network_fc, "features": _deduped_net}
        zone_fc = {
            "type": "FeatureCollection",
            "features": _deduped_zones,
            "properties": {
                **(zones_fc.get("properties") or {}),
                "modes": (network_fc.get("properties") or {}).get("modes") or [],
            },
        }
        _fl_base_props = feedlinks_fc.get("properties") or {}
        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": _all_fl_feats,
            "properties": {**_fl_base_props, "source": "Spectrum"},
        }

        print(
            f"  Joined: {len(_deduped_net)} net links, "
            f"{len(_deduped_zones)} zones, {len(_all_fl_feats)} feedlinks"
        )

        _ckpt.save("06_network_joined", network_fc)
        _ckpt.save("06_zone_joined", zone_fc)
        _ckpt.save("06_feedlinks_joined", feedlinks_fc)

    if debug:
        _snapshot(6, area_id, out_dir, NETWORK=network_fc, ZONE=zone_fc, FEEDLINKS=feedlinks_fc)

    # ======================================================================
    # STEP 6 — matrix_builder  (per mode — routes are never labelled MIXED)
    # Runs in parallel, one thread per mode.
    # ======================================================================
    print()
    print(f"[parallel] matrix_builder ({', '.join(modes)}) ...")

    from gmt_routing.matrix_builder.core.matrix_builder_core import build_matrix

    # Fetch the real Spectrum HB (car) OD matrix once — used for CAR only.
    # Internal zone pairs with a real entry override the synthetic estimate;
    # BOUNDARY pairs and missing internal pairs stay synthetic.
    _hb_od: dict[tuple[str, str], float] = {}
    if "CAR" in modes:
        _cached_hb = _ckpt.load("06b_hb_matrix")
        if _cached_hb is not None:
            # Checkpoint stores one feature per OD pair (fromZoneId/toZoneId/trips)
            # because _CheckpointStore only round-trips FeatureCollections.
            _hb_od = {
                (str(_p.get("fromZoneId")), str(_p.get("toZoneId"))): float(_p.get("trips") or 0.0)
                for _feat in (_cached_hb.get("features") or [])
                if (_p := _feat.get("properties") or {}).get("fromZoneId") is not None
            }
        else:
            _hb_od = _fetch_hb_matrix(catalog, schema, zone_fc)
            _ckpt.save(
                "06b_hb_matrix",
                {
                    "type": "FeatureCollection",
                    "features": [
                        {
                            "type": "Feature",
                            "geometry": None,
                            "properties": {
                                "fromZoneId": k[0],
                                "toZoneId": k[1],
                                "trips": v,
                            },
                        }
                        for k, v in _hb_od.items()
                    ],
                },
            )

    def _build_mode_matrix(mode: str) -> tuple[str, dict]:
        _mode_network_fc = _filter_fc_by_mode(network_fc, mode)
        # zone_fc already contains refined (split) zones for BIKE — zone_refiner
        # ran in the per-mode track and the joiner used those geometries directly.
        _routes_fc = build_matrix(
            _mode_network_fc,
            feedlinks_fc,
            zone_fc,
            max_routes=max_routes,
            hb_od=_hb_od if mode == "CAR" else None,
            progress_label=mode,
            worker_share=len(_modes_to_build) or 1,
        )
        return mode, _routes_fc

    routes_by_mode: dict[str, dict] = {}
    _modes_to_build = []
    for _m in modes:
        _cached_routes = _ckpt.load(f"07_routes_{_m}")
        if _cached_routes is not None:
            routes_by_mode[_m] = _cached_routes
        else:
            _modes_to_build.append(_m)

    if _modes_to_build:
        with concurrent.futures.ThreadPoolExecutor(max_workers=len(_modes_to_build)) as _pool:
            _mb_futures = {m: _pool.submit(_build_mode_matrix, m) for m in _modes_to_build}
        for _m in _modes_to_build:
            _built = _mb_futures[_m].result()[1]
            routes_by_mode[_m] = _built
            _ckpt.save(f"07_routes_{_m}", _built)

    for _m, _rfc in routes_by_mode.items():
        print(f"  [{_m}] {len(_rfc.get('features') or []):,} route features built")

    if debug:
        _snapshot(
            7, area_id, out_dir, **{f"ROUTES_{_m}": _fc for _m, _fc in routes_by_mode.items()}
        )

    # ======================================================================
    # Write final outputs
    # ======================================================================
    network_path.write_bytes(to_geoparquet(network_fc))
    feedlinks_path.write_bytes(to_geoparquet(feedlinks_fc))
    zone_path.write_bytes(to_geoparquet(zone_fc))
    for _m, _routes_fc in routes_by_mode.items():
        routes_paths[_m].write_bytes(to_geoparquet(_routes_fc))

    if export_geojson:
        from gmt_utils.parquet_exporter.core.parquet_exporter_core import (
            export_to_geojson,
        )

        _geojson_path: Path | None = network_path.with_suffix(".geojson")
        _geojson_path.write_text(export_to_geojson(network_fc), encoding="utf-8")
    else:
        _geojson_path = None

    print()
    print("============================================================")
    print(" Pipeline complete.")
    print(f" Network            : {network_path}")
    if _geojson_path:
        print(f" GeoJSON            : {_geojson_path}")
    print(f" Feedlinks          : {feedlinks_path}")
    print(f" Zones              : {zone_path}")
    if traffic_assets_path.exists():
        print(f" Traffic assets     : {traffic_assets_path}")
    if buildings_path.exists():
        print(f" Buildings          : {buildings_path}")
    if vegetation_path.exists():
        print(f" Vegetation         : {vegetation_path}")
    for _m, _rpath in routes_paths.items():
        print(f" OD matrix ({_m:<12}): {_rpath}")
    print("============================================================")

    _ckpt.clear()
    return area_id
