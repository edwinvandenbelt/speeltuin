"""Unit tests for prepare.core.prepare_core — pure helper functions only."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from prepare.core import prepare_core
from prepare.core.prepare_core import (
    _apply_building_link_ratios,
    _apply_stage05,
    _CheckpointStore,
    _discover_or_create_area_id,
    _extract_area_polygon_json,
    _fetch_hb_matrix,
    _fetch_stage05_assets,
    _filter_fc_by_mode,
    _resolve_osm_flags,
    _run_stage05_enrichment,
    _Stage05Assets,
    _validate_modes,
    _zones_union_bbox,
    run_pipeline,
)

# ---------------------------------------------------------------------------
# _validate_modes
# ---------------------------------------------------------------------------


class TestValidateModes:
    def test_single_valid_mode_passes(self):
        _validate_modes(["CAR"], "CAR")  # no exception

    def test_multi_mode_passes(self):
        _validate_modes(["CAR", "BIKE"], "MIXED")  # no exception

    def test_pedestrian_alone_passes(self):
        _validate_modes(["PEDESTRIAN"], "PEDESTRIAN")  # no exception

    def test_empty_modes_raises(self):
        with pytest.raises(ValueError, match="At least one transport mode"):
            _validate_modes([], "CAR")

    def test_unknown_mode_raises(self):
        with pytest.raises(ValueError, match="Unsupported mode"):
            _validate_modes(["HELICOPTER"], "HELICOPTER")

    def test_pedestrian_combined_raises(self):
        with pytest.raises(ValueError, match="PEDESTRIAN cannot be combined"):
            _validate_modes(["PEDESTRIAN", "CAR"], "MIXED")

    def test_mode_label_with_hyphen_raises(self):
        with pytest.raises(ValueError, match="must not contain hyphens"):
            _validate_modes(["CAR"], "CAR-BIKE")

    def test_multi_mode_label_without_hyphen_passes(self):
        _validate_modes(["CAR", "BIKE"], "CARBIKE")  # no exception


# ---------------------------------------------------------------------------
# mode_label default logic
# ---------------------------------------------------------------------------


class TestModeLabelDefault:
    """Verify that the default-label logic applied in run_pipeline is correct.

    We test the logic directly rather than calling run_pipeline (which requires
    a live Databricks connection).  The rule is:
        len(modes) == 1  →  label = modes[0]
        len(modes) >  1  →  label = "MIXED"
    """

    def _apply_default(self, modes: list[str], mode_label: str | None = None) -> str:
        """Mirror the normalise/default block at the top of run_pipeline."""
        modes = [m.strip().upper() for m in modes]
        if mode_label is None:
            return "MIXED" if len(modes) > 1 else modes[0]
        return mode_label.strip().upper()

    def test_single_mode_defaults_to_mode_name(self):
        assert self._apply_default(["CAR"]) == "CAR"

    def test_multi_mode_defaults_to_mixed(self):
        assert self._apply_default(["CAR", "BIKE"]) == "MIXED"

    def test_explicit_label_overrides_default(self):
        assert self._apply_default(["CAR", "BIKE"], "MULTIMODAAL") == "MULTIMODAAL"

    def test_explicit_label_single_mode(self):
        assert self._apply_default(["CAR"], "WEGNETWERK") == "WEGNETWERK"


# ---------------------------------------------------------------------------
# _discover_or_create_area_id
# ---------------------------------------------------------------------------


class TestDiscoverOrCreateAreaId:
    def test_generates_fresh_uuid_for_empty_dir(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            area_id = _discover_or_create_area_id(out_dir)
            assert len(area_id) == 36  # UUID format

    def test_discovers_from_existing_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "my-fixed-id-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_or_create_area_id(out_dir) == "my-fixed-id"

    def test_stable_across_calls(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "stable-id-NETWORK-CAR.parquet").write_bytes(b"")
            id1 = _discover_or_create_area_id(out_dir)
            id2 = _discover_or_create_area_id(out_dir)
            assert id1 == id2

    def test_explicit_override_takes_priority(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "other-id-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_or_create_area_id(out_dir, area_id="forced-id") == "forced-id"


# ---------------------------------------------------------------------------
# _extract_area_polygon_json
# ---------------------------------------------------------------------------


class TestExtractAreaPolygonJson:
    def _make_zones_fc(self, features: list[dict]) -> dict:
        return {"type": "FeatureCollection", "features": features}

    def test_extracts_area_geometry(self):
        geom = {"type": "Polygon", "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 0]]]}
        zones_fc = self._make_zones_fc(
            [
                {"type": "Feature", "properties": {"zoneClass": "STUDY"}, "geometry": {}},
                {"type": "Feature", "properties": {"zoneClass": "AREA"}, "geometry": geom},
            ]
        )
        result = json.loads(_extract_area_polygon_json(zones_fc))
        assert result == geom

    def test_raises_when_no_area_feature(self):
        zones_fc = self._make_zones_fc(
            [
                {"type": "Feature", "properties": {"zoneClass": "STUDY"}, "geometry": {}},
            ]
        )
        with pytest.raises(ValueError, match="No AREA feature"):
            _extract_area_polygon_json(zones_fc)

    def test_raises_on_empty_feature_collection(self):
        with pytest.raises(ValueError):
            _extract_area_polygon_json(self._make_zones_fc([]))


# ---------------------------------------------------------------------------
# _zones_union_bbox
# ---------------------------------------------------------------------------


class TestZonesUnionBbox:
    def _zones_fc(self, area_geom: dict | None) -> dict:
        features = [{"type": "Feature", "properties": {"zoneClass": "STUDY"}, "geometry": {}}]
        if area_geom is not None:
            features.append(
                {"type": "Feature", "properties": {"zoneClass": "AREA"}, "geometry": area_geom}
            )
        return {"type": "FeatureCollection", "features": features}

    def test_none_zones_fc_returns_fallback_unchanged(self):
        fallback = [5.0, 51.0, 5.5, 51.5]
        assert _zones_union_bbox(None, fallback) == fallback

    def test_no_area_feature_returns_fallback_unchanged(self):
        zones_fc = self._zones_fc(None)
        fallback = [5.0, 51.0, 5.5, 51.5]
        assert _zones_union_bbox(zones_fc, fallback) == fallback

    def test_area_feature_with_no_geometry_returns_fallback_unchanged(self):
        zones_fc = self._zones_fc(None)
        zones_fc["features"].append(
            {"type": "Feature", "properties": {"zoneClass": "AREA"}, "geometry": None}
        )
        fallback = [5.0, 51.0, 5.5, 51.5]
        assert _zones_union_bbox(zones_fc, fallback) == fallback

    def test_area_geometry_inside_fallback_bbox_leaves_bbox_unchanged(self):
        # AREA polygon fully inside the fallback bbox -> union == fallback.
        area_geom = {
            "type": "Polygon",
            "coordinates": [[[5.1, 51.1], [5.2, 51.1], [5.2, 51.2], [5.1, 51.2], [5.1, 51.1]]],
        }
        zones_fc = self._zones_fc(area_geom)
        fallback = [5.0, 51.0, 5.5, 51.5]
        assert _zones_union_bbox(zones_fc, fallback) == fallback

    def test_area_geometry_extending_beyond_fallback_bbox_expands_it(self):
        # AREA polygon pokes out to the west and south of the fallback bbox.
        area_geom = {
            "type": "Polygon",
            "coordinates": [[[4.8, 50.9], [5.2, 50.9], [5.2, 51.2], [4.8, 51.2], [4.8, 50.9]]],
        }
        zones_fc = self._zones_fc(area_geom)
        fallback = [5.0, 51.0, 5.5, 51.5]
        result = _zones_union_bbox(zones_fc, fallback)
        assert result == [4.8, 50.9, 5.5, 51.5]

    def test_multipolygon_area_geometry_supported(self):
        area_geom = {
            "type": "MultiPolygon",
            "coordinates": [
                [[[6.0, 52.0], [6.3, 52.0], [6.3, 52.3], [6.0, 52.3], [6.0, 52.0]]],
            ],
        }
        zones_fc = self._zones_fc(area_geom)
        fallback = [6.1, 52.1, 6.2, 52.2]
        result = _zones_union_bbox(zones_fc, fallback)
        assert result == [6.0, 52.0, 6.3, 52.3]


# ---------------------------------------------------------------------------
# _filter_fc_by_mode
# ---------------------------------------------------------------------------


def _make_fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features, "properties": {"modeLabel": "MIXED"}}


def _make_link(mode: str) -> dict:
    return {"type": "Feature", "geometry": None, "properties": {"mode": mode, "linkId": 1}}


class TestFilterFcByMode:
    def test_keeps_matching_mode(self):
        fc = _make_fc([_make_link("CAR"), _make_link("BIKE")])
        result = _filter_fc_by_mode(fc, "CAR")
        assert len(result["features"]) == 1
        assert result["features"][0]["properties"]["mode"] == "CAR"

    def test_excludes_non_matching_mode(self):
        fc = _make_fc([_make_link("CAR"), _make_link("CAR")])
        result = _filter_fc_by_mode(fc, "BIKE")
        assert result["features"] == []

    def test_empty_input_stays_empty(self):
        fc = _make_fc([])
        result = _filter_fc_by_mode(fc, "CAR")
        assert result["features"] == []

    def test_preserves_top_level_properties(self):
        fc = _make_fc([_make_link("CAR")])
        result = _filter_fc_by_mode(fc, "CAR")
        assert result["properties"]["modeLabel"] == "MIXED"

    def test_features_without_mode_excluded(self):
        no_mode = {"type": "Feature", "geometry": None, "properties": {"linkId": 99}}
        fc = _make_fc([no_mode, _make_link("CAR")])
        result = _filter_fc_by_mode(fc, "CAR")
        assert len(result["features"]) == 1

    def test_returns_new_dict_not_mutation(self):
        fc = _make_fc([_make_link("CAR"), _make_link("BIKE")])
        result = _filter_fc_by_mode(fc, "CAR")
        assert len(fc["features"]) == 2  # original unchanged
        assert len(result["features"]) == 1


# ---------------------------------------------------------------------------
# source metadata in FC properties
# ---------------------------------------------------------------------------


class TestFcSourceMetadata:
    """Verify that prepare_core sets source='Spectrum' on output FCs.

    These tests exercise the dict-update patterns directly rather than
    running the full pipeline (which requires mocking Databricks).
    """

    def test_network_fc_properties_update_sets_source(self):
        fc: dict = {"type": "FeatureCollection", "features": []}
        fc.setdefault("properties", {}).update(
            {
                "bbox": [0.0, 0.0, 1.0, 1.0],
                "region": None,
                "area_id": "test",
                "name": "Test",
                "modeLabel": "CAR",
                "source": "Spectrum",
            }
        )
        assert fc["properties"]["source"] == "Spectrum"

    def test_zones_fc_properties_update_sets_source(self):
        fc: dict = {"type": "FeatureCollection", "features": [], "properties": {"name": "old"}}
        fc.setdefault("properties", {}).update({"name": "Test", "source": "Spectrum"})
        assert fc["properties"]["source"] == "Spectrum"
        assert fc["properties"]["name"] == "Test"

    def test_feedlinks_fc_properties_dict_contains_source(self):
        base_props: dict = {"area_id": "test"}
        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": [],
            "properties": {**base_props, "source": "Spectrum"},
        }
        assert feedlinks_fc["properties"]["source"] == "Spectrum"
        assert feedlinks_fc["properties"]["area_id"] == "test"  # base props preserved


# ---------------------------------------------------------------------------
# _CheckpointStore
# ---------------------------------------------------------------------------


def _sample_fc(n: int = 2) -> dict:
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [float(i), float(i)]},
                "properties": {"id": i},
            }
            for i in range(n)
        ],
        "properties": {"area_id": "test", "modes": ["CAR"]},
    }


class TestCheckpointStore:
    def test_save_load_roundtrip_preserves_features_and_properties(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            fc = _sample_fc(3)
            store.save("01_stage", fc)

            loaded = store.load("01_stage")
            assert loaded is not None
            assert len(loaded["features"]) == 3
            assert loaded["properties"]["area_id"] == "test"
            assert loaded["properties"]["modes"] == ["CAR"]

    def test_load_missing_returns_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            assert store.load("does_not_exist") is None

    def test_refresh_wipes_existing_and_disables_loading(self):
        with tempfile.TemporaryDirectory() as tmp:
            _CheckpointStore(Path(tmp), refresh=False).save("01_stage", _sample_fc())
            # A fresh store with refresh=True should ignore the pre-existing checkpoint.
            store = _CheckpointStore(Path(tmp), refresh=True)
            assert store.load("01_stage") is None

    def test_load_corrupt_checkpoint_returns_none(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            (store.dir / "01_stage.parquet").write_bytes(b"not a parquet file")
            assert store.load("01_stage") is None

    def test_save_is_atomic_no_tmp_left_behind(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            store.save("01_stage", _sample_fc())
            assert not (store.dir / "01_stage.parquet.tmp").exists()
            assert (store.dir / "01_stage.parquet").exists()

    def test_clear_removes_directory(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            store.save("01_stage", _sample_fc())
            store.clear()
            assert not store.dir.exists()

    def test_empty_featurecollection_roundtrip(self):
        with tempfile.TemporaryDirectory() as tmp:
            store = _CheckpointStore(Path(tmp), refresh=False)
            store.save("01_empty", {"type": "FeatureCollection", "features": [], "properties": {}})
            loaded = store.load("01_empty")
            assert loaded is not None
            assert loaded["features"] == []


# ---------------------------------------------------------------------------
# _resolve_osm_flags
# ---------------------------------------------------------------------------


class TestResolveOsmFlags:
    def _all_on(self, *, no_dt: bool, ndw_available: bool) -> dict:
        return _resolve_osm_flags(
            no_dt=no_dt,
            annotate_traffic_signals=True,
            fetch_traffic_signs=True,
            fetch_osm_assets=True,
            fetch_buildings=True,
            fetch_vegetation=True,
            fetch_parking_areas=True,
            fetch_bgt_assets=True,
            ndw_available=ndw_available,
        )

    def test_no_dt_false_passes_through(self):
        result = self._all_on(no_dt=False, ndw_available=False)
        assert result == {
            "annotate_traffic_signals": True,
            "fetch_traffic_signs": True,
            "fetch_osm_assets": True,
            "fetch_buildings": True,
            "fetch_vegetation": True,
            "fetch_parking_areas": True,
            "fetch_bgt_assets": True,
            "parking_use_osm": True,
        }

    def test_no_dt_false_preserves_disabled_flags(self):
        result = _resolve_osm_flags(
            no_dt=False,
            annotate_traffic_signals=False,
            fetch_traffic_signs=False,
            fetch_osm_assets=False,
            fetch_buildings=False,
            fetch_vegetation=False,
            fetch_parking_areas=False,
            fetch_bgt_assets=False,
            ndw_available=True,
        )
        assert result["annotate_traffic_signals"] is False
        assert result["fetch_osm_assets"] is False
        assert result["fetch_buildings"] is False
        assert result["fetch_parking_areas"] is False
        assert result["fetch_bgt_assets"] is False
        assert result["parking_use_osm"] is True

    def test_no_dt_disables_pure_osm_sources(self):
        result = self._all_on(no_dt=True, ndw_available=True)
        assert result["annotate_traffic_signals"] is False
        assert result["fetch_osm_assets"] is False
        assert result["fetch_buildings"] is False
        assert result["fetch_vegetation"] is False

    def test_no_dt_disables_bgt_and_parking(self):
        result = self._all_on(no_dt=True, ndw_available=True)
        # Both BGT and parking (OSM + BGT legs) are digital-twin sources -> off.
        assert result["fetch_bgt_assets"] is False
        assert result["fetch_parking_areas"] is False
        assert result["parking_use_osm"] is False

    def test_no_dt_signs_on_only_when_ndw_available(self):
        with_ndw = self._all_on(no_dt=True, ndw_available=True)
        without_ndw = self._all_on(no_dt=True, ndw_available=False)
        assert with_ndw["fetch_traffic_signs"] is True
        assert without_ndw["fetch_traffic_signs"] is False

    def test_no_dt_signs_off_when_disabled_even_with_ndw(self):
        result = _resolve_osm_flags(
            no_dt=True,
            annotate_traffic_signals=True,
            fetch_traffic_signs=False,
            fetch_osm_assets=True,
            fetch_buildings=True,
            fetch_vegetation=True,
            fetch_parking_areas=True,
            fetch_bgt_assets=True,
            ndw_available=True,
        )
        assert result["fetch_traffic_signs"] is False


# ---------------------------------------------------------------------------
# run_pipeline — no_dt / only_dt guards (no Databricks required)
# ---------------------------------------------------------------------------


class TestRunPipelineOsmModes:
    def test_no_dt_and_only_dt_mutually_exclusive(self):
        with (
            tempfile.TemporaryDirectory() as tmp,
            pytest.raises(ValueError, match="mutually exclusive"),
        ):
            run_pipeline(
                min_lon=6.0,
                min_lat=52.0,
                max_lon=6.1,
                max_lat=52.1,
                modes=["CAR"],
                name="Test",
                out_dir=Path(tmp),
                catalog="spectrum",
                schema="2024_01",
                refresh=False,
                debug=False,
                no_dt=True,
                only_dt=True,
            )

    def test_only_dt_without_existing_network_raises(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError, match="requires an existing network"):
                run_pipeline(
                    min_lon=6.0,
                    min_lat=52.0,
                    max_lon=6.1,
                    max_lat=52.1,
                    modes=["CAR"],
                    name="Test",
                    out_dir=Path(tmp),
                    catalog="spectrum",
                    schema="2024_01",
                    refresh=False,
                    debug=False,
                    only_dt=True,
                )
            # No output files should have been written.
            assert not any(Path(tmp).glob("*-NETWORK-*.parquet"))


# ---------------------------------------------------------------------------
# Area dispatch: bbox outside the Netherlands delegates to osm_prepare
# ---------------------------------------------------------------------------

_NL_BBOX = [6.0, 52.0, 6.1, 52.1]
_NON_NL_BBOX = [10.0, 50.0, 10.1, 50.1]  # well inside Germany


class TestAreaDispatch:
    def test_nl_bbox_without_catalog_raises(self):
        with (
            tempfile.TemporaryDirectory() as tmp,
            pytest.raises(ValueError, match="catalog and schema are required"),
        ):
            run_pipeline(
                min_lon=_NL_BBOX[0],
                min_lat=_NL_BBOX[1],
                max_lon=_NL_BBOX[2],
                max_lat=_NL_BBOX[3],
                modes=["CAR"],
                name="Test",
                out_dir=Path(tmp),
                refresh=False,
                debug=False,
            )

    def test_non_nl_bbox_delegates_to_osm_prepare(self, monkeypatch):
        calls: dict = {}

        def _fake_osm_run_pipeline(min_lon, min_lat, max_lon, max_lat, out_dir, **kwargs):
            calls["bbox"] = (min_lon, min_lat, max_lon, max_lat)
            calls["out_dir"] = out_dir
            calls["kwargs"] = kwargs
            return "fake-osm-area-id"

        monkeypatch.setattr(
            "osm.osm_prepare.core.osm_prepare_core.run_pipeline",
            _fake_osm_run_pipeline,
        )

        with tempfile.TemporaryDirectory() as tmp:
            result = run_pipeline(
                min_lon=_NON_NL_BBOX[0],
                min_lat=_NON_NL_BBOX[1],
                max_lon=_NON_NL_BBOX[2],
                max_lat=_NON_NL_BBOX[3],
                modes=["CAR"],
                name="Test",
                out_dir=Path(tmp),
                refresh=False,
                debug=False,
            )

        assert result == "fake-osm-area-id"
        assert calls["bbox"] == tuple(_NON_NL_BBOX)
        assert calls["kwargs"]["annotate_traffic_signals"] is False
        assert calls["kwargs"]["fetch_traffic_signs"] is False
        assert calls["kwargs"]["fetch_osm_assets"] is False
        assert calls["kwargs"]["add_elevation"] is False
        assert calls["kwargs"]["enrich_priority_roundabouts"] is False
        # Databricks catalog/schema are irrelevant for this path — omitting
        # them must not raise.

    def test_non_nl_bbox_with_non_car_mode_raises(self):
        with (
            tempfile.TemporaryDirectory() as tmp,
            pytest.raises(ValueError, match="only supports CAR mode"),
        ):
            run_pipeline(
                min_lon=_NON_NL_BBOX[0],
                min_lat=_NON_NL_BBOX[1],
                max_lon=_NON_NL_BBOX[2],
                max_lat=_NON_NL_BBOX[3],
                modes=["BIKE"],
                name="Test",
                out_dir=Path(tmp),
                refresh=False,
                debug=False,
            )


# ---------------------------------------------------------------------------
# _apply_building_link_ratios
# ---------------------------------------------------------------------------


def _link_feature(link_id: str, coords: list[list[float]]) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {"linkId": link_id},
    }


def _building_feature(lon: float, lat: float, building_type: str = "shop") -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": {"buildingType": building_type},
    }


class TestApplyBuildingLinkRatios:
    def _network_fc(self) -> dict:
        return {
            "type": "FeatureCollection",
            "features": [_link_feature("L1", [[0.0, 0.0], [0.0, 0.0002]])],
        }

    def test_uses_buildings_fc_from_assets_when_present(self, tmp_path):
        buildings_fc = {
            "type": "FeatureCollection",
            "features": [_building_feature(0.0, 0.0001)],
        }
        assets = _Stage05Assets(buildings_fc=buildings_fc)

        network_fc = _apply_building_link_ratios(
            self._network_fc(), assets, buildings_path=tmp_path / "missing.parquet"
        )

        props = network_fc["features"][0]["properties"]
        assert "buildingMotifRatio" in props
        assert props["buildingMotifRatio"] == {"shop": pytest.approx(1.0)}

    def test_falls_back_to_buildings_path_when_assets_empty(self, tmp_path, monkeypatch):
        # Simulates a resumed run: _run_stage05_enrichment returned a fresh,
        # empty _Stage05Assets() because "05_network_annotated" was loaded
        # from checkpoint, so the in-memory buildings_fc is gone — but the
        # buildings were already written to disk on the earlier run.
        buildings_path = tmp_path / "area-BUILDINGS.parquet"
        buildings_path.write_bytes(b"not-real-parquet")  # from_geoparquet is faked below

        buildings_fc = {
            "type": "FeatureCollection",
            "features": [_building_feature(0.0, 0.0001)],
        }
        monkeypatch.setattr(prepare_core, "from_geoparquet", lambda _data: buildings_fc)

        assets = _Stage05Assets()  # buildings_fc=None, as after a checkpoint resume
        network_fc = _apply_building_link_ratios(
            self._network_fc(), assets, buildings_path=buildings_path
        )

        props = network_fc["features"][0]["properties"]
        assert "buildingMotifRatio" in props

    def test_no_buildings_available_is_a_no_op(self, tmp_path):
        assets = _Stage05Assets()  # buildings_fc=None
        network_fc = self._network_fc()

        result = _apply_building_link_ratios(
            network_fc, assets, buildings_path=tmp_path / "missing.parquet"
        )

        assert result is network_fc
        assert "buildingMotifRatio" not in result["features"][0]["properties"]


# ---------------------------------------------------------------------------
# Stage-5 split: _fetch_stage05_assets / _apply_stage05
# ---------------------------------------------------------------------------

_BBOX = [6.0, 52.0, 6.1, 52.1]


def _feat(id_: str) -> dict:
    """Minimal GeoJSON point feature with a stable identifier property."""
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [6.05, 52.05]},
        "properties": {"id": id_},
    }


def _patch_all_fetchers(monkeypatch, *, fail: set[str] | None = None) -> None:
    """Monkeypatch every stage-5 fetcher with deterministic, network-free stubs.

    Fetchers named in *fail* raise, to exercise per-fetcher failure isolation.
    """
    fail = fail or set()

    import gmt_network_enrichment.bgt_fetcher.core.bgt_fetcher_core as bgt
    import gmt_network_enrichment.osm_asset_fetcher.core.osm_asset_fetcher_core as osm
    import gmt_network_enrichment.parking_area_fetcher.core.parking_area_fetcher_core as park
    import gmt_network_enrichment.traffic_sign_fetcher.core.traffic_sign_fetcher_core as sign
    import gmt_network_enrichment.traffic_signal_annotator.core.traffic_signal_annotator_core as sig

    import osm.osm_building_fetcher.core.osm_building_fetcher_core as bld
    import osm.osm_vegetation_fetcher.core.osm_vegetation_fetcher_core as veg

    def _guard(name, fn):
        def _inner(*a, **k):
            if name in fail:
                raise RuntimeError(f"boom-{name}")
            return fn(*a, **k)

        return _inner

    monkeypatch.setattr(
        sig, "fetch_signal_coords", _guard("signals", lambda *_a, **_k: [(6.05, 52.05)])
    )
    monkeypatch.setattr(sign, "is_netherlands", lambda _bbox: False)
    monkeypatch.setattr(
        sign,
        "fetch_sign_features",
        _guard("signs", lambda *_a, **_k: ({"features": [_feat("sign1")]}, {"source": "OSM"})),
    )
    monkeypatch.setattr(
        bgt,
        "fetch_bgt_assets",
        _guard(
            "bgt",
            lambda *_a, **_k: ({"features": [_feat("bgt1")]}, {"speedBump": 1, "source": "BGT"}),
        ),
    )
    monkeypatch.setattr(
        osm,
        "fetch_osm_assets",
        _guard(
            "osm",
            lambda *_a, **_k: ({"features": [_feat("osm1")]}, {"counts": {}, "source": "OSM"}),
        ),
    )
    monkeypatch.setattr(
        park,
        "fetch_parking_areas",
        _guard(
            "parking",
            lambda *_a, **_k: (
                {"features": [_feat("park1")]},
                {"bgt": 1, "osm": 0, "source": "BGT"},
            ),
        ),
    )
    monkeypatch.setattr(
        bld,
        "build_buildings",
        _guard(
            "buildings",
            lambda *_a, **_k: (
                {"type": "FeatureCollection", "features": [_feat("bld1")]},
                {"buildings": 1},
            ),
        ),
    )
    monkeypatch.setattr(
        veg,
        "build_vegetation",
        _guard(
            "vegetation",
            lambda *_a, **_k: (
                {"type": "FeatureCollection", "features": [_feat("veg1")]},
                {"total": 1},
            ),
        ),
    )


_ALL_ON = {
    "annotate_traffic_signals": True,
    "fetch_traffic_signs": True,
    "fetch_bgt_assets": True,
    "fetch_osm_assets": True,
    "fetch_parking_areas": True,
    "fetch_buildings": True,
    "fetch_vegetation": True,
    "parking_use_osm": False,
    "ndw_data_uri": None,
    "bgt_url": None,
    "signal_overpass_timeout": 60,
}


class TestStage05Assets:
    def test_any_traffic_asset_true_when_a_contributor_ran(self):
        assets = _Stage05Assets(bgt_ran=True)
        assert assets.any_traffic_asset is True

    def test_any_traffic_asset_false_for_buildings_and_vegetation_only(self):
        assets = _Stage05Assets(buildings_ran=True, vegetation_ran=True)
        assert assets.any_traffic_asset is False


class TestFetchStage05Assets:
    def test_runs_all_enabled_fetchers(self, monkeypatch):
        _patch_all_fetchers(monkeypatch)
        assets = _fetch_stage05_assets(bbox=_BBOX, **_ALL_ON)

        assert assets.signal_coords == [(6.05, 52.05)]
        assert [f["properties"]["id"] for f in assets.sign_features] == ["sign1"]
        assert [f["properties"]["id"] for f in assets.bgt_features] == ["bgt1"]
        assert [f["properties"]["id"] for f in assets.osm_features] == ["osm1"]
        assert [f["properties"]["id"] for f in assets.parking_features] == ["park1"]
        assert assets.buildings_fc is not None
        assert assets.vegetation_fc is not None
        assert assets.any_traffic_asset is True

    def test_disabled_fetchers_stay_empty(self, monkeypatch):
        _patch_all_fetchers(monkeypatch)
        flags = {**_ALL_ON, "fetch_buildings": False, "fetch_vegetation": False}
        assets = _fetch_stage05_assets(bbox=_BBOX, **flags)

        assert assets.buildings_ran is False
        assert assets.vegetation_ran is False
        assert assets.buildings_fc is None
        assert assets.vegetation_fc is None

    def test_one_failing_fetcher_does_not_abort_the_batch(self, monkeypatch):
        _patch_all_fetchers(monkeypatch, fail={"bgt"})
        assets = _fetch_stage05_assets(bbox=_BBOX, **_ALL_ON)

        # BGT failed but is marked as ran (so a warning is logged) and stays empty.
        assert assets.bgt_ran is True
        assert assets.bgt_features == []
        assert "bgt_fetcher failed" in assets.logs["bgt"]
        # Every other contributor still produced its features.
        assert [f["properties"]["id"] for f in assets.osm_features] == ["osm1"]
        assert [f["properties"]["id"] for f in assets.parking_features] == ["park1"]

    def test_buildings_bbox_expanded_by_zones_fc_area_feature(self, monkeypatch):
        """The buildings fetch alone should use the AREA-expanded bbox."""
        _patch_all_fetchers(monkeypatch)
        captured: dict[str, list] = {}

        import osm.osm_building_fetcher.core.osm_building_fetcher_core as bld

        def _capture_bbox(bbox, **_k):
            captured["bbox"] = bbox
            return ({"type": "FeatureCollection", "features": [_feat("bld1")]}, {"buildings": 1})

        monkeypatch.setattr(bld, "build_buildings", _capture_bbox)

        # AREA geometry pokes out west of _BBOX = [6.0, 52.0, 6.1, 52.1].
        area_geom = {
            "type": "Polygon",
            "coordinates": [[[5.8, 52.0], [6.1, 52.0], [6.1, 52.1], [5.8, 52.1], [5.8, 52.0]]],
        }
        zones_fc = {
            "type": "FeatureCollection",
            "features": [
                {"type": "Feature", "properties": {"zoneClass": "AREA"}, "geometry": area_geom}
            ],
        }

        _fetch_stage05_assets(bbox=_BBOX, zones_fc=zones_fc, **_ALL_ON)

        assert captured["bbox"] == [5.8, 52.0, 6.1, 52.1]

    def test_buildings_bbox_unchanged_without_zones_fc(self, monkeypatch):
        """Omitting zones_fc must not change the buildings bbox (backward compatible)."""
        _patch_all_fetchers(monkeypatch)
        captured: dict[str, list] = {}

        import osm.osm_building_fetcher.core.osm_building_fetcher_core as bld

        def _capture_bbox(bbox, **_k):
            captured["bbox"] = bbox
            return ({"type": "FeatureCollection", "features": [_feat("bld1")]}, {"buildings": 1})

        monkeypatch.setattr(bld, "build_buildings", _capture_bbox)

        _fetch_stage05_assets(bbox=_BBOX, **_ALL_ON)

        assert captured["bbox"] == _BBOX


class TestApplyStage05:
    def _patch_apply(self, monkeypatch):
        captured: dict[str, dict] = {}
        monkeypatch.setattr(
            prepare_core, "to_geoparquet", lambda fc: captured.__setitem__("last", fc) or b"x"
        )
        import gmt_network_enrichment.traffic_signal_annotator.core.traffic_signal_annotator_core as sig

        monkeypatch.setattr(
            sig,
            "annotate_network",
            lambda fc, *_a, **_k: (fc, {"annotated": 1, "total": 2}),
        )
        monkeypatch.setattr(sig, "signals_to_features", lambda *_a: [_feat("signal1")])
        return captured

    def test_fixed_order_of_combined_traffic_assets(self, monkeypatch, tmp_path):
        self._patch_apply(monkeypatch)
        assets = _Stage05Assets(
            signal_coords=[(6.05, 52.05)],
            signal_ran=True,
            sign_features=[_feat("sign1")],
            sign_ran=True,
            bgt_features=[_feat("bgt1")],
            bgt_ran=True,
            osm_features=[_feat("osm1")],
            osm_ran=True,
            parking_features=[_feat("park1")],
            parking_ran=True,
        )
        ta = tmp_path / "TA.parquet"
        written: list[dict] = []
        monkeypatch.setattr(prepare_core, "to_geoparquet", lambda fc: written.append(fc) or b"x")
        _apply_stage05(
            {"type": "FeatureCollection", "features": []},
            assets,
            bbox=_BBOX,
            area_id="A",
            out_dir=tmp_path,
            debug=False,
            traffic_assets_path=ta,
            buildings_path=tmp_path / "B.parquet",
            vegetation_path=tmp_path / "V.parquet",
            signal_tolerance_m=5.0,
        )
        ids = [f["properties"]["id"] for f in written[0]["features"]]
        assert ids == ["signal1", "sign1", "bgt1", "osm1", "park1"]
        assert ta.exists()

    def test_no_traffic_parquet_when_only_buildings(self, monkeypatch, tmp_path):
        self._patch_apply(monkeypatch)
        assets = _Stage05Assets(
            buildings_fc={"type": "FeatureCollection", "features": [_feat("b")]},
            buildings_stats={"buildings": 1},
            buildings_ran=True,
        )
        ta = tmp_path / "TA.parquet"
        bld = tmp_path / "B.parquet"
        _apply_stage05(
            {"type": "FeatureCollection", "features": []},
            assets,
            bbox=_BBOX,
            area_id="A",
            out_dir=tmp_path,
            debug=False,
            traffic_assets_path=ta,
            buildings_path=bld,
            vegetation_path=tmp_path / "V.parquet",
            signal_tolerance_m=5.0,
        )
        assert not ta.exists()
        assert bld.exists()

    def test_bgt_speed_bumps_enrich_num_speed_bumps(self, monkeypatch, tmp_path):
        """BGT speed-bump polygons must be matched and counted on the network."""
        self._patch_apply(monkeypatch)
        network = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "LineString",
                        "coordinates": [[6.05, 52.05], [6.06, 52.05]],
                    },
                    "properties": {"linkId": 100, "toNode": "B"},
                }
            ],
        }
        bgt_speed_bump = {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [
                    [
                        [6.052, 52.049],
                        [6.053, 52.051],
                        [6.054, 52.049],
                        [6.052, 52.049],
                    ]
                ],
            },
            "properties": {"id": "bgt-speedbump", "assetType": "speedBump"},
        }
        assets = _Stage05Assets(
            bgt_features=[bgt_speed_bump],
            bgt_ran=True,
        )
        result = _apply_stage05(
            network,
            assets,
            bbox=_BBOX,
            area_id="A",
            out_dir=tmp_path,
            debug=False,
            traffic_assets_path=tmp_path / "TA.parquet",
            buildings_path=tmp_path / "B.parquet",
            vegetation_path=tmp_path / "V.parquet",
            signal_tolerance_m=5.0,
        )
        props = result["features"][0]["properties"]
        assert props["numSpeedBumps"] == 1


class TestRunStage05Wrapper:
    def test_resume_from_checkpoint_skips_fetch(self, monkeypatch, tmp_path):
        ckpt = _CheckpointStore(tmp_path, refresh=False)
        sentinel = {"type": "FeatureCollection", "features": [_feat("cached")]}
        ckpt.save("05_network_annotated", sentinel)

        # Any fetch attempt would explode — proving the checkpoint short-circuits.
        def _boom(**_k):
            raise AssertionError("should not fetch on resume")

        monkeypatch.setattr(prepare_core, "_fetch_stage05_assets", _boom)

        out, _stage_assets = _run_stage05_enrichment(
            {"type": "FeatureCollection", "features": []},
            bbox=_BBOX,
            area_id="A",
            out_dir=tmp_path,
            debug=False,
            traffic_assets_path=tmp_path / "TA.parquet",
            buildings_path=tmp_path / "B.parquet",
            vegetation_path=tmp_path / "V.parquet",
            annotate_traffic_signals=True,
            fetch_traffic_signs=True,
            fetch_bgt_assets=True,
            fetch_osm_assets=True,
            fetch_parking_areas=True,
            fetch_buildings=True,
            fetch_vegetation=True,
            parking_use_osm=False,
            ndw_data_uri=None,
            bgt_url=None,
            signal_tolerance_m=5.0,
            signal_overpass_timeout=60,
            ckpt=ckpt,
            use_checkpoint=True,
        )
        assert out["features"][0]["properties"]["id"] == "cached"
        assert isinstance(_stage_assets, _Stage05Assets)

    def test_uses_prefetched_assets_without_refetching(self, monkeypatch, tmp_path):
        ckpt = _CheckpointStore(tmp_path, refresh=False)
        monkeypatch.setattr(
            prepare_core,
            "_fetch_stage05_assets",
            lambda **_k: (_ for _ in ()).throw(AssertionError("should use prefetched")),
        )
        written: list[dict] = []
        monkeypatch.setattr(prepare_core, "to_geoparquet", lambda fc: written.append(fc) or b"x")
        prefetched = _Stage05Assets(bgt_features=[_feat("pre-bgt")], bgt_ran=True)

        _run_stage05_enrichment(
            {"type": "FeatureCollection", "features": []},
            bbox=_BBOX,
            area_id="A",
            out_dir=tmp_path,
            debug=False,
            traffic_assets_path=tmp_path / "TA.parquet",
            buildings_path=tmp_path / "B.parquet",
            vegetation_path=tmp_path / "V.parquet",
            annotate_traffic_signals=False,
            fetch_traffic_signs=False,
            fetch_bgt_assets=True,
            fetch_osm_assets=False,
            fetch_parking_areas=False,
            fetch_buildings=False,
            fetch_vegetation=False,
            parking_use_osm=False,
            ndw_data_uri=None,
            bgt_url=None,
            signal_tolerance_m=5.0,
            signal_overpass_timeout=60,
            ckpt=ckpt,
            use_checkpoint=True,
            prefetched=prefetched,
        )
        ids = [f["properties"]["id"] for f in written[0]["features"]]
        assert ids == ["pre-bgt"]


# ---------------------------------------------------------------------------
# _fetch_hb_matrix
# ---------------------------------------------------------------------------


class _FakeCursor:
    def __init__(self, cols, rows):
        self.description = [(c,) for c in cols]
        self._rows = rows

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def execute(self, sql):
        self._sql = sql

    def fetchall(self):
        return self._rows


class _FakeConn:
    def __init__(self, cursor):
        self._cursor = cursor

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False

    def cursor(self):
        return self._cursor


def _zones_fc_with_gids():
    def _z(gid, zone_id, zone_class):
        return {
            "type": "Feature",
            "geometry": None,
            "properties": {"gid": gid, "zoneId": zone_id, "zoneClass": zone_class},
        }

    return {
        "type": "FeatureCollection",
        "features": [
            _z(10, "A", "STUDY"),
            _z(20, "B", "INFLUENCE"),
            _z(None, "area", "AREA"),
        ],
    }


class TestFetchHbMatrix:
    def _patch_conn(self, monkeypatch, cols, rows):
        import gmt_shared.databricks_sql as dbsql

        monkeypatch.setattr(dbsql, "connect_from_env", lambda: _FakeConn(_FakeCursor(cols, rows)))

    def test_maps_gids_to_zone_ids(self, monkeypatch):
        cols = ["from_zone_gid", "to_zone_gid", "trips"]
        rows = [(10, 20, 100.0), (20, 10, 40.0)]
        self._patch_conn(monkeypatch, cols, rows)
        hb = _fetch_hb_matrix("cat", "2023_01", _zones_fc_with_gids())
        assert hb == {("A", "B"): 100.0, ("B", "A"): 40.0}

    def test_aggregates_duplicate_pairs(self, monkeypatch):
        cols = ["from_zone_gid", "to_zone_gid", "trips"]
        rows = [(10, 20, 100.0), (10, 20, 25.0)]
        self._patch_conn(monkeypatch, cols, rows)
        hb = _fetch_hb_matrix("cat", "2023_01", _zones_fc_with_gids())
        assert hb[("A", "B")] == pytest.approx(125.0)

    def test_skips_unknown_gids(self, monkeypatch):
        cols = ["from_zone_gid", "to_zone_gid", "trips"]
        rows = [(10, 999, 100.0)]  # 999 not a known inner gid
        self._patch_conn(monkeypatch, cols, rows)
        hb = _fetch_hb_matrix("cat", "2023_01", _zones_fc_with_gids())
        assert hb == {}

    def test_no_inner_gids_returns_empty(self):
        # Only an AREA zone -> no inner gids -> no DB call needed.
        zones = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": None,
                    "properties": {"gid": None, "zoneId": "area", "zoneClass": "AREA"},
                }
            ],
        }
        hb = _fetch_hb_matrix("cat", "2023_01", zones)
        assert hb == {}

    def test_db_error_degrades_to_empty(self, monkeypatch):
        import gmt_shared.databricks_sql as dbsql

        def _boom():
            raise RuntimeError("no such table")

        monkeypatch.setattr(dbsql, "connect_from_env", _boom)
        hb = _fetch_hb_matrix("cat", "2023_01", _zones_fc_with_gids())
        assert hb == {}

    def test_other_schema_falls_back_to_synthetic(self, monkeypatch):
        # For any schema other than 2023_01 the real HB matrix is unavailable;
        # the function must return an empty dict WITHOUT touching the database.
        import gmt_shared.databricks_sql as dbsql

        def _boom():
            raise AssertionError("connect_from_env must not be called for other schemas")

        monkeypatch.setattr(dbsql, "connect_from_env", _boom)
        hb = _fetch_hb_matrix("cat", "2024_01", _zones_fc_with_gids())
        assert hb == {}


class TestHbMatrixCheckpointRoundTrip:
    """The HB OD matrix must survive the FeatureCollection-based checkpoint store."""

    def _save_hb(self, ckpt, hb_od):
        ckpt.save(
            "06b_hb_matrix",
            {
                "type": "FeatureCollection",
                "features": [
                    {
                        "type": "Feature",
                        "geometry": None,
                        "properties": {"fromZoneId": k[0], "toZoneId": k[1], "trips": v},
                    }
                    for k, v in hb_od.items()
                ],
            },
        )

    def _load_hb(self, ckpt):
        cached = ckpt.load("06b_hb_matrix")
        return {
            (str(p.get("fromZoneId")), str(p.get("toZoneId"))): float(p.get("trips") or 0.0)
            for feat in (cached.get("features") or [])
            if (p := feat.get("properties") or {}).get("fromZoneId") is not None
        }

    def test_non_empty_matrix_round_trips(self):
        with tempfile.TemporaryDirectory() as tmp:
            ckpt = _CheckpointStore(Path(tmp), refresh=False)
            hb_od = {("A", "B"): 12.0, ("A", "C"): 3.5, ("D", "E"): 100.0}
            self._save_hb(ckpt, hb_od)
            assert self._load_hb(ckpt) == hb_od

    def test_empty_matrix_round_trips_without_error(self):
        with tempfile.TemporaryDirectory() as tmp:
            ckpt = _CheckpointStore(Path(tmp), refresh=False)
            self._save_hb(ckpt, {})
            assert self._load_hb(ckpt) == {}
