"""Extract stopping lanes (opstelstroken) from turn:lanes OSM tags.

Stopping lanes are lane-specific turning movement indicators encoded in OSM
as pipe-separated turn directions on way tags:

    turn:lanes = "left|through|through|right"
    turn:lanes:forward = "left|through|through|right"
    turn:lanes:backward = "left|right"

Each pipe-separated value represents a single traffic lane and the allowed
turning movement(s) from that lane. Values include:
    left, right, through, slight_left, slight_right, sharp_left, sharp_right,
    left_right, left_straight, right_straight, through_left, through_right,
    etc.

Generation Strategy
-------------------
For each way with turn:lanes* tags:
1. Parse the pipe-separated turn directions
2. For each lane, generate a Point feature positioned on the way geometry
3. Lanes are positioned perpendicular to the way centerline:
   - Left lanes: offset to the left
   - Right lanes: offset to the right
   - Through lanes: on the centerline
4. Spatially match each lane point to the nearest network link to attach linkId

Output
------
Each feature is a Point with assetType='stoppingLane' and properties:
- osm_id: Original OSM way ID
- laneIndex: Position in the turn:lanes sequence (0-based)
- turnDirection: The parsed turn movement (e.g., "left", "through")
- direction: "forward" or "backward" (which turn:lanes variant)
- linkId: Matched network link ID (filled via spatial matching)
- nodeId: Destination node of the matched link
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)


def parse_turn_lanes_tag(value: str | None) -> list[str]:
    """Parse pipe-separated turn directions from OSM turn:lanes* tag.

    Parameters
    ----------
    value:
        Pipe-separated string, e.g., "left|through|right".

    Returns
    -------
    list[str]
        List of turn directions, or empty list if None/empty.
    """
    if not value:
        return []
    # Split by pipe and strip whitespace.
    directions = [d.strip() for d in value.split("|")]
    # Filter out empty strings (in case of double-pipes, trailing pipes, etc.).
    return [d for d in directions if d]


def _linestring_offset_points(
    coords: list[list[float]],
    offset_distance: float = 0.0000045,  # ~0.5m in degrees at 52°N
    left_side: bool = True,
) -> list[list[float]]:
    """Calculate offset points perpendicular to a LineString.

    For each vertex, calculate a perpendicular offset to the left or right.
    Returns list of offset points (one per original vertex).

    Parameters
    ----------
    coords:
        [[lon, lat], ...] LineString coordinates.
    offset_distance:
        Perpendicular offset distance in degrees.
    left_side:
        If True, offset to the left; else to the right.

    Returns
    -------
    list[list[float]]
        Offset coordinates [[lon, lat], ...].
    """
    if len(coords) < 2:
        return coords

    offset_points = []

    for i, (lon, lat) in enumerate(coords):
        if i == 0:
            # First point: use direction to next point.
            dx = coords[1][0] - lon
            dy = coords[1][1] - lat
        elif i == len(coords) - 1:
            # Last point: use direction from previous point.
            dx = lon - coords[i - 1][0]
            dy = lat - coords[i - 1][1]
        else:
            # Middle points: average direction to next and previous.
            dx = coords[i + 1][0] - coords[i - 1][0]
            dy = coords[i + 1][1] - coords[i - 1][1]

        # Normalize direction vector.
        norm = (dx**2 + dy**2) ** 0.5
        if norm < 1e-10:
            offset_points.append([lon, lat])
            continue

        dx /= norm
        dy /= norm

        # Perpendicular (rotate 90°): (-dy, dx) for left, (dy, -dx) for right.
        if left_side:
            perp_dx, perp_dy = -dy, dx
        else:
            perp_dx, perp_dy = dy, -dx

        # Apply offset.
        offset_lon = lon + perp_dx * offset_distance
        offset_lat = lat + perp_dy * offset_distance

        offset_points.append([offset_lon, offset_lat])

    return offset_points


def _way_linestring(geometry: list[dict]) -> list[list[float]] | None:
    """Extract [[lon, lat], ...] from Overpass way geometry."""
    pts = [[float(p["lon"]), float(p["lat"])] for p in geometry if "lat" in p and "lon" in p]
    if len(pts) < 2:
        return None
    return pts


def _bearing_at_point(coords: list[list[float]]) -> float:
    """Calculate bearing (azimuth) of LineString at its midpoint.

    Parameters
    ----------
    coords:
        [[lon, lat], ...] LineString coordinates.

    Returns
    -------
    float
        Bearing in degrees (0-360), where 0=North, 90=East, 180=South, 270=West.
    """
    if len(coords) < 2:
        return 0.0

    # Use bearing from first to last point (overall direction).
    lon1, lat1 = coords[0]
    lon2, lat2 = coords[-1]

    # Calculate bearing using atan2.
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    dlon = math.radians(lon2 - lon1)

    y = math.sin(dlon) * math.cos(lat2_rad)
    x = math.cos(lat1_rad) * math.sin(lat2_rad) - math.sin(lat1_rad) * math.cos(
        lat2_rad
    ) * math.cos(dlon)

    bearing = math.degrees(math.atan2(y, x))
    return (bearing + 360) % 360  # Normalize to 0-360


def _offset_point_perpendicular(
    lon: float,
    lat: float,
    bearing: float,
    distance: float,
    left_side: bool = True,
) -> list[float]:
    """Calculate a point offset perpendicular to a bearing direction.

    Parameters
    ----------
    lon, lat:
        Starting point coordinates.
    bearing:
        Bearing (azimuth) in degrees (0-360).
    distance:
        Offset distance in decimal degrees.
    left_side:
        If True, offset to the left of bearing direction; else to the right.

    Returns
    -------
    list[float]
        [lon_offset, lat_offset]
    """
    # Perpendicular bearing: 90° to the left, or 270° (90° to the right).
    perp_bearing = (bearing + 90) % 360 if left_side else (bearing + 270) % 360

    # Move in perpendicular direction by offset distance.
    perp_bearing_rad = math.radians(perp_bearing)
    offset_lon = lon + distance * math.cos(perp_bearing_rad)
    offset_lat = lat + distance * math.sin(perp_bearing_rad)

    return [offset_lon, offset_lat]


def stopping_lane_features_from_way(
    way_element: dict,
) -> list[dict]:
    """Generate stopping lane Point features from a single OSM way.

    For each turn:lanes* tag variant, generate lane points positioned
    transversally across the way (perpendicular offsets).

    Each lane gets a Point feature at the centroid of the way, offset
    perpendicular to the way direction. Lane positions are:
    - Lane 0 (left-most): offset to the left
    - Lane N/2 (center): on centerline
    - Lane N (right-most): offset to the right

    Parameters
    ----------
    way_element:
        Overpass way element with turn:lanes* tags and full geometry.

    Returns
    -------
    list[dict]
        GeoJSON Point features with assetType='stoppingLane', each at
        (lon, lat) with turnDirection preserved for visualization.
    """
    features: list[dict] = []
    tags = way_element.get("tags") or {}
    osm_id = way_element.get("id")
    geometry = way_element.get("geometry") or []

    # Extract LineString from Overpass geometry.
    coords = _way_linestring(geometry)
    if coords is None or len(coords) < 2:
        return features

    # Compute way centroid (midpoint of LineString).
    way_centroid = coords[len(coords) // 2]

    # Compute way bearing at centroid for perpendicularity.
    way_bearing = _bearing_at_point(coords)

    # Process each turn:lanes variant.
    for tag_key, direction in [
        ("turn:lanes:forward", "forward"),
        ("turn:lanes:backward", "backward"),
        ("turn:lanes", "both"),  # Fallback to symmetric if no directional tag
    ]:
        value = tags.get(tag_key)
        if not value:
            continue

        turn_directions = parse_turn_lanes_tag(value)
        if not turn_directions:
            continue

        num_lanes = len(turn_directions)

        # Determine lane positioning: center at num_lanes/2.
        # Lane indices 0, 1, 2, 3 for 4 lanes → positions -1.5, -0.5, +0.5, +1.5
        for lane_idx, turn_dir in enumerate(turn_directions):
            # Position relative to center (-num_lanes/2 to +num_lanes/2).
            position = lane_idx - num_lanes / 2.0 + 0.5
            is_left = position < 0

            # Calculate offset based on lane position.
            # Each lane is ~3m wide ≈ 0.000027 degrees at 52°N.
            offset_distance = abs(position) * 0.000027

            # Compute perpendicular offset from centroid.
            lane_point = _offset_point_perpendicular(
                way_centroid[0],
                way_centroid[1],
                way_bearing,
                offset_distance,
                left_side=is_left,
            )

            props = {
                "osm_id": osm_id,
                "assetType": "stoppingLane",
                "laneIndex": lane_idx,
                "turnDirection": turn_dir,
                "direction": direction,
                # linkId and nodeId will be filled in by match_lane_points_to_network()
                "linkId": None,
                "nodeId": None,
                **tags,  # Preserve all raw OSM tags
            }

            features.append(
                {
                    "type": "Feature",
                    "geometry": {"type": "Point", "coordinates": lane_point},
                    "properties": props,
                }
            )

    return features


def match_lane_points_to_network(
    lane_features: list[dict],
    network_fc: dict,
    max_distance_m: float = 20.0,
) -> list[dict]:
    """Attach linkId + nodeId to lane points via spatial matching to network.

    Delegates to :func:`geometry_matching.match_features_to_network` using the
    Point geometry of each stopping lane feature.
    """
    from gmt_network_enrichment.osm_asset_fetcher.core.domain.geometry_matching import (
        match_features_to_network,
    )

    matched: list[dict] = match_features_to_network(
        lane_features, network_fc, max_distance_m=max_distance_m
    )
    return matched


def stopping_lanes_to_features(
    elements: list[dict],
    network_fc: dict | None = None,
) -> list[dict]:
    """Main entry point: Convert ways with turn:lanes* to lane Point features.

    Parameters
    ----------
    elements:
        Overpass way elements.
    network_fc:
        Optional network FeatureCollection for linkId matching.

    Returns
    -------
    list[dict]
        GeoJSON Point features with assetType='stoppingLane'.
    """
    features: list[dict] = []

    # Generate lane points from all ways.
    for elem in elements:
        if elem.get("type") != "way":
            continue

        tags = elem.get("tags") or {}
        if not any(k in tags for k in ("turn:lanes", "turn:lanes:forward", "turn:lanes:backward")):
            continue

        way_features = stopping_lane_features_from_way(elem)
        features.extend(way_features)

    logger.info("Generated %d stopping lane features from OSM.", len(features))

    # Optionally match to network for linkId/nodeId.
    if network_fc:
        features = match_lane_points_to_network(features, network_fc)

    return features
