"""Extract refuge areas on footpaths and cyclepaths.

Refuge areas on pedestrian and cycling infrastructure are encoded in OSM as:

    way[footway=traffic_island]
    way[cycleway=traffic_island]

These are typically portions of a footpath or cycleway that lie on a traffic
island or median. They are often used to provide safe waiting areas for
pedestrians or cyclists crossing a road in stages.

Output
------
Ways are converted to Polygon features by buffering the LineString geometry
by ~0.5 meters on each side, simulating the physical width of the path.
Each feature has assetType='refugeAreaFootway' with properties for path type,
surface, width (if available), and calculated area.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def parse_width_m(value: str | None) -> float | None:
    """Parse an OSM width tag to metres, or None when non-numeric/absent."""
    if not value:
        return None
    import re

    m = re.match(r"^\s*(\d+(?:[.,]\d+)?)\s*(?:m(?:eters?)?)?\s*$", value, re.IGNORECASE)
    if not m:
        return None
    try:
        return float(m.group(1).replace(",", "."))
    except ValueError:
        return None


def parse_bool_tag(value: str | None) -> bool | None:
    """Parse OSM yes/no-style tag to bool, or None when unknown/absent."""
    if value is None:
        return None
    lc = value.strip().lower()
    if lc in ("yes", "true", "1"):
        return True
    if lc in ("no", "false", "0"):
        return False
    return None


def _buffer_linestring(
    coords: list[list[float]],
    buffer_distance: float = 0.5,
) -> list[list[float]] | None:
    """Convert LineString to Polygon via buffering using shapely.

    Parameters
    ----------
    coords:
        [[lon, lat], ...] vertex sequence.
    buffer_distance:
        Buffer distance in meters (default 0.5m on each side).

    Returns
    -------
    list[list[float]]
        Exterior ring coordinates [[lon, lat], ...] for a Polygon geometry,
        or None if buffering failed.
    """
    try:
        from shapely.geometry import LineString

        # Convert to (lon, lat) tuples.
        if len(coords) < 2:
            return None

        line = LineString([(c[0], c[1]) for c in coords])
        # Buffer in decimal degrees (~111m per degree at equator, but we'll use
        # a rough approximation: 0.5m ≈ 0.0000045 degrees).
        # More precise: use shapely's buffer with approximate=True.
        buffered = line.buffer(0.0000045, resolution=8)

        if buffered.is_empty or buffered.geom_type not in ("Polygon", "MultiPolygon"):
            return None

        if buffered.geom_type == "Polygon":
            # Extract exterior ring.
            return [list(c) for c in buffered.exterior.coords]
        # MultiPolygon — take largest.
        largest = max(buffered.geoms, key=lambda p: p.area)
        return [list(c) for c in largest.exterior.coords]
    except Exception as e:
        logger.warning("Failed to buffer LineString: %s", e)
        return None


def _way_linestring(geometry: list[dict]) -> list[list[float]] | None:
    """Extract [[lon, lat], ...] from Overpass way geometry.

    Parameters
    ----------
    geometry:
        List of {"lat": ..., "lon": ...} dicts from Overpass.

    Returns
    -------
    list[list[float]]
        Coordinate pairs, or None if fewer than 2 vertices.
    """
    pts = [[float(p["lon"]), float(p["lat"])] for p in geometry if "lat" in p and "lon" in p]
    if len(pts) < 2:
        return None
    return pts


def _calculate_polygon_area(exterior_ring: list[list[float]]) -> float:
    """Calculate area of polygon in m² using shoelace formula (approximate).

    Parameters
    ----------
    exterior_ring:
        [[lon, lat], ...] coordinate sequence.

    Returns
    -------
    float
        Area in square meters (rough approximation).
    """
    try:
        from shapely.geometry import Polygon

        poly = Polygon([(c[0], c[1]) for c in exterior_ring])
        # Convert from degrees² to m² using rough factor at ~52° N (Netherlands).
        # 1 degree ≈ 111 km, so 1 degree² ≈ 12,321 km² at equator.
        # At 52° N, adjust by cos(52°) ≈ 0.616, so ~7,578 km²/degree².
        # For small areas we approximate: area_m² ≈ area_degrees² * 7.6e9
        area_m2: float = poly.area * 7.6e9
        return area_m2
    except Exception:
        return 0.0


def footway_refuge_features(elements: list[dict]) -> list[dict]:
    """Convert Overpass footway/cycleway ways to refuge area features.

    Parameters
    ----------
    elements:
        List of Overpass way elements with footway=traffic_island or
        cycleway=traffic_island.

    Returns
    -------
    list[dict]
        GeoJSON Polygon features with assetType='refugeAreaFootway'.
    """
    features: list[dict] = []

    for elem in elements:
        if elem.get("type") != "way":
            continue

        tags = elem.get("tags") or {}
        geometry = elem.get("geometry") or []

        # Determine traffic type (foot or bike).
        traffic_type = None
        if tags.get("footway") == "traffic_island":
            traffic_type = "foot"
        elif tags.get("cycleway") == "traffic_island":
            traffic_type = "bike"
        else:
            continue

        # Extract LineString.
        coords = _way_linestring(geometry)
        if coords is None:
            continue

        # Buffer to Polygon.
        polygon_coords = _buffer_linestring(coords, buffer_distance=0.0000045)
        if polygon_coords is None:
            continue

        # Calculate area.
        area_m2 = _calculate_polygon_area(polygon_coords)

        # Extract typed properties.
        surface = tags.get("surface")  # asphalt | concrete | paving_stones | ...
        width = parse_width_m(tags.get("width"))
        lit = parse_bool_tag(tags.get("lit"))

        props = {
            "osm_id": elem.get("id"),
            "assetType": "refugeAreaFootway",
            "trafficType": traffic_type,
            "surface": surface,
            "width": width,
            "lit": lit,
            "area_m2": round(area_m2, 2),
            **tags,  # Preserve all raw OSM tags
        }

        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Polygon", "coordinates": [polygon_coords]},
                "properties": props,
            }
        )

    logger.info("Extracted %d footway refuge features.", len(features))
    return features
