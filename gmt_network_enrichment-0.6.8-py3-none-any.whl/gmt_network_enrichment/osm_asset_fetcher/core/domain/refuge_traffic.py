"""Extract traffic-calming refuge islands.

Traffic-calming refuge islands are physical objects on or near roads designed
to slow traffic and separate different types of road users. They are encoded
in OSM as:

    way[area:highway=traffic_island]  — polygonal refuge areas
    node[traffic_calming=island]      — point-based refuge islands

These can be concrete islands, green medians, or bollard-protected areas.

Output
------
Way-based features are emitted as Polygon. Node-based features are emitted
as Point. Each feature has assetType='refugeAreaTraffic' with properties for
physical type, height, diameter (if available), and calculated area for
polygonal features.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def parse_float_tag(value: str | None) -> float | None:
    """Parse an OSM numeric tag to float, or None when non-numeric/absent."""
    if not value:
        return None
    try:
        return float(value.strip().replace(",", "."))
    except ValueError:
        return None


def parse_bool_tag(value: str | None) -> bool | None:
    """Parse OSM yes/no-style tag to bool, or None when unknown/absent."""
    if value is None:
        return None
    lc = value.strip().lower()
    if lc in ("yes", "true", "1"):
        return True
    if lc in ("no", "false", "0"):
        return False
    return None


def _calculate_polygon_area(exterior_ring: list[list[float]]) -> float:
    """Calculate area of polygon in m² using shoelace formula (approximate).

    Parameters
    ----------
    exterior_ring:
        [[lon, lat], ...] coordinate sequence.

    Returns
    -------
    float
        Area in square meters (rough approximation).
    """
    try:
        from shapely.geometry import Polygon

        poly = Polygon([(c[0], c[1]) for c in exterior_ring])
        # Convert from degrees² to m² using factor at ~52° N (Netherlands).
        area_m2: float = poly.area * 7.6e9
        return area_m2
    except Exception:
        return 0.0


def _infer_physical_type(tags: dict) -> str | None:
    """Infer physical type from OSM tags.

    Heuristic:
    - If material=* or surface=* suggests green → "green"
    - If material mentions concrete/asphalt → "concrete"
    - Otherwise → "mixed" (default for unknown)
    """
    material = tags.get("material", "").lower()
    surface = tags.get("surface", "").lower()

    # Green material indicators.
    if any(x in material for x in ("grass", "soil", "earth", "vegetation", "turf")):
        return "green"
    if any(x in surface for x in ("grass", "soil", "earth", "vegetation", "turf")):
        return "green"

    # Concrete/hard material indicators.
    if any(x in material for x in ("concrete", "asphalt", "stone", "brick", "paving")):
        return "concrete"
    if any(x in surface for x in ("concrete", "asphalt", "stone", "brick", "paving")):
        return "concrete"

    return "mixed"


def _way_polygon_ring(geometry: list[dict]) -> list[list[float]] | None:
    """Extract polygon ring [[lon, lat], ...] from Overpass way geometry.

    For closed ways (first == last), returns the ring. For open ways, attempts
    to close the ring by duplicating the first vertex.

    Parameters
    ----------
    geometry:
        List of {"lat": ..., "lon": ...} dicts from Overpass.

    Returns
    -------
    list[list[float]]
        Coordinate pairs, or None if fewer than 3 unique vertices.
    """
    pts = [[float(p["lon"]), float(p["lat"])] for p in geometry if "lat" in p and "lon" in p]

    if len(pts) < 3:
        return None

    # Close ring if not already closed.
    if pts[0] != pts[-1]:
        pts.append(pts[0])

    return pts


def traffic_refuge_features(elements: list[dict]) -> list[dict]:
    """Convert Overpass traffic island elements to refuge area features.

    Parameters
    ----------
    elements:
        List of Overpass way/node elements with area:highway=traffic_island or
        traffic_calming=island.

    Returns
    -------
    list[dict]
        GeoJSON Polygon or Point features with assetType='refugeAreaTraffic'.
    """
    features: list[dict] = []

    for elem in elements:
        etype = elem.get("type")
        tags = elem.get("tags") or {}

        # Check element type match.
        if etype == "way":
            if tags.get("area:highway") != "traffic_island":
                continue

            geometry = elem.get("geometry") or []
            polygon_ring = _way_polygon_ring(geometry)
            if polygon_ring is None:
                continue

            # Calculate area.
            area_m2 = _calculate_polygon_area(polygon_ring)

            # Infer physical type.
            physical_type = _infer_physical_type(tags)

            # Extract optional properties.
            height = parse_float_tag(tags.get("height"))
            diameter = parse_float_tag(tags.get("diameter"))
            surface = tags.get("surface")

            props = {
                "osm_id": elem.get("id"),
                "assetType": "refugeAreaTraffic",
                "physicalType": physical_type,
                "height": height,
                "diameter": diameter,
                "surface": surface,
                "area_m2": round(area_m2, 2),
                **tags,  # Preserve all raw OSM tags
            }

            features.append(
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": [polygon_ring]},
                    "properties": props,
                }
            )

        elif etype == "node":
            if tags.get("traffic_calming") != "island":
                continue

            lat = elem.get("lat")
            lon = elem.get("lon")
            if lat is None or lon is None:
                continue

            # Infer physical type.
            physical_type = _infer_physical_type(tags)

            # Extract optional properties.
            height = parse_float_tag(tags.get("height"))
            diameter = parse_float_tag(tags.get("diameter"))
            surface = tags.get("surface")

            props = {
                "osm_id": elem.get("id"),
                "assetType": "refugeAreaTraffic",
                "physicalType": physical_type,
                "height": height,
                "diameter": diameter,
                "surface": surface,
                **tags,  # Preserve all raw OSM tags
            }

            features.append(
                {
                    "type": "Feature",
                    "geometry": {"type": "Point", "coordinates": [lon, lat]},
                    "properties": props,
                }
            )

    logger.info("Extracted %d traffic refuge features.", len(features))
    return features
