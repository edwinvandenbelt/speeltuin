"""Pure-Python bag_fetcher core — fetches BAG pand bouwjaar, merges onto buildings.

Fetches Dutch BAG (Basisregistratie Adressen en Gebouwen) ``pand`` features
for a bounding box from the PDOK BAG OGC API Features service, then merges
the construction year (``bouwjaar``) onto an existing OSM-derived buildings
FeatureCollection (e.g. the output of
``osm.osm_building_fetcher.build_buildings``).

Matching a building to its BAG pand is tried in two steps:

1. **By id** — the OSM building's ``ref:bag`` tag (stored under the
   ``tag_ref:bag`` property by ``osm_building_fetcher``, which preserves
   every original OSM tag with a ``tag_`` prefix) equals a BAG pand's
   ``identificatie``.  Exact and cheap, but only works when OSM carries the
   tag.
2. **By geometry** — when there is no id match, the building's centroid is
   tested against every BAG pand polygon via a ``shapely.STRtree`` spatial
   index; the pand whose polygon contains the centroid wins.

BAG ``bouwjaar`` uses ``9999`` as a sentinel for "unknown"; it is normalised
to ``None`` on fetch. The BAG OGC API has no ``eind_registratie``-style
"current version" filter like BGT, so ``current_only=False`` is always
passed to the shared OGC client.

Panden whose BAG ``status`` indicates they do not physically exist (not yet
built, demolished, or erroneously registered) are dropped on fetch — see
``PAND_STATUS_BESTAAND``. The remaining ``status`` is still carried through
onto merged buildings as ``bagStatus``, so a later step can filter further
(e.g. excluding ``"Pand buiten gebruik"``) without re-fetching BAG.

Every pand also gets a deterministic wall/roof colour, derived from its
``bouwjaar`` (which bouwperiode-palette applies) and ``identificatie`` (which
colour variant within that palette) — see ``pand_colors``.

The service serves GeoJSON in CRS84 (WGS-84 lon/lat), so no reprojection is
needed.  BAG only covers the Netherlands: outside NL, fetching is skipped.

Public API
----------
fetch_bag_panden(bbox, *, url, timeout) -> tuple[dict, dict]
    Fetch BAG pand features (geometry + identificatie + bouwjaar + status +
    colours) for a bbox, excluding panden that do not physically exist.
merge_bag_bouwjaar(buildings_fc, bag_fc, *, ref_bag_property) -> tuple[dict, dict]
    Merge bouwjaar/status/colours onto buildings_fc, by id then by
    centroid-in-polygon.
pand_colors(identificatie, bouwjaar) -> dict[str, str]
    Deterministic ``{wall, roofPitched, roofFlat}`` hex colours for a pand.
"""

from __future__ import annotations

import logging
import math
import os
from typing import Any

from gmt_shared.geo import is_netherlands

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached BAG output.
BAG_QUERY_VER: int = 3

#: BAG collection id on the PDOK BAG OGC API Features (v2) service.
COLLECTION_PAND: str = "pand"

#: BAG's sentinel value for "construction year unknown".
BOUWJAAR_UNKNOWN: int = 9999

#: BAG pand statuses that represent a physically existing building. Panden
#: with any other status (not yet built, demolished, or erroneously
#: registered) are dropped on fetch — see ``fetch_bag_panden``.
PAND_STATUS_BESTAAND: frozenset[str] = frozenset(
    {
        "Bouw gestart",
        "Pand in gebruik (niet ingemeten)",
        "Pand in gebruik",
        "Verbouwing pand",
        "Sloopvergunning verleend",
        "Pand buiten gebruik",
    }
)

_BAG_URL_FALLBACK: str = "https://api.pdok.nl/kadaster/bag/ogc/v2"
DEFAULT_BAG_URL: str = os.environ.get("PDOK_BAG_URL", _BAG_URL_FALLBACK)

#: Property on an OSM building feature holding the BAG pand id.  Written by
#: osm_building_fetcher as ``tag_<osm-tag>`` for every original OSM tag, so
#: an OSM ``ref:bag`` tag ends up under this property name.
DEFAULT_REF_BAG_PROPERTY: str = "tag_ref:bag"


# ---------------------------------------------------------------------------
# Gevel-/dakkleuren per bouwperiode
# ---------------------------------------------------------------------------

RGB = tuple[int, int, int]

#: Palet voor panden zonder (bruikbaar) bouwjaar: (gevel, schuin dak, plat dak).
_BAG3D_COLORS: tuple[RGB, RGB, RGB] = ((236, 226, 210), (172, 94, 70), (156, 153, 148))

#: Palet per bouwperiode (gevel, schuin dak, plat dak), op basis van het
#: bouwjaar. Elke periode heeft meerdere kleurvarianten; welke variant een
#: pand krijgt wordt met een stabiele hash van de pand-``identificatie``
#: bepaald (zie ``_b3_bucket``), zodat het willekeurig oogt maar elke run
#: hetzelfde pand treft. Moet 1-op-1 gelijk blijven aan de terugval-logica in
#: speeltuin's ``digital-twin/scripts/main.js`` (``_BAG3D_PERIODS``) en
#: ``digital-twin/bag_panden_colors.py``, inclusief de groene jaren-'70/'80-
#: variant die daar de oorspronkelijke blauwgrijze (onrealistische) variant
#: vervangt.
_BAG3D_PERIODS: tuple[dict[str, Any], ...] = (
    {  # 17e/18e eeuw: donkere baksteen/pannen
        "before": 1800,
        "colors": (
            ((96, 52, 44), (72, 38, 32), (92, 90, 86)),
            ((84, 46, 40), (60, 40, 34), (88, 86, 82)),
        ),
    },
    {  # 19e eeuw: lichte stuc, donker houtwerk
        "before": 1906,
        "colors": (
            ((222, 210, 188), (98, 70, 56), (122, 120, 114)),
            ((206, 196, 176), (70, 58, 50), (118, 116, 110)),
        ),
    },
    {  # jaren '20-'30: warme rode/oranje baksteen
        "before": 1945,
        "colors": (
            ((152, 72, 52), (168, 88, 64), (140, 136, 130)),
            ((128, 64, 48), (140, 78, 58), (134, 130, 124)),
        ),
    },
    {  # wederopbouw jaren '50-'60: gele baksteen/beton
        "before": 1970,
        "colors": (
            ((198, 190, 166), (150, 128, 104), (150, 148, 144)),
            ((172, 170, 164), (132, 118, 100), (146, 144, 140)),
        ),
    },
    {  # jaren '70-'80: experimenteel, maar geen blauw
        "before": 1990,
        "colors": (
            ((112, 80, 56), (96, 68, 48), (112, 110, 106)),
            ((70, 86, 58), (54, 68, 46), (100, 98, 94)),
            ((134, 54, 44), (104, 44, 38), (100, 98, 94)),
        ),
    },
    {  # 1990-heden: veel materiaal-/kleurkeuze
        "before": math.inf,
        "colors": (
            ((220, 220, 218), (72, 72, 76), (70, 68, 66)),
            ((196, 196, 198), (130, 130, 132), (128, 128, 130)),
            ((64, 64, 66), (48, 48, 50), (60, 60, 62)),
            ((150, 118, 86), (100, 76, 54), (92, 90, 86)),
        ),
    },
)


def _b3_bucket_colors() -> tuple[list[tuple[RGB, RGB, RGB]], list[tuple[int, int]]]:
    """Flatten ``_BAG3D_PERIODS`` into a bucket lookup table + per-period ranges.

    Returns ``(bucket_colors, period_ranges)``: ``bucket_colors[0]`` is the
    unknown-bouwjaar fallback ``_BAG3D_COLORS``; the rest are every period's
    colour variants in order. ``period_ranges[p - 1]`` gives
    ``(first_bucket, variant_count)`` for 1-based period index ``p``.
    """
    bucket_colors: list[tuple[RGB, RGB, RGB]] = [_BAG3D_COLORS]
    period_ranges: list[tuple[int, int]] = []
    start = 1
    for period in _BAG3D_PERIODS:
        variants = period["colors"]
        bucket_colors.extend(variants)
        period_ranges.append((start, len(variants)))
        start += len(variants)
    return bucket_colors, period_ranges


_BAG3D_BUCKET_COLORS, _BAG3D_PERIOD_RANGES = _b3_bucket_colors()

#: RGB-afstand waaronder gevel- en dakkleur als "vrijwel gelijk" gelden.
_SIMILAR_COLOR_DISTANCE: float = 15.0

#: Factor waarmee een dakkleur donkerder wordt gemaakt als die te dicht op de
#: gevelkleur zit ("een paar tinten donkerder").
_DARKEN_FACTOR: float = 0.75


def _b3_period_idx(year: int | None) -> int:
    """1-based index into ``_BAG3D_PERIODS`` for *year*, or 0 if unknown/out of range."""
    if year is None or not (1000 < year < 2100):
        return 0
    for i, period in enumerate(_BAG3D_PERIODS):
        if year < period["before"]:
            return i + 1
    return len(_BAG3D_PERIODS)


def _b3_hash(value: str) -> int:
    """32-bit FNV-1a hash, only used to deterministically pick a colour variant."""
    h = 2166136261
    for ch in value:
        h ^= ord(ch)
        h = (h * 16777619) & 0xFFFFFFFF
    return h


def _b3_bucket(period_idx: int, seed: int) -> int:
    """Bucket index into ``_BAG3D_BUCKET_COLORS`` for a period + hash seed."""
    if period_idx == 0:
        return 0
    start, n = _BAG3D_PERIOD_RANGES[period_idx - 1]
    return start + (seed % n)


def _rgb_distance(a: RGB, b: RGB) -> float:
    squared = sum((x - y) ** 2 for x, y in zip(a, b, strict=True))
    return math.sqrt(squared)


def _darken(rgb: RGB) -> RGB:
    r, g, b = (max(0, round(c * _DARKEN_FACTOR)) for c in rgb)
    return (r, g, b)


def _adjust_roof_color(wall: RGB, roof: RGB) -> RGB:
    """Darken *roof* a few shades when it is virtually the same colour as *wall*."""
    if _rgb_distance(wall, roof) < _SIMILAR_COLOR_DISTANCE:
        return _darken(roof)
    return roof


def _rgb_to_hex(rgb: RGB) -> str:
    return "#{:02x}{:02x}{:02x}".format(*rgb)


def pand_colors(identificatie: str | None, bouwjaar: int | None) -> dict[str, str]:
    """Return deterministic ``{wall, roofPitched, roofFlat}`` hex colours for a pand.

    The colour is picked from ``_BAG3D_PERIODS`` by *bouwjaar*; which variant
    within that period is picked is a stable hash of *identificatie*, so the
    same pand always gets the same colours across runs. Panden without a
    usable *bouwjaar* fall back to ``_BAG3D_COLORS``. A roof colour that
    would be virtually indistinguishable from the wall colour is darkened a
    few shades (see ``_adjust_roof_color``).
    """
    period_idx = _b3_period_idx(bouwjaar)
    seed = _b3_hash(identificatie) if identificatie else 0
    bucket = _b3_bucket(period_idx, seed)
    wall, roof_pitched, roof_flat = _BAG3D_BUCKET_COLORS[bucket]
    return {
        "wall": _rgb_to_hex(wall),
        "roofPitched": _rgb_to_hex(_adjust_roof_color(wall, roof_pitched)),
        "roofFlat": _rgb_to_hex(_adjust_roof_color(wall, roof_flat)),
    }


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------


def parse_bouwjaar(raw: object) -> int | None:
    """Normalise a raw BAG ``bouwjaar`` value to an int, or None if unknown.

    Returns None for a missing value, an unparsable value, or the BAG
    sentinel ``9999`` ("onbekend").
    """
    if raw is None:
        return None
    if not isinstance(raw, int | float | str):
        return None
    try:
        year = int(raw)
    except (TypeError, ValueError):
        return None
    if year == BOUWJAAR_UNKNOWN:
        return None
    return year


def _pand_feature_properties(feature: dict) -> dict[str, Any]:
    """Return normalised pand properties: identificatie, bouwjaar, status, and colors."""
    props = feature.get("properties") or {}
    identificatie = props.get("identificatie")
    bouwjaar = parse_bouwjaar(props.get("bouwjaar"))
    colors = pand_colors(identificatie, bouwjaar)
    return {
        "identificatie": identificatie,
        "bouwjaar": bouwjaar,
        "status": props.get("status"),
        "wallColor": colors["wall"],
        "roofColorPitched": colors["roofPitched"],
        "roofColorFlat": colors["roofFlat"],
    }


def _pand_bestaat(feature: dict) -> bool:
    """True when a raw pand feature's BAG ``status`` is a physically existing one."""
    props = feature.get("properties") or {}
    return props.get("status") in PAND_STATUS_BESTAAND


# ---------------------------------------------------------------------------
# Fetch
# ---------------------------------------------------------------------------


def fetch_bag_panden(
    bbox: list[float],
    *,
    url: str | None = None,
    timeout: int = 60,
) -> tuple[dict, dict]:
    """Fetch BAG pand features (geometry + identificatie + bouwjaar + status + colours) for bbox.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    url:
        OGC API Features base URL.  Defaults to :data:`DEFAULT_BAG_URL`
        (``PDOK_BAG_URL`` env var or the public PDOK BAG v2 endpoint).
    timeout:
        HTTP request timeout in seconds (per page).

    Returns
    -------
    fc:
        A GeoJSON ``FeatureCollection`` of BAG pand Polygon features, limited
        to panden whose ``status`` is in ``PAND_STATUS_BESTAAND`` (physically
        existing panden). Every feature's properties are normalised to
        exactly ``identificatie`` (str or None), ``bouwjaar`` (int or None —
        ``9999`` mapped to None), ``status`` (str or None), and the hex
        colours ``wallColor``/``roofColorPitched``/``roofColorFlat`` (see
        :func:`pand_colors`).
    stats:
        ``{"total": int, "source": "BAG" | "skipped"}``.  ``source`` is
        ``"skipped"`` when the bbox lies outside the Netherlands. ``total``
        counts only panden that passed the status filter.
    """
    if not is_netherlands(bbox):
        logger.info("bbox centroid outside NL — skipping BAG fetch.")
        return (
            {
                "type": "FeatureCollection",
                "features": [],
                "properties": {"_qv": BAG_QUERY_VER, "source": "skipped"},
            },
            {"total": 0, "source": "skipped"},
        )

    from gmt_shared.ogc_features import fetch_collection_items

    base_url = url if url is not None else DEFAULT_BAG_URL
    raw_panden = fetch_collection_items(
        COLLECTION_PAND,
        bbox,
        url=base_url,
        timeout=timeout,
        # BAG has no eind_registratie-style "current version" field like BGT.
        current_only=False,
    )

    bestaande_panden = [feat for feat in raw_panden if _pand_bestaat(feat)]
    logger.info(
        "BAG panden: %d opgehaald, %d na statusfilter",
        len(raw_panden),
        len(bestaande_panden),
    )

    features = [
        {
            "type": "Feature",
            "geometry": feat.get("geometry"),
            "properties": _pand_feature_properties(feat),
        }
        for feat in bestaande_panden
    ]

    fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"_qv": BAG_QUERY_VER, "source": "BAG"},
    }
    stats = {"total": len(features), "source": "BAG"}
    return fc, stats


# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------


#: Pand attributes carried from a BAG feature onto a matched building, keyed
#: by the ``bagXxx`` property name they end up under.
_PAND_ATTR_KEYS: tuple[str, ...] = (
    "bouwjaar",
    "status",
    "wallColor",
    "roofColorPitched",
    "roofColorFlat",
)


def _pand_attrs(props: dict) -> dict[str, Any]:
    """Pull the carried-through BAG attributes off a pand feature's properties."""
    return {key: props.get(key) for key in _PAND_ATTR_KEYS}


def merge_bag_bouwjaar(
    buildings_fc: dict,
    bag_fc: dict,
    *,
    ref_bag_property: str = DEFAULT_REF_BAG_PROPERTY,
) -> tuple[dict, dict]:
    """Merge BAG ``bouwjaar``, ``status`` and colours onto every feature of *buildings_fc*.

    Matching is tried in two steps per building feature:

    1. **By id** — ``properties[ref_bag_property]`` (the OSM ``ref:bag`` tag)
       is looked up directly in the BAG pand ``identificatie`` index.
    2. **By geometry** — when there is no tag, or its value is not a known
       BAG pand, the building's centroid is tested against every BAG pand
       polygon; the pand whose polygon contains the centroid wins.

    Does not mutate *buildings_fc* or *bag_fc*; returns a new
    FeatureCollection.  Fail-open: when *bag_fc* has no features (e.g. the
    bbox was outside the Netherlands), every building gets all ``bagXxx``
    properties set to ``None`` and ``_bagMatch=None``.

    ``bagStatus`` is carried through unfiltered (``fetch_bag_panden`` already
    dropped panden that do not physically exist, but e.g. ``"Pand buiten
    gebruik"`` is still included) so a later step can filter on it further
    without re-fetching BAG.

    Returns
    -------
    fc:
        *buildings_fc* with new properties on every feature: ``bagBouwjaar``
        (int or None), ``bagIdentificatie`` (str or None), ``bagStatus``
        (str or None), ``bagWallColor``/``bagRoofColorPitched``/
        ``bagRoofColorFlat`` (hex str or None), ``_bagMatch`` (``"id"`` |
        ``"centroid"`` | None).
    stats:
        ``{"matched_by_id": int, "matched_by_centroid": int,
        "unmatched": int, "total": int}``.
    """
    by_id: dict[str, dict[str, Any]] = {}
    for feat in bag_fc.get("features") or []:
        props = feat.get("properties") or {}
        ident = props.get("identificatie")
        if ident:
            by_id[str(ident)] = _pand_attrs(props)

    buildings = buildings_fc.get("features") or []
    stats = {
        "matched_by_id": 0,
        "matched_by_centroid": 0,
        "unmatched": 0,
        "total": len(buildings),
    }

    if not by_id:
        out_features = [_tag_no_match(feat) for feat in buildings]
        stats["unmatched"] = len(buildings)
        return {**buildings_fc, "features": out_features}, stats

    tree, pand_records = _build_pand_index(bag_fc)

    out_features = []
    for feat in buildings:
        props = feat.get("properties") or {}
        raw_ref = props.get(ref_bag_property)
        ref = str(raw_ref) if raw_ref else None

        if ref is not None and ref in by_id:
            out_features.append(_tag_match(feat, ref, by_id[ref], "id"))
            stats["matched_by_id"] += 1
            continue

        match = _match_by_centroid(feat, tree, pand_records) if tree is not None else None
        if match is not None:
            matched_ident, matched_attrs = match
            out_features.append(_tag_match(feat, matched_ident, matched_attrs, "centroid"))
            stats["matched_by_centroid"] += 1
            continue

        out_features.append(_tag_no_match(feat))
        stats["unmatched"] += 1

    return {**buildings_fc, "features": out_features}, stats


def _tag_match(feature: dict, identificatie: str, attrs: dict[str, Any], how: str) -> dict:
    props = {
        **(feature.get("properties") or {}),
        "bagBouwjaar": attrs["bouwjaar"],
        "bagIdentificatie": identificatie,
        "bagStatus": attrs["status"],
        "bagWallColor": attrs["wallColor"],
        "bagRoofColorPitched": attrs["roofColorPitched"],
        "bagRoofColorFlat": attrs["roofColorFlat"],
        "_bagMatch": how,
    }
    return {**feature, "properties": props}


def _tag_no_match(feature: dict) -> dict:
    props = {
        **(feature.get("properties") or {}),
        "bagBouwjaar": None,
        "bagIdentificatie": None,
        "bagStatus": None,
        "bagWallColor": None,
        "bagRoofColorPitched": None,
        "bagRoofColorFlat": None,
        "_bagMatch": None,
    }
    return {**feature, "properties": props}


def _build_pand_index(bag_fc: dict) -> tuple[Any, list[tuple[str | None, dict[str, Any]]]]:
    """Build a shapely STRtree over BAG pand polygons for centroid matching.

    Returns ``(tree, records)`` where *records* is a list of
    ``(identificatie, attrs)`` pairs in the same order as the geometries fed
    to the tree, so a query result index maps directly into *records* (same
    pattern as ``road_enricher_core``'s ``STRtree`` usage). Returns
    ``(None, [])`` when there are no usable pand polygons.
    """
    from shapely import STRtree
    from shapely.geometry import shape

    geoms = []
    records: list[tuple[str | None, dict[str, Any]]] = []
    for feat in bag_fc.get("features") or []:
        geom = feat.get("geometry")
        if not geom:
            continue
        try:
            shapely_geom = shape(geom)
        except Exception:
            continue
        props = feat.get("properties") or {}
        geoms.append(shapely_geom)
        records.append((props.get("identificatie"), _pand_attrs(props)))

    if not geoms:
        return None, []
    return STRtree(geoms), records


def _match_by_centroid(
    feature: dict,
    tree: Any,
    records: list[tuple[str | None, dict[str, Any]]],
) -> tuple[str, dict[str, Any]] | None:
    """Return ``(identificatie, attrs)`` for the BAG pand whose polygon
    contains *feature*'s centroid, or None when no pand polygon matches."""
    from shapely.geometry import shape

    geom = feature.get("geometry")
    if not geom:
        return None
    try:
        centroid = shape(geom).centroid
    except Exception:
        return None

    # STRtree predicates are evaluated as predicate(query_geometry, tree_geometry),
    # so "a pand polygon contains the centroid" is queried as "within".
    for idx in tree.query(centroid, predicate="within"):
        ident, attrs = records[int(idx)]
        if ident is None:
            continue
        return str(ident), attrs
    return None
