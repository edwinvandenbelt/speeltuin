# src/bag_fetcher/core/__init__.py
