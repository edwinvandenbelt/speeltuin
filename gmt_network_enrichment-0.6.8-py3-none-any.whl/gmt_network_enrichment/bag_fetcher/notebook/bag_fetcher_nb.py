# Databricks notebook source
# ---------------------------------------------------------------------------
# bag_fetcher_nb.py — Databricks notebook interface.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Derives the bounding box (explicit widget or from a network GeoParquet).
#   3. Fetches BAG pand features (bouwjaar) from the PDOK BAG OGC API Features
#      service.
#   4. Merges bouwjaar onto the input buildings GeoParquet (by ref:bag id,
#      falling back to centroid-in-polygon).
#   5. Writes the result as a GeoParquet FeatureCollection.
#   6. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("bag_fetcher_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "bbox",
    "",
    "Bounding box 'minLon,minLat,maxLon,maxLat' (leave empty to derive from network_uri)",
)
dbutils.widgets.text(
    "network_uri",
    "",
    "Network GeoParquet URI to derive the bbox from (used when bbox is empty)",
)
dbutils.widgets.text(
    "buildings_uri",
    "",
    "Input buildings GeoParquet URI to merge bouwjaar onto",
)
dbutils.widgets.text(
    "output_uri",
    "",
    "Output GeoParquet URI for the buildings FeatureCollection with bouwjaar merged in",
)
dbutils.widgets.text(
    "bag_url",
    "",
    "OGC API Features base URL (leave empty for the default PDOK BAG v2 endpoint)",
)
dbutils.widgets.text(
    "timeout",
    "60",
    "HTTP request timeout in seconds per page",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_network_enrichment.bag_fetcher.core.bag_fetcher_core import (
    fetch_bag_panden,
    merge_bag_bouwjaar,
)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

BBOX_RAW = dbutils.widgets.get("bbox").strip()
NETWORK_URI = dbutils.widgets.get("network_uri").strip()
BUILDINGS_URI = dbutils.widgets.get("buildings_uri").strip()
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()
BAG_URL = dbutils.widgets.get("bag_url").strip() or None
TIMEOUT = int(dbutils.widgets.get("timeout").strip() or "60")

if not BUILDINGS_URI:
    raise ValueError("Widget 'buildings_uri' is empty.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")
if not BBOX_RAW and not NETWORK_URI:
    raise ValueError("Provide either 'bbox' or 'network_uri'.")

logger.info(
    "bbox=%s  network_uri=%s  buildings_uri=%s  output_uri=%s  bag_url=%s",
    BBOX_RAW,
    NETWORK_URI,
    BUILDINGS_URI,
    OUTPUT_URI,
    BAG_URL,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body: bytes = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/vnd.apache.parquet",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    import os

    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run BagFetcher
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")

# Determine bbox
if BBOX_RAW:
    _bbox: list[float] | None = [float(v) for v in BBOX_RAW.split(",")]
else:
    _fc = from_geoparquet(_read_uri(NETWORK_URI))
    _bbox = (_fc.get("properties") or {}).get("bbox")
    if not _bbox or len(_bbox) < 4:
        _lons, _lats = [], []
        for _f in _fc.get("features") or []:
            for _c in (_f.get("geometry") or {}).get("coordinates") or []:
                _lons.append(float(_c[0]))
                _lats.append(float(_c[1]))
        _bbox = [min(_lons), min(_lats), max(_lons), max(_lats)]
print(f"Bbox      : {_bbox}")

# Read buildings
_buildings_fc = from_geoparquet(_read_uri(BUILDINGS_URI))
print(f"Buildings : {len(_buildings_fc.get('features') or [])} features")

# Fetch BAG panden and merge bouwjaar
_bag_fc, _bag_stats = fetch_bag_panden(_bbox, url=BAG_URL, timeout=TIMEOUT)
_merged_fc, _merge_stats = merge_bag_bouwjaar(_buildings_fc, _bag_fc)

# Write result
_write_uri(OUTPUT_URI, to_geoparquet(_merged_fc))

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"BagFetcher complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Output URI        : {OUTPUT_URI}")
print(f"  BAG panden fetched: {_bag_stats['total']:,}  (source={_bag_stats['source']})")
print(f"  Matched by id     : {_merge_stats['matched_by_id']:,}")
print(f"  Matched by centroid: {_merge_stats['matched_by_centroid']:,}")
print(f"  Unmatched         : {_merge_stats['unmatched']:,}")
print(f"  Total buildings   : {_merge_stats['total']:,}")
print(_SEP)
