"""Unit tests for bag_fetcher core (pure functions + stubbed OGC client)."""

from __future__ import annotations

from gmt_network_enrichment.bag_fetcher.core.bag_fetcher_core import (
    _BAG3D_PERIOD_RANGES,
    _BAG3D_PERIODS,
    BAG_QUERY_VER,
    BOUWJAAR_UNKNOWN,
    COLLECTION_PAND,
    DEFAULT_REF_BAG_PROPERTY,
    PAND_STATUS_BESTAAND,
    _adjust_roof_color,
    _b3_bucket,
    _b3_period_idx,
    _darken,
    _rgb_distance,
    fetch_bag_panden,
    merge_bag_bouwjaar,
    pand_colors,
    parse_bouwjaar,
)

# NL bbox (Lochem-ish) and a non-NL bbox (Paris) — same bboxes as bgt_fetcher's tests.
_NL_BBOX = [6.39, 52.14, 6.43, 52.17]
_PARIS_BBOX = [2.2, 48.8, 2.4, 48.9]


def _square(cx: float, cy: float, half: float = 0.001) -> dict:
    return {
        "type": "Polygon",
        "coordinates": [
            [
                [cx - half, cy - half],
                [cx + half, cy - half],
                [cx + half, cy + half],
                [cx - half, cy + half],
                [cx - half, cy - half],
            ]
        ],
    }


def _building(ref_bag: str | None, cx: float, cy: float) -> dict:
    props: dict = {"buildingType": "house"}
    if ref_bag is not None:
        props[DEFAULT_REF_BAG_PROPERTY] = ref_bag
    return {"type": "Feature", "geometry": _square(cx, cy), "properties": props}


def _pand(
    identificatie: str,
    bouwjaar: int | None,
    cx: float,
    cy: float,
    status: str = "Pand in gebruik",
) -> dict:
    colors = pand_colors(identificatie, bouwjaar)
    return {
        "type": "Feature",
        "geometry": _square(cx, cy),
        "properties": {
            "identificatie": identificatie,
            "bouwjaar": bouwjaar,
            "status": status,
            "wallColor": colors["wall"],
            "roofColorPitched": colors["roofPitched"],
            "roofColorFlat": colors["roofFlat"],
        },
    }


def _fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features, "properties": {}}


# ---------------------------------------------------------------------------
# parse_bouwjaar
# ---------------------------------------------------------------------------


def test_parse_bouwjaar_normal_int() -> None:
    assert parse_bouwjaar(1991) == 1991


def test_parse_bouwjaar_numeric_string() -> None:
    assert parse_bouwjaar("1975") == 1975


def test_parse_bouwjaar_none() -> None:
    assert parse_bouwjaar(None) is None


def test_parse_bouwjaar_unknown_sentinel() -> None:
    assert parse_bouwjaar(BOUWJAAR_UNKNOWN) is None
    assert parse_bouwjaar("9999") is None


def test_parse_bouwjaar_unparsable() -> None:
    assert parse_bouwjaar("onbekend") is None


# ---------------------------------------------------------------------------
# pand_colors and its helpers
# ---------------------------------------------------------------------------


def test_pand_colors_unknown_bouwjaar_falls_back_to_default() -> None:
    assert pand_colors("some-id", None) == {
        "wall": "#ece2d2",
        "roofPitched": "#ac5e46",
        "roofFlat": "#9c9994",
    }


def test_pand_colors_is_deterministic() -> None:
    assert pand_colors("0003100000117485", 1991) == pand_colors("0003100000117485", 1991)


def test_pand_colors_returns_valid_hex_strings() -> None:
    colors = pand_colors("0003100000117485", 1978)
    for value in colors.values():
        assert len(value) == 7
        assert value[0] == "#"
        int(value[1:], 16)  # raises if not valid hex


def test_bag3d_periods_has_no_blue_variant() -> None:
    # The original JS palette's 1970-1990 blue-grey variant was replaced with
    # a green one (unrealistic for Dutch residential architecture of that
    # period) — same substitution as speeltuin's main.js/bag_panden_colors.py,
    # keeping 3 variants in this period.
    jaren_70_80 = next(p for p in _BAG3D_PERIODS if p["before"] == 1990)
    assert len(jaren_70_80["colors"]) == 3
    for wall, *_roofs in jaren_70_80["colors"]:
        r, g, b = wall
        assert not (b > r and b > g), f"onrealistisch blauwe gevelkleur: {wall}"


def test_b3_period_idx_buckets_known_years() -> None:
    assert _b3_period_idx(None) == 0
    assert _b3_period_idx(500) == 0  # out of range
    assert _b3_period_idx(1750) == 1
    assert _b3_period_idx(1850) == 2
    assert _b3_period_idx(1930) == 3
    assert _b3_period_idx(1960) == 4
    assert _b3_period_idx(1980) == 5
    assert _b3_period_idx(2020) == len(_BAG3D_PERIODS)


def test_b3_bucket_unknown_period_is_always_bucket_zero() -> None:
    assert _b3_bucket(0, 12345) == 0


def test_b3_bucket_picks_variant_within_period_range() -> None:
    start, n = _BAG3D_PERIOD_RANGES[0]
    for seed in range(5):
        bucket = _b3_bucket(1, seed)
        assert start <= bucket < start + n


def test_rgb_distance_and_darken() -> None:
    assert _rgb_distance((10, 10, 10), (10, 10, 10)) == 0
    assert _rgb_distance((0, 0, 0), (3, 4, 0)) == 5  # 3-4-5 triangle

    assert _darken((60, 60, 62)) == (45, 45, 46)
    assert _darken((0, 0, 0)) == (0, 0, 0)


def test_adjust_roof_color_darkens_only_when_close_to_wall() -> None:
    wall = (64, 64, 66)
    close_roof = (60, 60, 62)  # distance ~6.9 -> too close, must darken
    distinct_roof = (48, 48, 50)  # distance ~27.7 -> distinct enough, unchanged

    assert _adjust_roof_color(wall, close_roof) != close_roof
    assert _adjust_roof_color(wall, distinct_roof) == distinct_roof


# ---------------------------------------------------------------------------
# fetch_bag_panden
# ---------------------------------------------------------------------------


def test_fetch_bag_panden_skips_outside_nl() -> None:
    fc, stats = fetch_bag_panden(_PARIS_BBOX)
    assert stats["source"] == "skipped"
    assert stats["total"] == 0
    assert fc["features"] == []


def test_fetch_bag_panden_normalises_bouwjaar(monkeypatch) -> None:
    def _fake_fetch(collection: str, _bbox: list[float], **_kwargs) -> list[dict]:
        assert collection == COLLECTION_PAND
        return [
            {
                "type": "Feature",
                "geometry": _square(6.40, 52.15),
                "properties": {
                    "identificatie": "0003100000117485",
                    "bouwjaar": 1991,
                    "status": "Pand in gebruik",
                },
            },
            {
                "type": "Feature",
                "geometry": _square(6.41, 52.16),
                "properties": {
                    "identificatie": "0003100000117486",
                    "bouwjaar": BOUWJAAR_UNKNOWN,
                    "status": "Pand in gebruik",
                },
            },
        ]

    monkeypatch.setattr("gmt_shared.ogc_features.fetch_collection_items", _fake_fetch, raising=True)

    fc, stats = fetch_bag_panden(_NL_BBOX)
    assert stats["source"] == "BAG"
    assert stats["total"] == 2
    assert fc["properties"]["_qv"] == BAG_QUERY_VER
    bouwjaren = {
        f["properties"]["identificatie"]: f["properties"]["bouwjaar"] for f in fc["features"]
    }
    assert bouwjaren["0003100000117485"] == 1991
    assert bouwjaren["0003100000117486"] is None


def test_fetch_bag_panden_filters_on_status(monkeypatch) -> None:
    uitgesloten_statussen = [
        "Bouwvergunning verleend",
        "Niet gerealiseerd pand",
        "Pand gesloopt",
        "Pand ten onrechte opgevoerd",
    ]

    def _fake_fetch(collection: str, _bbox: list[float], **_kwargs) -> list[dict]:
        assert collection == COLLECTION_PAND
        panden = [
            _pand(f"uitgesloten-{i}", 2000, 6.40 + i * 0.01, 52.15, status=status)
            for i, status in enumerate(uitgesloten_statussen)
        ]
        panden.extend(
            _pand(f"behouden-{i}", 2000, 6.50 + i * 0.01, 52.15, status=status)
            for i, status in enumerate(sorted(PAND_STATUS_BESTAAND))
        )
        return panden

    monkeypatch.setattr("gmt_shared.ogc_features.fetch_collection_items", _fake_fetch, raising=True)

    fc, stats = fetch_bag_panden(_NL_BBOX)
    assert stats["total"] == len(PAND_STATUS_BESTAAND)
    idents = {f["properties"]["identificatie"] for f in fc["features"]}
    assert all(ident.startswith("behouden-") for ident in idents)
    assert len(idents) == len(PAND_STATUS_BESTAAND)


# ---------------------------------------------------------------------------
# merge_bag_bouwjaar
# ---------------------------------------------------------------------------


def test_merge_matches_by_ref_bag_id() -> None:
    buildings = _fc([_building("0003100000117485", 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1991, 10.0, 10.0)])

    merged, stats = merge_bag_bouwjaar(buildings, bag)

    props = merged["features"][0]["properties"]
    assert props["bagBouwjaar"] == 1991
    assert props["bagIdentificatie"] == "0003100000117485"
    assert props["bagStatus"] == "Pand in gebruik"
    expected_colors = pand_colors("0003100000117485", 1991)
    assert props["bagWallColor"] == expected_colors["wall"]
    assert props["bagRoofColorPitched"] == expected_colors["roofPitched"]
    assert props["bagRoofColorFlat"] == expected_colors["roofFlat"]
    assert props["_bagMatch"] == "id"
    assert stats == {"matched_by_id": 1, "matched_by_centroid": 0, "unmatched": 0, "total": 1}


def test_merge_carries_through_bag_status_even_when_buiten_gebruik() -> None:
    # "Pand buiten gebruik" still physically exists, so it passes fetch_bag_panden's
    # status filter — merge must not drop or suppress it, so a later step can filter.
    buildings = _fc([_building("0003100000117485", 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1991, 10.0, 10.0, status="Pand buiten gebruik")])

    merged, _stats = merge_bag_bouwjaar(buildings, bag)

    assert merged["features"][0]["properties"]["bagStatus"] == "Pand buiten gebruik"


def test_merge_falls_back_to_centroid_when_no_ref_bag_tag() -> None:
    # Building has no ref:bag tag, but its centroid lies inside the pand polygon.
    buildings = _fc([_building(None, 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1975, 10.0, 10.0)])

    merged, stats = merge_bag_bouwjaar(buildings, bag)

    props = merged["features"][0]["properties"]
    assert props["bagBouwjaar"] == 1975
    assert props["bagIdentificatie"] == "0003100000117485"
    assert props["bagStatus"] == "Pand in gebruik"
    assert props["_bagMatch"] == "centroid"
    assert stats["matched_by_centroid"] == 1


def test_merge_falls_back_to_centroid_when_ref_bag_tag_not_found() -> None:
    # Tag present but points to a pand id that was not fetched for this bbox.
    buildings = _fc([_building("unknown-id", 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1975, 10.0, 10.0)])

    merged, _stats = merge_bag_bouwjaar(buildings, bag)

    assert merged["features"][0]["properties"]["_bagMatch"] == "centroid"


def test_merge_unmatched_when_centroid_outside_every_pand() -> None:
    buildings = _fc([_building(None, 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1975, 50.0, 50.0)])

    merged, stats = merge_bag_bouwjaar(buildings, bag)

    props = merged["features"][0]["properties"]
    assert props["bagBouwjaar"] is None
    assert props["bagIdentificatie"] is None
    assert props["bagStatus"] is None
    assert props["bagWallColor"] is None
    assert props["bagRoofColorPitched"] is None
    assert props["bagRoofColorFlat"] is None
    assert props["_bagMatch"] is None
    assert stats == {"matched_by_id": 0, "matched_by_centroid": 0, "unmatched": 1, "total": 1}


def test_merge_fail_open_when_bag_fc_empty() -> None:
    buildings = _fc([_building("0003100000117485", 10.0, 10.0), _building(None, 20.0, 20.0)])
    bag = _fc([])

    merged, stats = merge_bag_bouwjaar(buildings, bag)

    assert all(f["properties"]["_bagMatch"] is None for f in merged["features"])
    assert all(f["properties"]["bagWallColor"] is None for f in merged["features"])
    assert stats["unmatched"] == 2
    assert stats["total"] == 2


def test_merge_preserves_original_properties_and_geometry() -> None:
    buildings = _fc([_building("0003100000117485", 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1991, 10.0, 10.0)])

    merged, _stats = merge_bag_bouwjaar(buildings, bag)

    assert merged["features"][0]["properties"]["buildingType"] == "house"
    assert merged["features"][0]["geometry"]["type"] == "Polygon"
