"""Local debug runner for bag_fetcher.

Determines a bounding box (either passed explicitly with ``--bbox`` or derived
from a network parquet given with ``--network``), fetches BAG pand features
(construction year ``bouwjaar``) from the PDOK BAG OGC API Features service,
merges ``bouwjaar`` onto an existing buildings GeoParquet (``--buildings``),
and writes the result as a GeoParquet ``FeatureCollection``.

Usage
-----
    python -m bag_fetcher.bag_fetcher_runner \\
        --network output/deventer/abc123-NETWORK-CAR.parquet \\
        --buildings output/deventer/abc123-BUILDINGS.parquet \\
        --output output/deventer/abc123-BUILDINGS.parquet

    python -m bag_fetcher.bag_fetcher_runner \\
        --bbox 6.39 52.14 6.43 52.17 \\
        --buildings out/buildings.parquet \\
        --output out/buildings-with-bouwjaar.parquet

Prerequisites
-------------
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        data: bytes = get_bytes_s3(bucket, key)
        return data
    with open(uri.removeprefix("file://"), "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


def _bbox_from_network(uri: str) -> list[float]:
    from gmt_shared.geoparquet import from_geoparquet

    fc = from_geoparquet(_read_uri(uri))
    bbox: list[float] | None = (fc.get("properties") or {}).get("bbox")
    if bbox and len(bbox) >= 4:
        return [float(v) for v in bbox[:4]]
    lons: list[float] = []
    lats: list[float] = []
    for feat in fc.get("features") or []:
        for coord in (feat.get("geometry") or {}).get("coordinates") or []:
            lons.append(float(coord[0]))
            lats.append(float(coord[1]))
    if not lons:
        raise ValueError("Cannot determine bounding box — network has no geometry.")
    return [min(lons), min(lats), max(lons), max(lats)]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Fetch BAG pand bouwjaar and merge it onto a buildings GeoParquet."
    )
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument(
        "--network",
        metavar="URI",
        help="Network parquet URI to derive the bbox from (s3://bucket/key or local path).",
    )
    src.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Explicit bounding box in WGS-84 decimal degrees.",
    )
    parser.add_argument(
        "--buildings",
        required=True,
        metavar="URI",
        help="Input buildings GeoParquet URI to merge bouwjaar onto.",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="URI",
        help="Output GeoParquet URI for the buildings FeatureCollection with bouwjaar merged in.",
    )
    parser.add_argument(
        "--bag-url",
        default=None,
        metavar="URL",
        help="OGC API Features base URL (default: PDOK_BAG_URL env var or the public PDOK BAG v2).",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=60,
        metavar="SECONDS",
        help="HTTP request timeout in seconds per page (default: 60).",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        metavar="PATH",
        help="Path to .env file for AWS credentials (auto-discovered if omitted).",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_network_enrichment.bag_fetcher.core.bag_fetcher_core import (
        fetch_bag_panden,
        merge_bag_bouwjaar,
    )

    bbox = list(args.bbox) if args.bbox else _bbox_from_network(args.network)
    print(f"Bbox       : {bbox}")

    buildings_fc = from_geoparquet(_read_uri(args.buildings))
    print(f"Buildings  : {len(buildings_fc.get('features') or [])} features")

    bag_fc, bag_stats = fetch_bag_panden(bbox, url=args.bag_url, timeout=args.timeout)
    print(f"BAG panden : {bag_stats}")

    merged_fc, merge_stats = merge_bag_bouwjaar(buildings_fc, bag_fc)
    print(f"Merge      : {merge_stats}")

    print(f"Writing    : {args.output}")
    _write_uri(args.output, to_geoparquet(merged_fc))
    print("Done.")


if __name__ == "__main__":
    main()
