# src/bag_fetcher/__init__.py
