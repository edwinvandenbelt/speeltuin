# Databricks notebook source
# ---------------------------------------------------------------------------
# parking_area_fetcher_nb.py — Databricks notebook interface.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Derives the bounding box (explicit widget or from a network GeoParquet).
#   3. Fetches parking-area polygons (parkeervlakken) from BGT (NL) and/or OSM.
#   4. Writes the result as a GeoParquet FeatureCollection.
#   5. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("parking_area_fetcher_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "bbox",
    "",
    "Bounding box 'minLon,minLat,maxLon,maxLat' (leave empty to derive from network_uri)",
)
dbutils.widgets.text(
    "network_uri",
    "",
    "Network GeoParquet URI to derive the bbox from (used when bbox is empty)",
)
dbutils.widgets.text(
    "output_uri",
    "",
    "Output GeoParquet URI for the parking-area FeatureCollection",
)
dbutils.widgets.text(
    "bgt_url",
    "",
    "OGC API Features base URL (leave empty for the default PDOK BGT endpoint)",
)
dbutils.widgets.text(
    "overpass_url",
    "",
    "Overpass API endpoint (leave empty for the default public instance)",
)
dbutils.widgets.dropdown(
    "use_bgt",
    "true",
    ["true", "false"],
    "Fetch BGT parking areas (Netherlands only)",
)
dbutils.widgets.dropdown(
    "use_osm",
    "true",
    ["true", "false"],
    "Fetch OSM parking areas (fail-safe)",
)
dbutils.widgets.text(
    "timeout",
    "60",
    "HTTP request timeout in seconds",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_network_enrichment.parking_area_fetcher.core.parking_area_fetcher_core import (
    fetch_parking_areas,
)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

BBOX_RAW = dbutils.widgets.get("bbox").strip()
NETWORK_URI = dbutils.widgets.get("network_uri").strip()
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()
BGT_URL = dbutils.widgets.get("bgt_url").strip() or None
OVERPASS_URL = dbutils.widgets.get("overpass_url").strip() or None
USE_BGT = dbutils.widgets.get("use_bgt").strip().lower() == "true"
USE_OSM = dbutils.widgets.get("use_osm").strip().lower() == "true"
TIMEOUT = int(dbutils.widgets.get("timeout").strip() or "60")

if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")
if not BBOX_RAW and not NETWORK_URI:
    raise ValueError("Provide either 'bbox' or 'network_uri'.")

logger.info(
    "bbox=%s  network_uri=%s  output_uri=%s  use_bgt=%s  use_osm=%s",
    BBOX_RAW,
    NETWORK_URI,
    OUTPUT_URI,
    USE_BGT,
    USE_OSM,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body: bytes = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/vnd.apache.parquet",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    import os

    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run ParkingAreaFetcher
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")

# Determine bbox
if BBOX_RAW:
    _bbox: list[float] | None = [float(v) for v in BBOX_RAW.split(",")]
else:
    _fc = from_geoparquet(_read_uri(NETWORK_URI))
    _bbox = (_fc.get("properties") or {}).get("bbox")
    if not _bbox or len(_bbox) < 4:
        _lons, _lats = [], []
        for _f in _fc.get("features") or []:
            for _c in (_f.get("geometry") or {}).get("coordinates") or []:
                _lons.append(float(_c[0]))
                _lats.append(float(_c[1]))
        _bbox = [min(_lons), min(_lats), max(_lons), max(_lats)]
print(f"Bbox      : {_bbox}")

# Fetch parking areas
_fc_out, _stats = fetch_parking_areas(
    _bbox,
    bgt_url=BGT_URL,
    overpass_url=OVERPASS_URL or "https://overpass-api.de/api/interpreter",
    timeout=TIMEOUT,
    use_bgt=USE_BGT,
    use_osm=USE_OSM,
)

# Write result
_write_uri(OUTPUT_URI, to_geoparquet(_fc_out))

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"ParkingAreaFetcher complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Output URI     : {OUTPUT_URI}")
print(f"  Parking areas  : {_stats['parkingArea']:,}")
print(f"  BGT / OSM      : {_stats['bgt']:,} / {_stats['osm']:,}")
print(f"  Source         : {_stats['source']}")
print(_SEP)
