# src/roof_color_corrector/core/__init__.py
