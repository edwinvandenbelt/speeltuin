"""Pure-Python roof_color_corrector core — corrects roof colours from aerial photos.

Optional post-process step on a buildings GeoParquet: for every building
footprint, fetches the matching crop of the PDOK RGB luchtfoto (aerial photo)
WMS service, samples the actual roof pixel colours inside the footprint, and
— when the sample is confident enough — overwrites the building's roof-colour
properties with the photo-derived colour.

This is meant to run *after* a step like ``bag_fetcher`` that already wrote a
deterministic, bouwperiode-based roof colour (``bagRoofColorPitched`` /
``bagRoofColorFlat``): those colours are a plausible guess, this module
replaces the guess with what the roof actually looks like from above,
wherever the photo gives a clean-enough read. It is equally usable on a
buildings GeoParquet that has no pre-existing roof-colour properties — the
target properties are created rather than required.

Per building
------------
1. The footprint (WGS-84 lon/lat) is reprojected to RD New (EPSG:28992,
   the luchtfoto service's native CRS) with
   :func:`gmt_shared.rd_projection.wgs84_to_rd`.
2. A tight WMS ``GetMap`` crop around the footprint's bounds (+ a small
   margin) is requested and decoded to an RGB pixel array.
3. The footprint, shrunk inward by ``erode_m`` (to avoid gutters, walls and
   shadows at the roof edge), is rasterised into a pixel mask over that crop.
4. The *median* colour of the masked pixels is taken (robust against
   chimneys, dormers, solar panels, aerials); the fraction of masked pixels
   close to that median is the confidence ("uniformity") of the read.
5. Only when enough pixels were sampled and the uniformity clears a
   threshold is the building's roof colour corrected; otherwise the
   diagnostic ``aerialRoofColor*`` properties are still written, but the
   roof-colour properties are left untouched.

Every building is processed independently and fail-safe: one bad geometry or
one failed HTTP request never aborts the whole run.

PDOK's luchtfoto coverage is nationwide; outside the Netherlands the whole
run is skipped (fail-open — matches ``bag_fetcher``'s ``is_netherlands``
short-circuit).

Public API
----------
correct_roof_color(geometry, *, ...) -> dict
    Per-building: fetch + sample one footprint's aerial roof colour.
correct_roof_colors(buildings_fc, *, ...) -> tuple[dict, dict]
    High-level entry: correct every feature of a buildings FeatureCollection.
"""

from __future__ import annotations

import hashlib
import io
import logging
import os
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

from gmt_shared.geo import is_netherlands
from gmt_shared.rd_projection import wgs84_to_rd

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached aerial tiles.
ROOF_COLOR_QUERY_VER: int = 1

_WMS_URL_FALLBACK: str = "https://service.pdok.nl/hwh/luchtfotorgb/wms/v1_0"
DEFAULT_WMS_URL: str = os.environ.get("ROOF_COLOR_WMS_URL", _WMS_URL_FALLBACK)

#: Nationwide 25cm/pixel true-colour layer. ``Actueel_orthoHR`` (7.5-8cm) is
#: sharper but not yet guaranteed nationwide coverage — pass ``layer=`` or set
#: ``ROOF_COLOR_WMS_LAYER`` to opt into it for an area that has it.
_WMS_LAYER_FALLBACK: str = "Actueel_ortho25"
DEFAULT_LAYER: str = os.environ.get("ROOF_COLOR_WMS_LAYER", _WMS_LAYER_FALLBACK)

#: Native resolution of the default layer (pixels per metre). Requesting a
#: higher density than this just upsamples without adding real detail.
DEFAULT_PX_PER_METER: float = 4.0

#: Crop margin and inward erosion, both in metres (RD New is metric).
DEFAULT_MARGIN_M: float = 1.0
DEFAULT_ERODE_M: float = 0.5

#: Confidence thresholds for accepting a sampled colour as a correction.
DEFAULT_MIN_PIXELS: int = 9
DEFAULT_MIN_UNIFORMITY: float = 0.6
DEFAULT_CONSISTENCY_DISTANCE: float = 40.0

#: Hard cap on a single WMS crop's width/height, to bound request cost even
#: for an unusually large footprint.
DEFAULT_MAX_IMAGE_PX: int = 512
_MIN_IMAGE_PX: int = 16

DEFAULT_TIMEOUT: int = 30
DEFAULT_RETRIES: int = 3
DEFAULT_MAX_WORKERS: int = 8

#: Roof-colour properties corrected on a confident match. Match
#: ``bag_fetcher``'s output property names so the two modules chain directly.
DEFAULT_PITCHED_PROPERTY: str = "bagRoofColorPitched"
DEFAULT_FLAT_PROPERTY: str = "bagRoofColorFlat"

RGB = tuple[int, int, int]


# ---------------------------------------------------------------------------
# Disk cache for aerial tiles (same opt-in-by-default pattern as
# gmt_shared.ogc_features / npr_parking_fetcher_core).
# ---------------------------------------------------------------------------


def _cache_dir() -> Path | None:
    env_val = os.environ.get("ROOF_COLOR_CACHE_DIR")
    if env_val is not None:
        return Path(env_val) if env_val.strip() else None
    default = Path(tempfile.gettempdir()) / "roof_color_cache"
    return default if default.is_dir() else None


def _cache_key(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def _cache_load(cache_dir: Path, key: str) -> bytes | None:
    path = cache_dir / f"{key}.png"
    if not path.exists():
        return None
    try:
        return path.read_bytes()
    except OSError as exc:
        logger.warning("roof_color_corrector cache read failed (%s): %s", path.name, exc)
        return None


def _cache_store(cache_dir: Path, key: str, data: bytes) -> None:
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        (cache_dir / f"{key}.png").write_bytes(data)
    except OSError as exc:
        logger.warning("roof_color_corrector cache write failed: %s", exc)


# ---------------------------------------------------------------------------
# WMS fetch
# ---------------------------------------------------------------------------


def build_getmap_url(
    bbox_rd: tuple[float, float, float, float],
    width_px: int,
    height_px: int,
    *,
    url: str = DEFAULT_WMS_URL,
    layer: str = DEFAULT_LAYER,
) -> str:
    """Return a WMS 1.3.0 ``GetMap`` URL for *bbox_rd* (RD New metres)."""
    minx, miny, maxx, maxy = bbox_rd
    params = {
        "SERVICE": "WMS",
        "VERSION": "1.3.0",
        "REQUEST": "GetMap",
        "LAYERS": layer,
        "STYLES": "",
        "CRS": "EPSG:28992",
        "BBOX": f"{minx},{miny},{maxx},{maxy}",
        "WIDTH": str(width_px),
        "HEIGHT": str(height_px),
        "FORMAT": "image/png",
    }
    return f"{url.rstrip('/')}?{urllib.parse.urlencode(params)}"


def _get_bytes(url: str, *, timeout: int, retries: int) -> bytes:
    """GET *url* and return the raw response body, with retries."""
    last_exc: Exception | None = None
    for attempt in range(retries):
        if attempt > 0:
            wait = 2**attempt
            logger.warning(
                "roof_color_corrector retry %d/%d after %.0fs (last error: %s)",
                attempt,
                retries - 1,
                wait,
                last_exc,
            )
            time.sleep(wait)
        try:
            req = urllib.request.Request(url, method="GET")
            req.add_header("User-Agent", "gmt-calculation-lib/1.0")
            req.add_header("Accept", "image/png")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status in (429, 500, 502, 503, 504):
                    raise urllib.error.HTTPError(url, resp.status, resp.reason, resp.headers, None)
                body: bytes = resp.read()
                return body
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504):
                last_exc = exc
                continue
            raise
        except urllib.error.URLError as exc:
            last_exc = exc
            continue
        except TimeoutError as exc:
            last_exc = exc
            continue
    raise last_exc  # type: ignore[misc]


def fetch_aerial_tile(
    bbox_rd: tuple[float, float, float, float],
    width_px: int,
    height_px: int,
    *,
    url: str = DEFAULT_WMS_URL,
    layer: str = DEFAULT_LAYER,
    timeout: int = DEFAULT_TIMEOUT,
    retries: int = DEFAULT_RETRIES,
) -> bytes:
    """Fetch one WMS ``GetMap`` PNG crop for *bbox_rd*, using the on-disk cache."""
    full_url = build_getmap_url(bbox_rd, width_px, height_px, url=url, layer=layer)

    cache = _cache_dir()
    key = _cache_key(f"{ROOF_COLOR_QUERY_VER}:{full_url}") if cache is not None else None
    if cache is not None and key is not None:
        cached = _cache_load(cache, key)
        if cached is not None:
            return cached

    data = _get_bytes(full_url, timeout=timeout, retries=retries)

    if cache is not None and key is not None:
        _cache_store(cache, key, data)
    return data


# ---------------------------------------------------------------------------
# Geometry: WGS-84 -> RD New, footprint -> pixel mask
# ---------------------------------------------------------------------------


def _geometry_to_rd_polygon(geometry: dict[str, Any]) -> Any | None:
    """Reproject a GeoJSON Polygon/MultiPolygon geometry to an RD New shapely geometry."""
    from shapely.geometry import shape
    from shapely.ops import transform

    try:
        geom = shape(geometry)
    except Exception:
        return None
    if geom.is_empty or geom.geom_type not in ("Polygon", "MultiPolygon"):
        return None
    try:
        return transform(lambda lon, lat: wgs84_to_rd(lon, lat), geom)
    except Exception:
        return None


def _polygon_mask(
    rd_polygon: Any, bbox_rd: tuple[float, float, float, float], width_px: int, height_px: int
) -> Any:
    """Rasterise *rd_polygon* (RD New) into a boolean pixel mask over *bbox_rd*."""
    import numpy as np
    from PIL import Image, ImageDraw

    minx, miny, maxx, maxy = bbox_rd
    sx = width_px / (maxx - minx)
    sy = height_px / (maxy - miny)

    def to_px(x: float, y: float) -> tuple[float, float]:
        return (x - minx) * sx, (maxy - y) * sy

    mask_img = Image.new("L", (width_px, height_px), 0)
    draw = ImageDraw.Draw(mask_img)
    polygons = rd_polygon.geoms if rd_polygon.geom_type == "MultiPolygon" else [rd_polygon]
    for poly in polygons:
        if poly.is_empty:
            continue
        draw.polygon([to_px(x, y) for x, y in poly.exterior.coords], fill=255)
        for interior in poly.interiors:
            draw.polygon([to_px(x, y) for x, y in interior.coords], fill=0)
    return np.asarray(mask_img) > 0


def _decode_image(data: bytes) -> Any:
    """Decode PNG/JPEG *data* into an ``(h, w, 3)`` uint8 RGB array."""
    import numpy as np
    from PIL import Image

    with Image.open(io.BytesIO(data)) as im:
        return np.asarray(im.convert("RGB"))


def _rgb_to_hex(rgb: RGB) -> str:
    return "#{:02x}{:02x}{:02x}".format(*rgb)


def _sample_color(
    rgb_array: Any, mask: Any, *, consistency_distance: float
) -> tuple[RGB | None, int, float]:
    """Return ``(median_rgb, pixel_count, uniformity)`` for the masked pixels.

    ``uniformity`` is the fraction of masked pixels within
    *consistency_distance* of the median colour — a cluttered or shadowed
    roof scores low, a clean uniform roof scores close to 1.0.
    """
    import numpy as np

    h, w = rgb_array.shape[:2]
    if mask.shape != (h, w):
        return None, 0, 0.0
    pixels = rgb_array[mask]
    n = int(pixels.shape[0])
    if n == 0:
        return None, 0, 0.0
    median = np.median(pixels, axis=0)
    distances = np.sqrt(((pixels.astype(np.float64) - median) ** 2).sum(axis=1))
    uniformity = float((distances <= consistency_distance).mean())
    rgb: RGB = tuple(int(v) for v in median)  # type: ignore[assignment]
    return rgb, n, uniformity


# ---------------------------------------------------------------------------
# Per-building correction
# ---------------------------------------------------------------------------


def correct_roof_color(
    geometry: dict[str, Any],
    *,
    margin_m: float = DEFAULT_MARGIN_M,
    erode_m: float = DEFAULT_ERODE_M,
    px_per_meter: float = DEFAULT_PX_PER_METER,
    max_image_px: int = DEFAULT_MAX_IMAGE_PX,
    consistency_distance: float = DEFAULT_CONSISTENCY_DISTANCE,
    wms_url: str = DEFAULT_WMS_URL,
    layer: str = DEFAULT_LAYER,
    timeout: int = DEFAULT_TIMEOUT,
    retries: int = DEFAULT_RETRIES,
) -> dict[str, Any]:
    """Fetch and sample one building footprint's aerial roof colour.

    Returns ``{"color": hex str | None, "pixels": int, "uniformity": float}``.
    ``color`` is None when the footprint had no usable geometry or the aerial
    tile could not be fetched/decoded; callers decide the confidence
    threshold for actually applying ``color`` as a correction.
    """
    rd_polygon = _geometry_to_rd_polygon(geometry)
    if rd_polygon is None or rd_polygon.is_empty:
        return {"color": None, "pixels": 0, "uniformity": 0.0}

    minx, miny, maxx, maxy = rd_polygon.bounds
    bbox_rd = (minx - margin_m, miny - margin_m, maxx + margin_m, maxy + margin_m)
    width_px = min(
        max_image_px, max(_MIN_IMAGE_PX, round((bbox_rd[2] - bbox_rd[0]) * px_per_meter))
    )
    height_px = min(
        max_image_px, max(_MIN_IMAGE_PX, round((bbox_rd[3] - bbox_rd[1]) * px_per_meter))
    )

    try:
        data = fetch_aerial_tile(
            bbox_rd, width_px, height_px, url=wms_url, layer=layer, timeout=timeout, retries=retries
        )
        rgb_array = _decode_image(data)
    except Exception as exc:
        logger.warning("roof_color_corrector: aerial tile fetch/decode failed: %s", exc)
        return {"color": None, "pixels": 0, "uniformity": 0.0}

    sample_polygon = rd_polygon.buffer(-erode_m)
    if sample_polygon.is_empty:
        sample_polygon = rd_polygon
    mask = _polygon_mask(sample_polygon, bbox_rd, width_px, height_px)

    median, pixels, uniformity = _sample_color(
        rgb_array, mask, consistency_distance=consistency_distance
    )
    color = _rgb_to_hex(median) if median is not None else None
    return {"color": color, "pixels": pixels, "uniformity": round(uniformity, 3)}


# ---------------------------------------------------------------------------
# Bulk correction over a buildings FeatureCollection
# ---------------------------------------------------------------------------


def _bbox_from_features(features: list[dict[str, Any]]) -> list[float]:
    lons: list[float] = []
    lats: list[float] = []
    for feat in features:
        for coord in _iter_coords((feat.get("geometry") or {}).get("coordinates") or []):
            lons.append(float(coord[0]))
            lats.append(float(coord[1]))
    if not lons:
        return [0.0, 0.0, 0.0, 0.0]
    return [min(lons), min(lats), max(lons), max(lats)]


def _iter_coords(node: Any) -> Any:
    """Yield every ``[lon, lat, ...]`` leaf coordinate pair in a nested GeoJSON coordinates array."""
    if not node:
        return
    first = node[0]
    if isinstance(first, int | float):
        yield node
        return
    for child in node:
        yield from _iter_coords(child)


def _tag_result(
    feature: dict[str, Any],
    result: dict[str, Any],
    *,
    confident: bool,
    pitched_property: str,
    flat_property: str,
) -> dict[str, Any]:
    props = dict(feature.get("properties") or {})
    props["aerialRoofColor"] = result["color"]
    props["aerialRoofColorPixels"] = result["pixels"]
    props["aerialRoofColorUniformity"] = result["uniformity"]
    if confident:
        props[pitched_property] = result["color"]
        props[flat_property] = result["color"]
        props["_roofColorMatch"] = "aerial"
    else:
        props["_roofColorMatch"] = None
    return {**feature, "properties": props}


def correct_roof_colors(
    buildings_fc: dict[str, Any],
    *,
    pitched_property: str = DEFAULT_PITCHED_PROPERTY,
    flat_property: str = DEFAULT_FLAT_PROPERTY,
    margin_m: float = DEFAULT_MARGIN_M,
    erode_m: float = DEFAULT_ERODE_M,
    px_per_meter: float = DEFAULT_PX_PER_METER,
    max_image_px: int = DEFAULT_MAX_IMAGE_PX,
    min_pixels: int = DEFAULT_MIN_PIXELS,
    min_uniformity: float = DEFAULT_MIN_UNIFORMITY,
    consistency_distance: float = DEFAULT_CONSISTENCY_DISTANCE,
    wms_url: str = DEFAULT_WMS_URL,
    layer: str = DEFAULT_LAYER,
    timeout: int = DEFAULT_TIMEOUT,
    retries: int = DEFAULT_RETRIES,
    max_workers: int = DEFAULT_MAX_WORKERS,
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Correct the roof colour of every feature of *buildings_fc* from aerial photos.

    Every feature gets diagnostic properties ``aerialRoofColor`` (hex or
    None), ``aerialRoofColorPixels`` (int) and ``aerialRoofColorUniformity``
    (0.0-1.0). When the sample clears both ``min_pixels`` and
    ``min_uniformity``, *pitched_property* and *flat_property* are also
    overwritten with the sampled colour and ``_roofColorMatch`` is set to
    ``"aerial"``; otherwise those two properties are left untouched and
    ``_roofColorMatch`` is None.

    Does not mutate *buildings_fc*; returns a new FeatureCollection.
    Fail-open: when the buildings' bbox centroid lies outside the
    Netherlands, every feature is left untouched (only the diagnostic
    properties are added, all None/0) and no HTTP requests are made.

    Returns
    -------
    fc:
        *buildings_fc* with the properties above added/updated.
    stats:
        ``{"total": int, "corrected": int, "low_confidence": int,
        "fetch_failed": int, "skipped": int}``.
    """
    features = buildings_fc.get("features") or []
    stats = {
        "total": len(features),
        "corrected": 0,
        "low_confidence": 0,
        "fetch_failed": 0,
        "skipped": 0,
    }
    if not features:
        return dict(buildings_fc), stats

    bbox = _bbox_from_features(features)
    if not is_netherlands(bbox):
        logger.info("roof_color_corrector: bbox centroid outside NL — skipping.")
        stats["skipped"] = len(features)
        no_match = {"color": None, "pixels": 0, "uniformity": 0.0}
        out_features = [
            _tag_result(
                feat,
                no_match,
                confident=False,
                pitched_property=pitched_property,
                flat_property=flat_property,
            )
            for feat in features
        ]
        return {**buildings_fc, "features": out_features}, stats

    def _process(feature: dict[str, Any]) -> dict[str, Any]:
        geometry = feature.get("geometry")
        if not geometry:
            return {"color": None, "pixels": 0, "uniformity": 0.0}
        try:
            return correct_roof_color(
                geometry,
                margin_m=margin_m,
                erode_m=erode_m,
                px_per_meter=px_per_meter,
                max_image_px=max_image_px,
                consistency_distance=consistency_distance,
                wms_url=wms_url,
                layer=layer,
                timeout=timeout,
                retries=retries,
            )
        except Exception as exc:  # fail-safe per building
            logger.warning("roof_color_corrector: unexpected error for a feature: %s", exc)
            return {"color": None, "pixels": 0, "uniformity": 0.0}

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        results = list(pool.map(_process, features))

    out_features = []
    for feature, result in zip(features, results, strict=True):
        confident = (
            result["color"] is not None
            and result["pixels"] >= min_pixels
            and result["uniformity"] >= min_uniformity
        )
        if confident:
            stats["corrected"] += 1
        elif result["color"] is None:
            stats["fetch_failed"] += 1
        else:
            stats["low_confidence"] += 1
        out_features.append(
            _tag_result(
                feature,
                result,
                confident=confident,
                pitched_property=pitched_property,
                flat_property=flat_property,
            )
        )

    return {**buildings_fc, "features": out_features}, stats
