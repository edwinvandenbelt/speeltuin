"""Unit tests for roof_color_corrector core (pure functions + stubbed HTTP/image I/O)."""

from __future__ import annotations

import numpy as np
import pytest

import gmt_network_enrichment.roof_color_corrector.core.roof_color_corrector_core as core
from gmt_network_enrichment.roof_color_corrector.core.roof_color_corrector_core import (
    DEFAULT_FLAT_PROPERTY,
    DEFAULT_PITCHED_PROPERTY,
    build_getmap_url,
    correct_roof_color,
    correct_roof_colors,
)

# NL bbox (Lochem-ish) and a non-NL bbox (Paris) — same bboxes as bag_fetcher's tests.
_NL_BBOX = [6.39, 52.14, 6.43, 52.17]
_PARIS_BBOX = [2.2, 48.8, 2.4, 48.9]


def _square(cx: float, cy: float, half: float = 0.0005) -> dict:
    return {
        "type": "Polygon",
        "coordinates": [
            [
                [cx - half, cy - half],
                [cx + half, cy - half],
                [cx + half, cy + half],
                [cx - half, cy + half],
                [cx - half, cy - half],
            ]
        ],
    }


def _building(cx: float, cy: float) -> dict:
    return {"type": "Feature", "geometry": _square(cx, cy), "properties": {"buildingType": "house"}}


def _fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features, "properties": {}}


# ---------------------------------------------------------------------------
# build_getmap_url
# ---------------------------------------------------------------------------


def test_build_getmap_url_contains_bbox_and_layer() -> None:
    url = build_getmap_url(
        (100.0, 200.0, 150.0, 250.0), 64, 48, url="https://example.test/wms", layer="MyLayer"
    )
    assert url.startswith("https://example.test/wms?")
    assert "LAYERS=MyLayer" in url
    assert "WIDTH=64" in url
    assert "HEIGHT=48" in url
    assert "CRS=EPSG%3A28992" in url
    assert "BBOX=100.0%2C200.0%2C150.0%2C250.0" in url


# ---------------------------------------------------------------------------
# _geometry_to_rd_polygon
# ---------------------------------------------------------------------------


def test_geometry_to_rd_polygon_valid_square() -> None:
    rd_polygon = core._geometry_to_rd_polygon(_square(6.40, 52.15))
    assert rd_polygon is not None
    assert not rd_polygon.is_empty
    minx, miny, maxx, maxy = rd_polygon.bounds
    assert maxx > minx
    assert maxy > miny


def test_geometry_to_rd_polygon_rejects_non_polygon() -> None:
    assert core._geometry_to_rd_polygon({"type": "Point", "coordinates": [6.40, 52.15]}) is None


def test_geometry_to_rd_polygon_rejects_malformed() -> None:
    assert core._geometry_to_rd_polygon({"type": "Polygon", "coordinates": []}) is None


# ---------------------------------------------------------------------------
# _polygon_mask
# ---------------------------------------------------------------------------


def test_polygon_mask_marks_interior_true() -> None:
    from shapely.geometry import box

    rd_polygon = box(10.0, 10.0, 20.0, 20.0)
    mask = core._polygon_mask(rd_polygon, (0.0, 0.0, 30.0, 30.0), width_px=30, height_px=30)
    assert mask.shape == (30, 30)
    # Centre of the box in geo space -> middle-ish of the raster.
    assert bool(mask[15, 15])
    # Far outside the box.
    assert not bool(mask[1, 1])


# ---------------------------------------------------------------------------
# _sample_color
# ---------------------------------------------------------------------------


def _uniform_image(rgb: tuple[int, int, int], size: int = 10) -> np.ndarray:
    arr = np.zeros((size, size, 3), dtype=np.uint8)
    arr[:, :] = rgb
    return arr


def test_sample_color_uniform_image_gives_exact_median_and_full_uniformity() -> None:
    image = _uniform_image((120, 60, 40))
    mask = np.ones((10, 10), dtype=bool)
    rgb, pixels, uniformity = core._sample_color(image, mask, consistency_distance=10.0)
    assert rgb == (120, 60, 40)
    assert pixels == 100
    assert uniformity == 1.0


def test_sample_color_empty_mask_returns_none() -> None:
    image = _uniform_image((120, 60, 40))
    mask = np.zeros((10, 10), dtype=bool)
    rgb, pixels, uniformity = core._sample_color(image, mask, consistency_distance=10.0)
    assert rgb is None
    assert pixels == 0
    assert uniformity == 0.0


def test_sample_color_noisy_pixels_lower_uniformity() -> None:
    image = _uniform_image((100, 100, 100))
    # Corrupt a quarter of the pixels with a wildly different colour.
    image[:5, :5] = (0, 0, 255)
    mask = np.ones((10, 10), dtype=bool)
    _rgb, pixels, uniformity = core._sample_color(image, mask, consistency_distance=10.0)
    assert pixels == 100
    assert uniformity == pytest.approx(0.75, abs=0.01)


def test_sample_color_shape_mismatch_returns_none() -> None:
    image = _uniform_image((100, 100, 100), size=10)
    mask = np.ones((5, 5), dtype=bool)
    rgb, pixels, _uniformity = core._sample_color(image, mask, consistency_distance=10.0)
    assert rgb is None
    assert pixels == 0


# ---------------------------------------------------------------------------
# correct_roof_color (single building, stubbed fetch + decode)
# ---------------------------------------------------------------------------


def test_correct_roof_color_confident_match(monkeypatch) -> None:
    monkeypatch.setattr(
        core, "fetch_aerial_tile", lambda *_a, **_kw: b"stub-png-bytes", raising=True
    )
    monkeypatch.setattr(
        core, "_decode_image", lambda _data: _uniform_image((80, 30, 20), size=40), raising=True
    )
    # Isolate this test to the fetch/decode/sample wiring — the geometry ->
    # pixel-mask mapping itself is covered by test_polygon_mask_*.
    monkeypatch.setattr(
        core, "_polygon_mask", lambda *_a, **_kw: np.ones((40, 40), dtype=bool), raising=True
    )

    result = correct_roof_color(_square(6.40, 52.15))
    assert result["color"] == "#501e14"
    assert result["pixels"] == 1600
    assert result["uniformity"] == 1.0


def test_correct_roof_color_fetch_failure_returns_none(monkeypatch) -> None:
    def _boom(*_a, **_kw):
        raise ConnectionError("boom")

    monkeypatch.setattr(core, "fetch_aerial_tile", _boom, raising=True)

    result = correct_roof_color(_square(6.40, 52.15))
    assert result == {"color": None, "pixels": 0, "uniformity": 0.0}


def test_correct_roof_color_empty_geometry_returns_none() -> None:
    result = correct_roof_color({"type": "Polygon", "coordinates": []})
    assert result == {"color": None, "pixels": 0, "uniformity": 0.0}


# ---------------------------------------------------------------------------
# correct_roof_colors (bulk, stubbed correct_roof_color)
# ---------------------------------------------------------------------------


def test_correct_roof_colors_outside_nl_skips_every_building(monkeypatch) -> None:
    def _should_not_be_called(*_a, **_kw):
        raise AssertionError("correct_roof_color should not run outside NL")

    monkeypatch.setattr(core, "correct_roof_color", _should_not_be_called, raising=True)

    fc = _fc([_building(*_PARIS_BBOX[:2])])
    out_fc, stats = correct_roof_colors(fc)

    assert stats == {
        "total": 1,
        "corrected": 0,
        "low_confidence": 0,
        "fetch_failed": 0,
        "skipped": 1,
    }
    props = out_fc["features"][0]["properties"]
    assert props["aerialRoofColor"] is None
    assert props["_roofColorMatch"] is None


def test_correct_roof_colors_applies_confident_correction(monkeypatch) -> None:
    monkeypatch.setattr(
        core,
        "correct_roof_color",
        lambda *_a, **_kw: {"color": "#aabbcc", "pixels": 50, "uniformity": 0.9},
        raising=True,
    )

    fc = _fc([_building(6.40, 52.15)])
    out_fc, stats = correct_roof_colors(fc, min_pixels=9, min_uniformity=0.6)

    assert stats["corrected"] == 1
    assert stats["total"] == 1
    props = out_fc["features"][0]["properties"]
    assert props[DEFAULT_PITCHED_PROPERTY] == "#aabbcc"
    assert props[DEFAULT_FLAT_PROPERTY] == "#aabbcc"
    assert props["_roofColorMatch"] == "aerial"
    assert props["aerialRoofColorPixels"] == 50


def test_correct_roof_colors_low_confidence_leaves_properties_untouched(monkeypatch) -> None:
    monkeypatch.setattr(
        core,
        "correct_roof_color",
        lambda *_a, **_kw: {"color": "#aabbcc", "pixels": 3, "uniformity": 0.9},
        raising=True,
    )

    feature = _building(6.40, 52.15)
    feature["properties"]["bagRoofColorPitched"] = "#ff0000"
    fc = _fc([feature])
    out_fc, stats = correct_roof_colors(fc, min_pixels=9, min_uniformity=0.6)

    assert stats["low_confidence"] == 1
    props = out_fc["features"][0]["properties"]
    assert props["bagRoofColorPitched"] == "#ff0000"
    assert props["_roofColorMatch"] is None


def test_correct_roof_colors_fetch_failure_is_tracked(monkeypatch) -> None:
    monkeypatch.setattr(
        core,
        "correct_roof_color",
        lambda *_a, **_kw: {"color": None, "pixels": 0, "uniformity": 0.0},
        raising=True,
    )

    fc = _fc([_building(6.40, 52.15)])
    _out_fc, stats = correct_roof_colors(fc)
    assert stats["fetch_failed"] == 1


def test_correct_roof_colors_is_failsafe_per_building(monkeypatch) -> None:
    calls = {"n": 0}

    def _maybe_boom(geometry, **_kw):
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("boom")
        return {"color": "#aabbcc", "pixels": 50, "uniformity": 0.9}

    monkeypatch.setattr(core, "correct_roof_color", _maybe_boom, raising=True)

    fc = _fc([_building(6.40, 52.15), _building(6.41, 52.16)])
    _out_fc, stats = correct_roof_colors(fc)

    assert stats["total"] == 2
    assert stats["fetch_failed"] == 1
    assert stats["corrected"] == 1


def test_correct_roof_colors_empty_input() -> None:
    out_fc, stats = correct_roof_colors(_fc([]))
    assert out_fc["features"] == []
    assert stats["total"] == 0
