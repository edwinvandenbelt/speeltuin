# src/roof_color_corrector/tests/__init__.py
