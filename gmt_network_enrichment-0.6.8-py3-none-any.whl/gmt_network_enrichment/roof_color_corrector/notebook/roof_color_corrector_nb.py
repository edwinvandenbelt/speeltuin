# Databricks notebook source
# ---------------------------------------------------------------------------
# roof_color_corrector_nb.py — Databricks notebook interface.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads the input buildings GeoParquet.
#   3. For every building footprint, fetches a PDOK luchtfoto (aerial photo)
#      WMS crop and samples its roof colour.
#   4. Overwrites bagRoofColorPitched/bagRoofColorFlat (or the configured
#      property names) with the aerial colour wherever the sample is
#      confident enough; otherwise leaves them untouched.
#   5. Writes the result as a GeoParquet FeatureCollection.
#   6. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("roof_color_corrector_nb")

# COMMAND ----------
# MAGIC %pip install boto3 pillow

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "buildings_uri",
    "",
    "Input buildings GeoParquet URI to correct",
)
dbutils.widgets.text(
    "output_uri",
    "",
    "Output GeoParquet URI for the buildings FeatureCollection with corrected roof colours",
)
dbutils.widgets.text(
    "pitched_property",
    "",
    "Property to overwrite for pitched roofs (leave empty for bagRoofColorPitched)",
)
dbutils.widgets.text(
    "flat_property",
    "",
    "Property to overwrite for flat roofs (leave empty for bagRoofColorFlat)",
)
dbutils.widgets.text(
    "wms_url",
    "",
    "WMS base URL (leave empty for the default PDOK luchtfoto RGB service)",
)
dbutils.widgets.text(
    "layer",
    "",
    "WMS layer name (leave empty for 'Actueel_ortho25')",
)
dbutils.widgets.text(
    "timeout",
    "30",
    "HTTP request timeout in seconds per tile",
)
dbutils.widgets.text(
    "max_workers",
    "8",
    "Thread-pool size for the per-building aerial-tile fetch",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_network_enrichment.roof_color_corrector.core.roof_color_corrector_core import (
    DEFAULT_FLAT_PROPERTY,
    DEFAULT_LAYER,
    DEFAULT_PITCHED_PROPERTY,
    DEFAULT_WMS_URL,
    correct_roof_colors,
)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

BUILDINGS_URI = dbutils.widgets.get("buildings_uri").strip()
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()
PITCHED_PROPERTY = dbutils.widgets.get("pitched_property").strip() or DEFAULT_PITCHED_PROPERTY
FLAT_PROPERTY = dbutils.widgets.get("flat_property").strip() or DEFAULT_FLAT_PROPERTY
WMS_URL = dbutils.widgets.get("wms_url").strip() or DEFAULT_WMS_URL
LAYER = dbutils.widgets.get("layer").strip() or DEFAULT_LAYER
TIMEOUT = int(dbutils.widgets.get("timeout").strip() or "30")
MAX_WORKERS = int(dbutils.widgets.get("max_workers").strip() or "8")

if not BUILDINGS_URI:
    raise ValueError("Widget 'buildings_uri' is empty.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")

logger.info(
    "buildings_uri=%s  output_uri=%s  pitched_property=%s  flat_property=%s  layer=%s",
    BUILDINGS_URI,
    OUTPUT_URI,
    PITCHED_PROPERTY,
    FLAT_PROPERTY,
    LAYER,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body: bytes = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/vnd.apache.parquet",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    import os

    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run RoofColorCorrector
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")

_buildings_fc = from_geoparquet(_read_uri(BUILDINGS_URI))
print(f"Buildings : {len(_buildings_fc.get('features') or [])} features")

_corrected_fc, _stats = correct_roof_colors(
    _buildings_fc,
    pitched_property=PITCHED_PROPERTY,
    flat_property=FLAT_PROPERTY,
    wms_url=WMS_URL,
    layer=LAYER,
    timeout=TIMEOUT,
    max_workers=MAX_WORKERS,
)

_write_uri(OUTPUT_URI, to_geoparquet(_corrected_fc))

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"RoofColorCorrector complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Output URI       : {OUTPUT_URI}")
print(f"  Total buildings  : {_stats['total']:,}")
print(f"  Corrected        : {_stats['corrected']:,}")
print(f"  Low confidence   : {_stats['low_confidence']:,}")
print(f"  Fetch failed     : {_stats['fetch_failed']:,}")
print(f"  Skipped (non-NL) : {_stats['skipped']:,}")
print(_SEP)
