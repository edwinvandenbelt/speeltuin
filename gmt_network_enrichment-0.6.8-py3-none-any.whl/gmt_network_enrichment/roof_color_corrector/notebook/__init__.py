# src/roof_color_corrector/notebook/__init__.py
