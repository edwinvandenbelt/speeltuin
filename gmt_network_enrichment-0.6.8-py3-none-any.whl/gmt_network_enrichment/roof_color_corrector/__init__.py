# src/roof_color_corrector/__init__.py
