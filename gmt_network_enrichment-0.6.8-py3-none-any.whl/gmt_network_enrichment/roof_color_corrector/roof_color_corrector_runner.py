"""Local debug runner for roof_color_corrector.

Optional post-process step on a buildings GeoParquet: samples the PDOK RGB
luchtfoto (aerial photo) WMS service over every building footprint and, when
the sample is confident enough, corrects the roof-colour properties
(``bagRoofColorPitched`` / ``bagRoofColorFlat`` by default) with the colour
actually visible from above.

Needs only the buildings file itself — no bbox/network input, the bbox per
building is derived from its own footprint. ``--output`` defaults to
``--buildings`` (overwrite in place) when omitted.

Usage
-----
    python -m roof_color_corrector.roof_color_corrector_runner \\
        --buildings output/deventer/abc123-BUILDINGS.parquet

    python -m roof_color_corrector.roof_color_corrector_runner \\
        --buildings output/deventer/abc123-BUILDINGS.parquet \\
        --output output/deventer/abc123-BUILDINGS-CORRECTED.parquet

Prerequisites
-------------
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        data: bytes = get_bytes_s3(bucket, key)
        return data
    with open(uri.removeprefix("file://"), "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Correct building roof colours from PDOK aerial photos (luchtfoto's)."
    )
    parser.add_argument(
        "--buildings",
        required=True,
        metavar="URI",
        help="Input buildings GeoParquet URI to correct (s3://bucket/key or local path).",
    )
    parser.add_argument(
        "--output",
        default=None,
        metavar="URI",
        help=(
            "Output GeoParquet URI for the buildings FeatureCollection with corrected roof "
            "colours (default: overwrite --buildings in place)."
        ),
    )
    parser.add_argument(
        "--pitched-property",
        default=None,
        metavar="NAME",
        help="Building property to overwrite with the aerial colour for pitched roofs (default: bagRoofColorPitched).",
    )
    parser.add_argument(
        "--flat-property",
        default=None,
        metavar="NAME",
        help="Building property to overwrite with the aerial colour for flat roofs (default: bagRoofColorFlat).",
    )
    parser.add_argument(
        "--wms-url",
        default=None,
        metavar="URL",
        help="WMS base URL (default: ROOF_COLOR_WMS_URL env var or the public PDOK luchtfoto RGB service).",
    )
    parser.add_argument(
        "--layer",
        default=None,
        metavar="NAME",
        help="WMS layer name (default: ROOF_COLOR_WMS_LAYER env var or 'Actueel_ortho25').",
    )
    parser.add_argument(
        "--margin-m",
        type=float,
        default=None,
        metavar="METRES",
        help="Crop margin around each footprint, in metres (default: 1.0).",
    )
    parser.add_argument(
        "--erode-m",
        type=float,
        default=None,
        metavar="METRES",
        help="Inward erosion of the footprint before sampling, in metres (default: 0.5).",
    )
    parser.add_argument(
        "--px-per-meter",
        type=float,
        default=None,
        metavar="N",
        help="Requested image resolution in pixels per metre (default: 4.0, the layer's native resolution).",
    )
    parser.add_argument(
        "--min-pixels",
        type=int,
        default=None,
        metavar="N",
        help="Minimum sampled pixel count to accept a correction (default: 9).",
    )
    parser.add_argument(
        "--min-uniformity",
        type=float,
        default=None,
        metavar="0-1",
        help="Minimum colour uniformity to accept a correction (default: 0.6).",
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=30,
        metavar="SECONDS",
        help="HTTP request timeout in seconds per tile (default: 30).",
    )
    parser.add_argument(
        "--retries",
        type=int,
        default=3,
        metavar="N",
        help="Maximum retry attempts per HTTP request (default: 3).",
    )
    parser.add_argument(
        "--max-workers",
        type=int,
        default=8,
        metavar="N",
        help="Thread-pool size for the per-building aerial-tile fetch (default: 8).",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        metavar="PATH",
        help="Path to .env file for AWS credentials (auto-discovered if omitted).",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_network_enrichment.roof_color_corrector.core.roof_color_corrector_core import (
        DEFAULT_FLAT_PROPERTY,
        DEFAULT_LAYER,
        DEFAULT_PITCHED_PROPERTY,
        DEFAULT_WMS_URL,
        correct_roof_colors,
    )

    output_uri = args.output or args.buildings

    buildings_fc = from_geoparquet(_read_uri(args.buildings))
    print(f"Buildings : {len(buildings_fc.get('features') or [])} features")

    kwargs: dict = {
        "pitched_property": args.pitched_property or DEFAULT_PITCHED_PROPERTY,
        "flat_property": args.flat_property or DEFAULT_FLAT_PROPERTY,
        "wms_url": args.wms_url or DEFAULT_WMS_URL,
        "layer": args.layer or DEFAULT_LAYER,
        "timeout": args.timeout,
        "retries": args.retries,
        "max_workers": args.max_workers,
    }
    if args.margin_m is not None:
        kwargs["margin_m"] = args.margin_m
    if args.erode_m is not None:
        kwargs["erode_m"] = args.erode_m
    if args.px_per_meter is not None:
        kwargs["px_per_meter"] = args.px_per_meter
    if args.min_pixels is not None:
        kwargs["min_pixels"] = args.min_pixels
    if args.min_uniformity is not None:
        kwargs["min_uniformity"] = args.min_uniformity

    corrected_fc, stats = correct_roof_colors(buildings_fc, **kwargs)
    print(f"Stats     : {stats}")

    print(f"Writing   : {output_uri}")
    _write_uri(output_uri, to_geoparquet(corrected_fc))
    print("Done.")


if __name__ == "__main__":
    main()
