"""Pure-Python npr_parking_fetcher core — fetches NPR parking-facility data.

Fetches parking-facility information from the RDW **NPR** (Nationaal
Parkeerregister, formerly SHPV) open data API v2
(``https://npropendata.rdw.nl/parkingdata/v2/``) and converts it into a
GeoJSON ``FeatureCollection`` of Point features tagged
``assetType = "parkingFacility"``, ``source = "NPR"``.

Only the **static** facts the user asked for are kept: capacity, opening
times and tariff.  The API's real-time occupancy (``dynamicDataUrl``) is
deliberately ignored.

Two-step fetch
---------------
The facility *list* (``GET /``) has no coordinates — only a name and a
``staticDataUrl``.  Coordinates only appear in each facility's *static*
detail (``GET /static/{id}``), under ``accessPoints``.  There is no
nationwide spatial index, so every call walks the full national list
(~15k facilities as of 2026) and fetches each facility's static detail to
find its location, concurrently and **fail-safe per facility** (one bad
record never aborts the whole fetch).

Because that walk is expensive, each facility's static record is cached on
disk keyed by its identifier (see :func:`_cache_dir`, same opt-in-by-default
pattern as :mod:`gmt_shared.overpass`/:mod:`gmt_shared.ogc_features`): the
first nationwide run is slow, every run after that — for any bounding box —
only pays for facilities not yet cached.

Public API
----------
fetch_facility_list(*, base_url, timeout, retries) -> list[dict]
    Fetch the national facility list (name, identifier, staticDataUrl, ...).
fetch_facility_static(identifier, *, base_url, timeout, retries) -> dict
    Fetch one facility's static detail (``parkingFacilityInformation``).
summarize_opening_times(opening_times) -> str
    Human-readable opening-hours summary, e.g. "24/7".
summarize_tariff(tariffs) -> tuple[bool, str]
    ``(is_free, summary)``, e.g. ``(False, "€2.50/uur")``.
facility_to_feature(list_entry, static) -> dict | None
    Build a GeoJSON Point feature, or None if no usable location exists.
fetch_npr_parking(bbox, *, base_url, timeout, retries, max_workers) -> tuple[dict, dict]
    High-level entry: walk the national list, fetch + cache static details,
    keep facilities inside *bbox*.  Returns ``(fc, stats)``.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_NPR_URL_FALLBACK = "https://npropendata.rdw.nl/parkingdata/v2"
DEFAULT_NPR_URL: str = os.environ.get("NPR_URL", _NPR_URL_FALLBACK)

#: Bump to invalidate any cached NPR output.
NPR_QUERY_VER: int = 1

#: Asset-type tag written on produced features.
ASSET_TYPE_PARKING_FACILITY: str = "parkingFacility"

SOURCE_NPR: str = "NPR"

#: Default HTTP timeout / retries for both NPR endpoints.
DEFAULT_TIMEOUT: int = 30
DEFAULT_RETRIES: int = 5

#: Default thread pool size for the per-facility static-detail fetch.
DEFAULT_MAX_WORKERS: int = 16

#: Per-chargePeriod duration multiplier to normalise a tariff rate to
#: "charge per minute" (unknown duration types default to 1 — minutes).
_DURATION_MINUTES = {"Seconds": 1 / 60, "Minutes": 1.0, "Hours": 60.0, "Days": 1440.0}


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------


def _get_json(url: str, *, timeout: int, retries: int) -> dict[str, Any]:
    """GET *url* and return the parsed JSON response, with retries."""
    last_exc: Exception | None = None
    for attempt in range(retries):
        if attempt > 0:
            wait = 2**attempt
            logger.warning(
                "NPR retry %d/%d after %.0fs (last error: %s)",
                attempt,
                retries - 1,
                wait,
                last_exc,
            )
            time.sleep(wait)
        try:
            req = urllib.request.Request(url, method="GET")
            req.add_header("User-Agent", "gmt-calculation-lib/1.0")
            req.add_header("Accept", "application/json")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status in (429, 500, 502, 503, 504):
                    raise urllib.error.HTTPError(url, resp.status, resp.reason, resp.headers, None)
                body = resp.read().decode("utf-8")
            result: dict[str, Any] = json.loads(body)
            return result
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504):
                last_exc = exc
                continue
            raise
        except urllib.error.URLError as exc:
            last_exc = exc
            continue
        except TimeoutError as exc:
            last_exc = exc
            continue
        except json.JSONDecodeError as exc:
            raise ValueError(f"NPR returned invalid JSON: {exc}") from exc
    raise last_exc  # type: ignore[misc]


def fetch_facility_list(
    *,
    base_url: str = DEFAULT_NPR_URL,
    timeout: int = DEFAULT_TIMEOUT,
    retries: int = DEFAULT_RETRIES,
) -> list[dict]:
    """Fetch the national NPR facility list.

    Returns the raw ``ParkingFacilities`` array: each entry has ``name``,
    ``identifier``, ``staticDataUrl``, ``limitedAccess`` and
    ``staticDataLastUpdated`` — but no coordinates.
    """
    data = _get_json(f"{base_url.rstrip('/')}/", timeout=timeout, retries=retries)
    facilities: list[dict] = data.get("ParkingFacilities") or []
    return facilities


def fetch_facility_static(
    identifier: str,
    *,
    base_url: str = DEFAULT_NPR_URL,
    timeout: int = DEFAULT_TIMEOUT,
    retries: int = DEFAULT_RETRIES,
) -> dict:
    """Fetch one facility's static detail (the ``parkingFacilityInformation`` object)."""
    data = _get_json(
        f"{base_url.rstrip('/')}/static/{identifier}", timeout=timeout, retries=retries
    )
    info: dict = data.get("parkingFacilityInformation") or {}
    return info


# ---------------------------------------------------------------------------
# Disk cache — per facility, keyed by identifier
# ---------------------------------------------------------------------------


def _cache_dir() -> Path | None:
    """Return the active cache directory, or None when caching is disabled.

    Resolution order:
    1. ``NPR_CACHE_DIR`` environment variable (empty string disables it).
    2. ``{tempdir}/npr_cache`` when that directory already exists.
    3. ``None`` — no caching.
    """
    env_val = os.environ.get("NPR_CACHE_DIR")
    if env_val is not None:
        return Path(env_val) if env_val.strip() else None
    default = Path(tempfile.gettempdir()) / "npr_cache"
    return default if default.is_dir() else None


def _fetch_facility_static_cached(
    identifier: str,
    *,
    base_url: str,
    timeout: int,
    retries: int,
) -> dict:
    """Fetch one facility's static detail, through the on-disk cache when enabled."""
    cache = _cache_dir()
    if cache is not None:
        path = cache / f"{identifier}.json"
        if path.exists():
            try:
                cached: dict = json.loads(path.read_text(encoding="utf-8"))
                return cached
            except Exception as exc:
                logger.warning("NPR cache read failed (%s): %s", path.name, exc)

    data = fetch_facility_static(identifier, base_url=base_url, timeout=timeout, retries=retries)

    if cache is not None:
        try:
            cache.mkdir(parents=True, exist_ok=True)
            (cache / f"{identifier}.json").write_text(json.dumps(data), encoding="utf-8")
        except Exception as exc:
            logger.warning("NPR cache write failed: %s", exc)

    return data


# ---------------------------------------------------------------------------
# Pure parsers
# ---------------------------------------------------------------------------


def _current_specification(specifications: list[dict]) -> dict:
    """Return the current (no ``validityEndOfPeriod``) specification, else the last one."""
    if not specifications:
        return {}
    for spec in specifications:
        if spec.get("validityEndOfPeriod") is None:
            return spec
    return specifications[-1]


def summarize_opening_times(opening_times: list[dict]) -> str:
    """Return a short human-readable opening-hours summary.

    ``"24/7"`` when any period is open all year, lets vehicles exit all day
    and has no restricted entry times. Otherwise the (deduplicated) period
    names, or a generic "N tijdvak(ken)" when periods are unnamed.
    """
    if not opening_times:
        return "onbekend"
    for ot in opening_times:
        if ot.get("openAllYear") and ot.get("exitPossibleAllDay") and not ot.get("entryTimes"):
            return "24/7"
    names = [str(ot["periodName"]) for ot in opening_times if ot.get("periodName")]
    if names:
        return "; ".join(dict.fromkeys(names))
    return f"{len(opening_times)} tijdvak(ken)"


def _rate_per_minute(charge: float, charge_period: int, duration_type: str) -> float:
    """Normalise one ``intervalRate`` to a charge-per-minute figure."""
    unit = _DURATION_MINUTES.get(duration_type, 1.0)
    period = charge_period or 1
    return charge / (period * unit)


def summarize_tariff(tariffs: list[dict]) -> tuple[bool, str]:
    """Return ``(is_free, summary)`` derived from ``tariffs[].intervalRates``.

    ``is_free`` is True only when every interval rate charges 0.  Otherwise
    the summary reports the highest hourly-equivalent rate found across all
    tariffs (a conservative "worst case" price), e.g. ``"€2.50/uur"``.
    Returns ``(False, "onbekend")`` when no usable rate is present.
    """
    rates: list[tuple[float, int, str]] = []
    for tariff in tariffs or []:
        for rate in tariff.get("intervalRates") or []:
            charge = rate.get("charge")
            if not isinstance(charge, int | float):
                continue
            rates.append(
                (
                    float(charge),
                    int(rate.get("chargePeriod") or 1),
                    str(rate.get("durationType") or ""),
                )
            )

    if not rates:
        return False, "onbekend"
    if all(charge == 0.0 for charge, _, _ in rates):
        return True, "gratis"

    best = max(rates, key=lambda r: _rate_per_minute(*r))
    per_hour = _rate_per_minute(*best) * 60
    return False, f"€{per_hour:.2f}/uur"


def _facility_location(static: dict) -> tuple[float, float] | None:
    """Return ``(lon, lat)`` of the first access point with a location, else None."""
    for access_point in static.get("accessPoints") or []:
        for loc in access_point.get("accessPointLocation") or []:
            lat = loc.get("latitude")
            lon = loc.get("longitude")
            if lat is not None and lon is not None:
                return float(lon), float(lat)
    return None


def facility_to_feature(list_entry: dict, static: dict) -> dict | None:
    """Build a GeoJSON Point feature from a list entry + its static detail.

    Returns None when the facility has no usable access-point location.
    """
    location = _facility_location(static)
    if location is None:
        return None
    lon, lat = location

    identifier = static.get("identifier") or list_entry.get("identifier")
    spec = _current_specification(static.get("specifications") or [])
    is_free, tariff_summary = summarize_tariff(static.get("tariffs") or [])
    operator = static.get("operator") or {}

    properties = {
        "parkingId": f"npr_{identifier}",
        "assetType": ASSET_TYPE_PARKING_FACILITY,
        "source": SOURCE_NPR,
        "name": static.get("name") or list_entry.get("name"),
        "capacity": spec.get("capacity") or 0,
        "usage": spec.get("usage"),
        "disabledAccess": bool(spec.get("disabledAccess", False)),
        "chargingPointCapacity": spec.get("chargingPointCapacity") or 0,
        "operatorName": operator.get("name"),
        "limitedAccess": bool(static.get("limitedAccess", list_entry.get("limitedAccess", False))),
        "openingSummary": summarize_opening_times(static.get("openingTimes") or []),
        "tariffFree": is_free,
        "tariffSummary": tariff_summary,
    }
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": properties,
    }


# ---------------------------------------------------------------------------
# High-level entry point
# ---------------------------------------------------------------------------


def _in_bbox(lon: float, lat: float, bbox: list[float]) -> bool:
    min_lon, min_lat, max_lon, max_lat = bbox
    return min_lon <= lon <= max_lon and min_lat <= lat <= max_lat


def fetch_npr_parking(
    bbox: list[float],
    *,
    base_url: str = DEFAULT_NPR_URL,
    timeout: int = DEFAULT_TIMEOUT,
    retries: int = DEFAULT_RETRIES,
    max_workers: int = DEFAULT_MAX_WORKERS,
) -> tuple[dict, dict]:
    """Fetch NPR parking-facility points for *bbox*: capacity, opening times, tariff.

    Walks the full national facility list (there is no bbox-scoped endpoint),
    fetches each facility's static detail concurrently through the on-disk
    cache (see :func:`_cache_dir`), and keeps the facilities whose access
    point falls inside *bbox*.  A failure on one facility is logged and
    skipped — it never aborts the whole fetch.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    base_url:
        NPR open data v2 base URL.  Defaults to the public RDW endpoint (or
        the ``NPR_URL`` environment variable).
    timeout, retries:
        HTTP request timeout / retry count, applied per request.
    max_workers:
        Thread-pool size for the per-facility static-detail fetch.

    Returns
    -------
    fc:
        A GeoJSON ``FeatureCollection`` of Point features, each tagged
        ``properties.assetType == "parkingFacility"`` and
        ``properties.source == "NPR"``.
    stats:
        ``{"parkingFacility": int, "scanned": int, "errors": int, "source": str}``.
    """
    entries = fetch_facility_list(base_url=base_url, timeout=timeout, retries=retries)
    logger.info("NPR facility list: %d entries", len(entries))

    errors = 0

    def _handle(entry: dict) -> dict | None:
        nonlocal errors
        identifier = entry.get("identifier")
        if not identifier:
            return None
        try:
            static = _fetch_facility_static_cached(
                identifier, base_url=base_url, timeout=timeout, retries=retries
            )
        except Exception as exc:
            errors += 1
            logger.warning("NPR static fetch failed for %s: %s", identifier, exc)
            return None
        return facility_to_feature(entry, static)

    features: list[dict] = []
    workers = max(1, max_workers)
    with ThreadPoolExecutor(max_workers=workers) as pool:
        for feature in pool.map(_handle, entries):
            if feature is None:
                continue
            lon, lat = feature["geometry"]["coordinates"]
            if _in_bbox(lon, lat, bbox):
                features.append(feature)

    fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"_qv": NPR_QUERY_VER, "source": SOURCE_NPR},
    }
    stats = {
        "parkingFacility": len(features),
        "scanned": len(entries),
        "errors": errors,
        "source": SOURCE_NPR if features else "none",
    }
    return fc, stats
