"""Unit tests for npr_parking_fetcher core (pure functions + stubbed HTTP)."""

from __future__ import annotations

import gmt_network_enrichment.npr_parking_fetcher.core.npr_parking_fetcher_core as core
from gmt_network_enrichment.npr_parking_fetcher.core.npr_parking_fetcher_core import (
    ASSET_TYPE_PARKING_FACILITY,
    NPR_QUERY_VER,
    SOURCE_NPR,
    facility_to_feature,
    fetch_npr_parking,
    summarize_opening_times,
    summarize_tariff,
)

_NL_BBOX = [6.39, 52.14, 6.43, 52.17]


def _list_entry(identifier: str = "abc", name: str = "Test", limited: bool = False) -> dict:
    return {"identifier": identifier, "name": name, "limitedAccess": limited}


def _static(
    *,
    identifier: str = "abc",
    name: str = "Test",
    lon: float = 6.40,
    lat: float = 52.15,
    capacity: int = 10,
    usage: str = "Garage",
    disabled_access: bool = False,
    charging_capacity: int = 0,
    operator_name: str = "Gemeente Test",
    opening_times: list[dict] | None = None,
    tariffs: list[dict] | None = None,
    limited_access: bool = False,
) -> dict:
    return {
        "identifier": identifier,
        "name": name,
        "limitedAccess": limited_access,
        "specifications": [
            {
                "validityEndOfPeriod": None,
                "capacity": capacity,
                "usage": usage,
                "disabledAccess": disabled_access,
                "chargingPointCapacity": charging_capacity,
            }
        ],
        "operator": {"name": operator_name},
        "accessPoints": [
            {"accessPointLocation": [{"latitude": lat, "longitude": lon}]},
        ],
        "openingTimes": opening_times if opening_times is not None else [],
        "tariffs": tariffs if tariffs is not None else [],
    }


# ---------------------------------------------------------------------------
# summarize_opening_times
# ---------------------------------------------------------------------------


def test_summarize_opening_times_247() -> None:
    opening_times = [{"openAllYear": True, "exitPossibleAllDay": True, "entryTimes": []}]
    assert summarize_opening_times(opening_times) == "24/7"


def test_summarize_opening_times_named_periods() -> None:
    opening_times = [
        {"openAllYear": False, "periodName": "Zomer"},
        {"openAllYear": False, "periodName": "Winter"},
    ]
    assert summarize_opening_times(opening_times) == "Zomer; Winter"


def test_summarize_opening_times_unnamed_falls_back_to_count() -> None:
    opening_times = [{"openAllYear": False}, {"openAllYear": False}]
    assert summarize_opening_times(opening_times) == "2 tijdvak(ken)"


def test_summarize_opening_times_empty_is_unknown() -> None:
    assert summarize_opening_times([]) == "onbekend"


# ---------------------------------------------------------------------------
# summarize_tariff
# ---------------------------------------------------------------------------


def test_summarize_tariff_all_zero_is_free() -> None:
    tariffs = [{"intervalRates": [{"charge": 0.0, "chargePeriod": 1, "durationType": "Minutes"}]}]
    assert summarize_tariff(tariffs) == (True, "gratis")


def test_summarize_tariff_hourly_rate() -> None:
    tariffs = [{"intervalRates": [{"charge": 2.5, "chargePeriod": 1, "durationType": "Hours"}]}]
    is_free, summary = summarize_tariff(tariffs)
    assert is_free is False
    assert summary == "€2.50/uur"


def test_summarize_tariff_per_minute_rate_normalised_to_hour() -> None:
    tariffs = [{"intervalRates": [{"charge": 0.5, "chargePeriod": 15, "durationType": "Minutes"}]}]
    is_free, summary = summarize_tariff(tariffs)
    assert is_free is False
    assert summary == "€2.00/uur"


def test_summarize_tariff_picks_worst_case_across_tariffs() -> None:
    tariffs = [
        {"intervalRates": [{"charge": 1.0, "chargePeriod": 1, "durationType": "Hours"}]},
        {"intervalRates": [{"charge": 3.0, "chargePeriod": 1, "durationType": "Hours"}]},
    ]
    _is_free, summary = summarize_tariff(tariffs)
    assert summary == "€3.00/uur"


def test_summarize_tariff_empty_is_unknown() -> None:
    assert summarize_tariff([]) == (False, "onbekend")


def test_summarize_tariff_ignores_non_numeric_charge() -> None:
    tariffs = [{"intervalRates": [{"charge": None, "chargePeriod": 1, "durationType": "Hours"}]}]
    assert summarize_tariff(tariffs) == (False, "onbekend")


# ---------------------------------------------------------------------------
# facility_to_feature
# ---------------------------------------------------------------------------


def test_facility_to_feature_builds_point_with_properties() -> None:
    entry = _list_entry(identifier="abc", name="Test")
    static = _static(
        identifier="abc",
        name="Test",
        capacity=42,
        usage="P+R",
        tariffs=[
            {"intervalRates": [{"charge": 0.0, "chargePeriod": 1, "durationType": "Minutes"}]}
        ],
    )
    feat = facility_to_feature(entry, static)
    assert feat is not None
    assert feat["geometry"] == {"type": "Point", "coordinates": [6.40, 52.15]}
    props = feat["properties"]
    assert props["parkingId"] == "npr_abc"
    assert props["assetType"] == ASSET_TYPE_PARKING_FACILITY
    assert props["source"] == SOURCE_NPR
    assert props["capacity"] == 42
    assert props["usage"] == "P+R"
    assert props["operatorName"] == "Gemeente Test"
    assert props["tariffFree"] is True
    assert props["tariffSummary"] == "gratis"
    assert props["openingSummary"] == "onbekend"


def test_facility_to_feature_without_access_point_returns_none() -> None:
    entry = _list_entry()
    static = _static()
    static["accessPoints"] = []
    assert facility_to_feature(entry, static) is None


def test_facility_to_feature_defaults_missing_capacity_to_zero() -> None:
    entry = _list_entry()
    static = _static()
    static["specifications"] = [{"validityEndOfPeriod": None}]
    feat = facility_to_feature(entry, static)
    assert feat is not None
    assert feat["properties"]["capacity"] == 0


# ---------------------------------------------------------------------------
# fetch_npr_parking — orchestration
# ---------------------------------------------------------------------------


def test_fetch_npr_parking_filters_by_bbox(monkeypatch) -> None:
    entries = [_list_entry("in"), _list_entry("out")]
    statics = {
        "in": _static(identifier="in", lon=6.40, lat=52.15),
        "out": _static(identifier="out", lon=2.3, lat=48.8),  # Paris — outside bbox
    }

    monkeypatch.setattr(core, "fetch_facility_list", lambda **_kw: entries, raising=True)
    monkeypatch.setattr(
        core, "fetch_facility_static", lambda identifier, **_kw: statics[identifier], raising=True
    )
    monkeypatch.setenv("NPR_CACHE_DIR", "")

    fc, stats = fetch_npr_parking(_NL_BBOX)

    assert stats["scanned"] == 2
    assert stats["parkingFacility"] == 1
    assert stats["errors"] == 0
    assert stats["source"] == SOURCE_NPR
    assert len(fc["features"]) == 1
    assert fc["features"][0]["properties"]["parkingId"] == "npr_in"
    assert fc["properties"]["_qv"] == NPR_QUERY_VER


def test_fetch_npr_parking_is_failsafe_per_facility(monkeypatch) -> None:
    entries = [_list_entry("broken"), _list_entry("ok")]

    def _fake_static(identifier: str, **_kw) -> dict:
        if identifier == "broken":
            raise RuntimeError("boom")
        return _static(identifier="ok", lon=6.40, lat=52.15)

    monkeypatch.setattr(core, "fetch_facility_list", lambda **_kw: entries, raising=True)
    monkeypatch.setattr(core, "fetch_facility_static", _fake_static, raising=True)
    monkeypatch.setenv("NPR_CACHE_DIR", "")

    fc, stats = fetch_npr_parking(_NL_BBOX)

    assert stats["scanned"] == 2
    assert stats["errors"] == 1
    assert stats["parkingFacility"] == 1
    assert len(fc["features"]) == 1


def test_fetch_npr_parking_no_matches_reports_source_none(monkeypatch) -> None:
    entries = [_list_entry("out")]
    monkeypatch.setattr(core, "fetch_facility_list", lambda **_kw: entries, raising=True)
    monkeypatch.setattr(
        core,
        "fetch_facility_static",
        lambda _identifier, **_kw: _static(identifier="out", lon=2.3, lat=48.8),
        raising=True,
    )
    monkeypatch.setenv("NPR_CACHE_DIR", "")

    fc, stats = fetch_npr_parking(_NL_BBOX)

    assert stats["parkingFacility"] == 0
    assert stats["source"] == "none"
    assert fc["features"] == []


def test_fetch_npr_parking_skips_entries_without_identifier(monkeypatch) -> None:
    entries = [{"name": "No id"}]
    monkeypatch.setattr(core, "fetch_facility_list", lambda **_kw: entries, raising=True)
    monkeypatch.setenv("NPR_CACHE_DIR", "")

    fc, stats = fetch_npr_parking(_NL_BBOX)

    assert stats["parkingFacility"] == 0
    assert fc["features"] == []
