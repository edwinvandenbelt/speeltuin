# -*- coding: utf-8 -*-
"""
Created on Mon Sep 29 16:09:22 2025

@author: tthomas
"""

import numpy as np
import pyodbc
    
from mapping_data_lib import get_links_nvp
from mapping_data_lib import get_trips_nvp
from mapping_data_lib import get_links_spectrum
from mapping_data_lib import add_opposite_direction
from mapping_data_lib import get_mapped_results
from mapping_data_lib import export_mapped_data

from mapping_mapping_lib import get_vertices
from mapping_mapping_lib import get_sublinks
from mapping_mapping_lib import map1to2
from mapping_mapping_lib import mapped_with_overlap
from mapping_mapping_lib import add_inbetween_sublinks
from mapping_mapping_lib import add_missing_sublinks
from mapping_mapping_lib import get_mapped_segments
from mapping_mapping_lib import get_unmapped_segments
from mapping_mapping_lib import get_trips_per_link



if __name__ == '__main__':

    
    # Parameter Selection
    nnb = 20                  # Number of Nearest Neightbors
    maxlength_sublink = 5     # maximum length sublinks for mapping
    maxdist = 20              # maximum distances between source and target network for mapping
    maxalpha_forward1 = 15    # first maximum angle between source and target network for mapping
    maxalpha_forward2 = 45    # second maximum angle between source and target network for mapping
    maxalpha_backward = 30    # second maximum angle between source and target network for mapping
    map_direction = 'same'    # direction of mapping (same, opposite, both)
    map_on_self = False       # network is mapped on itself if true
    
    # main constraint for mapping
    fmatch12 = 0.5            # fraction of source or target (main) link that should be mapped 

    gemeentenaam = "Deventer"
    mode = "Car"
    year = 2025

    table_network = 'spectrum.2023_01.d110_toedeelbaar_autonetwerk'
    #table_nvp = 'mainworkspace_1863054340605750.ftallis.amsterdam_1_year_good_data'
    table_nvp = 'nvp_experimental.silver.vw_segments'

    path_mapped_links = 'C:/Users/tthomas/Goudappel Groep/Goudappel Mobility Twin - Documenten/General/Productie/what if project/uitsnedes/'+gemeentenaam+'_nvp_spectrum.gpkg'
    path_linktrips = 'C:/Users/tthomas/Goudappel Groep/Goudappel Mobility Twin - Documenten/General/Productie/what if project/preparation data/'+gemeentenaam+'_linktrips.parquet'
#    path_mapped_mainlinks = 'C:/Users/tthomas/Goudappel Groep/Goudappel Mobility Twin - Documenten/General/Productie/what if project/amsterdam/amsterdam_nvptrips_spectrum.csv'

    # connect to Databricks database
    conn = pyodbc.connect("DSN=Databricks", autocommit=True)
    cur = conn.cursor()

    print('nvp links / vertices: source network --> 1')    
    links1,vertlengths1,vertxys11,vertdxys1 = get_links_nvp(cur,table_nvp,
                                                        gemeentenaam,mode,year)
    vertlinks1 = np.array(range(len(links1)))   # each NVP vertix has a unique link id

    print('nvp trips')
    linktrips1, trips1 = get_trips_nvp(cur,table_nvp,
                                       gemeentenaam,mode,year)

    print('spectrum links & vertices: target network --> 2')
    links2,linknodes2,linkdirs2,linklengths2,linkxys2 = get_links_spectrum(cur,table_network,gemeentenaam)
    links2,linknodes2,linklengths2,linkxys2 = add_opposite_direction(links2,linknodes2,
                                                            linkdirs2,linklengths2,
                                                            linkxys2)
    vertlinks2,vertlengths2,vertxys21,vertdxys2 = get_vertices(links2,linkxys2)

    # Cut vertices into Sublinks
    print('sublinks')
    sublinks1,sublengths1,subxys1,subdxys1 = get_sublinks(vertlinks1,vertlengths1,vertxys11,vertdxys1,maxlength_sublink)
    sublinks2,sublengths2,subxys2,subdxys2 = get_sublinks(vertlinks2,vertlengths2,vertxys21,vertdxys2,maxlength_sublink)

    print('map forward small angle: source (nvp) to target (spectrum)')
    # map links1 of network1 to links2 of network2 using small angle
    nnb = 20 # Number of Nearest Neightbors
    use_parallel_distance = True    # mapped sublink should lie 'within' target link if True
    mapped = np.zeros(len(sublinks1),dtype=int)
    findex1, findex2 = map1to2(links1,sublinks1,sublinks2,
                               subxys1,subxys2,subdxys1,subdxys2,mapped,
                               maxlength_sublink,maxdist,maxalpha_forward1,
                               nnb,map_direction,map_on_self,
                               use_parallel_distance)

    print('map forward remaining angles: source (nvp) to target (spectrum)')
    # map links1 of network1 to links2 of network2 using remaing angles
    mapped[findex1] = 1 
    use_parallel_distance = True    # mapped sublink should lie 'within' target link if True
    addfindex1, addfindex2 = map1to2(links1,sublinks1,sublinks2,
                                     subxys1,subxys2,subdxys1,subdxys2,mapped,
                                     maxlength_sublink,maxdist,maxalpha_forward2,
                                     nnb,map_direction,map_on_self,
                                     use_parallel_distance)
    # add these maps
    findex1 = np.concatenate((findex1,np.array(addfindex1)))
    findex2 = np.concatenate((findex2,np.array(addfindex2)))

    print('map backward: target (spectrum) to source (nvp)')
    # map links2 of network2 to links1 of network1
    use_parallel_distance = False   
    mapped = np.zeros(len(sublinks2),dtype=int)
    bindex2, bindex1 = map1to2(links1,sublinks2,sublinks1,
                               subxys2,subxys1,subdxys2,subdxys1,mapped,
                               maxlength_sublink,maxdist,maxalpha_backward,
                               nnb,map_direction,map_on_self,
                               use_parallel_distance)

    print('check sufficient overlap')
    # check overlap: 1 if more than 50% overlap, include in mapped index
    mapindex = mapped_with_overlap(findex1,findex2,bindex1,bindex2,
                                   sublinks1,sublinks2,
                                   sublengths1,sublengths2,
                                   vertlengths1,linklengths2,fmatch12)

    # only NVP (sub)link id number is needed; not the sublink index
    mapindex[:,0] = sublinks1[mapindex[:,0]]
    
    # add sublinks that are not mapped:
    # 1) Sublinks in between two mapped sublinks with the same NVP link - Spectrum link combination 
    # 2) Other (i.e.,missing) sub links that are not mapped   
    print('add non-mapped in between sublinks')
    mapindex = add_inbetween_sublinks(mapindex,sublinks2)
    print('add other non-mapped sublinks')
    mapindex = add_missing_sublinks(mapindex,sublinks2)
    
    # Get mapped segments of the same NVP combinations per Spectrum link number    
    print('determine segments of the same NVP - Spectrum maps')
    tindex, nvpmatch = get_mapped_segments(mapindex,sublinks2)

    # Get unmapped segments    
    print('determine the unmapped segments')
    tindex1_unmapped, tindex2_unmapped = get_unmapped_segments(tindex,nvpmatch,sublinks2)

    # get mapped NVP trips on Spectrum mainlinks 
    print('select NVP trips per Spectrum mainlink')
    linktrips = get_trips_per_link(tindex,nvpmatch,
                                   links1, linktrips1,
                                   links2, linklengths2, sublengths2)

    # Get mapped geometry data 
    print('get geometries of mapped links')
    mapped_links = get_mapped_results(tindex,nvpmatch,
                                      tindex1_unmapped, tindex2_unmapped,
                                      linktrips, links1, links2,
                                      sublengths2, subxys2, subdxys2)

    print('schrijf gemapte resultaten weg')
    export_mapped_data(mapped_links, path_mapped_links, path_linktrips,
                       links2, linktrips)


    cur.close()
    conn.close()

    


                
   
