# -*- coding: utf-8 -*-
"""
Created on Tue Nov 11 13:34:49 2025

@author: tthomas
"""


import numpy as np
import pyodbc

from mapping_data_lib import get_links_spectrum
from mapping_data_lib import add_opposite_direction
from mapping_data_lib import get_volumes_spectrum
from mapping_data_lib import export_prepare_data

from mapping_mapping_lib import get_link_centroids
from mapping_mapping_lib import get_vertices
from mapping_mapping_lib import get_sublinks
from mapping_mapping_lib import map1to2


if __name__ == '__main__':

    # parameters
    maxlength_sublink = 5     # maximum length sublinks for mapping
    maxdist = 20              # maximum distances between nvp and network for mapping
    maxalpha = 15             # maximum angle between nvp and network for mapping
    map_on_self = True        # network is mapped on itself if true
    
    gemeentenaam = 'Deventer'

    # INPUT
    table_network = 'spectrum.2023_01.d110_toedeelbaar_autonetwerk'
    table_volumes = 'spectrum.2023_01.d171_toedelingsresultaten_auto_node_to_node_per_hoofdmotief'
    path_linktrips = 'C:/Users/tthomas/Goudappel Groep/Goudappel Mobility Twin - Documenten/General/Productie/what if project/preparation data/'+gemeentenaam+'_linktrips.parquet'

    # OUTPUT
    path_links_gpkg = 'C:/Users/tthomas/Goudappel Groep/Goudappel Mobility Twin - Documenten/General/Productie/what if project/preparation data/'+gemeentenaam+'_links.gpkg'
    path_links_gjson = 'C:/Users/tthomas/Goudappel Groep/Goudappel Mobility Twin - Documenten/General/Productie/what if project/preparation data/'+gemeentenaam+'_links.gjson'
    path_trips = 'C:/Users/tthomas/Goudappel Groep/Goudappel Mobility Twin - Documenten/General/Productie/what if project/preparation data/'+gemeentenaam+'_trips.parquet'

    
    # connect to Databricks database
    conn = pyodbc.connect("DSN=Databricks", autocommit=True)
    cur = conn.cursor()

    links, nodes, dirs, lengths, xys = get_links_spectrum(cur,table_network,gemeentenaam)
    links, nodes, lengths, xys = add_opposite_direction(links, nodes,
                                                        dirs, lengths, xys)
    volumes = get_volumes_spectrum(cur,table_network,table_volumes,links,gemeentenaam)

    cur.close()
    conn.close()

    # Get centroids of network that is mapped on sublinks of same network
    clinks,clinkxys,clinkdxys = get_link_centroids(links,lengths,xys)

    # Get vertices of links
    vertlinks,vertlengths,vertxys1,vertdxys = get_vertices(links,xys)

    # Cut Spectrum into Sublinks
    sublinks,sublengths,subxys,subdxys = get_sublinks(vertlinks,vertlengths,vertxys1,vertdxys,maxlength_sublink)


    # Map network on it self in same direction --> find nearest parallel link
    nnb = 20 # Number of Nearest Neightbors
    use_parallel_distance = True    # mapped sublink should lie 'within' target link if True
    map_direction = 'same'    # direction of mapping (same, opposite, both)
    mapped = np.zeros(len(clinks),dtype=int)
    index1_parallel, index2_parallel = map1to2(links,clinks,sublinks,
                            clinkxys,subxys,clinkdxys,subdxys,mapped,
                            maxlength_sublink,maxdist,maxalpha,
                            nnb,map_direction,map_on_self,
                            use_parallel_distance)


    # Map network on it self in opposite direction --> find nearest opposite link
    nnb = 20 # Number of Nearest Neightbors
    use_parallel_distance = True    # mapped sublink should lie 'within' target link if True
    map_direction = 'opposite'    # direction of mapping (same, opposite, both)
    mapped = np.zeros(len(clinks),dtype=int)
    index1_opposite, index2_opposite = map1to2(links,clinks,sublinks,
                            clinkxys,subxys,clinkdxys,subdxys,mapped,
                            maxlength_sublink,maxdist,maxalpha,
                            nnb,map_direction,map_on_self,
                            use_parallel_distance)

    
    # link - parallel link & link - opposite link combinations
    links_parallel, links_opposite = {}, {}
    for i, (link) in enumerate(links):
        links_parallel[link] =  0
        links_opposite[link] =  0

    # mapped in same direction, i.e., angle is about 0 degrees
    for i in range(len(index1_parallel)):
        link = links[clinks[index1_parallel[i]]]
        link_parallel = links[sublinks[index2_parallel[i]]] 
        links_parallel[link] = link_parallel

    # mapped in opposite direction, i.e., angle is about 180 degrees
    for i in range(len(index1_opposite)):
        link = links[clinks[index1_opposite[i]]]
        link_opposite = links[sublinks[index2_opposite[i]]]
        links_opposite[link] = link_opposite


    export_prepare_data(links, nodes, lengths, xys, volumes,
                        links_parallel, links_opposite, path_linktrips,
                        path_links_gpkg, path_links_gjson, path_trips)

    # hlinks = [-238372086, 600381762, 244371113, 600763459, 241372051, 600381190]
    # for link in hlinks:
    #     print(link,links_parallel[link],links_opposite[link])

    
 