# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 13:42:39 2026

@author: tthomas
"""

import numpy as np
from scipy.spatial import cKDTree
from collections import defaultdict


def get_mainlinks(links, nodes, lengths):
    
    # uni-directional mainlinks: sequence of links between deadends/intersections 
    # For two directional links there are 2 mainlinks. One for each direction 

    # inialize
    mainlinks =  -np.ones(len(links),dtype=int)
    mainlengths, mainnodes = [], []

    # connecting links to each node
    nodes_to_links = defaultdict(list)
    startnodes_to_ilinks = defaultdict(list)
    for i, (link,node1,node2) in enumerate(zip(links,nodes[:,0],nodes[:,1])):
        startnodes_to_ilinks[node1].append(i)
        nodes_to_links[node1].append(link)
        nodes_to_links[node2].append(link)

    # number of link geometries per node (positive link number)
    nodes_nlinks = {}
    for node in nodes_to_links:
        nodes_nlinks[node] = len(list(set(np.abs(np.array(nodes_to_links[node])))))

    # list with startnodes
    startnodes = []
    for startnode in startnodes_to_ilinks:
        startnodes.append(startnode)

    # start from each deadend node (with 1 link) or 
    # intersection node (with more than 2 links) and 
    # follow the links until the next deadend/intersection node
    for startnode in startnodes:

        # if intersection or deadend start to find segment
        if nodes_nlinks[startnode] != 2:
            
            # list with start links per startnode
            istartlinks = []
            for ilink in startnodes_to_ilinks[startnode]: 
                istartlinks.append(ilink)

            # Determine segments for each startlink
            for istartlink in istartlinks:

                # first link
                isvalid = True
                ilinks = [istartlink]
                nextnode = nodes[ilinks[-1],1]

                # keep following links, if not at the end of a segment 
                while nodes_nlinks[nextnode] == 2 and isvalid:

                    inextlink = -1
                    for ilink in startnodes_to_ilinks[nextnode]:
                        # select outgoing link not in opposite direction
                        if abs(links[ilinks[-1]]) != abs(links[ilink]):     
                            inextlink = ilink

                    # No next outgoing link found --> switch in direction; error in network
                    if inextlink == -1:
                        isvalid = False
                    else:
                        ilinks.append(inextlink)
                        nextnode = nodes[inextlink,1]
                        
                if isvalid:                    
                    mainlengths.append(0)
                    mainnodes.append([startnode,nextnode])
                    for ilink in ilinks:
                        mainlengths[-1] += lengths[ilink]
                        mainlinks[ilink] = len(mainlengths) - 1
            
    mainnodes, mainlengths = np.array(mainnodes), np.array(mainlengths)
 
    return mainlinks, mainlengths, mainnodes
    

def get_link_centroids(links, lengths, xys):

    # Initialize Output Lists
    clinks, clinkxys, clinkdxys = [], [], []

    # Iterate Over Each Link
    for i in range(len(links)):
       
        # Read Each Link and determine vertices
        hlength = 0
        for j in range(len(xys[i]) - 1):
            
            # Skip Duplicates
            if not (xys[i][j][0] == xys[i][j+1][0] and xys[i][j][1] == xys[i][j+1][1]): 

                # Store all necessary info for segment: link, link part, and coordinates.
                mx = (xys[i][j][0]+xys[i][j+1][0])/2
                my = (xys[i][j][1]+xys[i][j+1][1])/2
                dx = xys[i][j+1][0] - xys[i][j][0]
                dy = xys[i][j+1][1] - xys[i][j][1]
                hlength += np.sqrt(dx**2+dy**2)
                if hlength > lengths[i]/2:
                    clinks.append(i)
                    clinkxys.append([mx,my])
                    clinkdxys.append([dx,dy])
                    break

    # Convert to Arrays
    clinks = np.array(clinks)
    clinkxys, clinkdxys = np.array(clinkxys), np.array(clinkdxys)

    # Normalize directions
    clengths = np.sqrt(clinkdxys[:,0]**2+clinkdxys[:,1]**2)
    clinkdxys[:,0] = clinkdxys[:,0]/clengths[:]
    clinkdxys[:,1] = clinkdxys[:,1]/clengths[:]

    # Return Output
    return clinks, clinkxys, clinkdxys


def get_vertices(links, xys):

    # Split Spectrum links in Vertices        

    # Initialize Output Lists
    vertlinks, vertxys1, vertxys2 = [], [], []

    # Iterate Over Each Link
    for i in range(len(links)):
       
        # Segment the Geometry
        for j in range(len(xys[i]) - 1):
            
            # Skip Duplicates
            if not (xys[i][j][0] == xys[i][j+1][0] and xys[i][j][1] == xys[i][j+1][1]): 

                # Store all necessary info for segment: link, link part, and coordinates.
                vertlinks.append(i)
                vertxys1.append(xys[i][j])
                vertxys2.append(xys[i][j + 1])

    # Convert to Arrays
    vertlinks = np.array(vertlinks)
    vertxys1, vertxys2 = np.array(vertxys1), np.array(vertxys2)

    # Calculate Link Lengths
    vertlengths = np.sqrt((vertxys1[:,0]-vertxys2[:,0])**2+
                          (vertxys1[:,1]-vertxys2[:,1])**2)

    # Calculate direction vectors for vertices 
    vertdxys = np.zeros((len(vertlinks),2))
    vertdxys[:,0] = (vertxys2[:,0] - vertxys1[:,0])/vertlengths[:] # x
    vertdxys[:,1] = (vertxys2[:,1] - vertxys1[:,1])/vertlengths[:] # y

    # Return Output
    return vertlinks, vertlengths, vertxys1, vertdxys


def get_sublinks(vertlinks, vertlengths, vertxys1, vertdxys, maxlength_sublink):
    
    # Subdividing line segments from a network into smaller, 
    # regularly sized sublinks, which is useful for finer spatial matching or sampling.
    
    # Initialize Output Lists
    sublinks, sublengths = [], []
    subxys, subdxys = [], []

    # Iterate Over All Segments
    for i in range(len(vertlinks)):

        # Calculate num of Sublinks
        nsub = int(vertlengths[i]/maxlength_sublink)+1

        # Generate Sublinks
        for j in range(nsub):

            # f is the relative position along the segment, centered in each sublink.
            f = (j+0.5)/nsub
            sublinks.append(vertlinks[i]) # Link ID for each sublink
            sublengths.append(vertlengths[i]/nsub) #	Length of the sublink
            subxys.append(vertxys1[i,:]+f*vertlengths[i]*vertdxys[i,:]) # centroid
            subdxys.append(vertdxys[i]) # direction of sublink

    # Finalize Arrays
    sublinks, sublengths = np.array(sublinks), np.array(sublengths)
    subxys, subdxys = np.array(subxys), np.array(subdxys)

    return sublinks, sublengths, subxys, subdxys


def map1to2(links1, sublinks1, sublinks2, 
            subxys1, subxys2, subdxys1, subdxys2, 
            mapped, maxlength_sublink, maxdist, maxalpha,
            nnb, map_direction, map_on_self, use_parallel_distance):
            
    # Map network 1 to network 2 using k-d tree to find 
    # the closest network links to each NVP sublink. 
    # Also, filter based on distance and directionality    

    # k-d Tree Setup for Nearest Neighbor Search
    ckd_tree = cKDTree(subxys2)
    dist, idx = ckd_tree.query(subxys1,k=nnb)
    
    # Set Minimum Inproduct for Directional Similarity
    mininprod = np.cos(maxalpha*np.pi/180)
    
    # Initialize Arrays for Mapping
    index1, index2 = np.array([],dtype=int), np.array([],dtype=int)
    
    # Iterate Over the Nearest Neighbors for Each NVP Sublink
    for i in range(nnb): 
    
        # Check directional similarity
        if map_direction == 'both':
            inprod = np.abs(subdxys1[:,0]*subdxys2[idx[:,i],0]+subdxys1[:,1]*subdxys2[idx[:,i],1]) 
        elif map_direction == 'opposite':
            inprod = -(subdxys1[:,0]*subdxys2[idx[:,i],0]+subdxys1[:,1]*subdxys2[idx[:,i],1]) 
        else:
            inprod = subdxys1[:,0]*subdxys2[idx[:,i],0]+subdxys1[:,1]*subdxys2[idx[:,i],1] 
    
        # check parallel distance 
        dxys12 = np.zeros((len(idx),2))
        dxys12[:,0] = subxys2[idx[:,i],0] - subxys1[:,0] 
        dxys12[:,1] = subxys2[idx[:,i],1] - subxys1[:,1] 
        dist_parallel = np.abs(subdxys1[:,0]*dxys12[:,0]+subdxys1[:,1]*dxys12[:,1])  
    
        # For links not mapped yet, check if distance is under max, and angle similar, and parallel distance is smaller dan half of maximum sublink length 
        if use_parallel_distance:
            if map_on_self:
                hindex = np.where((mapped==0) & (dist_parallel<=maxlength_sublink/2) &
                                  (dist[:,i]<=maxdist) & (inprod>=mininprod) & 
                                  (links1[sublinks1] != links1[sublinks2[idx[:,i]]]))[0]
            else:    
                hindex = np.where((mapped==0) & (dist_parallel<=maxlength_sublink/2) &
                                  (dist[:,i]<=maxdist) & (inprod>=mininprod))[0]
        else:
            if map_on_self:
                hindex = np.where((mapped==0) & (dist[:,i]<=maxdist) & 
                                  (inprod>=mininprod) & 
                                  (links1[sublinks1] != links1[sublinks2[idx[:,i]]]))[0]
            else:
                hindex = np.where((mapped==0) & (dist[:,i]<=maxdist) &
                                  (inprod>=mininprod))[0]
        
        # Store mapped results
        index1 = np.concatenate((index1,hindex)) # store nvp
        index2 = np.concatenate((index2,idx[hindex,i])) #store matched spectrum

        mapped[hindex] = 1 # mark results mapped --> only one map per NVP link
                
    return index1, index2


def mapped_with_overlap(findex1, findex2, bindex1, bindex2,
                        sublinks1, sublinks2, sublengths1, sublengths2,
                        vertlengths1, linklengths2, fmatch12):

    # check overlap: 1 if more than 50% overlap, otherwise 0 
    check_overlap12 = {}
    nmapped_links12 = defaultdict(lambda: np.zeros(2))
    for i, (i1, i2) in enumerate(zip(findex1, findex2)):
        nmapped_links12[sublinks1[i1],sublinks2[i2]] += np.array([sublengths1[i1],sublengths2[i2]])
        check_overlap12[sublinks1[i1],sublinks2[i2]] = 0
    for i, (i1, i2) in enumerate(zip(bindex1, bindex2)):
        check_overlap12[sublinks1[i1],sublinks2[i2]] = 0
    for ilink1, ilink2 in nmapped_links12:
        if (nmapped_links12[ilink1,ilink2][0] >= fmatch12 * vertlengths1[ilink1] or
            nmapped_links12[ilink1,ilink2][1] >= fmatch12 * linklengths2[ilink2]):
            check_overlap12[ilink1,ilink2] = 1

    # put forward and backward mapped nvp - spectrum sublink indices in dictionaty
    mapindex_dict = {}        
    for i, (i1, i2) in enumerate(zip(findex1, findex2)):
        mapindex_dict[i1,i2] = check_overlap12[sublinks1[i1],sublinks2[i2]]
    for i, (i1, i2) in enumerate(zip(bindex1, bindex2)):
        mapindex_dict[i1,i2] = check_overlap12[sublinks1[i1],sublinks2[i2]]
    
    # put valid mapped nvp - spectrum sublink indices in array
    mapindex = np.array(list(mapindex_dict.keys()))
    mapindex_valid = np.array(list(mapindex_dict.values()))
    valid_mask = mapindex_valid == 1
    mapindex = mapindex[valid_mask]
    
    return mapindex


def add_inbetween_sublinks(mapindex, sublinks2):
    
    # Identify continuous mapped trajectories for each NVP link 
    # by combining NVP and Spectrum link indices    

    # Combine NVP Links, Spectrum Links, and Spectrum Sublink Indices into One Array
    linkcom = np.zeros((len(mapindex),3), dtype=int)
    linkcom[:,0] = mapindex[:,0]
    linkcom[:,1] = sublinks2[mapindex[:,1]]
    linkcom[:,2] = mapindex[:,1]
    
    # Get Unique Combinations of Mapped Pairs
    ulinkcom_index = np.unique(linkcom, axis=0)
    ulinkcom, nlinkcom = np.unique(ulinkcom_index[:,0:2], axis=0, return_counts=True)
    indices = np.concatenate((np.array([0], dtype=int), np.cumsum(nlinkcom)))
    
    # Extract Sorted Mapped Indices; double NVP to same Spectrum sublink are excluded
    index1 = ulinkcom_index[:,0]
    index2 = ulinkcom_index[:,2] 
    
    # Fill Gaps in Mapped Trajectories
    addindex1, addindex2 = [], []
    
    # For each unique NVP and network link combination
    for i in range(len(ulinkcom)):
        
        # Determine the range of network links 
        minindex = ulinkcom_index[indices[i],2]
        maxindex = ulinkcom_index[indices[i+1]-1,2]
        
        # An array initialized to zero, representing gaps in the network link sequence for the given NVP link.
        port = np.zeros(maxindex-minindex+1,dtype=int)
    
        # The indices of the network links in the range between minindex and maxindex for the current NVP link combination.
        hindex = ulinkcom_index[indices[i]:indices[i+1],2] - minindex
        port[hindex] = 1 # indicate Mapped 
        hindex2 = np.where(port == 0)[0] # Find Missing Network Links
    
        # Add the missing network links and their corresponding NVP links to the lists 
        for j in hindex2:
            addindex1.append(ulinkcom[i,0])
            addindex2.append(minindex+j)
    
    # Update networkindex and nvpindex
    index1 = np.concatenate((index1,np.array(addindex1)))
    index2 = np.concatenate((index2,np.array(addindex2)))

    mapindex = np.zeros((len(index1),2),dtype=int)
    mapindex[:,0] = index1
    mapindex[:,1] = index2

    return mapindex


def add_missing_sublinks(mapindex, sublinks2):

    # Adding remaining unmapped sublinks of links that have valid maps    

    #  Mapped Spectrum links; unmapped = 0, mapped = 1 
    port_links = np.zeros(np.max(sublinks2)+1,dtype=int)
    port_links[sublinks2[mapindex[:,1]]] = 1
    
    # Identify Validly Mapped Sublinks
    port_linkindex = port_links[sublinks2]
    
    # Find Unmapped Spectrum Sublinks of links with valid maps
    addindex2 = np.where(port_linkindex==1)[0] # All sublinks of validly mapped links 
    addindex2 = np.array(list(set(addindex2) - set(mapindex[:,1]))) # Only unmapped spectrum sublinks are added
    
    # Initialize the NVP Indices for the Unmapped Sublinks
    addindex1 = -np.ones(len(addindex2),dtype=int)
    
    # Update networkindex and nvpindex
    index1, index2 = mapindex[:,0], mapindex[:,1]
    index1 = np.concatenate((index1,np.array(addindex1)))
    index2 = np.concatenate((index2,np.array(addindex2)))

    mapindex = np.zeros((len(index1),2),dtype=int)
    mapindex[:,0] = index1
    mapindex[:,1] = index2

    return mapindex


def get_mapped_segments(mapindex, sublinks2):

    # This code is designed to identify and segment continuous trajectories 
    # based on the mapped NVP links and network links (sublinks). 
    # It handles cases where segments are broken, 
    # and it attempts to fill gaps where mapping might be incomplete. 
    # The idea is to group these trajectories into coherent segments 
    # based on unique NVP links and their corresponding network link combinations.
    
    # Combine matches of Spectrum and NVP Link indices into One Array
    linkcom = np.zeros((len(mapindex),2), dtype=int)
    linkcom[:,0] = mapindex[:,1]
    linkcom[:,1] = mapindex[:,0]
    
    # Sort by Unique Spectrum sublink indices. 
    # Note that One Spectrum sublink can be matched by multiple NVP sublinks (sublink indices)
    ulinkcom_index = np.unique(linkcom, axis=0)
    ulinkcom, nlinkcom = np.unique(ulinkcom_index[:,0], axis=0, return_counts=True)
    indices = np.concatenate((np.array([0], dtype=int), np.cumsum(nlinkcom)))
    
    # Initialize Spectrum network segments 
    tindex = {}  # start/end index of segments
    nvpmatch = {}  # matched nvp sublink(s) of the corresponding segments
    
    # Segments are determined per Spectrum link number. 
    # Start with the first sublink of the first link 
    ilink2 = sublinks2[ulinkcom[0]] # first link number
    tindex_dummy = [ulinkcom[0]] # start index of the first segment
    nvpmatch_dummy = [list(ulinkcom_index[indices[0]:indices[1],1])] # matched NVP links
    last_index = ulinkcom[0]
    
    # For Each Spectrum/NVP Link, determine segments
    for i in range(1,len(ulinkcom)):
        
        # If sublink belongs to the same link as the previous sublink 
        if sublinks2[ulinkcom[i]] == ilink2:
            # List of NVP matches to this sublink 
            hmatch = list(ulinkcom_index[indices[i]:indices[i+1],1])        
            # If the NVP match has changed a new segment is started 
            if hmatch != nvpmatch_dummy[-1]:
                # start index of new segment = end index previous segment + 1
                tindex_dummy.append(ulinkcom[i])   
                nvpmatch_dummy.append(hmatch)
    
        #  If new link or if at the end of the loop (last sublink), evaluate the previous link
        if sublinks2[ulinkcom[i]] != ilink2 or i == len(ulinkcom)-1:
            
            # iniate indices and nvp matches of the evaluated Spectrum link number
            tindex[ilink2] = []
            nvpmatch[ilink2] = []
    
            # keep first index and add end index of the evaluated link
            tindex_start = tindex_dummy[0]
            tindex_dummy.append(last_index+1)
            
            # Evaluate the link: check unmatched subliks. Take start and end index halfway  
            for j in range(len(nvpmatch_dummy)):
                if nvpmatch_dummy[j] == [-1]:
                    tp = int((tindex_dummy[j]+tindex_dummy[j+1])/2)               
                    tindex_dummy[j] = tp     
                    tindex_dummy[j+1] = tp     
    
            # Evaluate the link: add indices and NVP matched  
            for j in range(len(nvpmatch_dummy)):
                if nvpmatch_dummy[j] != [-1]:
                    tindex[ilink2].append(tindex_dummy[j])
                    nvpmatch[ilink2].append(nvpmatch_dummy[j])

            # set start index and add end index of the evaluated link
            tindex[ilink2][0] = tindex_start
            tindex[ilink2].append(last_index+1)
    
            # Start New segment for New Link
            ilink2 = sublinks2[ulinkcom[i]]
            tindex_dummy = [ulinkcom[i]] 
            nvpmatch_dummy = [list(ulinkcom_index[indices[i]:indices[i+1],1])]
    
        # remember last index: this ones is added as end index of the link
        last_index = ulinkcom[i]

    return tindex, nvpmatch


def get_unmapped_segments(tindex, nvpmatch, sublinks2):

    # gemapte subindices
    port_mapped = np.zeros(len(sublinks2),dtype=int)
    for ilink2 in nvpmatch:
        for i in range(len(nvpmatch[ilink2])):
          port_mapped[tindex[ilink2][i]:tindex[ilink2][i+1]] = 1
    
    # ongemapte subindices
    tindex1_unmapped = {}
    tindex2_unmapped = {}
    hindex = np.where(port_mapped==0)[0]
    tindex1_unmapped[sublinks2[hindex[0]]] = [hindex[0]]
    tindex2_unmapped[sublinks2[hindex[0]]] = []
    for i in range(1,len(hindex)):
        if hindex[i] > hindex[i-1] + 1 or sublinks2[hindex[i]] != sublinks2[hindex[i-1]]:
            tindex2_unmapped[sublinks2[hindex[i-1]]].append(hindex[i-1]+1)
            if sublinks2[hindex[i]] != sublinks2[hindex[i-1]]:
                tindex1_unmapped[sublinks2[hindex[i]]] = [hindex[i]]
                tindex2_unmapped[sublinks2[hindex[i]]] = []
            else:
                tindex1_unmapped[sublinks2[hindex[i]]].append(hindex[i])
    tindex2_unmapped[sublinks2[hindex[-1]]].append(hindex[-1]+1)

    return tindex1_unmapped, tindex2_unmapped
    

def get_trips_per_link(tindex,nvpmatch, links1, linktrips1,
                       links2, linklengths2, sublengths2):
    
    # NVP trips per Spectrum mainlink
    linktrips = {}
    for link2 in links2:
        linktrips[link2] = np.array([])
    
    # Loop through Spectrum links; only use valid mainlinks (!= -1)
    for ilink2 in nvpmatch:

        trips, triplengths = np.array([],dtype=int), np.array([])        

        # Loop through each link with the same NVP links:
        for i in range(len(nvpmatch[ilink2])):                 
            
            linklength = np.sum(sublengths2[tindex[ilink2][i]:tindex[ilink2][i+1]])

            # Loop through the NVP links per segment:
            for ilink1 in nvpmatch[ilink2][i]:
                
                # add trips and segment lengths of the corresponding segment
                addtrips = linktrips1[tuple(links1[ilink1])]
                trips = np.concatenate((trips,np.array(addtrips)))
                triplengths = np.concatenate((triplengths,linklength*np.ones(len(addtrips))))                    
                    
        # unique trips per mainlink; sort trip and lengths by trip id
        xs = np.argsort(trips)
        triplengths = triplengths[xs]
        utrips, ntrips = np.unique(trips, return_counts=True)
 
        # indices at the start of each new unique trip
        dummy = np.array([0])       
        indices = np.concatenate((dummy,np.cumsum(ntrips)),axis=0) 

        # trip lengths: first take cumlative of all trips.  
        cumlengths = np.concatenate((dummy,np.cumsum(triplengths)),axis=0)     
        agglengths = np.take(cumlengths,indices[1:]) - np.take(cumlengths,indices[0:-1]) 

        # select trips with aggregated length larger than half of mainlink length
        valid_mask = agglengths >= 0.5 * linklengths2[ilink2]
        linktrips[links2[ilink2]] = utrips[valid_mask]

    return linktrips
