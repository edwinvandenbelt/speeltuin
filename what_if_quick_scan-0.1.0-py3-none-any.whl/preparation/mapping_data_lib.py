# -*- coding: utf-8 -*-
"""
Created on Thu Mar  5 13:41:50 2026

@author: tthomas
"""

import numpy as np
from collections import defaultdict
import geopandas as gpd
import pandas as pd
from shapely.geometry import LineString
from shapely import wkt


def pyints(x):
    # zet NumPy integers om naar Python int, recursief door lijsten/tuples/dicts
    if isinstance(x, np.integer):
        return int(x)
    if isinstance(x, (list, tuple)):
        return [pyints(v) for v in x]
    if isinstance(x, dict):
        return {k: pyints(v) for k, v in x.items()}
    return x

def get_trips_nvp(cur, table_nvp, gemeentenaam, mode, year):
    
    # Get NVP links; these are already vertices
    sql = f"""
    WITH base AS (
      SELECT
        nodeId,
        next_nodeId,
        segment_id AS pairindex,
        array_distinct(flatten(collect_list(trip_ids))) AS trip_ids_all
      FROM {table_nvp}
      WHERE gemeentenaam = '{gemeentenaam}'
      AND trip_mode = '{mode}'
      AND location_year = {year}
      GROUP BY nodeId, next_nodeId, segment_id
    )
    SELECT
      nodeId,
      next_nodeId,
      pairindex,
      EXPLODE(trip_ids_all) AS trip_id
    FROM base    
    """

    # Read and put in pandas dataframe
    cur.execute(sql)    
    cols = [d[0] for d in cur.description]
    rows = cur.fetchall()    
    df = pd.DataFrame.from_records(rows, columns=cols)

    # Extract data
    links = df[["nodeId", "next_nodeId", "pairindex"]].to_numpy()
    trips = df["trip_id"].to_numpy()

    # trips indices per link
    linktrips = defaultdict(list)
    for i, (node1,node2,pairindex) in enumerate(links):
        linktrips[node1,node2,pairindex].append(trips[i])

    return dict(linktrips), trips


def get_links_nvp(cur, table_nvp, gemeentenaam, mode, year): 

    # Get NVP links; these are already vertices
    sql = f"""
    WITH base AS (
      SELECT
        nodeId        AS nodeId,
        next_nodeId   AS next_nodeId,
        segment_id    AS pairindex,
       First(ST_Transform(line_geom_4326, 28992)) AS g28992
      FROM {table_nvp}
      WHERE gemeentenaam = '{gemeentenaam}'
      AND trip_mode = '{mode}'
      AND location_year = {year}
      GROUP BY nodeId, next_nodeId, segment_id
    )
    SELECT
      nodeId,
      next_nodeId,
      pairindex,
      ST_X(ST_StartPoint(g28992)) AS x1,
      ST_Y(ST_StartPoint(g28992)) AS y1,
      ST_X(ST_EndPoint(g28992))   AS x2,
      ST_Y(ST_EndPoint(g28992))   AS y2,
      ST_Length(g28992)           AS length_m
    FROM base
    """
    
    # Read and put in pandas dataframe
    cur.execute(sql)    
    cols = [d[0] for d in cur.description]
    rows = cur.fetchall()    
    df = pd.DataFrame.from_records(rows, columns=cols)

    # Extract data
    links = df[["nodeId", "next_nodeId", "pairindex"]].to_numpy()
    lengths = df["length_m"].to_numpy()
    xys = np.stack((df[["x1", "y1"]].to_numpy(),
                    df[["x2", "y2"]].to_numpy()),axis=1)
    
    # only links with minimum length of 0.01 meter
    valid_mask = lengths > 0.01
    links = links[valid_mask]
    lengths = lengths[valid_mask]
    xys = xys[valid_mask]
    
    # Calculate direction vectors for vertices 
    dxys = np.zeros((len(links),2))
    dxys[:,0] = (xys[:,1,0] - xys[:,0,0])/lengths[:] # x
    dxys[:,1] = (xys[:,1,1] - xys[:,0,1])/lengths[:] # y

    # Convert to regular dict if needed
    return links, lengths, xys[:,0,:], dxys


def get_links_spectrum(cur, table_network, gemeentenaam):

    # Get Spectrum links
    sql = f"""
    SELECT
      link_id, van_knoop_id, naar_knoop_id,      
      rijrichting_heen, rijrichting_terug,
      ST_AsText(geometry) AS geom_wkt
    FROM {table_network}
    WHERE gemeentenaam = '{gemeentenaam}'
    """

    cur.execute(sql)
    cols = [c[0] for c in cur.description]
    rows = cur.fetchall()
    df = pd.DataFrame.from_records(rows, columns=cols)
    
    geoms = [wkt.loads(g) if g is not None else None for g in df["geom_wkt"]]

    # SPECTRUM NETWORK FOR TESTING
    gdf = gpd.GeoDataFrame(
        df.drop(columns=["geom_wkt"]),
        geometry=geoms,
        crs="EPSG:28992")   # alleen correct als geometry echt RD is
    path= 'C:/Users/tthomas/Goudappel Groep/Goudappel Mobility Twin - Documenten/General/Productie/what if project/uitsnedes/network_'+gemeentenaam+'.gpkg'
    gdf.to_file(path, driver="GPKG")
    
    # Extract data
    links = df["link_id"].to_list()
    nodes = df[["van_knoop_id", "naar_knoop_id"]].values.tolist()
    dirs = df[["rijrichting_heen", "rijrichting_terug"]].values.tolist()
    lengths = [g.length if g is not None else None for g in geoms]

    # ragged coordinates: list per link, each with many vertices
    xys = [list(g.coords) if g is not None else None for g in geoms]

    return links, nodes, dirs, lengths, xys


def add_opposite_direction(links, nodes, dirs, lengths, xys):

    # Iterate Over Each Link
    for i, (dir1, dir2) in enumerate(dirs):
       
        # Determine Directionality
        direction = "B" # B (Bidirectional)
        if not dir2:
            direction = "F"
        if not dir1:
            direction = "T"

        # Reverse Link if Nessessary
        if direction == "T":
            links[i] = -links[i]
            nodes[i] = list(reversed(nodes[i]))
            xys[i] = list(reversed(xys[i]))

        # Add reverse direction for bidirectional links
        if direction == "B":
            links.append(-links[i])
            lengths.append(lengths[i])
            nodes.append(list(reversed(nodes[i])))
            xys.append(list(reversed(xys[i])))

    links, nodes, lengths = np.array(links), np.array(nodes), np.array(lengths)
        
    return links, nodes, lengths, xys


def get_volumes_spectrum(cur, table_network, table_volumes, links, gemeentenaam):

    # attributes volumes
    motivecodes = {'werk':1, 'zakelijk':2, 
                  'basisonderwijs':3, 'middelbaaronderwijs':3,
                  'middelbaarberoepsonderwijs':3, 'hogeronderwijs': 3,
                  'sociaalrecreatief':4, 'winkel':5, 'overig':6}
    periodcodes = {'ochtendspits':1, 'avondspits':2, 'restdag':3}
    nuren = np.array([2,2,10.4])   # aantal uren per period; to calculate 24h numbers

    # Spectrum links and indices
    linkindices = {}
    for i, (link) in enumerate(links):
        linkindices[link] = i

    # Get Spectrum volumes
    sql = f"""
    SELECT {table_network}.link_id,motief,tijd,
           intensiteit_heen_pae_per_uur,
           intensiteit_terug_pae_per_uur
    FROM {table_network}
    JOIN {table_volumes}
    ON {table_network}.link_id = {table_volumes}.link_id
    WHERE {table_network}.gemeentenaam = '{gemeentenaam}'
    """

    # Read and put in pandas dataframe
    cur.execute(sql)
    cols = [c[0] for c in cur.description]
    rows = cur.fetchall()    
    df = pd.DataFrame.from_records(rows, columns=cols)

    # dataframe to numpy arrays
    volumelinks = df['link_id'].to_numpy(dtype=int)
    motives = df['motief'].to_numpy()
    periods = df['tijd'].to_numpy()
    qboth = df[['intensiteit_heen_pae_per_uur','intensiteit_terug_pae_per_uur']].to_numpy(dtype=float)
    
    # Replace None or NaN values with -1
    qboth = np.nan_to_num(qboth, nan=0)

    # first link arrays to intensities in dictionaries
    nmatch_invalid = 0
    volumes = np.zeros((len(links),len(motivecodes)+1,len(periodcodes)+1))
    for i, (link,motive,period,qheen,qterug) in enumerate(zip(volumelinks,motives,periods,qboth[:,0],qboth[:,1])):
        volumelinksin = []
        if qheen > 0:
            volumelinksin.append((link,qheen))
        if qterug > 0:
            volumelinksin.append((-link,qterug))
        for linkin,volumein in volumelinksin:
            try:
                ilink = linkindices[linkin]
                imotive, iperiod = motivecodes[motive],periodcodes[period]
                volumes[ilink,imotive,iperiod] += volumein
            except:
                #print('link and volume direction dont match:',links[ilink])
                nmatch_invalid += 1
    print('wrong matches Spectrum network and volume directions =',nmatch_invalid)
        
    for i in range(len(volumes)):
        # per period, morning rush hour, evening rush our and rest, determine total over motives 
        for j in range(len(periodcodes)):
            volumes[i,0,j+1] = np.sum(volumes[i,1:,j+1])
        # per motive and sum of motives, determine 24h intensity
        for j in range(len(motivecodes)+1):
            volumes[i,j,0] = np.sum(volumes[i,j,1:]*nuren)
        
    return volumes


def get_mapped_results(tindex,nvpmatch,
                       tindex1_unmapped, tindex2_unmapped,
                       linktrips, links1, links2,
                       sublengths2, subxys2, subdxys2):

    # Create subxys1, subxys2 for storing ends of sublinks
    subxys21, subxys22 = np.zeros((len(subxys2),2)), np.zeros((len(subxys2),2))

    # Computes the start and end coordinates for sublinks in spectrum (to not lose shape)
    for i in range(2):
        subxys21[:,i] = subxys2[:,i] - 0.5*sublengths2[:]*subdxys2[:,i]
        subxys22[:,i] = subxys2[:,i] + 0.5*sublengths2[:]*subdxys2[:,i]
    
    # Initialize Data Dictionary
    linkid = 100000 
    linkdata = {'linkid':[], 'link_spectrum':[],
                'link_part':[], 'nvplinks':[], 'geom':[]}
    
    # Loop Through Each Link and NVP Link Combination
    for ilink2 in nvpmatch:
        linkpart = 1
    
        # Store NVP Links and Build Geometry
        for i in range(len(nvpmatch[ilink2])):     
            nvplinks = []
            for ilink1 in nvpmatch[ilink2][i]:
                nvplinks.append(links1[ilink1,:].tolist())
    
            # Store Data in the Dictionary
            linkdata['linkid'].append(linkid)
            linkdata['link_spectrum'].append(links2[ilink2])
            linkdata['link_part'].append(linkpart)
            linkdata['nvplinks'].append(nvplinks)    
            # Create Line Geometry (WKT Format)
            coords = []
            for j in range(tindex[ilink2][i],tindex[ilink2][i+1]):
                coords.append((subxys21[j,0],subxys21[j,1]))	
            coords.append((subxys22[j,0],subxys22[j,1]))	
            linkdata['geom'].append(LineString(coords))
            linkid += 1
            linkpart += 1
        
    # Add non-mapped parts
    for ilink2 in tindex1_unmapped:
        for i in range(len(tindex1_unmapped[ilink2])):
            linkdata['linkid'].append(linkid)
            linkdata['link_spectrum'].append(links2[ilink2])
            linkdata['link_part'].append(0)
            linkdata['nvplinks'].append([])
            # Create Line Geometry (WKT Format)
            coords = []
            for j in range(tindex1_unmapped[ilink2][i],tindex2_unmapped[ilink2][i]):
                coords.append((subxys21[j,0],subxys21[j,1]))	
            coords.append((subxys22[j,0],subxys22[j,1]))	
            linkdata['geom'].append(LineString(coords))
            linkid += 1

    return linkdata


def export_mapped_data(mapped_links, path_mapped_links, path_linktrips, 
                       links, linktrips):
    
    # Export segments    
    df_linktrips = pd.DataFrame({
        "LinkId": links,
        "tripIds": [list(linktrips[l]) for l in links] })

    df_linktrips.to_parquet(path_linktrips, engine="pyarrow",
                            compression="snappy", index=False)

    # Write link results to gpkg file
    gdf_output = gpd.GeoDataFrame(mapped_links, geometry='geom', crs = 'EPSG:28992')
    gdf_output.to_file(path_mapped_links, driver='GPKG')    



def export_prepare_data(links, nodes, lengths, xys, volumes,
                        links_parallel, links_opposite, path_linktrips,
                        path_links_gpkg, path_links_gjson, path_trips):
    
    # output paths
    #path_links = 'C:/Users/tthomas/Goudappel Groep/Goudappel Mobility Twin - Documenten/General/Productie/what if project/amsterdam/npy/amsterdam_links.gjson'

    nodes_arr = np.asarray(nodes)
    
    linkdata = pd.DataFrame({
        'linkId': links,
        'fromNodeId': nodes_arr[:, 0],
        'toNodeId': nodes_arr[:, 1],
        'lengthinMeters': np.rint(lengths).astype(int),
        'parallelLinkIds': [pyints([links_parallel[l]]) if links_parallel[l] != 0 else pyints([]) for l in links],
        'oppositeLinkIds': [pyints([links_opposite[l]]) if links_opposite[l] != 0 else pyints([]) for l in links],
        'volume': volumes[:, 0, 0],
        'geom': [LineString(xy) for xy in xys] })
        
    # Write link results to gpkg file
    gdf_output = gpd.GeoDataFrame(linkdata, geometry='geom', crs = 'EPSG:28992')
    gdf_output.to_file(path_links_gpkg, driver='GPKG')    

    gdf_output = gdf_output.to_crs(epsg=4326)
    gdf_output.to_file(path_links_gjson, driver="GeoJSON")

    # Read trips per link
    df_linktrips = pd.read_parquet(path_linktrips, engine="pyarrow")

    # read links per trip
    trip_to_links = defaultdict(list)
    for link_id, trip_ids in zip(df_linktrips["LinkId"], df_linktrips["tripIds"]):
        for trip_id in trip_ids:
            trip_to_links[trip_id].append(link_id)
    
    # get sorted trips
    trip_ids = sorted(trip_to_links)

    # purposes to be estimated later
    purposes = np.zeros(len(trip_ids),dtype=int)
    df_trips = pd.DataFrame({
        "tripId": trip_ids,
        "linkIds": [trip_to_links[t] for t in trip_ids],
        "purpose": purposes })
    
    df_trips.to_parquet(path_trips, engine="pyarrow",
                  compression="snappy", index=False)




