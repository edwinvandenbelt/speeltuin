# -*- coding: utf-8 -*-
"""
Created on Wed Apr  1 13:53:07 2026

@author: tthomas
"""

import os
import argparse

# READ MODULES
from whatif.nvp_whatif_data_lib import read_nodes 
from whatif.nvp_whatif_data_lib import read_links_volumes 
from whatif.nvp_whatif_data_lib import read_segments 
from whatif.nvp_whatif_data_lib import read_trips

# EXPORT MODULES
from whatif.nvp_whatif_data_lib import export_selected_link

# PREPARE DATA
from whatif.nvp_whatif_lib import prepare_data
from whatif.nvp_whatif_lib import initialize_weights
from whatif.nvp_whatif_lib import initialize_mask
from whatif.nvp_whatif_lib import get_nsegments

# WHAT IF SELECTED FLOW MODULES
from whatif.nvp_whatif_lib import get_selection
from whatif.nvp_whatif_lib import clean_trips
from whatif.nvp_whatif_lib import calibrate_tripvolumes
from whatif.nvp_whatif_lib import get_selected_flows


if __name__ == '__main__':

    # DICTIONARY FOR MOTIVES AND PERIODS    
    motives = {'totaal': 0, 'werk': 1, 'zakelijk': 2, 'onderwijs': 3, 
                   'recreatief': 4, 'winkel': 5, 'overig': 6} 
    periods = {'etmaal': 0, 'ochtendspits': 1, 'avondspits': 2, 'restdag': 3}

    # COMMAND LINE ARGUMENTS
    parser = argparse.ArgumentParser(
        description='What-if analyse: geselecteerde link-flows op het NVP-netwerk.')

    # Verplichte positionele argumenten
    parser.add_argument('input_path',
        help='Map met invoerbestanden (npy/)')
    parser.add_argument('prefix',
        help='Bestandsprefix, bijv. amsterdam')
    parser.add_argument('output_path',
        help='Map voor uitvoerbestanden (wordt aangemaakt indien afwezig)')

    # Optionele model-argumenten
    parser.add_argument('--motive', default='totaal',
        choices=list(motives.keys()),
        help='Reismotief (standaard: totaal)')
    parser.add_argument('--period', default='etmaal',
        choices=list(periods.keys()),
        help='Tijdvak (standaard: etmaal)')
    parser.add_argument('--direction', default='same',
        choices=['same', 'opposite', 'both'],
        help='Rijrichting(en) van de geselecteerde link (standaard: same)')
    parser.add_argument('--selected-links', type=int, nargs='+', default=[600381762],
        metavar='LINK_ID',
        help='Een of meer link-IDs (standaard: 600381762)')
    parser.add_argument('--network', default=None,
        metavar='PATH',
        help='Pad naar netwerk-GeoPackage voor geometrie-export')

    args = parser.parse_args()

    # Pad-variabelen
    input_path  = args.input_path.rstrip('/\\')
    prefix      = args.prefix
    output_path = args.output_path.rstrip('/\\')
    os.makedirs(output_path, exist_ok=True)

    # Model-variabelen (elk link-ID wordt een eigen groep [[id1], [id2], ...])
    motive         = args.motive
    period         = args.period
    direction      = args.direction
    selected_links = [[lid] for lid in args.selected_links]
    path_network   = args.network or f'{input_path}/{prefix}_spectrum.gpkg'

    # DATA INPUT
    path_nodes     = f'{input_path}/npy/{prefix}_nodes.npy'
    path_links     = f'{input_path}/npy/{prefix}_linksegs.npy'
    path_segments  = f'{input_path}/npy/{prefix}_segments.npy'
    path_oppolinks = f'{input_path}/npy/{prefix}_oppolinks.npy'
    path_volumes   = f'{input_path}/npy/{prefix}_volumes.npy'
    path_trips     = f'{input_path}/npy/{prefix}_trips.npy'
    path_trippaths = f'{input_path}/npy/{prefix}_segtrips.npy'

    # EXPORT
    buffersize = 200
    path_sel   = f'{output_path}/{prefix}_sellink.gpkg'

    # READ NUMPY FILES 
    nodes = read_nodes(path_nodes)
    links, links_opposite, volumes = read_links_volumes(path_links, path_volumes, path_oppolinks)
    segments = read_segments(path_segments)
    tripsarr, trippaths = read_trips(path_trips, path_trippaths)


    # PREPARE DATA: FROM LINKS TO AGGREGATED SEGMENTS (FROM INTERSECTION TO INTERSECTION)
    nodexys, selected_segments, opposite_segments, qsegsmodel, qmodel, segments_to_links = prepare_data(
                                    nodes, links, links_opposite, 
                                    segments, volumes, 
                                    selected_links, direction,
                                    motives[motive], periods[period])


    # SELECTEDE SEGMENT FLOWS (AT LEAST ONE SELECTED SEGMENT IN FLOW); 
    nsel_pass = 1       # minimimum number of links being passed 
    tripweights = initialize_weights(tripsarr)
    trippaths2, tripweights2, trippaths12, trippaths21 = get_selection(
                                        trippaths, tripweights, 
                                        selected_segments, nsel_pass)


    # NUMBER OF USED SEGMENTS: TOTAL AND BY SELECTED SEGMENT FLOWS
    nsegment, nsegment2 = get_nsegments(segments, trippaths21)
    

    # REMOVE TOURS: ONLY SELECT TRIPS PASSING SELECTED SEGMENT ONCE WITHOUT PASSING OPPOSITE SEGMENT 
    tripweights2 = clean_trips(selected_segments, opposite_segments,
                               tripweights2, trippaths2, trippaths12)
    

    # UPDATE TRIP WEIGHTS TO GET ONE CONSISTEST SCALING VALUE FOR MODEL VALUES AT SELECTED SEGMENTS
    porttrips2_all = initialize_mask(trippaths2['trip'])
    ratio_model, qsegs_sel, qsegs_sel2 = calibrate_tripvolumes(
                                    selected_segments, qsegsmodel,
                                    trippaths12, trippaths21,
                                    trippaths2, tripweights2, porttrips2_all, 
                                    nsegment, nsegment2)


    # GET SCALED SELECTED LINK FLOWS PER LINK  
    qmodel_sel, qmodel_combsel = get_selected_flows(
                        links, qmodel, ratio_model,
                        selected_segments, qsegs_sel, segments_to_links,
                        trippaths, tripweights, nsegment,
                        trippaths2, tripweights2, nsegment2,
                        trippaths12, trippaths21, porttrips2_all)
        

    # EXPORT RESULTS
    export_selected_link(links, qmodel, qmodel_sel, qmodel_combsel,
                         path_network, path_sel, buffersize)
