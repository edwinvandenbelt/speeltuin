# -*- coding: utf-8 -*-
"""
Created on Tue Mar 17 09:15:58 2026

@author: tthomas
"""

import numpy as np
import networkx as nx
from collections import defaultdict

def initialize_weights(xarr):    

    weights = np.ones(len(xarr))

    return weights


def initialize_mask(xarr):

    mask = np.ones(np.max(xarr)+1,dtype=int)

    return mask


def get_nsegments(segments, trippaths21):

    nsegment = len(segments['node1'])
    nsegment2 = len(trippaths21['segment'])

    return nsegment, nsegment2


def from_links_to_segments(selected_links, links, qmodel_dict, nsegment):

    # key-values: links - segments & segments - links
    qmodel_segs = np.zeros(nsegment)
    nlinks_segs = np.zeros(nsegment)
    links_to_segments = {}
    segments_to_links = defaultdict(list)
    for i in range(len(links['link'])):
        links_to_segments[links['link'][i]] = links['segment'][i]
        segments_to_links[links['segment'][i]].append(links['link'][i])
        qmodel_segs[links['segment'][i]] += qmodel_dict[links['link'][i]]
        nlinks_segs[links['segment'][i]] += 1
 
    # segment model intensity is average link model values per segment 
    qmodel_segs = qmodel_segs / nlinks_segs 
    
    return links_to_segments, segments_to_links, qmodel_segs


def get_opposite_links(selected_links, links_to_segments, 
                       links_opposite, direction):

    selected_segments = []
    opposite_links, opposite_segments = {}, {}
    
    # if more than one selected link: fully use the links selected, including opposite direction for single links
    if len(selected_links) > 1:
        for j in range(len(selected_links)):
            link = selected_links[j][0]
            opposite_links[link] = link
            ii = np.where(links_opposite[:,0]==link)[0]
            if len(ii) > 0:
                opposite_links[link] = links_opposite[ii[0],1]
                opposite_links[links_opposite[ii[0],1]] = link 
                if links_opposite[ii[0],1] == -link:
                    selected_links[j].append(-link)

    # if one selected link: use direction provided by user
    else:
        link = selected_links[0][0]
        opposite_links[link] = link
        ii = np.where(links_opposite[:,0]==link)[0]        
        if len(ii) > 0:
            opposite_links[link] = links_opposite[ii[0],1]
            opposite_links[links_opposite[ii[0],1]] = link 
            # use opposite direction if indicated
            if direction == 'opposite':
                selected_links[0][0] = links_opposite[ii[0],1]
            # add opposite direction if both directions are wanted
            elif direction == 'both':
                selected_links[0].append(links_opposite[ii[0],1])

    # corresponding segments of the selected & opposite links
    for j in range(len(selected_links)):
        selected_segments.append([])
        for link in selected_links[j]:
            segment = links_to_segments[link]
            opposite_segment = links_to_segments[opposite_links[link]]
            selected_segments[j].append(segment)
            opposite_segments[segment] = opposite_segment

    return selected_links, opposite_links, selected_segments, opposite_segments



def prepare_data(nodes, links, links_opposite, segments, volumes, 
                 selected_links, direction, imotive, iperiod):

    # number of segments & initiate trip weights
    nsegment = len(segments['node1'])

    # key-values: nodes - xy-coordinates
    nodexys = {}
    for i in range(len(nodes['node'])):
        nodexys[nodes['node'][i]] = np.array([nodes['x'][i],nodes['y'][i]])

    # model values array 
    qmodel = np.zeros(len(links['link']))
    qmodel[:] = volumes[:,imotive,iperiod]
    qmodel = np.where(qmodel<0,0,qmodel)

    # model value per link key
    qmodel_dict = {}
    for i, (link,q) in enumerate(zip(links['link'],qmodel)):
        qmodel_dict[link] = q

    # key-values: links - segments, segments - links
    links_to_segments, segments_to_links, qsegsmodel = from_links_to_segments(
                                                        selected_links, links, 
                                                        qmodel_dict, nsegment)
    
    # get opposite links of the selected links & and get corresponding segments
    selected_links, opposite_links, selected_segments, opposite_segments = get_opposite_links(
                                    selected_links, links_to_segments, 
                                    links_opposite, direction)

    # flatten selected segments in 1d array
    selected_segments = np.concatenate([np.asarray(x) for x in selected_segments])

    # segment with selected link: use selected link intensity for segment intensity 
    for j in range(len(selected_links)):
        for link in selected_links[j]:
            qsegsmodel[links_to_segments[link]] = qmodel_dict[link]

    return nodexys, selected_segments, opposite_segments, qsegsmodel, qmodel, segments_to_links



def get_segment_intensities(trippaths_in,tripweights_in,porttrips_in,nsegment_in):

    # sort unique segments 
    qsegs_out = np.zeros(nsegment_in)
    xs = np.argsort(trippaths_in['segment'])
    trippaths_in['segment'] = trippaths_in['segment'][xs]
    trippaths_in['trip'] = trippaths_in['trip'][xs]
    usegments, nsegments = np.unique(trippaths_in['segment'], return_counts=True)

    # indices at the start of each new unique segment
    dummy = np.array([0])       
    hindices = np.concatenate((dummy,np.cumsum(nsegments)),axis=0) 

    # Segment intensity = sum all weigthed and selected nvp trips per segment 
    cqsegs = np.concatenate((dummy,np.cumsum(porttrips_in[trippaths_in['trip']]*tripweights_in[trippaths_in['trip']])),axis=0)     
    qsegs_out[usegments] = np.take(cqsegs,hindices[1:len(hindices)]) - np.take(cqsegs,hindices[0:len(hindices)-1]) 

    return qsegs_out 


def get_selection(trippaths_in,tripweights_in,selected_segments_in,nsel_pass):
    
    portsegments = np.zeros(np.max(trippaths_in['segment'])+1,dtype=int)
    porttrips = np.zeros(np.max(trippaths_in['trip'])+1,dtype=int)

    # array with all segments: for selected segments postsegment = 1 
    portsegments[selected_segments_in] = 1

    # Selecteer indices of segment - trip combinations for selected segments
    hindex = np.where(portsegments[trippaths_in['segment']]==1)[0]

    # for each trip id: determine number of selected segments in the route
    # Selecteer all trips with at least a minimum of selected segments in the route
    utrips, ntrips = np.unique(trippaths_in['trip'][hindex], return_counts=True)
    hindex = np.where(ntrips >= nsel_pass)[0]
    porttrips[utrips[hindex]] = 1

    # Selecteer indices of segment - trip combinations for selected trips
    hindex = np.where(porttrips[trippaths_in['trip']]==1)[0]

    # unique segements en indices van indices die over selected segmenten gaan 
    utrippaths = {}
    utrippaths['segment'] = np.unique(trippaths_in['segment'][hindex], return_counts=False)
    utrippaths['trip'] = np.unique(trippaths_in['trip'][hindex], return_counts=False)

    tripweights_out = np.zeros(len(utrips))
    trippaths_in_out = {'segment':{}, 'trip':{}}
    trippaths_out = {'segment':[], 'trip':[]}

    # new indices: link between old and new indices. Only use indices in the selection
    for i in range(len(utrippaths['segment'])):
        trippaths_in_out['segment'][utrippaths['segment'][i]] = i
    for i in range(len(utrippaths['trip'])):
        trippaths_in_out['trip'][utrippaths['trip'][i]] = i
        tripweights_out[i] = tripweights_in[utrippaths['trip'][i]]

    # segment - link combinations: expressed in new indices
    for i in range(len(hindex)):
        trippaths_out['segment'].append(trippaths_in_out['segment'][trippaths_in['segment'][hindex[i]]])
        trippaths_out['trip'].append(trippaths_in_out['trip'][trippaths_in['trip'][hindex[i]]])
    trippaths_out['segment'] = np.array(trippaths_out['segment']) 
    trippaths_out['trip'] = np.array(trippaths_out['trip'])

    return trippaths_out,tripweights_out,trippaths_in_out,utrippaths


def get_link_intensities(links,segments_to_links,qsegs):

    # put segment intensities on corresponding links
    qdict = {}
    qlinks = np.zeros(len(links['link']))
    for i in range(len(links['link'])):
        qdict[links['link'][i]] = 0
    for segment in range(len(qsegs)):
        for link in segments_to_links[segment]:
            qdict[link] = qsegs[segment]
    for i in range(len(links['link'])):
        qlinks[i] = qdict[links['link'][i]]

    return qlinks


def clean_trips(selected_segments, opposite_segments,
                tripweights2, trippaths2, trippaths12):
    
    # per selected segment: check that segments is passed once 
    # without passing opposite segment    
    for selseg in selected_segments:        

        selected_segments2 = []
        selected_segments2.append(trippaths12['segment'][selseg])
        opposite_segment = opposite_segments[selseg]
        if opposite_segment != selseg:
            selected_segments2.append(trippaths12['segment'][opposite_segment])
        
        # if segment and opposite segment is passed more than once -->
        # put weight to 0, effectively excluding the trip
        nsel_pass = 2          
        trippaths3,tripweights3,trippaths23,trippaths32 = get_selection(trippaths2,tripweights2,selected_segments2,nsel_pass)
        tripweights2[trippaths32['trip']] = 0

    return tripweights2


def calibrate_tripvolumes(selected_segments, qsegsmodel,
                          trippaths12, trippaths21,
                          trippaths2, tripweights2, porttrips2_all, 
                          nsegment, nsegment2):

    # selected link flows cleaned data
    qsegs_sel2 = get_segment_intensities(trippaths2,tripweights2,porttrips2_all,nsegment2)
    qsegs_sel = np.zeros(nsegment)    
    qsegs_sel[trippaths21['segment']] = qsegs_sel2[0:len(trippaths21['segment'])]

    # update nvp weights such that ratio between nvp intensities and model intensities
    # are the same at the selected links 
    
    # determine ratio
    mqmodel, mqsegs = 0, 0
    for selseg in selected_segments:
        mqmodel += qsegsmodel[selseg]
        mqsegs += qsegs_sel[selseg]
    ratio_model = mqmodel / mqsegs
    
    # iterate and keep updating weights until ratio is (more or less) constant
    niter = 5       # number of iterations in the calibration
    for iiter in range(niter):
        
        for selseg in selected_segments:
            selseg2 = trippaths12['segment'][selseg]
            ratio_seg = qsegsmodel[selseg]/(ratio_model*qsegs_sel[selseg])
            hindex = np.where(trippaths2['segment'] == selseg2)[0]
            tripweights2[trippaths2['trip'][hindex]] = ratio_seg * tripweights2[trippaths2['trip'][hindex]]
        qsegs_sel2 = get_segment_intensities(trippaths2,tripweights2,porttrips2_all,nsegment2)
        qsegs_sel = np.zeros(nsegment)
        qsegs_sel[trippaths21['segment']] = qsegs_sel2[0:len(trippaths21['segment'])]

        mqmodel, mqsegs = 0, 0
        for selseg in selected_segments:
            mqmodel += qsegsmodel[selseg]
            mqsegs += qsegs_sel[selseg]
        ratio_model = mqmodel / mqsegs

    return ratio_model, qsegs_sel, qsegs_sel2


def get_selected_flows(links, qmodel, ratio_model,
                       selected_segments, qsegs_sel, segments_to_links,
                       trippaths, tripweights, nsegment,
                       trippaths2, tripweights2, nsegment2,
                       trippaths12, trippaths21, porttrips2_all):

    tripweights[trippaths21['trip'][trippaths2['trip']]] = tripweights2[trippaths2['trip']]
    qlinks_sel = get_link_intensities(links,segments_to_links,qsegs_sel)    

    # Correction if scaled NVP selected link flow larger than model flow
    ratio_sel = np.ones(len(links['link']))
    hindex = np.where(qlinks_sel > 0)[0]
    ratio_sel[hindex] = np.where(ratio_model*qlinks_sel[hindex] > qmodel[hindex], 
                                 qmodel[hindex]/(ratio_model*qlinks_sel[hindex]), 1)

    # select trips along all selected segment, i.e., passing n selected links n times (assuming once per link; should be after cleaning!) 
    selected_segments2 = []
    nsel_pass = len(selected_segments)          
    for selseg in selected_segments:
        selected_segments2.append(trippaths12['segment'][selseg])
    trippaths3,tripweights3,trippaths23,trippaths32 = get_selection(trippaths2,tripweights2,selected_segments2,nsel_pass)
    
    # selected segment flow
    porttrips2 = np.zeros(np.max(trippaths2['trip'])+1,dtype=int)
    porttrips2[trippaths32['trip']] = porttrips2_all[trippaths32['trip']]
    qsegs_combsel2 = get_segment_intensities(trippaths2,tripweights2,porttrips2,nsegment2)
    qsegs_combsel = np.zeros(nsegment)
    qsegs_combsel[trippaths21['segment']] = qsegs_combsel2[0:len(trippaths21['segment'])]
    qlinks_combsel = get_link_intensities(links,segments_to_links,qsegs_combsel)    

    # Scale to model values
    qmodel_sel = qlinks_sel * ratio_sel * ratio_model
    qmodel_combsel = qlinks_combsel * ratio_sel * ratio_model        
    
    return qmodel_sel, qmodel_combsel


def get_nodeflows(segments, trippaths21, q2):

    # flows are denoted by the letter q
    # incoming and outgoing selected segment flows per node 
    nodes_q2_in, nodes_q2_out = {}, {}

    # Select all nodes with a volume on the corresponding segment
    for seg2 in range(len(trippaths21['segment'])):
        if q2[seg2] > 0:
            seg = trippaths21['segment'][seg2]
            nodes_q2_in[segments['node1'][seg]] = []
            nodes_q2_in[segments['node2'][seg]] = []
            nodes_q2_out[segments['node1'][seg]] = []    
            nodes_q2_out[segments['node2'][seg]] = []    

    # Add segment and volumes: 
    # incoming for end node (node2), outgoing for start node (node1)
    for seg2 in range(len(trippaths21['segment'])):
        if q2[seg2] > 0:
            seg = trippaths21['segment'][seg2]
            nodes_q2_in[segments['node2'][seg]].append((seg2,q2[seg2]))
            nodes_q2_out[segments['node1'][seg]].append((seg2,q2[seg2]))    

    # use arrays instead of lists
    for node in nodes_q2_in:
        nodes_q2_in[node] = np.array(nodes_q2_in[node])
        nodes_q2_out[node] = np.array(nodes_q2_out[node])    

    return nodes_q2_in, nodes_q2_out


def get_potential_odnodes(nodes_q2_in, nodes_q2_out, 
                          qselseg, fract_change, min_nvp):
    
    # Select potential origin and destination nodes
    onodes_valid, dnodes_valid = {}, {}
    osegs2_out, dsegs2_out = {}, {}
    for node in nodes_q2_in:
        
        # determine maximum incoming and outgoing flows per node
        maxin, maxout = 0, 0
        if len(nodes_q2_in[node]) > 0:
            imaxin = np.argmax(nodes_q2_in[node][:,1])
            maxin = nodes_q2_in[node][imaxin,1]
        if len(nodes_q2_out[node]) > 0:
            imaxout = np.argmax(nodes_q2_out[node][:,1])
            maxout = nodes_q2_out[node][imaxout,1]

        for fract in fract_change:

            # origin: where maximum outgoing flow exceed treshold, but incoming flow not 
            if maxout >= min_nvp and maxout >= fract * qselseg and maxin < fract * qselseg: 
                onodes_valid[node] = True
                osegs2_out[node] = int(nodes_q2_out[node][imaxout,0])

            # destination: where maximum incoming flow exceed treshold, but outgoing flow not 
            if maxin >= min_nvp and maxin >= fract * qselseg and maxout < fract * qselseg: 
                dnodes_valid[node] = True
                dsegs2_out[node] = int(nodes_q2_in[node][imaxin,0])
        
    return onodes_valid, dnodes_valid, osegs2_out, dsegs2_out        


def get_valid_odnodes(odnodes_valid, lengths1, lengths2, 
                      lengths_opposite, opposite_direction):
    
    for odnode in odnodes_valid:
 
        try:
            odcost1 = lengths1[odnode]
        except:
            # no route to destination
            odnodes_valid[odnode] = False

        if odnodes_valid[odnode]:
            try:
                # origin or destination node is actually other way around
                if lengths2[odnode] < odcost1:
                    odnodes_valid[odnode] = False
            except:
                pass

        if odnodes_valid[odnode] and opposite_direction:
            try:
                # node is actually in opposite direction
                if lengths_opposite[odnode] < odcost1:
                    odnodes_valid[odnode] = False
            except:
                pass
        
    return odnodes_valid


def get_array_odnodes(odnodes_valid, selnode, 
                      nodexys, min_radius_odnode):
    
    # Select valid o/d nodes
    odnodes = []
    for odnode in odnodes_valid:
        if odnodes_valid[odnode]:
            odnodes.append(odnode)
    odnodes = np.array(odnodes)

    # get distances to selected segment node
    odxys = np.zeros((len(odnodes),2))
    for i, (odnode) in enumerate(odnodes):
        odxys[i,:] = nodexys[odnode][:]
    dists = np.sqrt((odxys[:,0]-nodexys[selnode][0])**2+(odxys[:,1]-nodexys[selnode][1])**2)

    # include only od nodes beyond a certain distance from the selected link. E.g., of 200 meters
    valid_mask = dists > min_radius_odnode
    odnodes = odnodes[valid_mask]
    dists = dists[valid_mask]

    # sort origin and destionations from far to near. The former are inspected first
    xs = np.argsort(-dists)
    odnodes = odnodes[xs]

    return odnodes


def get_graphs_base(segments, selected_segments, qsegsmodel, nsegment):
    
    # including segments for routes: 1 = include, 0 = selected segment --> don't include
    segport = np.ones(nsegment,dtype=int)            
    segport[selected_segments] = 0
    
    # costs function based on segment volumes
    qmodel_max = np.max(qsegsmodel)
    segweights = np.ones(nsegment)
    nodepairs_segs, nodecosts = {}, {}
    for i in range(nsegment):
        segweights[i] = 1+2*np.log10((1000+qmodel_max)/(1000+qsegsmodel[i]))
        nodecosts[segments['node1'][i],segments['node2'][i]] = 10000000.
    
    # Make Graph
    G = nx.DiGraph()
    Gback = nx.DiGraph()
    for i in range(nsegment):
        if segport[i] == 1:
            node1 = segments['node1'][i]
            node2 = segments['node2'][i]
            segcost = segments['length'][i]*segweights[i]
            if segcost < nodecosts[node1,node2]:
                nodepairs_segs[node1,node2] = i
                nodecosts[node1,node2] = segcost
                G.add_edge(node1,node2,weight=segcost)
                Gback.add_edge(node2,node1,weight=segcost)
    
    return G, Gback, nodepairs_segs, nodecosts


def get_costs_volume_averaging(nodepairs_segs, nodecosts, qsegsmodel,
                               qsegsmodel_dmin, qsegsmodel_dplus,
                               G, Gback, cweight_add):

    for node1,node2 in nodepairs_segs: 

        seg = nodepairs_segs[node1,node2]
        qbase = qsegsmodel[seg]
        qplus = max(0,qsegsmodel_dplus[seg] - qsegsmodel_dmin[seg]) 
        segcost = nodecosts[node1,node2]*(1 + cweight_add * ((100+qplus)/(100+qbase))**2)
        G[node1][node2]['weight'] = segcost
        Gback[node2][node1]['weight'] = segcost

    return G, Gback


def get_ods(G, Gback, segments, nsegment,
            selected_segments, opposite_segments,
            trippaths12, trippaths21,
            trippaths2, tripweights2, porttrips2_all, nsegment2,
            fract_change, min_nvp, nodexys, min_radius_odnode):
                    
    # selected segment flows per selected segment
    nsel_pass = 1
    opaths, dpaths = {}, {}
    onodes, dnodes = {}, {}
    osegs2, dsegs2 = {}, {}
    for j, (selseg) in enumerate(selected_segments):

        # select trips along selected segment 
        selected_segments2 = [trippaths12['segment'][selseg]]
        trippaths3,tripweights3,trippaths23,trippaths32 = get_selection(trippaths2,tripweights2,selected_segments2,nsel_pass)
    
        # selected segment flow
        qsegs_selseg = np.zeros(nsegment)
        porttrips2 = np.zeros(np.max(trippaths2['trip'])+1,dtype=int)
        porttrips2[trippaths32['trip']] = porttrips2_all[trippaths32['trip']]
        qsegs_selseg2 = get_segment_intensities(trippaths2,tripweights2,porttrips2,nsegment2)
        qsegs_selseg[trippaths21['segment']] = qsegs_selseg2[0:len(trippaths21['segment'])]

        
        # incoming and outgoing selected segment flows per node 
        nodes_qsegs2_in, nodes_qsegs2_out = get_nodeflows(segments, trippaths21, qsegs_selseg2)

                # potential od nodes: where selected link flows pass tresholds
        # and corresponding outgoing (in case of origin) and incoming (in case of destination) segment
        onodes_valid, dnodes_valid, osegs2[selseg], dsegs2[selseg] = get_potential_odnodes(
                        nodes_qsegs2_in, nodes_qsegs2_out, 
                        qsegs_selseg[selseg], fract_change, min_nvp)

        # Select valid origins and destinations
        # get routes from first node of selected segment to all origins 
        olengths, opaths[selseg] = nx.single_source_dijkstra(Gback,segments['node1'][selseg])
  
        # get routes from second node of selected segment to all destinations 
        dlengths, dpaths[selseg] = nx.single_source_dijkstra(G,segments['node2'][selseg])
        
        # Do the same for the opposite direction if available
        opposite_direction = False
        olengths2, dlengths2 = {}, {}
        if opposite_segments[selseg] != selseg:
            opposite_direction = True
            olengths2, opaths2 = nx.single_source_dijkstra(Gback,segments['node1'][opposite_segments[selseg]])
            dlengths2, dpaths2 = nx.single_source_dijkstra(G,segments['node2'][opposite_segments[selseg]])


        # Select valid od nodes based on a comparison between paths 
        onodes_valid = get_valid_odnodes(onodes_valid, olengths, dlengths, 
                                         olengths2, opposite_direction)

        dnodes_valid = get_valid_odnodes(dnodes_valid, dlengths, olengths, 
                                         dlengths2, opposite_direction)

        # get array with origin nodes
        selnode = segments['node1'][selseg]
        onodes[selseg] = get_array_odnodes(onodes_valid, selnode,
                                           nodexys, min_radius_odnode)

        # get array with destination nodes
        selnode = segments['node2'][selseg]
        dnodes[selseg] = get_array_odnodes(dnodes_valid, selnode,
                                           nodexys, min_radius_odnode)

    return onodes, dnodes, osegs2, dsegs2, opaths, dpaths


def selected_od_flows(selected_segments, qsegsmodel, qsegs_sel, 
                      ratio_model, nsegment, nsegment2,  
                      trippaths12, trippaths21,
                      trippaths2, tripweights2, porttrips2_all,
                      onodes, dnodes, osegs2, dsegs2, validpaths):

    # Correcion if scaled NVP selected link flow larger than model flow         
    ratio_sel_segs = np.ones(nsegment)
    hindex = np.where(qsegs_sel > 0)[0]
    ratio_sel_segs[hindex] = np.where(ratio_model*qsegs_sel[hindex] > qsegsmodel[hindex], 
                                      qsegsmodel[hindex]/(ratio_model*qsegs_sel[hindex]), 1)
                
    nsel_pass_od = 2       # pass selected segment twice: origin / destination and selected link 

    # remaining flow: start with complete selected link flow
    # each iteration od flows with alternative routes will be excluded
    porttrips2_remain = np.zeros(np.max(trippaths2['trip'])+1,dtype=int)
    porttrips2_remain[:] = porttrips2_all[:]
    
    qsegs_od, qsegsmodel_od, qsegsmodel_od_tot = {}, {}, {}
    for j, (selseg) in enumerate(selected_segments):
    
        qsegsmodel_od_tot[selseg] = 0
        qsegs_od[selseg], qsegsmodel_od[selseg] = {}, {}
        selseg2 = trippaths12['segment'][selseg]
                    
        # origin - destination relations from outside to inside
        # Subtract flow after eacht OD pair is evaluates and flow is put on alternative route 
        for onode in onodes[selseg]:
            
            oseg = trippaths21['segment'][osegs2[selseg][onode]]
            qsegs_od[selseg][onode], qsegsmodel_od[selseg][onode] = {}, {}

            # selected trip ids along selected segment and origin segment 
            selected_segments2 = np.array([selseg2,osegs2[selseg][onode]])
            oporttrips2 = np.zeros(np.max(trippaths2['trip'])+1,dtype=int)
            trippaths3,tripweights3,trippaths23,trippaths32 = get_selection(trippaths2,tripweights2,selected_segments2,nsel_pass_od)
            oporttrips2[trippaths32['trip']] = porttrips2_remain[trippaths32['trip']]
            
            for dnode in dnodes[selseg]:
                
                if validpaths[selseg][onode][dnode]:
                
                    dseg = trippaths21['segment'][dsegs2[selseg][dnode]]
    
                    # selected trip ids along selected segment and destination segment 
                    selected_segments2 = np.array([selseg2,dsegs2[selseg][dnode]])
                    dporttrips2 = np.zeros(np.max(trippaths2['trip'])+1,dtype=int)
                    trippaths3,tripweights3,trippaths23,trippaths32 = get_selection(trippaths2,tripweights2,selected_segments2,nsel_pass_od)
                    dporttrips2[trippaths32['trip']] = porttrips2_remain[trippaths32['trip']]
    
                    # NVP trip intensity for trips from origin to destination
                    odporttrips2 = oporttrips2 * dporttrips2
                    qsegs_od2 = get_segment_intensities(trippaths2,tripweights2,odporttrips2,nsegment2)
                    qsegs_od[selseg][onode][dnode] = qsegs_od2[dsegs2[selseg][dnode]]   
                    
                    # Scale to model distribution
                    ratio_od = ratio_sel_segs[oseg] * ratio_sel_segs[dseg]
                    qsegsmodel_od[selseg][onode][dnode] = ratio_model * ratio_od * qsegs_od[selseg][onode][dnode]
                    qsegsmodel_od_tot[selseg] += qsegsmodel_od[selseg][onode][dnode]
                    
                    # Exclude selected OD trips from next evaluations 
                    hindex = np.where(odporttrips2==1)[0]
                    porttrips2_remain[hindex] = 0

    
        # Scale to model selected segment value
        if qsegsmodel_od_tot[selseg] == 0:
            print(f'Waarschuwing: geen geldige OD-paren gevonden voor segment {selseg}; herverdelingsflow = 0')
            continue
        rescale_factor =  qsegsmodel[selseg] / qsegsmodel_od_tot[selseg]
        delta_factor = 1 - 1 / rescale_factor
        print(rescale_factor,delta_factor)
        for onode in onodes[selseg]:

            oseg = trippaths21['segment'][osegs2[selseg][onode]]

            for dnode in dnodes[selseg]:                    

                if validpaths[selseg][onode][dnode]:
                    dseg = trippaths21['segment'][dsegs2[selseg][dnode]]

                    if ratio_sel_segs[oseg] * ratio_sel_segs[dseg] < 1:
                        delta_qmodel = qsegsmodel_od[selseg][onode][dnode] * delta_factor
                        qsegsmodel_od_tot[selseg] = qsegsmodel_od_tot[selseg] - delta_qmodel
                        qsegsmodel_od[selseg][onode][dnode] = qsegsmodel_od[selseg][onode][dnode] - delta_qmodel

        rescale_factor = (qsegsmodel[selseg] / qsegsmodel_od_tot[selseg]
                          if qsegsmodel_od_tot[selseg] != 0 else 1.0)

        for onode in onodes[selseg]:
            for dnode in dnodes[selseg]:

                if validpaths[selseg][onode][dnode]:
                    qsegsmodel_od[selseg][onode][dnode] = rescale_factor * qsegsmodel_od[selseg][onode][dnode] 

        print(rescale_factor)

    return qsegsmodel_od
 

def adopt_reduction(qsegsmodel_od, measure, 
                    reduction_factor, power_ratio_new_base):

    # ratio intensity new versus base at adapted link(s) given reduction factor capacity / velocity
    ratio_new_base_intensity = 0
    if measure == 'capacity' or measure == 'speed':

        ratio_new_base_intensity = (1 - reduction_factor)**power_ratio_new_base[measure]    
        reduction_factor_intensity = 1 - ratio_new_base_intensity  

        # multiply ODs with reduction factor: this part of OD will be rerouted
        for selseg in qsegsmodel_od:
            for onode in qsegsmodel_od[selseg]:
                for dnode in qsegsmodel_od[selseg][onode]:
                    
                    qsegsmodel_od[selseg][onode][dnode]= reduction_factor_intensity * qsegsmodel_od[selseg][onode][dnode]
                
    return qsegsmodel_od


def get_new_paths(G, onodes, dnodes, selected_segments):

    # get shortest paths between selected ods with roads closed
    newpaths, validpaths = {}, {}
    for j, (selseg) in enumerate(selected_segments):

        newpaths[selseg] = {}
        validpaths[selseg] = {}

        for onode in onodes[selseg]:

            validpaths[selseg][onode] = {}
            newpaths[selseg][onode] = {}
            hlengths, hpaths = nx.single_source_dijkstra(G,onode)

            for dnode in dnodes[selseg]:

                try:
                    newpaths[selseg][onode][dnode] = hpaths[dnode]
                    validpaths[selseg][onode][dnode] = True
                except:
                    validpaths[selseg][onode][dnode] = False

    return newpaths, validpaths


def assign_base(opath, dpath, qin, qdmin, nodepairs_segs, selseg):

    # flows current routes

    # from origin to selected segment (backward: paths are from selected segment)
    for i in range(len(opath)-1,0,-1):
        node1 = opath[i]
        node2 = opath[i-1]
        seg = nodepairs_segs[node1,node2]
        qdmin[seg] += qin

    # selected segment  
    qdmin[selseg] += qin

    # from selected segment to destination (forward path)
    for i in range(len(dpath)-1):
        node1 = dpath[i]
        node2 = dpath[i+1]
        seg = nodepairs_segs[node1,node2]
        qdmin[seg] += qin

    return qdmin            


def assign_new(odpath, qin, qdplus, nodepairs_segs):

    # flows detour routes
    for i in range(len(odpath)-1):
        node1 = odpath[i]
        node2 = odpath[i+1]
        seg = nodepairs_segs[node1,node2]
        qdplus[seg] += qin

    return qdplus


def full_assignment(segments, selected_segments, nsegment,
                    qsegsmodel, qsegsmodel_od,
                    G, Gback, nodepairs_segs, nodecosts,
                    onodes, dnodes, opaths, dpaths,
                    newpaths, validpaths, 
                    cweight_add, nroutes):

    # re-assignment of the selected segment flows 
    qsegsmodel_dmin = np.zeros(nsegment)        # base situation
    qsegsmodel_dplus = np.zeros(nsegment)       # new situation

    for j, (selseg) in enumerate(selected_segments):
    
        for onode in onodes[selseg]:
                
            # select remaining trips going through the destination
            for dnode in dnodes[selseg]:
                
                if validpaths[selseg][onode][dnode]:

                    qsegsmodel_dmin = assign_base(
                                opaths[selseg][onode],
                                dpaths[selseg][dnode],
                                qsegsmodel_od[selseg][onode][dnode],
                                qsegsmodel_dmin,
                                nodepairs_segs, selseg)                        

                    qsegsmodel_dplus = assign_new(
                                newpaths[selseg][onode][dnode],
                                qsegsmodel_od[selseg][onode][dnode],
                                qsegsmodel_dplus, nodepairs_segs)
                                
    # Add other routes to distribute traffic more evenly and deal with capacity constraints
    for i in range(1,nroutes):
    
        w1 =  i/(i+1)
    
        G, Gback = get_costs_volume_averaging(
                            nodepairs_segs, nodecosts, qsegsmodel,
                            qsegsmodel_dmin, qsegsmodel_dplus,
                            G, Gback, cweight_add)

        qmodel_old, qmodel_new = np.zeros(nsegment), np.zeros(nsegment)
        for selseg in qsegsmodel_od:

            olengths, opaths = nx.single_source_dijkstra(Gback,segments['node1'][selseg])
            dlengths, dpaths = nx.single_source_dijkstra(G,segments['node2'][selseg])

            for onode in qsegsmodel_od[selseg]:

                hlengths, hpaths = nx.single_source_dijkstra(G,onode)

                for dnode in qsegsmodel_od[selseg][onode]:

                    if validpaths[selseg][onode][dnode]:

                        qmodel_old = assign_base(
                                    opaths[onode], dpaths[dnode],
                                    qsegsmodel_od[selseg][onode][dnode],
                                    qmodel_old,
                                    nodepairs_segs, selseg)                        

                        qmodel_new = assign_new(hpaths[dnode],
                                    qsegsmodel_od[selseg][onode][dnode],
                                    qmodel_new, nodepairs_segs)

        qsegsmodel_dmin = w1 * qsegsmodel_dmin + (1-w1) * qmodel_old        
        qsegsmodel_dplus = w1 * qsegsmodel_dplus + (1-w1) * qmodel_new        

    print(np.max(qsegsmodel_dmin),np.max(qsegsmodel_dplus))

    return qsegsmodel_dmin, qsegsmodel_dplus


def get_difference_flows(links, qmodel, segments_to_links,
                         qsegsmodel_dmin, qsegsmodel_dplus):

    # flows per links 
    qmodel_dmin = get_link_intensities(links,segments_to_links,qsegsmodel_dmin)
    qmodel_dplus = get_link_intensities(links,segments_to_links,qsegsmodel_dplus)

    # subtracted flow is always smaller or equal than original flow plus rerouting flow
    qmodel_dmin = np.where(qmodel_dmin > qmodel + qmodel_dplus, qmodel + qmodel_dplus, qmodel_dmin)

    return qmodel_dmin, qmodel_dplus
