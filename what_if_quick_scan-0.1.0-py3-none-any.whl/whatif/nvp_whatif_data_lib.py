# -*- coding: utf-8 -*-
"""
Created on Tue Mar 17 09:29:18 2026

@author: tthomas
"""

import numpy as np
import pandas as pd
import geopandas as gpd
import warnings

def _read_geojson(path):
    """gpd.read_file() voor GeoJSON zonder pyogrio-waarschuwingen over integer-kolommen."""
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='Could not parse column', category=UserWarning)
        return gpd.read_file(path)

def read_data_geojson(path_geojson, path_csv):
    """
    Leest het ruwe NVP-export GeoJSON netwerk en de bijbehorende NVP-routes CSV
    en converteert deze naar hetzelfde formaat als de npy-readers, zodat de rest
    van de verwerkingspijplijn ongewijzigd kan worden gebruikt.

    Retourneert: nodes, links, links_opposite, volumes, segments, tripsarr, trippaths
      - nodes          : dict met 'node', 'x', 'y'  (EPSG:28992)
      - links          : dict met 'link', 'segment', 'node1', 'node2', 'length'
                         (elke GeoJSON-link is zijn eigen segment, 1-op-1 koppeling)
      - links_opposite : ndarray (N, 2)  [linkId, reverseLinkId]
      - volumes        : ndarray (n_links, 7 motieven, 4 perioden)
                         motieven : totaal=0, werk=1, zakelijk=2, onderwijs=3,
                                    recreatief=4, winkel=5, overig=6
                         perioden : etmaal=0, ochtendspits=1, avondspits=2, restdag=3
      - segments       : dict met 'node1', 'node2', 'length'  (1-op-1 met links)
      - tripsarr       : ndarray met unieke trip-IDs
      - trippaths      : dict met 'segment' en 'trip'  (segmentindex, tripindex)
    """

    # --- GeoJSON lezen en herprojecteren naar EPSG:28992 (Rijksdriehoek) ---
    gdf = _read_geojson(path_geojson)
    gdf = gdf.to_crs("EPSG:28992")
    n = len(gdf)

    # fromNode / toNode als integer.
    # De meeste waarden zijn numerieke strings ('415350011'), maar sommige GeoJSON-exports
    # bevatten samengestelde node-IDs zoals '422351005_1_in'. Die krijgen een unieke
    # negatieve fallback-ID zodat de graafstructuur intact blijft.
    _special: dict = {}
    def _node_to_int(s):
        try:
            return int(s)
        except (ValueError, TypeError):
            if s not in _special:
                _special[s] = -(len(_special) + 1)
            return _special[s]

    from_nodes = np.array([_node_to_int(s) for s in gdf['fromNode'].values], dtype=np.int64)
    to_nodes   = np.array([_node_to_int(s) for s in gdf['toNode'].values],   dtype=np.int64)

    # --- Knopen (coordinaten uit start/eindpunt van de LinkString-geometrie) ---
    from_xy = np.array([geom.coords[0] for geom in gdf.geometry])
    to_xy   = np.array([geom.coords[-1] for geom in gdf.geometry])
    node_ids_all = np.concatenate([from_nodes, to_nodes])
    xs_all = np.concatenate([from_xy[:, 0], to_xy[:, 0]])
    ys_all = np.concatenate([from_xy[:, 1], to_xy[:, 1]])
    _, idx = np.unique(node_ids_all, return_index=True)
    nodes = {
        'node': node_ids_all[idx],
        'x':    xs_all[idx],
        'y':    ys_all[idx]
    }

    # --- Links (1-op-1: elke GeoJSON-link is zijn eigen segment) ---
    link_ids = gdf['linkId'].values.astype(np.int64)
    link_to_index = {int(lid): i for i, lid in enumerate(link_ids)}
    links = {
        'link':    link_ids,
        'segment': np.arange(n, dtype=np.int64),
        'node1':   from_nodes,
        'node2':   to_nodes,
        'length':  gdf['length'].values.astype(np.float64)
    }

    # --- Links_opposite: (N, 2) array [linkId, reverseLinkId] ---
    opp_rows = [
        [int(row.linkId), int(row.reverseLinkIds[0])]
        for row in gdf.itertuples()
        if len(row.reverseLinkIds) > 0
    ]
    links_opposite = (np.array(opp_rows, dtype=np.int64)
                      if opp_rows else np.empty((0, 2), dtype=np.int64))

    # --- Volumes: shape (n, 7 motieven, 4 perioden) ---
    # GeoJSON flowsPerDaypart-waarden zijn uurintensiteiten per dagdeel.
    # GeoJSON flowsPerMotive bevat etmaalwaarden per motief.
    # 'zakelijk' (index 2) ontbreekt in de GeoJSON; wordt op 0 gelaten.
    volumes = np.zeros((n, 7, 4))
    volumes[:, 0, 0] = gdf['flow24hrs'].values                              # totaal, etmaal
    volumes[:, 0, 1] = [r.get('mrh', 0) for r in gdf['flowsPerDaypart']]   # totaal, ochtendspits
    volumes[:, 0, 2] = [r.get('erh', 0) for r in gdf['flowsPerDaypart']]   # totaal, avondspits
    volumes[:, 0, 3] = [r.get('rest', 0) for r in gdf['flowsPerDaypart']]  # totaal, restdag
    volumes[:, 1, 0] = [r.get('work', 0)         for r in gdf['flowsPerMotive']]  # werk
    volumes[:, 3, 0] = [r.get('education', 0)    for r in gdf['flowsPerMotive']]  # onderwijs
    volumes[:, 4, 0] = [r.get('recreational', 0) for r in gdf['flowsPerMotive']]  # recreatief
    volumes[:, 5, 0] = [r.get('shopping', 0)     for r in gdf['flowsPerMotive']]  # winkel
    volumes[:, 6, 0] = [r.get('unknown', 0)      for r in gdf['flowsPerMotive']]  # overig

    # --- Segmenten (1-op-1 met links) ---
    segments = {
        'node1':  links['node1'].copy(),
        'node2':  links['node2'].copy(),
        'length': links['length'].copy()
    }

    # --- Ritten en ritpaden vanuit CSV ---
    df_csv = pd.read_csv(path_csv)

    # Houd alleen rijen met een bekende linkId (zit in onze GeoJSON)
    df_csv = df_csv[df_csv['linkId'].isin(link_to_index)].copy()

    # Klap uit: één rij per (linkId, tripId) combinatie
    df_csv['nvpTripIds'] = df_csv['nvpTripIds'].astype(str).str.split('|')
    df_expanded = df_csv[['linkId', 'nvpTripIds']].explode('nvpTripIds')
    df_expanded['tripId'] = df_expanded['nvpTripIds'].astype(np.int64)

    # Wijs oplopende indices toe aan unieke trip-IDs
    unique_trip_ids = np.sort(df_expanded['tripId'].unique())
    trip_to_index_map = {int(tid): i for i, tid in enumerate(unique_trip_ids)}
    tripsarr = unique_trip_ids.astype(np.int64)

    # Bouw segmentindex- en tripindex-arrays
    df_expanded['seg_idx']  = df_expanded['linkId'].map(link_to_index).astype(np.int64)
    df_expanded['trip_idx'] = df_expanded['tripId'].map(trip_to_index_map).astype(np.int64)
    trippaths = {
        'segment': df_expanded['seg_idx'].values,
        'trip':    df_expanded['trip_idx'].values
    }

    return nodes, links, links_opposite, volumes, segments, tripsarr, trippaths


def read_nodes(path_nodes):

    # read data
    nodesarr = np.load(path_nodes)
    
    # node attributes
    nodes = {}
    nodes['node'] = nodesarr[:,0]
    nodes['x'] = nodesarr[:,1]
    nodes['y'] = nodesarr[:,2]

    return nodes


def read_links_volumes(path_links, path_volumes, path_oppolinks):
    
    # read data
    linksarr = np.load(path_links)
    links_opposite = np.load(path_oppolinks)    # opposite links
    volumes = np.load(path_volumes)             # model volumes

    # only select links with valid segment (>= 0)
    valid_mask = linksarr[:,1] >= 0
    linksarr = linksarr[valid_mask]
    volumes = volumes[valid_mask]

    # Link attributes
    links = {}
    links['link'] = linksarr[:,0]
    links['segment'] = linksarr[:,1]
    links['node1'] = linksarr[:,2]
    links['node2'] = linksarr[:,3]
    links['length'] = linksarr[:,4]

    return links, links_opposite, volumes


def read_segments(path_segments):

    # read data
    segmentsarr = np.load(path_segments)

    # segment attributes
    segments = {}
    segments['node1'] = segmentsarr[:,0]
    segments['node2'] = segmentsarr[:,1]
    segments['length'] = segmentsarr[:,2]

    return segments


def read_trips(path_trips, path_trippaths):

    # read data
    tripsarr = np.load(path_trips)
    trippathsarr = np.load(path_trippaths)
    
    # segment - trip combinations; weights added from nvp data --> user weights
    trippaths = {}
    trippaths['segment'] = trippathsarr[:,0]
    trippaths['trip'] = trippathsarr[:,1]
    
    return tripsarr, trippaths


def get_geometries(path_network):

    # get geometries (ondersteunt zowel GeoPackage met 'link_id' als GeoJSON met 'linkId')
    geoms = {}
    reader = _read_geojson if str(path_network).lower().endswith('.geojson') else gpd.read_file
    gdf_spectrum = reader(path_network)
    # Zorg dat geometrieën altijd in EPSG:28992 (meters) staan, zodat buffering correct werkt
    if gdf_spectrum.crs is not None and gdf_spectrum.crs.to_epsg() != 28992:
        gdf_spectrum = gdf_spectrum.to_crs("EPSG:28992")
    col = 'link_id' if 'link_id' in gdf_spectrum.columns else 'linkId'
    networklinks = np.array(gdf_spectrum[col])
    geometries = np.array(gdf_spectrum['geometry'])
    for i in range(len(networklinks)):
        geoms[abs(networklinks[i])] = geometries[i]

    return geoms


def export_selected_link(links, qmodel, qmodel_sel, qmodel_combsel,
                         path_network, path_sel, buffersize):
    
    # get geometries        
    geoms = get_geometries(path_network)
    
    vsel = {'link_id':[], 'type':[], 'klasse':[], 'flow':[], 'geometry':[]}
    qs = []
    for i in range(len(links['link'])):
        sign = -1
        if links['link'][i] < 0:
            sign = 1
        if qmodel[i] > 0:
                vsel['link_id'].append(links['link'][i])
                vsel['type'].append('model')
                vsel['klasse'].append(1)
                vsel['flow'].append(qmodel[i])
                vsel['geometry'].append(geoms[abs(links['link'][i])])
                qs.append(sign*qmodel[i])
        if qmodel_sel[i] > 0:
                vsel['link_id'].append(links['link'][i])
                vsel['type'].append('model')
                vsel['klasse'].append(2)
                vsel['flow'].append(qmodel_sel[i])
                vsel['geometry'].append(geoms[abs(links['link'][i])])
                qs.append(sign*qmodel_sel[i])
        if qmodel_combsel[i] > 0:
                vsel['link_id'].append(links['link'][i])
                vsel['type'].append('model')
                vsel['klasse'].append(3)
                vsel['flow'].append(qmodel_combsel[i])
                vsel['geometry'].append(geoms[abs(links['link'][i])])
                qs.append(sign*qmodel_combsel[i])
                
    qs = np.array(qs)
    gdf_sel = gpd.GeoDataFrame(vsel, crs='EPSG:28992')
    gdf_sel['geometry'] = gdf_sel['geometry'].buffer(distance=qs/buffersize,cap_style='flat',single_sided=True)
    if str(path_network).lower().endswith('.geojson'):
        gdf_sel = gdf_sel.to_crs("EPSG:4326")
    #print('schrijf weg')
    gdf_sel.to_file(path_sel, driver="GPKG")    


def export_diff_plot(links, qmodel, qmodel_dmin, qmodel_dplus, 
                     path_network, path_diff, buffersize):

    # get geometries        
    geoms = get_geometries(path_network)
      
    qs = []
    vmodel = {'link_id':[],'type':[],'klasse':[],'qmodel':[],'geometry':[]}    
    for i in range(len(links['link'])):
        sign = -1
        if links['link'][i] < 0:
            sign = 1
        qdiff = qmodel_dplus[i]-qmodel_dmin[i]
        qbeide = min(qmodel[i],qmodel[i]+qdiff)
        if qbeide > 0:
            vmodel['link_id'].append(links['link'][i])
            vmodel['type'].append('model')
            vmodel['klasse'].append(1)
            vmodel['qmodel'].append(qbeide)
            vmodel['geometry'].append(geoms[abs(links['link'][i])])
            qs.append(sign*qbeide)
        # afname
        if qdiff < 0 and qmodel[i] > 0: 
            vmodel['link_id'].append(links['link'][i])
            vmodel['type'].append('model')
            vmodel['klasse'].append(2)
            vmodel['qmodel'].append(qmodel[i])
            vmodel['geometry'].append(geoms[abs(links['link'][i])])
            qs.append(sign*qmodel[i])
        # toename
        if qdiff > 0: 
            vmodel['link_id'].append(links['link'][i])
            vmodel['type'].append('model')
            vmodel['klasse'].append(3)
            vmodel['qmodel'].append(qmodel[i]+qdiff)
            vmodel['geometry'].append(geoms[abs(links['link'][i])])
            qs.append(sign*(qmodel[i]+qdiff))
                
    qs = np.array(qs)
    gdf_model = gpd.GeoDataFrame(vmodel, crs='EPSG:28992')
    gdf_model['geometry'] = gdf_model['geometry'].buffer(distance=qs/buffersize,cap_style='flat',single_sided=True)
    if str(path_network).lower().endswith('.geojson'):
        gdf_model = gdf_model.to_crs("EPSG:4326")
    #print('schrijf weg')
    gdf_model.to_file(path_diff, driver="GPKG")    


def export_network_whatif(links, qmodel, qmodel_dmin, qmodel_dplus,
                          path_geojson, path_out):
    """
    Schrijft een kopie van de invoer-GeoJSON naar path_out, waarbij:
      - 'flow' en 'flow24hrs' worden opgeslagen als 'oldFlow' / 'oldFlow24hrs'
      - 'flow' en 'flow24hrs' worden overschreven met de nieuwe modelflow:
            new_flow = max(0, qmodel[i] + qmodel_dplus[i] - qmodel_dmin[i])
    Links die niet in het model voorkomen behouden hun originele flow-waarde.
    """
    # Bouw mapping: link_id (int) → nieuwe flow
    new_flow_map = {
        int(lid): max(0.0, float(qmodel[i]) + float(qmodel_dplus[i]) - float(qmodel_dmin[i]))
        for i, lid in enumerate(links['link'])
    }

    # Lees de originele GeoJSON (blijft in WGS84)
    gdf = _read_geojson(path_geojson)

    # Sla originele flows op
    gdf['oldFlow']     = gdf['flow']
    gdf['oldFlow24hrs'] = gdf['flow24hrs']

    # Overschrijf met nieuwe flow (onbekende links houden originele waarde)
    new_flows = [
        new_flow_map.get(int(lid), orig)
        for lid, orig in zip(gdf['linkId'], gdf['oldFlow'])
    ]
    gdf['flow']      = new_flows
    gdf['flow24hrs'] = new_flows

    gdf.to_file(path_out, driver="GeoJSON")



