# -*- coding: utf-8 -*-
"""
Created on Mon Jan 20 16:00:11 2025

@author: tthomas
"""

import os
import argparse

# READ MODULES
from whatif.nvp_whatif_data_lib import read_nodes 
from whatif.nvp_whatif_data_lib import read_links_volumes 
from whatif.nvp_whatif_data_lib import read_segments 
from whatif.nvp_whatif_data_lib import read_trips
from whatif.nvp_whatif_data_lib import read_data_geojson

# EXPORT MODULES
from whatif.nvp_whatif_data_lib import export_diff_plot
from whatif.nvp_whatif_data_lib import export_network_whatif

# PREPARE DATA
from whatif.nvp_whatif_lib import prepare_data
from whatif.nvp_whatif_lib import initialize_weights
from whatif.nvp_whatif_lib import initialize_mask
from whatif.nvp_whatif_lib import get_nsegments

# WHAT IF ROAD CLOSURE: OD AND ASSIGMENT MODULES
from whatif.nvp_whatif_lib import get_selection
from whatif.nvp_whatif_lib import clean_trips
from whatif.nvp_whatif_lib import calibrate_tripvolumes
from whatif.nvp_whatif_lib import get_graphs_base
from whatif.nvp_whatif_lib import get_ods
from whatif.nvp_whatif_lib import selected_od_flows
from whatif.nvp_whatif_lib import adopt_reduction
from whatif.nvp_whatif_lib import get_new_paths
from whatif.nvp_whatif_lib import full_assignment
from whatif.nvp_whatif_lib import get_difference_flows    


if __name__ == '__main__':
    # DICTIONARY FOR MOTIVES AND PERIODS    
    motives = {'totaal': 0, 'werk': 1, 'zakelijk': 2, 'onderwijs': 3, 
                   'recreatief': 4, 'winkel': 5, 'overig': 6} 
    periods = {'etmaal': 0, 'ochtendspits': 1, 'avondspits': 2, 'restdag': 3}

    # COMMAND LINE ARGUMENTS
    parser = argparse.ArgumentParser(
        description='What-if analyse: wegafsluitingen op het NVP-netwerk.')

    # Verplichte positionele argumenten
    parser.add_argument('input_path',
        help='Map met invoerbestanden (GeoJSON/CSV of npy/)')
    parser.add_argument('prefix',
        help='Bestandsprefix, bijv. 64e467ce-38fd-4368-944e-573875a73429')
    parser.add_argument('output_path',
        help='Map voor uitvoerbestanden (wordt aangemaakt indien afwezig)')

    # Optionele model-argumenten
    parser.add_argument('--motive', default='totaal',
        choices=list(motives.keys()),
        help='Reismotief (standaard: totaal)')
    parser.add_argument('--period', default='etmaal',
        choices=list(periods.keys()),
        help='Tijdvak (standaard: etmaal)')
    parser.add_argument('--direction', default='both',
        choices=['same', 'opposite', 'both'],
        help='Rijrichting(en) van de geselecteerde link (standaard: both)')
    parser.add_argument('--measure', default='closure',
        choices=['closure', 'capacity', 'speed'],
        help='Type maatregel (standaard: closure)')
    parser.add_argument('--reduction-factor', type=float, default=0.5,
        metavar='FACTOR',
        help='Reductiefactor bij capacity/speed (standaard: 0.5)')
    parser.add_argument('--nroutes', type=int, default=5,
        metavar='N',
        help='Aantal alternatieve routes (standaard: 5)')
    parser.add_argument('--selected-links', type=int, nargs='+', default=[600381762],
        metavar='LINK_ID',
        help='Een of meer link-IDs om af te sluiten (standaard: 600381762)')

    args = parser.parse_args()

    # Pad-variabelen
    input_path  = args.input_path.rstrip('/\\') 
    prefix      = args.prefix
    output_path = args.output_path.rstrip('/\\')
    os.makedirs(output_path, exist_ok=True)

    # Model-variabelen (elk link-ID wordt een eigen groep [[id1], [id2], ...])
    motive           = args.motive
    period           = args.period
    direction        = args.direction
    measure          = args.measure
    reduction_factor = args.reduction_factor
    nroutes          = args.nroutes
    selected_links   = [[lid] for lid in args.selected_links]

    # MODEL COEFFICIENTS
    fract_change = [0.10, 0.25, 0.50, 0.80, 0.95]  # Fractions of selected link flow at which origins and destinations are put
    min_nvp = 10
    min_radius_odnode = 200
    cweight_add = 0.3           # extra weight added per one unit of ratio new flow versus base flow        
    power_ratio_new_base = {}
    power_ratio_new_base['capacity'] = 0.45   
    power_ratio_new_base['speed'] = 0.20

    path_geojson   = f'{input_path}/{prefix}-NETWORK-CAR.geojson'
    path_csv       = f'{input_path}/{prefix}-NVP-ROUTES-CAR.csv'
    path_nodes     = f'{input_path}/npy/{prefix}_nodes.npy'
    path_links     = f'{input_path}/npy/{prefix}_linksegs.npy'
    path_segments  = f'{input_path}/npy/{prefix}_segments.npy'
    path_oppolinks = f'{input_path}/npy/{prefix}_oppolinks.npy'
    path_volumes   = f'{input_path}/npy/{prefix}_volumes.npy'
    path_trips     = f'{input_path}/npy/{prefix}_trips.npy'
    path_trippaths = f'{input_path}/npy/{prefix}_segtrips.npy'

    # EXPORT
    buffersize   = 200            # buffers: buffersize # per 'pixel' 
    path_network = f'{output_path}/{prefix}_spectrum.gpkg'
    path_diff    = f'{output_path}/{prefix}_diffplot.gpkg'
    path_network_out = f'{output_path}/{prefix}-NETWORK-CAR-whatif.geojson'

    # READ DATA: GEBRUIK GEOJSON + CSV ALS BESCHIKBAAR, ANDERS FALLBACK NAAR NUMPY FILES
    if os.path.exists(path_geojson):
        nodes, links, links_opposite, volumes, segments, tripsarr, trippaths = \
            read_data_geojson(path_geojson, path_csv)
        path_network = path_geojson   # geometrie voor export komt uit de GeoJSON
    else:
        nodes = read_nodes(path_nodes)
        links, links_opposite, volumes = read_links_volumes(path_links, path_volumes, path_oppolinks)
        segments = read_segments(path_segments)
        tripsarr, trippaths = read_trips(path_trips, path_trippaths)


    # PREPARE DATA: FROM LINKS TO AGGREGATED SEGMENTS (FROM INTERSECTION TO INTERSECTION)
    nodexys, selected_segments, opposite_segments, qsegsmodel, qmodel, segments_to_links = prepare_data(
                                    nodes, links, links_opposite, 
                                    segments, volumes, 
                                    selected_links, direction,
                                    motives[motive], periods[period])


    # SELECTEDE SEGMENT FLOWS (AT LEAST ONE SELECTED SEGMENT IN FLOW); 
    nsel_pass = 1       # aantal selected links dat gepasseerd moet worden 
    tripweights = initialize_weights(tripsarr)
    trippaths2, tripweights2, trippaths12, trippaths21 = get_selection(
                                        trippaths, tripweights, 
                                        selected_segments, nsel_pass)


    # NUMBER OF USED SEGMENTS: TOTAL AND BY SELECTED SEGMENT FLOWS
    nsegment, nsegment2 = get_nsegments(segments, trippaths21)
    

    # REMOVE TOURS: ONLY SELECT TRIPS PASSING SELECTED SEGMENT ONCE WITHOUT PASSING OPPOSITE SEGMENT 
    tripweights2 = clean_trips(selected_segments, opposite_segments,
                               tripweights2, trippaths2, trippaths12)
    

    # UPDATE TRIP WEIGHTS TO GET ONE CONSISTEST SCALING VALUE FOR MODEL VALUES AT SELECTED SEGMENTS
    porttrips2_all = initialize_mask(trippaths2['trip'])
    ratio_model, qsegs_sel, qsegs_sel2 = calibrate_tripvolumes(
                                    selected_segments, qsegsmodel,
                                    trippaths12, trippaths21,
                                    trippaths2, tripweights2, porttrips2_all, 
                                    nsegment, nsegment2)


    # GRAPHS AND SEGMENT COSTS (BASE SITUATION)
    G, Gback, nodepairs_segs, nodecosts = get_graphs_base(
                	segments, selected_segments, qsegsmodel, nsegment)    


    # OD NODES AND PATHS BETWEEN THEM (BASE SITUATION)
    onodes, dnodes, osegs2, dsegs2, opaths, dpaths = get_ods(
                    G, Gback, segments, nsegment,   
                    selected_segments, opposite_segments,
                    trippaths12, trippaths21,
                    trippaths2, tripweights2, porttrips2_all, nsegment2,
                    fract_change, min_nvp, nodexys, min_radius_odnode)


    # GET PATHS BETWEEN OD-RELATIONS IN NEW SITUATION
    newpaths, validpaths = get_new_paths(G, onodes, dnodes, selected_segments)                


    # GET RESCALED NVP OD FLOWS
    qsegsmodel_od = selected_od_flows(
                            selected_segments, qsegsmodel, qsegs_sel, 
                            ratio_model, nsegment, nsegment2,  
                            trippaths12, trippaths21,
                            trippaths2, tripweights2, porttrips2_all,
                            onodes, dnodes, osegs2, dsegs2, validpaths)

    # AND ADOPT REDUCTION FACTOR IN CASE OF CAPACITY OR SPEED REDUCTION 
    qsegsmodel_od = adopt_reduction(qsegsmodel_od, measure, 
                                    reduction_factor, power_ratio_new_base)


    # FULL ASSIGNMENT: ASSIGN BASE AND NEW ALONG SHORTEST PATHS, 
    # AND DO VOLUME AVERAGING BY ADJUSTING COSTS AND FINDING NEW ROUTES 
    qsegsmodel_dmin, qsegsmodel_dplus = full_assignment(
                        segments, selected_segments, nsegment,
                        qsegsmodel, qsegsmodel_od,
                        G, Gback, nodepairs_segs, nodecosts,
                        onodes, dnodes, opaths, dpaths,
                        newpaths, validpaths, 
                        cweight_add, nroutes)


    # TRANSFORM FROM SEGMENTS TO LINKS 
    qmodel_dmin, qmodel_dplus = get_difference_flows(
                        links, qmodel, segments_to_links,
                        qsegsmodel_dmin, qsegsmodel_dplus)            


    # EXPORT RESULTS
    export_diff_plot(links, qmodel, qmodel_dmin, qmodel_dplus,
                     path_network, path_diff, buffersize)

    if os.path.exists(path_geojson):
        export_network_whatif(links, qmodel, qmodel_dmin, qmodel_dplus,
                              path_geojson, path_network_out)
