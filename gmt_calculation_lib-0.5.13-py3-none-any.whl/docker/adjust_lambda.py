"""Adjust Lambda handler — thin I/O wrapper around adjust_core.

Runs the GMT adjustment pipeline on prepared source files (network, zones,
feedlinks, routes) and writes the adjusted outputs to a destination folder.
Supports S3 URIs, mem:// URIs, and local paths via shared.uri — the pipeline
itself calls shared.uri.read_uri / write_uri internally, so no extra upload
step is needed.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "folder":        "s3://bucket/source-prefix",  // required
        "changes":       "[{...}]",                    // required (inline JSON array)
        "routesPath":    "s3://bucket/routes.parquet", // required
        "outputFolder":  "s3://bucket/output-prefix",  // required
        "newAreaId":     null,   // optional — UUID override for output files
        "minLinkTrips":  1.0,    // optional — minimum flow delta threshold
        "debug":         false,  // optional — log per-link flow report
        "compare":       false   // optional — write bandwidth comparison GeoJSON
    }
}

Response (200 / direct invocation)
------------------------------------
{
    "statusCode":    200,
    "status":        "successful",
    "newAreaId":     str,
    "outputFolder":  str
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    # ------------------------------------------------------------------
    # Direct invocation
    # ------------------------------------------------------------------
    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Adjust invocation start [request_id=%s]", request_id)

    try:
        from adjust.core.adjust_core import run_pipeline

        inputs: dict = event.get("inputs", {})

        folder: str = inputs.get("folder", "") or ""
        if not folder:
            raise ValueError("inputs.folder is required.")

        changes_raw = inputs.get("changes")
        if not changes_raw:
            raise ValueError("inputs.changes is required.")
        # Normalise: if already a list/dict, re-serialise so _load_changes receives a string
        if isinstance(changes_raw, (list, dict)):
            changes_str: str = json.dumps(changes_raw)
        else:
            changes_str = str(changes_raw)

        routes_path: str = inputs.get("routesPath", "") or ""
        if not routes_path:
            raise ValueError("inputs.routesPath is required.")

        output_folder: str = inputs.get("outputFolder", "") or ""
        if not output_folder:
            raise ValueError("inputs.outputFolder is required.")

        new_area_id: str | None = inputs.get("newAreaId") or None
        min_link_trips: float = float(inputs.get("minLinkTrips", 1.0))
        debug: bool = bool(inputs.get("debug", False))
        compare: bool = bool(inputs.get("compare", False))

        logger.info(
            "Running adjust pipeline: folder=%s outputFolder=%s",
            folder,
            output_folder,
        )

        result_area_id: str = run_pipeline(
            folder=folder,
            changes=changes_str,
            output_folder=output_folder,
            routes_path=routes_path,
            new_area_id=new_area_id,
            min_link_trips=min_link_trips,
            debug=debug,
            compare=compare,
        )

        logger.info(
            "Adjust pipeline complete [request_id=%s] newAreaId=%s",
            request_id,
            result_area_id,
        )
        return {
            "statusCode": 200,
            "status": "successful",
            "newAreaId": result_area_id,
            "outputFolder": output_folder,
        }

    except SystemExit as exc:
        # adjust_core calls sys.exit(0) for "no changes" and sys.exit(1) for missing files.
        code = exc.code if exc.code is not None else 0
        if code == 0:
            msg = "No adjustments provided — nothing to do."
        else:
            msg = "Required input file not found. Check that folder and routesPath are correct."
        logger.warning("Pipeline early exit [request_id=%s] code=%s", request_id, code)
        return {"statusCode": 400, "error": "Bad request", "message": msg}
    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id,
            exc,
            traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
