"""Background job executor — ThreadPoolExecutor with max 2 concurrent async jobs.

Each async process (prepare, adjust) is submitted here.  The worker calls the
module's Lambda handler directly in a background thread, then persists the
outcome to S3 via docker.jobs.
"""

from __future__ import annotations

import logging
import threading
import traceback
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from docker import jobs as _jobs

logger = logging.getLogger(__name__)

# Two concurrent async jobs maximum — aligns with the Fargate task sizing.
_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="gmt-worker")


#: Pipeline core loggers whose records should be surfaced as job progress.
#: Listed explicitly (rather than attaching to the root logger) so that
#: unrelated log output — this module's own "Job ... starting/completed"
#: bookkeeping lines, third-party library logs (boto3, the Databricks SQL
#: connector), etc. — never overwrites a job's terminal status/message.
_PIPELINE_LOGGER_NAMES = (
    "prepare.core.prepare_core",
    "prepare.core.traffic_asset_sources",
    "osm.osm_prepare.core.osm_prepare_core",
    "logistiek.logistiek_prepare.core.logistiek_prepare_core",
    "adjust.core.adjust_core",
)


class JobProgressHandler(logging.Handler):
    """Forwards pipeline log records from the active job's thread to ``jobs.update_job``.

    Attached to the pipeline core loggers listed in ``_PIPELINE_LOGGER_NAMES``
    (they don't share a common parent logger, hence the explicit list).
    Routing is keyed by thread id rather than by handler instance, so two
    jobs running concurrently in the thread pool never cross-talk.
    """

    def __init__(self) -> None:
        super().__init__(level=logging.INFO)
        self._job_id_by_thread: dict[int, str] = {}

    def bind(self, job_id: str) -> None:
        self._job_id_by_thread[threading.get_ident()] = job_id

    def unbind(self) -> None:
        self._job_id_by_thread.pop(threading.get_ident(), None)

    def emit(self, record: logging.LogRecord) -> None:
        job_id = self._job_id_by_thread.get(threading.get_ident())
        if job_id is None:
            return  # not a tracked job thread (e.g. CLI/notebook/unrelated code)
        try:
            _jobs.update_job(
                job_id,
                "running",
                message=record.getMessage(),
                progress=getattr(record, "progress_percent", None),
            )
        except Exception:
            logger.exception("JobProgressHandler failed to update job %s", job_id)


_progress_handler = JobProgressHandler()
for _logger_name in _PIPELINE_LOGGER_NAMES:
    logging.getLogger(_logger_name).addHandler(_progress_handler)


def submit_job(
    job_id: str,
    handler: Callable[[dict, Any], dict],
    inputs: dict,
) -> None:
    """Submit an async job to the thread pool.

    Returns immediately; the job runs in a background thread.
    """
    _executor.submit(_run_job, job_id, handler, inputs)


def _run_job(
    job_id: str,
    handler: Callable[[dict, Any], dict],
    inputs: dict,
) -> None:
    """Run a Lambda handler in a background thread and persist the result to S3."""
    logger.info("Job %s: starting.", job_id)
    _jobs.update_job(job_id, "running", message="Job is running.")
    _progress_handler.bind(job_id)
    try:
        result = handler({"inputs": inputs}, None)
        status_code: int = result.get("statusCode", 500)
        if status_code == 200:
            _jobs.update_job(
                job_id,
                "successful",
                message="Job completed successfully.",
                progress=100,
                results=result,
            )
            logger.info("Job %s: completed successfully.", job_id)
        else:
            _jobs.update_job(
                job_id,
                "failed",
                message=result.get("message") or f"Handler returned statusCode {status_code}.",
            )
            logger.warning("Job %s: failed (statusCode=%s).", job_id, status_code)
    except Exception as exc:
        logger.error(
            "Job %s: unhandled exception: %s\n%s",
            job_id,
            exc,
            traceback.format_exc(),
        )
        _jobs.update_job(
            job_id,
            "failed",
            message=f"Unhandled exception: {exc}",
        )
    finally:
        _progress_handler.unbind()
