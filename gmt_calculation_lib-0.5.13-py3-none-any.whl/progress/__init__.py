"""Lightweight stage/progress tracking for long-running pipeline orchestrators.

Pipelines such as ``prepare.core.prepare_core.run_pipeline`` run through a
fixed, ordered sequence of top-level stages.  ``StageTracker`` logs each
stage transition as a single, fixed-format line so external consumers (the
speeltuin analyzer that drives an area extract, a log dashboard, ...) can
parse pipeline progress without scraping free-text prose. The same line also
becomes the job-status ``message`` seen by ``docker.worker.JobProgressHandler``.

Wire format — one line per stage transition, pipe-delimited, always 9 fields::

    GMT-STAGE|<process>|<stage>|<total>|<status>|<name>|<source>|<percent>|<elapsed_s>

    process    short pipeline id, e.g. "prepare" / "osm_prepare" / "logistiek_prepare"
    stage      1-based index of the current stage
    total      total number of stages for this run
    status     "running" | "done" | "skipped" | "failed"
    name       stage name (fixed, from the pipeline's stage-name list)
    source     external source(s) contacted for this stage, or "-" if none;
               for status="skipped" this field holds the skip reason instead
    percent    integer 0-100 overall progress (before the stage for "running",
               after it for "done" / "skipped" / "failed")
    elapsed_s  seconds the stage took, "-" for "running"

Example::

    GMT-STAGE|prepare|7|13|running|Enrich with external assets|Overpass / NDW / BGT|46|-
    GMT-STAGE|prepare|7|13|done|Enrich with external assets|Overpass / NDW / BGT|54|41.2

A consumer splits each log line on ``"GMT-STAGE|"`` and then on ``"|"`` to get
the 9 fields above; no field itself may contain ``|`` (``StageTracker``
replaces any stray ``|`` in free-text fields with ``/`` to keep this contract
unconditionally true).

Only call ``StageTracker.stage()`` / ``skip()`` from the single top-level
orchestration thread of a pipeline run — never from inside parallel per-mode
tracks or concurrent sub-fetchers, since the stage counter is not locked.
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager

#: Log-line prefix identifying a machine-parseable stage-transition line.
STAGE_TAG = "GMT-STAGE"


def _sanitize(field: str) -> str:
    """Guarantees a free-text field never breaks the ``|``-delimited wire format."""
    return field.replace("|", "/").replace("\n", " ")


class StageTracker:
    """Logs a fixed, ordered sequence of top-level pipeline stages."""

    def __init__(self, logger: logging.Logger, stage_names: list[str], *, process: str) -> None:
        self._logger = logger
        self._process = process
        self._total = len(stage_names)
        self._index = 0

    def _emit(
        self,
        status: str,
        name: str,
        *,
        source: str | None,
        percent: int,
        elapsed: float | None,
    ) -> None:
        fields = [
            STAGE_TAG,
            self._process,
            str(self._index),
            str(self._total),
            status,
            _sanitize(name),
            _sanitize(source) if source else "-",
            str(percent),
            f"{elapsed:.1f}" if elapsed is not None else "-",
        ]
        line = "|".join(fields)
        level = logging.WARNING if status == "failed" else logging.INFO
        self._logger.log(level, line, extra={"progress_percent": percent})

    @contextmanager
    def stage(self, name: str, *, source: str | None = None) -> Iterator[None]:
        """Logs the stage start/end. Raises whatever the wrapped body raises."""
        self._index += 1
        start_percent = round((self._index - 1) / self._total * 100)
        self._emit("running", name, source=source, percent=start_percent, elapsed=None)
        start = time.monotonic()
        try:
            yield
        except Exception:
            elapsed = time.monotonic() - start
            done_percent = round(self._index / self._total * 100)
            self._emit("failed", name, source=source, percent=done_percent, elapsed=elapsed)
            raise
        else:
            elapsed = time.monotonic() - start
            done_percent = round(self._index / self._total * 100)
            self._emit("done", name, source=source, percent=done_percent, elapsed=elapsed)

    def skip(self, name: str, reason: str) -> None:
        """Advances the counter for a stage that is not going to run."""
        self._index += 1
        percent = round(self._index / self._total * 100)
        self._emit("skipped", name, source=reason, percent=percent, elapsed=None)


@contextmanager
def heartbeat(logger: logging.Logger, label: str, interval: float = 20.0) -> Iterator[None]:
    """Logs an elapsed-time line every *interval* seconds while the body runs.

    This is a liveness ping for a slow stage, not a stage transition, so it
    stays free-text prose rather than a ``GMT-STAGE`` line.
    """
    stop = threading.Event()
    start = time.monotonic()

    def _beat() -> None:
        while not stop.wait(interval):
            logger.info("%s still running (%.0fs)", label, time.monotonic() - start)

    thread = threading.Thread(target=_beat, name="progress-heartbeat", daemon=True)
    thread.start()
    try:
        yield
    finally:
        stop.set()
        thread.join(timeout=1.0)
