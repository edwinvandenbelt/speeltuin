"""Local runner for logistiek_prepare.

Runs the logistics (Bridgestone) preparation pipeline for CAR mode: Spectrum
zones, the NWB wegvakken of ``logistiek_bridgestone.silver`` with the freight
flow of one day (distinct probe traces), and the OD matrix.

Usage
-----
    python -m logistiek.logistiek_prepare.logistiek_prepare_runner \\
        --bbox 6.15 51.95 6.25 52.00 \\
        --date 2026-08-21 \\
        --output-folder ./out/logistiek \\
        --name "Bridgestone Ede"

Output files
------------
``{area_id}-NETWORK-CAR.parquet``, ``-FEEDLINK-CAR``, ``-ZONE-CAR``,
``-ROUTES-CAR`` in the output folder.

Prerequisites
-------------
* Databricks credentials in the environment or a .env file (``tools/.env``),
  with SELECT rights on ``spectrum`` (zones) and ``logistiek_bridgestone.silver``.
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap  (allows running as a script without install)
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(
        level=logging.INFO, format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s"
    )
    from logistiek.logistiek_network_fetcher.domain.network import DEFAULT_PAE_PER_TRUCK
    from logistiek.logistiek_network_fetcher.domain.sql import DEFAULT_CATALOG, DEFAULT_SCHEMA
    from logistiek.logistiek_prepare.core.logistiek_prepare_core import (
        DEFAULT_MAX_ROUTES,
        DEFAULT_ZONE_CATALOG,
        DEFAULT_ZONE_SCHEMA,
    )

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for logistiek_prepare — runs the logistics (Bridgestone) "
            "preparation pipeline for CAR mode and writes four GeoParquet outputs."
        )
    )
    parser.add_argument(
        "--bbox",
        required=True,
        nargs="+",
        metavar="COORD",
        help=(
            "Bounding box in decimal degrees (WGS-84): MIN_LON MIN_LAT MAX_LON MAX_LAT, "
            "as four values or one comma-separated string.  Must lie within the Netherlands."
        ),
    )
    parser.add_argument(
        "--date",
        required=True,
        metavar="YYYY-MM-DD",
        help="Day of the probe traces used for the 24-hour freight flow.",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="DIR",
        help="Local output directory.  Created automatically when missing.",
    )
    parser.add_argument("--area-id", default=None, help="Area identifier for output filenames.")
    parser.add_argument("--name", default=None, help="Human-readable area name.")
    parser.add_argument(
        "--catalog",
        default=DEFAULT_ZONE_CATALOG,
        help=f"Spectrum catalog for the zones (default: {DEFAULT_ZONE_CATALOG}).",
    )
    parser.add_argument(
        "--schema",
        default=DEFAULT_ZONE_SCHEMA,
        help=f"Spectrum schema for the zones (default: {DEFAULT_ZONE_SCHEMA}).",
    )
    parser.add_argument(
        "--study-fallback",
        default="centroid",
        help="STUDY-zone fallback methodology for the zone_fetcher (default: centroid).",
    )
    parser.add_argument(
        "--exclude-zones", nargs="*", default=None, metavar="ID", help="Zone IDs to exclude."
    )
    parser.add_argument(
        "--logistiek-catalog",
        default=DEFAULT_CATALOG,
        help=f"Catalog of the logistics tables (default: {DEFAULT_CATALOG}).",
    )
    parser.add_argument(
        "--logistiek-schema",
        default=DEFAULT_SCHEMA,
        help=f"Schema of the logistics tables (default: {DEFAULT_SCHEMA}).",
    )
    parser.add_argument(
        "--pae-per-truck",
        type=float,
        default=DEFAULT_PAE_PER_TRUCK,
        help=f"PAE per probe vehicle (default: {DEFAULT_PAE_PER_TRUCK}).",
    )
    parser.add_argument(
        "--expansion-factor",
        type=float,
        default=1.0,
        help="Scale factor from probe sample to all freight traffic (default: 1.0).",
    )
    parser.add_argument(
        "--max-routes",
        type=int,
        default=DEFAULT_MAX_ROUTES,
        help=f"Maximum k-shortest routes per OD pair (default: {DEFAULT_MAX_ROUTES}).",
    )
    parser.add_argument(
        "--road-attributes",
        dest="enrich_road_attributes",
        action=argparse.BooleanOptionalAction,
        default=True,
        help="Add OSM road attributes to the network (default: enabled).",
    )
    parser.add_argument(
        "--elevation",
        dest="add_elevation",
        action="store_true",
        help="Look up terrain elevation per node (Open-Meteo).",
    )
    parser.add_argument("--refresh", action="store_true", help="Re-run even if outputs exist.")
    parser.add_argument("--debug", action="store_true", help="Write intermediate snapshots.")
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    raw_bbox: list[str] = args.bbox
    if len(raw_bbox) == 1:
        raw_bbox = raw_bbox[0].split(",")
    if len(raw_bbox) != 4:
        print(f"error: --bbox expects exactly 4 coordinates, got {len(raw_bbox)}", file=sys.stderr)
        sys.exit(2)
    try:
        min_lon, min_lat, max_lon, max_lat = (float(v) for v in raw_bbox)
    except ValueError as exc:
        print(f"error: --bbox values must be numbers: {exc}", file=sys.stderr)
        sys.exit(2)

    from logistiek.logistiek_prepare.core.logistiek_prepare_core import run_pipeline

    area_id = run_pipeline(
        min_lon,
        min_lat,
        max_lon,
        max_lat,
        Path(args.output_folder).resolve(),
        trace_date=args.date,
        area_id=args.area_id,
        name=args.name,
        zone_catalog=args.catalog,
        zone_schema=args.schema,
        study_fallback=args.study_fallback,
        exclude_zones=args.exclude_zones or None,
        logistiek_catalog=args.logistiek_catalog,
        logistiek_schema=args.logistiek_schema,
        pae_per_truck=args.pae_per_truck,
        expansion_factor=args.expansion_factor,
        max_routes=args.max_routes,
        enrich_road_attributes=args.enrich_road_attributes,
        add_elevation=args.add_elevation,
        refresh=args.refresh,
        debug=args.debug,
    )

    print()
    print(f"Area ID: {area_id}")
    print("Done.")


if __name__ == "__main__":
    main()
