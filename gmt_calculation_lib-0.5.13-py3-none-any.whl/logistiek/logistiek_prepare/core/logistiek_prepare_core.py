"""
logistiek_prepare_core.py — logistics (Bridgestone) preparation pipeline.

Third prepare variant next to Spectrum (``prepare``) and OSM (``osm_prepare``):
the network and its freight flows come from Databricks
``logistiek_bridgestone.silver`` (NWB wegvakken + map-matched probe traces of
one day), the zones from Spectrum as in the regular pipeline.

    zone_fetcher        →  zone_fetcher (Spectrum, unchanged)
    network_fetcher     →  logistiek_network_fetcher
    feedlink_fetcher    →  feedlinks from zone centroids only (Spectrum
                           voedingslinks refer to Spectrum nodes)

Steps:

    [1]  zone_fetcher (Spectrum)
    [2]  logistiek_network_fetcher            one link per NWB wegvak
    [2b] network_cleaner
    [2c] elevation_annotator                  optional
    [3]  bidirectional_splitter               + probe attributes restored
    [4]  parallel_link_finder, network_conflict_finder
    [4b] road_enricher                        OSM road attributes, default on
    [5]  feedlinks (zone centroids) + network_zone_joiner
    [6]  matrix_builder                       synthetic OD (no freight HB)

Skipped on purpose:

    network_simplifier  — merging would keep the flow of the leg with the
                          *smallest* total, so a wegvak with probe traces would
                          lose its flow to a neighbour without traces; one link
                          per wegvak also keeps ``linkId == WVK_ID``.
    HB matrix, nvp_mapper, wkd_fetcher — passenger-car / Spectrum specific.

Flows are PAE per etmaal in motive ``unknown`` with ``flowKind = "freight"``
on the network properties.  Probe attributes per directed link:
``probeTraceCount`` (distinct traces that day) and ``probeMeanSpeedKmh``.
``speed`` is the driven speed (mean probe speed where available, otherwise the
estimate); ``speedLimit`` is the estimated legal limit (road number, raised by
a high probe speed) and drives the capacity.

Final outputs
-------------
    {area_id}-NETWORK-CAR.parquet
    {area_id}-FEEDLINK-CAR.parquet
    {area_id}-ZONE-CAR.parquet
    {area_id}-ROUTES-CAR.parquet

Public API
----------
run_pipeline(min_lon, min_lat, max_lon, max_lat, out_dir, *, trace_date, ...) -> str
"""

from __future__ import annotations

import json
import logging
from pathlib import Path

from gmt_shared.geo import is_bbox_fully_in_netherlands
from gmt_shared.geoparquet import to_geoparquet

from logistiek.logistiek_network_fetcher.domain.network import (
    DEFAULT_PAE_PER_TRUCK,
    FLOW_KIND,
    SOURCE_LABEL,
)
from logistiek.logistiek_network_fetcher.domain.sql import DEFAULT_CATALOG, DEFAULT_SCHEMA
from progress import StageTracker

logger = logging.getLogger(__name__)

DEFAULT_MAX_ROUTES = 2
DEFAULT_ZONE_CATALOG = "spectrum"
DEFAULT_ZONE_SCHEMA = "2024_01"
MODE = "CAR"

#: Below this mean probe speed (km/h) the observation is not used as driven
#: ``speed`` — a 0 km/h link would get an infinite travel time in routing.
MIN_PROBE_SPEED_KMH = 5.0


def restore_probe_attributes(network_fc: dict, raw_fc: dict) -> int:
    """Copy probe attributes from the raw wegvak links onto the directed links.

    The bidirectional_splitter rebuilds the link properties, so
    ``probeTraceCount`` / ``probeMeanSpeedKmh`` (and road number / type) are
    put back via ``|linkId| == WVK_ID``.  A one-way wegvak gets the full trace
    count on its single direction; a two-way wegvak half per direction, matching
    the 50/50 flow split.

    ``speed`` is the *driven* speed: it becomes the mean probe speed when that
    is at least :data:`MIN_PROBE_SPEED_KMH`; otherwise it keeps the estimated
    limit.  ``speedLimit`` (and the capacity derived from it) stays the
    estimated legal limit.  Returns the number of links updated.
    """
    raw_by_id: dict[int, dict] = {}
    for feat in raw_fc.get("features") or []:
        props = feat.get("properties") or {}
        if props.get("linkId") is not None:
            raw_by_id[abs(int(props["linkId"]))] = props

    updated = 0
    for feat in network_fc.get("features") or []:
        props = feat.setdefault("properties", {})
        link_id = props.get("linkId")
        if isinstance(link_id, (int, float)):
            key = abs(int(link_id))
        elif isinstance(link_id, str) and link_id.lstrip("-").isdigit():
            key = int(link_id.lstrip("-"))
        else:
            continue
        raw = raw_by_id.get(key)
        if raw is None:
            continue
        n_open = int(bool(raw.get("rijrichting_heen"))) + int(bool(raw.get("rijrichting_terug")))
        count = float(raw.get("probeTraceCount") or 0)
        props["probeTraceCount"] = count / n_open if n_open else count
        mean_speed = raw.get("probeMeanSpeedKmh")
        props["probeMeanSpeedKmh"] = mean_speed
        if mean_speed is not None and mean_speed >= MIN_PROBE_SPEED_KMH:
            props["speed"] = float(mean_speed)
        props["roadNumber"] = raw.get("roadNumber")
        props["roadType"] = raw.get("roadType")
        updated += 1
    return updated


def _fetch_spectrum_zones(
    bbox: list[float],
    area_id: str,
    *,
    catalog: str,
    schema: str,
    study_fallback: str,
    exclude_zones: list[str] | None,
) -> dict:
    """Spectrum zones for *bbox* (same as ``prepare`` with ``zone_source='spectrum'``)."""
    from gmt_shared.databricks_sql import connect_from_env
    from gmt_zone_core.zone_fetcher.domain.sql import bbox_to_polygon_json, build_fetch_zones_sql
    from gmt_zone_core.zone_fetcher.domain.zone import rows_to_feature_collection

    sql = build_fetch_zones_sql(catalog, schema, study_fallback=study_fallback)
    with connect_from_env() as conn, conn.cursor() as cur:
        cur.execute(sql, (bbox_to_polygon_json(bbox),))
        cols = [d[0] for d in cur.description]
        rows = cur.fetchall()
    zones_fc: dict = rows_to_feature_collection(
        rows,
        cols,
        area_id,
        bbox,
        exclude_zone_ids=set(exclude_zones) if exclude_zones else None,
    )
    return zones_fc


def run_pipeline(
    min_lon: float,
    min_lat: float,
    max_lon: float,
    max_lat: float,
    out_dir: Path,
    *,
    trace_date: str,
    area_id: str | None = None,
    name: str | None = None,
    zone_catalog: str = DEFAULT_ZONE_CATALOG,
    zone_schema: str = DEFAULT_ZONE_SCHEMA,
    study_fallback: str = "centroid",
    exclude_zones: list[str] | None = None,
    logistiek_catalog: str = DEFAULT_CATALOG,
    logistiek_schema: str = DEFAULT_SCHEMA,
    pae_per_truck: float = DEFAULT_PAE_PER_TRUCK,
    expansion_factor: float = 1.0,
    max_routes: int = DEFAULT_MAX_ROUTES,
    enrich_road_attributes: bool = True,
    add_elevation: bool = False,
    refresh: bool = False,
    debug: bool = False,
) -> str:
    """Run the logistics preparation pipeline (CAR mode, Netherlands only).

    Parameters
    ----------
    min_lon, min_lat, max_lon, max_lat:
        Bounding box in decimal degrees (WGS-84); must lie within the
        Netherlands.
    out_dir:
        Output directory; created automatically when it does not exist.
    trace_date:
        Day of the probe traces (``YYYY-MM-DD``) that defines the 24-hour flow.
    area_id:
        Optional UUID override (otherwise discovered from *out_dir* or new).
    name:
        Human-readable label stored in every output's properties.
    zone_catalog, zone_schema:
        Spectrum catalog / schema for the zones.
    study_fallback, exclude_zones:
        Passed to the Spectrum zone_fetcher, as in ``prepare``.
    logistiek_catalog, logistiek_schema:
        Location of ``matched_probe_traces`` / ``nwb_road_segments``.
    pae_per_truck, expansion_factor:
        Conversion from distinct probe traces to PAE / etmaal.
    max_routes:
        Maximum k-shortest routes per OD pair (matrix_builder).
    enrich_road_attributes:
        Add OSM road attributes (surface, sidewalks, cycle lanes, …) to the
        network.  Best-effort.  Default: ``True``.
    add_elevation:
        Look up terrain elevation per node (Open-Meteo).  Best-effort.
    refresh:
        Re-run even when all final outputs already exist.
    debug:
        Write intermediate GeoJSON snapshots (``STEP_{n}_…``) to *out_dir*.

    Returns
    -------
    str
        The area UUID used for this run.
    """
    from logistiek.logistiek_network_fetcher.core.logistiek_network_fetcher_core import (
        parse_trace_date,
    )
    from prepare.core.prepare_core import (
        ARTIFACTS,
        _apply_road_enricher,
        _dedup_net_features,
        _dedup_zone_features,
        _discover_or_create_area_id,
        _extract_area_polygon_json,
        _snapshot,
    )

    bbox = [min_lon, min_lat, max_lon, max_lat]
    if not is_bbox_fully_in_netherlands(bbox):
        raise ValueError(
            "The logistics network (logistiek_bridgestone) only covers the Netherlands; "
            f"bbox {bbox} is not fully within the Netherlands."
        )
    parse_trace_date(trace_date)  # validate early, before any Databricks call

    out_dir.mkdir(parents=True, exist_ok=True)
    area_id = _discover_or_create_area_id(out_dir, area_id)

    network_path = out_dir / f"{area_id}-NETWORK-{MODE}.parquet"
    feedlinks_path = out_dir / f"{area_id}-FEEDLINK-{MODE}.parquet"
    zone_path = out_dir / f"{area_id}-ZONE-{MODE}.parquet"
    routes_path = out_dir / f"{area_id}-ROUTES-{MODE}.parquet"

    logger.info(
        "Logistiek prepare pipeline starting: bbox=%s mode=%s trace_date=%s source=%s.%s "
        "area_id=%s out=%s refresh=%s debug=%s",
        bbox,
        MODE,
        trace_date,
        logistiek_catalog,
        logistiek_schema,
        area_id,
        out_dir,
        refresh,
        debug,
    )

    stage_names = [
        "Resolve zones",
        "Build network from probe traces",
        "Clean network",
        "Annotate elevation",
        "Split bidirectional links",
        "Find parallel links & conflicts",
        "Enrich road attributes",
        "Join zones & feedlinks",
        "Build OD matrix & routes",
        "Write outputs",
    ]
    tracker = StageTracker(logger, stage_names, process="logistiek_prepare")

    if not refresh and all(
        p.exists() for p in (network_path, feedlinks_path, zone_path, routes_path)
    ):
        logger.info("All final outputs already exist — skipping pipeline (use refresh to force).")
        return area_id

    with tracker.stage("Resolve zones", source="Databricks SQL (Spectrum)"):
        zones_fc = _fetch_spectrum_zones(
            bbox,
            area_id,
            catalog=zone_catalog,
            schema=zone_schema,
            study_fallback=study_fallback,
            exclude_zones=exclude_zones,
        )
        zones_fc.setdefault("properties", {}).update({"name": name, "source": "Spectrum"})
        logger.info("%d zone features fetched", len(zones_fc.get("features") or []))
        if debug:
            _snapshot(1, area_id, out_dir, ZONES=zones_fc)

        area_polygon_json = _extract_area_polygon_json(zones_fc)
        if area_polygon_json == "null":
            from gmt_zone_core.zone_fetcher.domain.sql import bbox_to_polygon_json

            area_polygon_json = bbox_to_polygon_json(bbox)
            logger.warning("No zone geometries found — using input bbox as area polygon.")

    with tracker.stage(
        "Build network from probe traces",
        source=f"Databricks SQL ({logistiek_catalog}.{logistiek_schema}, trace_date={trace_date})",
    ):
        from gmt_shared.databricks_sql import connect_from_env

        from logistiek.logistiek_network_fetcher.core.logistiek_network_fetcher_core import (
            fetch_logistiek_network,
        )

        with connect_from_env() as conn, conn.cursor() as cur:
            raw_fc = fetch_logistiek_network(
                cur,
                area_polygon_json,
                trace_date,
                catalog=logistiek_catalog,
                schema=logistiek_schema,
                pae_per_truck=pae_per_truck,
                expansion_factor=expansion_factor,
            )
        raw_features = raw_fc.get("features") or []
        with_traces = sum(1 for f in raw_features if f["properties"]["probeTraceCount"] > 0)
        logger.info(
            "%d road segments fetched, %d with probe traces", len(raw_features), with_traces
        )
        if not raw_features:
            raise ValueError(
                f"No logistics wegvakken found for bbox {bbox} in "
                f"{logistiek_catalog}.{logistiek_schema}."
            )
        if debug:
            _snapshot(2, area_id, out_dir, NETWORK_RAW=raw_fc)

    with tracker.stage("Clean network"):
        from gmt_network_core.network_cleaner.core.network_cleaner_core import clean_network

        cleaned_fc, clean_stats = clean_network(raw_fc)
        logger.info(
            "%s links kept, %s removed",
            clean_stats.get("kept", "?"),
            clean_stats.get("removed", "?"),
        )

    if add_elevation:
        with tracker.stage("Annotate elevation", source="Open-Meteo"):
            try:
                from gmt_network_enrichment.elevation_annotator.core import (
                    elevation_annotator_core as _elevation_annotator_core,
                )

                cleaned_fc, elev_stats = _elevation_annotator_core.add_elevation(cleaned_fc)
                logger.info(
                    "Elevation set on %d/%d links", elev_stats["updated"], elev_stats["links"]
                )
            except Exception as exc:
                logger.warning("Elevation annotation failed (%s); continuing without it.", exc)
    else:
        tracker.skip("Annotate elevation", "add_elevation=False")

    with tracker.stage("Split bidirectional links"):
        from gmt_network_core.bidirectional_splitter.core.bidirectional_splitter_core import (
            post_process_features,
        )
        from gmt_network_core.bidirectional_splitter.domain.network import (
            DIRECTED_LINK_PROPERTIES,
        )
        from gmt_shared.region import determine_region

        region: str | None = None
        holiday_path = ARTIFACTS / "indices" / "holiday_regions.geojson"
        if holiday_path.exists():
            hfc = json.loads(holiday_path.read_text(encoding="utf-8"))
            region = determine_region(bbox, hfc.get("features") or [])

        common_meta: dict = {
            "bbox": bbox,
            "region": region,
            "area_id": area_id,
            "name": name,
            "modes": [MODE],
            "modeLabel": MODE,
            "source": SOURCE_LABEL,
        }
        network_fc: dict = {
            "type": "FeatureCollection",
            "features": post_process_features(cleaned_fc.get("features") or []),
            "properties": {
                **common_meta,
                "flowKind": FLOW_KIND,
                "traceDate": raw_fc["properties"].get("traceDate"),
                "paePerTruck": pae_per_truck,
                "expansionFactor": expansion_factor,
            },
        }
        restored = restore_probe_attributes(network_fc, raw_fc)
        logger.info(
            "%d directed links after split (%d with probe attributes)",
            len(network_fc["features"]),
            restored,
        )
        if debug:
            _snapshot(3, area_id, out_dir, NETWORK_SPLIT=network_fc)

    with tracker.stage("Find parallel links & conflicts"):
        from gmt_network_core.network_conflict_finder.core.network_conflict_finder_core import (
            enrich_network_with_conflicts,
        )
        from gmt_network_core.parallel_link_finder.core.parallel_link_finder_core import (
            find_parallel_links,
        )

        network_fc, parallel_stats = find_parallel_links(network_fc)
        logger.info(
            "parallel_link_finder: enriched=%s skipped=%s",
            parallel_stats.get("features_enriched", "?"),
            parallel_stats.get("features_skipped", "?"),
        )
        network_fc = enrich_network_with_conflicts(network_fc)

    if enrich_road_attributes:
        with tracker.stage("Enrich road attributes", source="local OSM extract"):
            network_fc = _apply_road_enricher(network_fc)
    else:
        tracker.skip("Enrich road attributes", "enrich_road_attributes=False")

    network_fc["properties"]["fields"] = [
        *DIRECTED_LINK_PROPERTIES,
        "probeTraceCount",
        "probeMeanSpeedKmh",
        "roadNumber",
        "roadType",
    ]
    if debug:
        _snapshot(4, area_id, out_dir, NETWORK=network_fc)

    with tracker.stage("Join zones & feedlinks"):
        from gmt_network_core.feedlink_fetcher.core.feedlink_fetcher_core import (
            build_feedlinks,
            parse_network_geojson,
        )
        from gmt_network_core.network_zone_joiner.core.network_zone_joiner_core import (
            join_zones_to_network,
        )

        node_positions, all_node_ids = parse_network_geojson(cleaned_fc)
        fl_fc = build_feedlinks(zones_fc, node_positions, all_node_ids, [], MODE)
        feedlinks_fc: dict = {
            "type": "FeatureCollection",
            "features": fl_fc.get("features") or [],
            "properties": {"area_id": area_id},
        }
        logger.info("%d feedlinks built from zone centroids", len(feedlinks_fc["features"]))

        results = join_zones_to_network(
            zones_fc,
            network_fc,
            zone_classes={"AREA"},
            feedlinks_fc=feedlinks_fc,
            adjust_boundary_demands=False,
        )
        net_feats: list[dict] = []
        zone_feats: list[dict] = []
        fl_feats: list[dict] = []
        for _zone_feat, clipped_net_fc, zone_fc_result, ext_fl_fc in results:
            net_feats.extend(clipped_net_fc.get("features") or [])
            zone_feats.extend(zone_fc_result.get("features") or [])
            fl_feats.extend(ext_fl_fc.get("features") or [])

        network_fc = {**network_fc, "features": _dedup_net_features(net_feats)}
        zone_fc = {
            "type": "FeatureCollection",
            "features": _dedup_zone_features(zone_feats),
            "properties": {**(zones_fc.get("properties") or {}), **common_meta},
        }
        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": fl_feats,
            "properties": {**common_meta},
        }
        logger.info(
            "Joined: %d net links, %d zones, %d feedlinks",
            len(network_fc["features"]),
            len(zone_fc["features"]),
            len(fl_feats),
        )
        if debug:
            _snapshot(5, area_id, out_dir, NETWORK=network_fc, ZONE=zone_fc, FEEDLINKS=feedlinks_fc)

    with tracker.stage("Build OD matrix & routes"):
        from gmt_routing.matrix_builder.core.matrix_builder_core import build_matrix

        routes_fc = build_matrix(
            network_fc,
            feedlinks_fc,
            zone_fc,
            max_routes=max_routes,
            hb_od=None,
            progress_label=MODE,
        )
        routes_fc.setdefault("properties", {}).update(common_meta)
        logger.info("%d route features built", len(routes_fc.get("features") or []))
        if debug:
            _snapshot(6, area_id, out_dir, ROUTES=routes_fc)

    with tracker.stage("Write outputs"):
        network_path.write_bytes(to_geoparquet(network_fc))
        feedlinks_path.write_bytes(to_geoparquet(feedlinks_fc))
        zone_path.write_bytes(to_geoparquet(zone_fc))
        routes_path.write_bytes(to_geoparquet(routes_fc))
        logger.info(
            "Logistiek pipeline complete: network=%s feedlinks=%s zones=%s routes=%s",
            network_path,
            feedlinks_path,
            zone_path,
            routes_path,
        )
    return area_id
