"""Pure-Python zone_fetcher core — no I/O, no boto3, no Databricks connections.

Builds the Databricks SQL query and converts raw result rows into a GeoJSON
FeatureCollection with STUDY, INFLUENCE, and AREA zone features.

Public API
----------
build_fetch_zones_sql(catalog, schema, *, study_fallback="centroid") -> str
    Return the parameterised Databricks SQL string (1 ``?`` placeholder).
    ``study_fallback`` selects the STUDY fallback methodology used when no
    zone reaches the 80 % bbox-overlap threshold: ``"centroid"`` (default,
    zone containing the bbox centre) or ``"max_overlap"`` (zone with the
    largest overlap ratio, falling back to centroid-containment only when no
    zone intersects the bbox at all).
bbox_to_polygon_json(bbox) -> str
    Convert [lon_min, lat_min, lon_max, lat_max] to a GeoJSON Polygon string.
rows_to_feature_collection(rows, col_names, area_id, bbox) -> dict
    Convert raw Databricks result rows into a GeoJSON FeatureCollection.
"""

from __future__ import annotations

from gmt_zone_core.zone_fetcher.domain.sql import (  # noqa: F401
    _CBS_COLS,
    ZONE_FETCH_PROPERTIES,
    bbox_to_polygon_json,
    build_fetch_zones_sql,
)
from gmt_zone_core.zone_fetcher.domain.zone import (  # noqa: F401
    _calc_attraction,
    _calc_production,
    rows_to_feature_collection,
)
