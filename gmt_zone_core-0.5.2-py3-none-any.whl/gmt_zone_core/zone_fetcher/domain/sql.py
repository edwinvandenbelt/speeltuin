"""SQL construction for zone_fetcher — no I/O, no boto3.

Builds the Databricks SQL query that:
 1. Finds STUDY zones (zones where ≥ 80 % of the zone area overlaps the input bbox).
 2. Falls back to a secondary STUDY rule when no zone reaches that 80 % threshold.
    Two fallback methodologies are available via ``study_fallback``:
      - ``"centroid"`` (default) — the zone containing the bbox centre, used
        only when no zone overlaps the bbox at all.
      - ``"max_overlap"`` — the zone with the single largest overlap ratio
        among zones that intersect the bbox at all, even when every ratio is
        below 80 %.  If literally no zone intersects the bbox (e.g. the bbox
        falls over a gap/water), this methodology falls back to the same
        centroid-containment rule as ``"centroid"``, so STUDY is never empty.
 3. Finds candidate INFLUENCE zones: all zones whose centroid lies within 12 km of
    the bbox centroid (fast point-to-point distance).  A Python-side BFS then
    filters this broad candidate set down to only zones that are reachable from a
    study zone via a chain of touching/overlapping zone bboxes — except that any
    candidate zone whose own bbox overlaps the input bbox is always kept, even
    when it is more than 1 hop from a study zone (see
    ``zone.py::_filter_influence_by_adjacency``).  INFLUENCE selection is
    identical regardless of which STUDY fallback methodology was used.

The returned SQL has **one** positional ``?`` placeholder:
    1. bbox GeoJSON polygon string  (used for spatial intersection)

The AREA feature (convex hull of all kept zones) is computed in Python by
``rows_to_feature_collection`` — it is no longer produced by the SQL query.
"""

from __future__ import annotations

import json
from typing import Literal

# ---------------------------------------------------------------------------
# CBS demographic columns — identical to zone_intersector._CBS_COLS
# ---------------------------------------------------------------------------

_CBS_COLS: tuple[str, ...] = (
    "inwoners",
    "huishoudens",
    "arbeidsplaatsen",
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)

# Output property keys present on every STUDY / INFLUENCE feature.
ZONE_FETCH_PROPERTIES: tuple[str, ...] = (
    "gid",
    "zoneId",
    "zoneName",
    "municipalityCode",
    "municipalityName",
    "zoneClass",
    "zoneClassCode",
    "centroidLon",
    "centroidLat",
    "production",
    "attraction",
    *_CBS_COLS,
)

# ---------------------------------------------------------------------------
# SQL fragments
# ---------------------------------------------------------------------------

_CBS_SELECT = ",\n        ".join(f"z.{c}" for c in _CBS_COLS)
_CBS_NULLS = ",\n    ".join(f"CAST(NULL AS DOUBLE) AS {c}" for c in _CBS_COLS)


_STUDY_FALLBACKS: tuple[str, ...] = ("centroid", "max_overlap")


def build_fetch_zones_sql(
    catalog: str,
    schema: str,
    *,
    study_fallback: Literal["centroid", "max_overlap"] = "centroid",
) -> str:
    """Return the zone-fetch SQL for *catalog* and *schema*.

    Placeholders (in order)
    -----------------------
    1. bbox GeoJSON polygon string

    Schema differences
    ------------------
    ``2024_01`` stores geometries as native ``geometry(4326)`` columns
    (``geom_zone_geometrie_4326`` / ``geom_centroid_geometrie_4326``).
    All other schemas store EWKB binary blobs in ``zone_geometrie`` /
    ``centroid_geometrie`` (in RD / EPSG:28992).  The correct SQL
    expressions are selected automatically based on *schema*.

    study_fallback
    --------------
    Methodology used to pick STUDY zones when none reach the 80 % bbox-overlap
    threshold:
      - ``"centroid"`` (default) — the zone containing the bbox centre, used
        only when no zone overlaps the bbox at all.
      - ``"max_overlap"`` — the zone with the largest overlap ratio among
        zones that intersect the bbox at all, falling back to
        centroid-containment only when literally no zone intersects the bbox.

    Raises
    ------
    ValueError
        If *study_fallback* is not one of ``"centroid"`` or ``"max_overlap"``.
    """
    if study_fallback not in _STUDY_FALLBACKS:
        raise ValueError(
            f"study_fallback must be one of {_STUDY_FALLBACKS!r}, got {study_fallback!r}"
        )

    db = f"`{catalog}`.`{schema}`"

    # ------------------------------------------------------------------
    # Schema-specific geometry expressions
    # ------------------------------------------------------------------
    if schema == "2024_01":
        # Columns are native geometry objects already in RD (EPSG:28992),
        # named with an explicit _28992 suffix.  No ST_GeomFromEWKB needed;
        # no transform required for spatial predicates against bbox_rd.
        _zone_geom_rd = "z.zone_geometrie_28992"
        _centroid_geom_rd = "z.centroid_geometrie_28992"
        _zone_geom_4326 = "ST_Transform(z.zone_geometrie_28992, 4326)"
        _centroid_geom_4326 = "ST_Transform(z.centroid_geometrie_28992, 4326)"
    else:
        # Columns are EWKB binary blobs in RD (EPSG:28992).
        _zone_geom_rd = "ST_GeomFromEWKB(z.zone_geometrie)"
        _centroid_geom_rd = "ST_GeomFromEWKB(z.centroid_geometrie)"
        _zone_geom_4326 = "ST_Transform(ST_GeomFromEWKB(z.zone_geometrie), 4326)"
        _centroid_geom_4326 = "ST_Transform(ST_GeomFromEWKB(z.centroid_geometrie), 4326)"

    # ------------------------------------------------------------------
    # STUDY fallback CTEs (used when no zone reaches the 80 % threshold)
    # ------------------------------------------------------------------
    if study_fallback == "max_overlap":
        _fallback_ctes = f"""\
-- Fallback: zone with the largest overlap ratio among zones that intersect
-- the bbox at all (used when no zone reaches the 80 % threshold).
study_overlap_ranked_gids AS (
    SELECT z.gid,
           ST_Area(ST_Intersection({_zone_geom_rd}, poly))
             / NULLIF(ST_Area({_zone_geom_rd}), 0) AS overlap_ratio
    FROM   {db}.d030_zones_met_centroids z
    CROSS JOIN bbox_rd
    WHERE  NOT EXISTS (SELECT 1 FROM study_intersect_gids)
      AND  ST_Intersects({_zone_geom_rd}, poly)
),

study_max_overlap_gids AS (
    SELECT gid FROM study_overlap_ranked_gids
    ORDER BY overlap_ratio DESC
    LIMIT 1
),

-- Last-resort fallback: used only when literally no zone intersects the
-- bbox at all (e.g. the bbox falls over a gap/water), so STUDY is never empty.
study_center_gids AS (
    SELECT z.gid
    FROM   {db}.d030_zones_met_centroids z
    CROSS JOIN bbox_rd
    WHERE  NOT EXISTS (SELECT 1 FROM study_intersect_gids)
      AND  NOT EXISTS (SELECT 1 FROM study_max_overlap_gids)
      AND  ST_Contains({_zone_geom_rd}, ST_Centroid(poly))
    LIMIT 1
),

study_gids AS (
    SELECT gid FROM study_intersect_gids
    UNION ALL
    SELECT gid FROM study_max_overlap_gids
    UNION ALL
    SELECT gid FROM study_center_gids
),"""
    else:
        _fallback_ctes = f"""\
-- Fallback: zone containing the bbox centre (used only when no zones intersect the bbox)
study_center_gids AS (
    SELECT z.gid
    FROM   {db}.d030_zones_met_centroids z
    CROSS JOIN bbox_rd
    WHERE  NOT EXISTS (SELECT 1 FROM study_intersect_gids)
      AND  ST_Contains({_zone_geom_rd}, ST_Centroid(poly))
    LIMIT 1
),

study_gids AS (
    SELECT gid FROM study_intersect_gids
    UNION ALL
    SELECT gid FROM study_center_gids
),"""

    return f"""\
WITH
bbox_rd AS (
    SELECT ST_Transform(ST_GeomFromGeoJSON(?), 28992) AS poly
),

-- Zones where at least 80 % of the zone area lies within the input bbox (primary study area)
study_intersect_gids AS (
    SELECT z.gid
    FROM   {db}.d030_zones_met_centroids z
    CROSS JOIN bbox_rd
    WHERE  ST_Intersects({_zone_geom_rd}, poly)
      AND  ST_Area(ST_Intersection({_zone_geom_rd}, poly))
             / NULLIF(ST_Area({_zone_geom_rd}), 0) >= 0.8
),

{_fallback_ctes}

-- Centre point of the input bbox (reference point for influence radius)
bbox_centroid_rd AS (
    SELECT ST_Centroid(poly) AS pt FROM bbox_rd
),

-- Broad candidate influence zones: centroid within 12 km of the bbox centroid.
-- Python-side BFS (in rows_to_feature_collection) then prunes this set to only
-- zones reachable from a study zone via a contiguous chain of touching zones —
-- except zones that themselves overlap the input bbox, which are always kept.
candidate_influence_gids AS (
    SELECT z.gid
    FROM   {db}.d030_zones_met_centroids z
    CROSS JOIN bbox_centroid_rd
    WHERE  z.gid NOT IN (SELECT gid FROM study_gids)
      AND  ST_DWithin({_centroid_geom_rd}, bbox_centroid_rd.pt, 12000)
),

relevant AS (
    SELECT gid, 'STUDY'     AS zone_class FROM study_gids
    UNION ALL
    SELECT gid, 'INFLUENCE' AS zone_class FROM candidate_influence_gids
),

zone_data AS (
    SELECT
        z.gid,
        z.zone_id                                                                AS zoneId,
        z.zone_naam                                                              AS zoneName,
        z.gemeente_code                                                          AS municipalityCode,
        z.gemeente_naam                                                          AS municipalityName,
        {_CBS_SELECT},
        ST_AsGeoJSON({_zone_geom_4326})                                          AS geom_json,
        ST_X(ST_Centroid({_centroid_geom_4326}))                                 AS centroidLon,
        ST_Y(ST_Centroid({_centroid_geom_4326}))                                 AS centroidLat,
        r.zone_class                                                             AS zoneClass
    FROM   {db}.d030_zones_met_centroids z
    JOIN   relevant r USING (gid)
)

SELECT
    gid,
    zoneId,
    zoneName,
    municipalityCode,
    municipalityName,
    {_CBS_SELECT.replace("z.", "")},
    geom_json,
    centroidLon,
    centroidLat,
    zoneClass
FROM zone_data
"""


def bbox_to_polygon_json(bbox: list[float]) -> str:
    """Convert ``[lon_min, lat_min, lon_max, lat_max]`` to a GeoJSON Polygon string."""
    lon_min, lat_min, lon_max, lat_max = bbox[0], bbox[1], bbox[2], bbox[3]
    coords = [
        [lon_min, lat_min],
        [lon_max, lat_min],
        [lon_max, lat_max],
        [lon_min, lat_max],
        [lon_min, lat_min],
    ]
    return json.dumps({"type": "Polygon", "coordinates": [coords]})
