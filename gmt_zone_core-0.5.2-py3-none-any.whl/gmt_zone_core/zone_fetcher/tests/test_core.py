"""Unit tests for zone_fetcher domain modules.

All tests are pure — no boto3, no Databricks, no network calls.
"""

from __future__ import annotations

import json

import pytest

from gmt_zone_core.zone_fetcher.domain.sql import (
    _CBS_COLS,
    ZONE_FETCH_PROPERTIES,
    bbox_to_polygon_json,
    build_fetch_zones_sql,
)
from gmt_zone_core.zone_fetcher.domain.zone import (
    _build_adjacency_graph,
    _build_area_feature,
    _calc_attraction,
    _calc_production,
    _convex_hull_ring,
    _filter_influence_by_adjacency,
    rows_to_feature_collection,
)

# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

_BBOX = [6.0, 52.0, 6.2, 52.1]
_AREA_ID = "test-area-001"

_GEOM_POLYGON = json.dumps(
    {
        "type": "Polygon",
        "coordinates": [[[6.0, 52.0], [6.1, 52.0], [6.1, 52.1], [6.0, 52.0]]],
    }
)

# Column names returned by build_fetch_zones_sql
_COL_NAMES = [
    "gid",
    "zoneId",
    "zoneName",
    "municipalityCode",
    "municipalityName",
    *_CBS_COLS,
    "geom_json",
    "centroidLon",
    "centroidLat",
    "zoneClass",
]


def _make_zone_row(
    gid: int = 1,
    zone_id: str = "z1",
    zone_name: str = "Zone 1",
    municipality_code: str = "0150",
    municipality_name: str = "Deventer",
    zone_class: str = "STUDY",
    geom: str | None = None,
    centroid_lon: float = 6.05,
    centroid_lat: float = 52.05,
    **cbs_overrides,
) -> tuple:
    """Return a result-set tuple for a STUDY or INFLUENCE zone row."""
    fixed = (gid, zone_id, zone_name, municipality_code, municipality_name)
    cbs = tuple(float(cbs_overrides.get(c, 0.0) or 0.0) for c in _CBS_COLS)
    tail = (geom or _GEOM_POLYGON, centroid_lon, centroid_lat, zone_class)
    return fixed + cbs + tail


def _make_feature(zone_id: str, zone_class: str, bbox: tuple) -> dict:
    """Build a minimal GeoJSON Feature with a rectangular geometry."""
    min_lon, min_lat, max_lon, max_lat = bbox
    ring = [
        [min_lon, min_lat],
        [max_lon, min_lat],
        [max_lon, max_lat],
        [min_lon, max_lat],
        [min_lon, min_lat],
    ]
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {"zoneId": zone_id, "zoneClass": zone_class},
    }


# ---------------------------------------------------------------------------
# bbox_to_polygon_json
# ---------------------------------------------------------------------------


class TestBboxToPolygonJson:
    def test_returns_valid_json(self):
        result = bbox_to_polygon_json(_BBOX)
        obj = json.loads(result)
        assert obj["type"] == "Polygon"

    def test_ring_is_closed(self):
        obj = json.loads(bbox_to_polygon_json(_BBOX))
        ring = obj["coordinates"][0]
        assert ring[0] == ring[-1]

    def test_contains_all_corners(self):
        obj = json.loads(bbox_to_polygon_json(_BBOX))
        ring = obj["coordinates"][0]
        lons = {c[0] for c in ring}
        lats = {c[1] for c in ring}
        assert 6.0 in lons and 6.2 in lons
        assert 52.0 in lats and 52.1 in lats

    def test_five_points(self):
        obj = json.loads(bbox_to_polygon_json(_BBOX))
        assert len(obj["coordinates"][0]) == 5


# ---------------------------------------------------------------------------
# build_fetch_zones_sql
# ---------------------------------------------------------------------------


class TestBuildFetchZonesSql:
    def test_returns_string(self):
        assert isinstance(build_fetch_zones_sql("spectrum", "2024_01"), str)

    def test_contains_catalog_and_schema(self):
        sql = build_fetch_zones_sql("my_catalog", "my_schema")
        assert "my_catalog" in sql
        assert "my_schema" in sql

    def test_contains_one_placeholder(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert sql.count("?") == 1

    def test_references_correct_table(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert "d030_zones_met_centroids" in sql

    def test_contains_study_and_influence(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert "STUDY" in sql
        assert "INFLUENCE" in sql

    def test_area_not_in_sql(self):
        # AREA is now computed in Python, not returned by SQL
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert "'AREA'" not in sql

    def test_contains_st_transform(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert "ST_Transform" in sql

    def test_influence_uses_st_dwithin_12km(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert "ST_DWithin" in sql
        assert "12000" in sql

    def test_influence_uses_centroid_not_union(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert "bbox_centroid_rd" in sql
        assert "centroid_geometrie" in sql
        assert "study_union" not in sql

    def test_study_uses_80_percent_overlap(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert "ST_Intersection" in sql
        assert "0.8" in sql

    def test_no_area_union_cte(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert "area_union" not in sql

    def test_no_union_all_between_study_and_area(self):
        # The old SQL had UNION ALL to append the AREA row; the new SQL only
        # uses UNION ALL within study_gids / relevant CTEs.
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        # It should still have UNION ALL for the study fallback CTE
        assert "UNION ALL" in sql.upper()
        # But not a second SELECT from area_union
        assert "FROM area_union" not in sql

    # ------------------------------------------------------------------
    # Schema-specific geometry expressions
    # ------------------------------------------------------------------

    def test_2024_01_uses_native_geometry_columns(self):
        """2024_01 uses zone_geometrie_28992 / centroid_geometrie_28992 (native, already in RD)."""
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        assert "zone_geometrie_28992" in sql
        assert "centroid_geometrie_28992" in sql
        # Should NOT reference the old EWKB column names
        assert "ST_GeomFromEWKB" not in sql

    def test_2024_01_transforms_to_rd_for_spatial_predicates(self):
        """2024_01 geometry is already in RD — no ST_Transform needed in spatial predicates."""
        sql = build_fetch_zones_sql("spectrum", "2024_01")
        # ST_Transform is still used for output (→ 4326) but not in WHERE predicates
        assert "ST_Transform" in sql
        assert "28992" in sql

    def test_other_schema_uses_ewkb_columns(self):
        """Non-2024_01 schemas use ST_GeomFromEWKB(z.zone_geometrie)."""
        sql = build_fetch_zones_sql("spectrum", "2025_01")
        assert "ST_GeomFromEWKB" in sql
        assert "zone_geometrie" in sql
        assert "centroid_geometrie" in sql
        assert "zone_geometrie_28992" not in sql


# ---------------------------------------------------------------------------
# build_fetch_zones_sql — study_fallback methodologies
# ---------------------------------------------------------------------------


class TestStudyFallback:
    def test_default_is_centroid(self):
        default_sql = build_fetch_zones_sql("spectrum", "2024_01")
        explicit_sql = build_fetch_zones_sql("spectrum", "2024_01", study_fallback="centroid")
        assert default_sql == explicit_sql

    def test_centroid_omits_max_overlap_cte(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01", study_fallback="centroid")
        assert "study_max_overlap_gids" not in sql
        assert "overlap_ratio" not in sql

    def test_max_overlap_contains_overlap_ranking(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01", study_fallback="max_overlap")
        assert "study_max_overlap_gids" in sql
        assert "overlap_ratio" in sql
        assert "ORDER BY overlap_ratio DESC" in sql

    def test_max_overlap_keeps_centroid_last_resort(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01", study_fallback="max_overlap")
        assert "study_center_gids" in sql
        assert "ST_Contains" in sql

    def test_max_overlap_union_includes_all_three_ctes(self):
        sql = build_fetch_zones_sql("spectrum", "2024_01", study_fallback="max_overlap")
        study_gids_block = sql[sql.index("study_gids AS (") : sql.index("candidate_influence_gids")]
        assert "study_intersect_gids" in study_gids_block
        assert "study_max_overlap_gids" in study_gids_block
        assert "study_center_gids" in study_gids_block

    def test_invalid_study_fallback_raises(self):
        with pytest.raises(ValueError):
            build_fetch_zones_sql("spectrum", "2024_01", study_fallback="bogus")  # type: ignore[arg-type]


# ---------------------------------------------------------------------------
# ZONE_FETCH_PROPERTIES
# ---------------------------------------------------------------------------


class TestZoneFetchProperties:
    def test_is_tuple(self):
        assert isinstance(ZONE_FETCH_PROPERTIES, tuple)

    def test_contains_zone_id(self):
        assert "zoneId" in ZONE_FETCH_PROPERTIES

    def test_contains_zone_class(self):
        assert "zoneClass" in ZONE_FETCH_PROPERTIES

    def test_contains_production_and_attraction(self):
        assert "production" in ZONE_FETCH_PROPERTIES
        assert "attraction" in ZONE_FETCH_PROPERTIES

    def test_contains_all_cbs_cols(self):
        for col in _CBS_COLS:
            assert col in ZONE_FETCH_PROPERTIES


# ---------------------------------------------------------------------------
# _calc_production
# ---------------------------------------------------------------------------


class TestCalcProduction:
    def test_zero_when_all_zero(self):
        assert _calc_production({}) == 0.0

    def test_formula(self):
        result = _calc_production({"huishoudens": 100.0, "inwoners": 200.0})
        expected = (7.0 * 100.0 + 2.3 * 200.0) / 2.0
        assert result == pytest.approx(expected)

    def test_none_treated_as_zero(self):
        assert _calc_production({"huishoudens": None, "inwoners": None}) == 0.0


# ---------------------------------------------------------------------------
# _calc_attraction
# ---------------------------------------------------------------------------


class TestCalcAttraction:
    def test_zero_when_all_zero(self):
        assert _calc_attraction({}) == 0.0

    def test_formula(self):
        result = _calc_attraction(
            {
                "arbeidsplaatsen": 500.0,
                "leerlingplaatsen_basisonderwijs": 50.0,
                "leerlingplaatsen_middelbaaronderwijs": 30.0,
                "leerlingplaatsen_middelbaarberoepsonderwijs": 20.0,
                "leerlingplaatsen_hogeronderwijs": 10.0,
            }
        )
        expected = 2.0 * (500.0 + 50.0 + 30.0 + 20.0 + 10.0)
        assert result == pytest.approx(expected)

    def test_none_treated_as_zero(self):
        assert _calc_attraction({"arbeidsplaatsen": None}) == 0.0


# ---------------------------------------------------------------------------
# _build_adjacency_graph
# ---------------------------------------------------------------------------


class TestBuildAdjacencyGraph:
    def test_touching_zones_are_adjacent(self):
        # z1: [0,0]-[1,1]   z2: [1,0]-[2,1]  — share edge at lon=1
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (1.0, 0.0, 2.0, 1.0)),
        ]
        graph = _build_adjacency_graph(features)
        assert "z2" in graph["z1"]
        assert "z1" in graph["z2"]

    def test_overlapping_zones_are_adjacent(self):
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.5, 1.0)),
            _make_feature("z2", "INFLUENCE", (1.0, 0.0, 2.0, 1.0)),
        ]
        graph = _build_adjacency_graph(features)
        assert "z2" in graph["z1"]

    def test_separated_zones_not_adjacent(self):
        # Gap of 0.1 degree between zones
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (1.1, 0.0, 2.0, 1.0)),
        ]
        graph = _build_adjacency_graph(features)
        assert "z2" not in graph["z1"]

    def test_no_self_loops(self):
        features = [_make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0))]
        graph = _build_adjacency_graph(features)
        assert "z1" not in graph["z1"]

    def test_missing_geometry_excluded(self):
        f = {
            "type": "Feature",
            "geometry": None,
            "properties": {"zoneId": "z1", "zoneClass": "STUDY"},
        }
        graph = _build_adjacency_graph([f])
        assert graph == {}


# ---------------------------------------------------------------------------
# _filter_influence_by_adjacency
# ---------------------------------------------------------------------------


class TestFilterInfluenceByAdjacency:
    def _chain(self, n: int) -> list[dict]:
        """Build a chain of n touching zones: 1 STUDY + (n-1) INFLUENCE."""
        features = [_make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0))]
        for i in range(2, n + 1):
            x = float(i - 1)
            features.append(_make_feature(f"z{i}", "INFLUENCE", (x, 0.0, x + 1.0, 1.0)))
        return features

    def test_study_zones_always_kept(self):
        features = [_make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0))]
        result = _filter_influence_by_adjacency(features)
        ids = {f["properties"]["zoneId"] for f in result}
        assert "z1" in ids

    def test_direct_neighbour_kept(self):
        features = self._chain(2)
        result = _filter_influence_by_adjacency(features)
        ids = {f["properties"]["zoneId"] for f in result}
        assert "z2" in ids

    def test_only_direct_neighbours_kept(self):
        # z1 STUDY, z2 INFLUENCE (touches z1), z3 INFLUENCE (touches z2 but NOT z1)
        # → z2 kept (1 hop), z3 dropped (2 hops)
        features = self._chain(3)  # z1 STUDY, z2–z3 INFLUENCE
        result = _filter_influence_by_adjacency(features)
        ids = {f["properties"]["zoneId"] for f in result}
        assert "z1" in ids
        assert "z2" in ids
        assert "z3" not in ids

    def test_isolated_influence_removed(self):
        # z1 STUDY at [0,0]-[1,1];  z2 INFLUENCE far away (not touching)
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (5.0, 0.0, 6.0, 1.0)),
        ]
        result = _filter_influence_by_adjacency(features)
        ids = {f["properties"]["zoneId"] for f in result}
        assert "z1" in ids
        assert "z2" not in ids

    def test_second_hop_influence_removed(self):
        # z1 STUDY — z2 INFLUENCE (touches z1) — z3 INFLUENCE (touches z2, NOT z1)
        # z4 INFLUENCE not touching anything near → dropped
        # Only z2 should be kept as influence (direct neighbour of z1).
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (1.0, 0.0, 2.0, 1.0)),
            _make_feature("z3", "INFLUENCE", (2.0, 0.0, 3.0, 1.0)),
            _make_feature("z4", "INFLUENCE", (9.0, 0.0, 10.0, 1.0)),
        ]
        result = _filter_influence_by_adjacency(features)
        ids = {f["properties"]["zoneId"] for f in result}
        assert "z2" in ids
        assert "z3" not in ids
        assert "z4" not in ids

    def test_no_study_zones_returns_all(self):
        """Degenerate case: no STUDY zones → return everything unchanged."""
        features = [
            _make_feature("z1", "INFLUENCE", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (5.0, 0.0, 6.0, 1.0)),
        ]
        result = _filter_influence_by_adjacency(features)
        assert len(result) == 2

    def test_multiple_study_zones_seed_bfs(self):
        # z1 STUDY and z3 STUDY; z2 INFLUENCE between them (touches both)
        # z4 INFLUENCE only touches z3
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (1.0, 0.0, 2.0, 1.0)),
            _make_feature("z3", "STUDY", (2.0, 0.0, 3.0, 1.0)),
            _make_feature("z4", "INFLUENCE", (3.0, 0.0, 4.0, 1.0)),
        ]
        result = _filter_influence_by_adjacency(features)
        ids = {f["properties"]["zoneId"] for f in result}
        assert ids == {"z1", "z2", "z3", "z4"}

    # -- bbox-overlap override (kept even when >1 hop from a study zone) ------

    def test_far_influence_kept_when_overlapping_bbox(self):
        # z1 STUDY — z2 INFLUENCE (touches z1) — z3 INFLUENCE (touches z2, 2 hops
        # from z1, would normally be dropped).  But z3 overlaps the query bbox,
        # so it must be kept.
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (1.0, 0.0, 2.0, 1.0)),
            _make_feature("z3", "INFLUENCE", (2.0, 0.0, 3.0, 1.0)),
        ]
        bbox = (2.2, 0.2, 2.8, 0.8)  # falls inside z3's bbox
        result = _filter_influence_by_adjacency(features, bbox=bbox)
        ids = {f["properties"]["zoneId"] for f in result}
        assert ids == {"z1", "z2", "z3"}

    def test_far_influence_dropped_when_not_overlapping_bbox(self):
        # Same shape as above, but the bbox does not touch z3 at all.
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (1.0, 0.0, 2.0, 1.0)),
            _make_feature("z3", "INFLUENCE", (2.0, 0.0, 3.0, 1.0)),
        ]
        bbox = (0.2, 0.2, 0.8, 0.8)  # only overlaps z1 (the study zone)
        result = _filter_influence_by_adjacency(features, bbox=bbox)
        ids = {f["properties"]["zoneId"] for f in result}
        assert ids == {"z1", "z2"}
        assert "z3" not in ids

    def test_no_bbox_preserves_historical_behaviour(self):
        # Omitting bbox entirely must behave exactly like before this change.
        features = self._chain(3)
        result = _filter_influence_by_adjacency(features)
        ids = {f["properties"]["zoneId"] for f in result}
        assert ids == {"z1", "z2"}
        assert "z3" not in ids

    def test_bbox_only_rescues_influence_zones_not_study(self):
        # bbox overlap should not change STUDY handling — it's already
        # unconditionally kept, this just confirms no double-counting/errors.
        features = [_make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0))]
        bbox = (0.0, 0.0, 1.0, 1.0)
        result = _filter_influence_by_adjacency(features, bbox=bbox)
        ids = {f["properties"]["zoneId"] for f in result}
        assert ids == {"z1"}


# ---------------------------------------------------------------------------
# _convex_hull_ring
# ---------------------------------------------------------------------------


class TestConvexHullRing:
    def test_square_gives_5_point_ring(self):
        pts = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]
        ring = _convex_hull_ring(pts)
        assert ring[0] == ring[-1]  # closed
        assert len(ring) == 5  # 4 corners + closing point

    def test_interior_point_excluded(self):
        pts = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.5, 0.5]]
        ring = _convex_hull_ring(pts)
        assert len(ring) == 5  # interior point removed

    def test_fewer_than_3_distinct_returns_empty(self):
        assert _convex_hull_ring([[0.0, 0.0], [0.0, 0.0]]) == []
        assert _convex_hull_ring([[0.0, 0.0]]) == []
        assert _convex_hull_ring([]) == []

    def test_all_hull_points_from_input(self):
        pts = [[0.0, 0.0], [2.0, 0.0], [1.0, 1.0], [2.0, 2.0], [0.0, 2.0]]
        ring = _convex_hull_ring(pts)
        hull_set = {(p[0], p[1]) for p in ring}
        # All ring points must come from the input set
        for p in hull_set:
            assert list(p) in pts or p == (pts[0][0], pts[0][1])


# ---------------------------------------------------------------------------
# _build_area_feature
# ---------------------------------------------------------------------------


class TestBuildAreaFeature:
    def test_returns_feature_with_area_class(self):
        features = [_make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0))]
        area = _build_area_feature(features, "aid-1")
        assert area["properties"]["zoneClass"] == "AREA"
        assert area["properties"]["zoneId"] == "aid-1"

    def test_geometry_is_polygon(self):
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (1.0, 0.0, 2.0, 1.0)),
        ]
        area = _build_area_feature(features, "aid-1")
        assert area["geometry"]["type"] == "Polygon"

    def test_hull_encloses_all_zone_corners(self):
        features = [
            _make_feature("z1", "STUDY", (0.0, 0.0, 1.0, 1.0)),
            _make_feature("z2", "INFLUENCE", (1.0, 0.0, 3.0, 1.0)),
        ]
        area = _build_area_feature(features, "aid-1")
        ring = area["geometry"]["coordinates"][0]
        lons = [p[0] for p in ring]
        lats = [p[1] for p in ring]
        assert min(lons) <= 0.0 and max(lons) >= 3.0
        assert min(lats) <= 0.0 and max(lats) >= 1.0

    def test_no_features_returns_none_geometry(self):
        area = _build_area_feature([], "aid-1")
        assert area["geometry"] is None


# ---------------------------------------------------------------------------
# rows_to_feature_collection
# ---------------------------------------------------------------------------


class TestRowsToFeatureCollection:
    def test_returns_feature_collection(self):
        fc = rows_to_feature_collection([], _COL_NAMES, _AREA_ID, _BBOX)
        assert fc["type"] == "FeatureCollection"

    def test_id_equals_area_id(self):
        fc = rows_to_feature_collection([], _COL_NAMES, _AREA_ID, _BBOX)
        assert fc["id"] == _AREA_ID

    def test_properties_contains_area_id(self):
        fc = rows_to_feature_collection([], _COL_NAMES, _AREA_ID, _BBOX)
        assert fc["properties"]["areaId"] == _AREA_ID

    def test_properties_contains_bbox(self):
        fc = rows_to_feature_collection([], _COL_NAMES, _AREA_ID, _BBOX)
        assert fc["properties"]["bbox"] == _BBOX

    def test_empty_rows_returns_area_feature(self):
        # Even with no zone rows, an AREA feature (with None geometry) is appended
        fc = rows_to_feature_collection([], _COL_NAMES, _AREA_ID, _BBOX)
        assert fc["properties"]["studyCount"] == 0
        assert fc["properties"]["influenceCount"] == 0
        # Still has 1 AREA feature
        assert len(fc["features"]) == 1
        assert fc["features"][0]["properties"]["zoneClass"] == "AREA"

    def test_study_row_counted(self):
        rows = [_make_zone_row(zone_class="STUDY")]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        assert fc["properties"]["studyCount"] == 1
        assert fc["properties"]["influenceCount"] == 0

    def test_area_feature_always_appended(self):
        rows = [_make_zone_row(zone_class="STUDY")]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        classes = [f["properties"]["zoneClass"] for f in fc["features"]]
        assert "AREA" in classes

    def test_isolated_influence_removed_by_bfs(self):
        # z1 STUDY at lon 6.0–6.1; z2 INFLUENCE at lon 7.0–7.1 (far away → isolated)
        study_geom = json.dumps(
            {
                "type": "Polygon",
                "coordinates": [[[6.0, 52.0], [6.1, 52.0], [6.1, 52.1], [6.0, 52.1], [6.0, 52.0]]],
            }
        )
        isolated_geom = json.dumps(
            {
                "type": "Polygon",
                "coordinates": [[[7.0, 52.0], [7.1, 52.0], [7.1, 52.1], [7.0, 52.1], [7.0, 52.0]]],
            }
        )
        rows = [
            _make_zone_row(gid=1, zone_id="z1", zone_class="STUDY", geom=study_geom),
            _make_zone_row(gid=2, zone_id="z2", zone_class="INFLUENCE", geom=isolated_geom),
        ]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        ids = {
            f["properties"]["zoneId"]
            for f in fc["features"]
            if f["properties"]["zoneClass"] != "AREA"
        }
        assert "z1" in ids
        assert "z2" not in ids
        assert fc["properties"]["influenceCount"] == 0

    def test_far_influence_kept_when_it_overlaps_query_bbox(self):
        # z1 STUDY [6.00-6.05]; z2 INFLUENCE [6.05-6.10] (touches z1, 1 hop);
        # z3 INFLUENCE [6.10-6.15] (touches z2 only — 2 hops from z1, would
        # normally be dropped).  But z3's bbox overlaps _BBOX
        # ([6.0, 52.0, 6.2, 52.1]), so it must be kept.
        study_geom = json.dumps(
            {
                "type": "Polygon",
                "coordinates": [
                    [[6.00, 52.0], [6.05, 52.0], [6.05, 52.1], [6.00, 52.1], [6.00, 52.0]]
                ],
            }
        )
        mid_geom = json.dumps(
            {
                "type": "Polygon",
                "coordinates": [
                    [[6.05, 52.0], [6.10, 52.0], [6.10, 52.1], [6.05, 52.1], [6.05, 52.0]]
                ],
            }
        )
        far_geom = json.dumps(
            {
                "type": "Polygon",
                "coordinates": [
                    [[6.10, 52.0], [6.15, 52.0], [6.15, 52.1], [6.10, 52.1], [6.10, 52.0]]
                ],
            }
        )
        rows = [
            _make_zone_row(gid=1, zone_id="z1", zone_class="STUDY", geom=study_geom),
            _make_zone_row(gid=2, zone_id="z2", zone_class="INFLUENCE", geom=mid_geom),
            _make_zone_row(gid=3, zone_id="z3", zone_class="INFLUENCE", geom=far_geom),
        ]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        ids = {
            f["properties"]["zoneId"]
            for f in fc["features"]
            if f["properties"]["zoneClass"] != "AREA"
        }
        assert ids == {"z1", "z2", "z3"}
        assert fc["properties"]["influenceCount"] == 2

        # z1 STUDY [6.0–6.1]; z2 INFLUENCE [6.1–6.2] (touching)
        study_geom = json.dumps(
            {
                "type": "Polygon",
                "coordinates": [[[6.0, 52.0], [6.1, 52.0], [6.1, 52.1], [6.0, 52.1], [6.0, 52.0]]],
            }
        )
        adj_geom = json.dumps(
            {
                "type": "Polygon",
                "coordinates": [[[6.1, 52.0], [6.2, 52.0], [6.2, 52.1], [6.1, 52.1], [6.1, 52.0]]],
            }
        )
        rows = [
            _make_zone_row(gid=1, zone_id="z1", zone_class="STUDY", geom=study_geom),
            _make_zone_row(gid=2, zone_id="z2", zone_class="INFLUENCE", geom=adj_geom),
        ]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        ids = {
            f["properties"]["zoneId"]
            for f in fc["features"]
            if f["properties"]["zoneClass"] != "AREA"
        }
        assert "z2" in ids
        assert fc["properties"]["influenceCount"] == 1

    def test_mixed_rows(self):
        rows = [
            _make_zone_row(gid=1, zone_class="STUDY"),
            _make_zone_row(gid=2, zone_id="z2", zone_class="INFLUENCE"),
        ]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        # Both zones have the same geometry (_GEOM_POLYGON) so they touch → influence kept
        assert fc["properties"]["studyCount"] == 1
        assert fc["properties"]["influenceCount"] == 1
        # Plus the AREA feature
        assert len(fc["features"]) == 3

    def test_zone_feature_has_required_properties(self):
        rows = [_make_zone_row()]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        zone_features = [f for f in fc["features"] if f["properties"]["zoneClass"] != "AREA"]
        props = zone_features[0]["properties"]
        for key in (
            "gid",
            "zoneId",
            "zoneName",
            "zoneClass",
            "zoneClassCode",
            "production",
            "attraction",
            "centroidLon",
            "centroidLat",
            "municipalityCode",
            "municipalityName",
        ):
            assert key in props, f"Missing property: {key}"

    def test_study_zone_class_code_is_1(self):
        rows = [_make_zone_row(zone_class="STUDY")]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        zone_f = next(f for f in fc["features"] if f["properties"]["zoneClass"] == "STUDY")
        assert zone_f["properties"]["zoneClassCode"] == 1

    def test_influence_zone_class_code_is_2(self):
        rows = [_make_zone_row(gid=2, zone_id="z2", zone_class="INFLUENCE")]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        # No study zone → BFS returns all (degenerate) → influence kept
        zone_f = next(
            (f for f in fc["features"] if f["properties"]["zoneClass"] == "INFLUENCE"), None
        )
        assert zone_f is not None
        assert zone_f["properties"]["zoneClassCode"] == 2

    def test_zone_feature_has_all_cbs_cols(self):
        rows = [_make_zone_row()]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        zone_f = next(f for f in fc["features"] if f["properties"]["zoneClass"] == "STUDY")
        props = zone_f["properties"]
        for col in _CBS_COLS:
            assert col in props

    def test_zone_feature_geometry_is_polygon(self):
        rows = [_make_zone_row()]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        zone_f = next(f for f in fc["features"] if f["properties"]["zoneClass"] == "STUDY")
        assert zone_f["geometry"]["type"] == "Polygon"

    def test_production_formula_applied(self):
        rows = [_make_zone_row(huishoudens=100.0, inwoners=200.0)]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        zone_f = next(f for f in fc["features"] if f["properties"]["zoneClass"] == "STUDY")
        expected = (7.0 * 100.0 + 2.3 * 200.0) / 2.0
        assert zone_f["properties"]["production"] == pytest.approx(expected)

    def test_attraction_formula_applied(self):
        rows = [
            _make_zone_row(
                arbeidsplaatsen=500.0,
                leerlingplaatsen_basisonderwijs=100.0,
            )
        ]
        fc = rows_to_feature_collection(rows, _COL_NAMES, _AREA_ID, _BBOX)
        zone_f = next(f for f in fc["features"] if f["properties"]["zoneClass"] == "STUDY")
        expected = 2.0 * (500.0 + 100.0)
        assert zone_f["properties"]["attraction"] == pytest.approx(expected)

    def test_zone_properties_list_in_fc_properties(self):
        fc = rows_to_feature_collection([], _COL_NAMES, _AREA_ID, _BBOX)
        assert "fields" in fc["properties"]
        assert isinstance(fc["properties"]["fields"], list)

    def test_unknown_zone_class_skipped(self):
        row = _make_zone_row(zone_class="UNKNOWN")
        fc = rows_to_feature_collection([row], _COL_NAMES, _AREA_ID, _BBOX)
        zone_features = [f for f in fc["features"] if f["properties"].get("zoneClass") != "AREA"]
        assert zone_features == []
        assert fc["properties"]["studyCount"] == 0
