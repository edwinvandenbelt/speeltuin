"""Local debug runner for zone_fetcher_aggregated.

Fetches CBS buurt centroids from Databricks within a search radius and
aggregates them down to target STUDY/INFLUENCE zone counts, writing a
GeoParquet file to disk or S3 — schema-compatible with ``zone_fetcher``.

Usage
-----
    # Using a bounding box:
    python -m zone_fetcher_aggregated.zone_fetcher_aggregated_runner \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder s3://gmp-networks/zones/ \\
        --area-id deventer-centrum \\
        --zones-studiegebied 150 --zones-totaal 250 \\
        --catalog spectrum --schema 2024_01

Prerequisites
-------------
* Databricks credentials in a .env file or os.environ:
  DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID and one of:
  - DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET  (OAuth M2M, preferred)
  - DATABRICKS_TOKEN  (personal access token, fallback)
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from uuid import uuid4

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for zone_fetcher_aggregated (aggregates CBS centroids "
            "into a target zone count, MobiliteitsScan-style)."
        )
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        required=True,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box as four floats; treated as the area-of-interest polygon.",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help=(
            "Output folder URI (s3://bucket/prefix/ or local directory). "
            "Output file is named {area_id}-ZONES.parquet."
        ),
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help="Area identifier (UUID generated if not provided).",
    )
    parser.add_argument(
        "--name", default=None, help="Human-readable area name stored in FC properties (optional)."
    )
    parser.add_argument("--catalog", default="spectrum", help="Databricks Unity Catalog name")
    parser.add_argument("--schema", default="2024_01", help="Databricks schema / dataset version")
    parser.add_argument(
        "--zones-studiegebied",
        type=int,
        default=150,
        help="Target number of STUDY zones inside the area of interest (default: 150).",
    )
    parser.add_argument(
        "--zones-totaal",
        type=int,
        default=250,
        help="Target total number of zones, STUDY + INFLUENCE (default: 250).",
    )
    parser.add_argument(
        "--search-radius-m",
        type=float,
        default=100_000.0,
        help="Radius in metres around the bbox centre to fetch candidate centroids from (default: 100000).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    import gmt_shared.databricks_sql as databricks_sql
    from gmt_shared.geoparquet import to_geoparquet

    from gmt_zone_core.zone_fetcher_aggregated.domain.sql import (
        bbox_to_polygon_json,
        bbox_to_polygon_ring,
        build_fetch_centroids_sql,
    )
    from gmt_zone_core.zone_fetcher_aggregated.domain.zone import rows_to_feature_collection

    bbox: list[float] = args.bbox
    polygon_json = bbox_to_polygon_json(bbox)
    aoi_ring = bbox_to_polygon_ring(bbox)
    area_id = args.area_id or str(uuid4())

    sql = build_fetch_centroids_sql(args.catalog, args.schema)
    params = (polygon_json, args.search_radius_m)

    print(f"Area ID              : {area_id}")
    print(f"BBox                 : {bbox}")
    print(f"Search radius (m)    : {args.search_radius_m}")
    print(f"Zones studiegebied   : {args.zones_studiegebied}")
    print(f"Zones totaal         : {args.zones_totaal}")

    with databricks_sql.connect_from_env() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            col_names = [d[0] for d in cur.description]
            rows = cur.fetchall()

    print(f"Raw rows             : {len(rows)}")

    fc = rows_to_feature_collection(
        rows,
        col_names,
        area_id,
        bbox,
        aoi_ring,
        zones_within_target=args.zones_studiegebied,
        zones_total_target=args.zones_totaal,
    )

    if args.name:
        fc["properties"]["name"] = args.name

    study_count = fc["properties"]["studyCount"]
    influence_count = fc["properties"]["influenceCount"]
    total = len(fc["features"])

    print(f"STUDY zones          : {study_count}")
    print(f"INFLUENCE zones      : {influence_count}")
    print(f"Total features       : {total}  (includes 1 AREA feature)")

    output_folder = args.output_folder.rstrip("/") + "/"
    out_uri = f"{output_folder}{area_id}-ZONES.parquet"
    print(f"Writing              : {out_uri}")
    _write_uri(out_uri, to_geoparquet(fc))

    print("\nDone.")


if __name__ == "__main__":
    main()
