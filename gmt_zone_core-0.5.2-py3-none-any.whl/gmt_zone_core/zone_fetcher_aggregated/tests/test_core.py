"""Unit tests for zone_fetcher_aggregated domain modules.

All tests are pure — no boto3, no Databricks, no network calls.
"""

from __future__ import annotations

import pytest

from gmt_zone_core.zone_fetcher_aggregated.domain.aggregate import (
    _Point,
    _vertex_distance_m,
    _weight,
    build_aggregated_zones,
    classify_inside_outside,
    reduce_outside_aoi,
    reduce_within_aoi,
)
from gmt_zone_core.zone_fetcher_aggregated.domain.sql import (
    CBS_COLS,
    CENTROID_FETCH_PROPERTIES,
    bbox_to_polygon_json,
    bbox_to_polygon_ring,
    build_fetch_centroids_sql,
)
from gmt_zone_core.zone_fetcher_aggregated.domain.zone import (
    ZONE_FETCHER_AGGREGATED_PROPERTIES,
    _calc_attraction,
    _calc_production,
    rows_to_feature_collection,
)

# ---------------------------------------------------------------------------
# Helpers / fixtures
# ---------------------------------------------------------------------------

_BBOX = [6.00, 52.00, 6.10, 52.05]
_AREA_ID = "test-area-001"
_AOI_RING = bbox_to_polygon_ring(_BBOX)

_COL_NAMES = list(CENTROID_FETCH_PROPERTIES)


def _make_row(
    gid: int,
    zone_id: str,
    lon: float,
    lat: float,
    municipality_code: str = "0150",
    **cbs_overrides: float,
) -> tuple:
    cbs = tuple(float(cbs_overrides.get(c, 0.0) or 0.0) for c in CBS_COLS)
    return (
        gid,
        zone_id,
        f"Zone {zone_id}",
        municipality_code,
        "Testgemeente",
        *(value for value in cbs),
        lon,
        lat,
    )


# ---------------------------------------------------------------------------
# SQL
# ---------------------------------------------------------------------------


def test_build_fetch_centroids_sql_has_two_placeholders() -> None:
    sql = build_fetch_centroids_sql("spectrum", "2024_01")
    assert sql.count("?") == 2
    assert "d030_zones_met_centroids" in sql


def test_build_fetch_centroids_sql_ewkb_schema() -> None:
    sql = build_fetch_centroids_sql("spectrum", "2023_01")
    assert "ST_GeomFromEWKB" in sql


def test_bbox_to_polygon_ring_is_closed_rectangle() -> None:
    ring = bbox_to_polygon_ring(_BBOX)
    assert ring[0] == ring[-1]
    assert len(ring) == 5


def test_bbox_to_polygon_json_matches_ring() -> None:
    import json

    polygon = json.loads(bbox_to_polygon_json(_BBOX))
    assert polygon["type"] == "Polygon"
    assert polygon["coordinates"][0] == bbox_to_polygon_ring(_BBOX)


# ---------------------------------------------------------------------------
# classify_inside_outside
# ---------------------------------------------------------------------------


def test_classify_splits_inside_and_outside() -> None:
    rows = [
        dict(zip(_COL_NAMES, _make_row(1, "z1", 6.05, 52.02, inwoners=100), strict=True)),
        dict(zip(_COL_NAMES, _make_row(2, "z2", 7.00, 52.02, inwoners=200), strict=True)),
    ]
    inside, outside = classify_inside_outside(rows, _AOI_RING)
    assert [p.source_id for p in inside] == ["z1"]
    assert [p.source_id for p in outside] == ["z2"]


def test_classify_drops_zero_quantity_rows() -> None:
    rows = [
        dict(
            zip(
                _COL_NAMES,
                _make_row(1, "z1", 6.05, 52.02, inwoners=0, arbeidsplaatsen=0),
                strict=True,
            )
        ),
        dict(zip(_COL_NAMES, _make_row(2, "z2", 6.06, 52.02, inwoners=50), strict=True)),
    ]
    inside, outside = classify_inside_outside(rows, _AOI_RING)
    assert len(inside) == 1
    assert inside[0].source_id == "z2"
    assert outside == []


def test_outside_points_get_distance_and_weight() -> None:
    rows = [dict(zip(_COL_NAMES, _make_row(1, "z1", 8.00, 52.02, inwoners=100), strict=True))]
    _, outside = classify_inside_outside(rows, _AOI_RING)
    assert outside[0].dist_to_aoi_m > 0
    assert 0.0 < _weight(outside[0].dist_to_aoi_m) < 1.0


def test_vertex_distance_m_is_zero_at_a_vertex() -> None:
    lon, lat = _AOI_RING[0]
    assert _vertex_distance_m(lon, lat, _AOI_RING) == pytest.approx(0.0, abs=1.0)


# ---------------------------------------------------------------------------
# reduce_within_aoi
# ---------------------------------------------------------------------------


def _points_in_a_line(n: int, start_lon: float = 6.00, step: float = 0.001) -> list[_Point]:
    points = []
    for i in range(n):
        points.append(
            _Point(
                row_id=i,
                lon=start_lon + i * step,
                lat=52.02,
                quantity=float(i + 1),
                sums=dict.fromkeys(CBS_COLS, 0.0),
                municipality_code="0150",
                source_id=f"z{i}",
            )
        )
    return points


def test_reduce_within_aoi_hits_target_count() -> None:
    points = _points_in_a_line(10)
    reduce_within_aoi(points, target_count=3)
    assert len({p.group_id for p in points}) == 3


def test_reduce_within_aoi_noop_when_already_at_or_below_target() -> None:
    points = _points_in_a_line(3)
    reduce_within_aoi(points, target_count=5)
    assert len({p.group_id for p in points}) == 3


def test_reduce_within_aoi_merges_smallest_quantity_first() -> None:
    # Point 0 has the smallest quantity (1.0) and point 1 is its nearest neighbour.
    points = _points_in_a_line(4)
    reduce_within_aoi(points, target_count=3)
    assert points[0].group_id == points[1].group_id
    assert points[2].group_id != points[0].group_id
    assert points[3].group_id != points[0].group_id


def test_reduce_within_aoi_preserves_total_quantity() -> None:
    points = _points_in_a_line(8)
    total_before = sum(p.quantity for p in points)
    reduce_within_aoi(points, target_count=2)
    zones = build_aggregated_zones(points, within_area_of_interest=True)
    # quantity itself isn't summed into AggregatedZone, but source lineage should
    # cover every original point exactly once.
    all_sources = sorted(sid for z in zones for sid in z.source_ids)
    assert all_sources == sorted(p.source_id for p in points)
    assert total_before > 0  # sanity: fixture actually has weight to merge by


# ---------------------------------------------------------------------------
# reduce_outside_aoi
# ---------------------------------------------------------------------------


def test_reduce_outside_aoi_hits_target_count() -> None:
    points = _points_in_a_line(10, start_lon=7.00)
    for p in points:
        p.dist_to_aoi_m = 5_000.0
    reduce_outside_aoi(points, target_count=4)
    assert len({p.group_id for p in points}) == 4


def test_reduce_outside_aoi_parks_unreachable_groups() -> None:
    # One point far away (beyond the corrected-distance search radius) from a
    # tight cluster of nearby points must not block the cluster from merging
    # down to its own target, nor loop forever.
    near = _points_in_a_line(5, start_lon=7.00, step=0.0005)
    far = _Point(
        row_id=100,
        lon=10.0,
        lat=52.02,
        quantity=1.0,
        sums=dict.fromkeys(CBS_COLS, 0.0),
        municipality_code="9999",
        source_id="far",
    )
    for p in near:
        p.dist_to_aoi_m = 5_000.0
    far.dist_to_aoi_m = 5_000.0
    points = [*near, far]
    reduce_outside_aoi(points, target_count=2)
    group_ids = {p.group_id for p in points}
    # The isolated point can never find an in-range partner, so it survives as
    # its own group even though the target asked for fewer groups overall.
    assert far.group_id in group_ids
    assert len(group_ids) >= 2


def test_reduce_outside_aoi_same_municipality_bonus_prefers_same_municipality() -> None:
    # Two equally-distant candidates; the same-municipality one should win.
    anchor = _Point(0, 7.000, 52.02, 1.0, dict.fromkeys(CBS_COLS, 0.0), "0150", "anchor")
    same_muni = _Point(1, 7.010, 52.02, 5.0, dict.fromkeys(CBS_COLS, 0.0), "0150", "same")
    other_muni = _Point(2, 6.990, 52.02, 5.0, dict.fromkeys(CBS_COLS, 0.0), "9999", "other")
    for p in (anchor, same_muni, other_muni):
        p.dist_to_aoi_m = 5_000.0
    points = [anchor, same_muni, other_muni]
    reduce_outside_aoi(points, target_count=2)
    assert anchor.group_id == same_muni.group_id
    assert anchor.group_id != other_muni.group_id


# ---------------------------------------------------------------------------
# build_aggregated_zones
# ---------------------------------------------------------------------------


def test_build_aggregated_zones_averages_position_and_sums_cols() -> None:
    a = _Point(
        0, 6.00, 52.00, 10.0, {**dict.fromkeys(CBS_COLS, 0.0), "inwoners": 100.0}, "0150", "a"
    )
    b = _Point(1, 6.02, 52.02, 5.0, {**dict.fromkeys(CBS_COLS, 0.0), "inwoners": 50.0}, "0150", "b")
    b.group_id = a.group_id
    zones = build_aggregated_zones([a, b], within_area_of_interest=True)
    assert len(zones) == 1
    zone = zones[0]
    assert zone.lon == pytest.approx(6.01)
    assert zone.lat == pytest.approx(52.01)
    assert zone.sums["inwoners"] == pytest.approx(150.0)
    assert sorted(zone.source_ids) == ["a", "b"]


# ---------------------------------------------------------------------------
# Production / attraction formulae
# ---------------------------------------------------------------------------


def test_calc_production_matches_zone_fetcher_formula() -> None:
    sums = {"huishoudens": 10.0, "inwoners": 20.0}
    assert _calc_production(sums) == pytest.approx((7.0 * 10.0 + 2.3 * 20.0) / 2.0)


def test_calc_attraction_matches_zone_fetcher_formula() -> None:
    sums = {
        "arbeidsplaatsen": 5.0,
        "leerlingplaatsen_basisonderwijs": 1.0,
        "leerlingplaatsen_middelbaaronderwijs": 2.0,
        "leerlingplaatsen_middelbaarberoepsonderwijs": 0.0,
        "leerlingplaatsen_hogeronderwijs": 0.0,
    }
    assert _calc_attraction(sums) == pytest.approx(2.0 * (5.0 + 1.0 + 2.0))


# ---------------------------------------------------------------------------
# rows_to_feature_collection — full pipeline, schema compatibility
# ---------------------------------------------------------------------------


def _build_sample_rows() -> list[tuple]:
    rows = []
    gid = 1
    # 6 centroids inside the AOI
    for i in range(6):
        rows.append(
            _make_row(gid, f"in{i}", 6.02 + i * 0.01, 52.02, inwoners=100 + i, arbeidsplaatsen=10)
        )
        gid += 1
    # 4 centroids outside the AOI
    for i in range(4):
        rows.append(
            _make_row(gid, f"out{i}", 6.50 + i * 0.01, 52.02, inwoners=50 + i, arbeidsplaatsen=5)
        )
        gid += 1
    return rows


def test_rows_to_feature_collection_schema_compatible_with_zone_fetcher() -> None:
    rows = _build_sample_rows()
    fc = rows_to_feature_collection(
        rows,
        _COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_within_target=2,
        zones_total_target=5,
    )

    assert fc["type"] == "FeatureCollection"
    assert fc["properties"]["areaId"] == _AREA_ID
    assert fc["properties"]["bbox"] == _BBOX

    study = [f for f in fc["features"] if f["properties"]["zoneClass"] == "STUDY"]
    influence = [f for f in fc["features"] if f["properties"]["zoneClass"] == "INFLUENCE"]
    area = [f for f in fc["features"] if f["properties"]["zoneClass"] == "AREA"]

    assert len(study) == 2
    assert len(influence) == 3  # zones_total_target(5) - studyCount(2)
    assert len(area) == 1
    assert fc["properties"]["studyCount"] == len(study)
    assert fc["properties"]["influenceCount"] == len(influence)

    # Fields consumed downstream by network_zone_joiner / feedlink_fetcher
    # (gid, zoneId, zoneClass, centroidLon, centroidLat, production, attraction)
    # must be present on every non-AREA feature.
    for feat in study + influence:
        props = feat["properties"]
        for key in (
            "gid",
            "zoneId",
            "zoneClass",
            "centroidLon",
            "centroidLat",
            "production",
            "attraction",
        ):
            assert key in props
        assert feat["geometry"]["type"] == "Point"

    # gids are unique across the whole collection, and strictly negative so
    # they can never collide with a real CBS zone gid downstream (see comment
    # in rows_to_feature_collection).
    gids = [f["properties"]["gid"] for f in study + influence]
    assert len(gids) == len(set(gids))
    assert all(g < 0 for g in gids)

    # AREA geometry is exactly the AOI ring (no convex-hull approximation).
    assert area[0]["geometry"] == {"type": "Polygon", "coordinates": [_AOI_RING]}
    assert area[0]["properties"]["zoneId"] == _AREA_ID

    assert fc["properties"]["fields"] == list(ZONE_FETCHER_AGGREGATED_PROPERTIES)


def test_rows_to_feature_collection_carries_source_zone_lineage() -> None:
    rows = _build_sample_rows()
    fc = rows_to_feature_collection(
        rows, _COL_NAMES, _AREA_ID, _BBOX, _AOI_RING, zones_within_target=1, zones_total_target=2
    )
    study = [f for f in fc["features"] if f["properties"]["zoneClass"] == "STUDY"]
    assert len(study) == 1
    # All 6 "inside" source rows were merged into the single STUDY zone.
    assert sorted(study[0]["properties"]["sourceZoneIds"]) == sorted(f"in{i}" for i in range(6))
