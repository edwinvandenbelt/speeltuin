"""Pure-Python port of MobiliteitsScan's base-scenario centroid-aggregation
algorithm — no I/O, no boto3.

Source: ``nl.dat.mobscan.base.server.basescenario.create.CreateBaseScenario``
(archived at ``Mobiliteitsscan30/trunk/mobscan-base-server``). Greedily merges
fine-grained source centroids down to a target zone count, separately inside
and outside an area-of-interest (AOI) polygon, so zone density stays fine near
the AOI and coarsens with distance from it.

Deviations from the Java original (deliberate, documented at each point):

* Distance is computed with ``gmt_shared.geo_utils._flat_earth_dist_m``
  instead of a Web Mercator projection — equivalent at the kilometre scale
  this algorithm operates at, and consistent with how the rest of this
  codebase already measures distance (``feedlink_fetcher``,
  ``network_zone_joiner``).
* The "same neighbourhood/district/municipality" merge bonus collapses to a
  single "same municipality" tier, because ``d030_zones_met_centroids`` only
  exposes a municipality code (``gemeente_code``) — no buurt/wijk-level code.
* Java tracks per-row bookkeeping (zeroing out all-but-one row's inhabitant
  count per group, broadcasting a shared weight to every member) as a side
  effect of mutating a flat list. This port instead recomputes each group's
  total quantity/weight directly from its member rows every iteration, which
  is behaviourally equivalent (same merge order, same stopping conditions)
  and easier to follow/test.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from gmt_shared.geo import point_in_polygon
from gmt_shared.geo_utils import _flat_earth_dist_m

from gmt_zone_core.zone_fetcher_aggregated.domain.sql import CBS_COLS

# ---------------------------------------------------------------------------
# Tuned constants — ported verbatim from CreateBaseScenario.java
# ---------------------------------------------------------------------------

_MIN_WEIGHT_DISTANCE_M = 1_000.0
_MAX_WEIGHT_DISTANCE_M = 100_000.0
_WEIGHT_DISTANCE_DIVISOR_M = 50_000.0
_MAX_STALLED_ITERATIONS = 1_000
_MAX_CORRECTED_DISTANCE_M = 50_000.0
_DISTANCE_OFFSET_M = 16_000.0
_SAME_MUNICIPALITY_BONUS_M = -5_000.0


@dataclass
class _Point:
    """One original source centroid. Position is immutable; ``group_id``
    (MobiliteitsScan's ``newId``) is mutated as rows get merged together."""

    row_id: int
    lon: float
    lat: float
    quantity: float  # inwoners + arbeidsplaatsen — merge-priority / weight basis
    sums: dict[str, float]  # CBS_COLS values, summed per group on output
    municipality_code: str | None
    source_id: str
    dist_to_aoi_m: float = 0.0
    group_id: int = field(init=False)

    def __post_init__(self) -> None:
        self.group_id = self.row_id


def _row_quantity(row: dict) -> float:
    """inwoners + arbeidsplaatsen — mirrors Java's ``1 + inhabitants + workplaces``
    merge-priority basis (the ``+1`` only matters there to make a zero-population
    centroid non-zero; here zero-quantity centroids are dropped outright, see
    ``classify_inside_outside``)."""
    return float(row.get("inwoners") or 0.0) + float(row.get("arbeidsplaatsen") or 0.0)


def _vertex_distance_m(lon: float, lat: float, ring: list[list[float]]) -> float:
    """Minimum distance from ``(lon, lat)`` to any vertex of *ring*.

    Mirrors ``AreaOfInterestPolygon.minimalDistanceToVertices`` — distance to
    the nearest *corner*, not the nearest edge point. Exact for the
    rectangular bbox AOI used today (4 corners); a reasonable approximation
    for an arbitrary polygon AOI in the future.
    """
    return min(float(_flat_earth_dist_m(lon, lat, v[0], v[1])) for v in ring)


def _weight(dist_m: float) -> float:
    d = min(max(dist_m, _MIN_WEIGHT_DISTANCE_M), _MAX_WEIGHT_DISTANCE_M)
    return 1.0 - math.tanh(d / _WEIGHT_DISTANCE_DIVISOR_M)


def _distance_m(a: _Point, b: _Point) -> float:
    return float(_flat_earth_dist_m(a.lon, a.lat, b.lon, b.lat))


def classify_inside_outside(
    rows: list[dict], aoi_ring: list[list[float]]
) -> tuple[list[_Point], list[_Point]]:
    """Split raw source rows into (inside AOI, outside AOI) points.

    Rows with zero inhabitants+jobs are dropped up front — MobiliteitsScan
    never aggregates "empty" centroids (``getInhabitants() > 0`` guards in
    ``initializeCentroids``); they would only ever contribute zero
    production/attraction anyway.
    """
    inside: list[_Point] = []
    outside: list[_Point] = []
    for row_id, row in enumerate(rows):
        quantity = _row_quantity(row)
        if quantity <= 0.0:
            continue
        lon = float(row["centroidLon"])
        lat = float(row["centroidLat"])
        sums = {c: float(row.get(c) or 0.0) for c in CBS_COLS}
        source_id = str(row.get("zoneId") or row.get("gid") or row_id)
        point = _Point(
            row_id=row_id,
            lon=lon,
            lat=lat,
            quantity=quantity,
            sums=sums,
            municipality_code=row.get("municipalityCode"),
            source_id=source_id,
        )
        if point_in_polygon(lon, lat, aoi_ring):
            inside.append(point)
        else:
            point.dist_to_aoi_m = _vertex_distance_m(lon, lat, aoi_ring)
            outside.append(point)
    return inside, outside


def _group_totals(points: list[_Point]) -> dict[int, float]:
    totals: dict[int, float] = {}
    for p in points:
        totals[p.group_id] = totals.get(p.group_id, 0.0) + p.quantity
    return totals


def _merge_groups(points: list[_Point], keep_id: int, drop_id: int) -> None:
    for p in points:
        if p.group_id == drop_id:
            p.group_id = keep_id


def reduce_within_aoi(points: list[_Point], target_count: int) -> None:
    """Merge *points* (mutated in place via ``group_id``) down to at most
    *target_count* groups.

    Repeatedly merges the group with the fewest inhabitants+jobs into its
    nearest neighbouring point (plain distance) — port of
    ``reduceNumberOfAggregatedCentroidsWithinAreaOfInterest``.
    """
    while points:
        group_quantity = _group_totals(points)
        if len(group_quantity) <= target_count or len(group_quantity) < 2:
            break

        smallest_id = min(group_quantity, key=lambda gid: group_quantity[gid])
        anchor = next(p for p in points if p.group_id == smallest_id)
        nearest = min(
            (p for p in points if p.group_id != smallest_id),
            key=lambda p: _distance_m(anchor, p),
        )
        _merge_groups(points, keep_id=smallest_id, drop_id=nearest.group_id)


def _group_weight(points: list[_Point]) -> dict[int, float]:
    totals: dict[int, float] = {}
    for p in points:
        totals[p.group_id] = totals.get(p.group_id, 0.0) + _weight(p.dist_to_aoi_m)
    return totals


def _corrected_distance_m(a: _Point, b: _Point) -> float:
    distance = _distance_m(a, b) + _DISTANCE_OFFSET_M
    if a.municipality_code is not None and a.municipality_code == b.municipality_code:
        distance += _SAME_MUNICIPALITY_BONUS_M
    return distance


def reduce_outside_aoi(points: list[_Point], target_count: int) -> None:
    """Merge *points* (mutated in place via ``group_id``) down to at most
    *target_count* groups.

    Port of ``reduceNumberOfAggregatedCentroidsOutsideAreaOfInterest``: the
    group with the smallest distance-decay weight is merged into whichever
    other point has the smallest "corrected" distance (plain distance, minus
    a bonus for sharing a municipality) among candidates closer than
    ``_MAX_CORRECTED_DISTANCE_M``. A group with no such candidate is "parked"
    (treated as infinite weight) so the next-smallest group gets tried
    instead, without re-attempting the stuck group forever. Stops at the
    target count or after ``_MAX_STALLED_ITERATIONS`` iterations without
    progress (safety valve ported from the original).
    """
    parked: set[int] = set()
    previous_count = -1
    stalled_iterations = 0
    while True:
        group_weight = _group_weight(points)
        for gid in parked:
            if gid in group_weight:
                group_weight[gid] = math.inf
        count = len(group_weight)
        if count == previous_count:
            stalled_iterations += 1
        else:
            stalled_iterations = 0
            previous_count = count

        if count <= target_count or count < 2 or stalled_iterations > _MAX_STALLED_ITERATIONS:
            break

        smallest_id = min(group_weight, key=lambda gid: group_weight[gid])
        anchor = next(p for p in points if p.group_id == smallest_id)
        candidates = [
            (p, _corrected_distance_m(anchor, p)) for p in points if p.group_id != smallest_id
        ]
        in_range = [(p, d) for p, d in candidates if d < _MAX_CORRECTED_DISTANCE_M]
        if not in_range:
            parked.add(smallest_id)
            continue
        nearest, _ = min(in_range, key=lambda pd: pd[1])
        _merge_groups(points, keep_id=smallest_id, drop_id=nearest.group_id)
        parked.discard(smallest_id)


@dataclass
class AggregatedZone:
    """One output zone: the result of merging one or more source points."""

    lon: float
    lat: float
    sums: dict[str, float]
    source_ids: list[str]
    within_area_of_interest: bool


def build_aggregated_zones(
    points: list[_Point], *, within_area_of_interest: bool
) -> list[AggregatedZone]:
    """Collapse *points* into one :class:`AggregatedZone` per remaining group.

    Position is the plain (unweighted) average of member positions and CBS
    columns are summed — port of ``createAggregatedCentroids``.
    """
    groups: dict[int, list[_Point]] = {}
    for p in points:
        groups.setdefault(p.group_id, []).append(p)

    zones: list[AggregatedZone] = []
    for members in groups.values():
        lon = sum(m.lon for m in members) / len(members)
        lat = sum(m.lat for m in members) / len(members)
        sums = {c: sum(m.sums[c] for m in members) for c in CBS_COLS}
        source_ids = [m.source_id for m in members]
        zones.append(
            AggregatedZone(
                lon=lon,
                lat=lat,
                sums=sums,
                source_ids=source_ids,
                within_area_of_interest=within_area_of_interest,
            )
        )
    return zones
