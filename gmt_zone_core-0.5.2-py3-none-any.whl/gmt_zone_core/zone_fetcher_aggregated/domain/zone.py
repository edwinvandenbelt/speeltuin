"""Aggregated-zone row/feature assembly for zone_fetcher_aggregated — no I/O.

Converts the ``AggregatedZone`` groups produced by ``domain/aggregate.py``
into a GeoJSON FeatureCollection with the same STUDY/INFLUENCE/AREA schema
``zone_fetcher`` produces, so it is a drop-in alternative input for
``network_zone_joiner`` and ``feedlink_fetcher``.
"""

from __future__ import annotations

from gmt_zone_core.zone_fetcher_aggregated.domain.aggregate import (
    AggregatedZone,
    _Point,
    build_aggregated_zones,
    classify_inside_outside,
    reduce_outside_aoi,
    reduce_within_aoi,
)
from gmt_zone_core.zone_fetcher_aggregated.domain.sql import (
    CBS_COLS,
    CENTROID_FETCH_PROPERTIES,
)

# ---------------------------------------------------------------------------
# Production / attraction formulae — duplicated from zone_fetcher.domain.zone
# (itself inherited from the retired zone_intersector), applied to the SUMMED
# CBS columns of every source centroid absorbed into a zone.
# ---------------------------------------------------------------------------

_LEERLING_COLS: tuple[str, ...] = (
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)


def _calc_production(sums: dict[str, float]) -> float:
    """production = (7 x huishoudens + 2.3 x inwoners) / 2"""
    huishoudens = sums.get("huishoudens", 0.0)
    inwoners = sums.get("inwoners", 0.0)
    return (7.0 * huishoudens + 2.3 * inwoners) / 2.0


def _calc_attraction(sums: dict[str, float]) -> float:
    """attraction = 2 x (arbeidsplaatsen + sum(leerlingplaatsen_*))"""
    arbeidsplaatsen = sums.get("arbeidsplaatsen", 0.0)
    leerling = sum(sums.get(c, 0.0) for c in _LEERLING_COLS)
    return 2.0 * (arbeidsplaatsen + leerling)


# Output property keys present on every STUDY / INFLUENCE feature.
ZONE_FETCHER_AGGREGATED_PROPERTIES: tuple[str, ...] = (
    "gid",
    "zoneId",
    "zoneClass",
    "zoneClassCode",
    "centroidLon",
    "centroidLat",
    "production",
    "attraction",
    "sourceZoneIds",
    *CBS_COLS,
)

_ZONE_CLASS_CODE: dict[str, int] = {"STUDY": 1, "INFLUENCE": 2}


def _aggregated_zone_to_feature(zone: AggregatedZone, gid: int, area_id: str) -> dict:
    zone_class = "STUDY" if zone.within_area_of_interest else "INFLUENCE"
    props: dict = {
        "gid": gid,
        "zoneId": f"{area_id}-{zone_class.lower()}-{gid}",
        "zoneClass": zone_class,
        "zoneClassCode": _ZONE_CLASS_CODE[zone_class],
        "centroidLon": zone.lon,
        "centroidLat": zone.lat,
        "production": _calc_production(zone.sums),
        "attraction": _calc_attraction(zone.sums),
        "sourceZoneIds": zone.source_ids,
    }
    for col in CBS_COLS:
        props[col] = zone.sums.get(col, 0.0)
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [zone.lon, zone.lat]},
        "properties": props,
    }


def _build_area_feature(aoi_ring: list[list[float]], area_id: str) -> dict:
    """Build the ``zoneClass = 'AREA'`` feature directly from the AOI ring —
    no convex-hull approximation needed, since the AOI polygon is already
    known up front (unlike ``zone_fetcher``, which only learns the study
    area's extent after fetching zones)."""
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [aoi_ring]},
        "properties": {"zoneId": area_id, "zoneClass": "AREA"},
    }


def rows_to_feature_collection(
    rows: list,
    col_names: list[str],
    area_id: str,
    bbox: list[float],
    aoi_ring: list[list[float]],
    *,
    zones_within_target: int,
    zones_total_target: int,
) -> dict:
    """Convert raw Databricks centroid rows into an aggregated GeoJSON FeatureCollection.

    Parameters
    ----------
    rows, col_names:
        Raw row tuples (and matching column names) from
        ``domain.sql.build_fetch_centroids_sql``.
    area_id:
        Identifier stored as ``FeatureCollection.id`` and used to build the
        AREA feature's ``zoneId`` plus every zone's synthetic ``zoneId``.
    bbox:
        Normalised ``[lon_min, lat_min, lon_max, lat_max]``, stored in
        ``FeatureCollection.properties.bbox`` for parity with ``zone_fetcher``.
    aoi_ring:
        Closed ``[lon, lat]`` ring — the area-of-interest polygon, built from
        *bbox* by ``domain.sql.bbox_to_polygon_ring`` (a bbox is a simplified
        4-point polygon). Used both to classify source centroids as
        inside/outside the AOI and, unmodified, as the AREA feature geometry.
    zones_within_target:
        Target number of STUDY zones to aggregate down to inside the AOI
        (MobiliteitsScan's ``zonesstudiegebied``).
    zones_total_target:
        Target total number of zones (STUDY + INFLUENCE). The INFLUENCE
        target is ``max(zones_total_target - studyCount, 0)``
        (MobiliteitsScan's ``zonestotaal``).

    Returns
    -------
    dict
        GeoJSON FeatureCollection with STUDY, INFLUENCE, and AREA features,
        schema-compatible with ``zone_fetcher``'s output.
    """
    raw_rows = [dict(zip(col_names, row, strict=True)) for row in rows]

    inside, outside = classify_inside_outside(raw_rows, aoi_ring)
    reduce_within_aoi(inside, zones_within_target)

    study_count = len({p.group_id for p in inside}) if inside else 0
    influence_target = max(zones_total_target - study_count, 0)
    reduce_outside_aoi(outside, influence_target)

    study_zones = build_aggregated_zones(inside, within_area_of_interest=True)
    influence_zones = build_aggregated_zones(outside, within_area_of_interest=False)

    # gid is negative here, deliberately: real CBS zone gids (as queried by
    # build_fetch_centroids_sql / zone_fetcher) are always positive surrogate
    # keys from d030_zones_met_centroids. Keeping our synthetic, per-call gids
    # strictly negative guarantees they can never collide with a real zone's
    # gid, so any downstream voedingslinks lookup keyed on gid (e.g.
    # feedlink_fetcher) naturally finds zero rows for these zones instead of
    # spuriously matching an unrelated real zone and producing a feedlink to
    # the wrong network node.
    features: list[dict] = []
    gid = -1
    for zone in study_zones + influence_zones:
        features.append(_aggregated_zone_to_feature(zone, gid, area_id))
        gid -= 1

    features.append(_build_area_feature(aoi_ring, area_id))

    return {
        "type": "FeatureCollection",
        "id": area_id,
        "features": features,
        "properties": {
            "areaId": area_id,
            "bbox": bbox,
            "studyCount": len(study_zones),
            "influenceCount": len(influence_zones),
            "zonesWithinTarget": zones_within_target,
            "zonesTotalTarget": zones_total_target,
            "fields": list(ZONE_FETCHER_AGGREGATED_PROPERTIES),
        },
    }


__all__ = [
    "CENTROID_FETCH_PROPERTIES",
    "ZONE_FETCHER_AGGREGATED_PROPERTIES",
    "_Point",
    "_calc_attraction",
    "_calc_production",
    "rows_to_feature_collection",
]
