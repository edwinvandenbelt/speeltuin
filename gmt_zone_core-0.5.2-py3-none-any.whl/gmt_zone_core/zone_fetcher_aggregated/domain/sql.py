"""SQL construction for zone_fetcher_aggregated — no I/O, no boto3.

Unlike ``zone_fetcher`` (which classifies pre-chopped CBS zone polygons as
STUDY/INFLUENCE by bbox overlap), this module fetches every CBS buurt
*centroid* within a search radius of the bbox centre, with no overlap
filtering or BFS pruning — the Python-side aggregation algorithm in
``domain/aggregate.py`` decides how many zones to keep and how to merge them.

The returned SQL has **two** positional ``?`` placeholders, in order:
    1. bbox GeoJSON polygon string (used to locate the search centre)
    2. search radius in metres

Only centroid positions and the additive CBS demographic columns are
selected — no zone polygon geometry is needed, because the aggregated
output represents each zone as a point (see ``domain/zone.py``).
"""

from __future__ import annotations

import json

# Additive CBS demographic columns — identical to zone_fetcher._CBS_COLS /
# zone_intersector._CBS_COLS, duplicated here per this repo's convention of
# keeping sibling modules independently deployable rather than cross-importing.
CBS_COLS: tuple[str, ...] = (
    "inwoners",
    "huishoudens",
    "arbeidsplaatsen",
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)

# Output property keys present on every fetched source-centroid row, in the
# exact order ``build_fetch_centroids_sql``'s SELECT list returns them.
CENTROID_FETCH_PROPERTIES: tuple[str, ...] = (
    "gid",
    "zoneId",
    "zoneName",
    "municipalityCode",
    "municipalityName",
    *CBS_COLS,
    "centroidLon",
    "centroidLat",
)

_CBS_SELECT = ",\n        ".join(f"z.{c}" for c in CBS_COLS)


def build_fetch_centroids_sql(catalog: str, schema: str) -> str:
    """Return the centroid-fetch SQL for *catalog* and *schema*.

    Placeholders (in order)
    -----------------------
    1. bbox GeoJSON polygon string (search centre)
    2. search radius in metres

    Schema differences
    ------------------
    Same geometry-column handling as ``zone_fetcher.domain.sql.build_fetch_zones_sql``:
    ``2024_01`` stores native ``geometry(4326)``/RD columns; other schemas store
    EWKB blobs in RD (EPSG:28992).
    """
    db = f"`{catalog}`.`{schema}`"

    if schema == "2024_01":
        _centroid_geom_rd = "z.centroid_geometrie_28992"
        _centroid_geom_4326 = "ST_Transform(z.centroid_geometrie_28992, 4326)"
    else:
        _centroid_geom_rd = "ST_GeomFromEWKB(z.centroid_geometrie)"
        _centroid_geom_4326 = "ST_Transform(ST_GeomFromEWKB(z.centroid_geometrie), 4326)"

    return f"""\
WITH
bbox_rd AS (
    SELECT ST_Transform(ST_GeomFromGeoJSON(?), 28992) AS poly
),

bbox_centroid_rd AS (
    SELECT ST_Centroid(poly) AS pt FROM bbox_rd
)

SELECT
    z.gid,
    z.zone_id                                      AS zoneId,
    z.zone_naam                                     AS zoneName,
    z.gemeente_code                                 AS municipalityCode,
    z.gemeente_naam                                 AS municipalityName,
    {_CBS_SELECT},
    ST_X(ST_Centroid({_centroid_geom_4326}))        AS centroidLon,
    ST_Y(ST_Centroid({_centroid_geom_4326}))        AS centroidLat
FROM   {db}.d030_zones_met_centroids z
CROSS JOIN bbox_centroid_rd
WHERE  ST_DWithin({_centroid_geom_rd}, bbox_centroid_rd.pt, ?)
"""


def bbox_to_polygon_json(bbox: list[float]) -> str:
    """Convert ``[lon_min, lat_min, lon_max, lat_max]`` to a GeoJSON Polygon string."""
    lon_min, lat_min, lon_max, lat_max = bbox[0], bbox[1], bbox[2], bbox[3]
    coords = [
        [lon_min, lat_min],
        [lon_max, lat_min],
        [lon_max, lat_max],
        [lon_min, lat_max],
        [lon_min, lat_min],
    ]
    return json.dumps({"type": "Polygon", "coordinates": [coords]})


def bbox_to_polygon_ring(bbox: list[float]) -> list[list[float]]:
    """Convert ``[lon_min, lat_min, lon_max, lat_max]`` to a closed ``[lon, lat]`` ring.

    This is the area-of-interest polygon used by ``domain.aggregate`` for the
    inside/outside classification and, unmodified, as the geometry of the
    output AREA feature.
    """
    lon_min, lat_min, lon_max, lat_max = bbox[0], bbox[1], bbox[2], bbox[3]
    return [
        [lon_min, lat_min],
        [lon_max, lat_min],
        [lon_max, lat_max],
        [lon_min, lat_max],
        [lon_min, lat_min],
    ]
