"""Pure-Python zone_refiner core — no I/O, no boto3, no external deps.

Splits each STUDY/INFLUENCE zone in a GeoJSON FeatureCollection into exactly
two sub-zones by cutting along the dominant road inside the zone.

Algorithm
---------
For every STUDY or INFLUENCE zone feature:

1.  Collect all network links that have any portion inside the zone polygon.
    Compute the clipped road length (metres) inside the zone for each link.

2.  Select the *dominant split line*: the network link whose clipped portion
    is longest.  Extend its direction vector to both sides until it intersects
    the zone boundary at exactly two points.

3.  Split the zone polygon ring at those two intersection points, producing
    two sub-rings (ring_a and ring_b).

4.  Compute the total road length inside each sub-ring using the same
    clip-and-sum approach.

5.  Distribute all numeric zone properties (``production``, ``attraction``,
    and all CBS demographic columns) proportionally by road length.
    If neither sub-zone contains any road metres, the split is 50/50.

6.  Assign each sub-zone a fresh UUID ``zoneId`` and record the original
    ``zoneId`` in a new ``parentZoneId`` property.
    ``centroidLon`` / ``centroidLat`` are recomputed from the new polygon.
    ``fromNodeProportions`` / ``toNodeProportions`` are cleared (they become
    stale once the zone geometry changes; the downstream pipeline recomputes
    them in the network_zone_joiner step).

AREA, BOUNDARY, and PEDESTRIAN zone features are passed through unchanged.
Zones for which no valid split line can be found are also passed through
unchanged (a WARNING is logged).

Public API
----------
refine_zones(zones_fc, network_fc) -> tuple[dict, dict]
    Returns ``(refined_zones_fc, stats)``.
    stats keys: ``inputZones``, ``outputZones``, ``splitZones``, ``unsplitZones``.
"""

from __future__ import annotations

import logging
import math
import uuid

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_M_PER_DEG_LAT = 111_320.0  # metres per degree latitude (approximately)

#: Zone classes eligible for splitting.
_SPLITTABLE_CLASSES = frozenset({"STUDY", "INFLUENCE"})

#: Properties that are NOT multiplied by the road-length fraction.
#: ``centroidLon`` / ``centroidLat`` are excluded here because the caller
#: overwrites them with the centroid of the new polygon after splitting.
_NON_SCALED_PROPS = frozenset(
    {
        "zoneId",
        "parentZoneId",
        "zoneClass",
        "zoneClassCode",
        "zoneName",
        "municipalityCode",
        "municipalityName",
        "centroidLon",
        "centroidLat",
        "fromNodeProportions",
        "toNodeProportions",
        "gid",
    }
)

# ---------------------------------------------------------------------------
# Low-level geometry helpers  (stdlib only — no external dependencies)
# ---------------------------------------------------------------------------


def _seg_length_m(ax: float, ay: float, bx: float, by: float) -> float:
    """Approximate WGS-84 distance in metres using a flat-earth model."""
    dlat = (by - ay) * _M_PER_DEG_LAT
    mid_lat = (ay + by) / 2.0
    dlon = (bx - ax) * _M_PER_DEG_LAT * math.cos(math.radians(mid_lat))
    return math.sqrt(dlat * dlat + dlon * dlon)


def _ring_bbox_size(ring: list) -> float:
    """Return the larger of the ring's bounding-box width and height in degrees."""
    lons = [p[0] for p in ring]
    lats = [p[1] for p in ring]
    return max(max(lons) - min(lons), max(lats) - min(lats))


def _segment_intersect_t(
    ax: float,
    ay: float,
    bx: float,
    by: float,
    cx: float,
    cy: float,
    dx: float,
    dy: float,
) -> float | None:
    """Return parametric *t* of the intersection of segment A→B with C→D.

    Both *t* (on A→B) and *u* (on C→D) must lie in [0, 1] for a valid
    intersection.  Returns ``None`` when no valid intersection exists.
    """
    denom = (bx - ax) * (dy - cy) - (by - ay) * (dx - cx)
    if abs(denom) < 1e-15:
        return None
    t = ((cx - ax) * (dy - cy) - (cy - ay) * (dx - cx)) / denom
    u = ((cx - ax) * (by - ay) - (cy - ay) * (bx - ax)) / denom
    if 0.0 <= t <= 1.0 and 0.0 <= u <= 1.0:
        return t
    return None


def _intersections_with_ring_indexed(
    ax: float,
    ay: float,
    bx: float,
    by: float,
    ring: list,
) -> list[tuple[float, float, float, int]]:
    """Return ``(t, ix, iy, edge_k)`` for all intersections of A→B with *ring*.

    *t*      — parametric position along A→B (0 = A, 1 = B).
    *ix, iy* — intersection coordinates.
    *edge_k* — ring edge index; the hit lies on ``ring[k] → ring[k+1]``.

    Results are sorted by *t* and deduplicated (tolerance 1e-10).
    """
    hits: list[tuple[float, float, float, int]] = []
    n = len(ring)
    for k in range(n - 1):
        cx, cy = ring[k][0], ring[k][1]
        dx, dy = ring[k + 1][0], ring[k + 1][1]
        t = _segment_intersect_t(ax, ay, bx, by, cx, cy, dx, dy)
        if t is not None:
            ix = ax + t * (bx - ax)
            iy = ay + t * (by - ay)
            hits.append((t, ix, iy, k))
    hits.sort(key=lambda h: h[0])
    deduped: list[tuple[float, float, float, int]] = []
    for hit in hits:
        if deduped and abs(hit[0] - deduped[-1][0]) < 1e-10:
            continue
        deduped.append(hit)
    return deduped


def _point_in_polygon(px: float, py: float, ring: list) -> bool:
    """Ray-casting point-in-polygon test for a closed GeoJSON ring."""
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > py) != (yj > py):
            if px < (xj - xi) * (py - yi) / (yj - yi) + xi:
                inside = not inside
        j = i
    return inside


def _clip_length_in_ring(coords: list, ring: list) -> float:
    """Return the total length in metres of *coords* clipped to *ring*.

    Uses a single-pass inside-tracking algorithm: the inside/outside state
    is tracked across segments, toggling at each ring-boundary intersection.
    """
    if len(coords) < 2:
        return 0.0
    total = 0.0
    cur_inside = _point_in_polygon(coords[0][0], coords[0][1], ring)
    for seg_i in range(len(coords) - 1):
        ax, ay = coords[seg_i][0], coords[seg_i][1]
        bx, by = coords[seg_i + 1][0], coords[seg_i + 1][1]
        hits = _intersections_with_ring_indexed(ax, ay, bx, by, ring)
        last_x, last_y = ax, ay
        for _t, ix, iy, _ek in hits:
            if cur_inside:
                total += _seg_length_m(last_x, last_y, ix, iy)
            last_x, last_y = ix, iy
            cur_inside = not cur_inside
        if cur_inside:
            total += _seg_length_m(last_x, last_y, bx, by)
    return total


def _find_split_hits(
    ring: list,
    link_coords: list,
) -> tuple[tuple, tuple] | None:
    """Find two ring-boundary crossings for splitting *ring* along *link_coords*.

    Extends the link's direction vector far beyond the ring so that the
    extended line is guaranteed to cross the boundary.  Returns
    ``(hit1, hit2)`` — each is ``(t, ix, iy, edge_k)`` — or ``None`` when
    fewer than two crossings are found.

    When the extended line crosses the ring at more than two points (concave
    zone), the first and last crossing are used, giving the widest possible
    chord.
    """
    if len(link_coords) < 2:
        return None
    ax, ay = link_coords[0][0], link_coords[0][1]
    bx, by = link_coords[-1][0], link_coords[-1][1]
    dx = bx - ax
    dy = by - ay
    seg_len_deg = math.sqrt(dx * dx + dy * dy)
    if seg_len_deg < 1e-10:
        return None

    # Normalise to unit vector in degree space.
    dx /= seg_len_deg
    dy /= seg_len_deg

    # Midpoint of the link.
    mx = (ax + bx) / 2.0
    my = (ay + by) / 2.0

    # Extend 20× the larger bbox dimension in both directions.
    bbox_size = _ring_bbox_size(ring)
    k = max(bbox_size * 20.0, 1e-4)

    x0, y0 = mx - k * dx, my - k * dy
    x1, y1 = mx + k * dx, my + k * dy

    hits = _intersections_with_ring_indexed(x0, y0, x1, y1, ring)
    if len(hits) < 2:
        return None
    return (hits[0], hits[-1])


def _split_ring_by_chord(
    ring: list,
    hit1: tuple,
    hit2: tuple,
) -> tuple[list, list] | tuple[None, None]:
    """Split *ring* at two boundary intersection points into two sub-rings.

    Parameters
    ----------
    ring:
        Closed polygon ring ``[[x, y], ..., [x, y]]`` with
        ``ring[0] == ring[-1]``.
    hit1, hit2:
        Each is ``(t, ix, iy, edge_k)`` from
        ``_intersections_with_ring_indexed``.

    Returns
    -------
    (ring_a, ring_b)
        Two new closed rings, or ``(None, None)`` when the split is
        degenerate (both hits on the same edge, or either result would
        have fewer than 3 unique vertices).

    Ring construction
    -----------------
    Given intersection points P1 (on edge e1) and P2 (on edge e2) with
    e1 < e2::

        ring_a = [P1] + ring[e1+1 : e2+1] + [P2] + [P1]   (short path)
        ring_b = [P2] + ring[e2+1 : n]                     (long path)
               + ring[0 : e1+1] + [P1] + [P2]
    """
    _, x1, y1, e1 = hit1
    _, x2, y2, e2 = hit2

    # Ensure e1 < e2; when equal but different t, compare t.
    if e1 > e2 or (e1 == e2 and hit1[0] > hit2[0]):
        x1, y1, e1, x2, y2, e2 = x2, y2, e2, x1, y1, e1

    if e1 == e2:
        # Both hits land on the same ring edge — degenerate.
        return None, None

    n = len(ring) - 1  # number of unique vertices (ring is closed: first == last)

    # Ring A: short path  P1 → … → P2 → P1
    ring_a: list = [[x1, y1]]
    for i in range(e1 + 1, e2 + 1):
        ring_a.append(list(ring[i]))
    ring_a.append([x2, y2])
    ring_a.append([x1, y1])  # close

    # Ring B: long path  P2 → … → P1 → P2
    ring_b: list = [[x2, y2]]
    for i in range(e2 + 1, n):
        ring_b.append(list(ring[i]))
    for i in range(0, e1 + 1):
        ring_b.append(list(ring[i]))
    ring_b.append([x1, y1])
    ring_b.append([x2, y2])  # close

    # Reject degenerate results (need at least 3 unique vertices + closing = 4 entries).
    if len(ring_a) < 4 or len(ring_b) < 4:
        return None, None

    return ring_a, ring_b


def _ring_centroid(ring: list) -> tuple[float, float]:
    """Compute the true centroid of a closed polygon ring via the shoelace formula.

    Works directly in WGS-84 degree space.  For the small polygons produced
    by zone splitting in the Netherlands the flat-earth error is negligible.
    Returns the arithmetic mean of unique vertices as a fallback for
    degenerate (zero-area) rings.
    """
    n = len(ring)
    if n < 3:
        return ring[0][0], ring[0][1]

    signed_area = 0.0
    cx = 0.0
    cy = 0.0
    for i in range(n - 1):
        xi, yi = ring[i][0], ring[i][1]
        xn, yn = ring[i + 1][0], ring[i + 1][1]
        cross = xi * yn - xn * yi
        signed_area += cross
        cx += (xi + xn) * cross
        cy += (yi + yn) * cross

    signed_area /= 2.0
    if abs(signed_area) < 1e-14:
        # Degenerate — arithmetic mean of unique vertices.
        pts = ring[:-1] if (ring[0][0] == ring[-1][0] and ring[0][1] == ring[-1][1]) else ring
        return (
            sum(p[0] for p in pts) / max(len(pts), 1),
            sum(p[1] for p in pts) / max(len(pts), 1),
        )

    cx /= 6.0 * signed_area
    cy /= 6.0 * signed_area
    return cx, cy


def _get_outer_ring(feature: dict) -> list | None:
    """Return the outer ring of a GeoJSON Polygon or MultiPolygon feature.

    For MultiPolygon, returns the ring of the largest sub-polygon (by vertex
    count).  Returns ``None`` for any other geometry type.
    """
    geom = feature.get("geometry") or {}
    gtype = geom.get("type", "")
    coords = geom.get("coordinates") or []
    if gtype == "Polygon":
        return coords[0] if coords else None
    if gtype == "MultiPolygon":
        if not coords:
            return None
        largest = max(coords, key=lambda poly: len(poly[0]) if poly else 0)
        return largest[0] if largest else None
    return None


def _scale_properties(
    props: dict,
    fraction: float,
    new_zone_id: str,
    parent_zone_id: str,
) -> dict:
    """Return a copy of *props* with numeric values scaled by *fraction*.

    Special handling:
    - ``zoneId``                  → replaced with *new_zone_id*
    - ``parentZoneId``            → set to *parent_zone_id* (always written)
    - ``fromNodeProportions``     → reset to ``{}`` (stale after geometry change)
    - ``toNodeProportions``       → reset to ``{}`` (stale after geometry change)
    - ``gid``                     → set to ``None`` (no Databricks row for derived zones)
    - ``centroidLon/Lat``         → copied as-is; the caller overwrites them
    - All other numeric (int/float, not bool) → multiplied by *fraction*
    - Strings, bools, ``None``    → copied unchanged
    """
    out: dict = {}
    for key, val in props.items():
        if key == "zoneId":
            out["zoneId"] = new_zone_id
        elif key in ("fromNodeProportions", "toNodeProportions"):
            out[key] = {}
        elif key == "gid":
            out["gid"] = None
        elif key in _NON_SCALED_PROPS:
            out[key] = val
        elif isinstance(val, (int, float)) and not isinstance(val, bool):
            out[key] = val * fraction
        else:
            out[key] = val
    out["parentZoneId"] = parent_zone_id
    return out


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def refine_zones(
    zones_fc: dict,
    network_fc: dict,
) -> tuple[dict, dict]:
    """Refine bike zones by splitting each STUDY/INFLUENCE zone into two sub-zones.

    Parameters
    ----------
    zones_fc:
        GeoJSON FeatureCollection of zone features.  Typically the
        ``*-ZONE-BIKE.geojson`` output of the GMT prepare pipeline.
    network_fc:
        GeoJSON FeatureCollection of directed network links (LineString).
        Used as the source of split-line candidates and for proportional
        road-length weighting.

    Returns
    -------
    (refined_zones_fc, stats)
        ``refined_zones_fc`` — all STUDY/INFLUENCE zones replaced by two
        sub-zones each; AREA and BOUNDARY features unchanged.

        ``stats`` — ``{"inputZones": int, "outputZones": int,
        "splitZones": int, "unsplitZones": int}``.

    Notes
    -----
    * ``fromNodeProportions`` and ``toNodeProportions`` are cleared on every
      split zone.  Re-run the ``network_zone_joiner`` step (or the full
      prepare pipeline) to recompute them for the new zone geometries.
    * Zones that cannot be split (no valid split line found, degenerate ring,
      etc.) are passed through unchanged; a WARNING is logged for each.
    """
    zone_features: list[dict] = zones_fc.get("features") or []
    net_features: list[dict] = network_fc.get("features") or []

    # Pre-extract link coordinate lists (LineString only).
    link_coords_list: list[list] = [
        feat["geometry"]["coordinates"]
        for feat in net_features
        if (feat.get("geometry") or {}).get("type") == "LineString"
        and len((feat.get("geometry") or {}).get("coordinates") or []) >= 2
    ]

    output_features: list[dict] = []
    split_zones = 0
    unsplit_zones = 0

    for feat in zone_features:
        props = feat.get("properties") or {}
        zone_class = props.get("zoneClass", "")

        if zone_class not in _SPLITTABLE_CLASSES:
            output_features.append(feat)
            continue

        ring = _get_outer_ring(feat)
        if not ring or len(ring) < 4:
            logger.warning(
                "Zone %s has no valid outer ring — skipping split",
                props.get("zoneId"),
            )
            output_features.append(feat)
            unsplit_zones += 1
            continue

        # ── Candidate split lines: links with any metres inside this zone ──
        candidates: list[tuple[float, list]] = []
        for coords in link_coords_list:
            clen = _clip_length_in_ring(coords, ring)
            if clen > 0.0:
                candidates.append((clen, coords))
        candidates.sort(key=lambda c: c[0], reverse=True)

        # ── Try each candidate until one yields a clean 2-point crossing ──
        split_hits: tuple | None = None
        for _, link_coords in candidates:
            hits = _find_split_hits(ring, link_coords)
            if hits is not None:
                split_hits = hits
                break

        if split_hits is None:
            logger.warning(
                "Zone %s: no valid split line found among %d candidate(s) — skipping",
                props.get("zoneId"),
                len(candidates),
            )
            output_features.append(feat)
            unsplit_zones += 1
            continue

        ring_a, ring_b = _split_ring_by_chord(ring, split_hits[0], split_hits[1])
        if ring_a is None:
            logger.warning(
                "Zone %s: ring split returned a degenerate polygon — skipping",
                props.get("zoneId"),
            )
            output_features.append(feat)
            unsplit_zones += 1
            continue
        assert ring_b is not None  # guaranteed: _split_ring_by_chord returns both or neither

        # ── Proportional road-length fractions ──
        len_a = sum(_clip_length_in_ring(coords, ring_a) for coords in link_coords_list)
        len_b = sum(_clip_length_in_ring(coords, ring_b) for coords in link_coords_list)
        total_len = len_a + len_b

        if total_len < 1e-6:
            frac_a, frac_b = 0.5, 0.5
        else:
            frac_a = len_a / total_len
            frac_b = len_b / total_len

        parent_id: str = props.get("zoneId") or ""

        # ── Sub-zone A ──
        new_id_a = str(uuid.uuid4())
        clon_a, clat_a = _ring_centroid(ring_a)
        props_a = _scale_properties(props, frac_a, new_id_a, parent_id)
        props_a["centroidLon"] = clon_a
        props_a["centroidLat"] = clat_a
        feat_a: dict = {
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [ring_a]},
            "properties": props_a,
        }

        # ── Sub-zone B ──
        new_id_b = str(uuid.uuid4())
        clon_b, clat_b = _ring_centroid(ring_b)
        props_b = _scale_properties(props, frac_b, new_id_b, parent_id)
        props_b["centroidLon"] = clon_b
        props_b["centroidLat"] = clat_b
        feat_b: dict = {
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [ring_b]},
            "properties": props_b,
        }

        output_features.extend([feat_a, feat_b])
        split_zones += 1
        logger.debug(
            "Zone %s → %s (%.0f%% road) + %s (%.0f%% road)",
            parent_id,
            new_id_a,
            frac_a * 100,
            new_id_b,
            frac_b * 100,
        )

    refined_fc: dict = {
        "type": "FeatureCollection",
        "features": output_features,
        "properties": dict(zones_fc.get("properties") or {}),
    }

    stats: dict = {
        "inputZones": len(zone_features),
        "outputZones": len(output_features),
        "splitZones": split_zones,
        "unsplitZones": unsplit_zones,
    }

    logger.info(
        "refine_zones: %d zones in → %d out  (%d split, %d unsplit)",
        stats["inputZones"],
        stats["outputZones"],
        split_zones,
        unsplit_zones,
    )
    return refined_fc, stats
