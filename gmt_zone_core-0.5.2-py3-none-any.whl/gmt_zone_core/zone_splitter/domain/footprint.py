"""Building floor-area estimation.

Ported from ``gmt-calculation-lib``'s ``osm.building_zone_creator.domain.footprint``
(deliberately duplicated rather than imported — ``gmt-zone-core`` has no
dependency on ``gmt-calculation-lib`` and must not gain one just for this
formula; see ``zone_splitter_core``'s module docstring).

Computes the ground-level footprint area (m²) of a building GeoJSON Feature
using a flat-Earth projection from WGS-84 coordinates, then scales it by the
feature's ``floorFraction`` property (as produced by
``osm_building_fetcher``) to obtain the registered floor area actually
attributable to this feature.

Public API
----------
building_footprint_m2(feature, ref_lat) -> float
    Shoelace-based footprint area in m² for a building GeoJSON Feature.
polygon_area_m2(coords, ref_lat) -> float
    Shoelace formula on flat-Earth projected polygon coordinates.
building_sqm(feature, ref_lat, default_floor_fraction=1.0) -> float
    ``building_footprint_m2(...) * floorFraction`` (default 1.0 when the
    property is absent).
"""

from __future__ import annotations

import math

_M_PER_DEG_LAT: float = 111_320.0  # metres per degree of latitude
_DEFAULT_FOOTPRINT_M2: float = 70.0  # assumed footprint for node (point) buildings


def polygon_area_m2(coords: list[list[float]], ref_lat: float) -> float:
    """Return the area in m² of a polygon given as a list of [lon, lat] pairs.

    Uses the shoelace formula applied to flat-Earth projected coordinates.
    The closing vertex (first == last) is handled transparently.

    Parameters
    ----------
    coords:
        List of ``[lon, lat]`` pairs forming the exterior ring.
    ref_lat:
        Reference latitude (decimal degrees) used for the longitude scale
        factor.  Typically the midpoint latitude of the zone being split.

    Returns
    -------
    float
        Area in m².  Returns 0.0 for degenerate inputs (< 3 points).
    """
    if len(coords) < 3:
        return 0.0

    m_per_deg_lon = _M_PER_DEG_LAT * math.cos(math.radians(ref_lat))

    # Convert to flat metres
    pts = [(c[0] * m_per_deg_lon, c[1] * _M_PER_DEG_LAT) for c in coords]

    # Shoelace
    n = len(pts)
    area = 0.0
    for i in range(n):
        j = (i + 1) % n
        area += pts[i][0] * pts[j][1]
        area -= pts[j][0] * pts[i][1]
    return abs(area) / 2.0


def building_footprint_m2(feature: dict, ref_lat: float = 52.0) -> float:
    """Return the footprint area in m² for a building GeoJSON Feature.

    For ``Polygon`` features the exterior ring is projected and the shoelace
    formula applied.  For ``Point`` features (OSM nodes) a fixed default
    footprint is returned.

    Parameters
    ----------
    feature:
        GeoJSON Feature dict (as produced by ``osm_building_fetcher``).
    ref_lat:
        Reference latitude in decimal degrees for the flat-Earth projection.
        Defaults to 52 °N (central Netherlands).

    Returns
    -------
    float
        Footprint area in m².
    """
    geom: dict = feature.get("geometry") or {}
    gtype = geom.get("type", "")

    if gtype == "Polygon":
        coords: list[list[float]] = geom.get("coordinates", [[]])[0]
        area = polygon_area_m2(coords, ref_lat)
        return area if area > 0.0 else _DEFAULT_FOOTPRINT_M2

    # Point / unknown → use default
    return _DEFAULT_FOOTPRINT_M2


def building_sqm(feature: dict, ref_lat: float, default_floor_fraction: float = 1.0) -> float:
    """Return the registered floor area (m²) of *feature*.

    ``floor_area_m2 = building_footprint_m2(feature, ref_lat) * floorFraction``,
    matching the convention already used by ``osm_building_fetcher``'s
    ``street_linker.py`` for weighting mixed-use buildings.  Falls back to
    *default_floor_fraction* (1.0) when the ``floorFraction`` property is
    absent.
    """
    footprint = building_footprint_m2(feature, ref_lat)
    props = feature.get("properties") or {}
    floor_fraction = props.get("floorFraction")
    ff = float(floor_fraction) if floor_fraction is not None else default_floor_fraction
    return footprint * ff
