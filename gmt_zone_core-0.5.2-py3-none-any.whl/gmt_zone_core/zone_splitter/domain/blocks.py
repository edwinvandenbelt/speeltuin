"""Road-following zone partitioning: polygonize a zone into street blocks and merge them.

The zone polygon is cut into *blocks* by the network's road geometry
(``unary_union`` + ``polygonize``, same technique as ``gmt-calculation-lib``'s
``osm.building_zone_creator.domain.block_builder``).  Every block boundary is
therefore either a road or the zone's own boundary.  Adjacent blocks are then
merged greedily into exactly *n* groups, balanced by a per-block weight
(registered building m², or area when the zone has no building data), so the
resulting sub-zone boundaries follow roads as much as possible.

All geometry work happens in a local flat-Earth metric projection (metres
around the zone's centroid) so area/length thresholds are meaningful; results
are converted back to WGS-84 GeoJSON.

Public API
----------
partition_zone(zone_geom, line_coords_list, building_points, n) -> list[dict] | None
    Split a zone geometry into at most *n* road-following groups.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field

import shapely
from shapely.geometry import LineString, MultiPolygon, Point, Polygon, shape
from shapely.ops import polygonize, unary_union
from shapely.strtree import STRtree

_M_PER_DEG_LAT = 111_320.0

# Lines are clipped to the zone grown by this many metres, so roads ending
# exactly on the zone boundary still get noded against it.
_CLIP_BUFFER_M = 1.0
# Blocks smaller than this (m²) — or this share of the zone area — are slivers
# (e.g. between a road and a zone edge that runs alongside it) and are merged
# into a neighbour before any balancing happens.
_SLIVER_MIN_M2 = 50.0
_SLIVER_ZONE_SHARE = 0.002
# Two blocks are adjacent when they share more than this length (m) of boundary.
_ADJACENCY_MIN_M = 0.5


@dataclass
class _Projection:
    """Local equirectangular projection around (lon0, lat0), in metres."""

    lon0: float
    lat0: float
    kx: float = field(init=False)

    def __post_init__(self) -> None:
        self.kx = _M_PER_DEG_LAT * math.cos(math.radians(self.lat0))

    def fwd(self, geom):
        return shapely.transform(
            geom,
            lambda c: (c - [self.lon0, self.lat0]) * [self.kx, _M_PER_DEG_LAT],
        )

    def inv(self, geom):
        return shapely.transform(
            geom,
            lambda c: c / [self.kx, _M_PER_DEG_LAT] + [self.lon0, self.lat0],
        )

    def point(self, lon: float, lat: float) -> Point:
        return Point((lon - self.lon0) * self.kx, (lat - self.lat0) * _M_PER_DEG_LAT)


@dataclass
class _Group:
    members: list[int]
    weight: float
    area: float


def _polygons(geom) -> list[Polygon]:
    """Return the non-empty Polygon parts of any shapely geometry."""
    if geom.is_empty:
        return []
    if isinstance(geom, Polygon):
        return [geom] if geom.area > 0 else []
    return [p for g in getattr(geom, "geoms", []) for p in _polygons(g)]


def _line_parts(geom) -> list[LineString]:
    """Return the LineString parts of any shapely geometry."""
    if geom.is_empty:
        return []
    if isinstance(geom, LineString):
        return [geom]
    return [p for g in getattr(geom, "geoms", []) for p in _line_parts(g)]


def _build_blocks(zone, lines: list[LineString]) -> list[Polygon]:
    """Cut *zone* (projected) into blocks along *lines* (projected)."""
    clip = zone.buffer(_CLIP_BUFFER_M)
    clipped = [ln.intersection(clip) for ln in lines]
    clipped = [g for g in clipped if not g.is_empty and g.length > 0]
    if not clipped:
        return _polygons(zone)
    merged = unary_union([*clipped, zone.boundary])
    blocks: list[Polygon] = []
    for face in polygonize(merged):
        blocks.extend(_polygons(face.intersection(zone)))
    # Faces of the thin ring between zone and clip buffer intersect the zone in
    # (near-)zero area; drop those numerical leftovers.
    return [b for b in blocks if b.area > 1e-3] or _polygons(zone)


def _adjacency(blocks: list[Polygon]) -> list[dict[int, float]]:
    """Return per-block ``{neighbour_index: shared_boundary_length_m}``."""
    tree = STRtree(blocks)
    adj: list[dict[int, float]] = [{} for _ in blocks]
    for i, block in enumerate(blocks):
        for j in tree.query(block.buffer(0.01)):
            j = int(j)
            if j <= i:
                continue
            shared = block.boundary.intersection(blocks[j].buffer(0.01)).length
            if shared > _ADJACENCY_MIN_M:
                adj[i][j] = shared
                adj[j][i] = shared
    return adj


def _merge_groups(
    blocks: list[Polygon],
    weights: list[float],
    n: int,
    zone_area: float,
) -> list[list[int]]:
    """Greedily merge adjacent blocks until exactly *n* groups remain (if possible)."""
    groups: dict[int, _Group] = {
        i: _Group([i], weights[i], blocks[i].area) for i in range(len(blocks))
    }
    adj = _adjacency(blocks)
    nbrs: dict[int, dict[int, float]] = {i: dict(a) for i, a in enumerate(adj)}
    sliver_area = max(_SLIVER_MIN_M2, _SLIVER_ZONE_SHARE * zone_area)

    def merge(src: int, dst: int) -> None:
        g_src, g_dst = groups.pop(src), groups[dst]
        g_dst.members.extend(g_src.members)
        g_dst.weight += g_src.weight
        g_dst.area += g_src.area
        for k, length in nbrs.pop(src).items():
            nbrs[k].pop(src, None)
            if k == dst:
                continue
            nbrs[dst][k] = nbrs[dst].get(k, 0.0) + length
            nbrs[k][dst] = nbrs[k].get(dst, 0.0) + length

    def nearest(src: int) -> int:
        geom = unary_union([blocks[m] for m in groups[src].members])
        others = [k for k in groups if k != src]
        return min(
            others,
            key=lambda k: geom.distance(unary_union([blocks[m] for m in groups[k].members])),
        )

    # 1. Slivers go to the neighbour they share the longest boundary with.
    while len(groups) > n:
        slivers = [k for k, g in groups.items() if g.area < sliver_area]
        if not slivers:
            break
        src = min(slivers, key=lambda k: groups[k].area)
        dst = max(nbrs[src], key=lambda k: nbrs[src][k]) if nbrs[src] else nearest(src)
        merge(src, dst)

    # 2. Balance: merge the lightest group into its lightest neighbour; ties
    #    (e.g. building-free blocks) go to the longest shared boundary.
    while len(groups) > n:
        src = min(groups, key=lambda k: (groups[k].weight, groups[k].area))
        if nbrs[src]:
            dst = min(
                nbrs[src],
                key=lambda k: (groups[k].weight, -nbrs[src][k], groups[k].area),
            )
        else:
            dst = nearest(src)
        merge(src, dst)

    return [g.members for g in groups.values()]


def _assign_sqm(blocks: list[Polygon], points: list[tuple[Point, float]]) -> list[float]:
    """Sum each building's m² into the block containing (or nearest to) its point."""
    sqm_per_block = [0.0] * len(blocks)
    if not points or not blocks:
        return sqm_per_block
    tree = STRtree(blocks)
    for pt, sqm in points:
        hits = tree.query(pt, predicate="intersects")
        idx = int(hits[0]) if len(hits) else int(tree.nearest(pt))
        sqm_per_block[idx] += sqm
    return sqm_per_block


def _bisect_largest(
    blocks: list[Polygon],
    weights: list[float],
    lines: list[LineString],
) -> bool:
    """Split the heaviest block in two along a straight cut (fallback for too few blocks).

    Cuts along the longest road inside the block when there is one, otherwise
    through the block's centroid perpendicular to its longest extent.
    Mutates *blocks* in place; returns ``False`` when no block could be split.
    """
    order = sorted(range(len(blocks)), key=lambda i: (weights[i], blocks[i].area), reverse=True)
    for i in order:
        block = blocks[i]
        cx, cy = block.centroid.x, block.centroid.y
        minx, miny, maxx, maxy = block.bounds
        reach = 4.0 * max(maxx - minx, maxy - miny, 1.0)
        # Roads strictly inside the block (those on its boundary already cut it).
        interior = block.buffer(-_ADJACENCY_MIN_M)
        inside = [
            part
            for ln in lines
            for part in _line_parts(ln.intersection(interior))
            if part.length > 0
        ]
        if inside:
            longest = max(inside, key=lambda g: g.length)
            (ax, ay), (bx, by) = longest.coords[0], longest.coords[-1]
            dx, dy = bx - ax, by - ay
        elif maxx - minx >= maxy - miny:
            dx, dy = 0.0, 1.0
        else:
            dx, dy = 1.0, 0.0
        norm = math.hypot(dx, dy)
        if norm == 0:
            continue
        dx, dy = dx / norm * reach, dy / norm * reach
        cutter = LineString([(cx - dx, cy - dy), (cx + dx, cy + dy)])
        parts = [
            p
            for face in polygonize(unary_union([block.boundary, cutter]))
            for p in _polygons(face.intersection(block))
        ]
        if len(parts) < 2:
            continue
        parts.sort(key=lambda p: p.area, reverse=True)
        a, rest = parts[0], unary_union(parts[1:])
        if rest.area < block.area * 1e-3:
            continue
        blocks[i] = a
        blocks.extend(_polygons(rest))
        return True
    return False


def partition_zone(
    zone_geom: dict,
    line_coords_list: list[list],
    building_points: list[tuple[float, float, float]],
    n: int,
) -> list[dict] | None:
    """Partition *zone_geom* into *n* road-following groups.

    Parameters
    ----------
    zone_geom:
        GeoJSON ``Polygon`` / ``MultiPolygon`` geometry (WGS-84).
    line_coords_list:
        Road LineString coordinate lists (WGS-84).
    building_points:
        ``(lon, lat, sqm)`` per building inside the zone.
    n:
        Requested number of groups.

    Returns
    -------
    list[dict] | None
        One dict per group: ``{"geometry": <GeoJSON Polygon|MultiPolygon>,
        "sqm": float, "area": float (m²)}``.  May contain fewer than *n*
        entries when the zone cannot be split that far; ``None`` when it
        cannot be split at all.
    """
    zone_wgs = shapely.make_valid(shape(zone_geom))
    zone_polys = _polygons(zone_wgs)
    if not zone_polys:
        return None
    centroid = zone_wgs.centroid
    proj = _Projection(centroid.x, centroid.y)
    zone = proj.fwd(unary_union(zone_polys))
    lines = [proj.fwd(LineString(c)) for c in line_coords_list if len(c) >= 2]

    blocks = _build_blocks(zone, lines)
    points = [(proj.point(x, y), sqm) for x, y, sqm in building_points]
    use_sqm = sum(sqm for _p, sqm in points) > 1e-6

    def block_weights() -> tuple[list[float], list[float]]:
        sqm_per_block = _assign_sqm(blocks, points)
        return (sqm_per_block if use_sqm else [b.area for b in blocks]), sqm_per_block

    weights, sqm_per_block = block_weights()
    while len(blocks) < n and _bisect_largest(blocks, weights, lines):
        weights, sqm_per_block = block_weights()

    if len(blocks) < 2:
        return None

    member_lists = _merge_groups(blocks, weights, n, zone.area)
    result: list[dict] = []
    for members in member_lists:
        geom = unary_union([blocks[m] for m in members])
        parts = _polygons(geom)
        geom = parts[0] if len(parts) == 1 else MultiPolygon(parts)
        result.append(
            {
                "geometry": json.loads(shapely.to_geojson(proj.inv(geom))),
                "sqm": sum(sqm_per_block[m] for m in members),
                "area": geom.area,
            }
        )
    return result


__all__ = ["partition_zone"]
