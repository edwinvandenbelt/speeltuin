# Databricks notebook source
# ---------------------------------------------------------------------------
# zone_splitter_nb.py — Databricks notebook interface for building-m2-based
# zone splitting.
#
# This notebook:
#   1. Reads widget parameters (zones_uri, network_uri, buildings_uri,
#      zone_id, count).
#   2. Reads the zone, network, and buildings GeoJSON files (s3:// or local
#      path).
#   3. Calls the pure core function (explode_zone_by_sqm) — no Spark I/O.
#   4. Prints the resulting per-piece building-m2 fractions.
#
# This notebook is a debugging/inspection aid only — it does not write a
# ZONE output file.  Splicing split pieces back into a ZONE
# FeatureCollection, regenerating OD pairs, and tombstoning the original
# zone is the ``adjust`` pipeline's job
# (``adjust.core.adjust_core.apply_zone_explosions``).
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("zone_splitter_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-zone-core
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text("zones_uri", "", "Full URI of the zone GeoJSON (s3:// or local path)")
dbutils.widgets.text(
    "network_uri", "", "Full URI of the network GeoJSON used as split-line candidates"
)
dbutils.widgets.text("buildings_uri", "", "Full URI of the area-wide BUILDINGS GeoJSON")
dbutils.widgets.text("zone_id", "", "zoneId of the zone to split")
dbutils.widgets.text("count", "2", "Desired number of sub-zones (>= 2)")
dbutils.widgets.text("LOG_LEVEL", "INFO", "Log level (DEBUG / INFO / WARNING / ERROR)")

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_zone_core.zone_splitter.core.zone_splitter_core import explode_zone_by_sqm

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

ZONES_URI = dbutils.widgets.get("zones_uri").strip()
NETWORK_URI = dbutils.widgets.get("network_uri").strip()
BUILDINGS_URI = dbutils.widgets.get("buildings_uri").strip()
ZONE_ID = dbutils.widgets.get("zone_id").strip()
COUNT = int(dbutils.widgets.get("count").strip() or "2")

if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty — provide a full URI to the zone GeoJSON.")
if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty — provide a full URI to the network GeoJSON.")
if not BUILDINGS_URI:
    raise ValueError(
        "Widget 'buildings_uri' is empty — provide a full URI to the BUILDINGS GeoJSON."
    )
if not ZONE_ID:
    raise ValueError("Widget 'zone_id' is empty — provide the zoneId to split.")
if COUNT < 2:
    raise ValueError(f"Widget 'count' must be >= 2 (got {COUNT}).")

logger.info("zones_uri=%s", ZONES_URI)
logger.info("network_uri=%s", NETWORK_URI)
logger.info("buildings_uri=%s", BUILDINGS_URI)
logger.info("zone_id=%s count=%d", ZONE_ID, COUNT)

# COMMAND ----------
# ── S3 helpers ────────────────────────────────────────────────────────────────

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Zone Splitter
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
print(f"Starting   {_t_start.isoformat()}")

_zones_fc = json.loads(_read_uri(ZONES_URI))
logger.info("Loaded %d zone features", len(_zones_fc.get("features") or []))

_network_fc = json.loads(_read_uri(NETWORK_URI))
logger.info("Loaded %d network features", len(_network_fc.get("features") or []))

_buildings_fc = json.loads(_read_uri(BUILDINGS_URI))
logger.info("Loaded %d building features", len(_buildings_fc.get("features") or []))

_zone_feature = next(
    (
        f
        for f in _zones_fc.get("features") or []
        if (f.get("properties") or {}).get("zoneId") == ZONE_ID
    ),
    None,
)
if _zone_feature is None:
    raise ValueError(f"zoneId {ZONE_ID!r} not found in {ZONES_URI}")

_pieces, _fractions, _stats = explode_zone_by_sqm(_zone_feature, _network_fc, _buildings_fc, COUNT)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("Zone split complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"Zone splitter complete — {_total_elapsed:.1f}s total")
print(_SEP)
print()
print(f"  totalBuildingSqm : {_stats['totalBuildingSqm']:.0f}")
print(f"  targetSqmPerZone : {_stats['targetSqmPerZone']:.0f}")
print(f"  buildingCount    : {_stats['buildingCount']}")
print(f"  requestedPieces  : {_stats['requestedPieces']}")
print(f"  producedPieces   : {_stats['producedPieces']}")
print()
if _pieces is None:
    print("  No usable road geometry inside this zone — could not split.")
else:
    for _i, _fraction in enumerate(_fractions):
        print(f"  piece {_i}: {_fraction * 100:.1f}% of total building m2")
print(_SEP)
