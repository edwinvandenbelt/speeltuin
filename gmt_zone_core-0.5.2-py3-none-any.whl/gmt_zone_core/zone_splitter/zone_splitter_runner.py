"""Local debug runner for zone_splitter.

Calls zone_splitter_core.explode_zone_by_sqm() directly — no Lambda handler
involved.  Splits ONE named zone into N sub-zones, weighted by registered
building floor area (m²), and prints the resulting piece sizes.  It does
not write a zones file itself (unlike zone_refiner_runner, which processes
and rewrites a whole zone collection) — wiring the split pieces back into a
ZONE file and feedlink/OD/flow handling is the ``adjust`` pipeline's job
(see ``adjust.core.adjust_core.apply_zone_explosions``).

Usage
-----
    python -m zone_splitter.zone_splitter_runner \\
        --zones     /tmp/myarea-ZONE-CAR.parquet \\
        --network   /tmp/myarea-NETWORK-CAR.parquet \\
        --buildings /tmp/myarea-BUILDINGS.parquet \\
        --zone-id   BU0599001 \\
        --count     3

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed
  for s3:// URIs).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for zone_splitter (calls core directly).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--zones", required=True, metavar="URI", help="Full URI of the zone GeoParquet."
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="Full URI of the network GeoParquet used as split-line candidates.",
    )
    parser.add_argument(
        "--buildings",
        required=True,
        metavar="URI",
        help="Full URI of the area-wide BUILDINGS GeoParquet.",
    )
    parser.add_argument("--zone-id", required=True, help="zoneId of the zone to split.")
    parser.add_argument(
        "--count", required=True, type=int, help="Desired number of sub-zones (>= 2)."
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet

    from gmt_zone_core.zone_splitter.core.zone_splitter_core import explode_zone_by_sqm

    print(f"Reading zones     : {args.zones}")
    zones_fc = from_geoparquet(_read_uri(args.zones))
    print(f"Reading network   : {args.network}")
    network_fc = from_geoparquet(_read_uri(args.network))
    print(f"Reading buildings : {args.buildings}")
    buildings_fc = from_geoparquet(_read_uri(args.buildings))

    zone_feature = next(
        (
            f
            for f in zones_fc.get("features") or []
            if (f.get("properties") or {}).get("zoneId") == args.zone_id
        ),
        None,
    )
    if zone_feature is None:
        print(f"ERROR: zoneId {args.zone_id!r} not found in {args.zones}", file=sys.stderr)
        sys.exit(1)

    pieces, fractions, stats = explode_zone_by_sqm(
        zone_feature, network_fc, buildings_fc, args.count
    )

    print()
    print(f"  totalBuildingSqm : {stats['totalBuildingSqm']:.0f}")
    print(f"  targetSqmPerZone : {stats['targetSqmPerZone']:.0f}  (= total / {args.count})")
    print(f"  buildingCount    : {stats['buildingCount']}")
    print(f"  requestedPieces  : {stats['requestedPieces']}")
    print(f"  producedPieces   : {stats['producedPieces']}")

    if pieces is None:
        print("  No usable road geometry inside this zone — could not split.")
        return

    print()
    for i, fraction in enumerate(fractions):
        print(f"  piece {i}: {fraction * 100:.1f}% of total building m2")


if __name__ == "__main__":
    main()
