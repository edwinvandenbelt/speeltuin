"""zone_splitter core — no I/O, no boto3.

Splits one zone's polygon into *n* sub-zones, weighted by the registered
building floor area (m²) found inside each resulting piece instead of by
road length — the building-m² analogue of the road-length-weighted
``explodeInto`` zone-explode mechanism in ``gmt-calculation-lib``'s
``adjust.core.adjust_core`` (``apply_zone_explosions`` /
``_explode_ring_n_way``).

Algorithm
---------
Starting from the zone's own ring as a single piece, the ring is cut in two
``n - 1`` times (same chord-cut mechanism ``zone_refiner`` and
``adjust_core`` already use): at each iteration, the piece with the
**greatest total registered building floor area** (rather than the greatest
total clipped road length) is cut along its own locally dominant road — the
network link with the greatest clipped length inside that piece, extended
to the piece's boundary.  A candidate cut is rejected as degenerate when
either resulting sub-ring's area would be a negligible sliver of the piece
being cut (guards against re-selecting a road that lies exactly on an
earlier cut's boundary).

Road geometry is still what any individual cut follows (there is no other
way to carve a zone boundary that lines up with real infrastructure); only
*which piece to cut next*, and the final distribution of numeric zone
properties across the resulting pieces, are driven by building m² instead
of road length.

:func:`split_zone_by_roads` is the preferred entry point: it cuts the zone
into street blocks with shapely (``domain.blocks``) and merges those, so the
sub-zone boundaries follow the actual road geometry.  The chord-based
:func:`explode_zone_by_sqm` is kept for backwards compatibility.

The chord helpers below are deliberately self-contained (no shapely, no dependency on
``gmt-calculation-lib``'s ``building_zone_creator`` or on
``gmt-zone-core``'s own ``zone_refiner``): the low-level ring/chord/point-
in-polygon helpers are duplicated here rather than imported, matching this
repo's existing convention of keeping each module independently
maintainable and testable.

Public API
----------
compute_zone_building_sqm(zone_feature, buildings_fc, *, ref_lat=None) -> float
    Total registered building floor area (m²) inside one zone feature.
explode_zone_by_sqm(zone_feature, network_fc, buildings_fc, n, *, ref_lat=None)
    -> tuple[list[list] | None, list[float], dict]
    Split *zone_feature*'s ring into *n* sub-rings.  Returns
    ``(pieces, fractions, stats)``.  ``pieces`` is ``None`` when not even one
    cut could be made (mirrors ``_explode_ring_n_way``'s contract); it may
    contain fewer than *n* pieces when the zone runs out of usable road
    geometry partway through — the caller decides whether that shortfall is
    acceptable.  ``fractions`` gives each piece's share of the zone's total
    building m² (even split when the zone has no building data at all).
split_zone_by_roads(zone_feature, network_fc, buildings_fc, n, *, ref_lat=None)
    -> tuple[list[dict] | None, list[float], dict]
    Road-following split; returns GeoJSON geometries instead of rings.
"""

from __future__ import annotations

import math

from gmt_zone_core.zone_splitter.domain.footprint import building_sqm

_M_PER_DEG_LAT = 111_320.0  # metres per degree latitude (approximately)

# ---------------------------------------------------------------------------
# Low-level geometry helpers  (stdlib only — no external dependencies)
#
# Ported verbatim from gmt_zone_core.zone_refiner.core.zone_refiner_core —
# duplicated rather than imported, per this module's "no cross-module
# dependency" design (see module docstring).
# ---------------------------------------------------------------------------


def _seg_length_m(ax: float, ay: float, bx: float, by: float) -> float:
    """Approximate WGS-84 distance in metres using a flat-earth model."""
    dlat = (by - ay) * _M_PER_DEG_LAT
    mid_lat = (ay + by) / 2.0
    dlon = (bx - ax) * _M_PER_DEG_LAT * math.cos(math.radians(mid_lat))
    return math.sqrt(dlat * dlat + dlon * dlon)


def _ring_bbox_size(ring: list) -> float:
    """Return the larger of the ring's bounding-box width and height in degrees."""
    lons = [p[0] for p in ring]
    lats = [p[1] for p in ring]
    return max(max(lons) - min(lons), max(lats) - min(lats))


def _segment_intersect_t(
    ax: float,
    ay: float,
    bx: float,
    by: float,
    cx: float,
    cy: float,
    dx: float,
    dy: float,
) -> float | None:
    """Return parametric *t* of the intersection of segment A→B with C→D, or ``None``."""
    denom = (bx - ax) * (dy - cy) - (by - ay) * (dx - cx)
    if abs(denom) < 1e-15:
        return None
    t = ((cx - ax) * (dy - cy) - (cy - ay) * (dx - cx)) / denom
    u = ((cx - ax) * (by - ay) - (cy - ay) * (bx - ax)) / denom
    if 0.0 <= t <= 1.0 and 0.0 <= u <= 1.0:
        return t
    return None


def _intersections_with_ring_indexed(
    ax: float,
    ay: float,
    bx: float,
    by: float,
    ring: list,
) -> list[tuple[float, float, float, int]]:
    """Return sorted, deduplicated ``(t, ix, iy, edge_k)`` for A→B vs. *ring*."""
    hits: list[tuple[float, float, float, int]] = []
    n = len(ring)
    for k in range(n - 1):
        cx, cy = ring[k][0], ring[k][1]
        dx, dy = ring[k + 1][0], ring[k + 1][1]
        t = _segment_intersect_t(ax, ay, bx, by, cx, cy, dx, dy)
        if t is not None:
            ix = ax + t * (bx - ax)
            iy = ay + t * (by - ay)
            hits.append((t, ix, iy, k))
    hits.sort(key=lambda h: h[0])
    deduped: list[tuple[float, float, float, int]] = []
    for hit in hits:
        if deduped and abs(hit[0] - deduped[-1][0]) < 1e-10:
            continue
        deduped.append(hit)
    return deduped


def _point_in_polygon(px: float, py: float, ring: list) -> bool:
    """Ray-casting point-in-polygon test for a closed GeoJSON ring."""
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > py) != (yj > py):
            if px < (xj - xi) * (py - yi) / (yj - yi) + xi:
                inside = not inside
        j = i
    return inside


def _clip_length_in_ring(coords: list, ring: list) -> float:
    """Return the total length in metres of *coords* clipped to *ring*."""
    if len(coords) < 2:
        return 0.0
    total = 0.0
    cur_inside = _point_in_polygon(coords[0][0], coords[0][1], ring)
    for seg_i in range(len(coords) - 1):
        ax, ay = coords[seg_i][0], coords[seg_i][1]
        bx, by = coords[seg_i + 1][0], coords[seg_i + 1][1]
        hits = _intersections_with_ring_indexed(ax, ay, bx, by, ring)
        last_x, last_y = ax, ay
        for _t, ix, iy, _ek in hits:
            if cur_inside:
                total += _seg_length_m(last_x, last_y, ix, iy)
            last_x, last_y = ix, iy
            cur_inside = not cur_inside
        if cur_inside:
            total += _seg_length_m(last_x, last_y, bx, by)
    return total


def _find_split_hits(ring: list, link_coords: list) -> tuple[tuple, tuple] | None:
    """Find two ring-boundary crossings for splitting *ring* along *link_coords*."""
    if len(link_coords) < 2:
        return None
    ax, ay = link_coords[0][0], link_coords[0][1]
    bx, by = link_coords[-1][0], link_coords[-1][1]
    dx = bx - ax
    dy = by - ay
    seg_len_deg = math.sqrt(dx * dx + dy * dy)
    if seg_len_deg < 1e-10:
        return None

    dx /= seg_len_deg
    dy /= seg_len_deg
    mx = (ax + bx) / 2.0
    my = (ay + by) / 2.0

    bbox_size = _ring_bbox_size(ring)
    k = max(bbox_size * 20.0, 1e-4)

    x0, y0 = mx - k * dx, my - k * dy
    x1, y1 = mx + k * dx, my + k * dy

    hits = _intersections_with_ring_indexed(x0, y0, x1, y1, ring)
    if len(hits) < 2:
        return None
    return (hits[0], hits[-1])


def _split_ring_by_chord(
    ring: list, hit1: tuple, hit2: tuple
) -> tuple[list, list] | tuple[None, None]:
    """Split *ring* at two boundary intersection points into two sub-rings."""
    _, x1, y1, e1 = hit1
    _, x2, y2, e2 = hit2

    if e1 > e2 or (e1 == e2 and hit1[0] > hit2[0]):
        x1, y1, e1, x2, y2, e2 = x2, y2, e2, x1, y1, e1

    if e1 == e2:
        return None, None

    n = len(ring) - 1

    ring_a: list = [[x1, y1]]
    for i in range(e1 + 1, e2 + 1):
        ring_a.append(list(ring[i]))
    ring_a.append([x2, y2])
    ring_a.append([x1, y1])

    ring_b: list = [[x2, y2]]
    for i in range(e2 + 1, n):
        ring_b.append(list(ring[i]))
    for i in range(0, e1 + 1):
        ring_b.append(list(ring[i]))
    ring_b.append([x1, y1])
    ring_b.append([x2, y2])

    if len(ring_a) < 4 or len(ring_b) < 4:
        return None, None

    return ring_a, ring_b


def _ring_centroid(ring: list) -> tuple[float, float]:
    """Compute the true centroid of a closed polygon ring via the shoelace formula."""
    n = len(ring)
    if n < 3:
        return ring[0][0], ring[0][1]

    signed_area = 0.0
    cx = 0.0
    cy = 0.0
    for i in range(n - 1):
        xi, yi = ring[i][0], ring[i][1]
        xn, yn = ring[i + 1][0], ring[i + 1][1]
        cross = xi * yn - xn * yi
        signed_area += cross
        cx += (xi + xn) * cross
        cy += (yi + yn) * cross

    signed_area /= 2.0
    if abs(signed_area) < 1e-14:
        pts = ring[:-1] if (ring[0][0] == ring[-1][0] and ring[0][1] == ring[-1][1]) else ring
        return (
            sum(p[0] for p in pts) / max(len(pts), 1),
            sum(p[1] for p in pts) / max(len(pts), 1),
        )

    cx /= 6.0 * signed_area
    cy /= 6.0 * signed_area
    return cx, cy


def _ring_area(ring: list) -> float:
    """Return the absolute (shoelace) area of a closed ring, in degree² units."""
    n = len(ring)
    if n < 4:
        return 0.0
    signed_area = 0.0
    for i in range(n - 1):
        xi, yi = ring[i][0], ring[i][1]
        xn, yn = ring[i + 1][0], ring[i + 1][1]
        signed_area += xi * yn - xn * yi
    return abs(signed_area) / 2.0


def _get_outer_ring(feature: dict) -> list | None:
    """Return the outer ring of a GeoJSON Polygon or MultiPolygon feature.

    For MultiPolygon, returns the ring of the largest sub-polygon (by vertex
    count).  Returns ``None`` for any other geometry type.
    """
    geom = feature.get("geometry") or {}
    gtype = geom.get("type", "")
    coords = geom.get("coordinates") or []
    if gtype == "Polygon":
        return coords[0] if coords else None
    if gtype == "MultiPolygon":
        if not coords:
            return None
        largest = max(coords, key=lambda poly: len(poly[0]) if poly else 0)
        return largest[0] if largest else None
    return None


# ---------------------------------------------------------------------------
# Building floor-area helpers
# ---------------------------------------------------------------------------


def _building_point(feature: dict) -> tuple[float, float] | None:
    """Return a representative ``(x, y)`` point for a building Feature.

    Polygon buildings use their own shoelace centroid; Point buildings use
    the point's own coordinates.  Returns ``None`` for any other geometry
    (or empty/missing coordinates), so the building contributes 0 m² and is
    excluded from any piece.
    """
    geom = feature.get("geometry") or {}
    gtype = geom.get("type", "")
    if gtype == "Point":
        coords = geom.get("coordinates") or []
        if len(coords) < 2:
            return None
        return coords[0], coords[1]
    if gtype == "Polygon":
        coords = geom.get("coordinates") or []
        ring = coords[0] if coords else None
        if not ring or len(ring) < 3:
            return None
        return _ring_centroid(ring)
    return None


def _building_points_in_ring(
    buildings_fc: dict,
    ring: list,
    ref_lat: float,
) -> list[tuple[float, float, float]]:
    """Return ``(x, y, sqm)`` for every building in *buildings_fc* inside *ring*."""
    points: list[tuple[float, float, float]] = []
    for feat in buildings_fc.get("features") or []:
        point = _building_point(feat)
        if point is None:
            continue
        px, py = point
        if not _point_in_polygon(px, py, ring):
            continue
        sqm = building_sqm(feat, ref_lat)
        points.append((px, py, sqm))
    return points


def _sqm_in_ring(ring: list, building_points: list[tuple[float, float, float]]) -> float:
    """Sum the m² of every ``(x, y, sqm)`` point in *building_points* that falls inside *ring*."""
    return sum(sqm for x, y, sqm in building_points if _point_in_polygon(x, y, ring))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def compute_zone_building_sqm(
    zone_feature: dict,
    buildings_fc: dict,
    *,
    ref_lat: float | None = None,
) -> float:
    """Return the total registered building floor area (m²) inside *zone_feature*.

    Used by callers (e.g. the ``adjust`` pipeline) that take a desired
    sub-zone *count* ``n`` rather than a target m², to report/derive
    ``target_sqm = total / n`` before calling :func:`explode_zone_by_sqm`.
    """
    ring = _get_outer_ring(zone_feature)
    if not ring or len(ring) < 4:
        return 0.0
    resolved_ref_lat = ref_lat if ref_lat is not None else _ring_centroid(ring)[1]
    points = _building_points_in_ring(buildings_fc, ring, resolved_ref_lat)
    return sum(sqm for _x, _y, sqm in points)


def explode_ring_n_way_by_sqm(
    ring: list,
    link_coords_list: list[list],
    building_points: list[tuple[float, float, float]],
    n: int,
) -> list[list] | None:
    """Split *ring* into *n* sub-rings by repeatedly cutting along dominant roads.

    At each of the ``n - 1`` iterations, the current piece with the greatest
    total registered building floor area (m²) inside it — not the greatest
    road length — that still yields a usable, non-degenerate split is cut in
    two along its own longest contained road (extended to the piece
    boundary).  A candidate split is rejected as degenerate when either
    resulting sub-ring's area is below ``1e-6`` of the piece being cut
    (guards against re-selecting a road collinear with a boundary created by
    an earlier cut, which would otherwise "succeed" with a zero-width
    sliver ring).

    Returns ``None`` when not even one cut can be made; otherwise returns
    however many pieces could actually be produced, which may be fewer than
    *n* when the zone runs out of usable road geometry partway through — the
    caller decides whether that shortfall is acceptable.
    """
    pieces: list[list] = [ring]
    for _ in range(n - 1):
        best_idx: int | None = None
        best_sqm = -1.0
        best_split: tuple[list, list] | None = None
        for i, piece in enumerate(pieces):
            piece_sqm = _sqm_in_ring(piece, building_points)
            if piece_sqm <= best_sqm:
                continue
            candidates = sorted(
                ((_clip_length_in_ring(coords, piece), coords) for coords in link_coords_list),
                key=lambda c: c[0],
                reverse=True,
            )
            piece_area = _ring_area(piece)
            min_area = piece_area * 1e-6
            split: tuple[list, list] | None = None
            for clen, coords in candidates:
                if clen <= 0.0:
                    break
                hits = _find_split_hits(piece, coords)
                if hits is None:
                    continue
                ring_a, ring_b = _split_ring_by_chord(piece, hits[0], hits[1])
                if ring_a is None:
                    continue
                if _ring_area(ring_a) < min_area or _ring_area(ring_b) < min_area:
                    continue  # degenerate sliver — try the next candidate road
                split = (ring_a, ring_b)
                break
            if split is not None:
                best_idx, best_sqm, best_split = i, piece_sqm, split
        if best_idx is None:
            break
        pieces.pop(best_idx)
        pieces.append(best_split[0])
        pieces.append(best_split[1])
    return pieces if len(pieces) > 1 else None


def explode_zone_by_sqm(
    zone_feature: dict,
    network_fc: dict,
    buildings_fc: dict,
    n: int,
    *,
    ref_lat: float | None = None,
) -> tuple[list[list] | None, list[float], dict]:
    """Split *zone_feature*'s polygon into *n* sub-zones, weighted by building m².

    Parameters
    ----------
    zone_feature:
        The zone GeoJSON Feature to split (must have ``Polygon`` or
        ``MultiPolygon`` geometry).
    network_fc:
        Network GeoJSON FeatureCollection — source of candidate split lines
        (same role as in ``zone_refiner``/``adjust_core``'s road-based
        splitting).
    buildings_fc:
        Area-wide buildings GeoJSON FeatureCollection (e.g. the prepare
        pipeline's ``{area_id}-BUILDINGS.parquet`` output).  Only buildings
        whose representative point falls inside *zone_feature*'s ring are
        considered.
    n:
        Desired number of sub-zones (``>= 2``).
    ref_lat:
        Reference latitude for the flat-Earth footprint projection.
        Defaults to the zone's own centroid latitude.

    Returns
    -------
    (pieces, fractions, stats)
        ``pieces`` — list of closed polygon rings, or ``None`` when not even
        one cut could be made (mirrors
        ``adjust_core._explode_ring_n_way``'s contract).  May contain fewer
        than *n* rings when the zone runs out of usable road geometry
        partway through.
        ``fractions`` — each piece's share of the zone's total building m²
        (parallel list to ``pieces``; even split when the zone has no
        building data at all). Empty when ``pieces`` is ``None``.
        ``stats`` — ``{"requestedPieces", "producedPieces", "totalBuildingSqm",
        "targetSqmPerZone", "buildingCount"}``.
    """
    ring = _get_outer_ring(zone_feature)
    if not ring or len(ring) < 4:
        raise ValueError("explode_zone_by_sqm: zone_feature has no valid polygon geometry.")

    resolved_ref_lat = ref_lat if ref_lat is not None else _ring_centroid(ring)[1]

    link_coords_list: list[list] = [
        feat["geometry"]["coordinates"]
        for feat in network_fc.get("features") or []
        if (feat.get("geometry") or {}).get("type") == "LineString"
        and len((feat.get("geometry") or {}).get("coordinates") or []) >= 2
    ]

    building_points = _building_points_in_ring(buildings_fc, ring, resolved_ref_lat)
    total_sqm = sum(sqm for _x, _y, sqm in building_points)

    stats: dict = {
        "requestedPieces": n,
        "totalBuildingSqm": total_sqm,
        "targetSqmPerZone": total_sqm / n if n else 0.0,
        "buildingCount": len(building_points),
    }

    pieces = explode_ring_n_way_by_sqm(ring, link_coords_list, building_points, n)
    if pieces is None:
        stats["producedPieces"] = 0
        return None, [], stats

    sqm_per_piece = [_sqm_in_ring(piece, building_points) for piece in pieces]
    if total_sqm > 1e-6:
        fractions = [sqm / total_sqm for sqm in sqm_per_piece]
    else:
        fractions = [1.0 / len(pieces)] * len(pieces)

    stats["producedPieces"] = len(pieces)
    return pieces, fractions, stats


def split_zone_by_roads(
    zone_feature: dict,
    network_fc: dict,
    buildings_fc: dict | None,
    n: int,
    *,
    ref_lat: float | None = None,
) -> tuple[list[dict] | None, list[float], dict]:
    """Split *zone_feature* into *n* sub-zones whose boundaries follow the roads.

    The zone is cut into street blocks by every network link (polygonize),
    after which adjacent blocks are merged into *n* groups balanced by
    registered building m² (by area when the zone has no building data).
    Unlike :func:`explode_zone_by_sqm` the boundaries follow the actual road
    geometry instead of straight chords, all parts of a ``MultiPolygon`` zone
    are kept, and holes are preserved.

    Returns
    -------
    (geometries, fractions, stats)
        ``geometries`` — GeoJSON ``Polygon``/``MultiPolygon`` geometry per
        sub-zone, or ``None`` when the zone cannot be split at all.  May hold
        fewer than *n* entries; the caller decides whether that is acceptable.
        ``fractions`` — each sub-zone's share of the zone's building m² (area
        share when there are no buildings).  Empty when ``geometries`` is
        ``None``.
        ``stats`` — same keys as :func:`explode_zone_by_sqm`.
    """
    from shapely.geometry import Point, shape
    from shapely.prepared import prep

    from gmt_zone_core.zone_splitter.domain.blocks import partition_zone

    geom = zone_feature.get("geometry") or {}
    if geom.get("type") not in ("Polygon", "MultiPolygon") or not geom.get("coordinates"):
        raise ValueError("split_zone_by_roads: zone_feature has no valid polygon geometry.")
    zone_shape = shape(geom)
    if zone_shape.is_empty:
        raise ValueError("split_zone_by_roads: zone_feature has no valid polygon geometry.")
    resolved_ref_lat = ref_lat if ref_lat is not None else zone_shape.centroid.y

    link_coords_list: list[list] = [
        feat["geometry"]["coordinates"]
        for feat in network_fc.get("features") or []
        if (feat.get("geometry") or {}).get("type") == "LineString"
        and len((feat.get("geometry") or {}).get("coordinates") or []) >= 2
    ]

    prepared = prep(zone_shape)
    building_points: list[tuple[float, float, float]] = []
    for feat in (buildings_fc or {}).get("features") or []:
        point = _building_point(feat)
        if point is None or not prepared.intersects(Point(point)):
            continue
        building_points.append((point[0], point[1], building_sqm(feat, resolved_ref_lat)))
    total_sqm = sum(sqm for _x, _y, sqm in building_points)

    stats: dict = {
        "requestedPieces": n,
        "totalBuildingSqm": total_sqm,
        "targetSqmPerZone": total_sqm / n if n else 0.0,
        "buildingCount": len(building_points),
    }

    groups = partition_zone(geom, link_coords_list, building_points, n)
    if groups is None:
        stats["producedPieces"] = 0
        return None, [], stats

    if total_sqm > 1e-6:
        fractions = [g["sqm"] / total_sqm for g in groups]
    else:
        total_area = sum(g["area"] for g in groups)
        fractions = [g["area"] / total_area for g in groups]

    stats["producedPieces"] = len(groups)
    return [g["geometry"] for g in groups], fractions, stats


__all__ = [
    "compute_zone_building_sqm",
    "explode_ring_n_way_by_sqm",
    "explode_zone_by_sqm",
    "split_zone_by_roads",
]
