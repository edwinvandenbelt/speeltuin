"""Unit tests for zone_splitter.domain.footprint."""

from __future__ import annotations

import pytest

from gmt_zone_core.zone_splitter.domain.footprint import (
    building_footprint_m2,
    building_sqm,
    polygon_area_m2,
)

# A ~100m x 100m square near 52N (roughly), used only to sanity-check the
# shoelace/flat-earth math — exact value is not the point, order of
# magnitude and monotonicity are.
_REF_LAT = 52.0
_SMALL_SQUARE = [[0.0, 0.0], [0.001, 0.0], [0.001, 0.001], [0.0, 0.001], [0.0, 0.0]]


def _polygon_feature(ring: list, props: dict | None = None) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": props or {},
    }


def _point_feature(props: dict | None = None) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [0.0, 0.0]},
        "properties": props or {},
    }


class TestPolygonAreaM2:
    def test_degenerate_returns_zero(self) -> None:
        assert polygon_area_m2([[0.0, 0.0], [1.0, 1.0]], _REF_LAT) == 0.0

    def test_small_square_is_positive(self) -> None:
        area = polygon_area_m2(_SMALL_SQUARE, _REF_LAT)
        assert area > 0.0

    def test_scales_with_size(self) -> None:
        small = polygon_area_m2(_SMALL_SQUARE, _REF_LAT)
        big_ring = [[0.0, 0.0], [0.002, 0.0], [0.002, 0.002], [0.0, 0.002], [0.0, 0.0]]
        big = polygon_area_m2(big_ring, _REF_LAT)
        assert big == pytest.approx(small * 4.0, rel=1e-6)


class TestBuildingFootprintM2:
    def test_polygon_uses_shoelace(self) -> None:
        feat = _polygon_feature(_SMALL_SQUARE)
        assert building_footprint_m2(feat, _REF_LAT) > 0.0

    def test_point_uses_default(self) -> None:
        feat = _point_feature()
        assert building_footprint_m2(feat, _REF_LAT) == 70.0

    def test_degenerate_polygon_falls_back_to_default(self) -> None:
        feat = _polygon_feature([[0.0, 0.0], [0.0, 0.0], [0.0, 0.0]])
        assert building_footprint_m2(feat, _REF_LAT) == 70.0


class TestBuildingSqm:
    def test_default_floor_fraction_is_one(self) -> None:
        feat = _point_feature()
        assert building_sqm(feat, _REF_LAT) == pytest.approx(70.0)

    def test_floor_fraction_scales_result(self) -> None:
        feat = _point_feature({"floorFraction": 0.5})
        assert building_sqm(feat, _REF_LAT) == pytest.approx(35.0)

    def test_missing_floor_fraction_uses_given_default(self) -> None:
        feat = _point_feature()
        assert building_sqm(feat, _REF_LAT, default_floor_fraction=0.25) == pytest.approx(17.5)
