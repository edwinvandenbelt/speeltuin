"""Unit tests for zone_splitter_core.py."""

from __future__ import annotations

import pytest

from gmt_zone_core.zone_splitter.core.zone_splitter_core import (
    _clip_length_in_ring,
    _get_outer_ring,
    _point_in_polygon,
    _ring_centroid,
    _sqm_in_ring,
    compute_zone_building_sqm,
    explode_ring_n_way_by_sqm,
    explode_zone_by_sqm,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

# Unit square ring: (0,0) - (1,0) - (1,1) - (0,1) - closed
_SQUARE = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.0, 0.0]]


def _zone_feature(ring: list, props: dict | None = None) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {"zoneId": "zone-1", "zoneClass": "STUDY", **(props or {})},
    }


def _network_fc(*lines: list) -> dict:
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": line},
                "properties": {},
            }
            for line in lines
        ],
    }


def _building_point_feature(lon: float, lat: float, floor_fraction: float | None = None) -> dict:
    props: dict = {}
    if floor_fraction is not None:
        props["floorFraction"] = floor_fraction
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": props,
    }


def _buildings_fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features)}


# A road that bisects the unit square vertically through x=0.5 (extended well
# beyond the square so _find_split_hits can extend it to two crossings).
_VERTICAL_ROAD = [[0.5, -1.0], [0.5, 2.0]]
# A road that bisects the left half (x in [0, 0.5]) vertically through x=0.25.
_LEFT_HALF_ROAD = [[0.25, -1.0], [0.25, 2.0]]
# A road that bisects the right half (x in [0.5, 1]) vertically through x=0.75.
_RIGHT_HALF_ROAD = [[0.75, -1.0], [0.75, 2.0]]


# ---------------------------------------------------------------------------
# compute_zone_building_sqm
# ---------------------------------------------------------------------------


class TestComputeZoneBuildingSqm:
    def test_sums_buildings_inside_zone(self) -> None:
        feat = _zone_feature(_SQUARE)
        buildings = _buildings_fc(
            _building_point_feature(0.25, 0.5),  # inside, default 70 m2
            _building_point_feature(0.75, 0.5),  # inside, default 70 m2
            _building_point_feature(5.0, 5.0),  # outside
        )
        total = compute_zone_building_sqm(feat, buildings)
        assert total == pytest.approx(140.0)

    def test_floor_fraction_scales_contribution(self) -> None:
        feat = _zone_feature(_SQUARE)
        buildings = _buildings_fc(_building_point_feature(0.5, 0.5, floor_fraction=0.5))
        total = compute_zone_building_sqm(feat, buildings)
        assert total == pytest.approx(35.0)

    def test_no_buildings_is_zero(self) -> None:
        feat = _zone_feature(_SQUARE)
        total = compute_zone_building_sqm(feat, _buildings_fc())
        assert total == 0.0

    def test_invalid_geometry_is_zero(self) -> None:
        feat = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0, 0]},
            "properties": {},
        }
        assert compute_zone_building_sqm(feat, _buildings_fc()) == 0.0


# ---------------------------------------------------------------------------
# explode_ring_n_way_by_sqm
# ---------------------------------------------------------------------------


class TestExplodeRingNWayBySqm:
    def test_two_way_split_prefers_denser_side(self) -> None:
        link_coords_list = [_VERTICAL_ROAD]
        building_points = [(0.25, 0.5, 100.0), (0.75, 0.5, 10.0)]
        pieces = explode_ring_n_way_by_sqm(_SQUARE, link_coords_list, building_points, 2)
        assert pieces is not None
        assert len(pieces) == 2
        # Every original building must land in exactly one piece.
        for bx, by, _sqm in building_points:
            count = sum(1 for piece in pieces if _point_in_polygon(bx, by, piece))
            assert count == 1

    def test_three_way_split(self) -> None:
        link_coords_list = [_VERTICAL_ROAD, _LEFT_HALF_ROAD, _RIGHT_HALF_ROAD]
        building_points = [
            (0.1, 0.5, 50.0),
            (0.4, 0.5, 50.0),
            (0.9, 0.5, 50.0),
        ]
        pieces = explode_ring_n_way_by_sqm(_SQUARE, link_coords_list, building_points, 3)
        assert pieces is not None
        assert len(pieces) == 3

    def test_returns_none_with_no_usable_road(self) -> None:
        pieces = explode_ring_n_way_by_sqm(_SQUARE, [], [(0.5, 0.5, 100.0)], 2)
        assert pieces is None

    def test_returns_fewer_than_n_when_road_geometry_runs_out(self) -> None:
        # Only one usable road -> at most one cut (2 pieces), even if n=3 is requested.
        pieces = explode_ring_n_way_by_sqm(_SQUARE, [_VERTICAL_ROAD], [(0.5, 0.5, 100.0)], 3)
        assert pieces is not None
        assert len(pieces) == 2

    def test_all_zero_sqm_still_splits(self) -> None:
        # No buildings at all -> ties on sqm (all 0.0), but a split should
        # still occur since road geometry is available.
        pieces = explode_ring_n_way_by_sqm(_SQUARE, [_VERTICAL_ROAD], [], 2)
        assert pieces is not None
        assert len(pieces) == 2


# ---------------------------------------------------------------------------
# explode_zone_by_sqm
# ---------------------------------------------------------------------------


class TestExplodeZoneBySqm:
    def test_splits_and_scales_fractions_by_building_sqm(self) -> None:
        feat = _zone_feature(_SQUARE)
        network_fc = _network_fc(_VERTICAL_ROAD)
        buildings = _buildings_fc(
            _building_point_feature(0.25, 0.5),  # left, 70 m2
            _building_point_feature(0.25, 0.6),  # left, 70 m2
            _building_point_feature(0.75, 0.5),  # right, 70 m2
        )
        pieces, fractions, stats = explode_zone_by_sqm(feat, network_fc, buildings, 2)
        assert pieces is not None
        assert len(pieces) == 2
        assert len(fractions) == 2
        assert sum(fractions) == pytest.approx(1.0)
        assert stats["requestedPieces"] == 2
        assert stats["producedPieces"] == 2
        assert stats["buildingCount"] == 3
        assert stats["totalBuildingSqm"] == pytest.approx(210.0)
        assert stats["targetSqmPerZone"] == pytest.approx(105.0)
        # The piece containing two buildings should get the larger fraction.
        assert max(fractions) == pytest.approx(140.0 / 210.0)

    def test_no_buildings_falls_back_to_even_split(self) -> None:
        feat = _zone_feature(_SQUARE)
        network_fc = _network_fc(_VERTICAL_ROAD)
        pieces, fractions, stats = explode_zone_by_sqm(feat, network_fc, _buildings_fc(), 2)
        assert pieces is not None
        assert fractions == pytest.approx([0.5, 0.5])
        assert stats["totalBuildingSqm"] == 0.0

    def test_no_usable_road_returns_none_pieces(self) -> None:
        feat = _zone_feature(_SQUARE)
        pieces, fractions, stats = explode_zone_by_sqm(feat, _network_fc(), _buildings_fc(), 2)
        assert pieces is None
        assert fractions == []
        assert stats["producedPieces"] == 0

    def test_invalid_zone_geometry_raises(self) -> None:
        bad_feat = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0, 0]},
            "properties": {},
        }
        with pytest.raises(ValueError, match="valid polygon geometry"):
            explode_zone_by_sqm(bad_feat, _network_fc(_VERTICAL_ROAD), _buildings_fc(), 2)

    def test_ref_lat_defaults_to_zone_centroid(self) -> None:
        feat = _zone_feature(_SQUARE)
        ring = _get_outer_ring(feat)
        expected_lat = _ring_centroid(ring)[1]
        network_fc = _network_fc(_VERTICAL_ROAD)
        # Sanity: explode_zone_by_sqm should not raise when ref_lat is omitted,
        # and should behave identically to passing the zone centroid lat explicitly.
        pieces_a, fractions_a, _ = explode_zone_by_sqm(feat, network_fc, _buildings_fc(), 2)
        pieces_b, fractions_b, _ = explode_zone_by_sqm(
            feat, network_fc, _buildings_fc(), 2, ref_lat=expected_lat
        )
        assert fractions_a == fractions_b
        assert len(pieces_a) == len(pieces_b)


# ---------------------------------------------------------------------------
# _sqm_in_ring / _clip_length_in_ring sanity (ported-helper smoke tests)
# ---------------------------------------------------------------------------


class TestPortedHelpersSmoke:
    def test_sqm_in_ring_sums_only_contained_points(self) -> None:
        points = [(0.25, 0.5, 10.0), (5.0, 5.0, 999.0)]
        assert _sqm_in_ring(_SQUARE, points) == pytest.approx(10.0)

    def test_clip_length_in_ring_zero_outside(self) -> None:
        outside_road = [[5.0, 5.0], [6.0, 6.0]]
        assert _clip_length_in_ring(outside_road, _SQUARE) == pytest.approx(0.0)
