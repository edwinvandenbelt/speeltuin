# Databricks notebook source
# ---------------------------------------------------------------------------
# prepare_nb.py — Databricks notebook interface for the GMT preparation pipeline.
#
# This notebook:
#   1. Reads widget parameters (bbox, modes, mode_label, name, catalog, schema, …).
#   2. Installs gmt-calculation-lib from Nexus (if not already present).
#   3. Calls prepare.core.prepare_core.run_pipeline directly.
#
# Requirements (Databricks cluster):
#   pip install gmt-calculation-lib
# ---------------------------------------------------------------------------

# COMMAND ----------
# MAGIC %pip install --quiet gmt-calculation-lib

# COMMAND ----------
import logging
from pathlib import Path

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("prepare_nb")

# COMMAND ----------
# Widget definitions — edit defaults here or via the Databricks widget UI.
dbutils.widgets.text("min_lon", "6.143", "Min longitude")  # noqa: F821
dbutils.widgets.text("min_lat", "52.248", "Min latitude")  # noqa: F821
dbutils.widgets.text("max_lon", "6.184", "Max longitude")  # noqa: F821
dbutils.widgets.text("max_lat", "52.272", "Max latitude")  # noqa: F821
dbutils.widgets.text("modes", "CAR", "Transport mode(s) — comma-separated, e.g. CAR or CAR,BIKE")  # noqa: F821
dbutils.widgets.text(  # noqa: F821
    "mode_label",
    "",
    "Mode label for output filenames (optional, e.g. MIXED; defaults to single mode name)",
)
dbutils.widgets.text("name", "MyArea", "Area name")  # noqa: F821
dbutils.widgets.text("out_dir", "/tmp/gmt_prep", "Output directory")  # noqa: F821
dbutils.widgets.text("catalog", "spectrum", "Databricks catalog")  # noqa: F821
dbutils.widgets.text("schema", "2023_01", "Databricks schema")  # noqa: F821
dbutils.widgets.dropdown("refresh", "false", ["true", "false"], "Refresh")  # noqa: F821
dbutils.widgets.dropdown("debug", "false", ["true", "false"], "Debug")  # noqa: F821
dbutils.widgets.dropdown(  # noqa: F821
    "repair_gaps", "false", ["true", "false"], "Repair gaps (runs gap detector, step 4)"
)
dbutils.widgets.text("exclude_zones", "", "Exclude zones (comma-separated zoneId values, optional)")  # noqa: F821
dbutils.widgets.dropdown(  # noqa: F821
    "annotate_traffic_signals", "true", ["true", "false"], "Annotate + fetch traffic signals"
)
dbutils.widgets.dropdown("fetch_traffic_signs", "true", ["true", "false"], "Fetch traffic signs")  # noqa: F821
dbutils.widgets.text("ndw_data_uri", "", "Pre-provisioned NDW traffic-signs GeoJSON URI (optional)")  # noqa: F821
dbutils.widgets.dropdown(  # noqa: F821
    "fetch_bgt_assets", "true", ["true", "false"], "Fetch BGT assets (NL only)"
)
dbutils.widgets.text("bgt_url", "", "BGT OGC API Features base URL (optional)")  # noqa: F821
dbutils.widgets.dropdown("fetch_osm_assets", "true", ["true", "false"], "Fetch OSM traffic objects")  # noqa: F821
dbutils.widgets.dropdown("fetch_parking_areas", "true", ["true", "false"], "Fetch parking areas")  # noqa: F821
dbutils.widgets.dropdown("fetch_buildings", "true", ["true", "false"], "Fetch OSM buildings")  # noqa: F821
dbutils.widgets.dropdown("fetch_vegetation", "true", ["true", "false"], "Fetch OSM vegetation")  # noqa: F821
dbutils.widgets.dropdown("add_elevation", "true", ["true", "false"], "Add elevationFrom/To")  # noqa: F821
dbutils.widgets.text("elevation_batch_size", "100", "Elevation batch size (max 100)")  # noqa: F821
dbutils.widgets.text("elevation_timeout", "30", "Elevation HTTP timeout (s)")  # noqa: F821
dbutils.widgets.text("elevation_retries", "8", "Elevation retries per batch")  # noqa: F821
dbutils.widgets.text("elevation_pause", "2.0", "Elevation pause between batches (s)")  # noqa: F821

# COMMAND ----------
min_lon = float(dbutils.widgets.get("min_lon"))  # noqa: F821
min_lat = float(dbutils.widgets.get("min_lat"))  # noqa: F821
max_lon = float(dbutils.widgets.get("max_lon"))  # noqa: F821
max_lat = float(dbutils.widgets.get("max_lat"))  # noqa: F821
_modes_raw = dbutils.widgets.get("modes").strip()  # noqa: F821
modes = [m.strip().upper() for m in _modes_raw.split(",") if m.strip()]
_ml_raw = dbutils.widgets.get("mode_label").strip()  # noqa: F821
mode_label = _ml_raw.upper() if _ml_raw else None
name = dbutils.widgets.get("name").strip()  # noqa: F821
out_dir = Path(dbutils.widgets.get("out_dir").strip())  # noqa: F821
catalog = dbutils.widgets.get("catalog").strip()  # noqa: F821
schema = dbutils.widgets.get("schema").strip()  # noqa: F821
refresh = dbutils.widgets.get("refresh") == "true"  # noqa: F821
debug = dbutils.widgets.get("debug") == "true"  # noqa: F821
repair_gaps = dbutils.widgets.get("repair_gaps") == "true"  # noqa: F821
_excl_raw = dbutils.widgets.get("exclude_zones").strip()  # noqa: F821
exclude_zones = [z.strip() for z in _excl_raw.split(",") if z.strip()] or None
annotate_traffic_signals = dbutils.widgets.get("annotate_traffic_signals") == "true"  # noqa: F821
fetch_traffic_signs = dbutils.widgets.get("fetch_traffic_signs") == "true"  # noqa: F821
ndw_data_uri = dbutils.widgets.get("ndw_data_uri").strip() or None  # noqa: F821
fetch_bgt_assets = dbutils.widgets.get("fetch_bgt_assets") == "true"  # noqa: F821
bgt_url = dbutils.widgets.get("bgt_url").strip() or None  # noqa: F821
fetch_osm_assets = dbutils.widgets.get("fetch_osm_assets") == "true"  # noqa: F821
fetch_parking_areas = dbutils.widgets.get("fetch_parking_areas") == "true"  # noqa: F821
fetch_buildings = dbutils.widgets.get("fetch_buildings") == "true"  # noqa: F821
fetch_vegetation = dbutils.widgets.get("fetch_vegetation") == "true"  # noqa: F821
add_elevation = dbutils.widgets.get("add_elevation") == "true"  # noqa: F821
elevation_batch_size = int(dbutils.widgets.get("elevation_batch_size").strip() or "100")  # noqa: F821
elevation_timeout = int(dbutils.widgets.get("elevation_timeout").strip() or "30")  # noqa: F821
elevation_retries = int(dbutils.widgets.get("elevation_retries").strip() or "8")  # noqa: F821
elevation_pause = float(dbutils.widgets.get("elevation_pause").strip() or "2.0")  # noqa: F821

logger.info(
    "Preparation pipeline: bbox=(%s %s %s %s) modes=%s mode_label=%s name=%s out=%s",
    min_lon,
    min_lat,
    max_lon,
    max_lat,
    modes,
    mode_label,
    name,
    out_dir,
)

# COMMAND ----------
from prepare.core.prepare_core import run_pipeline  # noqa: E402

run_pipeline(
    min_lon=min_lon,
    min_lat=min_lat,
    max_lon=max_lon,
    max_lat=max_lat,
    modes=modes,
    name=name,
    out_dir=out_dir,
    mode_label=mode_label,
    catalog=catalog,
    schema=schema,
    refresh=refresh,
    debug=debug,
    repair_gaps=repair_gaps,
    exclude_zones=exclude_zones,
    annotate_traffic_signals=annotate_traffic_signals,
    fetch_traffic_signs=fetch_traffic_signs,
    ndw_data_uri=ndw_data_uri,
    fetch_bgt_assets=fetch_bgt_assets,
    bgt_url=bgt_url,
    fetch_osm_assets=fetch_osm_assets,
    fetch_parking_areas=fetch_parking_areas,
    fetch_buildings=fetch_buildings,
    fetch_vegetation=fetch_vegetation,
    add_elevation=add_elevation,
    elevation_batch_size=elevation_batch_size,
    elevation_timeout=elevation_timeout,
    elevation_retries=elevation_retries,
    elevation_pause=elevation_pause,
)
