"""Pure-Python graph utilities — BFS reachability and Dijkstra shortest-path.

No external dependencies beyond the stdlib (heapq, collections).
All functions accept and return plain Python dicts / sets.

Public API
----------
reachable_nodes(adjacency, seed) -> set[int]
    Directed BFS from *seed*; returns all node IDs reachable (including seed).

dijkstra(adjacency_weighted, seed) -> dict[int, float]
    Weighted Dijkstra; returns {node: min_distance} for all reachable nodes.
    adjacency_weighted: {node: [(neighbour, weight), ...]}

dijkstra_od(adjacency, seed) -> tuple[dict, dict, dict]
    Single-pass Dijkstra for OD matrices; returns (travel_time_s, distance_m,
    resistance) dicts for all reachable nodes.
    adjacency: {node: [(neighbour, time_s, dist_m, remaining_cap), ...]}
    resistance at each node = min(remaining_cap) along the time-optimal path.
"""

from __future__ import annotations

import heapq
from collections import deque


def reachable_nodes(adjacency: dict[int, list[int]], seed: int) -> set[int]:
    """Return the set of all node IDs reachable from *seed* via directed BFS.

    Parameters
    ----------
    adjacency:
        Directed graph as ``{node: [neighbour, ...]}``.
        Nodes not present as keys are treated as having no outgoing edges.
    seed:
        Starting node.  If *seed* is not in *adjacency* the returned set
        contains only *seed* itself (it is still considered "reached").
    """
    visited: set[int] = set()
    queue: deque[int] = deque([seed])
    visited.add(seed)
    while queue:
        node = queue.popleft()
        for neighbour in adjacency.get(node, []):
            if neighbour not in visited:
                visited.add(neighbour)
                queue.append(neighbour)
    return visited


def dijkstra(
    adjacency_weighted: dict[int, list[tuple[int, float]]],
    seed: int,
) -> dict[int, float]:
    """Dijkstra shortest-path distances from *seed*.

    Returns ``{node: min_distance}`` for every node reachable from *seed*
    (including *seed* itself with distance 0.0).

    Parameters
    ----------
    adjacency_weighted:
        Directed weighted graph as ``{node: [(neighbour, weight), ...]}``.
        All weights should be non-negative for correct results.
    seed:
        Starting node.
    """
    dist: dict[int, float] = {seed: 0.0}
    # min-heap of (tentative_distance, node)
    heap: list[tuple[float, int]] = [(0.0, seed)]
    while heap:
        d, node = heapq.heappop(heap)
        if d > dist.get(node, float("inf")):
            continue
        for neighbour, weight in adjacency_weighted.get(node, []):
            nd = d + weight
            if nd < dist.get(neighbour, float("inf")):
                dist[neighbour] = nd
                heapq.heappush(heap, (nd, neighbour))
    return dist


def dijkstra_od(
    adjacency: dict[str, list[tuple[str, float, float, float, float]]],
    seed: str,
) -> tuple[dict[str, float], dict[str, float], dict[str, float]]:
    """Single-pass Dijkstra for OD-matrix computation.

    Computes travel time, distance, and resistance (bottleneck capacity) in one
    heap traversal, following the time-optimal path.

    Parameters
    ----------
    adjacency:
        Directed weighted graph as
        ``{node: [(neighbour, time_s, dist_m, remaining_cap, total_cap), ...]}``.
        All weights should be non-negative.  ``remaining_cap`` is the spare
        capacity of the edge (capacity minus peak flow); it is propagated as a
        *minimum* (bottleneck) along the optimal path.  ``total_cap`` is the
        gross capacity of the edge and is stored for congestion calculations
        downstream.
    seed:
        Starting node.

    Returns
    -------
    time_dict:
        ``{node: travel_time_seconds}`` for every node reachable from *seed*.
    dist_dict:
        ``{node: distance_metres}`` along the time-optimal path.
    res_dict:
        ``{node: min_remaining_cap}`` (resistance factor) along the
        time-optimal path.  The seed node itself has resistance ``inf``
        (no edges traversed).
    """
    inf_ = float("inf")
    time_dict: dict[str, float] = {seed: 0.0}
    dist_dict: dict[str, float] = {seed: 0.0}
    res_dict: dict[str, float] = {seed: inf_}

    # min-heap of (tentative_time, node)
    heap: list[tuple[float, str]] = [(0.0, seed)]

    while heap:
        t, node = heapq.heappop(heap)
        if t > time_dict.get(node, inf_):
            continue
        cur_dist = dist_dict[node]
        cur_res = res_dict[node]
        for neighbour, time_w, dist_w, cap, _total_cap in adjacency.get(node, []):
            nt = t + time_w
            if nt < time_dict.get(neighbour, inf_):
                time_dict[neighbour] = nt
                dist_dict[neighbour] = cur_dist + dist_w
                res_dict[neighbour] = min(cur_res, cap)
                heapq.heappush(heap, (nt, neighbour))

    return time_dict, dist_dict, res_dict
