"""OGC API Features client — pure stdlib (urllib), no extra dependencies.

Used by bgt_fetcher to query the PDOK BGT OGC API Features service.  Fetches
GeoJSON features for a bounding box, following ``links[rel="next"]``
pagination, with on-disk caching, retries and rate-limit handling that mirror
:mod:`shared.overpass`.

The PDOK BGT service serves GeoJSON in CRS84 (WGS-84 lon/lat) by default, so no
coordinate reprojection is required.

Public API
----------
fetch_collection_items(collection, bbox, *, url, limit, timeout, retries) -> list[dict]
    Fetch all GeoJSON features of *collection* intersecting *bbox*,
    transparently following pagination links.
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

_BGT_URL_FALLBACK = "https://api.pdok.nl/lv/bgt/ogc/v1"
DEFAULT_BGT_URL: str = os.environ.get("PDOK_BGT_URL", _BGT_URL_FALLBACK)

#: Hard cap on pages to follow, to guard against a runaway ``next`` chain.
_MAX_PAGES = 1000


# ---------------------------------------------------------------------------
# Disk cache helpers
# ---------------------------------------------------------------------------


def _cache_dir() -> Path | None:
    """Return the active cache directory, or None when caching is disabled.

    Resolution order:
    1. ``PDOK_BGT_CACHE_DIR`` environment variable (empty string disables it).
    2. ``{tempdir}/bgt_cache`` when that directory already exists.
    3. ``None`` — no caching.
    """
    env_val = os.environ.get("PDOK_BGT_CACHE_DIR")
    if env_val is not None:
        return Path(env_val) if env_val.strip() else None
    default = Path(tempfile.gettempdir()) / "bgt_cache"
    return default if default.is_dir() else None


def _cache_key(text: str) -> str:
    """Return a stable filename-safe key for *text*."""
    return hashlib.sha256(text.encode()).hexdigest()


def _cache_load(cache_dir: Path, key: str) -> list[dict[str, Any]] | None:
    """Load a cached feature list.  Returns None on miss or read error."""
    path = cache_dir / f"{key}.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        logger.info("BGT cache HIT  %s", path.name)
        return data
    except Exception as exc:
        logger.warning("BGT cache read failed (%s): %s", path.name, exc)
        return None


def _cache_store(cache_dir: Path, key: str, data: list[dict[str, Any]]) -> None:
    """Persist *data* to the cache directory.  Silently ignores write errors."""
    try:
        cache_dir.mkdir(parents=True, exist_ok=True)
        path = cache_dir / f"{key}.json"
        path.write_text(json.dumps(data), encoding="utf-8")
        logger.info("BGT cache STORE %s  (%d features)", path.name, len(data))
    except Exception as exc:
        logger.warning("BGT cache write failed: %s", exc)


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------


def _get_json(url: str, *, timeout: int, retries: int) -> dict[str, Any]:
    """GET *url* and return the parsed JSON response, with retries."""
    last_exc: Exception | None = None
    for attempt in range(retries):
        if attempt > 0:
            wait = 2**attempt
            logger.warning(
                "BGT retry %d/%d after %.0fs (last error: %s)",
                attempt,
                retries - 1,
                wait,
                last_exc,
            )
            time.sleep(wait)
        try:
            req = urllib.request.Request(url, method="GET")
            req.add_header("User-Agent", "gmt-calculation-lib/1.0")
            req.add_header("Accept", "application/geo+json, application/json")
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                if resp.status in (429, 500, 502, 503, 504):
                    raise urllib.error.HTTPError(url, resp.status, resp.reason, resp.headers, None)
                body = resp.read().decode("utf-8")
            return json.loads(body)
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504):
                last_exc = exc
                continue
            raise
        except urllib.error.URLError as exc:
            last_exc = exc
            continue
        except TimeoutError as exc:
            # Read-phase socket timeouts raise a bare TimeoutError (not wrapped
            # in URLError), so catch them explicitly to keep the retry going.
            last_exc = exc
            continue
        except json.JSONDecodeError as exc:
            raise ValueError(f"BGT returned invalid JSON: {exc}") from exc
    raise last_exc  # type: ignore[misc]


def _next_link(feature_collection: dict[str, Any]) -> str | None:
    """Return the ``rel="next"`` href from an OGC FeatureCollection, or None."""
    for link in feature_collection.get("links") or []:
        if link.get("rel") == "next" and link.get("href"):
            return str(link["href"])
    return None


def fetch_collection_items(
    collection: str,
    bbox: list[float],
    *,
    url: str = DEFAULT_BGT_URL,
    limit: int = 1000,
    timeout: int = 60,
    retries: int = 5,
) -> list[dict[str, Any]]:
    """Fetch all GeoJSON features of *collection* intersecting *bbox*.

    Transparently follows ``links[rel="next"]`` pagination and returns the
    concatenated ``features`` list.  Responses are cached on disk keyed on the
    first-page request URL (see :func:`_cache_dir`).

    Parameters
    ----------
    collection:
        OGC collection id, e.g. ``"wegdeel"``.
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    url:
        OGC API Features base URL (up to and including ``/v1``).
    limit:
        Page size requested from the server.
    timeout:
        HTTP request timeout in seconds (per page).
    retries:
        Maximum retry attempts per page on transient errors.

    Returns
    -------
    A list of GeoJSON Feature dicts (may be empty).
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    query = urllib.parse.urlencode(
        {
            "bbox": f"{min_lon},{min_lat},{max_lon},{max_lat}",
            "limit": limit,
            "f": "json",
        }
    )
    first_url = f"{url.rstrip('/')}/collections/{collection}/items?{query}"

    cache = _cache_dir()
    key: str | None = None
    if cache is not None:
        key = _cache_key(first_url)
        cached = _cache_load(cache, key)
        if cached is not None:
            print(f"  [BGT] cache HIT  {collection} (key={key[:12]}…)")
            return cached

    features: list[dict[str, Any]] = []
    page_url: str | None = first_url
    pages = 0
    while page_url and pages < _MAX_PAGES:
        pages += 1
        print(f"  [BGT] GET {collection} page {pages}")
        data = _get_json(page_url, timeout=timeout, retries=retries)
        features.extend(data.get("features") or [])
        page_url = _next_link(data)

    logger.info("BGT collection %s: %d features over %d page(s)", collection, len(features), pages)

    if cache is not None and key is not None:
        _cache_store(cache, key, features)

    return features
