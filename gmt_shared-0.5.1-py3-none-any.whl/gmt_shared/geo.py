"""geo.py — tiny pure-Python geometry helpers shared across GMT modules.

No external dependencies (stdlib only) so that ``*_core`` modules can import it
while staying pure.

Public API
----------
point_in_polygon(lon, lat, polygon) -> bool
    Ray-casting point-in-polygon test.
is_netherlands(bbox) -> bool
    True when the centroid of *bbox* lies inside a coarse outline of the
    Netherlands.
is_bbox_fully_in_netherlands(bbox) -> bool
    True when all four corners of *bbox* lie inside a coarse outline of the
    Netherlands.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Coarse outline of the Netherlands (mainland), WGS-84 [lon, lat] vertices.
# Deliberately simple — a rough envelope is enough to decide "NL vs elsewhere"
# for data-source selection.  Ordered as a single closed ring.
# ---------------------------------------------------------------------------
_NL_POLYGON: list[list[float]] = [
    [3.36, 51.37],
    [4.00, 51.25],
    [4.55, 51.42],
    [5.05, 51.30],
    [6.02, 51.15],
    [6.22, 51.85],
    [7.07, 52.40],
    [7.21, 53.30],
    [6.80, 53.55],
    [5.50, 53.45],
    [4.60, 52.95],
    [4.00, 52.00],
    [3.36, 51.37],
]


def point_in_polygon(lon: float, lat: float, polygon: list[list[float]]) -> bool:
    """Return True when point ``(lon, lat)`` lies inside *polygon*.

    Uses the standard ray-casting (even-odd) algorithm.  *polygon* is a list of
    ``[lon, lat]`` vertices; it may be open or closed (the ring is treated as
    closed regardless).
    """
    inside = False
    n = len(polygon)
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i][0], polygon[i][1]
        xj, yj = polygon[j][0], polygon[j][1]
        if ((yi > lat) != (yj > lat)) and (lon < (xj - xi) * (lat - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside


def is_netherlands(bbox: list[float]) -> bool:
    """Return True when the centroid of *bbox* lies inside the Netherlands.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    """
    cx = (bbox[0] + bbox[2]) / 2.0
    cy = (bbox[1] + bbox[3]) / 2.0
    return point_in_polygon(cx, cy, _NL_POLYGON)


def is_bbox_fully_in_netherlands(bbox: list[float]) -> bool:
    """Return True when *bbox* lies entirely inside the Netherlands.

    Unlike :func:`is_netherlands` (which only checks the bbox centroid), this
    checks all four corners — a bbox straddling the border returns False even
    when its centroid happens to fall inside the coarse outline.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    corners = [
        (min_lon, min_lat),
        (min_lon, max_lat),
        (max_lon, min_lat),
        (max_lon, max_lat),
    ]
    return all(point_in_polygon(lon, lat, _NL_POLYGON) for lon, lat in corners)
