"""Unified URI dispatch for GMT runners — ``mem://``, ``s3://``, ``file://``, bare paths.

This module is the single source of truth for reading and writing data across
all supported URI schemes:

* ``mem://key``        — in-process memory store; zero I/O, ideal for chaining
                         pipeline steps without touching disk or S3.
* ``s3://bucket/key`` — AWS S3 via :mod:`shared.s3`.
* ``file:///path``    — local filesystem (the ``file://`` prefix is stripped).
* bare path           — local filesystem (treated the same as ``file://``).

In-memory store
---------------
The store is a plain ``dict[str, bytes]`` that lives for the lifetime of the
Python process.  In a Lambda environment each invocation shares the same
process (warm start), so :func:`mem_clear` should be called between unrelated
pipeline runs.

Typical stacking pattern::

    from gmt_shared.uri import mem_put, mem_get, mem_clear, read_uri

    # 1. Seed the store with source data (once).
    mem_put("mem://base/uuid-NETWORK-CAR.geojson", Path("network.geojson").read_bytes())
    mem_put("mem://base/uuid-ZONE-CAR.geojson",    Path("zone.geojson").read_bytes())
    mem_put("mem://base/uuid-FEEDLINK-CAR.geojson", Path("feedlink.geojson").read_bytes())
    mem_put("mem://base/uuid-ROUTES-CAR.geojson",  Path("routes.geojson").read_bytes())

    # 2. First scenario — fully in-memory.
    aid1 = run_pipeline(
        folder="mem://base",
        output_folder="mem://scenario1",
        routes_path="mem://base/uuid-ROUTES-CAR.geojson",
        changes=[{"nodeId": "417346001", "production": "+300"}],
        ...
    )

    # 3. Chain: read output of scenario 1 directly.
    network = json.loads(mem_get(f"mem://scenario1/{aid1}-NETWORK-CAR.geojson"))

    # 4. Second scenario — stacked on scenario 1.
    aid2 = run_pipeline(
        folder="mem://scenario1",
        output_folder="mem://scenario2",
        routes_path=f"mem://scenario1/{aid1}-ROUTES-CAR.geojson",
        changes=[{"linkId": "9876", "capacity": "0"}],
        ...
    )

    # 5. Clean up when done.
    mem_clear()
"""

from __future__ import annotations

from pathlib import Path

# ---------------------------------------------------------------------------
# In-process memory store
# ---------------------------------------------------------------------------

_store: dict[str, bytes] = {}


def mem_put(uri: str, data: bytes) -> None:
    """Store *data* at *uri* (must start with ``mem://``)."""
    if not uri.startswith("mem://"):
        raise ValueError(f"mem_put expects a mem:// URI, got: {uri!r}")
    _store[uri.removeprefix("mem://")] = data


def mem_get(uri: str) -> bytes:
    """Return the bytes stored at *uri* (must start with ``mem://``).

    Raises :exc:`FileNotFoundError` when the key is absent.
    """
    if not uri.startswith("mem://"):
        raise ValueError(f"mem_get expects a mem:// URI, got: {uri!r}")
    key = uri.removeprefix("mem://")
    try:
        return _store[key]
    except KeyError:
        raise FileNotFoundError(f"No entry in memory store for {uri!r}") from None


def mem_exists(uri: str) -> bool:
    """Return ``True`` if *uri* is present in the memory store."""
    return uri.removeprefix("mem://") in _store


def mem_list(prefix: str) -> list[str]:
    """Return all ``mem://`` URIs whose key starts with *prefix* (after stripping ``mem://``)."""
    p = prefix.removeprefix("mem://")
    return ["mem://" + k for k in _store if k.startswith(p)]


def mem_delete(uri: str) -> None:
    """Remove *uri* from the memory store (no-op if absent)."""
    _store.pop(uri.removeprefix("mem://"), None)


def mem_clear(prefix: str | None = None) -> None:
    """Clear the memory store.

    When *prefix* is given, only entries whose key starts with
    ``prefix.removeprefix("mem://")`` are removed; otherwise the entire store
    is cleared.
    """
    if prefix is None:
        _store.clear()
        return
    p = prefix.removeprefix("mem://")
    for key in [k for k in _store if k.startswith(p)]:
        del _store[key]


# ---------------------------------------------------------------------------
# URI helpers
# ---------------------------------------------------------------------------


def join_uri(folder: str | Path, filename: str) -> str:
    """Join *folder* (URI or local path) with *filename*.

    For URI schemes (``mem://``, ``s3://``, ``file://``), the separator is
    always ``/``.  For bare local paths :class:`pathlib.Path` joining is used.
    """
    folder_str = str(folder)
    if folder_str.startswith(("mem://", "s3://", "file://")):
        return folder_str.rstrip("/") + "/" + filename
    return str(Path(folder_str) / filename)


def ensure_folder(folder: str | Path) -> None:
    """Create *folder* on the local filesystem if it does not exist.

    No-op for ``mem://`` and ``s3://`` URIs (those schemes have no directory
    concept).
    """
    folder_str = str(folder)
    if folder_str.startswith(("mem://", "s3://")):
        return
    Path(folder_str.removeprefix("file://")).mkdir(parents=True, exist_ok=True)


def uri_exists(uri: str) -> bool:
    """Return ``True`` if the resource at *uri* is readable.

    For ``s3://`` this always returns ``True``; any ``NoSuchKey`` error will
    surface on the subsequent :func:`read_uri` call.
    """
    if uri.startswith("mem://"):
        return mem_exists(uri)
    if uri.startswith("s3://"):
        return True
    return Path(uri.removeprefix("file://")).exists()


# ---------------------------------------------------------------------------
# I/O dispatch
# ---------------------------------------------------------------------------


def read_uri(uri: str) -> bytes:
    """Read and return the raw bytes at *uri*.

    Supported schemes: ``mem://``, ``s3://``, ``file://``, bare local path.
    """
    if uri.startswith("mem://"):
        return mem_get(uri)
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    return _read_local_bytes(Path(uri.removeprefix("file://")))


def _read_local_bytes(path: Path) -> bytes:
    """Read a local file in bounded chunks.

    A single ``file.read()`` of a multi-gigabyte file can fail on Windows with
    ``OSError: [Errno 22] Invalid argument`` when a contiguous buffer of that
    size cannot be satisfied (this happens intermittently under memory
    pressure).  Reading in fixed-size chunks avoids the large single-shot
    allocation and works uniformly across platforms.
    """
    chunk_size = 64 * 1024 * 1024  # 64 MiB
    chunks: list[bytes] = []
    with path.open("rb") as fh:
        while True:
            chunk = fh.read(chunk_size)
            if not chunk:
                break
            chunks.append(chunk)
    return b"".join(chunks)


def write_uri(
    uri: str,
    data: bytes,
    content_type: str = "application/vnd.apache.parquet",
) -> None:
    """Write *data* to *uri*.

    Supported schemes: ``mem://``, ``s3://``, ``file://``, bare local path.
    Parent directories are created automatically for local paths.
    """
    if uri.startswith("mem://"):
        mem_put(uri, data)
        return
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data, content_type)
        return
    path = Path(uri.removeprefix("file://"))
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
