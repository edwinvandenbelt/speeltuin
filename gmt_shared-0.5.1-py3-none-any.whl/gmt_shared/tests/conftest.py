"""Shared test fixtures for the ``shared`` package.

The ``.osm.pbf`` session cache (:mod:`shared._osm_session`) keeps an in-process
map and writes an on-disk artifact.  To keep tests isolated and free of
side effects, every test gets a fresh temp session directory and a cleared
in-process cache.
"""

from __future__ import annotations

from collections.abc import Iterator

import pytest


@pytest.fixture(autouse=True)
def _isolate_osm_session(
    tmp_path_factory: pytest.TempPathFactory, monkeypatch: pytest.MonkeyPatch
) -> Iterator[None]:
    monkeypatch.setenv("OSM_SESSION_DIR", str(tmp_path_factory.mktemp("osm_session")))
    from gmt_shared import _osm_session

    _osm_session._MEMORY.clear()
    yield
    _osm_session._MEMORY.clear()
