"""Tests for shared._osm_ql — the Overpass QL subset parser.

Includes a regression suite that parses the output of every real
``build_*_query`` helper in the repo so the parser stays in sync with the
queries the local ``.osm.pbf`` backend must serve.
"""

from __future__ import annotations

import pytest

from gmt_shared._osm_ql import (
    OP_ABSENT,
    OP_EQ,
    OP_EXISTS,
    OP_REGEX,
    Filter,
    Selector,
    parse_overpass_ql,
)

# ---------------------------------------------------------------------------
# Filter.matches
# ---------------------------------------------------------------------------


def test_filter_eq() -> None:
    f = Filter("highway", OP_EQ, "crossing")
    assert f.matches({"highway": "crossing"})
    assert not f.matches({"highway": "stop"})
    assert not f.matches({})


def test_filter_exists() -> None:
    f = Filter("building", OP_EXISTS)
    assert f.matches({"building": "yes"})
    assert f.matches({"building": "house"})
    assert not f.matches({"amenity": "parking"})


def test_filter_absent() -> None:
    f = Filter("building", OP_ABSENT)
    assert f.matches({"amenity": "parking"})
    assert not f.matches({"building": "yes"})


def test_filter_regex_anchored() -> None:
    f = Filter("highway", OP_REGEX, "^(motorway|trunk|primary)$")
    assert f.matches({"highway": "motorway"})
    assert f.matches({"highway": "primary"})
    assert not f.matches({"highway": "residential"})


# ---------------------------------------------------------------------------
# Basic parsing
# ---------------------------------------------------------------------------


def test_parse_single_bare_statement() -> None:
    q = '[out:json][timeout:40];\nnode["traffic_sign"](52.0,6.0,52.1,6.2);\nout body;'
    sels = parse_overpass_ql(q)
    assert sels == [Selector("node", [Filter("traffic_sign", OP_EXISTS)], (52.0, 6.0, 52.1, 6.2))]


def test_parse_union_block() -> None:
    q = (
        "[out:json][timeout:25];\n"
        "(\n"
        '  way["amenity"="parking"](52.0,6.0,52.1,6.2);\n'
        '  way["park_ride"](52.0,6.0,52.1,6.2);\n'
        ");\n"
        "out geom;\n"
    )
    sels = parse_overpass_ql(q)
    assert len(sels) == 2
    assert sels[0] == Selector("way", [Filter("amenity", OP_EQ, "parking")], (52.0, 6.0, 52.1, 6.2))
    assert sels[1] == Selector("way", [Filter("park_ride", OP_EXISTS)], (52.0, 6.0, 52.1, 6.2))


def test_parse_recurse_down_is_ignored() -> None:
    q = (
        "[out:json][timeout:60];\n"
        "(\n"
        '  way["highway"~"^(motorway|residential)$"](52.0,6.0,52.1,6.2);\n'
        ");\n"
        "(._;>;);\n"
        "out geom;\n"
    )
    sels = parse_overpass_ql(q)
    assert len(sels) == 1
    assert sels[0].kind == "way"
    assert sels[0].filters == [Filter("highway", OP_REGEX, "^(motorway|residential)$")]


def test_parse_absent_and_multi_selectors() -> None:
    q = '[out:json][timeout:40];\nnode["amenity"][!"building"](52.0,6.0,52.1,6.2);\nout body;'
    sels = parse_overpass_ql(q)
    assert sels[0].filters == [
        Filter("amenity", OP_EXISTS),
        Filter("building", OP_ABSENT),
    ]


def test_parse_equality_selector() -> None:
    q = '[out:json][timeout:40];\nway["highway"="traffic_signals"](52.0,6.0,52.1,6.2);\nout geom;'
    sels = parse_overpass_ql(q)
    assert sels[0] == Selector(
        "way", [Filter("highway", OP_EQ, "traffic_signals")], (52.0, 6.0, 52.1, 6.2)
    )


def test_empty_query_raises() -> None:
    with pytest.raises(NotImplementedError):
        parse_overpass_ql("[out:json][timeout:40];\nout body;")


def test_unsupported_statement_raises() -> None:
    with pytest.raises(NotImplementedError):
        parse_overpass_ql("[out:json];\narea[name](1,2,3,4);\nout body;")


# ---------------------------------------------------------------------------
# Regression: every real build_*_query must parse
# ---------------------------------------------------------------------------

_BBOX = [6.0, 52.0, 6.2, 52.1]  # [minLon, minLat, maxLon, maxLat]


def test_all_builder_queries_parse() -> None:
    pytest.skip("cross-repo builder queries now live in gmt-calculation-lib")
