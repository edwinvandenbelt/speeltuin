"""Tests for shared.geo — point_in_polygon / is_netherlands / is_bbox_fully_in_netherlands."""

from __future__ import annotations

from gmt_shared.geo import is_bbox_fully_in_netherlands, is_netherlands, point_in_polygon


class TestPointInPolygon:
    def test_point_inside_square(self):
        square = [[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0]]
        assert point_in_polygon(1.0, 1.0, square) is True

    def test_point_outside_square(self):
        square = [[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0]]
        assert point_in_polygon(3.0, 3.0, square) is False


class TestIsNetherlands:
    def test_centroid_well_inside_nl_is_true(self):
        # Utrecht-ish bbox, fully inside the coarse NL outline.
        assert is_netherlands([5.0, 52.0, 5.2, 52.15]) is True

    def test_centroid_far_outside_nl_is_false(self):
        assert is_netherlands([10.0, 50.0, 10.2, 50.15]) is False

    def test_border_straddling_bbox_with_centroid_inside_is_true(self):
        # Centroid lies just inside NL even though the bbox extends past the
        # eastern border — is_netherlands only looks at the centroid.
        assert is_netherlands([6.5, 52.1, 7.0, 52.3]) is True


class TestIsBboxFullyInNetherlands:
    def test_bbox_fully_inside_nl_is_true(self):
        assert is_bbox_fully_in_netherlands([5.0, 52.0, 5.2, 52.15]) is True

    def test_bbox_fully_outside_nl_is_false(self):
        assert is_bbox_fully_in_netherlands([10.0, 50.0, 10.2, 50.15]) is False

    def test_border_straddling_bbox_is_false_even_with_centroid_inside(self):
        # Same bbox as the is_netherlands centroid-true case above: the
        # centroid is inside NL, but the east edge crosses the border, so the
        # strict corners-based check must return False.
        bbox = [6.5, 52.1, 7.0, 52.3]
        assert is_netherlands(bbox) is True
        assert is_bbox_fully_in_netherlands(bbox) is False
