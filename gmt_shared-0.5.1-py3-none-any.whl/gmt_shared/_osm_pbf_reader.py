"""Self-contained OpenStreetMap ``.osm.pbf`` reader (no external dependencies).

A minimal, fast, pure-Python decoder for the subset of the OSM PBF format the
local Overpass backend needs.  It exists because:

* ``pyosmium`` has no Python 3.14 wheels, and
* the pure-Python ``google.protobuf`` runtime used by ``esy-osm-pbf`` spends
  ~98% of its time in ``ParseFromString`` — decoding a 120 MB extract took
  ~229 s.  A hand-written varint decoder does the same pass in ~55 s (4.2x)
  while pulling in **zero** third-party dependencies (only stdlib ``zlib`` /
  ``struct``), which also removes the ``protobuf<4`` pin conflict.

The reader understands only what the backend consumes:

* file framing — ``BlobHeader`` / ``Blob`` (raw or zlib-compressed),
* ``PrimitiveBlock`` — string table, ``granularity`` / ``lat_offset`` /
  ``lon_offset``,
* ``DenseNodes`` (id / lat / lon / keys_vals),
* ``Way`` (id / keys / vals / refs),
* ``Relation`` (id / keys / vals / roles_sid / memids / types).

``DenseInfo`` / ``Info`` metadata (versions, timestamps, changesets) and the
rare non-dense ``Node`` message and LocationsOnWays lat/lon are intentionally
skipped.

Public API
----------
iter_block_frames(fileobj) -> Iterator[tuple[str, int, int]]
    Yield ``(blob_type, offset, datasize)`` for each blob (headers only).
read_blob(fileobj, offset, datasize) -> bytes
    Read and decompress one blob body.
decode_primitive_block(raw) -> BlockEntities
    Decode a decompressed OSMData blob into nodes / ways / relations.
iter_entities(path) -> Iterator[Node | Way | Relation]
    Convenience serial iterator over a whole file (esy-compatible tuples).
"""

from __future__ import annotations

import struct
import zlib
from collections import namedtuple
from collections.abc import Iterator
from pathlib import Path
from typing import BinaryIO, NamedTuple

# esy-compatible element tuples so callers can switch backends with no changes.
Node = namedtuple("Node", ("id", "tags", "lonlat"))
Way = namedtuple("Way", ("id", "tags", "refs"))
Relation = namedtuple("Relation", ("id", "tags", "members"))

_MEMBER_TYPES = ("NODE", "WAY", "RELATION")

_COORD_SCALE = 1e-9


class BlockEntities(NamedTuple):
    """Decoded contents of a single ``PrimitiveBlock``."""

    nodes: list  # list[Node]
    ways: list  # list[Way]
    relations: list  # list[Relation]


# ---------------------------------------------------------------------------
# Low-level varint / packed readers
# ---------------------------------------------------------------------------


def _read_varint(buf: bytes, pos: int) -> tuple[int, int]:
    """Decode a base-128 varint from *buf* at *pos*; return ``(value, new_pos)``."""
    result = 0
    shift = 0
    while True:
        b = buf[pos]
        pos += 1
        result |= (b & 0x7F) << shift
        if not b & 0x80:
            return result, pos
        shift += 7


def _read_packed(buf: bytes, pos: int, end: int) -> list[int]:
    """Decode a packed run of varints in ``buf[pos:end]`` into a list."""
    out: list[int] = []
    append = out.append
    while pos < end:
        result = 0
        shift = 0
        while True:
            b = buf[pos]
            pos += 1
            result |= (b & 0x7F) << shift
            if not b & 0x80:
                break
            shift += 7
        append(result)
    return out


def _zigzag(v: int) -> int:
    """Decode a protobuf zig-zag encoded signed integer."""
    return (v >> 1) ^ -(v & 1)


def _skip(buf: bytes, pos: int, wire: int) -> int:
    """Advance *pos* past one field of the given *wire* type."""
    if wire == 0:
        _, pos = _read_varint(buf, pos)
    elif wire == 2:
        ln, pos = _read_varint(buf, pos)
        pos += ln
    elif wire == 1:
        pos += 8
    elif wire == 5:
        pos += 4
    else:
        raise ValueError(f"Unsupported protobuf wire type {wire}")
    return pos


# ---------------------------------------------------------------------------
# File framing — BlobHeader / Blob
# ---------------------------------------------------------------------------


def iter_block_frames(fileobj: BinaryIO) -> Iterator[tuple[str, int, int]]:
    """Yield ``(blob_type, body_offset, datasize)`` for every blob in the file.

    Only the (tiny) ``BlobHeader`` of each blob is parsed; the blob body is
    skipped, so this is cheap enough to enumerate all blocks before dispatching
    them to worker processes.
    """
    ofs = 0
    read = fileobj.read
    seek = fileobj.seek
    while True:
        seek(ofs)
        size_bytes = read(4)
        if len(size_bytes) < 4:
            return
        (header_size,) = struct.unpack(">I", size_bytes)
        header = read(header_size)
        blob_type, datasize = _parse_blob_header(header)
        body_ofs = ofs + 4 + header_size
        yield blob_type, body_ofs, datasize
        ofs = body_ofs + datasize


def _parse_blob_header(buf: bytes) -> tuple[str, int]:
    """Parse a ``BlobHeader`` -> ``(type, datasize)``.  (type=1 str, datasize=3)."""
    blob_type = ""
    datasize = 0
    pos, end = 0, len(buf)
    while pos < end:
        tag, pos = _read_varint(buf, pos)
        field, wire = tag >> 3, tag & 7
        if field == 1 and wire == 2:
            ln, pos = _read_varint(buf, pos)
            blob_type = buf[pos : pos + ln].decode("ascii")
            pos += ln
        elif field == 3 and wire == 0:
            datasize, pos = _read_varint(buf, pos)
        else:
            pos = _skip(buf, pos, wire)
    return blob_type, datasize


def read_blob(fileobj: BinaryIO, offset: int, datasize: int) -> bytes:
    """Read the blob body at *offset* and return its decompressed bytes.

    Supports the ``raw`` (uncompressed) and ``zlib_data`` blob encodings used by
    Geofabrik / osmium.  ``lzma`` and other encodings raise ``ValueError``.
    """
    fileobj.seek(offset)
    buf = fileobj.read(datasize)
    return _decode_blob(buf)


def _decode_blob(buf: bytes) -> bytes:
    """Decode a ``Blob`` message: raw=1 (bytes), zlib_data=3 (bytes)."""
    pos, end = 0, len(buf)
    while pos < end:
        tag, pos = _read_varint(buf, pos)
        field, wire = tag >> 3, tag & 7
        if field == 1 and wire == 2:  # raw
            ln, pos = _read_varint(buf, pos)
            return buf[pos : pos + ln]
        if field == 3 and wire == 2:  # zlib_data
            ln, pos = _read_varint(buf, pos)
            return zlib.decompress(buf[pos : pos + ln])
        if field == 4 and wire == 2:  # lzma_data
            raise ValueError("lzma-compressed PBF blobs are not supported")
        pos = _skip(buf, pos, wire)
    raise ValueError("Blob contains no raw or zlib data")


# ---------------------------------------------------------------------------
# PrimitiveBlock decoding
# ---------------------------------------------------------------------------


def decode_primitive_block(raw: bytes) -> BlockEntities:
    """Decode a decompressed ``OSMData`` blob into nodes / ways / relations."""
    strtab: list[str] = []
    group_spans: list[tuple[int, int]] = []
    granularity = 100
    lat_offset = 0
    lon_offset = 0

    pos, end = 0, len(raw)
    while pos < end:
        tag, pos = _read_varint(raw, pos)
        field, wire = tag >> 3, tag & 7
        if field == 1 and wire == 2:  # stringtable
            ln, pos = _read_varint(raw, pos)
            _decode_stringtable(raw, pos, pos + ln, strtab)
            pos += ln
        elif field == 2 and wire == 2:  # primitivegroup
            ln, pos = _read_varint(raw, pos)
            group_spans.append((pos, pos + ln))
            pos += ln
        elif field == 17 and wire == 0:  # granularity
            granularity, pos = _read_varint(raw, pos)
        elif field == 19 and wire == 0:  # lat_offset
            lat_offset, pos = _read_varint(raw, pos)
        elif field == 20 and wire == 0:  # lon_offset
            lon_offset, pos = _read_varint(raw, pos)
        else:
            pos = _skip(raw, pos, wire)

    granularity = granularity or 100
    nodes: list = []
    ways: list = []
    relations: list = []
    for gpos, gend in group_spans:
        _decode_group(
            raw, gpos, gend, strtab, granularity, lat_offset, lon_offset, nodes, ways, relations
        )
    return BlockEntities(nodes, ways, relations)


def _decode_stringtable(buf: bytes, pos: int, end: int, out: list[str]) -> None:
    """Decode ``StringTable`` (repeated bytes s = 1) into UTF-8 strings."""
    while pos < end:
        tag, pos = _read_varint(buf, pos)
        if (tag >> 3) == 1 and (tag & 7) == 2:
            ln, pos = _read_varint(buf, pos)
            out.append(buf[pos : pos + ln].decode("utf-8"))
            pos += ln
        else:
            pos = _skip(buf, pos, tag & 7)


def _decode_group(
    buf: bytes,
    pos: int,
    end: int,
    strtab: list[str],
    granularity: int,
    lat_offset: int,
    lon_offset: int,
    nodes: list,
    ways: list,
    relations: list,
) -> None:
    """Decode one ``PrimitiveGroup`` span, appending to the entity lists."""
    while pos < end:
        tag, pos = _read_varint(buf, pos)
        field, wire = tag >> 3, tag & 7
        if wire != 2:
            pos = _skip(buf, pos, wire)
            continue
        ln, pos = _read_varint(buf, pos)
        span_end = pos + ln
        if field == 1:  # plain nodes (not emitted by osmium; unsupported)
            raise ValueError("Plain (non-dense) nodes are not supported")
        if field == 2:  # dense
            _decode_dense(buf, pos, span_end, strtab, granularity, lat_offset, lon_offset, nodes)
        elif field == 3:  # way
            ways.append(_decode_way(buf, pos, span_end, strtab))
        elif field == 4:  # relation
            relations.append(_decode_relation(buf, pos, span_end, strtab))
        pos = span_end


def _decode_dense(
    buf: bytes,
    pos: int,
    end: int,
    strtab: list[str],
    granularity: int,
    lat_offset: int,
    lon_offset: int,
    nodes: list,
) -> None:
    """Decode a ``DenseNodes`` message and append :class:`Node` tuples."""
    ids: list[int] = []
    lats: list[int] = []
    lons: list[int] = []
    keys_vals: list[int] = []
    while pos < end:
        tag, pos = _read_varint(buf, pos)
        field, wire = tag >> 3, tag & 7
        if wire == 2:
            ln, pos = _read_varint(buf, pos)
            span = _read_packed(buf, pos, pos + ln)
            if field == 1:
                ids = span
            elif field == 8:
                lats = span
            elif field == 9:
                lons = span
            elif field == 10:
                keys_vals = span
            pos += ln
        else:
            pos = _skip(buf, pos, wire)

    cur_id = cur_lat = cur_lon = 0
    kv_i = 0
    kv_len = len(keys_vals)
    append = nodes.append
    for i, did in enumerate(ids):
        cur_id += _zigzag(did)
        cur_lat += _zigzag(lats[i])
        cur_lon += _zigzag(lons[i])
        lat = _COORD_SCALE * (lat_offset + granularity * cur_lat)
        lon = _COORD_SCALE * (lon_offset + granularity * cur_lon)
        # keys_vals is a flat, 0-delimited (k, v) stream, one node per delimiter.
        tags: dict[str, str] = {}
        if kv_i < kv_len:
            while keys_vals[kv_i] != 0:
                k = strtab[keys_vals[kv_i]]
                v = strtab[keys_vals[kv_i + 1]]
                tags[k] = v
                kv_i += 2
            kv_i += 1  # skip the 0 delimiter
        append(Node(cur_id, tags, (lon, lat)))


def _decode_way(buf: bytes, pos: int, end: int, strtab: list[str]) -> Way:
    """Decode a ``Way`` message into a :class:`Way` tuple (with delta refs)."""
    way_id = 0
    keys: list[int] = []
    vals: list[int] = []
    refs: list[int] = []
    while pos < end:
        tag, pos = _read_varint(buf, pos)
        field, wire = tag >> 3, tag & 7
        if field == 1 and wire == 0:  # id
            way_id, pos = _read_varint(buf, pos)
        elif wire == 2:
            ln, pos = _read_varint(buf, pos)
            if field == 2:
                keys = _read_packed(buf, pos, pos + ln)
            elif field == 3:
                vals = _read_packed(buf, pos, pos + ln)
            elif field == 8:
                refs = _read_packed(buf, pos, pos + ln)
            pos += ln
        else:
            pos = _skip(buf, pos, wire)
    tags = {strtab[k]: strtab[v] for k, v in zip(keys, vals, strict=False)}
    node_refs: list[int] = []
    r = 0
    for d in refs:
        r += _zigzag(d)
        node_refs.append(r)
    return Way(way_id, tags, tuple(node_refs))


def _decode_relation(buf: bytes, pos: int, end: int, strtab: list[str]) -> Relation:
    """Decode a ``Relation`` message into a :class:`Relation` tuple."""
    rel_id = 0
    keys: list[int] = []
    vals: list[int] = []
    roles: list[int] = []
    memids: list[int] = []
    types: list[int] = []
    while pos < end:
        tag, pos = _read_varint(buf, pos)
        field, wire = tag >> 3, tag & 7
        if field == 1 and wire == 0:  # id
            rel_id, pos = _read_varint(buf, pos)
        elif wire == 2:
            ln, pos = _read_varint(buf, pos)
            if field == 2:
                keys = _read_packed(buf, pos, pos + ln)
            elif field == 3:
                vals = _read_packed(buf, pos, pos + ln)
            elif field == 8:
                roles = _read_packed(buf, pos, pos + ln)
            elif field == 9:
                memids = _read_packed(buf, pos, pos + ln)
            elif field == 10:
                types = _read_packed(buf, pos, pos + ln)
            pos += ln
        else:
            pos = _skip(buf, pos, wire)
    tags = {strtab[k]: strtab[v] for k, v in zip(keys, vals, strict=False)}
    members: list[tuple[int, str, str]] = []
    ref = 0
    for i, dmem in enumerate(memids):
        ref += _zigzag(dmem)
        mtype = _MEMBER_TYPES[types[i]] if i < len(types) else "NODE"
        role = strtab[roles[i]] if i < len(roles) else ""
        members.append((ref, mtype, role))
    return Relation(rel_id, tags, members)


# ---------------------------------------------------------------------------
# Serial convenience iterator
# ---------------------------------------------------------------------------


def iter_entities(path: str | Path) -> Iterator:
    """Yield every :class:`Node`, :class:`Way` and :class:`Relation` in *path*.

    Serial, esy-compatible drop-in for ``esy.osm.pbf.File(path)`` iteration.
    """
    with open(path, "rb") as fh:
        for blob_type, offset, datasize in iter_block_frames(fh):
            if blob_type != "OSMData":
                continue
            block = decode_primitive_block(read_blob(fh, offset, datasize))
            yield from block.nodes
            yield from block.ways
            yield from block.relations


def iter_blocks_decoded(path: str | Path) -> Iterator[tuple[int, int, BlockEntities]]:
    """Yield ``(offset, datasize, BlockEntities)`` for each ``OSMData`` blob.

    Unlike :func:`iter_entities` this exposes the blob framing so the caller can
    build a block index (``(max_id, offset, datasize)`` per kind) during the
    same pass it scans for matches — avoiding a second full scan when it later
    needs to resolve referenced node/way ids.
    """
    with open(path, "rb") as fh:
        for blob_type, offset, datasize in iter_block_frames(fh):
            if blob_type != "OSMData":
                continue
            yield offset, datasize, decode_primitive_block(read_blob(fh, offset, datasize))


# ---------------------------------------------------------------------------
# Targeted id resolution (single-pass friendly; no second full scan)
# ---------------------------------------------------------------------------
#
# A block index is a list of ``(max_id, offset, datasize)`` triples in file
# order.  OSM ids are ascending across blocks, so a sorted-id query can be
# walked block-by-block with :func:`bisect.bisect`, decoding only the blocks
# that can contain a wanted id.


def resolve_node_coords(
    path: str | Path,
    node_index: list[tuple[int, int, int]],
    needed_ids: set[int],
) -> dict[int, tuple[float, float]]:
    """Return ``{node_id: (lon, lat)}`` for *needed_ids* using *node_index*.

    Only the blocks that can contain a wanted id are read and decoded.
    """
    coords: dict[int, tuple[float, float]] = {}
    if not needed_ids:
        return coords
    query = sorted(needed_ids)
    with open(path, "rb") as fh:
        for offset, datasize in _blocks_for_query(node_index, query):
            block = decode_primitive_block(read_blob(fh, offset, datasize))
            for node in block.nodes:
                if node.id in needed_ids:
                    coords[node.id] = node.lonlat
    return coords


def resolve_way_refs(
    path: str | Path,
    way_index: list[tuple[int, int, int]],
    needed_ids: set[int],
) -> dict[int, tuple[int, ...]]:
    """Return ``{way_id: node_refs}`` for *needed_ids* using *way_index*."""
    refs: dict[int, tuple[int, ...]] = {}
    if not needed_ids:
        return refs
    query = sorted(needed_ids)
    with open(path, "rb") as fh:
        for offset, datasize in _blocks_for_query(way_index, query):
            block = decode_primitive_block(read_blob(fh, offset, datasize))
            for way in block.ways:
                if way.id in needed_ids:
                    refs[way.id] = way.refs
    return refs


def _blocks_for_query(
    index: list[tuple[int, int, int]],
    sorted_query: list[int],
) -> Iterator[tuple[int, int]]:
    """Yield ``(offset, datasize)`` of blocks that may contain a queried id.

    *index* is ``(max_id, offset, datasize)`` per block in ascending file order;
    *sorted_query* is the ascending list of wanted ids.
    """
    from bisect import bisect

    start = 0
    n = len(sorted_query)
    for max_id, offset, datasize in index:
        if start >= n:
            break
        stop = bisect(sorted_query, max_id, lo=start)
        if stop > start:
            yield offset, datasize
            start = stop
