"""geoparquet.py — GeoParquet serialisation helpers for GMT pipeline artifacts.

All in-memory representations stay as plain Python dicts (GeoJSON FeatureCollections).
Only the I/O boundary changes: pipeline artifacts are stored as ``.parquet`` files.

Serialisation rules
-------------------
- **Scalar columns** (``str``, ``int``, ``float``, ``bool``, ``None``):
  native Parquet column (pyarrow infers the best type).
- **Geometry**: WKB column named ``geometry`` (GeoParquet 1.0 spec).
- **Complex columns** (``list`` / ``dict`` values — e.g. ``routes``,
  ``parallelLinkIds``, ``nodePath``): JSON-serialised string column.
- **Mixed-type scalar columns** (e.g. ``fromNode`` sometimes stored as a
  string ``'-600950219'`` instead of an integer): coerced to a consistent
  Python type (int → float → str) before DataFrame construction so that
  PyArrow does not produce a type-inference error.
- **FeatureCollection ``"properties"`` dict**: stored as Parquet footer
  metadata under the key ``b"gmt_properties"``.
- **List of JSON-serialised column names**: stored as Parquet footer
  metadata under the key ``b"gmt_json_columns"``.
"""

from __future__ import annotations

import io
import json

try:
    import geopandas  # noqa: F401

    _HAS_GEOPARQUET = True
except ImportError:
    _HAS_GEOPARQUET = False

_MISSING_MSG = (
    "geopandas, pyarrow, and shapely are required for GeoParquet I/O. "
    "Install them with: pip install 'geopandas>=0.14' 'pyarrow>=15' 'shapely>=2.0'"
)

PARQUET_CONTENT_TYPE = "application/vnd.apache.parquet"
GEOJSON_CONTENT_TYPE = "application/geo+json"


def _coerce_mixed_columns(rows: list[dict], skip: set[str]) -> None:
    """Coerce columns with mixed int/float/str scalar values to a single type.

    Mutates *rows* in-place.  Columns listed in *skip* (e.g. JSON-serialised
    complex columns) are left unchanged.

    Coercion order: ``int`` → ``float`` → ``str``.  This handles the common
    case where node-ID properties like ``fromNode`` are stored as integers in
    most features but as numeric strings (e.g. ``'-600950219'``) in a few.
    """
    if not rows:
        return
    all_keys = {k for row in rows for k in row} - skip
    for col in all_keys:
        vals = [row.get(col) for row in rows]
        non_none = [v for v in vals if v is not None]
        if not non_none:
            continue
        types = {type(v) for v in non_none}
        if len(types) <= 1:
            continue  # Already homogeneous — no action needed.
        # Attempt coercion: int, then float, then str.
        for coerce_fn in (int, float, str):
            try:
                coerced = [coerce_fn(v) if v is not None else None for v in vals]
                for row, new_val in zip(rows, coerced, strict=False):
                    if col in row:
                        row[col] = new_val
                break
            except Exception:
                continue


def to_geoparquet(fc: dict) -> bytes:
    """Serialise a GeoJSON FeatureCollection dict to GeoParquet bytes.

    Complex property values (``list``/``dict``) are JSON-serialised to string
    columns.  The FeatureCollection-level ``"properties"`` dict is stored in
    Parquet footer metadata so it survives a round-trip without any schema
    changes.

    Parameters
    ----------
    fc:
        A GeoJSON FeatureCollection dict (plain Python, not a GeoDataFrame).

    Returns
    -------
    bytes
        GeoParquet-format bytes suitable for S3 or local-disk storage.
    """
    if not _HAS_GEOPARQUET:
        raise ImportError(_MISSING_MSG)

    import geopandas as gpd
    import pandas as pd
    import pyarrow.parquet as pq
    import shapely

    features = fc.get("features") or []
    fc_props: dict = fc.get("properties") or {}

    # Scan all features to find columns with complex values (list/dict).
    json_columns: set[str] = set()
    for feat in features:
        for key, val in (feat.get("properties") or {}).items():
            if isinstance(val, (list, dict)):
                json_columns.add(key)

    # Build rows (dicts) and geometry list in parallel.
    rows: list[dict] = []
    geoms: list = []

    for feat in features:
        props = dict(feat.get("properties") or {})
        for col in json_columns:
            if col in props:
                props[col] = json.dumps(props[col], ensure_ascii=False)
            # Absent columns are left absent; pandas fills with NaN/None.
        rows.append(props)
        geom = feat.get("geometry")
        geoms.append(shapely.from_geojson(json.dumps(geom)) if geom is not None else None)

    # Coerce columns with mixed int/float/str values to a single consistent
    # type so that PyArrow does not raise a type-inference error.
    _coerce_mixed_columns(rows, skip=json_columns)

    if features:
        df = pd.DataFrame(rows)
        gdf = gpd.GeoDataFrame(df, geometry=gpd.GeoSeries(geoms, crs="EPSG:4326"))
    else:
        gdf = gpd.GeoDataFrame({"geometry": gpd.GeoSeries([], crs="EPSG:4326")})

    # Initial write (without custom metadata).
    buf = io.BytesIO()
    gdf.to_parquet(buf, index=False)
    buf.seek(0)

    # Inject GMT-specific footer metadata.
    table = pq.read_table(buf)
    existing_meta: dict = dict(table.schema.metadata or {})
    existing_meta[b"gmt_properties"] = json.dumps(fc_props, ensure_ascii=False).encode()
    existing_meta[b"gmt_json_columns"] = json.dumps(
        sorted(json_columns), ensure_ascii=False
    ).encode()
    table = table.replace_schema_metadata(existing_meta)

    out = io.BytesIO()
    pq.write_table(table, out)
    return out.getvalue()


def from_geoparquet(data: bytes) -> dict:
    """Deserialise GeoParquet bytes back to a GeoJSON FeatureCollection dict.

    JSON-serialised string columns are deserialised back to Python objects.
    The FeatureCollection-level ``"properties"`` dict is restored from footer
    metadata.

    Parameters
    ----------
    data:
        GeoParquet bytes as produced by :func:`to_geoparquet`.

    Returns
    -------
    dict
        A GeoJSON FeatureCollection dict (plain Python, not a GeoDataFrame).
    """
    if not _HAS_GEOPARQUET:
        raise ImportError(_MISSING_MSG)

    import geopandas as gpd
    import pyarrow.parquet as pq

    pf = pq.ParquetFile(io.BytesIO(data))
    meta: dict = pf.schema_arrow.metadata or {}

    fc_props: dict = json.loads(meta.get(b"gmt_properties", b"{}"))
    json_columns: list[str] = json.loads(meta.get(b"gmt_json_columns", b"[]"))

    gdf = gpd.read_parquet(io.BytesIO(data))  # type: ignore[arg-type]

    # geopandas to_json() handles WKB → GeoJSON geometry, NaN → null, type coercions.
    fc: dict = json.loads(gdf.to_json())

    # Deserialise JSON-string columns back to Python objects.
    if json_columns:
        json_col_set = set(json_columns)
        for feat in fc.get("features") or []:
            props = feat.get("properties") or {}
            for col in json_col_set:
                val = props.get(col)
                if val is not None and isinstance(val, str):
                    try:
                        props[col] = json.loads(val)
                    except Exception:
                        pass  # Leave as string if not valid JSON.

    # Restore FeatureCollection-level properties from footer metadata.
    fc["properties"] = fc_props
    return fc
