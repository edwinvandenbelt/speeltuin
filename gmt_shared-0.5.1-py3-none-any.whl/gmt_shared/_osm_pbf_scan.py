"""Block scanning for the local ``.osm.pbf`` backend — serial and parallel.

The first pass over a PBF (decode every block, match selectors, collect
referenced ids and a per-block index) is CPU-bound in pure-Python varint
decoding and holds the GIL, so it is parallelised across **processes** rather
than threads.

Each blob in a PBF is self-contained given its ``(offset, datasize)``, so the
main process enumerates block frames cheaply (headers only) and hands contiguous
chunks to worker processes.  Every worker re-opens the file, decodes its blocks,
applies the selectors locally and returns only the (small) matched results plus
its slice of the block index.  The main process merges the partials in file
order, keeping output deterministic regardless of worker scheduling.

For small extracts the process-spawn overhead dominates, so callers below a size
threshold (or with ``workers == 1``) use the serial path.

Public API
----------
resolve_workers(env_value, cpu) -> int
    Resolve the effective worker count (env override, capped).
scan(path, node_sels, way_sels, rel_sels, *, workers, min_parallel_bytes) -> ScanResult
    Run pass-1, serial or parallel depending on file size and worker count.
"""

from __future__ import annotations

import os
from concurrent.futures import ProcessPoolExecutor
from pathlib import Path
from typing import NamedTuple

from gmt_shared import _osm_pbf_reader as reader
from gmt_shared._osm_ql import Selector

#: Default cap on worker processes (merge/spawn overhead grows past this).
DEFAULT_WORKER_CAP = 8

#: Files smaller than this stay serial (spawn overhead would dominate).
DEFAULT_MIN_PARALLEL_BYTES = 50 * 1024 * 1024


class ScanResult(NamedTuple):
    """Everything pass-1 collects from a file (mergeable across chunks)."""

    node_elements: list[dict]
    matched_ways: dict  # id -> (tags, refs, bbox)
    matched_rels: dict  # id -> (tags, members, bbox)
    needed_nodes: set[int]
    needed_ways: set[int]
    node_index: list[tuple[int, int, int]]  # (max_id, offset, datasize), file order
    way_index: list[tuple[int, int, int]]


def _in_bbox(lon: float, lat: float, bbox: tuple[float, float, float, float] | None) -> bool:
    if bbox is None:
        return True
    south, west, north, east = bbox
    return west <= lon <= east and south <= lat <= north


def _match(selectors: list[Selector], tags: dict) -> Selector | None:
    for sel in selectors:
        if sel.matches(tags):
            return sel
    return None


def resolve_workers(env_value: str | None, cpu: int | None) -> int:
    """Resolve the effective worker count.

    *env_value* is the raw ``OSM_PBF_WORKERS`` string (or None); *cpu* is
    ``os.cpu_count()``.  An explicit, valid, positive env value wins (still
    bounded by the available CPUs); otherwise defaults to
    ``min(cpu, DEFAULT_WORKER_CAP)``.
    """
    cpu = cpu or 1
    raw = (env_value or "").strip()
    if raw:
        try:
            requested = int(raw)
        except ValueError:
            requested = 0
        if requested > 0:
            return max(1, min(requested, cpu))
    return max(1, min(cpu, DEFAULT_WORKER_CAP))


# ---------------------------------------------------------------------------
# Per-chunk worker (must be top-level for spawn/pickling)
# ---------------------------------------------------------------------------


def _scan_chunk(
    path_str: str,
    frames: list[tuple[int, int]],
    node_sels: list[Selector],
    way_sels: list[Selector],
    rel_sels: list[Selector],
) -> ScanResult:
    """Decode the blocks in *frames* and return their partial :class:`ScanResult`."""
    node_elements: list[dict] = []
    matched_ways: dict = {}
    matched_rels: dict = {}
    needed_nodes: set[int] = set()
    needed_ways: set[int] = set()
    node_index: list[tuple[int, int, int]] = []
    way_index: list[tuple[int, int, int]] = []

    with open(path_str, "rb") as fh:
        for offset, datasize in frames:
            block = reader.decode_primitive_block(reader.read_blob(fh, offset, datasize))
            if block.nodes:
                node_index.append((block.nodes[-1].id, offset, datasize))
                if node_sels:
                    for node in block.nodes:
                        sel = _match(node_sels, node.tags)
                        if sel is not None:
                            lon, lat = node.lonlat
                            if _in_bbox(lon, lat, sel.bbox):
                                node_elements.append(
                                    {
                                        "type": "node",
                                        "id": node.id,
                                        "lat": lat,
                                        "lon": lon,
                                        "tags": dict(node.tags),
                                    }
                                )
            if block.ways:
                way_index.append((block.ways[-1].id, offset, datasize))
                if way_sels:
                    for way in block.ways:
                        sel = _match(way_sels, way.tags)
                        if sel is not None:
                            matched_ways[way.id] = (dict(way.tags), tuple(way.refs), sel.bbox)
                            needed_nodes.update(way.refs)
            if block.relations and rel_sels:
                for rel in block.relations:
                    sel = _match(rel_sels, rel.tags)
                    if sel is not None:
                        matched_rels[rel.id] = (dict(rel.tags), list(rel.members), sel.bbox)
                        for ref, mtype, _role in rel.members:
                            if mtype == "WAY":
                                needed_ways.add(ref)
                            elif mtype == "NODE":
                                needed_nodes.add(ref)

    return ScanResult(
        node_elements,
        matched_ways,
        matched_rels,
        needed_nodes,
        needed_ways,
        node_index,
        way_index,
    )


# ---------------------------------------------------------------------------
# Serial / parallel drivers
# ---------------------------------------------------------------------------


def _frames(path: Path) -> list[tuple[int, int]]:
    """Enumerate ``(offset, datasize)`` of every ``OSMData`` blob (headers only)."""
    out: list[tuple[int, int]] = []
    with open(path, "rb") as fh:
        for blob_type, offset, datasize in reader.iter_block_frames(fh):
            if blob_type == "OSMData":
                out.append((offset, datasize))
    return out


def _chunk(items: list, n: int) -> list[list]:
    """Split *items* into *n* roughly equal contiguous chunks (file order)."""
    if n <= 1 or len(items) <= 1:
        return [items]
    size = (len(items) + n - 1) // n
    return [items[i : i + size] for i in range(0, len(items), size)]


def _merge(parts: list[ScanResult]) -> ScanResult:
    """Merge per-chunk results; indexes are concatenated in file (chunk) order."""
    node_elements: list[dict] = []
    matched_ways: dict = {}
    matched_rels: dict = {}
    needed_nodes: set[int] = set()
    needed_ways: set[int] = set()
    node_index: list[tuple[int, int, int]] = []
    way_index: list[tuple[int, int, int]] = []
    for p in parts:
        node_elements.extend(p.node_elements)
        matched_ways.update(p.matched_ways)
        matched_rels.update(p.matched_rels)
        needed_nodes.update(p.needed_nodes)
        needed_ways.update(p.needed_ways)
        node_index.extend(p.node_index)
        way_index.extend(p.way_index)
    return ScanResult(
        node_elements,
        matched_ways,
        matched_rels,
        needed_nodes,
        needed_ways,
        node_index,
        way_index,
    )


def scan(
    path: Path,
    node_sels: list[Selector],
    way_sels: list[Selector],
    rel_sels: list[Selector],
    *,
    workers: int,
    min_parallel_bytes: int = DEFAULT_MIN_PARALLEL_BYTES,
) -> ScanResult:
    """Run pass-1 over *path*, parallel across processes when it is worthwhile.

    Falls back to a serial single-process scan when ``workers <= 1`` or the file
    is smaller than *min_parallel_bytes* (spawn overhead would dominate).
    """
    frames = _frames(path)
    use_parallel = workers > 1 and path.stat().st_size >= min_parallel_bytes and len(frames) > 1
    if not use_parallel:
        return _scan_chunk(str(path), frames, node_sels, way_sels, rel_sels)

    chunks = _chunk(frames, workers)
    path_str = str(path)
    parts: list[ScanResult] = []
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = [
            pool.submit(_scan_chunk, path_str, chunk, node_sels, way_sels, rel_sels)
            for chunk in chunks
        ]
        # Preserve file order (chunk order) so output is deterministic.
        parts = [f.result() for f in futures]
    return _merge(parts)


def _default_workers() -> int:
    """Effective worker count from ``OSM_PBF_WORKERS`` / cpu count."""
    return resolve_workers(os.environ.get("OSM_PBF_WORKERS"), os.cpu_count())


# ---------------------------------------------------------------------------
# Session scan — collect *all* tagged entities once so many selector queries can
# be answered from memory without re-reading the file (see shared._osm_session).
# ---------------------------------------------------------------------------


class SessionResult(NamedTuple):
    """Every tagged entity in a file plus the per-block geometry indexes.

    Unlike :class:`ScanResult` this is selector-independent: it holds *all*
    tagged nodes / ways / relations so any number of later selector queries can
    be answered in-memory.  Untagged geometry (way node coords, member ways) is
    still resolved on demand through ``node_index`` / ``way_index``.
    """

    tagged_nodes: list[tuple[int, dict, tuple[float, float]]]  # (id, tags, (lon, lat))
    tagged_ways: dict[int, tuple[dict, tuple[int, ...]]]  # id -> (tags, refs)
    tagged_rels: dict[int, tuple[dict, list]]  # id -> (tags, members)
    node_index: list[tuple[int, int, int]]  # (max_id, offset, datasize), file order
    way_index: list[tuple[int, int, int]]


def _session_chunk(path_str: str, frames: list[tuple[int, int]]) -> SessionResult:
    """Decode the blocks in *frames*, collecting every tagged entity + indexes."""
    tagged_nodes: list[tuple[int, dict, tuple[float, float]]] = []
    tagged_ways: dict[int, tuple[dict, tuple[int, ...]]] = {}
    tagged_rels: dict[int, tuple[dict, list]] = {}
    node_index: list[tuple[int, int, int]] = []
    way_index: list[tuple[int, int, int]] = []

    with open(path_str, "rb") as fh:
        for offset, datasize in frames:
            block = reader.decode_primitive_block(reader.read_blob(fh, offset, datasize))
            if block.nodes:
                node_index.append((block.nodes[-1].id, offset, datasize))
                tagged_nodes.extend(
                    (node.id, dict(node.tags), node.lonlat) for node in block.nodes if node.tags
                )
            if block.ways:
                way_index.append((block.ways[-1].id, offset, datasize))
                for way in block.ways:
                    if way.tags:
                        tagged_ways[way.id] = (dict(way.tags), tuple(way.refs))
            if block.relations:
                for rel in block.relations:
                    if rel.tags:
                        tagged_rels[rel.id] = (dict(rel.tags), list(rel.members))

    return SessionResult(tagged_nodes, tagged_ways, tagged_rels, node_index, way_index)


def _merge_session(parts: list[SessionResult]) -> SessionResult:
    """Merge per-chunk session results, keeping indexes in file (chunk) order."""
    tagged_nodes: list[tuple[int, dict, tuple[float, float]]] = []
    tagged_ways: dict[int, tuple[dict, tuple[int, ...]]] = {}
    tagged_rels: dict[int, tuple[dict, list]] = {}
    node_index: list[tuple[int, int, int]] = []
    way_index: list[tuple[int, int, int]] = []
    for p in parts:
        tagged_nodes.extend(p.tagged_nodes)
        tagged_ways.update(p.tagged_ways)
        tagged_rels.update(p.tagged_rels)
        node_index.extend(p.node_index)
        way_index.extend(p.way_index)
    return SessionResult(tagged_nodes, tagged_ways, tagged_rels, node_index, way_index)


def scan_session(
    path: Path,
    *,
    workers: int,
    min_parallel_bytes: int = DEFAULT_MIN_PARALLEL_BYTES,
) -> SessionResult:
    """Scan *path* once, collecting every tagged entity plus the block indexes.

    Parallel across processes on large files (same size / worker rules as
    :func:`scan`); serial otherwise.
    """
    frames = _frames(path)
    use_parallel = workers > 1 and path.stat().st_size >= min_parallel_bytes and len(frames) > 1
    if not use_parallel:
        return _session_chunk(str(path), frames)

    chunks = _chunk(frames, workers)
    path_str = str(path)
    with ProcessPoolExecutor(max_workers=workers) as pool:
        futures = [pool.submit(_session_chunk, path_str, chunk) for chunk in chunks]
        parts = [f.result() for f in futures]
    return _merge_session(parts)
