"""Derive zone centroids from a feedlinks FeatureCollection — no I/O, no external deps."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def derive_centroids(feedlinks_fc: dict) -> dict:
    """Derive a centroids GeoJSON from a feedlinks FeatureCollection.

    One ``Point`` feature is produced per zone.  The centroid's ``nodeId`` is
    the zone-side node of the feedlink — i.e. ``fromNode`` of a production
    feedlink (which equals ``str(zoneGid)``), or ``toNode`` of an attraction
    feedlink as a fallback.  This virtual zone node is the origin/destination
    node for demand in the STAQ assignment model; the feedlinks themselves
    connect these virtual nodes to the real network.

    Priority: production feedlink > attraction feedlink > any other direction.

    Each output feature carries:
    - ``zoneId``    — zone identifier (string)
    - ``nodeId``    — zone centroid node ID in the STAQ network (string)
    - ``zoneIndex`` — 1-based integer index, sorted by ``zoneId``

    The result is consumed by ``link_based_staq_assigner`` (needs ``nodeId`` + ``zoneIndex``).
    """
    production: dict[str, tuple] = {}  # zoneId -> (feat, zone_node_id)
    fallback: dict[str, tuple] = {}  # zoneId -> (feat, zone_node_id)

    for feat in feedlinks_fc.get("features", []):
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "").strip()

        from_node = str(props.get("fromNode") or "").strip()
        to_node = str(props.get("toNode") or "").strip()

        direction = props.get("linkDirection")

        if not zone_id:
            continue

        if direction == "production":
            zone_node_id = from_node
        elif direction == "attraction":
            zone_node_id = to_node
        elif direction is None:
            zone_node_id = from_node if from_node else to_node
        else:
            zone_node_id = from_node if from_node else to_node

        if not zone_node_id:
            continue

        if direction == "production" and zone_id not in production:
            production[zone_id] = (feat, zone_node_id)
        if zone_id not in fallback:
            fallback[zone_id] = (feat, zone_node_id)

    chosen: dict[str, tuple] = {**fallback, **production}

    features = []
    for idx, zone_id in enumerate(sorted(chosen), start=1):
        feat, zone_node_id = chosen[zone_id]
        geom = feat.get("geometry") or {}
        coords = geom.get("coordinates") or []
        if geom.get("type") == "LineString" and coords:
            point_coords = coords[0]
        elif geom.get("type") == "Point":
            point_coords = coords
        else:
            point_coords = [0.0, 0.0]

        features.append(
            {
                "type": "Feature",
                "id": zone_id,
                "geometry": {"type": "Point", "coordinates": point_coords},
                "properties": {
                    "zoneId": zone_id,
                    "nodeId": zone_node_id,
                    "zoneIndex": idx,
                },
            }
        )

    logger.info(
        "derive_centroids: %d centroids from %d feedlinks",
        len(features),
        len(feedlinks_fc.get("features", [])),
    )
    return {"type": "FeatureCollection", "features": features}


__all__ = ["derive_centroids"]
