"""Bbox / polygon region utilities — no I/O, no external deps."""

from __future__ import annotations

import json
import re
from uuid import uuid4


def to_polygon_geojson(inputs: dict) -> str:
    """Build a GeoJSON Polygon string from inputs["bbox"].

    Accepts:
    - [minX, minY, maxX, maxY]             – flat 4-element bbox (WGS-84)
    - [minX, minY, minZ, maxX, maxY, maxZ] – 6-element 3D bbox (Z ignored)
    - [[x1, y1], [x2, y2], …]              – polygon ring (closed if needed)
    """
    raw = inputs.get("bbox")
    if not raw:
        raise ValueError("inputs.bbox is required.")

    if isinstance(raw[0], (int, float)):
        if len(raw) == 4:
            x1, y1, x2, y2 = raw
        elif len(raw) == 6:
            x1, y1, _, x2, y2, _ = raw
        else:
            raise ValueError(f"bbox must have 4 or 6 elements, got {len(raw)}.")
        ring = [[x1, y1], [x2, y1], [x2, y2], [x1, y2], [x1, y1]]
    else:
        ring = [list(p[:2]) for p in raw]
        if ring[0] != ring[-1]:
            ring.append(ring[0])

    return json.dumps({"type": "Polygon", "coordinates": [ring]})


def to_bbox(inputs: dict) -> list:
    """Return a normalised [minX, minY, maxX, maxY] from inputs["bbox"].

    Accepts the same shapes as ``to_polygon_geojson``.
    """
    raw = inputs.get("bbox")
    if not raw:
        raise ValueError("inputs.bbox is required.")

    if isinstance(raw[0], (int, float)):
        if len(raw) == 4:
            return list(raw)
        if len(raw) == 6:
            x1, y1, _, x2, y2, _ = raw
            return [x1, y1, x2, y2]
        raise ValueError(f"bbox must have 4 or 6 elements, got {len(raw)}.")

    xs = [p[0] for p in raw]
    ys = [p[1] for p in raw]
    return [min(xs), min(ys), max(xs), max(ys)]


def point_in_polygon(px: float, py: float, ring: list) -> bool:
    """Ray-casting point-in-polygon for a single exterior ring."""
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside


def determine_region(bbox: list, region_features: list) -> str | None:
    """Return the ``regio`` property of the first region polygon that contains
    the centroid of *bbox*, or ``None`` if no match is found.
    """
    if not region_features or not bbox or len(bbox) < 4:
        return None
    cx = (bbox[0] + bbox[2]) / 2.0
    cy = (bbox[1] + bbox[3]) / 2.0
    for feature in region_features:
        try:
            geom = feature.get("geometry") or {}
            if geom.get("type") != "Polygon":
                continue
            exterior = geom["coordinates"][0]
            if point_in_polygon(cx, cy, exterior):
                return (feature.get("properties") or {}).get("regio")
        except Exception:
            continue
    return None


def slugify(text: str) -> str:
    """Convert *text* to a URL-safe lowercase slug."""
    text = text.lower().strip()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    text = re.sub(r"-{2,}", "-", text)
    return text.strip("-") or str(uuid4())


__all__ = ["to_polygon_geojson", "to_bbox", "point_in_polygon", "determine_region", "slugify"]
