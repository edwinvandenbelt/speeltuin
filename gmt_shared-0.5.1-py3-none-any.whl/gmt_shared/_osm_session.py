"""Shared ``.osm.pbf`` session cache — scan once, answer many queries.

A single ``prepare`` run invokes roughly seven OSM fetchers (traffic signals,
traffic signs, OSM assets, parking, buildings, vegetation, …), each of which
would otherwise re-scan the entire local PBF extract.  A :class:`OsmSession`
scans the file **once**, collecting every *tagged* node / way / relation plus a
per-block geometry index, so each fetcher's selector query is answered from
memory.  Untagged geometry (way node coords, relation member ways) is resolved
on demand through the block indexes — exactly as the single-pass backend does.

Two cache layers share that work:

* **E1 — in-process** (:data:`_MEMORY`): the session for a given file is built
  once per Python process and reused by every subsequent :func:`get_session`
  call.  This is what makes the many fetchers in one ``prepare`` run share a
  single scan.  No fetcher-core changes are required — the sharing happens
  transparently inside :func:`shared._osm_pbf.fetch_from_pbf`.
* **E2 — on-disk** (:func:`_disk_path`): the built session is pickled into a
  cache directory (``OSM_SESSION_DIR`` env, else ``{tempdir}/osm_session``)
  keyed by ``(basename, mtime_ns, size)`` so that *separate* processes — e.g.
  the standalone ``osm_*_fetcher`` runners — reuse it too.  A stale extract
  (different mtime/size) misses the key and is rebuilt.

Both layers are keyed on ``(basename, mtime_ns, size)`` and never touch S3.
Set ``OSM_SESSION=0`` to disable the whole mechanism and fall back to a
per-query targeted scan.

Public API
----------
sessions_enabled() -> bool
    Whether the session cache is active (``OSM_SESSION`` not disabled).
get_session(path, *, workers) -> OsmSession
    Return the cached session for *path*, building (and caching) it if needed.
query_session(session, node_sels, way_sels, rel_sels) -> ScanResult
    Answer a selector query from an in-memory session (same shape as
    :func:`shared._osm_pbf_scan.scan`).
"""

from __future__ import annotations

import hashlib
import logging
import os
import pickle
import tempfile
import threading
from pathlib import Path
from typing import NamedTuple

from gmt_shared import _osm_pbf_scan as scan
from gmt_shared._osm_ql import Selector

logger = logging.getLogger(__name__)

#: Pickle protocol / on-disk format version — bump to invalidate old artifacts.
_DISK_VERSION = 1

_DISABLE_VALUES = {"0", "false", "no", "off"}


class OsmSession(NamedTuple):
    """An in-memory, selector-independent view of one ``.osm.pbf`` file."""

    tagged_nodes: list[tuple[int, dict, tuple[float, float]]]
    tagged_ways: dict[int, tuple[dict, tuple[int, ...]]]
    tagged_rels: dict[int, tuple[dict, list]]
    node_index: list[tuple[int, int, int]]
    way_index: list[tuple[int, int, int]]
    key: tuple[str, int, int]


# ---------------------------------------------------------------------------
# Enablement / cache keys
# ---------------------------------------------------------------------------


def sessions_enabled() -> bool:
    """Return True unless ``OSM_SESSION`` is set to a disabling value."""
    return os.environ.get("OSM_SESSION", "").strip().lower() not in _DISABLE_VALUES


def _session_key(path: Path) -> tuple[str, int, int]:
    """Return ``(basename, mtime_ns, size)`` — the invalidation key for *path*."""
    st = path.stat()
    return (path.name, st.st_mtime_ns, st.st_size)


# ---------------------------------------------------------------------------
# E1 — in-process cache
# ---------------------------------------------------------------------------

_MEMORY: dict[tuple[str, int, int], OsmSession] = {}
_LOCK = threading.Lock()


# ---------------------------------------------------------------------------
# E2 — on-disk cache
# ---------------------------------------------------------------------------


def _disk_dir() -> Path:
    """Return the on-disk session cache directory (``OSM_SESSION_DIR`` or temp)."""
    raw = os.environ.get("OSM_SESSION_DIR", "").strip()
    return Path(raw) if raw else Path(tempfile.gettempdir()) / "osm_session"


def _disk_path(key: tuple[str, int, int]) -> Path:
    """Return the cache file path for *key* (hash keeps the name filesystem-safe)."""
    digest = hashlib.sha256(f"{_DISK_VERSION}|{key[0]}|{key[1]}|{key[2]}".encode()).hexdigest()
    return _disk_dir() / f"{key[0]}.{digest[:16]}.session.pkl"


def _disk_load(key: tuple[str, int, int]) -> OsmSession | None:
    """Load a cached session for *key* from disk, or ``None`` on miss / error."""
    path = _disk_path(key)
    if not path.is_file():
        return None
    try:
        with open(path, "rb") as fh:
            data = pickle.load(fh)  # noqa: S301 — our own cache dir, our own format.
    except (OSError, pickle.UnpicklingError, EOFError, AttributeError) as exc:
        logger.warning("Ignoring unreadable OSM session cache %s: %s", path.name, exc)
        return None
    if not isinstance(data, OsmSession) or data.key != key:
        return None
    return data


def _disk_store(session: OsmSession) -> None:
    """Persist *session* to the on-disk cache (best-effort; failures are logged)."""
    path = _disk_path(session.key)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(".pkl.tmp")
        with open(tmp, "wb") as fh:
            pickle.dump(session, fh, protocol=pickle.HIGHEST_PROTOCOL)
        tmp.replace(path)
    except OSError as exc:  # pragma: no cover - disk full / permissions.
        logger.warning("Could not write OSM session cache %s: %s", path.name, exc)


# ---------------------------------------------------------------------------
# Build / fetch
# ---------------------------------------------------------------------------


def get_session(path: Path, *, workers: int) -> OsmSession:
    """Return the shared :class:`OsmSession` for *path*, building it if needed.

    Resolution order: in-process cache (E1) -> on-disk cache (E2) -> full scan.
    A freshly built session is written back to both layers.
    """
    key = _session_key(path)
    with _LOCK:
        cached = _MEMORY.get(key)
        if cached is not None:
            return cached

    disk = _disk_load(key)
    if disk is not None:
        with _LOCK:
            _MEMORY[key] = disk
        return disk

    result = scan.scan_session(path, workers=workers)
    session = OsmSession(
        result.tagged_nodes,
        result.tagged_ways,
        result.tagged_rels,
        result.node_index,
        result.way_index,
        key,
    )
    with _LOCK:
        _MEMORY[key] = session
    _disk_store(session)
    return session


# ---------------------------------------------------------------------------
# Query answering (mirrors _osm_pbf_scan._scan_chunk, but from memory)
# ---------------------------------------------------------------------------


def query_session(
    session: OsmSession,
    node_sels: list[Selector],
    way_sels: list[Selector],
    rel_sels: list[Selector],
) -> scan.ScanResult:
    """Answer a selector query from *session*, returning a :class:`ScanResult`.

    The result has the exact shape :func:`shared._osm_pbf_scan.scan` returns, so
    the caller resolves geometry identically whether the pass was a targeted
    scan or a session lookup.
    """
    node_elements: list[dict] = []
    matched_ways: dict = {}
    matched_rels: dict = {}
    needed_nodes: set[int] = set()
    needed_ways: set[int] = set()

    if node_sels:
        for node_id, tags, (lon, lat) in session.tagged_nodes:
            sel = scan._match(node_sels, tags)
            if sel is not None and scan._in_bbox(lon, lat, sel.bbox):
                node_elements.append(
                    {"type": "node", "id": node_id, "lat": lat, "lon": lon, "tags": dict(tags)}
                )

    if way_sels:
        for way_id, (tags, refs) in session.tagged_ways.items():
            sel = scan._match(way_sels, tags)
            if sel is not None:
                matched_ways[way_id] = (dict(tags), refs, sel.bbox)
                needed_nodes.update(refs)

    if rel_sels:
        for rel_id, (tags, members) in session.tagged_rels.items():
            sel = scan._match(rel_sels, tags)
            if sel is not None:
                matched_rels[rel_id] = (dict(tags), list(members), sel.bbox)
                for ref, mtype, _role in members:
                    if mtype == "WAY":
                        needed_ways.add(ref)
                    elif mtype == "NODE":
                        needed_nodes.add(ref)

    return scan.ScanResult(
        node_elements,
        matched_ways,
        matched_rels,
        needed_nodes,
        needed_ways,
        session.node_index,
        session.way_index,
    )
