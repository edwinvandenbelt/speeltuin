"""
Add speed bump attributes to the NWB network GeoJSON (default values).

Adds:
  - speed_bumps  (default: 'niet aanwezig')

No external data source is currently available for this attribute.
Replace the default with actual data when a source becomes available.

Usage:
    python add_speed_bumps.py
    python add_speed_bumps.py -i nwb_network.geojson -o nwb_network_speed_bumps.geojson
"""
import argparse
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

def compute_bbox(geojson):
    """Compute a bounding box (minlon, minlat, maxlon, maxlat) from GeoJSON features.

    If the GeoJSON already has a bbox in its 'properties', use that directly.
    Otherwise walk all feature geometries to determine bounds (WGS84).
    """
    props = geojson.get("properties") or {}
    if "bbox" in props and len(props["bbox"]) >= 4:
        return tuple(props["bbox"][:4])

    min_x, min_y = float("inf"), float("inf")
    max_x, max_y = float("-inf"), float("-inf")

    def update_bounds(coords):
        nonlocal min_x, min_y, max_x, max_y
        if isinstance(coords[0], (int, float)):
            x, y = coords[0], coords[1]
            min_x = min(min_x, x)
            max_x = max(max_x, x)
            min_y = min(min_y, y)
            max_y = max(max_y, y)
        else:
            for item in coords:
                update_bounds(item)

    for feature in geojson.get("features", []):
        geom = feature.get("geometry")
        if geom and "coordinates" in geom:
            update_bounds(geom["coordinates"])

    if min_x == float("inf"):
        return None

    return (min_x, min_y, max_x, max_y)


def build_sql(bbox=None):
    """Build the speed extraction SQL, optionally filtered to a WGS84 bounding box."""
    spatial_clause = ""
    if bbox:
        minlon, minlat, maxlon, maxlat = bbox
        wkt = (
            f"POLYGON(({minlon} {minlat}, {maxlon} {minlat}, "
            f"{maxlon} {maxlat}, {minlon} {maxlat}, {minlon} {minlat}))"
        )
        spatial_clause = f"""
    AND ST_Intersects(
        ST_SetSRID(ST_GeomFromText('{wkt}'), 4326),
        ST_Transform(nwb.geom_28992, 4326)
    )"""

    return f"""
WITH basis AS (
    SELECT
        *,
        CASE
            WHEN WVK_ID IS NULL OR trim(WVK_ID) = '' THEN 'onbekend'
            WHEN size(array_distinct(split(WVK_ID, ','))) > 1 THEN 'kruising'
            ELSE 'wegvak'
        END AS kruising_of_wegvak,
        array_distinct(
            transform(
                split(WVK_ID, ','),
                x -> trim(x)
            )
        ) AS wvk_id_array_uniek
    FROM nwb.tussenbestanden.`2025_drempels`
),
exploded AS (
    SELECT
        kruising_of_wegvak,
        explode(wvk_id_array_uniek) AS wvk_id
    FROM basis
    WHERE WVK_ID IS NOT NULL
      AND trim(WVK_ID) <> ''
),
resultaat AS (
    SELECT
        wvk_id,
        SUM(CASE WHEN kruising_of_wegvak = 'wegvak' THEN 1 ELSE 0 END) AS aantal_drempels_op_wegvak,
        SUM(CASE WHEN kruising_of_wegvak = 'kruising' THEN 1 ELSE 0 END) AS aantal_drempels_op_kruising,
        COUNT(*) AS totaal_aantal_drempels
    FROM exploded
    WHERE wvk_id <> ''
    GROUP BY wvk_id
)
SELECT 
    wvk_id,
    CASE 
        WHEN aantal_drempels_op_wegvak > 0 AND aantal_drempels_op_kruising > 0 THEN 'op wegvakken en kruispunten'
        WHEN aantal_drempels_op_wegvak > 0 THEN 'op wegvakken'
        WHEN aantal_drempels_op_kruising > 0 THEN 'op kruispunten'
        ELSE 'niet aanwezig' 
    END AS drempels_aanwezig
FROM resultaat
ORDER BY wvk_id
"""


def build_bumps_lookup(columns, rows):
    """Build a dict mapping wvk_id -> max_speed from query results."""
    wvk_idx = columns.index("wvk_id")
    drempels_idx = columns.index("drempels_aanwezig")

    lookup = {}
    for row in rows:
        wvk_id = row[wvk_idx]
        speed_bumps = row[drempels_idx]
        lookup[str(wvk_id)] = speed_bumps

    return lookup

def main():
# Load input GeoJSON
    print(f"Loading {INPUT_FILE}...")
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    print(f"  {len(geojson['features'])} features loaded")

    # Determine bounding box for spatial filtering
    bbox = compute_bbox(geojson)
    if bbox:
        print(f"  Bounding box: {bbox}")
    else:
        print("  No bounding box found, querying full network")

    # Query bumps data from Databricks
    sql = build_sql(bbox)
    columns, rows = execute_sql(sql)

    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} bumps records retrieved")

    bumps_lookup = build_bumps_lookup(columns, rows)

    # Merge bumps into GeoJSON features
    matched = 0
    for feature in geojson["features"]:
        wvk_id = str(feature["properties"].get("wvk_id", ""))
        if wvk_id in bumps_lookup:
            feature["properties"]["speed_bumps"] = bumps_lookup[wvk_id]
            matched += 1
        else:
            feature["properties"]["speed_bumps"] = "niet aanwezig"

    print(f"  {matched} features matched with bumps data")

    # Save output
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {OUTPUT_FILE} ({len(geojson['features'])} features)")

if __name__ == "__main__":
    main()
