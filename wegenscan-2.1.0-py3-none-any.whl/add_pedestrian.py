"""
Add pedestrian attributes to the NWB network GeoJSON.

Queries NWB tables for:
  - Pedestrian presence (vtgngr_h/t from verkeerstypen)
  - Pedestrian crossings (voetgangeroversteekplaats)
  - Median refuge (middenbermbreedte)

Derives:
  - pedestrian_location
  - pedestrian_crossing

Usage:
    python add_pedestrian.py
    python add_pedestrian.py -i nwb_network.geojson -o nwb_network_pedestrian.geojson
"""
import argparse
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

# NOTE: Table names may need adjustment to match the actual schema.
SQL_QUERY = """
SELECT
    t.wvk_id,
    t.vtgngr_h,
    t.vtgngr_t
FROM nwb.`2026_02`.wkd_vrkrstpnv2 t

"""

def flag(value):
    """Convert a flag value to bool."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.upper() in ("J", "TRUE", "1", "YES")
    return bool(value)


def derive_pedestrian(vtgngr_h, vtgngr_t):
    """Derive pedestrian_location and pedestrian_crossing."""
    no_pedestrians = not vtgngr_h and not vtgngr_t

    if no_pedestrians:
        return {
            "pedestrian_location": "niet van toepassing",
            "pedestrian_crossing": "niet van toepassing",
        }

    # Pedestrians are present
    location = "op voetpad/trottoir"

    crossing = "uit de voorrang / geen voorziening"

    return {
        "pedestrian_location": location,
        "pedestrian_crossing": crossing,
    }


def build_lookup(columns, rows):
    """Build a dict mapping wvk_id -> pedestrian properties."""
    idx = {col: i for i, col in enumerate(columns)}

    lookup = {}
    for row in rows:
        wvk_id = str(row[idx["wvk_id"]])
        vtgngr_h = flag(row[idx["vtgngr_h"]])
        vtgngr_t = flag(row[idx["vtgngr_t"]])

        lookup[wvk_id] = derive_pedestrian(
            vtgngr_h, vtgngr_t
        )
    return lookup


def main():
    parser = argparse.ArgumentParser(
        description="Add pedestrian attributes from NWB to GeoJSON"
    )
    parser.add_argument("-i", "--input", default=INPUT_FILE)
    parser.add_argument("-o", "--output", default=OUTPUT_FILE)
    args = parser.parse_args()

    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    columns, rows = execute_sql(SQL_QUERY)
    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} pedestrian records retrieved")
    lookup = build_lookup(columns, rows)

    matched = 0
    for feature in geojson["features"]:
        props = feature["properties"]
        wvk_id = str(props.get("wvk_id", ""))
        props["pedestrian_width"] = 0  # default, as NWB does not provide width data
        if wvk_id in lookup:
            props.update(lookup[wvk_id])
            matched += 1
        else:
            props["pedestrian_location"] = "op voetpad/trottoir"
            props["pedestrian_crossing"] = "uit de voorrang / geen voorziening"

    print(f"  {matched}/{num_features} features matched")

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output}")


if __name__ == "__main__":
    main()
