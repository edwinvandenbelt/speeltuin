"""
Add bus facility attributes to the NWB network GeoJSON (default values).

Adds:
  - bus_frequency  (default: 'niet aanwezig')
  - bus_facility   (default: 'niet van toepassing')

No external data source is currently available for these attributes.
Replace the defaults with actual data when a source becomes available.

Usage:
    python add_bus.py
    python add_bus.py -i nwb_network.geojson -o nwb_network_bus.geojson
"""
import argparse
import json

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

DEFAULT_BUS_FREQUENCY = "niet aanwezig"
DEFAULT_BUS_FACILITY = "niet van toepassing"


def main():
    parser = argparse.ArgumentParser(
        description="Add bus facility attributes (defaults) to GeoJSON"
    )
    parser.add_argument("-i", "--input", default=INPUT_FILE)
    parser.add_argument("-o", "--output", default=OUTPUT_FILE)
    args = parser.parse_args()

    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    for feature in geojson["features"]:
        props = feature["properties"]
        props.setdefault("bus_frequency", DEFAULT_BUS_FREQUENCY)
        props.setdefault("bus_facility", DEFAULT_BUS_FACILITY)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output} ({num_features} features, defaults applied)")


if __name__ == "__main__":
    main()
