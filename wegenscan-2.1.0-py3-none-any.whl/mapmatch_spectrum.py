"""
Map-match NWB road segments to Spectrum autonetwerk links.

Reads an NWB GeoJSON (WGS84), computes the bounding box, performs a spatial
join between NWB segments and Spectrum's d110_toedeelbaar_autonetwerk links,
and merges the matched Spectrum link_id into each GeoJSON feature as the
``spectrum`` property.

Each NWB segment is matched to the Spectrum link with the longest geometric
overlap.

Usage:
    python mapmatch_spectrum.py
    python mapmatch_spectrum.py -i nwb_network.geojson -o nwb_network.geojson
"""
import argparse
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

# Buffer around the bounding box (in degrees, ~200 m at Dutch latitudes)
BBOX_BUFFER = 0.002

def build_sql(bbox_wkt):
    """Build SQL that spatial-joins NWB road geometries with Spectrum network links.

    The NWB geometry (EPSG:28992) is transformed to WGS84 for the spatial join.
    Spectrum geometries are also in EPSG:28992 and transformed to WGS84.
    A ~5 m buffer is used for the spatial match.
    The best match per wvk_id (longest overlap) is selected via ROW_NUMBER.
    """
    return f"""
WITH spectrum_links AS (
    SELECT
        link_id AS spectrum_id,
        origineel_link_id,
        geom_4326 AS geom_wgs,
        ST_Transform(geom_4326, 28992) AS geom_rd
    FROM spectrum.`2024_01`.d110_toedeelbaar_autonetwerk
    WHERE ST_Intersects(
        ST_SetSRID(ST_GeomFromText('{bbox_wkt}'), 4326),
        geom_4326
    )
),
nwb_rd AS (
    SELECT
        nwb.wvk_id,
        nwb.geom_28992 AS geom_rd
    FROM nwb.`2026_02`.wegvakken AS nwb
    WHERE nwb.bst_code NOT IN (
        'VP','FP','RP','VZ','OVB','BUS','VDA','VDF','VDV',
        'PKP','BVP','PKB','TN','PP','PC','PR','DST','CADO','VV'
    )
),
direct_match_ranked AS (
    SELECT
        nwb.wvk_id,
        spectrum.spectrum_id,
        'wvk_id' AS match_type,
        nwb.geom_rd,
        ROW_NUMBER() OVER (
            PARTITION BY nwb.wvk_id
            ORDER BY ST_Length(
                ST_Intersection(
                    ST_Buffer(nwb.geom_rd, 10),
                    spectrum.geom_rd
                )
            ) DESC,
            spectrum.spectrum_id
        ) AS rn
    FROM nwb_rd nwb
    JOIN spectrum_links spectrum
      ON nwb.wvk_id = try_cast(spectrum.origineel_link_id AS BIGINT) 
),
direct_match AS (
    SELECT
        wvk_id,
        spectrum_id,
        match_type,
        geom_rd,
        -1 AS overlap_percentage
    FROM direct_match_ranked
    WHERE rn = 1
),
buffer_match_ranked AS (
    SELECT
        nwb.wvk_id,
        spectrum.spectrum_id,
        'buffer' AS match_type,
        nwb.geom_rd,
        ST_Length(
            ST_Intersection(
                ST_Buffer(nwb.geom_rd, 10),
                spectrum.geom_rd
            )
        ) AS overlap_length,
        (
            ST_Length(
                ST_Intersection(
                    ST_Buffer(nwb.geom_rd, 10),
                    spectrum.geom_rd
                )
            )
            /
            ST_Length(nwb.geom_rd)
        )*100
        AS overlap_percentage,
        ROW_NUMBER() OVER (
            PARTITION BY nwb.wvk_id
            ORDER BY ST_Length(
                ST_Intersection(
                    ST_Buffer(nwb.geom_rd, 10),
                    spectrum.geom_rd
                )
            ) DESC,
            spectrum.spectrum_id
        ) AS rn
    FROM nwb_rd nwb
    JOIN spectrum_links spectrum
      ON ST_Intersects(
           ST_Buffer(nwb.geom_rd, 10),
           spectrum.geom_rd
         )
    WHERE NOT EXISTS (
        SELECT 1
        FROM direct_match 
        WHERE direct_match.wvk_id = nwb.wvk_id
    )
),
buffer_match AS (
    SELECT
        wvk_id,
        spectrum_id,
        match_type,
        geom_rd,
        overlap_percentage
    FROM buffer_match_ranked
    WHERE rn = 1
      AND overlap_percentage > 60
),
all_matches AS (
   SELECT * FROM direct_match
   UNION ALL
    SELECT * FROM buffer_match
)
SELECT
    wvk_id,
    spectrum_id,
    match_type,
    overlap_percentage    
FROM all_matches
;"""



def compute_bbox_wkt(geojson):
    """Compute a WKT POLYGON bounding box from a GeoJSON FeatureCollection.

    If the GeoJSON has a bbox in its 'properties', use that directly.
    Otherwise walk all feature geometries to determine bounds.
    Coordinates are WGS84 (EPSG:4326).
    """
    props = geojson.get("properties") or {}
    if "bbox" in props and len(props["bbox"]) >= 4:
        min_x, min_y, max_x, max_y = props["bbox"][:4]
    else:
        min_x, min_y = float("inf"), float("inf")
        max_x, max_y = float("-inf"), float("-inf")

        def update_bounds(coords):
            nonlocal min_x, min_y, max_x, max_y
            if isinstance(coords[0], (int, float)):
                x, y = coords[0], coords[1]
                min_x = min(min_x, x)
                max_x = max(max_x, x)
                min_y = min(min_y, y)
                max_y = max(max_y, y)
            else:
                for item in coords:
                    update_bounds(item)

        for feature in geojson["features"]:
            geom = feature.get("geometry")
            if geom and "coordinates" in geom:
                update_bounds(geom["coordinates"])

    min_x -= BBOX_BUFFER
    min_y -= BBOX_BUFFER
    max_x += BBOX_BUFFER
    max_y += BBOX_BUFFER

    return (
        f"POLYGON(({min_x} {min_y}, {max_x} {min_y}, "
        f"{max_x} {max_y}, {min_x} {max_y}, {min_x} {min_y}))"
    )


def main():
    parser = argparse.ArgumentParser(
        description="Map-match NWB road segments to Spectrum autonetwerk links"
    )
    parser.add_argument(
        "-i", "--input",
        type=str,
        default=INPUT_FILE,
        help=f"Input NWB GeoJSON file (default: {INPUT_FILE})",
    )
    parser.add_argument(
        "-o", "--output",
        type=str,
        default=OUTPUT_FILE,
        help=f"Output GeoJSON file (default: {OUTPUT_FILE})",
    )
    args = parser.parse_args()

    # Load input GeoJSON
    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    if num_features == 0:
        print("No features found, nothing to do.")
        sys.exit(0)

    # Compute bounding box
    bbox_wkt = compute_bbox_wkt(geojson)
    print(f"  Bounding box (WGS84): {bbox_wkt[:80]}...")

    # Run spatial join
    sql = build_sql(bbox_wkt)
    #print(f" {sql}")
    columns, rows = execute_sql(sql)

    for row in rows:
        print(row)

    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} matches found")

    # Build wvk_id -> spectrum_id lookup from query results
    wvk_idx = columns.index("wvk_id")
    spec_idx = columns.index("spectrum_id")
    match_type_idx = columns.index("match_type")

    lookup = {
        str(row[wvk_idx]): (
            str(row[spec_idx]) if row[spec_idx] is not None else None,
            str(row[match_type_idx]) if row[match_type_idx] is not None else None,
        )
        for row in rows
    }

    matched = 0
    features = geojson.get("features", [])

    for feature in features:
        props = feature.setdefault("properties", {})
        match = lookup.get(str(props.get("wvk_id"))) if props.get("wvk_id") is not None else None

        if match is not None:
            props["spectrum"], props["spectrum_match_type"] = match
            matched += 1
        else:
            props["spectrum"] = None
            props["spectrum_match_type"] = None

    print(f"  {matched}/{len(features)} features matched with Spectrum links")

    # Save output GeoJSON
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output} ({num_features} features)")
if __name__ == "__main__":
    main()
