"""
Extract base NWB road network to GeoJSON.

Queries the NWB road segments with geometry, street name, city, municipality
and road width. Outputs nwb_network.geojson.

Usage:
    python extract_nwb_network.py                              # full network
    python extract_nwb_network.py --bbox 4.3,52.0,4.4,52.1    # bounding box (minlon,minlat,maxlon,maxlat)
    python extract_nwb_network.py --wkt "POLYGON((4.3 52.0, 4.4 52.0, 4.4 52.1, 4.3 52.1, 4.3 52.0))"
"""
import argparse
import json
import sys
from decimal import Decimal

from db import execute_sql


class DecimalEncoder(json.JSONEncoder):
    """JSON encoder that converts Decimal to float."""
    def default(self, o):
        if isinstance(o, Decimal):
            return float(o)
        return super().default(o)

OUTPUT_FILE = "nwb_network.geojson"

def build_sql(spatial_filter=None):
    """Build the extraction SQL, optionally with a spatial filter clause."""
    spatial_clause = ""
    if spatial_filter:
        spatial_clause = f"""
    AND ST_Intersects(
        ST_SetSRID(ST_GeomFromText('{spatial_filter}'), 4326),
        ST_Transform(nwb.geom_28992, 4326)
    )"""

    return f"""
WITH wegbreedte AS (
    SELECT
        wvk_id,
        round(AVG(breedte::numeric),1) breedte,
        MIN(brdt_min::numeric) brdt_min,
        MAX(brdt_max::numeric) brdt_max
    FROM  nwb.`2026_01_jaarlijks`.wkd_wegbrdtv2
    WHERE breedte NOT IN ('onbekend')
    GROUP BY wvk_id
)
SELECT
    nwb.wvk_id,
    nwb.STT_NAAM  AS street,
    nwb.WPSNAAM   AS city,
    nwb.GME_NAAM  AS municipality,
    wb.breedte    AS width,
    wb.brdt_min   AS min_width,
    wb.brdt_max   AS max_width,
    ST_AsGeoJSON(ST_Transform(nwb.geom_28992, 4326)) AS geom
FROM nwb.`2026_01`.wegvakken AS nwb
LEFT JOIN wegbreedte wb USING (wvk_id)
WHERE nwb.bst_code NOT IN (
    'VP','FP','RP','VZ','OVB','BUS','VDA','VDF','VDV',
    'PKP','BVP','PKB','TN','PP','PC','PR','DST','CADO','VV'
){spatial_clause}
"""

def bbox_to_wkt(bbox_str):
    """Convert a 'minlon,minlat,maxlon,maxlat' string to a WKT POLYGON."""
    parts = [float(x.strip()) for x in bbox_str.split(",")]
    if len(parts) != 4:
        raise ValueError("Bounding box must have exactly 4 values: minlon,minlat,maxlon,maxlat")
    minlon, minlat, maxlon, maxlat = parts
    return (
        f"POLYGON(({minlon} {minlat}, {maxlon} {minlat}, "
        f"{maxlon} {maxlat}, {minlon} {maxlat}, {minlon} {minlat}))"
    )

def rows_to_geojson(columns, rows):
    """Convert query result rows into a GeoJSON FeatureCollection."""
    geom_index = columns.index("geom")

    features = []
    min_x, min_y = float("inf"), float("inf")
    max_x, max_y = float("-inf"), float("-inf")

    def update_bounds(coords):
        nonlocal min_x, min_y, max_x, max_y
        if isinstance(coords[0], (int, float)):
            min_x = min(min_x, coords[0])
            max_x = max(max_x, coords[0])
            min_y = min(min_y, coords[1])
            max_y = max(max_y, coords[1])
        else:
            for item in coords:
                update_bounds(item)

    for row in rows:
        geom_value = row[geom_index]
        if not geom_value:
            continue

        geometry = json.loads(geom_value) if isinstance(geom_value, str) else geom_value

        if geometry and "coordinates" in geometry:
            update_bounds(geometry["coordinates"])

        properties = {}
        for i, col in enumerate(columns):
            if col != "geom":
                properties[col] = row[i]

        features.append({
            "type": "Feature",
            "geometry": geometry,
            "properties": properties,
        })

    result = {
        "type": "FeatureCollection",
        "properties": {},
        "features": features,
        "crs": {
            "type": "name",
            "properties": {
                "name": "urn:ogc:def:crs:OGC:1.3:CRS84"
            }
        }
    }

    if min_x != float("inf"):
        result["properties"]["bbox"] = [min_x, min_y, max_x, max_y]

    return result


def main():
    parser = argparse.ArgumentParser(description="Extract NWB road network to GeoJSON")
    group = parser.add_mutually_exclusive_group()
    group.add_argument(
        "--bbox",
        type=str,
        help="Bounding box as minlon,minlat,maxlon,maxlat (WGS84)",
    )
    group.add_argument(
        "--wkt",
        type=str,
        help="WKT geometry string (e.g. POLYGON) in WGS84 to spatially filter",
    )
    parser.add_argument(
        "-o", "--output",
        type=str,
        default=OUTPUT_FILE,
        help=f"Output file path (default: {OUTPUT_FILE})",
    )
    args = parser.parse_args()

    spatial_filter = None
    if args.bbox:
        spatial_filter = bbox_to_wkt(args.bbox)
        print(f"Spatial filter (bbox): {spatial_filter}")
    elif args.wkt:
        spatial_filter = args.wkt
        print(f"Spatial filter (WKT): {spatial_filter}")

    sql = build_sql(spatial_filter)
    columns, rows = execute_sql(sql)

    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"Retrieved {len(rows)} rows, converting to GeoJSON...")

    geojson = rows_to_geojson(columns, rows)

    output_path = args.output
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False, cls=DecimalEncoder)

    print(f"GeoJSON saved to {output_path} ({len(geojson['features'])} features)")

if __name__ == "__main__":
    main()
