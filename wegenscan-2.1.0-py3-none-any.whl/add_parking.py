"""
Add parking attributes to the NWB network GeoJSON.

Queries wkd_parkvlak for parking area per road segment and derives:
  - parking_location  (haaksparkeren / langsparkeren / op de rijbaan / niet van toepassing)
  - parking_width     (average parking width in meters)

The parking location logic follows the original wegenscan:
  - If parking area exists and avg width > 3.5 m → haaksparkeren
  - If parking area exists and avg width <= 3.5 m → langsparkeren
  - If no parking area and road category LIKE 'GOW 50' → 'niet van toepassing'
  - If no parking and fietsstroken → 'niet van toepassing'
  - If no parking area and speed <= 50 → op de rijbaan
  - Otherwise → niet van toepassing

Usage:
    python add_parking.py
    python add_parking.py -i nwb_network.geojson -o nwb_network_parking.geojson
"""
import argparse
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

# NOTE: Table name may need adjustment to match the actual schema.
SQL_QUERY = """
SELECT
    wvk_id,
    AVG(oppervlak / (CAST(tot AS DOUBLE) - CAST(van AS DOUBLE))) AS parkeer_breedte
FROM nwb.2025_01_jaarlijks.wkd_parkvlak
WHERE oppervlak IS NOT NULL
  AND (CAST(tot AS DOUBLE) - CAST(van AS DOUBLE)) > 0
  AND (oppervlak / (CAST(tot AS DOUBLE) - CAST(van AS DOUBLE))) < 7
GROUP BY wvk_id
"""


def derive_parking(parkeer_breedte):
    """Derive parking_location and parking_width from parking width."""
    if parkeer_breedte is not None:
        width = round(float(parkeer_breedte), 2)
        if width > 3.5:
            return {"parking_location": "haaksparkeren", "parking_width": width}
        return {"parking_location": "langsparkeren", "parking_width": width}
    return None

def derive_parking_from_road_category(road_category):
    """Derive parking_location when no parking data is available, based on road category."""
    if road_category is not None:
        if "GOW 50" in road_category:
            return {"parking_location": "niet van toepassing", "parking_width": 0}
    return None

def derive_parking_from_bicycle_location(bicycle_location):
    """Derive parking_location when no parking data is available, based on road category."""
    if bicycle_location is not None:
        if "fietsstroken" in bicycle_location:
            return {"parking_location": "niet van toepassing", "parking_width": 0}
    return None

def derive_parking_from_speed(max_speed):
    """Derive parking_location when no parking data is available, based on speed."""
    if max_speed is not None and max_speed != -1:
        try:
            sp = int(max_speed)
        except (TypeError, ValueError):
            sp = 0
        if sp <= 50:
            return {"parking_location": "op de rijbaan", "parking_width": 0}
    return {"parking_location": "niet van toepassing", "parking_width": 0}



def derive_parking_from_speed(max_speed):
    """Derive parking_location when no parking data is available, based on speed."""
    if max_speed is not None and max_speed != -1:
        try:
            sp = int(max_speed)
        except (TypeError, ValueError):
            sp = 0
        if sp <= 50:
            return {"parking_location": "op de rijbaan", "parking_width": 0}
    return {"parking_location": "niet van toepassing", "parking_width": 0}


def build_lookup(columns, rows):
    """Build a dict mapping wvk_id -> parking properties."""
    idx = {col: i for i, col in enumerate(columns)}

    lookup = {}
    for row in rows:
        wvk_id = str(row[idx["wvk_id"]])
        parkeer_breedte = row[idx["parkeer_breedte"]]
        result = derive_parking(parkeer_breedte)
        if result:
            lookup[wvk_id] = result
    return lookup


def main():
    parser = argparse.ArgumentParser(
        description="Add parking attributes from NWB to GeoJSON"
    )
    parser.add_argument("-i", "--input", default=INPUT_FILE)
    parser.add_argument("-o", "--output", default=OUTPUT_FILE)
    args = parser.parse_args()

    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    columns, rows = execute_sql(SQL_QUERY)
    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} parking records retrieved")
    lookup = build_lookup(columns, rows)

    matched = 0
    for feature in geojson["features"]:
        props = feature["properties"]
        wvk_id = str(props.get("wvk_id", ""))
        if wvk_id in lookup:
            props.update(lookup[wvk_id])
            matched += 1
        else:
            derived = None

            # Eerst road_category proberen
            road_category = props.get("road_category")
            derived = derive_parking_from_road_category(road_category)

            # Als dat niets oplevert: bicycle_location
            if derived is None:
                bicycle_location = props.get("bicycle_location")
                derived = derive_parking_from_bicycle_location(bicycle_location)

            # Als dat ook niets oplevert: max_speed
            if derived is None:
                max_speed = props.get("max_speed", -1)
                derived = derive_parking_from_speed(max_speed)

            # Alleen updaten als er echt iets is teruggegeven
            if derived is not None:
                props.update(derived)

    print(f"  {matched}/{num_features} features matched")

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output}")


if __name__ == "__main__":
    main()
