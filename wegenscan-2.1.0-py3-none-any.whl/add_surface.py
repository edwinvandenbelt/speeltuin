"""
Add road surface attributes to the NWB network GeoJSON using OSM data.

Reads an NWB GeoJSON whose features already contain an ``osm`` property
(set by mapmatch_osm.py), then queries OSM surface attributes for the
matched way IDs and merges them into the GeoJSON features.

Requires mapmatch_osm.py to have been run first so that the ``osm``
property is present on each feature.

Usage:
    python add_surface.py
    python add_surface.py -i nwb_network.geojson -o nwb_network.geojson
"""
import argparse
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"


def build_sql(way_ids):
    """Build SQL to fetch surface attributes for a set of OSM way IDs."""
    ids_list = ", ".join(way_ids)
    return f"""
SELECT
    way_id,
    tags['surface'] AS surface,
    tags['highway'] AS highway
FROM osm.silver.way
WHERE way_id IN ({ids_list})
  AND tags['surface'] IS NOT NULL
"""


def build_surface_lookup(columns, rows):
    """Build a dict mapping way_id -> {surface, highway} from query results."""
    wid_idx = columns.index("way_id")
    surface_idx = columns.index("surface")
    highway_idx = columns.index("highway")

    lookup = {}
    for row in rows:
        way_id = str(row[wid_idx])
        lookup[way_id] = {
            "surface": row[surface_idx],
            "highway": row[highway_idx],
        }
    return lookup


def main():
    parser = argparse.ArgumentParser(
        description="Add road surface from OSM to NWB network GeoJSON"
    )
    parser.add_argument(
        "-i", "--input",
        type=str,
        default=INPUT_FILE,
        help=f"Input GeoJSON file (default: {INPUT_FILE})",
    )
    parser.add_argument(
        "-o", "--output",
        type=str,
        default=OUTPUT_FILE,
        help=f"Output GeoJSON file (default: {OUTPUT_FILE})",
    )
    args = parser.parse_args()

    # Load input GeoJSON
    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    if num_features == 0:
        print("No features found, nothing to do.")
        sys.exit(0)

    # Collect unique OSM way IDs from feature properties
    unique_way_ids = set()
    for feature in geojson["features"]:
        way_id = feature["properties"].get("osm")
        if way_id:
            unique_way_ids.add(str(way_id))

    if not unique_way_ids:
        print("No OSM way IDs found in features, nothing to query.")
        sys.exit(0)

    print(f"  Querying surface attributes for {len(unique_way_ids)} OSM ways...")
    sql = build_sql(unique_way_ids)
    columns, rows = execute_sql(sql)

    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} surface records retrieved from OSM")

    surface_lookup = build_surface_lookup(columns, rows)

    # Merge surface into GeoJSON features via the osm property
    matched = 0
    for feature in geojson["features"]:
        way_id = feature["properties"].get("osm")
        if way_id and str(way_id) in surface_lookup:
            feature["properties"]["surface"] = surface_lookup[str(way_id)]["surface"]
            feature["properties"]["osm_highway"] = surface_lookup[str(way_id)]["highway"]
            matched += 1
        else:
            feature["properties"]["surface"] = None
            feature["properties"]["osm_highway"] = None

    print(f"  {matched}/{num_features} features matched with OSM surface data")

    # Save output
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output} ({num_features} features)")


if __name__ == "__main__":
    main()
