"""
Add road category attributes to the NWB network GeoJSON.

Reads nwb_network_speed.geojson (which must already contain max_speed),
queries the wegcat number per road segment from Databricks, and derives
the wegcat label and road_category. Outputs nwb_network_complete.geojson.

Usage:
    python add_road_category.py
"""
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

SQL_QUERY = """
SELECT
    wvk_id,
    MIN(
        CASE
            WHEN wegcat.weg_cat = "autosnelweg"    THEN 1
            WHEN wegcat.weg_cat = "autoweg"        THEN 2
            WHEN wegcat.weg_cat = "regionale weg"  THEN 3
            WHEN wegcat.weg_cat = "stadshoofdweg"  THEN 4
            WHEN wegcat.weg_cat = "lokale weg"     THEN 5
            WHEN wegcat.weg_cat = "straat"         THEN 6
            WHEN wegcat.weg_cat = "erf"            THEN 7
            ELSE 99
        END
    ) AS wegcat_number
FROM nwb.`2026_02`.wegvakken AS nwb
LEFT JOIN nwb.`2026_02`.wkd_weg_catv2 wegcat USING (wvk_id)
WHERE nwb.bst_code NOT IN (
    'VP','FP','RP','VZ','OVB','BUS','VDA','VDF','VDV',
    'PKP','BVP','PKB','TN','PP','PC','PR','DST','CADO','VV'
)
GROUP BY wvk_id
"""

WEGCAT_LABELS = {
    1: "autosnelweg",
    2: "autoweg",
    3: "regionale weg",
    4: "stadshoofdweg",
    5: "lokale weg",
    6: "straat",
    7: "erf",
}


def derive_wegcat(wegcat_number):
    """Map wegcat_number to its label."""
    return WEGCAT_LABELS.get(wegcat_number, "andere wegcat")


def derive_road_category(wegcat_number, max_speed):
    """Derive the road category from wegcat_number and max_speed."""
    if wegcat_number == 1:
        return "none"

    if wegcat_number == 2:
        if max_speed == 80:
            return "autoweg 80 km/h"
        return "autoweg 80 km/h"

    if wegcat_number in (3, 4):
        if max_speed >= 80:
            return "GOW 80 km/h"
        if max_speed >= 60:
            return "ETW-I 60 km/h"
        if 30 < max_speed < 60:
            return "GOW 50 km/h"
        return "GOW 30 km/h"

    if wegcat_number in (5, 6):
        if max_speed >= 60:
            return "ETW-II 60 km/h"
        if 50 <= max_speed < 60:
            return "geen categorie,50 km/uur"
        return "ETW 30 km/h"

    if wegcat_number == 7:
        if max_speed < 50:
            return "ETW 15 km/h (erf)"

    if max_speed == 30:
        return "ETW 30 km/h"
    elif max_speed == 50:
        return "GOW 50 km/h"
    elif max_speed == 60:
        return "ETW-I 60 km/h"

    return "geen snelheid of wegcategorie"


def build_wegcat_lookup(columns, rows):
    """Build a dict mapping wvk_id -> wegcat_number from query results."""
    wvk_idx = columns.index("wvk_id")
    cat_idx = columns.index("wegcat_number")

    lookup = {}
    for row in rows:
        wvk_id = row[wvk_idx]
        wegcat_number = row[cat_idx]
        try:
            wegcat_number = int(wegcat_number)
        except (TypeError, ValueError):
            wegcat_number = 99
        lookup[str(wvk_id)] = wegcat_number

    return lookup


def main():
    # Load input GeoJSON (must already contain max_speed from add_speed_attributes)
    print(f"Loading {INPUT_FILE}...")
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    print(f"  {len(geojson['features'])} features loaded")

    # Query road category data from Databricks
    columns, rows = execute_sql(SQL_QUERY)

    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} road category records retrieved")

    wegcat_lookup = build_wegcat_lookup(columns, rows)

    # Merge road category into GeoJSON features
    matched = 0
    for feature in geojson["features"]:
        props = feature["properties"]
        wvk_id = str(props.get("wvk_id", ""))
        max_speed = props.get("max_speed", -1)

        if isinstance(max_speed, str):
            try:
                max_speed = int(max_speed)
            except (TypeError, ValueError):
                max_speed = -1

        wegcat_number = wegcat_lookup.get(wvk_id, 99)
        props["wegcat_number"] = wegcat_number
        props["wegcat"] = derive_wegcat(wegcat_number)
        props["road_category"] = derive_road_category(wegcat_number, max_speed)

        if wvk_id in wegcat_lookup:
            matched += 1

    print(f"  {matched} features matched with road category data")

    # Save output
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {OUTPUT_FILE} ({len(geojson['features'])} features)")


if __name__ == "__main__":
    main()
