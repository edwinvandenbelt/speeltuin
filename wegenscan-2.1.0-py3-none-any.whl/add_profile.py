"""
Add traffic profile attributes to the NWB network GeoJSON.

Queries wkd_verkeerstypen for directional traffic type flags (auto, fiets,
vtgngr) per road segment and derives:
  - profile          (road usage profile: directions for cars + bikes)
  - bicycle_location (set to 'niet van toepassing' when no cyclists)
  - bicycle_crossing (set to 'niet van toepassing' when no cyclists)

Usage:
    python add_profile.py
    python add_profile.py -i nwb_network.geojson -o nwb_network_profile.geojson
"""
import argparse
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"


def compute_bbox(geojson):
    """Compute a bounding box (minlon, minlat, maxlon, maxlat) from GeoJSON features.

    If the GeoJSON already has a bbox in its 'properties', use that directly.
    Otherwise walk all feature geometries to determine bounds (WGS84).
    """
    props = geojson.get("properties") or {}
    if "bbox" in props and len(props["bbox"]) >= 4:
        return tuple(props["bbox"][:4])

    min_x, min_y = float("inf"), float("inf")
    max_x, max_y = float("-inf"), float("-inf")

    def update_bounds(coords):
        nonlocal min_x, min_y, max_x, max_y
        if isinstance(coords[0], (int, float)):
            x, y = coords[0], coords[1]
            min_x = min(min_x, x)
            max_x = max(max_x, x)
            min_y = min(min_y, y)
            max_y = max(max_y, y)
        else:
            for item in coords:
                update_bounds(item)

    for feature in geojson.get("features", []):
        geom = feature.get("geometry")
        if geom and "coordinates" in geom:
            update_bounds(geom["coordinates"])

    if min_x == float("inf"):
        return None

    return (min_x, min_y, max_x, max_y)


def build_sql(bbox=None):
    """Build the profile extraction SQL, optionally filtered to a WGS84 bounding box."""
    spatial_clause = ""
    if bbox:
        minlon, minlat, maxlon, maxlat = bbox
        wkt = (
            f"POLYGON(({minlon} {minlat}, {maxlon} {minlat}, "
            f"{maxlon} {maxlat}, {minlon} {maxlat}, {minlon} {minlat}))"
        )
        spatial_clause = f"""
WHERE ST_Intersects(
        ST_SetSRID(ST_GeomFromText('{wkt}'), 4326),
        ST_Transform(nwb.geom_28992, 4326)
    )"""

    return f"""
WITH fietstrook_raw AS (
  SELECT
    WVK_ID,
    CASE
      WHEN FTS_SUG_H = 1 AND FTS_SUG_T = 1 THEN 'both'
      WHEN FTS_SUG_H = 1 AND FTS_SUG_T = 0 THEN 'one side'
      WHEN FTS_SUG_H = 0 AND FTS_SUG_T = 1 THEN 'one side'
      ELSE 'none'
    END AS stroken,
    (tot - van) AS lengte
  FROM nwb.`2025_01_jaarlijks`.wkd_fietsstrk
),

-- Aggregate per WVK_ID and category
fietstrook_agg AS (
  SELECT
    WVK_ID,
    stroken,
    SUM(lengte) AS lengte
  FROM fietstrook_raw
  GROUP BY WVK_ID, stroken
),

-- Bring in the road segment length (one row per WVK_ID)
wegvakken AS (
  SELECT
    WVK_ID,
    ST_LENGTH(geom_28992) AS wegvaklengte
  FROM nwb.`2026_02`.wegvakken
),

-- Pivot to get lengths per category on one row, then compute "none" remainder
per_wvk AS (
  SELECT
    w.WVK_ID,
    w.wegvaklengte,
    COALESCE(SUM(CASE WHEN a.stroken = 'both'     THEN a.lengte END), 0.0) AS len_both,
    COALESCE(SUM(CASE WHEN a.stroken = 'one side' THEN a.lengte END), 0.0) AS len_one
  FROM wegvakken w
  LEFT JOIN fietstrook_agg a
    ON a.WVK_ID = w.WVK_ID
  GROUP BY w.WVK_ID, w.wegvaklengte
),

per_wvk_with_none AS (
  SELECT
    WVK_ID,
    wegvaklengte,
    len_both,
    len_one,
    GREATEST(wegvaklengte - (len_both + len_one), 0.0) AS len_none
  FROM per_wvk
),

-- Choose the category with the maximum length
winner AS (
  SELECT
    WVK_ID,
    CASE
      WHEN len_both >= len_one AND len_both >= len_none THEN 1 --'both'
      WHEN len_one  >= len_both AND len_one  >= len_none THEN 1 --'one side'
      ELSE 0
    END AS stroken,
    GREATEST(len_both, len_one, len_none) AS lengte,
    wegvaklengte
  FROM per_wvk_with_none
)

SELECT
  nwb.WVK_ID AS wvk_id,
  nwb.auto_h,
  nwb.auto_t,
  nwb.fiets_h,
  nwb.fiets_t,
  nwb.vtgngr_h,
  nwb.vtgngr_t,
  COALESCE(w.stroken, 0)  AS stroken,
  COALESCE(w.lengte,  0)  AS lengte,
  wegvaklengte,
  round((lengte/wegvaklengte)*100, 0) perc_stroken
FROM `nwb`.`2026_01`.`wkd_vrkrstpnv2` nwb
LEFT JOIN winner w
  ON w.WVK_ID = nwb.WVK_ID
{spatial_clause}
"""


def derive_profile(auto_h, auto_t, fiets_h, fiets_t, stroken):
    """Derive the traffic profile from directional flags."""
    bicycle_2_dir = fiets_h and fiets_t
    no_bicycles = not fiets_h and not fiets_t
    car_2_dir = auto_h and auto_t
    

    if no_bicycles:
        if car_2_dir:
            return "rijbaan auto 2 richtingen (geen fietsers)"
        return "rijbaan auto 1 richting (geen fietsers)"
    if stroken:
        if bicycle_2_dir and car_2_dir:
            return "fietsstroken (auto 2, fiets 2 richtingen)"
        if bicycle_2_dir and not car_2_dir:
            return "fietsstroken (auto 1, fiets 2 richtingen)"
        if not bicycle_2_dir and not car_2_dir:
            return "fietsstroken (auto 1, fiets 1 richting)"
    if bicycle_2_dir and car_2_dir:
        return "gemengd (auto 2, fiets 2 richtingen)"
    if bicycle_2_dir and not car_2_dir:
        return "gemengd (auto 1, fiets 2 richtingen)"
    if not bicycle_2_dir and not car_2_dir:
        return "gemengd (auto 1, fiets 1 richting)"

    # car_2_dir and single bicycle direction
    return "gemengd (auto 2, fiets 1 richting)"


def flag(value):
    """Convert a flag value (J/N/True/False/etc.) to bool."""
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.upper() in ("J", "TRUE", "1", "YES")
    return bool(value)


def build_lookup(columns, rows):
    """Build a dict mapping wvk_id -> traffic type flags."""
    idx = {col: i for i, col in enumerate(columns)}

    lookup = {}
    for row in rows:
        wvk_id = str(row[idx["wvk_id"]])
        auto_h = flag(row[idx["auto_h"]])
        auto_t = flag(row[idx["auto_t"]])
        fiets_h = flag(row[idx["fiets_h"]])
        fiets_t = flag(row[idx["fiets_t"]])
        stroken= flag(row[idx["stroken"]])
        no_bicycles = not fiets_h and not fiets_t
        no_stroken = not stroken

        lookup[wvk_id] = {
            "profile": derive_profile(auto_h, auto_t, fiets_h, fiets_t, stroken),
            "bicycle_location": "niet van toepassing" if no_bicycles else ("gemengd op rijbaan" if no_stroken else "fietsstroken"),
            "bicycle_width": 0,  # default, as NWB does not provide width data
            "bicycle_crossing": "niet van toepassing" if no_bicycles else "uit de voorrang / geen voorziening",
        }
    return lookup


def main():
    parser = argparse.ArgumentParser(
        description="Add traffic profile from NWB to GeoJSON"
    )
    parser.add_argument("-i", "--input", default=INPUT_FILE)
    parser.add_argument("-o", "--output", default=OUTPUT_FILE)
    args = parser.parse_args()

    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    # Determine bounding box for spatial filtering
    bbox = compute_bbox(geojson)
    if bbox:
        print(f"  Bounding box: {bbox}")
    else:
        print("  No bounding box found, querying full network")

    sql = build_sql(bbox)
    columns, rows = execute_sql(sql)
    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} traffic type records retrieved")
    lookup = build_lookup(columns, rows)

    matched = 0
    for feature in geojson["features"]:
        props = feature["properties"]
        wvk_id = str(props.get("wvk_id", ""))
        if wvk_id in lookup:
            props.update(lookup[wvk_id])
            matched += 1
        else:
            # Defaults from wegenscan_old
            props["profile"] = "gemengd (auto 2, fiets 2 richtingen)"
            props["bicycle_location"] = "niet van toepassing"
            props["bicycle_crossing"] = "uit de voorrang / geen voorziening"

    print(f"  {matched}/{num_features} features matched")

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output}")


if __name__ == "__main__":
    main()
