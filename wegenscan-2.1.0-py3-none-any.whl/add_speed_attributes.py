"""
Add speed attributes to the NWB network GeoJSON.

Reads nwb_network.geojson, queries max speed per road segment from Databricks,
and merges the speed data by wvk_id. Outputs nwb_network_speed.geojson.

Usage:
    python add_speed_attributes.py
"""
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

def compute_bbox(geojson):
    """Compute a bounding box (minlon, minlat, maxlon, maxlat) from GeoJSON features.

    If the GeoJSON already has a bbox in its 'properties', use that directly.
    Otherwise walk all feature geometries to determine bounds (WGS84).
    """
    props = geojson.get("properties") or {}
    if "bbox" in props and len(props["bbox"]) >= 4:
        return tuple(props["bbox"][:4])

    min_x, min_y = float("inf"), float("inf")
    max_x, max_y = float("-inf"), float("-inf")

    def update_bounds(coords):
        nonlocal min_x, min_y, max_x, max_y
        if isinstance(coords[0], (int, float)):
            x, y = coords[0], coords[1]
            min_x = min(min_x, x)
            max_x = max(max_x, x)
            min_y = min(min_y, y)
            max_y = max(max_y, y)
        else:
            for item in coords:
                update_bounds(item)

    for feature in geojson.get("features", []):
        geom = feature.get("geometry")
        if geom and "coordinates" in geom:
            update_bounds(geom["coordinates"])

    if min_x == float("inf"):
        return None

    return (min_x, min_y, max_x, max_y)


def build_sql(bbox=None):
    """Build the speed extraction SQL, optionally filtered to a WGS84 bounding box."""
    spatial_clause = ""
    if bbox:
        minlon, minlat, maxlon, maxlat = bbox
        wkt = (
            f"POLYGON(({minlon} {minlat}, {maxlon} {minlat}, "
            f"{maxlon} {maxlat}, {minlon} {maxlat}, {minlon} {minlat}))"
        )
        spatial_clause = f"""
    AND ST_Intersects(
        ST_SetSRID(ST_GeomFromText('{wkt}'), 4326),
        ST_Transform(nwb.geom_28992, 4326)
    )"""

    return f"""
SELECT
    wvk_id,
    MAX(
        CASE
            WHEN try_cast(MAXSHD AS int) > 0 THEN try_cast(MAXSHD AS int)
            ELSE -1
        END
    ) AS max_speed,
    MAX(
        CASE
            WHEN try_cast(e_s85 AS int) > 0 THEN try_cast(e_s85 AS int)
            ELSE -1
        END
    ) AS max_speed_s85
FROM nwb.`2026_02`.wegvakken AS nwb
LEFT JOIN nwb.`2026_02`.snelheden snelheden USING (wvk_id)
LEFT JOIN nwb.tussenbestanden.2025_s85_19400_met_snelheid AS snelheid USING (wvk_id)
WHERE nwb.bst_code NOT IN (
    'VP','FP','RP','VZ','OVB','BUS','VDA','VDF','VDV',
    'PKP','BVP','PKB','TN','PP','PC','PR','DST','CADO','VV'
){spatial_clause}
GROUP BY wvk_id
"""


def build_speed_lookup(columns, rows):
    """Build a dict mapping wvk_id -> max_speed from query results."""
    wvk_idx = columns.index("wvk_id")
    speed_idx = columns.index("max_speed")
    speed_max_idx = columns.index("max_speed_s85")
    

    lookup = {}
    for row in rows:
        wvk_id = row[wvk_idx]
        max_speed = row[speed_idx]
        max_speed_s85 = row[speed_max_idx]
        # Convert to int if possible
        try:
            max_speed = int(max_speed)
            max_speed_s85 = int(max_speed_s85)
        except (TypeError, ValueError):
            max_speed = -1
            max_speed_s85 = -1
        lookup[str(wvk_id)] = (max_speed, max_speed_s85)

    return lookup


def main():
    # Load input GeoJSON
    print(f"Loading {INPUT_FILE}...")
    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    print(f"  {len(geojson['features'])} features loaded")

    # Determine bounding box for spatial filtering
    bbox = compute_bbox(geojson)
    if bbox:
        print(f"  Bounding box: {bbox}")
    else:
        print("  No bounding box found, querying full network")

    # Query speed data from Databricks
    sql = build_sql(bbox)
    columns, rows = execute_sql(sql)

    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} speed records retrieved")

    speed_lookup = build_speed_lookup(columns, rows)

    # Merge speed into GeoJSON features
    matched = 0
    for feature in geojson["features"]:
        wvk_id = str(feature["properties"].get("wvk_id", ""))
        if wvk_id in speed_lookup:
            max_speed, max_speed_s85 = speed_lookup[wvk_id]
            feature["properties"]["max_speed"] = max_speed
            feature["properties"]["max_speed_s85"] = max_speed_s85
            matched += 1
        else:
            feature["properties"]["max_speed"] = -1
            feature["properties"]["max_speed_s85"] = -1

    print(f"  {matched} features matched with speed data")

    # Save output
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {OUTPUT_FILE} ({len(geojson['features'])} features)")


if __name__ == "__main__":
    main()
