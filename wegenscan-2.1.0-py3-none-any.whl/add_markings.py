"""
Add road marking attributes to the NWB network GeoJSON (default values).

Adds:
  - longitudinal_markings  (default: 'niet aanwezig')
  - separation             (default: 'niet aanwezig')

No external data source is currently available for these attributes.
Replace the defaults with actual data when a source becomes available.

Usage:
    python add_markings.py
    python add_markings.py -i nwb_network.geojson -o nwb_network_markings.geojson
"""
import argparse
import json
import sys

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

DEFAULT_LONGITUDINAL_MARKINGS = "niet aanwezig"
DEFAULT_SEPARATION = "niet aanwezig"


def main():
    parser = argparse.ArgumentParser(
        description="Add road marking attributes (defaults) to GeoJSON"
    )
    parser.add_argument("-i", "--input", default=INPUT_FILE)
    parser.add_argument("-o", "--output", default=OUTPUT_FILE)
    args = parser.parse_args()

    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    for feature in geojson["features"]:
        props = feature["properties"]
        props.setdefault("longitudinal_markings", DEFAULT_LONGITUDINAL_MARKINGS)
        props.setdefault("separation", DEFAULT_SEPARATION)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output} ({num_features} features, defaults applied)")


if __name__ == "__main__":
    main()
