"""
Wegenscan – safety KPI orchestrator.

Loads a fully-enriched NWB GeoJSON (output of the enrichment pipeline) and
computes safety KPIs for every road segment using the three core modules:

    * FunctieGebruik  – functional usage assessment
    * FunctieVorm     – functional form assessment
    * VormGebruik     – form-usage assessment

Results are stored under each feature's ``safety`` property (21 KPIs) together
with an aggregated ``generic_safety`` score.

Usage:
    python wegenscan.py
    python wegenscan.py -i enriched.geojson -o wegenscan_result.geojson
"""
import argparse
import json
import sys

from core.functie_gebruik import FunctieGebruik
from core.functie_vorm import FunctieVorm
from core.vorm_gebruik import VormGebruik

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "wegenscan_result.geojson"

fg = FunctieGebruik()
fv = FunctieVorm()
vg = VormGebruik()

# ---------------------------------------------------------------------------
# OSM surface → KPI surface translation
# ---------------------------------------------------------------------------
OPEN_SURFACES = ["stone", "paving", "paved", "brick", "rock", "tegels",
                 "straatstenen", "cobblestone", "sett", "paving_stones",
                 "unhewn_cobblestone"]
CLOSED_SURFACES = ["concrete", "tartan", "asphalt", "asfalt", "tarmac"]


def translate_surface(osm_surface: str | None) -> str:
    """Map raw OSM surface tag to the KPI surface category."""
    if osm_surface is None:
        return "gesloten (o.a. asfalt)"  # default assumption
    val = osm_surface.lower()
    for keyword in OPEN_SURFACES:
        if keyword in val:
            return "open (o.a.klinkers)"
    for keyword in CLOSED_SURFACES:
        if keyword in val:
            return "gesloten (o.a. asfalt)"
    return "gedeeltelijk open"


# ---------------------------------------------------------------------------
# Flow aggregation
# ---------------------------------------------------------------------------
def compute_total_flow(flow_prop) -> int:
    """Sum all hourly intensity values from the Spectrum flow property.

    ``flow_prop`` may be:
    - ``None``            → 0
    - an ``int``/``float``→ used directly
    - a ``dict``          → numeric values are summed (non-numeric keys like
      'modaliteit' and 'tijd_categorie' are skipped)
    """
    if flow_prop is None:
        return 0
    if isinstance(flow_prop, (int, float)):
        return int(flow_prop)
    if isinstance(flow_prop, dict):
        total = 0
        for v in flow_prop.values():
            if isinstance(v, (int, float)):
                total += v
        return int(total)
    return 0


# ---------------------------------------------------------------------------
# Build the input dict expected by the KPI functions
# ---------------------------------------------------------------------------
DEFAULTS = {
    "r_category": "ETW 15 km/h",
    "r_flow": 0,
    "r_speed": 30,
    "r_width": 6.0,
    "r_profile": "gemengd (auto 2, fiets 2 richtingen)",
    "r_surface": "open (o.a.klinkers)",
    "r_separation": "niet aanwezig",
    "r_longitudinal_markings": "niet aanwezig",
    "r_speed_bumps": "niet aanwezig",
    "r_pedestrian_location": "op voetpad/trottoir",
    "r_pedestrian_width": 0,
    "r_pedestrian_crossing": "uit de voorrang / geen voorziening",
    "r_bicycle_location": "niet van toepassing",
    "r_bicycle_width": 0,
    "r_bicycle_crossing": "uit de voorrang / geen voorziening",
    "r_parking_location": "op de rijbaan",
    "r_parking_width": 0,
    "r_bus_frequency": "niet aanwezig",
    "r_bus_facility": "niet van toepassing",
    "r_social_interaction": "ja",
}


def build_invoer(props: dict) -> dict:
    """Map GeoJSON feature properties to the flat *invoer* dict consumed by
    the KPI calculation, applying sensible defaults where values are missing.
    """
    invoer = dict(DEFAULTS)

    # road_category → category
    if props.get("road_category"):
        invoer["r_category"] = props["road_category"]

    # max_speed → speed
    if props.get("max_speed") and props["max_speed_s85"] > 0:
        invoer["r_speed"] = props["max_speed_s85"]

    # width
    if props.get("width") and props["width"] > 0:
        invoer["r_width"] = float(props["width"])

    # profile (from add_profile.py)
    if props.get("profile"):
        invoer["r_profile"] = props["profile"]

    # surface – translate from raw OSM tag
    invoer["r_surface"] = translate_surface(props.get("surface"))

    # flow – aggregate from Spectrum dict
    invoer["r_flow"] = compute_total_flow(props.get("flow"))

    # Directional properties (from enrichment scripts)
    for key in (
        "separation",
        "longitudinal_markings",
        "speed_bumps",
        "pedestrian_location",
        "pedestrian_width",
        "pedestrian_crossing",
        "bicycle_location",
        "bicycle_width",
        "bicycle_crossing",
        "parking_location",
        "bus_frequency",
        "bus_facility",
        "social_interaction",
    ):
        if props.get(key) is not None:
            invoer["r_" + key] = props[key]

    # parking_width
    if props.get("parking_width") is not None:
        invoer["r_parking_width"] = float(props["parking_width"])

    return invoer


# ---------------------------------------------------------------------------
# KPI calculation
# ---------------------------------------------------------------------------
def calculate_kpis(invoer: dict) -> dict:
    """Compute all 21 safety KPI properties from a single *invoer* dict.

    Returns a dict with string keys and values (GOED / REDELIJK / MATIG /
    SLECHT / NVT / ONBEKEND).
    """
    category = invoer["r_category"].replace(" (erf)", "")  # strip "(erf)" suffix for KPI lookup
    flow = invoer["r_flow"]
    width = invoer["r_width"]
    speed = invoer["r_speed"]
    profile = invoer["r_profile"]
    pedestrian_location = invoer["r_pedestrian_location"]
    pedestrian_width = invoer["r_pedestrian_width"]
    bicycle_location = invoer["r_bicycle_location"]
    bicycle_width = invoer["r_bicycle_width"]
    parking_location = invoer["r_parking_location"]
    parking_width = invoer["r_parking_width"]

    return {
        "r_functional_usage": fg.bereken(category, flow),
        "r_longitudinal_marking": fv.longitudinal_marking(
            category, invoer["r_longitudinal_markings"]
        ),
        "r_directional_separation": fv.directional_separations(
            category, invoer["r_separation"]
        ),
        "r_lane_width": fv.lane_width(category, width, profile),
        "r_road_surface": fv.road_surface(category, invoer["r_surface"]),
        "r_pedestrian_facility": fv.pedestrian_facility(category, pedestrian_location),
        "r_bicycle_facility": fv.bicycle_facility(category, bicycle_location),
        "r_parking_facility": fv.parking_facility(category, parking_location),
        "r_bus_stop_facility": fv.bus_stop_facility(
            category, invoer["r_bus_facility"]
        ),
        "r_speed_bumps": fv.speed_bumps(category, invoer["r_speed_bumps"]),
        "r_roadside_damage": vg.bermschade(
            width, flow, invoer["r_longitudinal_markings"]
        ),
        "r_road_width": vg.rijbaanbreedte(width, flow, parking_location, profile),
        "r_pedestrian_width": vg.pedestrian_width(pedestrian_width, pedestrian_location),
        "r_bicycle_width": vg.bicycle_width(bicycle_width, bicycle_location),
        "r_parking_location": vg.parking_width(flow, parking_location),
        "r_bus_location": vg.bus_stop_facility(
            invoer["r_bus_frequency"], invoer["r_bus_facility"], flow
        ),
        "r_pedestrian_crossing": vg.pedestrian_crossing(
            flow,
            width,
            invoer["r_pedestrian_crossing"],
            category,
            speed,
        ),
        "r_bicycle_crossing": vg.bicycle_crossing(
            flow,
            width,
            invoer["r_bicycle_crossing"],
            category,
            speed,
        ),
        "r_bike_speed": vg.speed_bike(category, speed, bicycle_location, width),
        "r_bike_usage": vg.usage_bike(flow, category, bicycle_location, width),
        "r_bike_parking": vg.bicycle_parking(
            parking_width, parking_location, bicycle_location, category
        ),
        "r_social_interaction": vg.social_interaction(
            flow, invoer["r_social_interaction"] == "ja"
        ),
    }


# ---------------------------------------------------------------------------
# Generic safety score
# ---------------------------------------------------------------------------
_SCORE_MAP = {"GOED": 3, "REDELIJK": 2, "MATIG": 1, "SLECHT": 0}


def calculate_generic_safety(safety: dict) -> str:
    """Compute a single aggregate safety judgement from all 21 KPI values."""
    total = 0
    count = 0
    for v in safety.values():
        score = _SCORE_MAP.get(v)
        if score is not None:
            total += score
            count += 1

    if count == 0:
        return "NVT"

    avg = total / count
    if avg > 2.2:
        return "GOED"
    if avg > 1.8:
        return "REDELIJK"
    if avg > 1:
        return "MATIG"
    return "SLECHT"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Compute Wegenscan safety KPIs for an enriched NWB GeoJSON"
    )
    parser.add_argument(
        "-i", "--input",
        type=str,
        default=INPUT_FILE,
        help=f"Input GeoJSON file (default: {INPUT_FILE})",
    )
    parser.add_argument(
        "-o", "--output",
        type=str,
        default=OUTPUT_FILE,
        help=f"Output GeoJSON file (default: {OUTPUT_FILE})",
    )
    args = parser.parse_args()

    # Load GeoJSON
    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    if num_features == 0:
        print("No features found, nothing to do.")
        sys.exit(0)

    # Calculate KPIs per feature
    errors = 0
    for feature in geojson["features"]:
        props = feature["properties"]
        invoer = build_invoer(props)
        try:
            safety = calculate_kpis(invoer)
            props.update(safety)
            props["generic_safety"] = calculate_generic_safety(safety)
        except Exception as exc:
            errors += 1
            wvk_id = props.get("wvk_id", "?")
            print(f"  [WARN] KPI calculation failed for wvk_id={wvk_id}: {exc}")
            props["generic_safety"] = None

    ok = num_features - errors
    print(f"  {ok}/{num_features} features scored successfully")

    # Save output
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output} ({num_features} features)")


if __name__ == "__main__":
    main()
