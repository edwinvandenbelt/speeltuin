"""
Add traffic flow (intensity) attributes to the NWB network GeoJSON using Spectrum data.

Reads an NWB GeoJSON whose features already contain a ``spectrum`` property
(set by mapmatch_spectrum.py), then queries intensity profiles from
spectrum.d300_intensiteitsprofielen_auto_vracht
(modaliteit = 'auto', tijd_categorie = 'maandag') for the matched Spectrum
link IDs and merges them into the GeoJSON features.

Requires mapmatch_spectrum.py to have been run first so that the ``spectrum``
property is present on each feature.

Usage:
    python add_flow.py
    python add_flow.py -i nwb_network.geojson -o nwb_network.geojson
"""
import argparse
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"


def build_sql(spectrum_ids):
    """Build SQL to fetch Monday car-traffic intensity profiles for a set of Spectrum IDs."""
    ids_list = ", ".join(f"'{sid}'" for sid in spectrum_ids)
    return f"""
SELECT *
FROM spectrum.`2024_01`.d300_intensiteitsprofielen_auto_vracht
WHERE link_id IN ({ids_list})
  AND modaliteit = 'auto'
  AND tijd_categorie = 'maandag'
"""


def build_flow_lookup(columns, rows):
    """Build a dict mapping spectrum_id -> total 24h flow (heen + terug).

    Sums gemiddelde_intensiteit_heen_voertuigen_per_etmaal_of_uur and
    gemiddelde_intensiteit_terug_voertuigen_per_etmaal_of_uur into a single value.
    """
    id_idx = columns.index("link_id")
    heen_idx = columns.index("gemiddelde_intensiteit_heen_voertuigen_per_etmaal_of_uur")
    terug_idx = columns.index("gemiddelde_intensiteit_terug_voertuigen_per_etmaal_of_uur")

    lookup = {}
    for row in rows:
        spectrum_id = str(row[id_idx])
        heen = row[heen_idx] or 0
        terug = row[terug_idx] or 0
        try:
            lookup[spectrum_id] = float(heen) + float(terug)
        except (TypeError, ValueError):
            lookup[spectrum_id] = 0

    return lookup


def main():
    parser = argparse.ArgumentParser(
        description="Add traffic flow from Spectrum to NWB network GeoJSON"
    )
    parser.add_argument(
        "-i", "--input",
        type=str,
        default=INPUT_FILE,
        help=f"Input GeoJSON file (default: {INPUT_FILE})",
    )
    parser.add_argument(
        "-o", "--output",
        type=str,
        default=OUTPUT_FILE,
        help=f"Output GeoJSON file (default: {OUTPUT_FILE})",
    )
    args = parser.parse_args()

    # Load input GeoJSON
    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    if num_features == 0:
        print("No features found, nothing to do.")
        sys.exit(0)

    # Collect unique Spectrum IDs from feature properties
    unique_spectrum_ids = set()
    for feature in geojson["features"]:
        spectrum_id = feature["properties"].get("spectrum")
        if spectrum_id:
            unique_spectrum_ids.add(str(spectrum_id))

    if not unique_spectrum_ids:
        print("No Spectrum IDs found in features, nothing to query.")
        sys.exit(0)

    print(f"  Querying intensity profiles for {len(unique_spectrum_ids)} Spectrum links...")
    sql = build_sql(unique_spectrum_ids)
    columns, rows = execute_sql(sql)

    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} flow records retrieved from Spectrum")

    flow_lookup = build_flow_lookup(columns, rows)

    # Merge flow into GeoJSON features via the spectrum property
    matched = 0
    for feature in geojson["features"]:
        spectrum_id = feature["properties"].get("spectrum")
        if spectrum_id and str(spectrum_id) in flow_lookup:
            feature["properties"]["flow"] = flow_lookup[str(spectrum_id)]
            matched += 1
        else:
            feature["properties"]["flow"] = 0

    print(f"  {matched}/{num_features} features matched with Spectrum flow data")

    # Save output
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output} ({num_features} features)")


if __name__ == "__main__":
    main()
