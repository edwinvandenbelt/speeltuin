"""
geojson_to_csv.py
-----------------
Exporteert alle feature-attributen (properties) uit een GeoJSON-bestand naar CSV.

Gebruik:
    python geojson_to_csv.py <input.geojson> [output.csv]

Als output.csv wordt weggelaten, wordt de naam afgeleid van het GeoJSON-bestand
(bijv. nwb_network.geojson -> nwb_network.csv).

Optioneel kan ook de geometry (WKT) als kolom worden meegenomen via --geometry.
"""

import argparse
import csv
import json
import sys
from pathlib import Path


def geometry_to_wkt(geometry) -> str:
    """Converteert een GeoJSON geometry-object naar een WKT-string (eenvoudige implementatie)."""
    if not geometry:
        return ""

    geom_type = geometry.get("type", "")
    coords = geometry.get("coordinates")
    if coords is None:
        return ""

    def fmt_coord(c):
        return f"{c[0]} {c[1]}"

    def fmt_ring(ring):
        return ", ".join(fmt_coord(c) for c in ring)

    if geom_type == "Point":
        return f"POINT ({fmt_coord(coords)})"
    elif geom_type == "MultiPoint":
        return f"MULTIPOINT ({', '.join(fmt_coord(c) for c in coords)})"
    elif geom_type == "LineString":
        return f"LINESTRING ({fmt_ring(coords)})"
    elif geom_type == "MultiLineString":
        parts = "; ".join(f"({fmt_ring(r)})" for r in coords)
        return f"MULTILINESTRING ({parts})"
    elif geom_type == "Polygon":
        rings = "; ".join(f"({fmt_ring(r)})" for r in coords)
        return f"POLYGON ({rings})"
    elif geom_type == "MultiPolygon":
        polys = ", ".join(
            f"({'; '.join(f'({fmt_ring(r)})' for r in poly)})" for poly in coords
        )
        return f"MULTIPOLYGON ({polys})"
    else:
        return json.dumps(geometry)


def collect_all_keys(features: list) -> list:
    """Verzamelt alle unieke property-sleutels in volgorde van eerste verschijning."""
    seen: set[str] = set()
    keys: list[str] = []
    for feature in features:
        for key in (feature.get("properties") or {}).keys():
            if key not in seen:
                seen.add(key)
                keys.append(key)
    return keys


def geojson_to_csv(
    input_path: Path,
    output_path: Path,
    include_geometry: bool = False,
) -> int:
    """
    Leest een GeoJSON-bestand en schrijft de properties naar CSV.

    Returns:
        Aantal weggeschreven features.
    """
    with input_path.open(encoding="utf-8") as f:
        data = json.load(f)

    # Ondersteun zowel FeatureCollection als losse Feature
    if data.get("type") == "FeatureCollection":
        features = data.get("features", [])
    elif data.get("type") == "Feature":
        features = [data]
    else:
        raise ValueError(
            f"Onverwacht GeoJSON-type: '{data.get('type')}'. "
            "Verwacht 'FeatureCollection' of 'Feature'."
        )

    if not features:
        print("Waarschuwing: geen features gevonden in het GeoJSON-bestand.")
        return 0

    property_keys = collect_all_keys(features)
    fieldnames = property_keys + (["geometry_wkt"] if include_geometry else [])

    with output_path.open("w", newline="", encoding="utf-8") as csvfile:
        writer = csv.DictWriter(
            csvfile,
            fieldnames=fieldnames,
            extrasaction="ignore",
            quoting=csv.QUOTE_MINIMAL,
        )
        writer.writeheader()

        for feature in features:
            props = dict(feature.get("properties") or {})
            if include_geometry:
                props["geometry_wkt"] = geometry_to_wkt(feature.get("geometry"))
            # Zorg dat ontbrekende kolommen leeg blijven
            row = {key: props.get(key, "") for key in fieldnames}
            writer.writerow(row)

    return len(features)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Exporteer GeoJSON feature-attributen naar CSV."
    )
    parser.add_argument("input", help="Pad naar het GeoJSON-bestand.")
    parser.add_argument(
        "output",
        nargs="?",
        help="Pad naar het uitvoer-CSV-bestand (optioneel).",
    )
    parser.add_argument(
        "--geometry",
        action="store_true",
        help="Voeg een 'geometry_wkt'-kolom toe met de geometrie als WKT.",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.is_file():
        print(f"Fout: bestand niet gevonden: {input_path}", file=sys.stderr)
        sys.exit(1)

    output_path = Path(args.output) if args.output else input_path.with_suffix(".csv")

    print(f"Inlezen : {input_path}")
    print(f"Schrijven: {output_path}")
    if args.geometry:
        print("Geometrie wordt als WKT meegenomen.")

    count = geojson_to_csv(input_path, output_path, include_geometry=args.geometry)
    print(f"Klaar: {count} features weggeschreven naar {output_path}")


if __name__ == "__main__":
    main()
