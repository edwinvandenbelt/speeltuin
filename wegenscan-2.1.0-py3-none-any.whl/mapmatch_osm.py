"""
Map-match NWB road segments to OSM ways.

Reads an NWB GeoJSON (WGS84), computes the bounding box, performs a spatial
join between NWB segments and OSM ways, and merges the matched OSM way_id
into each GeoJSON feature as the ``osm`` property.

Each NWB segment is matched to the OSM way with the longest geometric overlap.

Usage:
    python mapmatch_osm.py
    python mapmatch_osm.py -i nwb_network.geojson -o nwb_network.geojson
"""
import argparse
import json
import sys

from db import execute_sql

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

# Buffer around the bounding box (in degrees, ~200 m at Dutch latitudes)
BBOX_BUFFER = 0.002

def build_sql(bbox_wkt):
    """Build SQL that spatial-joins NWB road geometries with OSM ways.

    The NWB geometry (EPSG:28992) is transformed to WGS84 for the spatial join
    with OSM data. A ~5 m buffer is used. The best match per wvk_id (longest
    overlap) is selected via ROW_NUMBER.
    """
    return f"""
WITH osm_roads AS (
    SELECT
        way_id,
        ST_SetSRID(geometry,4326) AS geom
    FROM osm.silver.way
    WHERE tags['highway'] IS NOT NULL
      AND ST_Intersects(
            ST_SetSRID(ST_GeomFromText('{bbox_wkt}'),4326),
            ST_SetSRID(geometry,4326)
          )
),
nwb_4326 AS (
    SELECT
        nwb.wvk_id,
        ST_Transform(nwb.geom_28992, 4326) AS geom_wgs,
        nwb.bst_code
    FROM nwb.`2026_02`.wegvakken AS nwb
    WHERE nwb.bst_code NOT IN (
        'VP','FP','RP','VZ','OVB','BUS','VDA','VDF','VDV',
        'PKP','BVP','PKB','TN','PP','PC','PR','DST','CADO','VV'
    )
),
matched AS (
    SELECT
        n.wvk_id,
        o.way_id,
        ST_Intersection(
            ST_Buffer(n.geom_wgs, 0.00005),
            o.geom
        ) AS overlap_geom,
        n.geom_wgs,
        ST_Length(
            ST_Intersection(
                ST_Buffer(n.geom_wgs, 0.00005),
                o.geom
            )
        ) AS overlap_length,
        ROW_NUMBER() OVER (
            PARTITION BY n.wvk_id
            ORDER BY ST_Length(
                ST_Intersection(
                    ST_Buffer(n.geom_wgs, 0.00005),
                    o.geom
                )
            ) DESC
        ) AS rn
    FROM nwb_4326 n
    JOIN osm_roads o
      ON ST_Intersects(
           ST_Buffer(n.geom_wgs, 0.00005),
           o.geom
         )
)
SELECT
    wvk_id,
    way_id,
    overlap_length,
    ROUND(
        CASE WHEN ST_Length(geom_wgs) > 0 THEN
            GREATEST(0,
                (ST_Distance(ST_StartPoint(geom_wgs), ST_Centroid(overlap_geom))
                 - overlap_length / 2)
                / ST_Length(geom_wgs) * 100
            )
        ELSE 0 END, 1
    ) AS start_pct,
    ROUND(
        CASE WHEN ST_Length(geom_wgs) > 0 THEN
            LEAST(100,
                (ST_Distance(ST_StartPoint(geom_wgs), ST_Centroid(overlap_geom))
                 + overlap_length / 2)
                / ST_Length(geom_wgs) * 100
            )
        ELSE 100 END, 1
    ) AS end_pct
FROM matched
WHERE rn = 1
"""

def compute_bbox_wkt(geojson):
    """Compute a WKT POLYGON bounding box from a GeoJSON FeatureCollection.

    If the GeoJSON has a bbox in its 'properties', use that directly.
    Otherwise walk all feature geometries to determine bounds.
    Coordinates are WGS84 (EPSG:4326).
    """
    props = geojson.get("properties") or {}
    if "bbox" in props and len(props["bbox"]) >= 4:
        min_x, min_y, max_x, max_y = props["bbox"][:4]
    else:
        min_x, min_y = float("inf"), float("inf")
        max_x, max_y = float("-inf"), float("-inf")

        def update_bounds(coords):
            nonlocal min_x, min_y, max_x, max_y
            if isinstance(coords[0], (int, float)):
                x, y = coords[0], coords[1]
                min_x = min(min_x, x)
                max_x = max(max_x, x)
                min_y = min(min_y, y)
                max_y = max(max_y, y)
            else:
                for item in coords:
                    update_bounds(item)

        for feature in geojson["features"]:
            geom = feature.get("geometry")
            if geom and "coordinates" in geom:
                update_bounds(geom["coordinates"])

    min_x -= BBOX_BUFFER
    min_y -= BBOX_BUFFER
    max_x += BBOX_BUFFER
    max_y += BBOX_BUFFER

    return (
        f"POLYGON(({min_x} {min_y}, {max_x} {min_y}, "
        f"{max_x} {max_y}, {min_x} {max_y}, {min_x} {min_y}))"
    )


def main():
    parser = argparse.ArgumentParser(
        description="Map-match NWB road segments to OSM ways"
    )
    parser.add_argument(
        "-i", "--input",
        type=str,
        default=INPUT_FILE,
        help=f"Input NWB GeoJSON file (default: {INPUT_FILE})",
    )
    parser.add_argument(
        "-o", "--output",
        type=str,
        default=OUTPUT_FILE,
        help=f"Output GeoJSON file (default: {OUTPUT_FILE})",
    )
    args = parser.parse_args()

    # Load input GeoJSON
    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    if num_features == 0:
        print("No features found, nothing to do.")
        sys.exit(0)

    # Compute bounding box
    bbox_wkt = compute_bbox_wkt(geojson)
    print(f"  Bounding box (WGS84): {bbox_wkt[:80]}...")

    # Run spatial join
    sql = build_sql(bbox_wkt)
    columns, rows = execute_sql(sql)

    if columns is None or rows is None:
        print("Query execution failed.")
        sys.exit(1)

    print(f"  {len(rows)} matches found")

    # Build wvk_id -> way_id lookup from query results
    wvk_idx = columns.index("wvk_id")
    way_idx = columns.index("way_id")
    lookup = {str(row[wvk_idx]): str(row[way_idx]) for row in rows}

    # Merge OSM way_id into GeoJSON features
    matched = 0
    for feature in geojson["features"]:
        wvk_id = str(feature["properties"].get("wvk_id", ""))
        way_id = lookup.get(wvk_id)
        if way_id:
            feature["properties"]["osm"] = way_id
            matched += 1
        else:
            feature["properties"]["osm"] = None

    print(f"  {matched}/{num_features} features matched with OSM ways")

    # Save output GeoJSON
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output} ({num_features} features)")


if __name__ == "__main__":
    main()
