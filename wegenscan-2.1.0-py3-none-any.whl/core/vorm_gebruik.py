import math

class VormGebruik:
    def __init__(self):
        self.bermschade_waarden = [
            { 'breedte': 3, 'values': [300, 350] },
            { 'breedte': 3.5, 'values': [350, 400] },
            { 'breedte': 4, 'values': [500, 575] },
            { 'breedte': 4.5, 'values': [800, 1000] },
            { 'breedte': 5, 'values': [1150, 1400] },
            { 'breedte': 5.5, 'values': [3000, 4000] },
            { 'breedte': 6, 'values': [5000, 6000] },
            { 'breedte': 20, 'values': [20000, 20000] }
        ]

        self.lane_width_tabels = {
            'gemengd (auto 2, fiets 2 richtingen)': [ {
                    'breedte': 0,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'] 
                },
                {
                    'breedte': 3.5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG'] 
                },
                {
                    'breedte': 3.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 4.5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 4.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 5.5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 5.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 6.5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG'] 
                }
            ],
            'gemengd (auto 1, fiets 2 richtingen)': [ {
                    'breedte': 0,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'] 
                },
                {
                    'breedte': 2.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT']  
                },
                {
                    'breedte': 3.5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG']  
                },
                {
                    'breedte': 3.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'GOED', 'GOED']  
                },
                {
                    'breedte': 4.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED']  
                },
                {
                    'breedte': 6.5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG']
                },
                {
                    'breedte': 6.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG']
                }
            ],
            'gemengd (auto 1, fiets 1 richting)': [ {
                    'breedte': 0,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'] 
                },
                {
                    'breedte': 2.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG']  
                },
                {
                    'breedte': 3.5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'GOED', 'GOED']  
                },
                {
                    'breedte': 3.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'GOED', 'GOED']  
                },
                {
                    'breedte': 4.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED']  
                },
                {
                    'breedte': 6.5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG']
                },
                {
                    'breedte': 6.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG']
                }
            ],
            'fietsstroken (auto 2, fiets 2 richtingen)': [ {
                    'breedte': 0,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'] 
                },
                {
                    'breedte': 5.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 6.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 7.8,
                    'values': ['SLECHT', 'MATIG', 'MATIG', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK']
                },
                {
                    'breedte': 8.8,
                    'values': ['SLECHT', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK']
                },
                {
                    'breedte': 9.8,
                    'values': ['SLECHT', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK']
                },
                {
                    'breedte': 10.8,
                    'values': ['SLECHT', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK', 'REDELIJK']
                }
            ],
            'fietsstroken (auto 1, fiets 2 richtingen)': [ {
                    'breedte': 0,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'] 
                },
                {
                    'breedte': 4,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'] 
                },
                {
                    'breedte': 5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'] 
                },
                {
                    'breedte': 5.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 6.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG'] 
                }
            ],
            'fietsstroken (auto 1, fiets 1 richting)': [ {
                    'breedte': 0,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'] 
                },
                {
                    'breedte': 4,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 5,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG'] 
                },
                {
                    'breedte': 5.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG'] 
                },
                {
                    'breedte': 6.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG'] 
                }
            ],
            'rijbaan auto 2 richtingen (geen fietsers)': [ {
                    'breedte': 0,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'] 
                },
                {
                    'breedte': 4.8,
                    'values': ['SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG'] 
                },
                {
                    'breedte': 5.8,
                    'values': ['SLECHT', 'SLECHT', 'MATIG', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 6.8,
                    'values': ['SLECHT', 'SLECHT', 'MATIG', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED', 'GOED'] 
                },
                {
                    'breedte': 7.8,
                    'values': ['SLECHT', 'SLECHT', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG', 'MATIG'] 
                }
            ],
            # =ALS.VOORWAARDEN(C19<3;"SLECHT";EN(C19>=3;C19<3,2);"MATIG";EN(C19>=3,2;C19<=3,5);"GOED";C19>3,5;"MATIG")
            'rijbaan auto 1 richting (geen fietsers)': [
                {
                    'breedte': 0,
                    'values': ['SLECHT'] 
                },
                {
                    'breedte': 3,
                    'values': ['MATIG'] 
                },
                {
                    'breedte': 3.2,
                    'values': ['GOED'] 
                },
                {
                    'breedte': 3.5,
                    'values': ['MATIG'] 
                }
            ]
        }

        self.usage_bike_values = {
            'ETW 30 km/h gemengd': ['GOED', 'GOED', 'REDELIJK', 'SLECHT', 'SLECHT'],
            'GOW 30 km/h fietsstroken smal profiel': ['GOED', 'GOED', 'REDELIJK', 'SLECHT', 'SLECHT'],
            'GOW 30 km/h fietsstroken breed profiel': ['GOED', 'GOED', 'GOED', 'REDELIJK', 'SLECHT'],
            'ETW-I 60 km/h gemengd':                    ['GOED', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'],
            'ETW-I 60 km/h fietsstroken smal profiel':  ['GOED', 'REDELIJK', 'SLECHT', 'SLECHT', 'SLECHT'],
            'ETW-I 60 km/h fietsstroken breed profiel': ['GOED', 'REDELIJK', 'SLECHT', 'SLECHT', 'SLECHT'],
            'ETW-II 60 km/h gemengd':                   ['GOED', 'SLECHT', 'SLECHT', 'SLECHT', 'SLECHT'],
            'ETW-II 60 km/h fietsstroken smal profiel': ['GOED', 'REDELIJK', 'SLECHT', 'SLECHT', 'SLECHT'],
            'ETW-II 60 km/h fietsstroken breed profiel':['GOED', 'REDELIJK', 'SLECHT', 'SLECHT', 'SLECHT'],
        }

        self.bike_parking_values = {
            'ETW 30 km/h': ['MATIG', 'GOED', 'MATIG', 'GOED', 'REDELIJK'],
            'GOW 30 km/h': ['SLECHT', 'MATIG', 'SLECHT', 'GOED', 'MATIG'],
            'GOW 50 km/h': ['SLECHT', 'SLECHT', 'SLECHT', 'MATIG', 'SLECHT']
        }

    def bermschade(self, width, flow, longitudinal_markings):
        if longitudinal_markings == 'opsluitbanden':
            return 'NVT'
        waarden = self.get_bermschade_waarden(width)
        if waarden is None:
            return 'ONBEKEND'
        if flow < waarden[0]:
            return 'GOED'
        if flow < waarden[1]:
            return 'REDELIJK'
        return 'SLECHT'

    def get_bermschade_waarden(self, width):
        self.bermschade_waarden.sort(key=lambda x: x['breedte'])
        for item in self.bermschade_waarden:
            if item['breedte'] >= width:
                return item['values']
        return waarden[-1]['values']

    def rijbaanbreedte(self, width, flow, parking_facility, profile):
        tabel = self.get_lane_width_table(profile)
        corrected_lane_width = width
        # The -2 m parking correction only applies to mixed / fietsstroken profiles.
        # "geen fietsers" profiles (rijbaan auto 1/2 richting) use raw width per Excel.
        _NO_PARKING_CORRECTION = {
            'rijbaan auto 2 richtingen (geen fietsers)',
            'rijbaan auto 1 richting (geen fietsers)',
        }
        if parking_facility == 'op de rijbaan' and profile not in _NO_PARKING_CORRECTION:
            corrected_lane_width = corrected_lane_width - 2
        try:
            column = self.get_lane_width_column_index(tabel, corrected_lane_width)
            index = self.get_lane_width_row_index(profile, flow)

            return tabel[column]['values'][index]
        except Exception as exc:
            return corrected_lane_width

    def get_lane_width_column_index(self, tabel, width):
        # Zoek de laatste kolom waarvan de breedte-drempel <= de invoerbreedte is.
        # Dit komt overeen met Excel VLOOKUP (benadering): de grootste tabelwaarde
        # die <= de opzoekwaarde is. De vorige implementatie zocht de eerste waarde
        # >= width, waardoor de kolom één te hoog uitviel.
        result = 0
        for i, item in enumerate(tabel):
            if item['breedte'] <= width:
                result = i
            else:
                break
        return result
            
    def get_lane_width_row_index(self, profile, flow):
        if profile == 'gemengd (auto 2, fiets 2 richtingen)':
            for i, item in enumerate([9999,7001,6501,6001,5501,5001,4501,4001,3501,3001,2501,2001,1501,1001,501,0]):
                if flow > item:
                    return i
        elif profile == 'rijbaan auto 2 richtingen (geen fietsers)':
            for i, item in enumerate([30001,25001,20001,14001,12001,10001,8001,6001,4001,2001,0]):
                if flow > item:
                    return i
        elif profile == 'rijbaan auto 1 richting (geen fietsers)':
            return 0
        else:
            for i, item in enumerate([9999,9001,8001,7001,6001,5001,4001,3001,2001,1001,0]):
                if flow > item:
                    return i
        return -1

    def get_lane_width_table(self, name):
        return self.lane_width_tabels.get(name, self.lane_width_tabels['gemengd (auto 2, fiets 2 richtingen)'])

    def pedestrian_width(self, width, pedestrian_location):
        # =ALS(C160="op voetpad/trottoir";G159;"NVT")
        # G159=ALS.VOORWAARDEN(C161<1,5;"SLECHT";EN(C161>=1,5;C161<1,8);"MATIG";EN(C161>=1,8;C161<2);"REDELIJK";C161>=2;"GOED")
        # 1.5, 1.8, 2
        if pedestrian_location != 'op voetpad/trottoir':
            return "NVT"
        
        if width < 1.5:
            return 'SLECHT'
        elif width < 1.8:
            return 'MATIG'  
        elif width < 2:
            return 'REDELIJK'
        return 'GOED'

    def bicycle_width(self, width, bicycle_location):
        # gemengd op rijbaan, fietsstroken, parallelweg, vrijliggend fietspad (eenrichting), tweerichtingenfietspad, niet van toepassing
        if bicycle_location == 'gemengd op rijbaan':
            return 'NVT'
        elif bicycle_location == 'fietsstroken':
            if width < 1.5:
                return 'SLECHT'
            elif width < 1.7:
                return 'MATIG'
            elif width < 2:
                return 'REDELIJK'
            else:
                return 'GOED'
        elif bicycle_location == 'parallelweg':
            return 'NVT'    
        elif bicycle_location == 'vrijliggend fietspad (eenrichting)':
            if width < 2:
                return 'SLECHT'
            elif width < 2.3:
                return 'MATIG'
            else:
                return 'GOED'
        elif bicycle_location == 'tweerichtingenfietspad':
            if width < 3:
                return 'SLECHT'
            elif width < 3.5:
                return 'MATIG'
            elif width < 4:
                return 'REDELIJK'
            else:
                return 'GOED'   
        elif bicycle_location == 'niet van toepassing':
            return 'NVT'

    def parking_width(self, flow, parking_location):
        if parking_location == 'op de rijbaan':
            # =ALS.VOORWAARDEN(C180<4000;"GOED";C180>=4000;"SLECHT")
            if flow < 4000:
                return 'GOED'
            else:
                return 'SLECHT'
        elif parking_location == 'haaksparkeren':
            # =ALS.VOORWAARDEN(C180<4000;"GOED";C180>=4000;"SLECHT")
            if flow < 4000:
                return 'GOED'
            else:
                return 'SLECHT'
        elif parking_location == 'langsparkeren':  
            # =ALS.VOORWAARDEN(C180<8000;"GOED";C180>=8000;"SLECHT")
            if flow < 8000:
                return 'GOED'
            else:
                return 'SLECHT'
        return 'GOED'

    def bus_stop_facility(self, frequency, bus_facility, flow):
        # =ALS(C189="niet van toepassing";"NVT";ALS(C189=G199;"GOED";"MATIG"))
        if bus_facility == 'niet van toepassing':
            return 'NVT'
        
        if frequency == '1-4 bussen/uur':
            expected_facility = 'halteren op rijbaan'
        elif frequency == '4-6 bussen/uur':
            if flow * 0.1 <= 800:
                expected_facility = 'halteren op rijbaan'
            else:
                expected_facility = 'haltehaven'
        elif frequency == '>6 bussen/uur':
            expected_facility = 'haltehaven'
        elif frequency == 'niet aanwezig':
            expected_facility = 'NVT'
    
        if bus_facility == expected_facility:
            return 'GOED'
        return 'MATIG'

    def pedestrian_crossing(self, flow, width, pedestrian_crossing, category, speed):
        if pedestrian_crossing in ['geregeld (verkeerslichten)', 'in de voorrang / zebrapad']:
            return 'GOED'
        elif pedestrian_crossing in ['uit de voorrang / geen voorziening', 'uit de voorrang met middengeleider']:
            if flow == 0:
                return 'NVT'
            # =ALS.VOORWAARDEN(L213<=5;"GOED";EN(L213>5;L213<=10);"REDELIJK";EN(L213>10;L213<=15);"MATIG";L213>15;"SLECHT")
            
            # C206 = pedestrain_crossing
            # C204 = flow

            # L204 = ALS(C206='uit de voorrang met middengeleider';0,6*C204;C204)
            # L206 = ((L204)*0,1)/3600

            # L208 = ALS(C206='uit de voorrang met middengeleider';G229;C205)
            # L211 = (L208*U215)/L209

            # L213 =((EXP(L206*L211)-1)/L206)-L211 (wachttijd, formule van Adams)
            l204 = flow
            l208 = width

            if pedestrian_crossing == 'uit de voorrang met middengeleider':
                l204 = l204 * 0.6
                l208 = max(width / 2, 3.5)

            l206 = (l204 * 0.1) / 3600

            t215 = (-0.0106 * speed) + 1.50059
            u215 = 1 / t215  # seconds per meter (crossing time per meter)
            l211 = l208 * u215  # crossing time in seconds (meters * s/m)

            l213 = ((math.exp(l206 * l211) - 1) / l206) - l211

            # =ALS.VOORWAARDEN(L213<=5;"GOED";EN(L213>5;L213<=10);"REDELIJK";EN(L213>10;L213<=15);"MATIG";L213>15;"SLECHT")
            if l213 <= 5:
                return 'GOED'
            elif l213 <= 10:
                return 'REDELIJK'
            elif l213 <= 15:
                return 'MATIG'
            return 'SLECHT'
        
        elif pedestrian_crossing == 'niet van toepassing':
            return 'NVT'

    def bicycle_crossing(self, flow, width, bicycle_crossing, category, speed=None):
        # geregeld (verkeerslichten)	GOED
        # in de voorrang	GOED
        # uit de voorrang / geen voorziening	GOED
        # uit de voorrang met middengeleider	GOED
        # niet van toepassing	NVT

        if bicycle_crossing == 'geregeld (verkeerslichten)':
            return 'GOED'
        elif bicycle_crossing == 'in de voorrang':
            # =ALS(C222="GOW 50 km/h";ALS.VOORWAARDEN(EN(C222="GOW 50 km/h";C219>=10000);"SLECHT";EN(C222="GOW 50 km/h";C219<10000);"MATIG");"GOED")
            return self.__g218(flow, width, category)
        elif bicycle_crossing == 'uit de voorrang / geen voorziening':
            return self.__l229(flow, width, speed, bicycle_crossing)
        elif bicycle_crossing == 'uit de voorrang met middengeleider':
            return self.__l229(flow, width, speed, bicycle_crossing)
        elif bicycle_crossing == 'niet van toepassing':
            return 'NVT'

    def __l229(self, flow, width, speed, bicycle_crossing):
        if flow == 0:
            return 'NVT'
        # C219 = flow
        # F220 = 'uit de voorrang met middengeleider'
        # C221 = bicycle_crossing

        # L218 = ALS(C221=F220;0,6*C219;C219)
        # L219 = L218*0,1
        # L220 = L219/3600
        # L228 = ((EXP(L220*L225)-1)/L220)-L225

        # l226 = (L222*U215)/L223
        # l222 = ALS(C221=F220;G229;C220)
        # u215 = 1/T215
        # t215 = (-0,0106*C208)+1,50059
        # c208 = speed
        # l223 = 1.2
        # L225 = (L222*U215)/L223

        t215 = (-0.0106*speed)+1.50059
        u215 = 1 / t215
        l222 = width
        l218 = flow 
        if bicycle_crossing == 'uit de voorrang met middengeleider':
            g227 = width / 2
            g228 = 3.5
            g229 = max(g227,g228)
            l222 = g229
            l218 = 0.6 * flow
        l223 = 1.2
        l225 = (l222*u215)/l223
        l219 = l218 * 0.1
        l220 = l219 / 3600
        l228 = ((math.exp(l220 * l225) - 1) / l220) - l225

        # =ALS.VOORWAARDEN(L228<=5;"GOED";EN(L228>5;L228<=10);"REDELIJK";EN(L228>10;L228<=15);"MATIG";L228>15;"SLECHT")
        if l228 <= 5:
            return 'GOED'   
        elif l228 <= 10:
            return 'REDELIJK'   
        elif l228 <= 15:
            return 'MATIG'  
        return 'SLECHT'

    def __g218(self, flow, width, category):
        # =ALS(C222="GOW 50 km/h";
        #   ALS.VOORWAARDEN(EN(C222="GOW 50 km/h";C219>=10000);
        #       "SLECHT";
        #   EN(C222="GOW 50 km/h";C219<10000);
        #       "MATIG");
        #   "GOED")
        if category == 'GOW 50 km/h':
            if flow >= 10000:
                return 'SLECHT'
            else:
                return 'MATIG'
        return 'GOED'

    def speed_bike(self, category, speed, bicycle_location, width):
        if bicycle_location in ['parallelweg', 'vrijliggend fietspad (eenrichting)', 'tweerichtingenfietspad', 'niet van toepassing']:
           return 'NVT'
        
        c235 = speed
        if self.__in_city_limits(category):
            if self.__small_bicycle_profile(width):
                # =ALS.VOORWAARDEN(C235<=30;"GOED";EN(C235>30;C235<=35);"REDELIJK";EN(C235>35;C235<=40);"MATIG";C235>40;"SLECHT")
                if c235 <= 30:
                    return 'GOED'
                elif c235 <= 35:
                    return 'REDELIJK'
                elif c235 <= 40:
                    return 'MATIG'
                return 'SLECHT'
            else:
                # =ALS.VOORWAARDEN(C235<=30;"GOED";EN(C235>30;C235<=40);"REDELIJK";EN(C235>40;C235<=45);"MATIG";C235>45;"SLECHT")
                if c235 <= 30:
                    return 'GOED'
                elif c235 <= 40:
                    return 'REDELIJK'
                elif c235 <= 45:
                    return 'MATIG'
                return 'SLECHT'
        else:
            # =ALS.VOORWAARDEN(C235<=60;"GOED";EN(C235>60;C235<=65);"MATIG";C235>65;"SLECHT")
            if c235 <= 60:
                return 'GOED'
            elif c235 <= 65:
                return 'MATIG'
            return 'SLECHT'

    def __in_city_limits(self, category):
        return category in ['ETW 15 km/h', 'ETW 30 km/h', 'GOW 30 km/h', 'GOW 50 km/h']

    def __small_bicycle_profile(self, width):
        return width < 7
    
    def usage_bike(self, flow, category, bicycle_location, width):
        try:
            return self.__g255(flow, category, bicycle_location, width)
        except Exception as e:
            return 'NVT'

    def __g255(self, flow, category, bicycle_location, width):
        # For ETW 30 km/h ALL bicycle locations (including 'niet van toepassing')
        # always use the mixed (gemengd) rating — bicycle type is not assessed separately.
        if category == 'ETW 30 km/h':
            index = self.__get_usage_index(flow)
            return self.usage_bike_values['ETW 30 km/h gemengd'][index]

        if bicycle_location == 'niet van toepassing':
            return 'NVT'

        index = self.__get_usage_index(flow)

        # For all other categories only on-road locations are assessed.
        if bicycle_location not in ['gemengd op rijbaan', 'fietsstroken']:
            return 'NVT'

        sub_cat = bicycle_location
        if sub_cat == 'fietsstroken':
            if width < 7:
                sub_cat = 'fietsstroken smal profiel'
            else:
                sub_cat = 'fietsstroken breed profiel'
        else:
            sub_cat = 'gemengd'

        return self.usage_bike_values[category + ' ' + sub_cat][index]

    def __get_usage_index(self, flow):
        if flow < 2500:
            return 0
        elif flow < 3001:
            return 1
        elif flow < 6001:
            return 2
        elif flow < 10001:
            return 3
        else:
            return 4       

    def bicycle_parking(self, width, parking_location, bicycle_location, category): 
        try:
            if width == 0:
                return 'NVT'

            # =ALS.VOORWAARDEN(C265="gemengd op rijbaan";"met fietsers";C265="fietsstroken";"met fietsers")
            # gemengd op rijbaan, fietsstroken, parallelweg, vrijliggend fietspad (eenrichting), tweerichtingenfietspad, niet van toepassing
            fietsers = "zonder fietsers"
            if bicycle_location in ['gemengd op rijbaan', 'fietsstroken']:
                fietsers = "met fietsers"
            else:
                return 'NVT'

            # 'op de rijbaan' parking has no separate bay width to assess → NVT per Excel
            if parking_location == 'op de rijbaan':
                return 'NVT'

            schrikruimte = "met schrikruimte"
            # =ALS.VOORWAARDEN(C264="langsparkeren";G274;C264="haaksparkeren";G275;C264="op de rijbaan";"")
            if parking_location == 'langsparkeren':
                # =ALS(C263<G271;"weinig_sr";"voldoende_sr")
                schrikruimte = "voldoende_sr"
                if width < 2.3:
                    schrikruimte = "weinig_sr"
                
            elif parking_location == 'haaksparkeren':
                # =ALS(C263<G272;"weinig_sr";"voldoende_sr")
                schrikruimte = "voldoende_sr"
                if width < 6:
                    schrikruimte = "weinig_sr"

            elif parking_location == 'op de rijbaan':   
                schrikruimte = ""
            
            key = f"{parking_location} {fietsers} {schrikruimte}".strip()
            index = self.__get_parking_index(key)
            return self.bike_parking_values[category][index]
            
        except Exception as e:
            return 'NVT'
    
    def __get_parking_index(self, key):
        if key == 'op de rijbaan met fietsers':
            return 0
        elif key == 'haaksparkeren met fietsers voldoende_sr':
            return 1
        elif key == 'haaksparkeren met fietsers weinig_sr':
            return 2
        elif key == 'langsparkeren met fietsers voldoende_sr':
            return 3
        elif key == 'langsparkeren met fietsers weinig_sr':
            return 4
        return None

    def social_interaction(self, flow, into_account):
        if not into_account:
            return 'NVT'
        
        if flow < 2000:
            return 'GOED'
        elif flow < 4000:
            return 'REDELIJK'
        elif flow < 8000:
            return 'MATIG'
        return 'SLECHT'