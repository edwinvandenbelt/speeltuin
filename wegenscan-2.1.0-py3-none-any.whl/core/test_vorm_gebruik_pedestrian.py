import unittest
from vorm_gebruik import VormGebruik

class TestVormGebruik(unittest.TestCase):
    def setUp(self):
        self.vorm_gebruik = VormGebruik()

    def test_ped_width_niet_op_opvoetpad_trottoir(self):
        result = self.vorm_gebruik.pedestrian_width(1.8, 'iets anders')
        self.assertEqual(result, 'NVT')

    def test_ped_width_opvoetpad_trottoir_narrow(self):
        result = self.vorm_gebruik.pedestrian_width(1.0, 'op voetpad/trottoir')
        self.assertEqual(result, 'SLECHT')

    def test_ped_width_opvoetpad_trottoir_medium(self):
        result = self.vorm_gebruik.pedestrian_width(1.7, 'op voetpad/trottoir')
        self.assertEqual(result, 'MATIG')        

    def test_ped_width_opvoetpad_trottoir_wide(self):
        result = self.vorm_gebruik.pedestrian_width(2.0, 'op voetpad/trottoir')
        self.assertEqual(result, 'GOED')        

    def test_ped_crossing_in_de_voorrang(self):
        result = self.vorm_gebruik.pedestrian_crossing(100, 7.3, 'in de voorrang / zebrapad', 'ETW 30 km/h', 34)
        self.assertEqual(result, 'GOED')

    def test_ped_crossing_geregeld(self):
        result = self.vorm_gebruik.pedestrian_crossing(100, 7.3, 'geregeld (verkeerslichten)', 'ETW 30 km/h', 34)
        self.assertEqual(result, 'GOED')

    def test_ped_crossing_uit_de_voorrang_geen_voorzieningen(self):
        result = self.vorm_gebruik.pedestrian_crossing(100, 7.3, 'uit de voorrang / geen voorziening', 'ETW 30 km/h', 34)
        self.assertEqual(result, 'GOED')        

    def test_ped_crossing_slecht_high_flow(self):
        # ETW-I 60 km/h, hoge intensiteit + hoge snelheid → SLECHT
        result = self.vorm_gebruik.pedestrian_crossing(16946, 6, 'uit de voorrang / geen voorziening', 'ETW-I 60 km/h', 78)
        self.assertEqual(result, 'SLECHT')

    def test_ped_crossing_uit_de_voorrang_met_middengeleider(self):
        result = self.vorm_gebruik.pedestrian_crossing(100, 7.3, 'uit de voorrang met middengeleider', 'ETW 30 km/h', 34)
        self.assertEqual(result, 'GOED')                

    def test_ped_crossing_nvt(self):
        result = self.vorm_gebruik.pedestrian_crossing(100, 7.3, 'niet van toepassing', 'ETW 30 km/h', 34)
        self.assertEqual(result, 'NVT')                