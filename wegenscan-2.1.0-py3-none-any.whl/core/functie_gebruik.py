class FunctieGebruik:
    def __init__(self):
        self.values = {
            'ETW 15 km/h': [500, None, 1000],
            'ETW 30 km/h': [2000, 4000, 6000],
            'GOW 30 km/h': [10000, None, 15000],
            'GOW 50 km/h': [4000, 20000, 25000],
            'ETW-I 60 km/h': [2000, None, 6000],
            'ETW-II 60 km/h': [1000, None, 3000],
            'GOW 80 km/h': [3000, None, 3000]
        }
        self.functions = {
            'ETW 15 km/h': # lambda intensity: self.between(intensity, [500, None, 1000]),
                lambda intensity, cat: 
                    "GOED" if intensity < self.values[cat][0] 
                    else "REDELIJK" if intensity >= self.values[cat][0] and intensity <= self.values[cat][2] 
                    else "SLECHT",

            'ETW 30 km/h': 
                lambda intensity, cat: 
                    "GOED" if intensity<self.values[cat][0] 
                    else "REDELIJK" if intensity>=self.values[cat][0] and intensity<=self.values[cat][1] 
                    else "MATIG" if intensity>self.values[cat][1] and intensity<=self.values[cat][2]
                    else "SLECHT",
                                    
            'GOW 30 km/h': 
                lambda intensity, cat: 
                    "GOED" if intensity < self.values[cat][0] 
                    else "MATIG" if intensity >= self.values[cat][0] and intensity <= self.values[cat][2] 
                    else "SLECHT",

            'GOW 50 km/h': 
                lambda intensity, cat: 
                    "REDELIJK" if intensity<self.values[cat][0] 
                    else "GOED" if intensity>=self.values[cat][0] and intensity<=self.values[cat][1] 
                    else "MATIG" if intensity>self.values[cat][1] and intensity<=self.values[cat][2]
                    else "SLECHT",

            'ETW-I 60 km/h': 
                lambda intensity, cat: 
                    "REDELIJK" if intensity < self.values[cat][0] 
                    else "GOED" if intensity >= self.values[cat][0] and intensity <= self.values[cat][2] 
                    else "SLECHT",

            'ETW-II 60 km/h': 
                lambda intensity, cat: 
                    "GOED" if intensity < self.values[cat][0] 
                    else "MATIG" if intensity >= self.values[cat][0] and intensity <= self.values[cat][2] 
                    else "SLECHT",
                    
            'GOW 80 km/h': 
                lambda intensity, cat: 
                    "MATIG" if intensity < self.values[cat][0] 
                    else "GOED" if intensity >= self.values[cat][0] and intensity <= self.values[cat][2] 
                    else "GOED",
        }

    def bereken(self, categorie, intensiteit):
        f = self.functions.get(categorie)
        return f(intensiteit, categorie) if f else 'NVT'
