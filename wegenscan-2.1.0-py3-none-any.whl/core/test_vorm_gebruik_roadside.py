import unittest
from vorm_gebruik import VormGebruik

class TestVormGebruik(unittest.TestCase):
    def setUp(self):
        self.vorm_gebruik = VormGebruik()

    def test_bermschade_opsluitbanden(self):
        result = self.vorm_gebruik.bermschade(7.3, 100, 'opsluitbanden')
        self.assertEqual(result, 'NVT')

    def test_bermschade_geen_lengtemarkering_low_flow(self):
        result = self.vorm_gebruik.bermschade(7.3, 100, 'niet aanwezig')
        self.assertEqual(result, 'GOED')

    def test_bermschade_geen_lengtemarkering_medium_flow(self):
        result = self.vorm_gebruik.bermschade(4.3, 900, 'niet aanwezig')
        self.assertEqual(result, 'REDELIJK')

    def test_bermschade_geen_lengtemarkering_high_flow(self):
        result = self.vorm_gebruik.bermschade(4.3, 1100, 'niet aanwezig')
        self.assertEqual(result, 'SLECHT')
