import unittest
import sys, os
sys.path.insert(0, os.path.dirname(__file__))
from functie_vorm import FunctieVorm


class TestFunctieVormLaneWidth(unittest.TestCase):
    def setUp(self):
        self.fv = FunctieVorm()

    # --- GOW 50 km/h single-lane (fietsstroken auto 1) ---

    def test_gow50_fietsstroken_auto1_width_5_1_is_matig(self):
        """Regression: width 5.1 must be MATIG (was incorrectly GOED before the fix)."""
        result = self.fv.lane_width(
            'GOW 50 km/h', 5.1, 'fietsstroken (auto 1, fiets 2 richtingen)'
        )
        self.assertEqual(result, 'MATIG')

    def test_gow50_fietsstroken_auto1_width_6_9_is_matig(self):
        result = self.fv.lane_width(
            'GOW 50 km/h', 6.9, 'fietsstroken (auto 1, fiets 2 richtingen)'
        )
        self.assertEqual(result, 'MATIG')

    def test_gow50_fietsstroken_auto1_width_7_4_is_matig(self):
        result = self.fv.lane_width(
            'GOW 50 km/h', 7.4, 'fietsstroken (auto 1, fiets 2 richtingen)'
        )
        self.assertEqual(result, 'MATIG')

    # --- GOW 50 km/h single-lane (rijbaan auto 1 richting) ---

    def test_gow50_rijbaan_auto1_width_3_6_is_goed(self):
        result = self.fv.lane_width(
            'GOW 50 km/h', 3.6, 'rijbaan auto 1 richting (geen fietsers)'
        )
        self.assertEqual(result, 'GOED')

    def test_gow50_rijbaan_auto1_width_3_9_is_goed(self):
        result = self.fv.lane_width(
            'GOW 50 km/h', 3.9, 'rijbaan auto 1 richting (geen fietsers)'
        )
        self.assertEqual(result, 'GOED')

    def test_gow50_rijbaan_auto1_width_4_2_boundary_is_goed(self):
        """Exact upper boundary (4.2 m) is inclusive, so GOED."""
        result = self.fv.lane_width(
            'GOW 50 km/h', 4.2, 'rijbaan auto 1 richting (geen fietsers)'
        )
        self.assertEqual(result, 'GOED')

    def test_gow50_rijbaan_auto1_width_4_3_above_boundary_is_matig(self):
        """Just above the upper boundary (4.2 m) must be MATIG."""
        result = self.fv.lane_width(
            'GOW 50 km/h', 4.3, 'rijbaan auto 1 richting (geen fietsers)'
        )
        self.assertEqual(result, 'MATIG')

    def test_gow50_rijbaan_auto1_width_11_2_is_matig(self):
        result = self.fv.lane_width(
            'GOW 50 km/h', 11.2, 'rijbaan auto 1 richting (geen fietsers)'
        )
        self.assertEqual(result, 'MATIG')

    def test_gow50_rijbaan_auto1_below_min_is_matig(self):
        """Below lower boundary (3.5 m) for GOW 50 returns MATIG."""
        result = self.fv.lane_width(
            'GOW 50 km/h', 3.0, 'rijbaan auto 1 richting (geen fietsers)'
        )
        self.assertEqual(result, 'MATIG')

    # --- GOW 50 km/h dual-lane ---

    def test_gow50_dual_width_6_0_is_goed(self):
        result = self.fv.lane_width(
            'GOW 50 km/h', 6.0, 'gemengd (auto 2, fiets 2 richtingen)'
        )
        self.assertEqual(result, 'GOED')

    def test_gow50_dual_width_3_4_below_min_is_matig(self):
        result = self.fv.lane_width(
            'GOW 50 km/h', 3.4, 'gemengd (auto 2, fiets 2 richtingen)'
        )
        self.assertEqual(result, 'MATIG')


if __name__ == '__main__':
    unittest.main()
