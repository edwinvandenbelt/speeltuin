import unittest
from vorm_gebruik import VormGebruik

class TestVormGebruik(unittest.TestCase):
    def setUp(self):
        self.vorm_gebruik = VormGebruik()

    def test_bike_width_gemengd(self):
        result = self.vorm_gebruik.bicycle_width(7.3, 'gemengd op rijbaan')
        self.assertEqual(result, 'NVT')
    
    def test_bike_width_fietsstrook_narrow(self):
        result = self.vorm_gebruik.bicycle_width(1.2, 'fietsstroken')
        self.assertEqual(result, 'SLECHT')

    def test_bike_width_fietsstrook_wide(self):
        result = self.vorm_gebruik.bicycle_width(3.5, 'fietsstroken')
        self.assertEqual(result, 'GOED')

    def test_bike_width_parallelweg(self):
        result = self.vorm_gebruik.bicycle_width(7.3, 'parallelweg')
        self.assertEqual(result, 'NVT')

    def test_bike_width_vrijliggend(self):
        result = self.vorm_gebruik.bicycle_width(1, 'vrijliggend fietspad (eenrichting)')
        self.assertEqual(result, 'SLECHT')

    def test_bike_width_tweerichtingen(self):
        result = self.vorm_gebruik.bicycle_width(1, 'tweerichtingenfietspad')
        self.assertEqual(result, 'SLECHT')

    def test_bike_nvt(self):
        result = self.vorm_gebruik.bicycle_width(7.3, 'niet van toepassing')
        self.assertEqual(result, 'NVT')

    # --- rijbaanbreedte tests ---

    def test_rijbaanbreedte_fietsstroken_7m_langsparkeren_laag(self):
        # 7.0m breedte valt in de klasse >=6.8m (niet >=7.8m).
        # Bij intensiteit 749 mvt/etm moet het resultaat GOED zijn.
        result = self.vorm_gebruik.rijbaanbreedte(7.0, 749, 'langsparkeren', 'fietsstroken (auto 2, fiets 2 richtingen)')
        self.assertEqual(result, 'GOED')

    def test_rijbaanbreedte_fietsstroken_exact_drempel(self):
        # Op de exacte drempel (6.8m) moet hetzelfde klasse gebruikt worden als erboven.
        result = self.vorm_gebruik.rijbaanbreedte(6.8, 749, 'langsparkeren', 'fietsstroken (auto 2, fiets 2 richtingen)')
        self.assertEqual(result, 'GOED')

    def test_rijbaanbreedte_fietsstroken_net_onder_drempel(self):
        # Net onder de 5.8m drempel → klasse 0 (breedte 0) → SLECHT voor alle intensiteiten.
        result = self.vorm_gebruik.rijbaanbreedte(5.7, 749, 'langsparkeren', 'fietsstroken (auto 2, fiets 2 richtingen)')
        self.assertEqual(result, 'SLECHT')

    def test_rijbaanbreedte_op_rijbaan_correctie(self):
        # Bij 'op de rijbaan' wordt 2m afgetrokken: 7.0 - 2.0 = 5.0m → klasse 0 → SLECHT.
        result = self.vorm_gebruik.rijbaanbreedte(7.0, 749, 'op de rijbaan', 'fietsstroken (auto 2, fiets 2 richtingen)')
        self.assertEqual(result, 'SLECHT')
