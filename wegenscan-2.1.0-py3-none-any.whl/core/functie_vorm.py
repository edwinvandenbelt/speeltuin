class FunctieVorm:
    def __init__(self):
        self.longitudinal_markings = {
            'opsluitbanden': {'ETW 15 km/h': 'GOED','ETW 30 km/h': 'GOED','GOW 30 km/h': 'GOED','GOW 50 km/h': 'GOED','ETW-I 60 km/h': 'SLECHT','ETW-II 60 km/h': 'SLECHT','GOW 80 km/h': 'SLECHT'},
            'kantmarkering': {'ETW 15 km/h': 'SLECHT','ETW 30 km/h': 'SLECHT','GOW 30 km/h': 'SLECHT','GOW 50 km/h': 'REDELIJK','ETW-I 60 km/h': 'GOED','ETW-II 60 km/h': 'REDELIJK','GOW 80 km/h': 'GOED'},
            'niet aanwezig': {'ETW 15 km/h': 'REDELIJK','ETW 30 km/h': 'REDELIJK','GOW 30 km/h': 'SLECHT','GOW 50 km/h': 'SLECHT','ETW-I 60 km/h': 'REDELIJK','ETW-II 60 km/h': 'GOED','GOW 80 km/h': 'SLECHT'}
        }

        self.directional_separation_values = {
            'fysieke scheiding': {
                'ETW 15 km/h': 'SLECHT', 'ETW 30 km/h': 'MATIG', 'GOW 30 km/h': 'GOED',
                'GOW 50 km/h': 'GOED', 'ETW-I 60 km/h': 'SLECHT', 'ETW-II 60 km/h': 'SLECHT', 'GOW 80 km/h': 'GOED'
            },
            'asstreep': {
                'ETW 15 km/h': 'SLECHT', 'ETW 30 km/h': 'SLECHT', 'GOW 30 km/h': 'SLECHT',
                'GOW 50 km/h': 'REDELIJK', 'ETW-I 60 km/h': 'GOED', 'ETW-II 60 km/h': 'REDELIJK', 'GOW 80 km/h': 'REDELIJK'
            },
            'niet aanwezig door fietsstroken': {
                'ETW 15 km/h': 'SLECHT', 'ETW 30 km/h': 'REDELIJK', 'GOW 30 km/h': 'GOED',
                'GOW 50 km/h': 'REDELIJK', 'ETW-I 60 km/h': 'GOED', 'ETW-II 60 km/h': 'GOED', 'GOW 80 km/h': 'SLECHT'
            },
            'niet aanwezig': {
                'ETW 15 km/h': 'GOED', 'ETW 30 km/h': 'GOED', 'GOW 30 km/h': 'GOED',
                'GOW 50 km/h': 'SLECHT', 'ETW-I 60 km/h': 'REDELIJK', 'ETW-II 60 km/h': 'GOED', 'GOW 80 km/h': 'SLECHT'
            }
        }

        self.road_surfaces = {
            'open (o.a.klinkers)': {
                'ETW 15 km/h': 'GOED', 'ETW 30 km/h': 'GOED', 'GOW 30 km/h': 'MATIG',
                'GOW 50 km/h': 'SLECHT', 'ETW-I 60 km/h': 'SLECHT', 'ETW-II 60 km/h': 'MATIG', 'GOW 80 km/h': 'SLECHT'
            },
            'gesloten (o.a. asfalt)': {
                'ETW 15 km/h': 'MATIG', 'ETW 30 km/h': 'MATIG', 'GOW 30 km/h': 'MATIG',
                'GOW 50 km/h': 'GOED', 'ETW-I 60 km/h': 'GOED', 'ETW-II 60 km/h': 'GOED', 'GOW 80 km/h': 'GOED'
            },
            'gedeeltelijk open': {
                'ETW 15 km/h': 'MATIG', 'ETW 30 km/h': 'MATIG', 'GOW 30 km/h': 'GOED',
                'GOW 50 km/h': 'SLECHT', 'ETW-I 60 km/h': 'SLECHT', 'ETW-II 60 km/h': 'SLECHT', 'GOW 80 km/h': 'SLECHT'
            }
        }
        self.pedestrian_facilities = {
            'gemengd op rijbaan': {
                'ETW 15 km/h': 'GOED', 'ETW 30 km/h': 'MATIG', 'GOW 30 km/h': 'SLECHT',
                'GOW 50 km/h': 'SLECHT', 'ETW-I 60 km/h': 'GOED', 'ETW-II 60 km/h': 'GOED', 'GOW 80 km/h': 'SLECHT'
            },
            'op fietspad/parallelweg': {
                'ETW 15 km/h': 'MATIG', 'ETW 30 km/h': 'MATIG', 'GOW 30 km/h': 'MATIG',
                'GOW 50 km/h': 'MATIG', 'ETW-I 60 km/h': 'GOED', 'ETW-II 60 km/h': 'GOED', 'GOW 80 km/h': 'GOED'
            },
            'op voetpad/trottoir': {
                'ETW 15 km/h': 'MATIG', 'ETW 30 km/h': 'GOED', 'GOW 30 km/h': 'GOED',
                'GOW 50 km/h': 'GOED', 'ETW-I 60 km/h': 'GOED', 'ETW-II 60 km/h': 'GOED', 'GOW 80 km/h': 'GOED'
            },
            'niet van toepassing': {
                'ETW 15 km/h': 'NVT', 'ETW 30 km/h': 'NVT', 'GOW 30 km/h': 'NVT',
                'GOW 50 km/h': 'NVT', 'ETW-I 60 km/h': 'NVT', 'ETW-II 60 km/h': 'NVT', 'GOW 80 km/h': 'NVT'
            }
        }
        self.bicycle_facilities = {
            'gemengd op rijbaan': {
                'ETW 15 km/h': 'GOED', 'ETW 30 km/h': 'GOED', 'GOW 30 km/h': 'SLECHT',
                'GOW 50 km/h': 'SLECHT', 'ETW-I 60 km/h': 'MATIG', 'ETW-II 60 km/h': 'GOED', 'GOW 80 km/h': 'SLECHT'
            },
            'fietsstroken': {
                'ETW 15 km/h': 'SLECHT', 'ETW 30 km/h': 'MATIG', 'GOW 30 km/h': 'GOED',
                'GOW 50 km/h': 'SLECHT', 'ETW-I 60 km/h': 'GOED', 'ETW-II 60 km/h': 'MATIG', 'GOW 80 km/h': 'SLECHT'
            },
            'parallelweg': {
                'ETW 15 km/h': 'SLECHT', 'ETW 30 km/h': 'MATIG', 'GOW 30 km/h': 'GOED',
                'GOW 50 km/h': 'GOED', 'ETW-I 60 km/h': 'MATIG', 'ETW-II 60 km/h': 'MATIG', 'GOW 80 km/h': 'GOED'
            },
            'vrijliggend fietspad (eenrichting)': {
                'ETW 15 km/h': 'SLECHT', 'ETW 30 km/h': 'MATIG', 'GOW 30 km/h': 'GOED',
                'GOW 50 km/h': 'GOED', 'ETW-I 60 km/h': 'GOED', 'ETW-II 60 km/h': 'MATIG', 'GOW 80 km/h': 'GOED'
            },
            'tweerichtingenfietspad': {
                'ETW 15 km/h': 'SLECHT', 'ETW 30 km/h': 'MATIG', 'GOW 30 km/h': 'GOED',
                'GOW 50 km/h': 'GOED', 'ETW-I 60 km/h': 'GOED', 'ETW-II 60 km/h': 'MATIG', 'GOW 80 km/h': 'GOED'
            },
            'niet van toepassing': {
                'ETW 15 km/h': 'NVT', 'ETW 30 km/h': 'NVT', 'GOW 30 km/h': 'NVT',
                'GOW 50 km/h': 'NVT', 'ETW-I 60 km/h': 'NVT', 'ETW-II 60 km/h': 'NVT', 'GOW 80 km/h': 'NVT'
            }
        }
        self.parking_facilities = {
            "op de rijbaan": {"ETW 15 km/h": "MATIG", "ETW 30 km/h": "REDELIJK", "GOW 30 km/h": "SLECHT", "GOW 50 km/h": "SLECHT", "ETW-I 60 km/h": "SLECHT", "ETW-II 60 km/h": "SLECHT", "GOW 80 km/h": "SLECHT"},
            "haaksparkeren": {"ETW 15 km/h": "GOED", "ETW 30 km/h": "GOED", "GOW 30 km/h": "MATIG", "GOW 50 km/h": "SLECHT", "ETW-I 60 km/h": "SLECHT", "ETW-II 60 km/h": "SLECHT", "GOW 80 km/h": "SLECHT"},
            "langsparkeren": {"ETW 15 km/h": "GOED", "ETW 30 km/h": "GOED", "GOW 30 km/h": "GOED", "GOW 50 km/h": "MATIG", "ETW-I 60 km/h": "SLECHT", "ETW-II 60 km/h": "SLECHT", "GOW 80 km/h": "SLECHT"},
            "niet van toepassing": {"ETW 15 km/h": "NVT", "ETW 30 km/h": "NVT", "GOW 30 km/h": "NVT", "GOW 50 km/h": "NVT", "ETW-I 60 km/h": "NVT", "ETW-II 60 km/h": "NVT", "GOW 80 km/h": "NVT"}
        }
        self.bus_stop_facilities = {
            "halteren op rijbaan": {"ETW 15 km/h": "NVT", "ETW 30 km/h": "GOED", "GOW 30 km/h": "GOED", "GOW 50 km/h": "MATIG", "ETW-I 60 km/h": "GOED", "ETW-II 60 km/h": "GOED", "GOW 80 km/h": "SLECHT"},
            "haltehaven": {"ETW 15 km/h": "NVT", "ETW 30 km/h": "REDELIJK", "GOW 30 km/h": "REDELIJK", "GOW 50 km/h": "GOED", "ETW-I 60 km/h": "GOED", "ETW-II 60 km/h": "GOED", "GOW 80 km/h": "GOED"},
            "niet van toepassing": {"ETW 15 km/h": "NVT", "ETW 30 km/h": "NVT", "GOW 30 km/h": "NVT", "GOW 50 km/h": "NVT", "ETW-I 60 km/h": "NVT", "ETW-II 60 km/h": "NVT", "GOW 80 km/h": "NVT"}
        }
        self.speed_bump_values = {
            "op wegvakken": {"ETW 15 km/h": "MATIG", "ETW 30 km/h": "MATIG", "GOW 30 km/h": "MATIG", "GOW 50 km/h": "MATIG", "ETW-I 60 km/h": "MATIG", "ETW-II 60 km/h": "GOED", "GOW 80 km/h": "SLECHT"},
            "op kruispunten": {"ETW 15 km/h": "MATIG", "ETW 30 km/h": "MATIG", "GOW 30 km/h": "GOED", "GOW 50 km/h": "MATIG", "ETW-I 60 km/h": "MATIG", "ETW-II 60 km/h": "GOED", "GOW 80 km/h": "MATIG"},
            "op wegvakken en kruispunten": {"ETW 15 km/h": "GOED", "ETW 30 km/h": "GOED", "GOW 30 km/h": "MATIG", "GOW 50 km/h": "SLECHT", "ETW-I 60 km/h": "GOED", "ETW-II 60 km/h": "GOED", "GOW 80 km/h": "SLECHT"},
            "niet aanwezig": {"ETW 15 km/h": "SLECHT", "ETW 30 km/h": "SLECHT", "GOW 30 km/h": "SLECHT", "GOW 50 km/h": "GOED", "ETW-I 60 km/h": "SLECHT", "ETW-II 60 km/h": "GOED", "GOW 80 km/h": "GOED"},
            "niet op beoordelen": {"ETW 15 km/h": "NVT", "ETW 30 km/h": "NVT", "GOW 30 km/h": "NVT", "GOW 50 km/h": "NVT", "ETW-I 60 km/h": "NVT", "ETW-II 60 km/h": "NVT", "GOW 80 km/h": "NVT"}
        }
        self.dual_lane_width = {"ETW 15 km/h": [3.8, 4.8]
                                , "ETW 30 km/h": [4.8, 5.8]
                                , "GOW 30 km/h": [5.8, 6.8]
                                , "GOW 50 km/h": [5.8, 7.8]
                                , "ETW-I 60 km/h": [4.5, 6.2]
                                , "ETW-II 60 km/h": [2.5, 4.5]
                                , "GOW 80 km/h": [7.0, 7.5]}
        self.single_lane_width = {"ETW 15 km/h": [3.8, 4.8]
                                , "ETW 30 km/h": [3.8, 4.8]
                                , "GOW 30 km/h": [4.8, 5.5]
                                , "GOW 50 km/h": [3.5, 4.2]
                                , "ETW-I 60 km/h": [0, 0]
                                , "ETW-II 60 km/h": [0, 0]
                                , "GOW 80 km/h": [3.5, 4.5]}
        self.lane_width_below_min_score = {"ETW 15 km/h": "MATIG",
                                    "ETW 30 km/h": "MATIG",
                                    "GOW 30 km/h": "SLECHT",
                                    "GOW 50 km/h": "MATIG",
                                    "ETW-I 60 km/h": "SLECHT",
                                    "ETW-II 60 km/h": "SLECHT",
                                    "GOW 80 km/h": "MATIG"}

    def longitudinal_marking(self, category, marking_type):
        return self.longitudinal_markings[marking_type].get(category, 'ONBEKEND')
    def directional_separations(self, category, separation_type):
        return self.directional_separation_values[separation_type].get(category, 'ONBEKEND')
    def lane_width(self, category, width, profile):
        boundaries = []
        if self.back_and_forth(profile):
            boundaries = self.dual_lane_width[category]
        else:
            boundaries = self.single_lane_width[category]

        return self.between(category, width, boundaries)
    def back_and_forth(self, profile):
        return profile in ['gemengd (auto 2, fiets 2 richtingen)'
                           , 'fietsstroken (auto 2, fiets 2 richtingen)'
                           , 'rijbaan auto 2 richtingen (geen fietsers)']
    def road_surface(self, category, surface):
        return self.road_surfaces[surface].get(category, 'ONBEKEND')
    def bicycle_facility(self, category, facility):
        return self.bicycle_facilities[facility].get(category, 'ONBEKEND')
    def parking_facility(self, category, facility):
        return self.parking_facilities[facility].get(category, 'ONBEKEND')
    def bus_stop_facility(self, category, facility):
        return self.bus_stop_facilities[facility].get(category, 'ONBEKEND')
    def speed_bumps(self, category, bumps):
        return self.speed_bump_values[bumps].get(category, 'ONBEKEND')
    def pedestrian_facility(self, category, facility):
        return self.pedestrian_facilities[facility].get(category, 'ONBEKEND')
    
    def between(self, category, value, boundaries: list):
        lower, upper = boundaries

        if value < lower:
            return self.lane_width_below_min_score.get(category, "ONBEKEND")
        elif upper is not None and value <= upper:
            return "GOED"
        else:
            return "MATIG"
