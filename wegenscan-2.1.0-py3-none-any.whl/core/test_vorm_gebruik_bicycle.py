import unittest
from vorm_gebruik import VormGebruik

class TestVormGebruik(unittest.TestCase):
    def setUp(self):
        self.vorm_gebruik = VormGebruik()

    def test_bike_width_niet_op_opvoetpad_trottoir(self):
        result = self.vorm_gebruik.bicycle_width(1.8, 'gemengd op rijbaan')
        self.assertEqual(result, 'NVT')

    def test_bike_width_opvoetpad_trottoir_narrow(self):
        result = self.vorm_gebruik.bicycle_width(1.0, 'fietsstroken')
        self.assertEqual(result, 'SLECHT')

    def test_bike_width_opvoetpad_trottoir_medium(self):
        result = self.vorm_gebruik.bicycle_width(1.7, 'parallelweg')
        self.assertEqual(result, 'NVT')        

    def test_bike_width_opvoetpad_trottoir_wide(self):
        result = self.vorm_gebruik.bicycle_width(2.6, 'vrijliggend fietspad (eenrichting)')
        self.assertEqual(result, 'GOED')        

    def test_bike_crossing_nvt(self):
        result = self.vorm_gebruik.bicycle_crossing(100, 7.3, 'in de voorrang', 'ETW 30 km/h')
        self.assertEqual(result, 'GOED')

    def test_bike_speed_breed_profiel(self):
        result = self.vorm_gebruik.speed_bike('GOW 30 km/h', 34, 'fietsstroken', 7.3)
        self.assertEqual(result, 'REDELIJK')

    def test_bike_speed_outside_city_limits(self):
        result = self.vorm_gebruik.speed_bike('ETW 60 km/h', 34, 'fietsstroken', 7.3)
        self.assertEqual(result, 'GOED')

    def test_bike_usage_breed_profiel(self):
        result = self.vorm_gebruik.usage_bike(3000, 'GOW 30 km/h', 'fietsstroken', 7.3)
        self.assertEqual(result, 'GOED')

    def test_bike_usage_small_profiel(self):
        result = self.vorm_gebruik.usage_bike(3010, 'GOW 30 km/h', 'fietsstroken', 5.3)
        self.assertEqual(result, 'REDELIJK')        

    def test_bike_parking(self):
        result = self.vorm_gebruik.bicycle_parking(2.0, 'haaksparkeren', 'gemengd op rijbaan', 'ETW 30 km/h')
        self.assertEqual(result, 'MATIG')

    def test_bike_parking_width_zero_nvt(self):
        # Breedte parkeervak + margestrook = 0 means no parking exists → NVT
        result = self.vorm_gebruik.bicycle_parking(0, 'op de rijbaan', 'gemengd op rijbaan', 'ETW 30 km/h')
        self.assertEqual(result, 'NVT')

    def test_social_interaction(self):
        result = self.vorm_gebruik.social_interaction(2000, True)
        self.assertEqual(result, 'REDELIJK')