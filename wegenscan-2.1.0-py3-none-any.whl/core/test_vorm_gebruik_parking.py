import unittest
from vorm_gebruik import VormGebruik

class TestVormGebruik(unittest.TestCase):
    def setUp(self):
        self.vorm_gebruik = VormGebruik()

    def test_parking_op_rijbaan(self):
        result = self.vorm_gebruik.parking_width(100, 'op de rijbaan')
        self.assertEqual(result, 'GOED')

    def test_parking_haaksparkeren_goed(self):
        result = self.vorm_gebruik.parking_width(100, 'haaksparkeren')
        self.assertEqual(result, 'GOED')

    def test_parking_haaksparkeren_slecht(self):
        result = self.vorm_gebruik.parking_width(5000, 'haaksparkeren')
        self.assertEqual(result, 'SLECHT')

    def test_parking_langsparkeren_goed(self):
        result = self.vorm_gebruik.parking_width(100, 'langsparkeren')
        self.assertEqual(result, 'GOED')

    def test_parking_langsparkeren_slecht(self):
        result = self.vorm_gebruik.parking_width(9000, 'langsparkeren')
        self.assertEqual(result, 'SLECHT')
    
    def test_parking_nvt(self):
        result = self.vorm_gebruik.parking_width(1.0, 'niet van toepassing')
        self.assertEqual(result, 'NVT')