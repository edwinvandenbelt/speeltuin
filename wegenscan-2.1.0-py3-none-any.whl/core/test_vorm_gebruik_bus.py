import unittest
from vorm_gebruik import VormGebruik

class TestVormGebruik(unittest.TestCase):
    def setUp(self):
        self.vorm_gebruik = VormGebruik()

    def test_bus_weinig_bussen(self):
        result = self.vorm_gebruik.bus_stop_facility('1-4 bussen/uur', 'halteren op rijbaan', 100)
        self.assertEqual(result, 'GOED')

    def test_bus_medium_bussen_busy(self):
        result = self.vorm_gebruik.bus_stop_facility('4-6 bussen/uur', 'halteren op rijbaan', 1000)
        self.assertEqual(result, 'MATIG')

    def test_bus_medium_bussen(self):
        result = self.vorm_gebruik.bus_stop_facility('4-6 bussen/uur', 'halteren op rijbaan', 100)
        self.assertEqual(result, 'GOED')

    def test_bus_veel_bussen(self):
        result = self.vorm_gebruik.bus_stop_facility('>6 bussen/uur', 'halteren op rijbaan', 100)
        self.assertEqual(result, 'MATIG')

    def test_bus_niet_aanwezig(self):
        result = self.vorm_gebruik.bus_stop_facility('niet aanwezig', 'niet van toepassing', 100)
        self.assertEqual(result, 'NVT')
