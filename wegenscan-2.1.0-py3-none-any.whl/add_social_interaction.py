"""
Add social interaction attribute to the NWB network GeoJSON (default value).

Adds:
  - social_interaction  (default: 'ja')

No external data source is currently available for this attribute.
Replace the default with actual data when a source becomes available.

Usage:
    python add_social_interaction.py
    python add_social_interaction.py -i nwb_network.geojson -o nwb_network_social.geojson
"""
import argparse
import json
import sys

INPUT_FILE = "nwb_network.geojson"
OUTPUT_FILE = "nwb_network.geojson"

DEFAULT_SOCIAL_INTERACTION = "ja"


def main():
    parser = argparse.ArgumentParser(
        description="Add social interaction attribute (default) to GeoJSON"
    )
    parser.add_argument("-i", "--input", default=INPUT_FILE)
    parser.add_argument("-o", "--output", default=OUTPUT_FILE)
    args = parser.parse_args()

    print(f"Loading {args.input}...")
    with open(args.input, "r", encoding="utf-8") as f:
        geojson = json.load(f)

    num_features = len(geojson["features"])
    print(f"  {num_features} features loaded")

    for feature in geojson["features"]:
        feature["properties"].setdefault("social_interaction", DEFAULT_SOCIAL_INTERACTION)

    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(geojson, f, ensure_ascii=False)

    print(f"GeoJSON saved to {args.output} ({num_features} features, defaults applied)")


if __name__ == "__main__":
    main()
