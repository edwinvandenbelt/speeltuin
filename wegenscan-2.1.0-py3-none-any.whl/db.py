"""
Thin Databricks SQL helper using the official databricks-sql-connector package.

All scripts import execute_sql() from here instead of rolling their own HTTP logic.

Configuration via environment variables:
    DATABRICKS_SERVER_HOSTNAME  - e.g. dbc-f8574491-808a.cloud.databricks.com
    DATABRICKS_HTTP_PATH        - e.g. /sql/1.0/warehouses/<warehouse_id>
    DATABRICKS_CLIENT_ID        - OAuth M2M service principal client ID
    DATABRICKS_CLIENT_SECRET    - OAuth M2M service principal client secret
"""

import os

from databricks import sql as databricks_sql


DATABRICKS_SERVER_HOSTNAME = os.environ.get("DATABRICKS_SERVER_HOSTNAME", "")
DATABRICKS_HTTP_PATH = os.environ.get("DATABRICKS_HTTP_PATH", "")
DATABRICKS_CLIENT_ID = os.environ.get("DATABRICKS_CLIENT_ID", "")
DATABRICKS_CLIENT_SECRET = os.environ.get("DATABRICKS_CLIENT_SECRET", "")


def get_connection():
    """Return a new Databricks SQL connection."""
    if not DATABRICKS_HTTP_PATH:
        raise ValueError(
            "No HTTP path configured. "
            "Set the DATABRICKS_HTTP_PATH environment variable "
            "(e.g. /sql/1.0/warehouses/<warehouse_id>)."
        )
    return databricks_sql.connect(
        server_hostname=DATABRICKS_SERVER_HOSTNAME,
        http_path=DATABRICKS_HTTP_PATH,
        client_id=DATABRICKS_CLIENT_ID,
        client_secret=DATABRICKS_CLIENT_SECRET,
    )


def execute_sql(sql):
    """Execute a SQL statement and return (columns, rows).

    Returns:
        tuple: (list[str], list[list]) — column names and row data,
               or (None, None) on failure.
    """
    try:
        with get_connection() as conn:
            with conn.cursor() as cursor:
                print("Executing SQL statement...")
                cursor.execute(sql)
                columns = [desc[0] for desc in cursor.description]
                rows = cursor.fetchall()
                # Convert Row objects to plain lists for consistency
                rows = [list(row) for row in rows]
                print(f"  {len(rows)} rows returned")
                return columns, rows
    except Exception as e:
        print(f"Query execution failed: {e}")
        return None, None
