# Databricks notebook source
"""
Parallel Link Finder — Databricks notebook entry point.

Reads a directed network GeoJSON from S3 or local path, enriches each feature with
parallelLinkIds and reverseLinkIds (KD-tree spatial matching in RD New),
and writes the result back.

Set the widgets below and run all cells.
"""

# COMMAND ----------

dbutils.widgets.text(
    "network_uri", "", "Full URI of the input network GeoJSON (s3:// or local path)"
)
dbutils.widgets.text("output_uri", "", "Full URI for the output (blank = overwrite input)")
dbutils.widgets.text("maxlength_sublink", "5", "Max sub-link length (m)")
dbutils.widgets.text("maxdist", "20", "Max lateral distance (m)")
dbutils.widgets.text("maxalpha", "15", "Max angular difference (deg)")

# COMMAND ----------

import sys

# Add the workspace source root to sys.path so the module packages are importable.
_workspace_path = (
    dbutils.widgets.get("workspace_path")
    if "workspace_path" in [w.name for w in dbutils.widgets.getAll()]
    else "/Workspace/Shared/gmt"
)
if _workspace_path not in sys.path:
    sys.path.insert(0, _workspace_path)

# COMMAND ----------

import json

import gmt_shared.s3 as _s3

from gmt_network_core.parallel_link_finder.core.parallel_link_finder_core import find_parallel_links

network_uri = dbutils.widgets.get("network_uri").strip()
output_uri = dbutils.widgets.get("output_uri").strip() or network_uri
maxlength_sublink = float(dbutils.widgets.get("maxlength_sublink"))
maxdist = float(dbutils.widgets.get("maxdist"))
maxalpha = float(dbutils.widgets.get("maxalpha"))

if not network_uri:
    raise ValueError("Widget 'network_uri' must not be empty.")


def _read_bytes(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, k = _s3.s3_split(uri)
        return _s3.get_bytes_s3(bucket, k)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_bytes(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, k = _s3.s3_split(uri)
        _s3.put_bytes_s3(bucket, k, data)
    else:
        import pathlib

        pathlib.Path(uri).parent.mkdir(parents=True, exist_ok=True)
        pathlib.Path(uri).write_bytes(data)


print(f"Reading {network_uri} …")
geojson_network = json.loads(_read_bytes(network_uri))
print(f"  {len(geojson_network['features'])} features loaded")

# COMMAND ----------

print("Enriching with parallel / opposite link IDs …")
enriched, stats = find_parallel_links(
    geojson_network,
    maxlength_sublink=maxlength_sublink,
    maxdist=maxdist,
    maxalpha=maxalpha,
)
print(
    f"  features_enriched={stats['featuresEnriched']}  features_skipped={stats['featuresSkipped']}"
)

# COMMAND ----------

print(f"Writing enriched network to {output_uri} …")
_write_bytes(output_uri, json.dumps(enriched).encode())
print("Done.")
displayHTML(f"<b>Written:</b> {output_uri}  &mdash;  {stats['featuresEnriched']} features enriched")
