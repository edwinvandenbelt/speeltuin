# Databricks notebook source
# -----------------------------------------------------------------------------
# network_conflict_finder_nb.py — Databricks notebook interface.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads input network / traffic-assets from S3 (or local path when bucket
#      widget is empty).
#   3. Calls the pure core function — no Spark I/O.
#   4. Writes the annotated network back to S3 (or local path).
#   5. Prints a summary.
# -----------------------------------------------------------------------------

# COMMAND ----------
import contextlib
import json
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("network_conflict_finder_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
with contextlib.suppress(Exception):
    dbutils.widgets.removeAll()

dbutils.widgets.text(
    "network_uri",
    "",
    "Full URI of the input network GeoJSON (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "traffic_assets_uri",
    "",
    "Optional URI of TRAFFIC-ASSETS GeoJSON (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "output_uri",
    "",
    "Full URI for the output network GeoJSON (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
dbutils.import_notebook("network_conflict_finder.core.network_conflict_finder_core")
from gmt_network_core.network_conflict_finder.core.network_conflict_finder_core import (
    enrich_network_with_conflicts,
)

# COMMAND ----------
NETWORK_URI = dbutils.widgets.get("network_uri").strip()
TRAFFIC_ASSETS_URI = dbutils.widgets.get("traffic_assets_uri").strip()
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")

logger.info(
    "network_uri=%s  traffic_assets_uri=%s  output_uri=%s",
    NETWORK_URI,
    TRAFFIC_ASSETS_URI,
    OUTPUT_URI,
)

# COMMAND ----------
# S3 helpers
import boto3


def _get_s3(bucket: str, key: str) -> bytes:
    body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
    logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
    return body


def _put_s3(bucket: str, key: str, data: bytes) -> None:
    boto3.client("s3").put_object(
        Bucket=bucket,
        Key=key,
        Body=data,
        ContentType="application/geo+json",
    )
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        return _get_s3(bucket, key)
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        _put_s3(bucket, key, data)
    else:
        import os

        os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
        with open(uri, "wb") as _fh:
            _fh.write(data)
        logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run NetworkConflictFinder
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
_t_start = datetime.now(UTC)

print(f"Starting  {_t_start.isoformat()}")
print(f"Network : {NETWORK_URI}")
print(f"Assets  : {TRAFFIC_ASSETS_URI or '(none)'}")
print(f"Output  : {OUTPUT_URI}")
print()

network_raw = _read_uri(NETWORK_URI)
network_fc = json.loads(network_raw)

control_assets: list[dict] = []
if TRAFFIC_ASSETS_URI:
    assets_raw = _read_uri(TRAFFIC_ASSETS_URI)
    assets_fc = json.loads(assets_raw)
    control_assets = assets_fc.get("features") or []

result = enrich_network_with_conflicts(network_fc, control_assets)

payload = json.dumps(result, ensure_ascii=False).encode("utf-8")
_write_uri(OUTPUT_URI, payload)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

feature_count = len(result.get("features") or [])
annotated = sum(
    1
    for f in result.get("features") or []
    if (f.get("properties") or {}).get("fromRightLinkId") is not None
    or (f.get("properties") or {}).get("oppositeLinkId") is not None
)

# COMMAND ----------
_SEP = "─" * 60
print(_SEP)
print(f"NetworkConflictFinder complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Output URL : {OUTPUT_URI}")
print(f"  Links      : {feature_count}")
print(f"  Annotated  : {annotated}")
print(_SEP)
