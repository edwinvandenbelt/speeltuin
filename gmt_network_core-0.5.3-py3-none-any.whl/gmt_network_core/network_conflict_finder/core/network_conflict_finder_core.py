"""Pure-Python network conflict finder — no I/O, no boto3, no external deps.

Adds speed-layer columns to every network link:

| Column | Source |
|---|---|
| ``fromRightLinkId`` | other link sharing the ``toNode`` and arriving from the right |
| ``fromLeftLinkId`` | other link sharing the ``toNode`` and arriving from the left |
| ``oppositeLinkId`` | other link sharing the ``toNode`` and arriving from the opposite direction |
| ``turnLeftRatio`` / ``turnRightRatio`` | demand-weighted turn ratios at the ``toNode`` |

The module is intentionally conservative: when classification is ambiguous it
falls back to ``null`` / ``0.0`` rather than guessing.

Public API
----------
enrich_network_with_conflicts(network_fc)
    Add conflict columns to *network_fc* in-place and return it.
"""

from __future__ import annotations

import logging
import math
from collections import defaultdict

logger = logging.getLogger(__name__)

# Approximate metres per degree at mid-latitudes (flat-earth).
_METERS_PER_DEGREE: float = 111_000.0

# Bearing tolerance for conflicting links sharing the toNode.
_RIGHT_BEARING_TOLERANCE: float = 25.0
_LEFT_BEARING_TOLERANCE: float = 25.0
_OPPOSITE_BEARING_TOLERANCE: float = 25.0

# Bearing tolerance when classifying outgoing links as left / straight / right.
_LEFT_TURN_TOLERANCE: float = 30.0
_RIGHT_TURN_TOLERANCE: float = 30.0

_NodeId = str | int


def _bearing_deg(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """Compass bearing 0-360° from (lon1,lat1) to (lon2,lat2)."""
    lat_mid = math.radians((lat1 + lat2) / 2.0)
    dx = (lon2 - lon1) * math.cos(lat_mid)
    dy = lat2 - lat1
    return math.degrees(math.atan2(dx, dy)) % 360.0


def _bearing_difference(a: float, b: float) -> float:
    """Smallest signed difference a - b, range [-180, 180]."""
    diff = (a - b + 180.0) % 360.0 - 180.0
    if diff < -180.0:
        diff += 360.0
    return diff


def _link_endpoints(feature: dict) -> tuple[tuple[float, float], tuple[float, float]] | None:
    """Return ((from_lon, from_lat), (to_lon, to_lat)) for a LineString link."""
    geom = feature.get("geometry") or {}
    if geom.get("type") != "LineString":
        return None
    coords = geom.get("coordinates") or []
    if len(coords) < 2:
        return None
    return (
        (float(coords[0][0]), float(coords[0][1])),
        (float(coords[-1][0]), float(coords[-1][1])),
    )


def _link_bearing(feature: dict) -> float | None:
    """Compass bearing of the link from fromNode to toNode."""
    ends = _link_endpoints(feature)
    if ends is None:
        return None
    (lon1, lat1), (lon2, lat2) = ends
    return _bearing_deg(lon1, lat1, lon2, lat2)


def _node_link_index(network_fc: dict) -> dict[_NodeId, list[dict]]:
    """Return ``nodeId -> [link features touching that node]``."""
    idx: dict[_NodeId, list[dict]] = defaultdict(list)
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        for node_key in ("fromNode", "toNode"):
            node_id = props.get(node_key)
            if node_id is not None:
                idx[node_id].append(feat)
    return idx


def _find_conflicting_links(
    subject: dict,
    node_links: dict[_NodeId, list[dict]],
) -> tuple[_NodeId | None, _NodeId | None, _NodeId | None]:
    """Return ``(from_right_link_id, from_left_link_id, opposite_link_id)`` at toNode.

    Looks at all other links that share the subject's ``toNode`` and classifies
    them by the signed bearing difference ``other_bearing - subject_bearing``:

    * ``opposite_link_id`` — difference between 135° and 225° (rechtdoor).
    * ``from_left_link_id`` — difference between 0° and 135° (linksaf).
    * ``from_right_link_id`` — difference between 225° and 360° (rechtsaf).

    When multiple links fall in the same sector, the one closest to the ideal
    angle (90°, 180° or 270°) wins. ``None`` is returned for sectors without a
    match.
    """
    subject_props = subject.get("properties") or {}
    node_id = subject_props.get("toNode")
    if node_id is None:
        return None, None, None

    subject_bearing = _link_bearing(subject)
    if subject_bearing is None:
        return None, None, None

    subject_link_id = subject_props.get("linkId")
    left_candidates: list[tuple[dict, float]] = []
    opposite_candidates: list[tuple[dict, float]] = []
    right_candidates: list[tuple[dict, float]] = []

    for other in node_links.get(node_id, []):
        other_props = other.get("properties") or {}
        other_id = other_props.get("linkId")
        if other_id is None or other_id == subject_link_id:
            continue

        # Only links that also end at this node are "approaching" it.
        if other_props.get("toNode") != node_id:
            continue

        other_bearing = _link_bearing(other)
        if other_bearing is None:
            continue

        diff = _bearing_difference(other_bearing, subject_bearing) % 360.0
        if 0.0 < diff < 135.0:
            left_candidates.append((other, diff))
        elif 135.0 <= diff <= 225.0:
            opposite_candidates.append((other, diff))
        elif 225.0 < diff < 360.0:
            right_candidates.append((other, diff))

    def _closest(candidates: list[tuple[dict, float]], target: float) -> _NodeId | None:
        if not candidates:
            return None
        best = min(candidates, key=lambda item: abs(item[1] - target))
        return best[0].get("properties", {}).get("linkId")

    from_left_link_id = _closest(left_candidates, 90.0)
    opposite_link_id = _closest(opposite_candidates, 180.0)
    from_right_link_id = _closest(right_candidates, 270.0)

    return from_right_link_id, from_left_link_id, opposite_link_id


def _outgoing_flows_by_node(
    network_fc: dict,
) -> dict[_NodeId, dict[str, object]]:
    """Return ``nodeId -> {"total": flow, "by_link_id": {linkId: flow}}``.

    Only links that have the node as ``fromNode`` are considered outgoing.
    """
    result: dict[_NodeId, dict[str, object]] = defaultdict(lambda: {"total": 0.0, "by_link_id": {}})
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        lid = props.get("linkId")
        from_node = props.get("fromNode")
        if lid is None or from_node is None:
            continue
        flow = props.get("flow24hrs") or props.get("flow") or props.get("aadt") or 0.0
        try:
            flow_f = float(flow)
        except (TypeError, ValueError):
            flow_f = 0.0
        by_link = result[from_node]["by_link_id"]
        assert isinstance(by_link, dict)
        by_link[lid] = flow_f
        current_total = result[from_node]["total"]
        assert isinstance(current_total, (int, float))
        result[from_node]["total"] = float(current_total) + flow_f
    return result


def _turn_ratios_at_node(
    subject: dict,
    node_links: dict[_NodeId, list[dict]],
    outgoing_flows: dict[_NodeId, dict[str, object]],
) -> tuple[float, float]:
    """Return ``(left_turn_ratio, right_turn_ratio)`` at the subject's toNode.

    The ratios are computed from the total outgoing flow at the ``toNode``.
    Outgoing links are classified by comparing the subject's approach bearing
    with each outgoing link's bearing:

    * left turn  → outgoing bearing ≈ subject approach bearing - 90°
    * right turn → outgoing bearing ≈ subject approach bearing + 90°
    * straight   → outgoing bearing ≈ subject approach bearing

    The subject link itself (or its reverse, i.e. a U-turn back over the same
    geometry) is excluded from the classification.  When no outgoing flow is
    available the function returns ``(0.0, 0.0)``.
    """
    subject_props = subject.get("properties") or {}
    node_id = subject_props.get("toNode")
    if node_id is None:
        return 0.0, 0.0

    subject_bearing = _link_bearing(subject)
    if subject_bearing is None:
        return 0.0, 0.0

    subject_link_id = subject_props.get("linkId")
    node_flow = outgoing_flows.get(node_id, {"total": 0.0, "by_link_id": {}})
    total_out = node_flow.get("total", 0.0)
    assert isinstance(total_out, (int, float))
    if total_out <= 0.0:
        return 0.0, 0.0

    left_flow = 0.0
    right_flow = 0.0

    for other in node_links.get(node_id, []):
        other_props = other.get("properties") or {}
        other_id = other_props.get("linkId")
        if other_id is None:
            continue

        # Exclude the subject itself and its reverse (U-turn back over same link).
        if other_id == subject_link_id:
            continue
        other_from = other_props.get("fromNode")
        other_to = other_props.get("toNode")
        if other_from == subject_props.get("toNode") and other_to == subject_props.get("fromNode"):
            continue

        # Only outgoing links have this node as fromNode.
        if other_from != node_id:
            continue

        other_bearing = _link_bearing(other)
        if other_bearing is None:
            continue
        diff = _bearing_difference(other_bearing, subject_bearing)

        by_link = node_flow.get("by_link_id", {})
        assert isinstance(by_link, dict)
        flow = by_link.get(other_id, 0.0)
        assert isinstance(flow, (int, float))
        if abs(diff + 90.0) <= _LEFT_TURN_TOLERANCE:
            left_flow += flow
        elif abs(diff - 90.0) <= _RIGHT_TURN_TOLERANCE:
            right_flow += flow

    return (
        round(left_flow / float(total_out), 4),
        round(right_flow / float(total_out), 4),
    )


def enrich_network_with_conflicts(network_fc: dict) -> dict:
    """Add conflict columns to every link in *network_fc*.

    Parameters
    ----------
    network_fc:
        GeoJSON FeatureCollection of network links. Each link must have
        ``linkId``, ``fromNode`` and ``toNode`` properties.

    Returns
    -------
    dict
        The same *network_fc* instance with additional properties on each link:

    * ``fromRightLinkId`` — link sharing ``toNode`` and approaching from the
      right (bearing ≈ subject bearing - 90°).
    * ``fromLeftLinkId`` — link sharing ``toNode`` and approaching from the
      left (bearing ≈ subject bearing + 90°).
    * ``oppositeLinkId`` — link sharing ``toNode`` and approaching from the
      opposite direction (bearing ≈ subject bearing + 180°).
    * ``turnLeftRatio`` / ``turnRightRatio`` — estimated share of traffic at
      the ``toNode`` that turns left or right onto an outgoing link. Ratios
      are based on the ``flow24hrs`` of outgoing links from that node (range
      ``0..1``, ``0.0`` when no outgoing flow is available).

    The function never raises: malformed links are skipped and the rest of the
    network is enriched.
    """
    node_links = _node_link_index(network_fc)
    outgoing_flows = _outgoing_flows_by_node(network_fc)

    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        lid = props.get("linkId")
        if lid is None:
            continue

        from_right_link_id, from_left_link_id, opposite_link_id = _find_conflicting_links(
            feat, node_links
        )

        props["fromRightLinkId"] = from_right_link_id
        props["fromLeftLinkId"] = from_left_link_id
        props["oppositeLinkId"] = opposite_link_id

        # Turn ratios based on outgoing flows at the toNode.
        left_at_to, right_at_to = _turn_ratios_at_node(feat, node_links, outgoing_flows)
        props["turnLeftRatio"] = left_at_to
        props["turnRightRatio"] = right_at_to

    return network_fc
