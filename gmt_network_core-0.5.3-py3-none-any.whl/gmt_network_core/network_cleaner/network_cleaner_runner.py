"""Local debug runner for network_cleaner.

Calls network_cleaner_core.clean_network() directly — no Lambda handler involved.

Usage
-----
    python -m network_cleaner.network_cleaner_runner \\
        --networks /tmp/network-CAR.parquet /tmp/network-BIKE.parquet

    # Single file, separate output:
    python -m network_cleaner.network_cleaner_runner \\
        --networks /tmp/network.parquet \\
        --output /tmp/network-clean.parquet

    # S3 input (overwrites in place):
    python -m network_cleaner.network_cleaner_runner \\
        --networks s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.parquet

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for network_cleaner (calls core directly)."
    )
    parser.add_argument(
        "--networks",
        nargs="+",
        required=True,
        metavar="URI",
        help="One or more full network GeoJSON URIs (s3:// or local path).",
    )
    parser.add_argument(
        "--output-folder",
        metavar="URI",
        default=None,
        help=(
            "Output folder URI; only valid with a single --networks entry. "
            "File named {area_id}-NETWORK.parquet. Defaults to overwriting the input."
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    if args.output_folder and len(args.networks) > 1:
        print(
            "[error] --output-folder can only be used with a single --networks entry.",
            file=sys.stderr,
        )
        sys.exit(1)

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet
    from gmt_shared.output_path import build_output_path

    from gmt_network_core.network_cleaner.core.network_cleaner_core import (
        clean_network,
    )

    for in_uri in args.networks:
        print(f"\nReading  : {in_uri}")
        fc = from_geoparquet(_read_uri(in_uri))
        cleaned_fc, stats = clean_network(fc)
        if args.output_folder:
            area_id = (fc.get("properties") or {}).get("area_id")
            if not area_id:
                import os as _os

                area_id = _os.path.basename(in_uri).split("-NETWORK")[0] or "unknown"
            out_uri = build_output_path(args.output_folder, area_id, "NETWORK")
        else:
            out_uri = in_uri
        print(f"Writing  : {out_uri}")
        _write_uri(out_uri, to_geoparquet(cleaned_fc))
        print(
            f"  total={stats['total']}  kept={stats['kept']}  "
            f"removed={stats['removed']}  seed_node={stats.get('seed_node')}"
        )


if __name__ == "__main__":
    main()
