# Databricks notebook source
# ---------------------------------------------------------------------------
# bidirectional_splitter_nb.py — Databricks notebook for bidirectional_splitter.
#
# This notebook:
#   1. Reads widget parameters (input_uri, output_uri).
#   2. Reads a raw bidirectional GeoJSON FeatureCollection from S3.
#   3. Calls post_process_features to split into directed unidirectional links.
#   4. Writes the result back to S3.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("bidirectional_splitter_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "input_uri",
    "",
    "Full URI of the raw bidirectional GeoJSON (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "output_uri",
    "",
    "Full URI for the directed output GeoJSON (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll = getattr(logging, dbutils.widgets.get("LOG_LEVEL").strip().upper(), logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
INPUT_URI = dbutils.widgets.get("input_uri").strip()
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()

if not INPUT_URI:
    raise ValueError("Widget 'input_uri' is empty.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")

logger.info("input_uri=%s  output_uri=%s", INPUT_URI, OUTPUT_URI)

# COMMAND ----------
import sys

sys.path.insert(0, "/Workspace/Shared/gmt-calculation-lib/src")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run BidirectionalSplitter
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess.
# COMMAND ----------
import boto3

from gmt_network_core.bidirectional_splitter.core.bidirectional_splitter_core import (
    post_process_features,
)


def _get_s3(uri: str) -> bytes:
    rest = uri[5:]
    bucket, _, key = rest.partition("/")
    body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
    logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
    return body


def _put_s3(uri: str, data: bytes) -> None:
    rest = uri[5:]
    bucket, _, key = rest.partition("/")
    boto3.client("s3").put_object(
        Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json"
    )
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


_t_start = datetime.now(UTC)

logger.info("Reading %s ...", INPUT_URI)
_raw = _get_s3(INPUT_URI) if INPUT_URI.startswith("s3://") else open(INPUT_URI, "rb").read()
_fc = json.loads(_raw)

_input_count = len(_fc.get("features", []))
logger.info("Input features: %d", _input_count)

_fc["features"] = post_process_features(_fc["features"])
_output_count = len(_fc["features"])
logger.info("Output features: %d", _output_count)

_payload = json.dumps(_fc, ensure_ascii=False).encode("utf-8")
if OUTPUT_URI.startswith("s3://"):
    _put_s3(OUTPUT_URI, _payload)
else:
    import os

    os.makedirs(os.path.dirname(os.path.abspath(OUTPUT_URI)) or ".", exist_ok=True)
    with open(OUTPUT_URI, "wb") as _fh:
        _fh.write(_payload)
    logger.info("Wrote %s  (%d bytes)", OUTPUT_URI, len(_payload))

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
_SEP = "─" * 60
print(_SEP)
print(f"BidirectionalSplitter complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Input features  : {_input_count}")
print(f"  Output features : {_output_count}")
print(f"  Output URI      : {OUTPUT_URI}")
print(_SEP)
