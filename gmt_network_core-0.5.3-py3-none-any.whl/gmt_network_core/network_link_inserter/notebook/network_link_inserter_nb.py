# Databricks notebook source
# ---------------------------------------------------------------------------
# network_link_inserter_nb.py — Databricks notebook interface for
# network link insertion.
#
# This notebook:
#   1. Reads widget parameters (network URI, changes JSON, output URI).
#   2. Reads the network GeoJSON from S3 (or local path when bucket widget
#      is empty).
#   3. Calls pure core functions (insert_links) — no Spark I/O.
#   4. Writes the modified network back to S3 (or local path).
#   5. Prints a summary of inserted and skipped links.
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s - %(message)s")
logger = logging.getLogger("network_link_inserter_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "network_uri",
    "",
    "Full URI of the input network GeoJSON (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "output_uri",
    "",
    "Full URI for the output network GeoJSON (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "changes_json",
    "[]",
    "JSON array of link-insert change objects",
)
dbutils.widgets.text(
    "snap_tolerance",
    "15.0",
    "Max distance (m) for snapping to an existing node",
)
dbutils.widgets.text(
    "max_snap_distance",
    "30.0",
    "Max distance (m) for snapping via foot-of-perpendicular",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_network_core.network_link_inserter.core.network_link_inserter_core import insert_links

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

NETWORK_URI = dbutils.widgets.get("network_uri").strip()
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()
CHANGES_JSON = dbutils.widgets.get("changes_json").strip()
SNAP_TOL = float(dbutils.widgets.get("snap_tolerance").strip())
MAX_SNAP_DIST = float(dbutils.widgets.get("max_snap_distance").strip())

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")

changes = json.loads(CHANGES_JSON)
if not isinstance(changes, list):
    raise ValueError("Widget 'changes_json' must be a JSON array.")

logger.info(
    "network_uri=%s  output_uri=%s  changes=%d  snap_tol=%.1f  max_snap=%.1f",
    NETWORK_URI,
    OUTPUT_URI,
    len(changes),
    SNAP_TOL,
    MAX_SNAP_DIST,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Network Link Inserter
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

_t_start = datetime.now(UTC)

print(f"Starting  {_t_start.isoformat()}")
print(f"Network   : {NETWORK_URI}")
print(f"Output    : {OUTPUT_URI}")
print(f"Changes   : {len(changes)}")
print()

_raw = _read_uri(NETWORK_URI)
_network_fc = json.loads(_raw)

_result_fc, _report = insert_links(
    _network_fc,
    changes,
    snap_tolerance_m=SNAP_TOL,
    max_snap_distance_m=MAX_SNAP_DIST,
)

_payload = json.dumps(_result_fc, ensure_ascii=False).encode("utf-8")
_write_uri(OUTPUT_URI, _payload)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "-" * 60
print(_SEP)
print(f"Network Link Inserter complete -- {_elapsed:.1f}s")
print(_SEP)
print(f"  inserted    : {_report['inserted']}")
print(f"  links_added : {_report['links_added']}")
print(f"  skipped     : {_report['skipped']}")
if _report["warnings"]:
    print("  warnings:")
    for _w in _report["warnings"]:
        print(f"    [WARN] {_w}")
print(_SEP)
