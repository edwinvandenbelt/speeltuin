"""Local debug runner for network_link_inserter.

Calls network_link_inserter_core.insert_links() directly — no Lambda handler
involved.

Usage
-----
    python -m network_link_inserter.network_link_inserter_runner \\
        --network-file /tmp/NETWORK-CAR.geojson \\
        --changes '[{"linkId":null,"geometry":{"type":"LineString","coordinates":[[5.0,52.0],[5.01,52.0]]},"speed":50,"capacity":800}]' \\
        --output-file /tmp/NETWORK-CAR-new.geojson

    # Changes from a JSON file:
    python -m network_link_inserter.network_link_inserter_runner \\
        --network-file /tmp/NETWORK-CAR.geojson \\
        --changes /path/to/changes.json \\
        --output-file /tmp/NETWORK-CAR-new.geojson

    # S3 URIs:
    python -m network_link_inserter.network_link_inserter_runner \\
        --network-file s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.geojson \\
        --changes changes.json \\
        --output-file s3://gmp-networks/network/deventer-centrum-NETWORK-CAR-new.geojson

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for
  s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for network_link_inserter (calls core directly)."
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="Full URI of the network GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--changes",
        required=True,
        metavar="JSON_OR_PATH",
        help=(
            "JSON array of change objects, or path to a .json file containing the array.  "
            "Each change must have linkId=null, geometry (LineString), speed, capacity, "
            "and optionally direction ('both'|'forward'|'backward') and lanes."
        ),
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder URI (s3://bucket/prefix/ or local dir). File named {area_id}-NETWORK.geojson.",
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help=(
            "Override the area_id used in the output filename. "
            "Defaults to the area_id from the network GeoJSON properties, "
            "or is derived from the input filename."
        ),
    )
    parser.add_argument(
        "--snap-tolerance",
        type=float,
        default=15.0,
        metavar="METRES",
        help="Max distance (m) for snapping to an existing node (default: 15.0).",
    )
    parser.add_argument(
        "--max-snap-distance",
        type=float,
        default=30.0,
        metavar="METRES",
        help="Max distance (m) for snapping via foot-of-perpendicular (default: 30.0).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    # Parse changes
    changes_raw = args.changes.strip()
    if changes_raw.endswith(".json") and not changes_raw.startswith("["):
        # Treat as file path
        with open(changes_raw, encoding="utf-8") as fh:
            changes = json.load(fh)
    else:
        changes = json.loads(changes_raw)

    if not isinstance(changes, list):
        print("[error] --changes must be a JSON array.", file=sys.stderr)
        sys.exit(1)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet
    from gmt_shared.output_path import build_output_path

    from gmt_network_core.network_link_inserter.core.network_link_inserter_core import (
        insert_links,
    )

    print(f"\nReading  : {args.network_file}")
    network_fc = from_geoparquet(_read_uri(args.network_file))

    result_fc, report = insert_links(
        network_fc,
        changes,
        snap_tolerance_m=args.snap_tolerance,
        max_snap_distance_m=args.max_snap_distance,
    )

    area_id = args.area_id or (network_fc.get("properties") or {}).get("area_id")
    if not area_id:
        import os as _os

        area_id = _os.path.basename(args.network_file).split("-NETWORK")[0] or "unknown"
    out_uri = build_output_path(args.output_folder, area_id, "NETWORK")

    print(f"Writing  : {out_uri}")
    _write_uri(
        out_uri,
        to_geoparquet(result_fc),
    )

    print(
        f"  inserted={report['inserted']}  links_added={report['links_added']}"
        f"  skipped={report['skipped']}"
    )
    if report["warnings"]:
        for w in report["warnings"]:
            print(f"  [WARN] {w}")


if __name__ == "__main__":
    main()
