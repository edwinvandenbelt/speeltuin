# Databricks notebook source
# ---------------------------------------------------------------------------
# network_zone_joiner_nb.py — Databricks notebook interface for network_zone_joiner.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads zones and network GeoJSON from S3 (or local path).
#   3. Calls pure core functions — no Spark I/O.
#   4. Writes per-zone NETWORK and ZONE output files to S3 (or local path).
#   5. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("network_zone_joiner_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "zones_uri",
    "",
    "Full URI of the zones GeoJSON file (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "network_uri",
    "",
    "Full URI of the network GeoJSON file (s3://bucket/key or local path)",
)
dbutils.widgets.text(
    "output_folder",
    "",
    "Output folder URI (s3://bucket/prefix/ or local directory)",
)
dbutils.widgets.text(
    "area_id",
    "",
    "Override area ID (optional — read from zones file if blank)",
)
dbutils.widgets.text(
    "mode",
    "",
    "Override transport mode (optional — read from network file if blank)",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_network_core.network_zone_joiner.core.network_zone_joiner_core import (
    build_zone_output_path,
    join_zones_to_network,
)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

ZONES_URI = dbutils.widgets.get("zones_uri").strip()
NETWORK_URI = dbutils.widgets.get("network_uri").strip()
OUTPUT_FOLDER = dbutils.widgets.get("output_folder").strip()
AREA_ID_OVERRIDE = dbutils.widgets.get("area_id").strip()
MODE_OVERRIDE = dbutils.widgets.get("mode").strip()

if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty.")
if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")
if not OUTPUT_FOLDER:
    raise ValueError("Widget 'output_folder' is empty.")

logger.info(
    "zones_uri=%s  network_uri=%s  output_folder=%s",
    ZONES_URI,
    NETWORK_URI,
    OUTPUT_FOLDER,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3


def _get_s3(bucket: str, key: str) -> bytes:
    body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
    logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
    return body


def _put_s3(bucket: str, key: str, data: bytes) -> None:
    boto3.client("s3").put_object(
        Bucket=bucket,
        Key=key,
        Body=data,
        ContentType="application/geo+json",
    )
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        _bucket, _key = uri[5:].split("/", 1)
        return _get_s3(_bucket, _key)
    with open(uri.removeprefix("file://"), "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        _bucket, _key = uri[5:].split("/", 1)
        _put_s3(_bucket, _key, data)
    else:
        import os

        _path = uri.removeprefix("file://")
        os.makedirs(os.path.dirname(_path) or ".", exist_ok=True)
        with open(_path, "wb") as _fh:
            _fh.write(data)
        logger.info("Wrote %s  (%d bytes)", _path, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run NetworkZoneJoiner
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

_t_start = datetime.now(UTC)

print(f"Starting  {_t_start.isoformat()}")
print(f"Zones URI    : {ZONES_URI}")
print(f"Network URI  : {NETWORK_URI}")
print(f"Output folder: {OUTPUT_FOLDER}")
print()

_zones_fc = json.loads(_read_uri(ZONES_URI))
_network_fc = json.loads(_read_uri(NETWORK_URI))

_zones_props = _zones_fc.get("properties") or {}
_network_props = _network_fc.get("properties") or {}

_area_id = (
    AREA_ID_OVERRIDE or _zones_props.get("areaId") or _network_props.get("area_id") or "unknown"
)
_modes = _network_props.get("modes") or []
_mode = MODE_OVERRIDE or (_modes[0] if _modes else None) or "UNKNOWN"

print(f"Area ID : {_area_id}")
print(f"Mode    : {_mode}")

_results = join_zones_to_network(_zones_fc, _network_fc)

for _zone_feat, _clipped_net_fc, _zone_fc in _results:
    _zp = _zone_feat.get("properties") or {}
    _zone_id = _zp.get("zoneId") or ""

    _net_uri = build_zone_output_path(OUTPUT_FOLDER, _area_id, _zone_id, "NETWORK", _mode)
    _zone_uri = build_zone_output_path(OUTPUT_FOLDER, _area_id, _zone_id, "ZONE", _mode)

    _write_uri(_net_uri, json.dumps(_clipped_net_fc, ensure_ascii=False).encode("utf-8"))
    _write_uri(_zone_uri, json.dumps(_zone_fc, ensure_ascii=False).encode("utf-8"))

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"NetworkZoneJoiner complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Zones processed : {len(_results)}")
print(f"  Area ID         : {_area_id}")
print(f"  Mode            : {_mode}")
print(f"  Output folder   : {OUTPUT_FOLDER}")
print(_SEP)
