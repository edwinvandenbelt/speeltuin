"""Feedlink-building logic for feedlink_fetcher.

Builds production + attraction feedlinks from voedingslinks rows and
zone_fetcher zone features.  Zones with ``zoneClass`` AREA are skipped
(they have no gid / voedingslinks entry in Databricks).

For zones that are not covered by any valid voedingslinks row (i.e. the
Databricks table has no entry for the zone, or the referenced node is absent
from the local network), a **fallback feedlink** is synthesised by connecting
the zone centroid to a nearby network node. The candidate pool considered for
each direction is first restricted to the entry/exit nodes of the selected
boundary mini-zones (as computed by
``network_zone_joiner.domain.joiner.compute_network_boundary_node_roles``,
which makes exactly the same selection as ``join_zones_to_network``: every
crossing faster than ``major_boundary_speed_kph``, topped up with the
highest-flow crossings at exactly that speed until ``min_boundary_zones`` is
reached), split by role: nodes registered as the ``fromNode`` of a
boundary-crossing link (entry points) are valid candidates for the
**production** feedlink (zone → network), while nodes registered as the
``toNode`` of a boundary-crossing link (exit points) are valid candidates for
the **attraction** feedlink (network → zone). From that role-restricted pool,
the ``top_n`` (default 10) geometrically nearest network nodes are determined,
and then the candidate with the highest outgoing ``flow`` is chosen for the
production feedlink and the candidate with the highest incoming ``flow`` is
chosen for the attraction feedlink (see ``_nearest_nodes``/``_best_by_flow``
and ``network.node_flow_totals``). Production and attraction can therefore end
up attached to two different nodes. Ties — including the case where none of
the candidates carry any flow data at all (e.g. PEDESTRIAN mode) — are broken
by nearest distance, so the algorithm degrades gracefully to a plain
nearest-node fallback when flow data is unavailable. When the caller does not
supply the entry/exit node ID sets (e.g. no AREA zone is present), the
candidate pool falls back to *all* network nodes for both directions,
preserving the previous (undifferentiated) behaviour. This guarantees that
every non-AREA zone is reachable in the routed network regardless of whether
Databricks has an up-to-date voedingslinks entry. Zones with zero production
and zero attraction still get a zero-capacity connectivity feedlink rather
than being skipped, so they are never left without any feedlink at all.

This also covers zones from ``zone_fetcher_aggregated`` (STUDY/INFLUENCE
aggregates), which are assigned a negative synthetic ``gid`` precisely so
they can never match a real Databricks voedingslinks row (real gids are
always positive). Such zones therefore always and correctly fall through to
the fallback path above — no special-casing is needed here; the caller is
only responsible for excluding negative gids from the Databricks query (see
``feedlink_fetcher_runner.py`` / ``notebook/feedlink_fetcher_nb.py``).
"""

from __future__ import annotations

import logging

from gmt_shared.geo_utils import _flat_earth_dist_m, _parse_wkt_geometry, _straight_line

logger = logging.getLogger(__name__)

# Property keys on every feedlink feature.
FEEDLINK_PROPERTIES: tuple[str, ...] = (
    "feedlinkId",
    "reverseLinkIds",
    "zoneId",
    "fromNode",
    "toNode",
    "length",
    "capacity",
    "mode",
    "ringIndex",
    "ringLabel",
    "sectorIndex",
    "type",
    "source",
)


def _nearest_nodes(
    zone_lon: float,
    zone_lat: float,
    node_positions: dict,
    top_n: int,
) -> list[tuple[object, float]]:
    """Return the ``top_n`` nearest network nodes to a zone centroid.

    Parameters
    ----------
    zone_lon, zone_lat:
        WGS-84 coordinates of the zone centroid.
    node_positions:
        Mapping of ``node_id → (lon, lat)`` as returned by
        :func:`~feedlink_fetcher.domain.network.parse_network_geojson`.
    top_n:
        Maximum number of candidates to return.

    Returns
    -------
    list[tuple]
        ``[(node_id, distance_m), ...]`` sorted by ascending distance,
        truncated to *top_n* entries. Empty when *node_positions* is empty.
    """
    distances = [
        (node_id, _flat_earth_dist_m(zone_lon, zone_lat, nlon, nlat))
        for node_id, (nlon, nlat) in node_positions.items()
    ]
    distances.sort(key=lambda pair: pair[1])
    return distances[:top_n]


def _best_by_flow(
    candidates: list[tuple[object, float]],
    flow_by_node: dict,
) -> tuple[object, float]:
    """Pick the candidate with the highest flow, tie-breaking by nearest distance.

    Parameters
    ----------
    candidates:
        ``[(node_id, distance_m), ...]`` as returned by :func:`_nearest_nodes`.
        Order does not matter — ties are always resolved by comparing
        *distance_m* directly.
    flow_by_node:
        Mapping of ``node_id → flow``. Nodes absent from this mapping are
        treated as having zero flow.

    Returns
    -------
    tuple
        ``(node_id, distance_m)`` of the best candidate — or ``(None, inf)``
        when *candidates* is empty. When every candidate has equal (including
        zero or missing) flow, the geometrically nearest candidate wins —
        which is also what happens when *flow_by_node* carries no data at
        all, degrading gracefully to plain nearest-node selection.
    """
    if not candidates:
        return None, float("inf")

    best_id, best_dist = candidates[0]
    best_flow = flow_by_node.get(best_id, 0.0)
    for node_id, dist_m in candidates[1:]:
        flow = flow_by_node.get(node_id, 0.0)
        if flow > best_flow or (flow == best_flow and dist_m < best_dist):
            best_id, best_dist, best_flow = node_id, dist_m, flow
    return best_id, best_dist


def build_feedlinks(
    zones_fc: dict,
    node_positions: dict,
    all_node_ids: set,
    vl_rows: list,
    mode: str,
    outgoing_flow: dict | None = None,
    incoming_flow: dict | None = None,
    top_n: int = 10,
    entry_node_ids: set | None = None,
    exit_node_ids: set | None = None,
) -> dict:
    """Build a feedlink FeatureCollection from zone_fetcher zones + voedingslinks rows.

    For every non-AREA zone that is **not** covered by a valid voedingslinks row
    (i.e. no row exists, or the row's node is absent from the network), a fallback
    feedlink is created using the highest-flow node among the nearest candidates.

    Parameters
    ----------
    zones_fc:
        GeoJSON FeatureCollection from zone_fetcher.  Features with
        ``properties.zoneClass`` of ``"AREA"`` are skipped (no gid).
    node_positions:
        Mapping of ``node_id → (lon, lat)`` from the parsed network.
    all_node_ids:
        Set of all node IDs present in the network.
    vl_rows:
        Rows from the Databricks voedingslinks table
        (``van_centroid_gid``, ``naar_knoop_id``, ``wkt_geom_4326``, …).
    mode:
        Transport mode string, e.g. ``"CAR"``.
    outgoing_flow, incoming_flow:
        Optional ``node_id → flow`` mappings (see
        :func:`~feedlink_fetcher.domain.network.node_flow_totals`), used by
        the fallback path to pick, among the ``top_n`` nearest candidate
        nodes for a zone centroid, the one with the highest outgoing flow (for
        the production feedlink) resp. highest incoming flow (for the
        attraction feedlink) — instead of literally the nearest point in
        space. Zones covered by a valid voedingslinks row are unaffected —
        this only biases the fallback path.
    top_n:
        Number of geometrically nearest candidate network nodes considered
        per zone, per direction, when picking the highest-flow fallback
        attachment node. Default: 10.
    entry_node_ids, exit_node_ids:
        Optional sets of network node IDs restricting the fallback candidate
        pool, as returned by
        ``network_zone_joiner.domain.joiner.compute_network_boundary_node_roles``
        — i.e. the entry/exit nodes of the selected boundary mini-zones, so
        a change in the boundary-zone selection changes this pool too.
        ``entry_node_ids`` (nodes registered as the ``fromNode`` of a
        boundary-crossing link) restricts the candidates considered for the
        **production** feedlink; ``exit_node_ids`` (nodes registered as the
        ``toNode`` of a boundary-crossing link) restricts the candidates for
        the **attraction** feedlink. When a set is *None* or empty, the
        corresponding direction falls back to searching all of
        *node_positions* (the previous, undifferentiated behaviour).

    Returns
    -------
    dict
        GeoJSON FeatureCollection with feedlink features.
    """
    # Index zone features by gid for quick lookup
    zone_by_gid: dict[int, dict] = {}
    for feat in zones_fc.get("features") or []:
        props = feat.get("properties") or {}
        if props.get("zoneClass") == "AREA":
            continue
        gid = props.get("gid")
        if gid is None:
            continue
        zone_by_gid[int(gid)] = props

    records: list[dict] = []
    fid = 1

    # Track which zones are successfully linked via voedingslinks rows.
    covered_gids: set[int] = set()

    for raw in vl_rows:
        gid = raw.get("van_centroid_gid")
        node_id = raw.get("naar_knoop_id")

        if gid is None or node_id is None:
            continue
        gid = int(gid)
        zone = zone_by_gid.get(gid)
        if zone is None:
            logger.debug("VL row gid=%d: zone not found — skipped", gid)
            continue
        if node_id not in all_node_ids:
            logger.debug("VL row gid=%d: node %s not in network — skipped", gid, node_id)
            continue

        covered_gids.add(gid)

        zone_node_id = str(gid)
        node_lon, node_lat = node_positions[node_id]
        zone_lon = float(zone.get("centroidLon") or 0)
        zone_lat = float(zone.get("centroidLat") or 0)
        production = float(zone.get("production") or 0.0)
        attraction = float(zone.get("attraction") or 0.0)
        dist_m = _flat_earth_dist_m(zone_lon, zone_lat, node_lon, node_lat)

        geom_prod = _parse_wkt_geometry(raw.get("wkt_geom_4326"))
        if geom_prod is None:
            geom_prod = _straight_line(zone_lon, zone_lat, node_lon, node_lat)
        geom_attr = _straight_line(node_lon, node_lat, zone_lon, zone_lat)

        zone_id = str(zone.get("zoneId") or "")
        length = round(dist_m, 1)
        prod_fid = fid
        attr_fid = fid + 1

        if production > 0.0:
            records.append(
                {
                    "type": "Feature",
                    "geometry": geom_prod,
                    "properties": {
                        "feedlinkId": prod_fid,
                        "reverseLinkIds": [attr_fid],
                        "zoneId": zone_id,
                        "fromNode": zone_node_id,
                        "toNode": node_id,
                        "length": length,
                        "capacity": production,
                        "mode": mode,
                        "ringIndex": -1,
                        "ringLabel": "",
                        "sectorIndex": -1,
                        "type": "feedlink",
                        "source": "databricks",
                    },
                }
            )
        if attraction > 0.0:
            records.append(
                {
                    "type": "Feature",
                    "geometry": geom_attr,
                    "properties": {
                        "feedlinkId": attr_fid,
                        "reverseLinkIds": [prod_fid],
                        "zoneId": zone_id,
                        "fromNode": node_id,
                        "toNode": zone_node_id,
                        "length": length,
                        "capacity": attraction,
                        "mode": mode,
                        "ringIndex": -1,
                        "ringLabel": "",
                        "sectorIndex": -1,
                        "type": "feedlink",
                        "source": "databricks",
                    },
                }
            )
        if production == 0.0 and attraction == 0.0:
            # Zero-demand zone: still emit a connectivity-only feedlink (capacity 0)
            # so the zone remains reachable in the routed network.
            records.append(
                {
                    "type": "Feature",
                    "geometry": geom_prod,
                    "properties": {
                        "feedlinkId": prod_fid,
                        "reverseLinkIds": [],
                        "zoneId": zone_id,
                        "fromNode": zone_node_id,
                        "toNode": node_id,
                        "length": length,
                        "capacity": 0.0,
                        "mode": mode,
                        "ringIndex": -1,
                        "ringLabel": "",
                        "sectorIndex": -1,
                        "type": "feedlink",
                        "source": "databricks-connectivity",
                    },
                }
            )
        fid += 2

    # ------------------------------------------------------------------
    # Fallback: for zones not covered by a valid voedingslinks row,
    # synthesise a feedlink to the nearest network node.
    # ------------------------------------------------------------------
    uncovered = [(gid, zone) for gid, zone in zone_by_gid.items() if gid not in covered_gids]

    if uncovered and not node_positions:
        logger.warning(
            "No network nodes available — cannot create fallback feedlinks for %d zone(s)",
            len(uncovered),
        )

    outgoing_flow = outgoing_flow or {}
    incoming_flow = incoming_flow or {}

    # Restrict each direction's candidate pool to the network's true boundary
    # entry/exit nodes when provided; otherwise fall back to all network nodes
    # (previous, undifferentiated behaviour).
    prod_node_positions = (
        {nid: pos for nid, pos in node_positions.items() if nid in entry_node_ids}
        if entry_node_ids
        else node_positions
    )
    attr_node_positions = (
        {nid: pos for nid, pos in node_positions.items() if nid in exit_node_ids}
        if exit_node_ids
        else node_positions
    )

    for gid, zone in uncovered:
        zone_lon = float(zone.get("centroidLon") or 0)
        zone_lat = float(zone.get("centroidLat") or 0)
        production = float(zone.get("production") or 0.0)
        attraction = float(zone.get("attraction") or 0.0)

        if not node_positions:
            continue

        prod_candidates = _nearest_nodes(zone_lon, zone_lat, prod_node_positions, top_n)
        if not prod_candidates and prod_node_positions is not node_positions:
            # Restricted entry-node pool yielded nothing (e.g. no overlap with
            # the network) — degrade gracefully to searching all nodes rather
            # than leaving the zone unconnected.
            prod_candidates = _nearest_nodes(zone_lon, zone_lat, node_positions, top_n)

        attr_candidates = _nearest_nodes(zone_lon, zone_lat, attr_node_positions, top_n)
        if not attr_candidates and attr_node_positions is not node_positions:
            attr_candidates = _nearest_nodes(zone_lon, zone_lat, node_positions, top_n)

        if not prod_candidates and not attr_candidates:
            continue

        prod_node_id, prod_dist_m = _best_by_flow(prod_candidates, outgoing_flow)
        attr_node_id, attr_dist_m = _best_by_flow(attr_candidates, incoming_flow)

        prod_node_lon, prod_node_lat = node_positions[prod_node_id]
        attr_node_lon, attr_node_lat = node_positions[attr_node_id]
        zone_node_id = str(gid)
        zone_id = str(zone.get("zoneId") or "")
        prod_length = round(prod_dist_m, 1)
        attr_length = round(attr_dist_m, 1)
        prod_fid = fid
        attr_fid = fid + 1

        geom_prod = _straight_line(zone_lon, zone_lat, prod_node_lon, prod_node_lat)
        geom_attr = _straight_line(attr_node_lon, attr_node_lat, zone_lon, zone_lat)

        if production > 0.0:
            records.append(
                {
                    "type": "Feature",
                    "geometry": geom_prod,
                    "properties": {
                        "feedlinkId": prod_fid,
                        "reverseLinkIds": [attr_fid],
                        "zoneId": zone_id,
                        "fromNode": zone_node_id,
                        "toNode": prod_node_id,
                        "length": prod_length,
                        "capacity": production,
                        "mode": mode,
                        "ringIndex": -1,
                        "ringLabel": "",
                        "sectorIndex": -1,
                        "type": "feedlink",
                        "source": "fallback",
                    },
                }
            )
        if attraction > 0.0:
            records.append(
                {
                    "type": "Feature",
                    "geometry": geom_attr,
                    "properties": {
                        "feedlinkId": attr_fid,
                        "reverseLinkIds": [prod_fid],
                        "zoneId": zone_id,
                        "fromNode": attr_node_id,
                        "toNode": zone_node_id,
                        "length": attr_length,
                        "capacity": attraction,
                        "mode": mode,
                        "ringIndex": -1,
                        "ringLabel": "",
                        "sectorIndex": -1,
                        "type": "feedlink",
                        "source": "fallback",
                    },
                }
            )
        if production == 0.0 and attraction == 0.0:
            # Zero-demand zone: still emit a connectivity-only feedlink (capacity 0)
            # so the zone remains reachable in the routed network.
            records.append(
                {
                    "type": "Feature",
                    "geometry": geom_prod,
                    "properties": {
                        "feedlinkId": prod_fid,
                        "reverseLinkIds": [],
                        "zoneId": zone_id,
                        "fromNode": zone_node_id,
                        "toNode": prod_node_id,
                        "length": prod_length,
                        "capacity": 0.0,
                        "mode": mode,
                        "ringIndex": -1,
                        "ringLabel": "",
                        "sectorIndex": -1,
                        "type": "feedlink",
                        "source": "fallback-connectivity",
                    },
                }
            )

        logger.debug(
            "Fallback feedlink gid=%d → prod node %s (%.1f m), attr node %s (%.1f m)",
            gid,
            prod_node_id,
            prod_dist_m,
            attr_node_id,
            attr_dist_m,
        )
        fid += 2

    logger.info("Built %d feedlinks for mode %s", len(records), mode)
    return {
        "type": "FeatureCollection",
        "features": records,
        "properties": {"fields": list(FEEDLINK_PROPERTIES)},
    }
