"""Local runner for bottleneck_detector.

Reads a NETWORK parquet (and optionally FEEDLINK / ZONE parquet) from an
input folder, runs structural bottleneck (bridge) detection, and writes a
BOTTLENECK parquet to the output folder.

File naming convention (consistent with other modules):
    Input  : {input_folder}/{areaId}-NETWORK-{mode}.parquet
    Input  : {input_folder}/{areaId}-FEEDLINK-{mode}.parquet   (optional)
    Input  : {input_folder}/{areaId}-ZONE-{mode}.parquet       (optional)
    Output : {output_folder}/{areaId}-BOTTLENECK-{mode}.parquet

Usage
-----
    python -m bottleneck_detector.bottleneck_detector_runner \\
        --area-id deventer-centrum \\
        --mode CAR \\
        --input-folder output/deventer-centrum \\
        --output-folder output/deventer-centrum
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


def _resolve_uri(folder: str, filename: str) -> str:
    """Join a folder URI and a filename, supporting both s3:// and local paths."""
    if folder.startswith("s3://"):
        return folder.rstrip("/") + "/" + filename
    return str(Path(folder) / filename)


def _try_read_fc(uri: str, label: str) -> dict | None:
    from gmt_shared.geoparquet import from_geoparquet

    try:
        data = _read_uri(uri)
    except FileNotFoundError:
        print(f"{label} not found, skipping: {uri}")
        return None
    return from_geoparquet(data)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Bottleneck detection: finds structural bridge links in a network "
            "(removing them would disconnect part of the graph)."
        )
    )
    parser.add_argument("--area-id", required=True, metavar="ID", help="Area identifier.")
    parser.add_argument("--mode", required=True, metavar="MODE", help="Transport mode, e.g. CAR.")
    parser.add_argument(
        "--input-folder",
        required=True,
        metavar="URI",
        help="Folder containing the NETWORK (and optional FEEDLINK/ZONE) files.",
    )
    parser.add_argument(
        "--output-folder",
        default=None,
        metavar="URI",
        help="Output folder URI. Defaults to --input-folder.",
    )
    parser.add_argument(
        "--network-file",
        default=None,
        metavar="URI",
        help="Override the NETWORK file URI directly.",
    )
    parser.add_argument(
        "--feedlinks-file",
        default=None,
        metavar="URI",
        help="Override the FEEDLINK file URI directly (optional).",
    )
    parser.add_argument(
        "--zones-file",
        default=None,
        metavar="URI",
        help="Override the ZONE file URI directly (optional).",
    )
    parser.add_argument(
        "--output-file",
        default=None,
        metavar="URI",
        help="Override the output file URI directly.",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for AWS credentials.")
    args = parser.parse_args()

    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_routing.bottleneck_detector.core.bottleneck_detector_core import detect_bottlenecks

    output_folder = args.output_folder or args.input_folder

    network_uri = args.network_file or _resolve_uri(
        args.input_folder, f"{args.area_id}-NETWORK-{args.mode}.parquet"
    )
    feedlinks_uri = args.feedlinks_file or _resolve_uri(
        args.input_folder, f"{args.area_id}-FEEDLINK-{args.mode}.parquet"
    )
    zones_uri = args.zones_file or _resolve_uri(
        args.input_folder, f"{args.area_id}-ZONE-{args.mode}.parquet"
    )
    output_uri = args.output_file or _resolve_uri(
        output_folder, f"{args.area_id}-BOTTLENECK-{args.mode}.parquet"
    )

    print(f"Reading network   : {network_uri}")
    network_fc: dict = from_geoparquet(_read_uri(network_uri))
    print(f"Network links     : {len(network_fc.get('features') or [])}")

    feedlinks_fc = _try_read_fc(feedlinks_uri, "Feedlinks")
    zones_fc = _try_read_fc(zones_uri, "Zones")

    result_fc = detect_bottlenecks(network_fc, feedlinks_fc, zones_fc)

    n_out = len(result_fc.get("features") or [])
    print(f"Bottlenecks found : {n_out}")
    print(f"Writing output    : {output_uri}")

    _write_uri(output_uri, to_geoparquet(result_fc))
    print("Done.")


if __name__ == "__main__":
    main()
