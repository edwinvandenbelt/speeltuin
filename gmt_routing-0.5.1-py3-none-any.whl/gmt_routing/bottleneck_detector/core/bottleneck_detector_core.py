"""Pure-Python bottleneck (structural bridge) detection core — no I/O, no boto3.

Detects links whose removal would disconnect part of the network -- the
graph-theoretic definition of a "bridge" (e.g. a river crossing with no
parallel alternative).  The directed network adjacency (same shape as
``route_explorer_core.Adjacency`` / ``od_support_matrices_creator_core.build_graph``'s
output) is projected onto an undirected multigraph -- a dual carriageway
(two antiparallel directed links) collapses to a single undirected edge --
and Tarjan's bridge-finding algorithm is run on that projection, iteratively
(not recursively) to avoid Python's recursion limit on large networks.

An undirected bridge is a *sufficient* condition for a genuine connectivity
cut: if removing edge ``{u, v}`` disconnects the undirected graph, no walk of
any kind -- and therefore no directed path either -- can cross between the
two resulting components.  This is a correctness guarantee for the common
real-world case (a literal physical chokepoint, represented as one one-way
link or a pair of antiparallel links).

Known limitation: a one-way-only bottleneck whose reverse direction has an
alternate return route is a *directed* cut but not an *undirected* one, and
is therefore **not** detected by this method.  This is an accepted v1 scope
boundary; a future enhancement could add an SCC-condensation-based
"directed strong bridges" algorithm for that case.

Public API
----------
detect_bottlenecks(network_fc, feedlinks_fc=None, zones_fc=None)
    Returns a GeoJSON FeatureCollection, one feature per detected bottleneck.
bottleneck_edge_set(bottleneck_fc)
    Flattens a ``detect_bottlenecks()`` output into the
    ``{(fromNode, toNode), ...}`` shape consumed by
    ``route_explorer_core``'s ``bottleneck_edges`` parameter.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# Directed adjacency: {node: [(neighbour, time_s, dist_m, remaining_cap, cap_total), ...]}.
# Defined locally (not imported from route_explorer_core) to avoid a dependency
# from this lower-level module into route_explorer -- mirrors the same choice
# already made by od_support_matrices_creator_core.
Adjacency = dict[str, list[tuple[str, float, float, float, float]]]

BOTTLENECK_PROPERTIES: tuple[str, ...] = (
    "linkId",
    "linkIds",
    "fromNode",
    "toNode",
    "directedEdges",
    "componentSizeA",
    "componentSizeB",
    "cutOffZonePairCount",
    "cutOffZonePairs",
    "estimatedTripsAtRisk",
)


# ---------------------------------------------------------------------------
# Undirected projection + iterative Tarjan bridge-finding
# ---------------------------------------------------------------------------


def _build_undirected_adjacency(
    adj: Adjacency,
) -> tuple[
    dict[str, list[tuple[str, int]]],
    dict[int, tuple[str, str]],
    dict[int, list[tuple[str, str]]],
]:
    """Collapse a directed ``Adjacency`` into an undirected multigraph.

    Each unordered node pair gets exactly one ``edge_id``, regardless of how
    many directed edges connect them -- a divided dual carriageway (two
    antiparallel directed links) collapses to one undirected edge, tagged
    with both of its directed counterparts.

    Returns
    -------
    undirected_adj:
        ``{node: [(neighbour, edge_id), ...]}``.
    edge_id_to_pair:
        ``{edge_id: (node_a, node_b)}`` -- one arbitrary but stable
        orientation per undirected edge.
    edge_id_to_directed:
        ``{edge_id: [(fromNode, toNode), ...]}`` -- the 1 or 2 directed edges
        this undirected edge represents.
    """
    undirected_adj: dict[str, list[tuple[str, int]]] = {}
    edge_id_to_pair: dict[int, tuple[str, str]] = {}
    edge_id_to_directed: dict[int, list[tuple[str, str]]] = {}
    pair_to_edge_id: dict[frozenset[str], int] = {}
    next_edge_id = 0

    for u, neighbours in adj.items():
        for entry in neighbours:
            v = entry[0]
            if u == v:
                continue  # self-loops have no bridge semantics
            key = frozenset((u, v))
            edge_id = pair_to_edge_id.get(key)
            if edge_id is None:
                edge_id = next_edge_id
                next_edge_id += 1
                pair_to_edge_id[key] = edge_id
                edge_id_to_pair[edge_id] = (u, v)
                edge_id_to_directed[edge_id] = []
                undirected_adj.setdefault(u, []).append((v, edge_id))
                undirected_adj.setdefault(v, []).append((u, edge_id))
            edge_id_to_directed[edge_id].append((u, v))

    return undirected_adj, edge_id_to_pair, edge_id_to_directed


def _find_undirected_bridges(undirected_adj: dict[str, list[tuple[str, int]]]) -> list[int]:
    """Return the list of bridge ``edge_id``s via an iterative Tarjan low-link DFS.

    Non-recursive: uses an explicit stack of
    ``[node, parent_edge_id, neighbour_iterator]`` frames so large/path-like
    networks don't hit Python's recursion limit.
    """
    disc: dict[str, int] = {}
    low: dict[str, int] = {}
    bridges: list[int] = []
    timer = 0

    for start in undirected_adj:
        if start in disc:
            continue

        stack: list[list] = [[start, -1, iter(undirected_adj.get(start, []))]]
        disc[start] = low[start] = timer
        timer += 1

        while stack:
            node, parent_edge_id, children = stack[-1]
            descended = False
            for nbr, edge_id in children:
                if edge_id == parent_edge_id:
                    continue
                if nbr in disc:
                    low[node] = min(low[node], disc[nbr])
                else:
                    disc[nbr] = low[nbr] = timer
                    timer += 1
                    stack.append([nbr, edge_id, iter(undirected_adj.get(nbr, []))])
                    descended = True
                    break
            if not descended:
                stack.pop()
                if stack:
                    parent_node = stack[-1][0]
                    low[parent_node] = min(low[parent_node], low[node])
                    if low[node] > disc[parent_node]:
                        bridges.append(parent_edge_id)

    return bridges


def _component_sizes_after_removal(
    undirected_adj: dict[str, list[tuple[str, int]]],
    removed_edge_id: int,
    node_a: str,
    node_b: str,
) -> tuple[set[str], set[str]]:
    """Return ``(side containing node_a, side containing node_b)`` with *removed_edge_id* excluded."""

    def _bfs(start: str) -> set[str]:
        seen = {start}
        queue = [start]
        while queue:
            cur = queue.pop()
            for nbr, edge_id in undirected_adj.get(cur, []):
                if edge_id == removed_edge_id or nbr in seen:
                    continue
                seen.add(nbr)
                queue.append(nbr)
        return seen

    return _bfs(node_a), _bfs(node_b)


def find_bridge_edges(adj: Adjacency) -> list[dict]:
    """Detect structural bridges in a directed network adjacency.

    Returns
    -------
    list[dict]
        One dict per bridge:
        ``{"directed_edges": [(fromNode, toNode), ...], "side_a_nodes": frozenset[str],
        "side_b_nodes": frozenset[str]}``.  ``directed_edges`` has 1 entry for a
        one-way link, 2 for a dual-carriageway pair.
    """
    undirected_adj, edge_id_to_pair, edge_id_to_directed = _build_undirected_adjacency(adj)
    bridge_edge_ids = _find_undirected_bridges(undirected_adj)

    bridges: list[dict] = []
    for edge_id in bridge_edge_ids:
        node_a, node_b = edge_id_to_pair[edge_id]
        side_a_nodes, side_b_nodes = _component_sizes_after_removal(
            undirected_adj, edge_id, node_a, node_b
        )
        bridges.append(
            {
                "directed_edges": list(edge_id_to_directed[edge_id]),
                "side_a_nodes": frozenset(side_a_nodes),
                "side_b_nodes": frozenset(side_b_nodes),
            }
        )
    return bridges


# ---------------------------------------------------------------------------
# Zone-impact assessment
# ---------------------------------------------------------------------------


def _zone_side_membership(zone_node_ids: dict[str, str], side_nodes: frozenset[str]) -> set[str]:
    """Zone IDs whose virtual feedlink node falls on the given side."""
    return {zone_id for zone_id, vnode in zone_node_ids.items() if vnode in side_nodes}


def assess_bottleneck_impact(
    bridges: list[dict],
    zone_node_ids: dict[str, str],
    zone_productions: dict[str, float] | None = None,
    zone_attractions: dict[str, float] | None = None,
    max_pairs_reported: int = 50,
) -> list[dict]:
    """Enrich each bridge dict with the O-D zone pairs it would cut off.

    Parameters
    ----------
    bridges:
        Output of :func:`find_bridge_edges`.
    zone_node_ids:
        ``{zoneId: virtual_node_id}`` mapping, e.g. from
        ``od_support_matrices_creator_core.build_graph``.
    zone_productions, zone_attractions:
        Optional ``{zoneId: value}`` maps.  When both are supplied,
        ``estimated_trips_at_risk`` is computed as
        ``sum(production[a] * attraction[b])`` over every cut-off ``(a, b)``
        pair (both directions).  Left at ``0.0`` when omitted.
    max_pairs_reported:
        Caps the number of zone pairs listed per bridge (the count is never
        capped, only the listed examples).

    Returns
    -------
    list[dict]
        Each input bridge dict, plus ``cut_off_zone_pair_count``,
        ``cut_off_zone_pairs`` (list of ``(fromZoneId, toZoneId)``, capped),
        and ``estimated_trips_at_risk``.
    """
    enriched: list[dict] = []
    for bridge in bridges:
        zones_a = _zone_side_membership(zone_node_ids, bridge["side_a_nodes"])
        zones_b = _zone_side_membership(zone_node_ids, bridge["side_b_nodes"])

        cut_off_pairs: list[tuple[str, str]] = []
        for za in sorted(zones_a):
            for zb in sorted(zones_b):
                cut_off_pairs.append((za, zb))
                cut_off_pairs.append((zb, za))

        trips_at_risk = 0.0
        if zone_productions is not None and zone_attractions is not None:
            for za in zones_a:
                for zb in zones_b:
                    trips_at_risk += zone_productions.get(za, 0.0) * zone_attractions.get(zb, 0.0)
                    trips_at_risk += zone_productions.get(zb, 0.0) * zone_attractions.get(za, 0.0)

        enriched.append(
            {
                **bridge,
                "cut_off_zone_pair_count": len(cut_off_pairs),
                "cut_off_zone_pairs": cut_off_pairs[:max_pairs_reported],
                "estimated_trips_at_risk": round(trips_at_risk, 4),
            }
        )
    return enriched


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def detect_bottlenecks(
    network_fc: dict,
    feedlinks_fc: dict | None = None,
    zones_fc: dict | None = None,
) -> dict:
    """Detect structural bottleneck (bridge) links in a network.

    Builds the directed adjacency via
    ``od_support_matrices_creator_core.build_graph`` (the same dependency
    ``route_explorer_core`` already takes), finds undirected bridges, and --
    when *zones_fc* is supplied -- enriches each bottleneck with the O-D zone
    pairs it would cut off and an estimated trips-at-risk figure.

    Only bridges whose directed edge(s) are all real network links (not
    feedlink/zone-attachment edges) are reported -- a zone's sole feedlink
    is technically also a graph-theoretic bridge, but it isn't a road a
    scenario could close, so it is out of scope for this module.

    Parameters
    ----------
    network_fc:
        Directed network GeoJSON FeatureCollection.
    feedlinks_fc:
        Optional feedlinks GeoJSON FeatureCollection, needed to resolve zone
        virtual nodes for the impact assessment.  Bottleneck detection itself
        still works without it (zone impact fields will simply be empty).
    zones_fc:
        Optional zones GeoJSON FeatureCollection (``production``/``attraction``
        properties), used for ``estimatedTripsAtRisk``.

    Returns
    -------
    dict
        GeoJSON FeatureCollection, one feature per bottleneck.  Geometry is
        the underlying link's LineString, or a MultiLineString when the
        bridge is a dual-carriageway pair.  See :data:`BOTTLENECK_PROPERTIES`
        for the properties written on each feature.
    """
    from gmt_routing.od_support_matrices_creator.core.od_support_matrices_creator_core import (
        build_graph,
    )

    adj, zone_node_ids, _zone_centroids = build_graph(network_fc, feedlinks_fc or {})
    bridges = find_bridge_edges(adj)

    zone_productions: dict[str, float] | None = None
    zone_attractions: dict[str, float] | None = None
    if zones_fc is not None:
        zone_productions = {}
        zone_attractions = {}
        for feat in zones_fc.get("features") or []:
            props = feat.get("properties") or {}
            zid = str(props.get("zoneId") or "")
            if zid:
                zone_productions[zid] = float(props.get("production") or 0.0)
                zone_attractions[zid] = float(props.get("attraction") or 0.0)

    enriched = assess_bottleneck_impact(bridges, zone_node_ids, zone_productions, zone_attractions)

    link_index: dict[tuple[str, str], dict] = {}
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        fn = str(props.get("fromNode") or "")
        tn = str(props.get("toNode") or "")
        if fn and tn:
            link_index[(fn, tn)] = feat

    features: list[dict] = []
    for bridge in enriched:
        directed_edges: list[tuple[str, str]] = bridge["directed_edges"]
        net_feats = [link_index[e] for e in directed_edges if e in link_index]
        if len(net_feats) != len(directed_edges):
            # At least one side is a feedlink/zone-attachment edge, not a
            # real network link -- out of scope for this module (see
            # docstring); skip rather than report a half-resolved bottleneck.
            continue

        link_ids = [str((f.get("properties") or {}).get("linkId") or "") for f in net_feats]
        if len(net_feats) == 1:
            geometry = net_feats[0].get("geometry")
        else:
            geometry = {
                "type": "MultiLineString",
                "coordinates": [f.get("geometry", {}).get("coordinates") for f in net_feats],
            }

        from_node, to_node = directed_edges[0]
        features.append(
            {
                "type": "Feature",
                "geometry": geometry,
                "properties": {
                    "linkId": link_ids[0] if len(link_ids) == 1 else None,
                    "linkIds": link_ids if len(link_ids) > 1 else None,
                    "fromNode": from_node,
                    "toNode": to_node,
                    "directedEdges": [list(e) for e in directed_edges],
                    "componentSizeA": len(bridge["side_a_nodes"]),
                    "componentSizeB": len(bridge["side_b_nodes"]),
                    "cutOffZonePairCount": bridge["cut_off_zone_pair_count"],
                    "cutOffZonePairs": [
                        {"fromZoneId": a, "toZoneId": b} for a, b in bridge["cut_off_zone_pairs"]
                    ],
                    "estimatedTripsAtRisk": bridge["estimated_trips_at_risk"],
                },
            }
        )

    logger.info("detect_bottlenecks: %d structural bottleneck(s) found", len(features))

    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"fields": list(BOTTLENECK_PROPERTIES)},
    }


def bottleneck_edge_set(bottleneck_fc: dict) -> set[tuple[str, str]]:
    """Flatten a :func:`detect_bottlenecks` output into a set of directed edges.

    Adapter for ``route_explorer_core``'s ``bottleneck_edges`` parameter
    (``_yen_k_shortest`` / ``build_od_matrix`` / ``recompute_routes_for_pairs``).
    """
    edges: set[tuple[str, str]] = set()
    for feat in bottleneck_fc.get("features") or []:
        props = feat.get("properties") or {}
        for pair in props.get("directedEdges") or []:
            if len(pair) == 2 and pair[0] and pair[1]:
                edges.add((str(pair[0]), str(pair[1])))
    return edges
