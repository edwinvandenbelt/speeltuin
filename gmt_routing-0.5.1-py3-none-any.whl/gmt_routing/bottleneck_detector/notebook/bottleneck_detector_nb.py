# Databricks notebook source
# ---------------------------------------------------------------------------
# bottleneck_detector_nb.py — Databricks notebook interface for bottleneck detection.
#
# This notebook:
#   1. Reads widget parameters (area_id, mode, input_folder, output_folder).
#   2. Reads {area_id}-NETWORK-{mode}.geojson, and optionally
#      {area_id}-FEEDLINK-{mode}.geojson / {area_id}-ZONE-{mode}.geojson,
#      from input_folder (s3:// or local).
#   3. Calls detect_bottlenecks() — no Spark I/O.
#   4. Writes {area_id}-BOTTLENECK-{mode}.geojson to output_folder.
#
# Requirements (Databricks cluster):
#   pip install boto3
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("bottleneck_detector_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text("area_id", "", "Area ID (e.g. deventer-centrum)")
dbutils.widgets.text("mode", "CAR", "Transport mode (CAR / BIKE / …)")
dbutils.widgets.text("input_folder", "", "Input folder URI (s3://bucket/prefix or local path)")
dbutils.widgets.text("output_folder", "", "Output folder URI (leave empty to use input_folder)")
dbutils.widgets.text("LOG_LEVEL", "INFO", "Log level (DEBUG / INFO / WARNING / ERROR)")

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_routing.bottleneck_detector.core.bottleneck_detector_core import detect_bottlenecks

# COMMAND ----------
# Widget read + validation
AREA_ID = dbutils.widgets.get("area_id").strip()
MODE = dbutils.widgets.get("mode").strip().upper()
INPUT_FOLDER = dbutils.widgets.get("input_folder").strip()
OUTPUT_FOLDER = dbutils.widgets.get("output_folder").strip() or INPUT_FOLDER

for _name, _val in [
    ("area_id", AREA_ID),
    ("mode", MODE),
    ("input_folder", INPUT_FOLDER),
]:
    if not _val:
        raise ValueError(f"Widget '{_name}' is required but was not filled in.")

logger.info(
    "area_id=%s  mode=%s  input_folder=%s  output_folder=%s",
    AREA_ID,
    MODE,
    INPUT_FOLDER,
    OUTPUT_FOLDER,
)

# COMMAND ----------
# S3 / local I/O helpers
import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read  s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _try_read_uri(uri: str, label: str) -> bytes | None:
    try:
        return _read_uri(uri)
    except Exception:
        logger.info("%s not found, skipping: %s", label, uri)
        return None


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


def _resolve(folder: str, filename: str) -> str:
    if folder.startswith("s3://"):
        return folder.rstrip("/") + "/" + filename
    import pathlib

    return str(pathlib.Path(folder) / filename)


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Bottleneck Detection
# MAGIC Adjust widget values above, then **re-run from this cell**.

# COMMAND ----------
_t_start = datetime.now(timezone.utc)

_network_uri = _resolve(INPUT_FOLDER, f"{AREA_ID}-NETWORK-{MODE}.geojson")
_feedlinks_uri = _resolve(INPUT_FOLDER, f"{AREA_ID}-FEEDLINK-{MODE}.geojson")
_zones_uri = _resolve(INPUT_FOLDER, f"{AREA_ID}-ZONE-{MODE}.geojson")
_output_uri = _resolve(OUTPUT_FOLDER, f"{AREA_ID}-BOTTLENECK-{MODE}.geojson")

logger.info("network_uri=%s", _network_uri)
logger.info("feedlinks_uri=%s", _feedlinks_uri)
logger.info("zones_uri=%s", _zones_uri)
logger.info("output_uri=%s", _output_uri)

# COMMAND ----------
_network_fc = json.loads(_read_uri(_network_uri))

_feedlinks_raw = _try_read_uri(_feedlinks_uri, "Feedlinks")
_feedlinks_fc = json.loads(_feedlinks_raw) if _feedlinks_raw is not None else None

_zones_raw = _try_read_uri(_zones_uri, "Zones")
_zones_fc = json.loads(_zones_raw) if _zones_raw is not None else None

logger.info("Network links: %d", len(_network_fc.get("features") or []))

# COMMAND ----------
_result_fc = detect_bottlenecks(_network_fc, _feedlinks_fc, _zones_fc)

_n_out = len(_result_fc.get("features") or [])
logger.info("Bottleneck detection output: %d feature(s)", _n_out)

# COMMAND ----------
_payload = json.dumps(_result_fc, ensure_ascii=False).encode("utf-8")
_write_uri(_output_uri, _payload)

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# Results summary
_SEP = "─" * 60
print(_SEP)
print(f"Bottleneck detection complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Area ID          : {AREA_ID}")
print(f"  Mode             : {MODE}")
print(f"  Bottlenecks found: {_n_out}")
print(f"  Output URI       : {_output_uri}")
print(_SEP)
