# Databricks notebook source
# ---------------------------------------------------------------------------
# link_based_staq_assigner_nb.py — Databricks notebook for link-based STAQ assigner.
#
# This notebook:
#   1. Reads widget parameters (network_uri, centroid_uri, demand_matrix_uri,
#      output_uri, and algorithm configuration).
#   2. Reads the three input files (s3:// or local path).
#   3. Runs the STAQ assignment (pure core, no Spark).
#   4. Writes the enriched output GeoJSON to the specified URI.
#   5. Prints a summary of the assignment results.
#
# No Databricks SQL dependency — operates on pre-computed GeoJSON/CSV files only.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s - %(message)s")
logger = logging.getLogger("link_based_staq_assigner_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "network_uri",
    "",
    "Full URI of the network GeoJSON file (s3:// or local path)",
)
dbutils.widgets.text(
    "centroid_uri",
    "",
    "Full URI of the centroids GeoJSON file (s3:// or local path)",
)
dbutils.widgets.text(
    "demand_matrix_uri",
    "",
    "Full URI of the demand matrix CSV file (s3:// or local path)",
)
dbutils.widgets.text(
    "output_folder",
    "",
    "Output folder: s3://bucket/prefix  or  /dbfs/path (required)",
)
dbutils.widgets.text(
    "value_of_distance_per_km",
    "0.10",
    "Value of distance per kilometre (euros/km)",
)
dbutils.widgets.text(
    "value_of_time_per_hour",
    "10.0",
    "Value of time per hour (euros/h)",
)
dbutils.widgets.text(
    "duration_hours",
    "1.0",
    "Modelling period length in hours",
)
dbutils.widgets.text(
    "fundamental_diagram_type",
    "Newell",
    "Fundamental diagram type: Newell | QuadraticLinear",
)
dbutils.widgets.text(
    "epsilon",
    "0.001",
    "RDG convergence threshold",
)
dbutils.widgets.text(
    "max_iterations",
    "100",
    "Maximum outer STAQ iterations",
)
dbutils.widgets.text(
    "fixed_point_epsilon",
    "0.0001",
    "Fixed-point solver convergence threshold",
)
dbutils.widgets.text(
    "fixed_point_max_iterations",
    "10",
    "Fixed-point solver maximum iterations",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_routing.link_based_staq_assigner.core.link_based_staq_assigner_core import run_assignment

# COMMAND ----------
# Widget read + validation

NETWORK_URI = dbutils.widgets.get("network_uri").strip()
CENTROID_URI = dbutils.widgets.get("centroid_uri").strip()
DEMAND_MATRIX_URI = dbutils.widgets.get("demand_matrix_uri").strip()
OUT_FOLDER = dbutils.widgets.get("output_folder").strip()

VOD = float(dbutils.widgets.get("value_of_distance_per_km").strip())
VOT = float(dbutils.widgets.get("value_of_time_per_hour").strip())
DURATION_HOURS = float(dbutils.widgets.get("duration_hours").strip())
FD_TYPE = dbutils.widgets.get("fundamental_diagram_type").strip()
EPSILON = float(dbutils.widgets.get("epsilon").strip())
MAX_ITERATIONS = int(dbutils.widgets.get("max_iterations").strip())
FP_EPSILON = float(dbutils.widgets.get("fixed_point_epsilon").strip())
FP_MAX_ITER = int(dbutils.widgets.get("fixed_point_max_iterations").strip())

for _param_name, _param_val in [
    ("network_uri", NETWORK_URI),
    ("centroid_uri", CENTROID_URI),
    ("demand_matrix_uri", DEMAND_MATRIX_URI),
    ("output_folder", OUT_FOLDER),
]:
    if not _param_val:
        raise ValueError(f"Widget '{_param_name}' is required but was left empty.")

logger.info(
    "network_uri=%s centroid_uri=%s demand_matrix_uri=%s output_folder=%s",
    NETWORK_URI,
    CENTROID_URI,
    DEMAND_MATRIX_URI,
    OUT_FOLDER,
)

# COMMAND ----------
# S3 / local I/O helpers

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType=content_type,
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run STAQ Assignment
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# Main execution

_t_start = datetime.now(timezone.utc)

print(f"Starting             : {_t_start.isoformat()}")
print(f"Network URI          : {NETWORK_URI}")
print(f"Centroid URI         : {CENTROID_URI}")
print(f"Demand Matrix URI    : {DEMAND_MATRIX_URI}")
print(f"Output Folder        : {OUT_FOLDER}")
print(f"VoD                  : {VOD} euros/km")
print(f"VoT                  : {VOT} euros/h")
print(f"Duration             : {DURATION_HOURS} h")
print(f"FD type              : {FD_TYPE}")
print(f"Epsilon              : {EPSILON}")
print(f"Max iterations       : {MAX_ITERATIONS}")
print(f"FP epsilon           : {FP_EPSILON}")
print(f"FP max iterations    : {FP_MAX_ITER}")
print()

logger.info("Reading input files ...")
_network_geojson = json.loads(_read_uri(NETWORK_URI))
_centroids_geojson = json.loads(_read_uri(CENTROID_URI))
_matrix_csv_text = _read_uri(DEMAND_MATRIX_URI).decode("utf-8")

# Read AREA_ID from network properties
AREA_ID = (_network_geojson.get("properties") or {}).get("area_id") or ""
if not AREA_ID:
    from uuid import uuid4

    AREA_ID = str(uuid4())
    logger.warning("Network has no 'area_id' property — using generated ID: %s", AREA_ID)
print(f"Area ID              : {AREA_ID}")

logger.info("Running STAQ assignment ...")
_output_geojson, _stats = run_assignment(
    network_geojson=_network_geojson,
    centroids_geojson=_centroids_geojson,
    matrix_csv_text=_matrix_csv_text,
    value_of_distance_per_km=VOD,
    value_of_time_per_hour=VOT,
    duration_hours=DURATION_HOURS,
    fundamental_diagram_type=FD_TYPE,
    epsilon=EPSILON,
    max_iterations=MAX_ITERATIONS,
    fixed_point_epsilon=FP_EPSILON,
    fixed_point_max_iterations=FP_MAX_ITER,
)

logger.info("Writing output ...")
_output_filename = f"{AREA_ID}-ASSIGNED-NETWORK.geojson"
_output_bytes = json.dumps(_output_geojson, ensure_ascii=False).encode("utf-8")
_out_folder = OUT_FOLDER.rstrip("/")
if _out_folder.startswith("s3://"):
    _bucket, _key_prefix = _out_folder[5:].split("/", 1)
    _key = f"{_key_prefix}/{_output_filename}".lstrip("/")
    _write_uri(f"s3://{_bucket}/{_key}", _output_bytes, "application/geo+json")
    OUTPUT_PATH = f"s3://{_bucket}/{_key}"
else:
    import os as _os

    _os.makedirs(_out_folder, exist_ok=True)
    OUTPUT_PATH = _os.path.join(_out_folder, _output_filename)
    _write_uri(OUTPUT_PATH, _output_bytes, "application/geo+json")

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# Results summary

_SEP = "-" * 60

print(_SEP)
print(f"STAQ assignment complete - {_total_elapsed:.1f}s total")
print(_SEP)
print(f"  Links       : {_stats['nLinks']}")
print(f"  Centroids   : {_stats['nCentroids']}")
print(f"  Iterations  : {_stats['iterations']}")
print(f"  RDG         : {_stats['rdg']:.6f}")
print(f"  Area ID     : {AREA_ID}")
print(f"  Output      : {OUTPUT_PATH}")
print(_SEP)
