"""Local debug runner for link_based_staq_assigner.

Calls link_based_staq_assigner_core functions directly — no Lambda handler involved.

Usage
-----
    python -m link_based_staq_assigner.link_based_staq_assigner_runner \\
        --network-file /tmp/network.parquet \\
        --feedlink-file /tmp/feedlinks.parquet \\
        --od-matrix-file /tmp/od-completed.parquet \\
        --output-file /tmp/assignment.parquet \\
        --value-of-distance-per-km 0.10 \\
        --value-of-time-per-hour 10.0 \\
        --duration-hours 1.0

    # S3 inputs and outputs:
    python -m link_based_staq_assigner.link_based_staq_assigner_runner \\
        --network-file s3://gmp-networks/network/deventer-NETWORK-CAR.parquet \\
        --feedlink-file s3://gmp-networks/network/deventer-FEEDLINK-CAR.parquet \\
        --od-matrix-file s3://gmp-networks/matrix/deventer-OD-COMPLETED.parquet \\
        --output-file s3://gmp-networks/assignment/deventer-ASSIGNMENT-CAR.parquet \\
        --value-of-distance-per-km 0.10 \\
        --value-of-time-per-hour 10.0 \\
        --duration-hours 1.0

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for link_based_staq_assigner (calls core directly)."
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="Full URI of the network GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--feedlink-file",
        required=True,
        metavar="URI",
        help="Full URI of the feedlinks GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--od-matrix-file",
        required=True,
        metavar="URI",
        help="Full URI of the completed OD matrix GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder URI (s3://bucket/prefix/ or local dir). File named {area_id}-ASSIGNED-NETWORK.geojson.",
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help=(
            "Override the area_id used in the output filename. "
            "Defaults to the area_id from the network GeoJSON properties, "
            "or is derived from the input filename."
        ),
    )
    parser.add_argument(
        "--value-of-distance-per-km",
        required=True,
        type=float,
        metavar="FLOAT",
        help="Value of distance per kilometre (euros/km).",
    )
    parser.add_argument(
        "--value-of-time-per-hour",
        required=True,
        type=float,
        metavar="FLOAT",
        help="Value of time per hour (euros/h).",
    )
    parser.add_argument(
        "--duration-hours",
        required=True,
        type=float,
        metavar="FLOAT",
        help="Modelling period length in hours.",
    )
    parser.add_argument(
        "--fundamental-diagram-type",
        default="Newell",
        metavar="STRING",
        help="Newell | QuadraticLinear (default: Newell).",
    )
    parser.add_argument(
        "--epsilon",
        default=0.001,
        type=float,
        metavar="FLOAT",
        help="RDG convergence threshold (default: 0.001).",
    )
    parser.add_argument(
        "--max-iterations",
        default=100,
        type=int,
        metavar="INT",
        help="Maximum outer iterations (default: 100).",
    )
    parser.add_argument(
        "--fixed-point-epsilon",
        default=0.0001,
        type=float,
        metavar="FLOAT",
        help="Fixed-point convergence threshold (default: 0.0001).",
    )
    parser.add_argument(
        "--fixed-point-max-iterations",
        default=10,
        type=int,
        metavar="INT",
        help="Fixed-point max iterations (default: 10).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet
    from gmt_shared.output_path import build_output_path

    from gmt_routing.link_based_staq_assigner.core.link_based_staq_assigner_core import (
        run_assignment,
    )

    print(f"Reading network       : {args.network_file}")
    network_geojson = from_geoparquet(_read_uri(args.network_file))

    print(f"Reading feedlinks     : {args.feedlink_file}")
    feedlinks_geojson = from_geoparquet(_read_uri(args.feedlink_file))

    print(f"Reading OD matrix     : {args.od_matrix_file}")
    od_matrix_geojson = from_geoparquet(_read_uri(args.od_matrix_file))

    print("Running STAQ assignment ...")
    output_geojson, stats = run_assignment(
        network_geojson=network_geojson,
        feedlinks_geojson=feedlinks_geojson,
        od_matrix_geojson=od_matrix_geojson,
        value_of_distance_per_km=args.value_of_distance_per_km,
        value_of_time_per_hour=args.value_of_time_per_hour,
        duration_hours=args.duration_hours,
        fundamental_diagram_type=args.fundamental_diagram_type,
        epsilon=args.epsilon,
        max_iterations=args.max_iterations,
        fixed_point_epsilon=args.fixed_point_epsilon,
        fixed_point_max_iterations=args.fixed_point_max_iterations,
    )

    print(f"  Links      : {stats['nLinks']}")
    print(f"  Centroids  : {stats['nCentroids']}")
    print(f"  Iterations : {stats['iterations']}")
    print(f"  RDG        : {stats['rdg']:.6f}")

    area_id = args.area_id or (network_geojson.get("properties") or {}).get("area_id")
    if not area_id:
        import os as _os

        area_id = _os.path.basename(args.network_file).split("-NETWORK")[0] or "unknown"
    output_uri = build_output_path(args.output_folder, area_id, "ASSIGNED-NETWORK")

    print(f"Writing output        : {output_uri}")
    _write_uri(
        output_uri,
        to_geoparquet(output_geojson),
    )
    print("Done.")


if __name__ == "__main__":
    main()
