"""
Cost calculations, MSA, link demand/flow, RDG, and LinkResult creation
for the Link-Based STAQ algorithm.

Mirrors:
  - LinkCostCalculator.java
  - MethodOfSuccessiveAveragesApplier.java
  - LinkDemandCalculator.java / LinkFlowCalculator.java
  - RelativeDualityGapCalculator.java
  - LinkResultCreator.java
"""

from __future__ import annotations

import math

from .config import Config, FundamentalDiagramType
from .domain import Centroid, Link, LinkResult, Matrix, Network, Turn

_METERS_PER_KM = 1000.0
_RDG_LOWER_BOUND = 1e-16


# ---------------------------------------------------------------------------
# Free-flow link cost
# ---------------------------------------------------------------------------


def calc_free_flow_link_cost(link: Link, cfg: Config) -> float:
    """
    Free-flow cost = distance_cost + travel_time_cost (at free-flow speed).
    """
    length_km = link.length_m / _METERS_PER_KM
    dist_cost = length_km * cfg.value_of_distance_per_km
    time_cost = (length_km / link.speed_kmh) * cfg.value_of_time_per_hour
    return dist_cost + time_cost


# ---------------------------------------------------------------------------
# Congested link cost (used after fixed-point solve)
# ---------------------------------------------------------------------------


def calc_link_cost(
    link: Link,
    total_flow: float,
    total_demand: float,
    cfg: Config,
) -> float:
    """
    Full generalised link cost including queuing delay.

    travel_time = free_flow_branch_time + queuing_time
    cost        = travel_time * VoT + distance * VoD
    """
    length_km = link.length_m / _METERS_PER_KM

    ff_branch_speed = _free_flow_branch_speed(link, total_flow, cfg.fundamental_diagram_type)
    ff_travel_time = length_km / ff_branch_speed

    queuing_time = 0.0
    af = link.acceptance_factor
    if af < 1.0 and total_flow > 0.0:
        queuing_time = (total_demand / total_flow) * (1.0 / af - 1.0) * cfg.duration_hours / 2.0

    total_time = ff_travel_time + queuing_time
    return total_time * cfg.value_of_time_per_hour + length_km * cfg.value_of_distance_per_km


def _free_flow_branch_speed(
    link: Link,
    total_flow: float,
    fd_type: FundamentalDiagramType,
) -> float:
    v_ff = link.speed_kmh
    if fd_type == FundamentalDiagramType.NEWELL:
        return v_ff
    if fd_type == FundamentalDiagramType.QUADRATIC_LINEAR:
        if link.speed_at_cap_kmh is None:
            raise ValueError(
                f"Link {link.external_id or link.index}: "
                "speedAtCapacityInKilometersPerHour is required for QuadraticLinear."
            )
        v_cap = link.speed_at_cap_kmh
        cap = link.capacity
        if total_flow >= cap:
            return v_cap
        return 0.5 * v_ff + 0.5 * math.sqrt(
            v_ff**2 - 4.0 * total_flow * v_cap * (v_ff - v_cap) / cap
        )
    raise ValueError(f"Unsupported fundamental diagram type: {fd_type}")


# ---------------------------------------------------------------------------
# Update link costs on network
# ---------------------------------------------------------------------------


def update_free_flow_costs(network: Network, cfg: Config) -> None:
    """Compute free-flow costs and set them on every link + as generalized_cost."""
    for link in network.links:
        c = calc_free_flow_link_cost(link, cfg)
        link.free_flow_cost = c
        link.generalized_cost = c


def update_congested_costs(
    network: Network,
    cfg: Config,
    link_demands: dict[Link, float],
    link_flows: dict[Link, float],
) -> None:
    """Compute congested costs and update generalized_cost on each link."""
    for link in network.links:
        preload = link.preload or 0.0
        total_flow = link_flows.get(link, 0.0) + preload
        total_demand = link_demands.get(link, 0.0) + preload
        link.generalized_cost = calc_link_cost(link, total_flow, total_demand, cfg)


# ---------------------------------------------------------------------------
# Link demand + flow
# ---------------------------------------------------------------------------


def calc_link_demands(network: Network) -> dict[Link, float]:
    """
    Aggregate demand onto links.

    link_demand = sum over all turns whose from_link == link of
                  sum(turn.demand_per_dest.values())
    """
    demands: dict[Link, float] = dict.fromkeys(network.links, 0.0)
    for turn in network.turns.values():
        d = sum(turn.demand_per_dest.values())
        demands[turn.from_link] = demands.get(turn.from_link, 0.0) + d
    return demands


def calc_link_flows(network: Network) -> dict[Link, float]:
    """
    Aggregate accepted flows onto links.

    link_flow = sum over all turns whose to_link == link of turn.flow
    """
    flows: dict[Link, float] = dict.fromkeys(network.links, 0.0)
    for turn in network.turns.values():
        flows[turn.to_link] = flows.get(turn.to_link, 0.0) + turn.flow
    return flows


def calc_turn_demands(network: Network) -> dict[Turn, float]:
    """Total demand on each turn (sum over destinations)."""
    return {turn: sum(turn.demand_per_dest.values()) for turn in network.turns.values()}


# ---------------------------------------------------------------------------
# Method of Successive Averages (MSA)
# ---------------------------------------------------------------------------


def apply_msa(
    previous_avg: dict[Turn, dict[Centroid, float]] | None,
    current: dict[Turn, dict[Centroid, float]],
    iteration: int,
) -> dict[Turn, dict[Centroid, float]]:
    """
    Compute the new MSA average of turn demand per destination.

    step_size = 1 / iteration
    new_avg   = (1 - step_size) * prev_avg + step_size * current
    """
    assert iteration > 0
    if previous_avg is None:
        # First iteration: just return current as-is
        return {turn: dict(dest_map) for turn, dest_map in current.items()}

    step = 1.0 / iteration
    all_turns = set(current) | set(previous_avg)
    result: dict[Turn, dict[Centroid, float]] = {}

    for turn in all_turns:
        cur_map = current.get(turn, {})
        prev_map = previous_avg.get(turn, {})
        all_dests = set(cur_map) | set(prev_map)
        new_map: dict[Centroid, float] = {}
        for dest in all_dests:
            cur_d = cur_map.get(dest, 0.0)
            prev_d = prev_map.get(dest, 0.0)
            new_map[dest] = (1 - step) * prev_d + step * cur_d
        result[turn] = new_map

    return result


def store_msa_demands(
    msa_result: dict[Turn, dict[Centroid, float]],
    network: Network,
) -> None:
    """Write MSA-averaged demands back into Turn objects."""
    for turn in network.turns.values():
        turn.demand_per_dest.clear()

    for turn, dest_map in msa_result.items():
        turn.demand_per_dest.update(dest_map)


# ---------------------------------------------------------------------------
# Relative Duality Gap (RDG)
# ---------------------------------------------------------------------------


def calc_rdg(
    network: Network,
    demand_matrix: Matrix,
    link_demands: dict[Link, float],
    link_costs: dict[Link, float],
    turn_demands: dict[Turn, float],
    cost_matrix: Matrix,  # generalised costs from latest Dijkstra
) -> float:
    """
    RDG = (total_assigned_cost - total_shortest_path_cost) / total_shortest_path_cost

    total_assigned_cost = Σ link_demand[l] * link_cost[l]
                        + Σ turn_demand[t] * turn.free_flow_cost
    total_shortest_path_cost = Σ_{i,j} demand[i,j] * cost_matrix[i,j]
    """
    # Total assigned cost
    total_assigned = 0.0
    for link, demand in link_demands.items():
        cost = link_costs.get(link, link.generalized_cost)
        total_assigned += demand * cost
    for turn, demand in turn_demands.items():
        total_assigned += demand * turn.free_flow_cost

    # Total shortest path cost
    total_sp = 0.0
    for origin_c in network.centroids.values():
        oi = origin_c.zone_index_1based - 1
        for dest_c in network.centroids.values():
            di = dest_c.zone_index_1based - 1
            d = demand_matrix.get(oi, di)
            if d > 0.0:
                total_sp += d * cost_matrix.get(oi, di)

    if total_sp < _RDG_LOWER_BOUND:
        raise ValueError(
            "Total shortest path cost is (too close to) zero. "
            "Cannot compute RDG. Check that demand and link costs are nonzero."
        )

    return (total_assigned - total_sp) / total_sp


# ---------------------------------------------------------------------------
# LinkResult creator
# ---------------------------------------------------------------------------


def create_link_results(
    network: Network,
    link_demands: dict[Link, float],
    link_flows: dict[Link, float],
) -> list[LinkResult]:
    """Create output LinkResult objects for all non-virtual links."""
    results = []
    for link in network.links:
        if link.external_id is None:
            continue  # skip virtual connector links
        results.append(
            LinkResult(
                link_id=link.external_id,
                cost=link.generalized_cost,
                demand=link_demands.get(link, 0.0),
                flow=link_flows.get(link, 0.0),
                acceptance_factor=link.acceptance_factor,
            )
        )
    return results
