"""Unit tests for link_based_staq_assigner_core."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from gmt_routing.link_based_staq_assigner.core.link_based_staq_assigner_core import (
    build_output_geojson,
    parse_feedlinks_as_centroids,
    parse_feedlinks_as_links,
    parse_network_geojson,
    parse_od_matrix_geojson,
    run_assignment,
)
from gmt_routing.link_based_staq_assigner.core.staq.domain import LinkResult
from gmt_routing.link_based_staq_assigner.core.staq.network_builder import build_network

# ---------------------------------------------------------------------------
# Shared minimal fixtures (2-zone network, same as source test_smoke.py)
# ---------------------------------------------------------------------------

NETWORK_GEOJSON = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
            "properties": {
                "linkId": "AB",
                "fromNode": "A",
                "toNode": "B",
                "length": 1000.0,
                "speed": 50.0,
                "speedAtCapacityInKilometersPerHour": 30.0,
                "capacity": 1800.0,
            },
        },
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[1, 0], [0, 0]]},
            "properties": {
                "linkId": "BA",
                "fromNode": "B",
                "toNode": "A",
                "length": 1000.0,
                "speed": 50.0,
                "speedAtCapacityInKilometersPerHour": 30.0,
                "capacity": 1800.0,
            },
        },
    ],
}

# Feedlinks with virtual zone nodes "vA" and "vB" (distinct from road nodes "A" and "B").
# Each zone has a production feedlink (virtual→road) and an attraction feedlink (road→virtual).
# This ensures every A→B path is at least 3 links: FL-prod → road → FL-attr, giving ≥2 turns so
# the turn-based STAQ model can record and propagate demand correctly.
# zoneId "zone_A" < "zone_B" alphabetically, giving sorted indices 1 and 2.
FEEDLINKS_GEOJSON = {
    "type": "FeatureCollection",
    "features": [
        # Zone A — virtual centroid node "vA" wired to road node "A"
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[-0.1, 0], [0, 0]]},
            "properties": {
                "zoneId": "zone_A",
                "fromNode": "vA",
                "toNode": "A",
                "linkDirection": "production",
                "length": 100.0,
                "capacity": 3600.0,
                "feedlinkId": "FL-A-prod",
                "type": "feedlink",
            },
        },
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0, 0], [-0.1, 0]]},
            "properties": {
                "zoneId": "zone_A",
                "fromNode": "A",
                "toNode": "vA",
                "linkDirection": "attraction",
                "length": 100.0,
                "capacity": 3600.0,
                "feedlinkId": "FL-A-attr",
                "type": "feedlink",
            },
        },
        # Zone B — virtual centroid node "vB" wired to road node "B"
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[1.1, 0], [1, 0]]},
            "properties": {
                "zoneId": "zone_B",
                "fromNode": "vB",
                "toNode": "B",
                "linkDirection": "production",
                "length": 100.0,
                "capacity": 3600.0,
                "feedlinkId": "FL-B-prod",
                "type": "feedlink",
            },
        },
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[1, 0], [1.1, 0]]},
            "properties": {
                "zoneId": "zone_B",
                "fromNode": "B",
                "toNode": "vB",
                "linkDirection": "attraction",
                "length": 100.0,
                "capacity": 3600.0,
                "feedlinkId": "FL-B-attr",
                "type": "feedlink",
            },
        },
    ],
}

# 2 zones: 100 vehicles from zone_A to zone_B
OD_MATRIX_GEOJSON = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": None,
            "properties": {"fromZoneId": "zone_A", "toZoneId": "zone_B", "trips": 100.0},
        },
        {
            "type": "Feature",
            "geometry": None,
            "properties": {"fromZoneId": "zone_B", "toZoneId": "zone_A", "trips": 0.0},
        },
    ],
}

ASSIGNMENT_KWARGS = {
    "value_of_distance_per_km": 0.10,
    "value_of_time_per_hour": 10.0,
    "duration_hours": 1.0,
    "fundamental_diagram_type": "Newell",
    "epsilon": 0.001,
    "max_iterations": 10,
    "fixed_point_epsilon": 0.0001,
    "fixed_point_max_iterations": 5,
}


# ---------------------------------------------------------------------------
# parse_network_geojson
# ---------------------------------------------------------------------------


class TestParseNetworkGeojson:
    def test_element_count(self):
        elements, geometries = parse_network_geojson(NETWORK_GEOJSON)
        assert len(elements) == 2
        assert len(geometries) == 2

    def test_data_type(self):
        elements, _ = parse_network_geojson(NETWORK_GEOJSON)
        for elem in elements:
            assert elem["dataType"] == "link"

    def test_required_props_present(self):
        elements, _ = parse_network_geojson(NETWORK_GEOJSON)
        ab = next(e for e in elements if e["properties"]["id"] == "AB")
        p = ab["properties"]
        assert p["fromNodeId"] == "A"
        assert p["toNodeId"] == "B"
        assert p["lengthInMeters"] == pytest.approx(1000.0)
        assert p["speedInKilometersPerHour"] == pytest.approx(50.0)
        assert p["capacity"] == pytest.approx(1800.0)
        assert p["speedAtCapacityInKilometersPerHour"] == pytest.approx(30.0)

    def test_geometry_preserved(self):
        _, geometries = parse_network_geojson(NETWORK_GEOJSON)
        assert "AB" in geometries
        assert geometries["AB"]["type"] == "LineString"

    def test_empty_fc(self):
        elements, geometries = parse_network_geojson({"type": "FeatureCollection", "features": []})
        assert elements == []
        assert geometries == {}

    def test_reverse_link_ids_passed_through(self):
        """reverseLinkIds on a link feature must appear in the element properties."""
        fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
                    "properties": {
                        "linkId": "AB",
                        "fromNode": "A",
                        "toNode": "B",
                        "length": 500.0,
                        "speed": 50.0,
                        "capacity": 1800.0,
                        "reverseLinkIds": ["BA"],
                    },
                },
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[1, 0], [0, 0]]},
                    "properties": {
                        "linkId": "BA",
                        "fromNode": "B",
                        "toNode": "A",
                        "length": 500.0,
                        "speed": 50.0,
                        "capacity": 1800.0,
                        "reverseLinkIds": ["AB"],
                    },
                },
            ],
        }
        elements, _ = parse_network_geojson(fc)
        ab = next(e for e in elements if e["properties"]["id"] == "AB")
        ba = next(e for e in elements if e["properties"]["id"] == "BA")
        assert ab["properties"]["reverseLinkIds"] == ["BA"]
        assert ba["properties"]["reverseLinkIds"] == ["AB"]

    def test_reverse_link_ids_absent_when_not_in_source(self):
        """When the source has no reverseLinkIds the property must not appear."""
        elements, _ = parse_network_geojson(NETWORK_GEOJSON)
        for elem in elements:
            assert "reverseLinkIds" not in elem["properties"]


# ---------------------------------------------------------------------------
# build_network — opposite-link assignment via reverseLinkIds
# ---------------------------------------------------------------------------


def _link_elem(link_id, from_node, to_node, reverse_ids=None):
    props = {
        "id": link_id,
        "fromNodeId": from_node,
        "toNodeId": to_node,
        "lengthInMeters": 500.0,
        "speedInKilometersPerHour": 50.0,
        "capacity": 1800.0,
    }
    if reverse_ids is not None:
        props["reverseLinkIds"] = reverse_ids
    return {"dataType": "link", "properties": props}


def _centroid_elem(node_id, zone_index):
    return {"dataType": "centroid", "properties": {"nodeId": node_id, "zoneIndex": zone_index}}


class TestBuildNetworkOppositeLinks:
    def test_opposite_assigned_via_reverse_link_ids(self):
        """When reverseLinkIds is present, opposite_link is set by ID lookup."""
        elements = [
            _link_elem("AB", "A", "B", reverse_ids=["BA"]),
            _link_elem("BA", "B", "A", reverse_ids=["AB"]),
            _centroid_elem("A", 1),
            _centroid_elem("B", 2),
        ]
        network = build_network(elements)
        ab = next(lnk for lnk in network.links if lnk.external_id == "AB")
        ba = next(lnk for lnk in network.links if lnk.external_id == "BA")
        assert ab.opposite_link is ba
        assert ba.opposite_link is ab

    def test_opposite_assigned_via_geometric_fallback(self):
        """When reverseLinkIds is absent, geometric inference still works."""
        elements = [
            _link_elem("AB", "A", "B"),  # no reverseLinkIds
            _link_elem("BA", "B", "A"),
            _centroid_elem("A", 1),
            _centroid_elem("B", 2),
        ]
        network = build_network(elements)
        ab = next(lnk for lnk in network.links if lnk.external_id == "AB")
        ba = next(lnk for lnk in network.links if lnk.external_id == "BA")
        assert ab.opposite_link is ba
        assert ba.opposite_link is ab

    def test_reverse_link_ids_takes_priority_over_geometry(self):
        """An explicit reverseLinkIds pointing to a non-geometric opposite is respected."""
        # AB and CD share no nodes so geometry would never pair them.
        # We force AB.reverseLinkIds = ["CD"] to test that ID lookup wins.
        elements = [
            _link_elem("AB", "A", "B", reverse_ids=["CD"]),
            _link_elem("CD", "C", "D", reverse_ids=["AB"]),
            _centroid_elem("A", 1),
            _centroid_elem("D", 2),
        ]
        network = build_network(elements)
        ab = next(lnk for lnk in network.links if lnk.external_id == "AB")
        cd = next(lnk for lnk in network.links if lnk.external_id == "CD")
        assert ab.opposite_link is cd
        assert cd.opposite_link is ab

    def test_unknown_reverse_link_id_ignored(self):
        """A reverseLinkIds entry pointing to a non-existent link is silently ignored."""
        elements = [
            _link_elem("AB", "A", "B", reverse_ids=["DOES_NOT_EXIST"]),
            _centroid_elem("A", 1),
            _centroid_elem("B", 2),
        ]
        network = build_network(elements)
        ab = next(lnk for lnk in network.links if lnk.external_id == "AB")
        assert ab.opposite_link is None


# ---------------------------------------------------------------------------
# parse_feedlinks_as_centroids
# ---------------------------------------------------------------------------


class TestParseFeedlinksAsCentroids:
    def test_element_count(self):
        elements, zone_by_node, zone_index_by_zone_id = parse_feedlinks_as_centroids(
            FEEDLINKS_GEOJSON
        )
        assert len(elements) == 2
        assert len(zone_by_node) == 2
        assert len(zone_index_by_zone_id) == 2

    def test_zone_mapping(self):
        _, zone_by_node, zone_index_by_zone_id = parse_feedlinks_as_centroids(FEEDLINKS_GEOJSON)
        assert zone_by_node["vA"] == 1
        assert zone_by_node["vB"] == 2
        assert zone_index_by_zone_id["zone_A"] == 1
        assert zone_index_by_zone_id["zone_B"] == 2

    def test_data_type(self):
        elements, _, _2 = parse_feedlinks_as_centroids(FEEDLINKS_GEOJSON)
        for elem in elements:
            assert elem["dataType"] == "centroid"

    def test_duplicate_raises(self):
        # Two production feedlinks with different zoneIds but same fromNode → duplicate nodeId
        dup_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
                    "properties": {
                        "zoneId": "zone_X1",
                        "fromNode": "A",
                        "toNode": "net1",
                        "linkDirection": "production",
                        "length": 100.0,
                        "capacity": 1800.0,
                        "feedlinkId": "FL-X1",
                        "type": "feedlink",
                    },
                },
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
                    "properties": {
                        "zoneId": "zone_X2",
                        "fromNode": "A",
                        "toNode": "net1",
                        "linkDirection": "production",
                        "length": 100.0,
                        "capacity": 1800.0,
                        "feedlinkId": "FL-X2",
                        "type": "feedlink",
                    },
                },
            ],
        }
        with pytest.raises(ValueError, match="Duplicate centroid nodeId"):
            parse_feedlinks_as_centroids(dup_fc)


# ---------------------------------------------------------------------------
# parse_feedlinks_as_links
# ---------------------------------------------------------------------------


class TestParseFeedlinksAsLinks:
    def test_element_count(self):
        elements = parse_feedlinks_as_links(FEEDLINKS_GEOJSON)
        assert len(elements) == 4

    def test_data_type(self):
        for elem in parse_feedlinks_as_links(FEEDLINKS_GEOJSON):
            assert elem["dataType"] == "link"

    def test_properties_mapped(self):
        elements = parse_feedlinks_as_links(FEEDLINKS_GEOJSON)
        fl_a = next(e for e in elements if e["properties"]["id"] == "FL-A-prod")
        p = fl_a["properties"]
        assert p["fromNodeId"] == "vA"
        assert p["toNodeId"] == "A"
        assert p["lengthInMeters"] == pytest.approx(100.0)
        assert p["speedInKilometersPerHour"] == pytest.approx(999.0)
        assert p["capacity"] == pytest.approx(3600.0)

    def test_reverse_link_ids_forwarded(self):
        fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
                    "properties": {
                        "feedlinkId": 1,
                        "fromNode": "Z",
                        "toNode": "N",
                        "length": 50.0,
                        "capacity": 1000.0,
                        "reverseLinkIds": [2],
                    },
                },
            ],
        }
        elements = parse_feedlinks_as_links(fc)
        assert elements[0]["properties"]["reverseLinkIds"] == [2]

    def test_reverse_link_ids_absent_when_not_in_source(self):
        elements = parse_feedlinks_as_links(FEEDLINKS_GEOJSON)
        for elem in elements:
            assert "reverseLinkIds" not in elem["properties"]

    def test_empty_fc(self):
        assert parse_feedlinks_as_links({"type": "FeatureCollection", "features": []}) == []


# ---------------------------------------------------------------------------
# parse_od_matrix_geojson
# ---------------------------------------------------------------------------


class TestParseOdMatrixGeojson:
    def _zone_map(self):
        return {"zone_A": 1, "zone_B": 2}

    def test_basic_parsing(self):
        m = parse_od_matrix_geojson(OD_MATRIX_GEOJSON, self._zone_map())
        assert m.rows == 2
        assert m.cols == 2
        # zone_A(0) -> zone_B(1) = 100
        assert m.get(0, 1) == pytest.approx(100.0)
        # zone_B(1) -> zone_A(0) = 0 (trips=0.0 in GeoJSON)
        assert m.get(1, 0) == pytest.approx(0.0)

    def test_unknown_zones_skipped(self):
        od = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": None,
                    "properties": {"fromZoneId": "UNKNOWN", "toZoneId": "zone_B", "trips": 99.0},
                },
                {
                    "type": "Feature",
                    "geometry": None,
                    "properties": {"fromZoneId": "zone_A", "toZoneId": "zone_B", "trips": 75.0},
                },
            ],
        }
        m = parse_od_matrix_geojson(od, self._zone_map())
        assert m.get(0, 1) == pytest.approx(75.0)

    def test_zero_trips_not_stored(self):
        od = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": None,
                    "properties": {"fromZoneId": "zone_A", "toZoneId": "zone_B", "trips": 0.0},
                },
            ],
        }
        m = parse_od_matrix_geojson(od, self._zone_map())
        assert m.get(0, 1) == pytest.approx(0.0)

    def test_no_centroids_raises(self):
        with pytest.raises(ValueError, match="No centroids"):
            parse_od_matrix_geojson(OD_MATRIX_GEOJSON, {})


# ---------------------------------------------------------------------------
# build_output_geojson
# ---------------------------------------------------------------------------


class TestBuildOutputGeojson:
    def _link_results(self):
        return [
            LinkResult(link_id="AB", cost=1.5, demand=100.0, flow=95.0, acceptance_factor=0.95),
            LinkResult(link_id="BA", cost=1.5, demand=0.0, flow=0.0, acceptance_factor=1.0),
        ]

    def test_feature_count(self):
        fc = build_output_geojson(NETWORK_GEOJSON, self._link_results(), 0.001, 5)
        assert len(fc["features"]) == 2

    def test_output_properties_present(self):
        fc = build_output_geojson(NETWORK_GEOJSON, self._link_results(), 0.001, 5)
        ab = next(f for f in fc["features"] if f["properties"]["linkId"] == "AB")
        p = ab["properties"]
        assert p["flow"] == pytest.approx(95.0)
        assert p["demand"] == pytest.approx(100.0)
        assert p["cost"] == pytest.approx(1.5)
        assert p["acceptanceFactor"] == pytest.approx(0.95)
        assert p["relativeDualityGap"] == pytest.approx(0.001)
        assert p["iterations"] == 5

    def test_geometry_preserved(self):
        fc = build_output_geojson(NETWORK_GEOJSON, self._link_results(), 0.0, 1)
        ab = next(f for f in fc["features"] if f["properties"]["linkId"] == "AB")
        assert ab["geometry"]["type"] == "LineString"

    def test_link_not_in_results_gets_zero(self):
        # Only supply result for AB; BA should get zeros
        results = [
            LinkResult(link_id="AB", cost=1.5, demand=100.0, flow=95.0, acceptance_factor=0.95)
        ]
        fc = build_output_geojson(NETWORK_GEOJSON, results, 0.001, 5)
        ba = next(f for f in fc["features"] if f["properties"]["linkId"] == "BA")
        assert ba["properties"]["flow"] == pytest.approx(0.0)
        assert ba["properties"]["demand"] == pytest.approx(0.0)
        assert ba["properties"]["acceptanceFactor"] == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# run_assignment  (end-to-end)
# ---------------------------------------------------------------------------


class TestRunAssignment:
    def test_returns_geojson_and_stats(self):
        output_geojson, stats = run_assignment(
            NETWORK_GEOJSON, FEEDLINKS_GEOJSON, OD_MATRIX_GEOJSON, **ASSIGNMENT_KWARGS
        )
        assert output_geojson["type"] == "FeatureCollection"
        assert len(output_geojson["features"]) == 2
        assert "nLinks" in stats
        assert "nCentroids" in stats
        assert "rdg" in stats
        assert "iterations" in stats

    def test_stats_values(self):
        _, stats = run_assignment(
            NETWORK_GEOJSON, FEEDLINKS_GEOJSON, OD_MATRIX_GEOJSON, **ASSIGNMENT_KWARGS
        )
        assert stats["nLinks"] == 2
        assert stats["nCentroids"] == 2
        assert stats["rdg"] >= 0.0
        assert 1 <= stats["iterations"] <= ASSIGNMENT_KWARGS["max_iterations"]

    def test_link_ab_carries_demand(self):
        output_geojson, _ = run_assignment(
            NETWORK_GEOJSON, FEEDLINKS_GEOJSON, OD_MATRIX_GEOJSON, **ASSIGNMENT_KWARGS
        )
        ab = next(f for f in output_geojson["features"] if f["properties"]["linkId"] == "AB")
        p = ab["properties"]
        assert abs(p["demand"] - 100.0) < 1e-6, f"AB demand expected ~100, got {p['demand']}"
        assert p["flow"] > 0.0
        assert 0.0 < p["acceptanceFactor"] <= 1.0 + 1e-9

    def test_output_has_rdg_and_iterations_on_every_feature(self):
        output_geojson, stats = run_assignment(
            NETWORK_GEOJSON, FEEDLINKS_GEOJSON, OD_MATRIX_GEOJSON, **ASSIGNMENT_KWARGS
        )
        for feat in output_geojson["features"]:
            p = feat["properties"]
            assert "relativeDualityGap" in p
            assert p["relativeDualityGap"] == pytest.approx(stats["rdg"])
            assert p["iterations"] == stats["iterations"]

    def test_no_links_raises(self):
        empty_net = {"type": "FeatureCollection", "features": []}
        with pytest.raises(ValueError, match="No links"):
            run_assignment(empty_net, FEEDLINKS_GEOJSON, OD_MATRIX_GEOJSON, **ASSIGNMENT_KWARGS)

    def test_no_centroids_raises(self):
        empty_feedlinks = {"type": "FeatureCollection", "features": []}
        with pytest.raises(ValueError, match="No centroids"):
            run_assignment(NETWORK_GEOJSON, empty_feedlinks, OD_MATRIX_GEOJSON, **ASSIGNMENT_KWARGS)

    def test_unknown_fd_type_raises(self):
        kwargs = {**ASSIGNMENT_KWARGS, "fundamental_diagram_type": "BadType"}
        with pytest.raises(ValueError, match="fundamentalDiagramType"):
            run_assignment(NETWORK_GEOJSON, FEEDLINKS_GEOJSON, OD_MATRIX_GEOJSON, **kwargs)


# ---------------------------------------------------------------------------
# Feedlink support in parse_network_geojson
# ---------------------------------------------------------------------------

FEEDLINK_FEATURE = {
    "type": "Feature",
    "geometry": {"type": "LineString", "coordinates": [[0, 0], [0.5, 0]]},
    "properties": {
        "type": "feedlink",
        "feedlinkId": "FL-Z1-A",
        "fromNode": "Z1",
        "toNode": "A",
        "length": 100.0,
        "capacity": 3600.0,
        "mode": "CAR",
        "ringIndex": 0,
    },
}

MIXED_NETWORK_GEOJSON = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
            "properties": {
                "type": "link",
                "linkId": "AB",
                "fromNode": "A",
                "toNode": "B",
                "length": 1000.0,
                "speed": 50.0,
                "capacity": 1800.0,
            },
        },
        FEEDLINK_FEATURE,
    ],
}


class TestParseNetworkGeojsonFeedlinks:
    def test_feedlink_uses_feedlink_id(self):
        elements, _ = parse_network_geojson(
            {"type": "FeatureCollection", "features": [FEEDLINK_FEATURE]}
        )
        assert len(elements) == 1
        assert elements[0]["properties"]["id"] == "FL-Z1-A"

    def test_feedlink_uses_high_speed(self):
        elements, _ = parse_network_geojson(
            {"type": "FeatureCollection", "features": [FEEDLINK_FEATURE]}
        )
        assert elements[0]["properties"]["speedInKilometersPerHour"] == pytest.approx(999.0)

    def test_feedlink_nodes_and_length(self):
        elements, _ = parse_network_geojson(
            {"type": "FeatureCollection", "features": [FEEDLINK_FEATURE]}
        )
        p = elements[0]["properties"]
        assert p["fromNodeId"] == "Z1"
        assert p["toNodeId"] == "A"
        assert p["lengthInMeters"] == pytest.approx(100.0)
        assert p["capacity"] == pytest.approx(3600.0)

    def test_feedlink_geometry_preserved(self):
        _, geometries = parse_network_geojson(
            {"type": "FeatureCollection", "features": [FEEDLINK_FEATURE]}
        )
        assert "FL-Z1-A" in geometries

    def test_mixed_network_parsed_correctly(self):
        elements, geometries = parse_network_geojson(MIXED_NETWORK_GEOJSON)
        assert len(elements) == 2
        ids = {e["properties"]["id"] for e in elements}
        assert ids == {"AB", "FL-Z1-A"}
        # Regular link retains its speed
        ab = next(e for e in elements if e["properties"]["id"] == "AB")
        assert ab["properties"]["speedInKilometersPerHour"] == pytest.approx(50.0)
        # Feedlink gets the high default speed
        fl = next(e for e in elements if e["properties"]["id"] == "FL-Z1-A")
        assert fl["properties"]["speedInKilometersPerHour"] == pytest.approx(999.0)

    def test_feature_without_type_treated_as_link(self):
        """Features without a 'type' property fall back to regular-link parsing."""
        feat = {
            "type": "Feature",
            "geometry": None,
            "properties": {
                "linkId": "XY",
                "fromNode": "X",
                "toNode": "Y",
                "length": 500.0,
                "speed": 30.0,
                "capacity": 900.0,
            },
        }
        elements, _ = parse_network_geojson({"type": "FeatureCollection", "features": [feat]})
        assert elements[0]["properties"]["id"] == "XY"
        assert elements[0]["properties"]["speedInKilometersPerHour"] == pytest.approx(30.0)


# ---------------------------------------------------------------------------
# build_output_geojson feedlink id resolution
# ---------------------------------------------------------------------------


class TestBuildOutputGeojsonFeedlinks:
    def test_feedlink_result_resolved_by_feedlink_id(self):
        fc = {
            "type": "FeatureCollection",
            "features": [FEEDLINK_FEATURE],
        }
        results = [
            LinkResult(link_id="FL-Z1-A", cost=0.01, demand=50.0, flow=50.0, acceptance_factor=1.0),
        ]
        out = build_output_geojson(fc, results, 0.0, 1)
        feat = out["features"][0]
        assert feat["properties"]["flow"] == pytest.approx(50.0)
        assert feat["properties"]["demand"] == pytest.approx(50.0)

    def test_mixed_network_output_has_correct_ids(self):
        results = [
            LinkResult(link_id="AB", cost=1.0, demand=100.0, flow=90.0, acceptance_factor=0.9),
            LinkResult(
                link_id="FL-Z1-A", cost=0.01, demand=100.0, flow=100.0, acceptance_factor=1.0
            ),
        ]
        out = build_output_geojson(MIXED_NETWORK_GEOJSON, results, 0.001, 3)
        ab_feat = next(f for f in out["features"] if f["properties"].get("linkId") == "AB")
        fl_feat = next(f for f in out["features"] if f["properties"].get("feedlinkId") == "FL-Z1-A")
        assert ab_feat["properties"]["flow"] == pytest.approx(90.0)
        assert fl_feat["properties"]["flow"] == pytest.approx(100.0)
