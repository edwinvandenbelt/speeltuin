"""Local debug runner for matrix_builder.

Builds a complete zone × zone OD route set with unit productions — one
``+1.0`` production per zone — so that ``trips`` values represent the
proportional distribution of a single unit from each origin zone.

Usage
-----
python -m matrix_builder.matrix_builder_runner \\
    --network-file  /tmp/{areaId}-NETWORK-CAR.parquet \\
    --feedlinks-file /tmp/{areaId}-FEEDLINK-CAR.parquet \\
    --zone-file     /tmp/{areaId}-ZONE-CAR.parquet \\
    --output-folder /tmp/output \\
    --area-id       <uuid> \\
    --mode          CAR

# S3 inputs / local output folder:
python -m matrix_builder.matrix_builder_runner \\
    --network-file   s3://gmp-networks/network/{areaId}-NETWORK-CAR.parquet \\
    --feedlinks-file s3://gmp-networks/network/{areaId}-FEEDLINK-CAR.parquet \\
    --zone-file      s3://gmp-networks/network/{areaId}-ZONE-CAR.parquet \\
    --output-folder  /tmp/output \\
    --area-id        <uuid> \\
    --mode           CAR \\
    --max-routes     3

Output
------
{output_folder}/{area_id}-ROUTES-{mode}.parquet

Prerequisites
-------------
* PYTHONPATH must include <repo_root>/src  (set automatically when launched
  via run_preparation.bat or a matching VS Code launch config).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_file(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Build a complete zone × zone OD matrix with unit productions. "
            "Each zone receives production = +1.0 so that trips values represent "
            "the proportional ratio-distribution of a single unit from each origin."
        )
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="Network GeoJSON file (local path or s3://).",
    )
    parser.add_argument(
        "--feedlinks-file",
        required=True,
        metavar="URI",
        help="Feedlinks GeoJSON file (local path or s3://).",
    )
    parser.add_argument(
        "--zone-file",
        required=True,
        metavar="URI",
        help="Zones GeoJSON file (local path or s3://).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="DIR",
        help="Output directory.  The file is written as {area_id}-ROUTES-{mode}.parquet.",
    )
    parser.add_argument(
        "--area-id",
        required=True,
        metavar="UUID",
        help="Area UUID used to name the output file.",
    )
    parser.add_argument(
        "--mode",
        required=True,
        metavar="MODE",
        help="Transport mode, e.g. CAR, BIKE, PEDESTRIAN.",
    )
    parser.add_argument(
        "--max-routes",
        type=int,
        default=3,
        metavar="K",
        help="Maximum number of alternative routes per OD pair (default: 3).",
    )
    parser.add_argument(
        "--min-endpoint-dist",
        type=float,
        default=200.0,
        metavar="M",
        help=(
            "Minimum straight-line distance in metres between BOUNDARY zone centroids "
            "for the U-turn heading filter to apply (default: 200).  "
            "Set to 0 to disable U-turn filtering entirely."
        ),
    )
    parser.add_argument(
        "--max-heading-diff",
        type=float,
        default=120.0,
        metavar="DEG",
        help=(
            "Maximum compass-heading difference in degrees between two BOUNDARY zones "
            "before a close pair is treated as a U-turn and skipped (default: 120).  "
            "Only evaluated when zone centroids are closer than --min-endpoint-dist."
        ),
    )
    parser.add_argument(
        "--workers",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Number of parallel worker processes for zone routing.  "
            "Defaults to os.cpu_count().  Pass 1 to disable parallelism."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_routing.matrix_builder.core.matrix_builder_core import build_matrix

    print(f"Reading network         : {args.network_file}")
    network_fc = from_geoparquet(_read_uri(args.network_file))

    print(f"Reading feedlinks       : {args.feedlinks_file}")
    feedlinks_fc = from_geoparquet(_read_uri(args.feedlinks_file))

    print(f"Reading zones           : {args.zone_file}")
    zones_fc = from_geoparquet(_read_uri(args.zone_file))

    n_zones = len(zones_fc.get("features", []))
    print(
        f"Building complete OD matrix: {n_zones} zones × {n_zones - 1} destinations, "
        f"max_routes={args.max_routes}, "
        f"min_endpoint_dist={args.min_endpoint_dist} m, "
        f"max_heading_diff={args.max_heading_diff}° ..."
    )

    od_geojson = build_matrix(
        network_fc,
        feedlinks_fc,
        zones_fc,
        max_routes=args.max_routes,
        workers=args.workers,
        min_endpoint_dist_m=args.min_endpoint_dist,
        max_heading_diff_deg=args.max_heading_diff,
    )

    n_features = len(od_geojson.get("features", []))

    output_path = Path(args.output_folder) / f"{args.area_id}-ROUTES-{args.mode}.parquet"
    _write_file(output_path, to_geoparquet(od_geojson))

    print()
    print(f"Done. {n_features} OD pair features written.")


if __name__ == "__main__":
    main()
