"""Domain helpers for matrix_builder — pure Python, no I/O, no boto3."""
