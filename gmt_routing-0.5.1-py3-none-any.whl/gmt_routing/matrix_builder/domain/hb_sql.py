"""SQL builder for the real Spectrum HB (home-based) OD matrix.

Pure string construction — no I/O, no boto3, no Databricks connection.

The HB matrix table stores car ("auto") trip totals keyed on Spectrum zone
gids (``from_zone_gid`` / ``to_zone_gid``) with a ``ritten`` (trips) column.
``build_hb_od_sql`` aggregates ritten per gid pair, restricted to the given
set of inner (STUDY / INFLUENCE) zone gids.  The table lives in the same
``catalog`` / ``schema`` as the network and zone data used by the pipeline.
"""

from __future__ import annotations

HB_OD_TABLE = "d083_hb_matrices_met_2018_kalibratie_effect_auto"


def build_hb_od_sql(catalog: str, schema: str, inner_gids: set[int]) -> str:
    """Return the HB OD SQL with *inner_gids* inlined as integer literals.

    The query returns one row per ``(from_zone_gid, to_zone_gid)`` pair with
    the summed ``ritten`` as ``trips``.  Only pairs where the origin gid is an
    inner gid are kept, so the result covers internal-to-anywhere flows for the
    study / influence zones.  When *inner_gids* is empty a query returning no
    rows is produced.
    """
    if not inner_gids:
        return (
            f"SELECT od.from_zone_gid, od.to_zone_gid, SUM(od.ritten) AS trips\n"
            f"FROM {catalog}.`{schema}`.{HB_OD_TABLE} od\n"
            "WHERE 1=0\n"
            "GROUP BY od.from_zone_gid, od.to_zone_gid"
        )

    gids_csv = ", ".join(str(int(g)) for g in sorted(inner_gids))
    return (
        f"SELECT od.from_zone_gid, od.to_zone_gid, SUM(od.ritten) AS trips\n"
        f"FROM {catalog}.`{schema}`.{HB_OD_TABLE} od\n"
        f"WHERE od.from_zone_gid IN ({gids_csv})\n"
        f"   OR od.to_zone_gid   IN ({gids_csv})\n"
        "GROUP BY od.from_zone_gid, od.to_zone_gid"
    )
