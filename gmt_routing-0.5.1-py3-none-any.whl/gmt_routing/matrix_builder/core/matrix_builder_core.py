"""Pure-Python matrix_builder core — no I/O, no boto3, no external deps.

Builds a **complete** zone × zone OD route set by assigning unit production
(+1.0) to every zone.

Ratio-distribution semantics
-----------------------------
Because each zone receives production = 1.0, the ``trips`` value on every
output feature represents the *proportional share* of one unit of production
that flows from origin zone O to destination zone D:

    trips(O → D)  =  zone_attractions[D] / Σ zone_attractions[all reachable D′]

Summing ``trips`` over all destinations for a single origin always equals 1.0
(subject to routing coverage — unreachable pairs contribute 0).

Parallelism
-----------
Routing is **embarrassingly parallel** at the origin-zone level: each zone's
Dijkstra/Yen computations are fully independent.  ``build_matrix`` uses
``concurrent.futures.ProcessPoolExecutor`` with a per-worker initialiser that
loads the read-only graph and zone marginals *once per worker process*, so the
large adjacency dict is serialised at most ``workers`` times total rather than
once per zone.

Public API
----------
build_matrix(network_fc, feedlinks_fc, zones_fc, max_routes=3, workers=None)
    -> od_geojson dict

    When *workers* is ``None`` (the default) the process count is auto-detected
    from available RAM via ``psutil`` (budget: 768 MB/worker), capping at
    ``os.cpu_count()``.  Pass an explicit integer to override.
"""

from __future__ import annotations

import os

# Cap OpenBLAS (and generic OpenMP) thread count before numpy is initialised.
# Without this, spawning two ProcessPoolExecutors simultaneously (one per mode
# in prepare_core's parallel matrix_builder step) causes every worker process
# to compete for large aligned memory blocks during OpenBLAS thread-pool setup,
# resulting in "Memory allocation still failed after 10 retries".
# setdefault leaves the value unchanged if the caller has already set it.
os.environ.setdefault("OPENBLAS_NUM_THREADS", "4")
os.environ.setdefault("OMP_NUM_THREADS", "4")

import logging
import time
from concurrent.futures import ProcessPoolExecutor, as_completed
from typing import TYPE_CHECKING

from gmt_shared.geo_utils import _flat_earth_dist_m

from gmt_routing.od_support_matrices_creator.core.od_support_matrices_creator_core import (
    build_graph,
    compute_zone_headings,
    compute_zone_reverse_pairs,
    extract_zone_centroids,
)
from gmt_routing.route_explorer.core.route_explorer_core import (
    _build_link_index,
    _build_od_geojson,
    _build_reverse_edge_map,
    _dijkstra_tree,
    _estimate_zone_marginals,
    _extract_node_coords,
    _reconstruct_from_tree,
    _yen_k_shortest,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Worker auto-tuning
# ---------------------------------------------------------------------------

#: Memory budget per worker process (MB).  Each worker holds a full copy of
#: the adjacency graph plus Dijkstra working dicts.  For typical city networks
#: (up to 10 000 links) actual usage is 50-200 MB; we budget 768 MB to leave
#: room for OS overhead and other in-process data.
_WORKER_MEMORY_BUDGET_MB: float = 768.0


def _auto_workers(worker_share: int = 1) -> int:
    """Return a safe worker count based on available RAM and CPU count.

    Uses ``psutil.virtual_memory().available`` to determine how many worker
    processes can be spawned within :data:`_WORKER_MEMORY_BUDGET_MB` each.
    Falls back to ``min(cpu_count, 4)`` when *psutil* is not installed.

    Parameters
    ----------
    worker_share:
        Number of concurrent ``build_matrix`` calls that share this machine
        (e.g. CAR and BIKE run at the same time in ``prepare``).  The resolved
        worker count is divided by this value so the concurrent pools together
        do not oversubscribe CPU/RAM.  Defaults to 1 (sole user).

    Returns
    -------
    int
        At least 1, at most ``os.cpu_count()``.
    """
    cpu = os.cpu_count() or 1
    try:
        import psutil

        available_mb = psutil.virtual_memory().available / (1024.0 * 1024.0)
        mem_workers = max(1, int(available_mb // _WORKER_MEMORY_BUDGET_MB))
        logger.debug(
            "_auto_workers: %.0f MB available -> %d memory-budget workers (cpu_count=%d)",
            available_mb,
            mem_workers,
            cpu,
        )
    except ImportError:
        logger.debug("_auto_workers: psutil not available - capping at min(cpu_count, 4)")
        mem_workers = min(cpu, 4)
    share = max(1, worker_share)
    return max(1, min(cpu, mem_workers) // share)


if TYPE_CHECKING:
    pass

__all__ = ["build_matrix"]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _angular_diff(h1: float, h2: float) -> float:
    """Absolute angular difference between two compass headings in degrees [0, 180]."""
    diff = abs(h1 - h2) % 360.0
    return diff if diff <= 180.0 else 360.0 - diff


def _log_progress(label: str, done: int, total: int) -> None:
    """Emit a routing-progress line for *label* at *done*/*total* origin zones."""
    pct = (100.0 * done / total) if total else 100.0
    prefix = f"[{label}] " if label else ""
    msg = f"  {prefix}routed {done}/{total} origin zones ({pct:.0f}%)"
    logger.info(msg)
    print(msg)


# ---------------------------------------------------------------------------
# Worker-process shared state
# ---------------------------------------------------------------------------
# Each worker process sets this dict once via _init_worker().  Tasks then
# communicate only the origin zone_id (a small string) rather than the full
# graph, keeping inter-process data transfer minimal.

_worker_state: dict = {}


def _init_worker(
    adj: dict,
    zone_node_ids: dict,
    zone_ids: list[str],
    zone_attractions: dict[str, float],
    max_routes: int,
    boundary_zone_ids: set[str],
    zone_centroids: dict[str, tuple[float, float]],
    zone_headings: dict[str, float],
    min_endpoint_dist_m: float,
    max_heading_diff_deg: float,
    zone_reverse_pairs: set[frozenset],
    reverse_edge_map: dict,
) -> None:
    """Initialiser executed once per worker process."""
    _worker_state["adj"] = adj
    _worker_state["zone_node_ids"] = zone_node_ids
    _worker_state["zone_ids"] = zone_ids
    _worker_state["zone_attractions"] = zone_attractions
    _worker_state["max_routes"] = max_routes
    _worker_state["boundary_zone_ids"] = boundary_zone_ids
    _worker_state["zone_centroids"] = zone_centroids
    _worker_state["zone_headings"] = zone_headings
    _worker_state["min_endpoint_dist_m"] = min_endpoint_dist_m
    _worker_state["max_heading_diff_deg"] = max_heading_diff_deg
    _worker_state["zone_reverse_pairs"] = zone_reverse_pairs
    _worker_state["reverse_edge_map"] = reverse_edge_map


def _route_one_origin(
    adj_zone_id: str,
) -> list[tuple[tuple, list, float]]:
    """Worker task: route *adj_zone_id* to every other zone.

    Reads shared state set by ``_init_worker`` and returns a list of
    ``(pair_key, routes, trips)`` tuples — one per routable destination zone.
    The main process merges these into the global ``od_trips`` /
    ``routes_per_pair`` dicts.

    Parameters
    ----------
    adj_zone_id:
        The origin zone ID to route from.

    Returns
    -------
    list of ``(pair_key, routes, trips)`` where

    - ``pair_key`` is ``(from_id, to_id, "zone", "zone")``
    - ``routes`` is a ``list[RouteEntry]`` from Yen's algorithm
    - ``trips`` is the proportional share (unit production distributed by
      destination attraction weight)
    """
    adj = _worker_state["adj"]
    zone_node_ids = _worker_state["zone_node_ids"]
    zone_ids = _worker_state["zone_ids"]
    zone_attractions = _worker_state["zone_attractions"]
    max_routes = _worker_state["max_routes"]
    boundary_zone_ids = _worker_state["boundary_zone_ids"]
    zone_centroids = _worker_state["zone_centroids"]
    zone_headings = _worker_state["zone_headings"]
    min_endpoint_dist_m = _worker_state["min_endpoint_dist_m"]
    max_heading_diff_deg = _worker_state["max_heading_diff_deg"]
    zone_reverse_pairs = _worker_state["zone_reverse_pairs"]
    reverse_edge_map = _worker_state["reverse_edge_map"]

    if adj_zone_id not in zone_node_ids:
        return []

    vnode = zone_node_ids[adj_zone_id]
    target_zones = [z for z in zone_ids if z != adj_zone_id and z in zone_node_ids]

    # One-to-all Dijkstra from this origin's virtual node: the shortest-path
    # tree to every reachable node is computed once, so the first (shortest)
    # path to each target is a cheap backtrack instead of a fresh full Dijkstra
    # per target.  Yen's spur searches for k > 1 still run per pair.
    origin_tree = _dijkstra_tree(adj, vnode)

    prod_routes_by_zone: dict[str, list] = {}
    for target_zone_id in target_zones:
        # Skip destinations with zero attraction — tripFraction will be 0
        # regardless of route availability, so routing adds no value.
        if zone_attractions.get(target_zone_id, 0.0) == 0.0:
            continue

        if adj_zone_id in boundary_zone_ids and target_zone_id in boundary_zone_ids:
            # Hard skip: physically anti-parallel crossings (reverseLinkIds) are
            # always U-turns, regardless of distance or heading.
            if frozenset({adj_zone_id, target_zone_id}) in zone_reverse_pairs:
                logger.debug(
                    "Skipping BOUNDARY pair %s → %s: reverse link pair (U-turn)",
                    adj_zone_id,
                    target_zone_id,
                )
                continue

            # Soft skip: close together *and* headings are nearly anti-parallel.
            if min_endpoint_dist_m > 0.0:
                ac = zone_centroids.get(adj_zone_id)
                tc = zone_centroids.get(target_zone_id)
                if (
                    ac
                    and tc
                    and _flat_earth_dist_m(ac[0], ac[1], tc[0], tc[1]) < min_endpoint_dist_m
                ):
                    h_orig = zone_headings.get(adj_zone_id)
                    h_dest = zone_headings.get(target_zone_id)
                    if (
                        h_orig is not None
                        and h_dest is not None
                        and _angular_diff(h_orig, h_dest) > max_heading_diff_deg
                    ):
                        logger.debug(
                            "Skipping BOUNDARY pair %s → %s: dist=%.1f m, "
                            "heading diff=%.1f° > %.1f°",
                            adj_zone_id,
                            target_zone_id,
                            _flat_earth_dist_m(ac[0], ac[1], tc[0], tc[1]),
                            _angular_diff(h_orig, h_dest),
                            max_heading_diff_deg,
                        )
                        continue

        tvnode = zone_node_ids[target_zone_id]
        # Reuse the shared one-to-all tree for the shortest path; only k > 1
        # alternatives require additional spur Dijkstras inside Yen.
        first = _reconstruct_from_tree(vnode, tvnode, origin_tree)
        if first is None:
            continue
        routes = _yen_k_shortest(adj, vnode, tvnode, max_routes, reverse_edge_map, first=first)
        if routes:
            prod_routes_by_zone[target_zone_id] = routes

    total_attr_weight = sum(zone_attractions.get(z, 0.0) for z in prod_routes_by_zone)

    results: list[tuple] = []
    for target_zone_id, routes in prod_routes_by_zone.items():
        raw = zone_attractions.get(target_zone_id, 0.0)
        proportion = (raw / total_attr_weight) if total_attr_weight > 0.0 else 0.0
        pair_key = (adj_zone_id, target_zone_id, "zone", "zone")
        results.append((pair_key, routes, proportion))  # trips = 1.0 × proportion

    return results


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_matrix(
    network_fc: dict,
    feedlinks_fc: dict,
    zones_fc: dict,
    max_routes: int = 3,
    workers: int | None = None,
    min_endpoint_dist_m: float = 200.0,
    max_heading_diff_deg: float = 120.0,
    hb_od: dict[tuple[str, str], float] | None = None,
    progress_label: str = "",
    worker_share: int = 1,
) -> dict:
    """Build a complete zone × zone OD matrix with unit productions.

    For every zone present in *zones_fc*, a production of 1.0 is assigned and
    routes to all other zones are computed.  Trip weights are proportional to
    destination zone attractions derived from network ``flow`` values.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection.  Must carry ``fromNode``,
        ``toNode``, ``speed``, ``length``, ``capacity``, and ``flow`` per link.
    feedlinks_fc:
        Feedlinks GeoJSON (output of ``feedlink_creator`` /
        ``network_zone_joiner``).
    zones_fc:
        Zones GeoJSON.  Must contain one feature per zone with a ``zoneId``
        property and Polygon / MultiPolygon geometry.
    max_routes:
        Maximum number of k-shortest alternative routes per OD pair.
        Defaults to 3.
    workers:
        Number of parallel worker processes.  ``None`` (default) uses
        ``os.cpu_count()``.  Pass ``1`` to run sequentially (useful for
        debugging or when spawning overhead is not worth it for small networks).
    min_endpoint_dist_m:
        Minimum straight-line distance in metres between the centroids of two
        BOUNDARY zones for the U-turn heading filter to be applied.  Pairs
        where the centroids are *closer* than this threshold AND whose road
        headings are nearly anti-parallel are skipped.  Set to ``0`` to
        disable the filter entirely.  Defaults to 300 m.
    max_heading_diff_deg:
        Maximum allowed compass-heading difference (in degrees) between the
        origin and destination BOUNDARY zones before a close pair is considered
        a U-turn and skipped.  A value of 120° means: skip the pair if the
        roads are more than 120° apart in bearing (i.e. heading back the way
        you came).  Only evaluated when the zone centroids are closer than
        ``min_endpoint_dist_m``.  Defaults to 120°.

    hb_od:
        Optional real Spectrum HB (home-based) OD matrix, keyed on
        ``(fromZoneId, toZoneId)`` with absolute trip counts.  When supplied,
        internal (non-BOUNDARY) zone pairs that have a matching entry use the
        real HB trip count for the feature's absolute ``trips`` property
        (``tripSource = "spectrum-hb"``).  Internal pairs without an entry and
        all BOUNDARY pairs fall back to the synthetic attraction-proportional
        estimate (``tripSource = "synthetic"``).  ``None`` (default) means every
        pair is synthetic.

    progress_label:
        Short label (e.g. the mode ``"CAR"`` / ``"BIKE"``) prefixed to routing
        progress lines.  Distinguishes the output of concurrent ``build_matrix``
        calls.  Empty string (default) prints unlabelled progress.
    worker_share:
        Number of concurrent ``build_matrix`` calls sharing this machine.  Only
        used when *workers* is ``None``; the auto-detected worker count is
        divided by this value.  Defaults to 1.

    Returns
    -------
    dict
        GeoJSON FeatureCollection — one Feature per routable (zone, zone)
        pair.  Properties: ``fromId``, ``toId``, ``fromType`` (``"zone"``),
        ``toType`` (``"zone"``), ``trips``, ``routes``.
    """
    # ------------------------------------------------------------------
    # 1. Resolve worker count
    # ------------------------------------------------------------------
    n_workers: int = workers if workers is not None else _auto_workers(worker_share)
    n_workers = max(1, n_workers)

    # ------------------------------------------------------------------
    # 2. Build graph + zone marginals  (done once, on the main process)
    # ------------------------------------------------------------------
    adj, zone_node_ids, zone_centroids_graph = build_graph(network_fc, feedlinks_fc)
    zone_centroids: dict[str, tuple[float, float]] = dict(zone_centroids_graph)
    zone_centroids.update(extract_zone_centroids(zones_fc))

    zone_features: list[dict] = zones_fc.get("features") or []
    zone_ids: list[str] = [
        str(feat["properties"]["zoneId"])
        for feat in zone_features
        if (feat.get("properties") or {}).get("zoneId")
    ]

    # Boundary zone IDs and per-zone road headings — used for U-turn filtering.
    boundary_zone_ids: set[str] = {
        str((feat.get("properties") or {}).get("zoneId") or "")
        for feat in zone_features
        if (feat.get("properties") or {}).get("zoneClass") == "BOUNDARY"
    } - {""}
    zone_headings: dict[str, float] = compute_zone_headings(network_fc, feedlinks_fc)

    # Only route zones that have feedlink virtual nodes.
    routable_zone_ids = [z for z in zone_ids if z in zone_node_ids]

    logger.info(
        "build_matrix: %d zones total, %d routable, %d workers, max_routes=%d, "
        "min_endpoint_dist_m=%.0f, max_heading_diff_deg=%.0f",
        len(zone_ids),
        len(routable_zone_ids),
        n_workers,
        max_routes,
        min_endpoint_dist_m,
        max_heading_diff_deg,
    )

    if not routable_zone_ids:
        return {"type": "FeatureCollection", "features": [], "properties": {}}

    _, zone_attractions = _estimate_zone_marginals(network_fc, feedlinks_fc, zone_ids)
    # Read production directly from zone features (set by network_zone_joiner)
    # rather than estimating it from link flows, which always falls back to 1.0
    # when the network carries no flow data.
    zone_productions: dict[str, float] = {
        str(props.get("zoneId") or ""): float(props.get("production") or 0.0)
        for feat in (zones_fc.get("features") or [])
        if (props := feat.get("properties") or {}) and props.get("zoneId")
    }
    zone_building_by_type: dict[str, dict[str, float]] = {
        str(props.get("zoneId") or ""): {
            k: float(v) for k, v in (props.get("buildingByType") or {}).items()
        }
        for feat in (zones_fc.get("features") or [])
        if (props := feat.get("properties") or {})
        and props.get("zoneId")
        and props.get("buildingByType")
    }
    node_coords = _extract_node_coords(network_fc)
    link_index = _build_link_index(network_fc)

    # Anti-parallel boundary zone pairs (hard U-turn skip via reverseLinkIds).
    zone_reverse_pairs: set[frozenset] = compute_zone_reverse_pairs(network_fc, feedlinks_fc)
    # Reverse-edge map for Yen's spur step (prevents parallel-road backtracking).
    reverse_edge_map: dict = _build_reverse_edge_map(network_fc)

    # Shared init args — passed to every worker process.
    _init_args = (
        adj,
        zone_node_ids,
        zone_ids,
        zone_attractions,
        max_routes,
        boundary_zone_ids,
        zone_centroids,
        zone_headings,
        min_endpoint_dist_m,
        max_heading_diff_deg,
        zone_reverse_pairs,
        reverse_edge_map,
    )

    # ------------------------------------------------------------------
    # 3. Route all origin zones in parallel
    # ------------------------------------------------------------------
    od_trips: dict[tuple, float] = {}
    routes_per_pair: dict[tuple, list] = {}

    total = len(routable_zone_ids)
    # Report progress at most ~20 times, and never more than once per second.
    report_every = max(1, total // 20)
    last_report = time.monotonic()
    done = 0
    _log_progress(progress_label, 0, total)

    if n_workers == 1 or len(routable_zone_ids) <= 1:
        # Sequential path - avoids process-spawn overhead for small inputs.
        _init_worker(*_init_args)
        for zone_id in routable_zone_ids:
            for pair_key, routes, trips in _route_one_origin(zone_id):
                routes_per_pair[pair_key] = routes
                od_trips[pair_key] = trips
            done += 1
            now = time.monotonic()
            if done == total or (done % report_every == 0 and now - last_report >= 1.0):
                _log_progress(progress_label, done, total)
                last_report = now
    else:
        with ProcessPoolExecutor(
            max_workers=n_workers,
            initializer=_init_worker,
            initargs=_init_args,
        ) as executor:
            futures = [executor.submit(_route_one_origin, z) for z in routable_zone_ids]
            for future in as_completed(futures):
                for pair_key, routes, trips in future.result():
                    routes_per_pair[pair_key] = routes
                    od_trips[pair_key] = trips
                done += 1
                now = time.monotonic()
                if done == total or (done % report_every == 0 and now - last_report >= 1.0):
                    _log_progress(progress_label, done, total)
                    last_report = now

    # ------------------------------------------------------------------
    # 4. Serialise
    # ------------------------------------------------------------------
    # Map the real HB OD matrix onto routable internal (non-BOUNDARY) pairs.
    # Missing internal pairs and all BOUNDARY pairs stay synthetic.
    hb_pair_trips: dict[tuple, float] = {}
    if hb_od:
        for pair_key in routes_per_pair:
            from_id, to_id, _from_type, _to_type = pair_key
            if from_id in boundary_zone_ids or to_id in boundary_zone_ids:
                continue
            val = hb_od.get((from_id, to_id))
            if val is not None:
                hb_pair_trips[pair_key] = float(val)

    od_geojson = _build_od_geojson(
        od_trips,
        routes_per_pair,
        node_coords,
        zone_centroids,
        link_index,
        zone_productions=zone_productions,
        boundary_zone_ids=boundary_zone_ids,
        zone_building_by_type=zone_building_by_type,
        hb_trips=hb_pair_trips,
    )

    logger.info("build_matrix: %d OD pairs in output", len(routes_per_pair))
    return od_geojson
