"""Unit tests for matrix_builder_core."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from gmt_routing.matrix_builder.core.matrix_builder_core import _auto_workers, build_matrix

# ---------------------------------------------------------------------------
# Fixture helpers  (mirrors the toy network in route_explorer tests)
# ---------------------------------------------------------------------------


def _net_feature(from_node, to_node, speed, length, capacity, flow=0.0, coords=None):
    if coords is None:
        coords = [[0.0, 0.0], [1.0, 0.0]]
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "fromNode": from_node,
            "toNode": to_node,
            "speed": speed,
            "length": length,
            "capacity": capacity,
            "flow": flow,
            "flowsPerDaypart": {},
        },
    }


def _feedlink_feature(zone_id, network_node, direction, length, capacity=1000.0):
    """direction: 'production' -> zone→network; 'attraction' -> network→zone."""
    fake_zone = f"fake_{zone_id}"
    if direction == "attraction":
        from_node, to_node = network_node, fake_zone
    else:
        from_node, to_node = fake_zone, network_node
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [0.1, 0.0]]},
        "properties": {
            "zoneId": zone_id,
            "fromNode": from_node,
            "toNode": to_node,
            "length": length,
            "capacity": capacity,
        },
    }


def _zone_polygon(zone_id, ring):
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {"zoneId": zone_id, "zoneClass": "STUDY"},
    }


def _zone_polygon_with_bbt(zone_id, ring, building_by_type, zone_class="STUDY"):
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {
            "zoneId": zone_id,
            "zoneClass": zone_class,
            "buildingByType": building_by_type,
        },
    }


def _fc(features):
    return {"type": "FeatureCollection", "features": features}


# ---------------------------------------------------------------------------
# Toy network
#
#   "1" → "2" → "3"   (forward)
#   "3" → "2"          (return, so zone B → zone A routing works)
#
# Zone A covers nodes "1" and "2" (x ∈ [0,2), y ∈ [0,1])
# Zone B covers node  "3"         (x ∈ [2,4], y ∈ [0,1])
# ---------------------------------------------------------------------------

_ZONE_A_RING = [[0.0, 0.0], [2.0, 0.0], [2.0, 1.0], [0.0, 1.0], [0.0, 0.0]]
_ZONE_B_RING = [[2.0, 0.0], [4.0, 0.0], [4.0, 1.0], [2.0, 1.0], [2.0, 0.0]]


def _toy_network():
    return _fc(
        [
            _net_feature("1", "2", 36.0, 100.0, 500.0, flow=40.0, coords=[[0.5, 0.5], [1.5, 0.5]]),
            _net_feature("2", "3", 36.0, 100.0, 500.0, flow=50.0, coords=[[1.5, 0.5], [2.5, 0.5]]),
            _net_feature("3", "2", 36.0, 100.0, 500.0, flow=30.0, coords=[[2.5, 0.5], [1.5, 0.5]]),
        ]
    )


def _toy_feedlinks():
    return _fc(
        [
            _feedlink_feature("A", "2", "production", 10.0),
            _feedlink_feature("A", "2", "attraction", 10.0),
            _feedlink_feature("B", "3", "production", 10.0),
            _feedlink_feature("B", "3", "attraction", 10.0),
        ]
    )


def _toy_zones():
    return _fc(
        [
            _zone_polygon("A", _ZONE_A_RING),
            _zone_polygon("B", _ZONE_B_RING),
        ]
    )


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


class TestBuildMatrix:
    def test_returns_feature_collection(self):
        result = build_matrix(_toy_network(), _toy_feedlinks(), _toy_zones())
        assert result["type"] == "FeatureCollection"
        assert "features" in result

    def test_all_zone_pairs_present(self):
        """With 2 zones (A and B), every directed O→D pair must appear once.

        Expected pairs: A→B and B→A.
        """
        result = build_matrix(_toy_network(), _toy_feedlinks(), _toy_zones())
        features = result["features"]
        pairs = {(f["properties"]["fromZoneId"], f["properties"]["toZoneId"]) for f in features}
        # Both directed pairs must be present (A→B and B→A)
        assert ("A", "B") in pairs or ("B", "A") in pairs, (
            "At least one directed pair must be routable"
        )

    def test_trips_sum_to_one_per_origin(self):
        """The sum of trips leaving each origin zone must equal 1.0 (unit production).

        With unit production = 1.0 and proportional distribution, all trips from
        one origin always sum to exactly 1.0 (over reachable destinations).
        """
        result = build_matrix(_toy_network(), _toy_feedlinks(), _toy_zones())
        from_totals: dict[str, float] = {}
        for feat in result["features"]:
            props = feat["properties"]
            from_id = props["fromZoneId"]
            trips = float(props.get("tripFraction") or 0.0)
            from_totals[from_id] = from_totals.get(from_id, 0.0) + trips

        for zone_id, total in from_totals.items():
            assert total == pytest.approx(1.0, abs=1e-3), (
                f"Zone {zone_id!r} total outbound trips = {total}, expected 1.0"
            )

    def test_from_type_and_to_type_are_zone(self):
        """All features must have fromType='zone' and toType='zone'."""
        result = build_matrix(_toy_network(), _toy_feedlinks(), _toy_zones())
        for feat in result["features"]:
            props = feat["properties"]
            assert props["fromType"] == "zone"
            assert props["toType"] == "zone"

    def test_no_self_pairs(self):
        """A zone must never appear as its own destination (O == D)."""
        result = build_matrix(_toy_network(), _toy_feedlinks(), _toy_zones())
        for feat in result["features"]:
            props = feat["properties"]
            assert props["fromZoneId"] != props["toZoneId"], (
                f"Self-pair found for zone {props['fromZoneId']!r}"
            )

    def test_routes_property_present(self):
        """Every feature must have a non-empty 'routes' list."""
        result = build_matrix(_toy_network(), _toy_feedlinks(), _toy_zones())
        for feat in result["features"]:
            routes = feat["properties"].get("routes")
            assert isinstance(routes, list) and len(routes) > 0

    def test_empty_zones_returns_empty_fc(self):
        """Passing an empty zone file must return a FeatureCollection with no features."""
        empty_zones = _fc([])
        result = build_matrix(_toy_network(), _toy_feedlinks(), empty_zones)
        assert result["type"] == "FeatureCollection"
        assert result["features"] == []

    def test_single_zone_returns_empty_fc(self):
        """With only one zone there are no O≠D pairs to route — output must be empty."""
        single_zone = _fc([_zone_polygon("A", _ZONE_A_RING)])
        single_feedlinks = _fc(
            [
                _feedlink_feature("A", "2", "production", 10.0),
                _feedlink_feature("A", "2", "attraction", 10.0),
            ]
        )
        result = build_matrix(_toy_network(), single_feedlinks, single_zone)
        assert result["features"] == []

    def test_max_routes_respected(self):
        """The number of routes per pair must not exceed max_routes."""
        result = build_matrix(_toy_network(), _toy_feedlinks(), _toy_zones(), max_routes=1)
        for feat in result["features"]:
            routes = feat["properties"].get("routes", [])
            assert len(routes) <= 1, f"Expected ≤1 route, got {len(routes)}"

    def test_workers_1_same_result_as_default(self):
        """Sequential (workers=1) and parallel (workers=2) must produce identical results."""
        net, fl, zones = _toy_network(), _toy_feedlinks(), _toy_zones()
        result_seq = build_matrix(net, fl, zones, workers=1)
        result_par = build_matrix(net, fl, zones, workers=2)

        def _sorted_pairs(fc):
            return sorted(
                (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]) for f in fc["features"]
            )

        assert _sorted_pairs(result_seq) == _sorted_pairs(result_par)

        # tripFraction values must also match
        seq_trips = {
            (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"][
                "tripFraction"
            ]
            for f in result_seq["features"]
        }
        par_trips = {
            (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"][
                "tripFraction"
            ]
            for f in result_par["features"]
        }
        for key in seq_trips:
            assert seq_trips[key] == pytest.approx(par_trips[key], abs=1e-6), (
                f"tripFraction mismatch for pair {key}: seq={seq_trips[key]}, par={par_trips[key]}"
            )

    def test_worker_share_divides_worker_count(self):
        """A worker_share > 1 must never yield more workers than the sole-user case."""
        sole = _auto_workers(1)
        shared = _auto_workers(2)
        assert sole >= 1
        assert shared >= 1
        assert shared <= sole

    def test_progress_label_is_logged(self, caplog):
        """build_matrix must emit labelled routing-progress lines."""
        import logging

        with caplog.at_level(
            logging.INFO, logger="gmt_routing.matrix_builder.core.matrix_builder_core"
        ):
            build_matrix(
                _toy_network(), _toy_feedlinks(), _toy_zones(), workers=1, progress_label="CAR"
            )
        progress_lines = [r.message for r in caplog.records if "routed" in r.message]
        assert progress_lines, "expected at least one progress line"
        assert all("[CAR]" in line for line in progress_lines)

    def test_route_nodepath_includes_intermediate_waypoints(self):
        """nodePath for the A→B route must include the intermediate node '2'.

        The network has links 1→2→3, with zone A attached at node 2 and zone B
        at node 3.  The A→B route must traverse node '2' before reaching '3'.

        Route geometry is no longer pre-computed; consumers reconstruct it from
        linkPath/nodePath joined with the network file.
        """
        # Network identical to the toy network but with a curved 2→3 link
        # (kept as context; the bend point is now in the network file, not
        #  the routes file).
        curved_net = _fc(
            [
                _net_feature(
                    "1", "2", 36.0, 100.0, 500.0, flow=40.0, coords=[[0.5, 0.5], [1.5, 0.5]]
                ),
                _net_feature(
                    "2",
                    "3",
                    36.0,
                    100.0,
                    500.0,
                    flow=50.0,
                    coords=[[1.5, 0.5], [2.0, 0.8], [2.5, 0.5]],
                ),
                _net_feature(
                    "3", "2", 36.0, 100.0, 500.0, flow=30.0, coords=[[2.5, 0.5], [1.5, 0.5]]
                ),
            ]
        )
        result = build_matrix(curved_net, _toy_feedlinks(), _toy_zones(), workers=1)

        ab_feature = next(
            (
                f
                for f in result["features"]
                if f["properties"]["fromZoneId"] == "A" and f["properties"]["toZoneId"] == "B"
            ),
            None,
        )
        assert ab_feature is not None, "A→B route not found"
        assert ab_feature["geometry"] is None, (
            "Route geometry must be null; consumers reconstruct from linkPath + network"
        )

        routes = ab_feature["properties"]["routes"]
        assert len(routes) >= 1, "Expected at least one route for A→B"
        node_path = routes[0]["nodePath"]
        assert "2" in node_path, (
            "Node '2' missing from A→B nodePath — routing must traverse node '2' en route to '3'"
        )


# ---------------------------------------------------------------------------
# motifRatio tests
# ---------------------------------------------------------------------------


class TestMotifRatio:
    """motifRatio is present on every OD feature and reflects buildingByType."""

    def _zones_with_bbt(self):
        return _fc(
            [
                _zone_polygon_with_bbt("A", _ZONE_A_RING, {"house": 3000.0, "work": 1000.0}),
                _zone_polygon_with_bbt("B", _ZONE_B_RING, {"shopping": 2000.0, "other": 2000.0}),
            ]
        )

    def test_motif_ratio_present_on_all_features(self):
        """Every OD feature must carry a motifRatio dict."""
        result = build_matrix(_toy_network(), _toy_feedlinks(), self._zones_with_bbt(), workers=1)
        for feat in result["features"]:
            props = feat["properties"]
            assert "motifRatio" in props, (
                f"motifRatio missing on pair {props.get('fromZoneId')}→{props.get('toZoneId')}"
            )
            ratio = props["motifRatio"]
            assert isinstance(ratio, dict) and len(ratio) > 0

    def test_motif_ratio_normalised(self):
        """motifRatio values must sum to approximately 1.0 for every feature."""
        result = build_matrix(_toy_network(), _toy_feedlinks(), self._zones_with_bbt(), workers=1)
        for feat in result["features"]:
            ratio = feat["properties"]["motifRatio"]
            assert sum(ratio.values()) == pytest.approx(1.0, abs=1e-4), (
                f"motifRatio does not sum to 1.0: {ratio}"
            )

    def test_motif_ratio_uses_destination_zone(self):
        """A→B pair: ratio must reflect zone B's buildingByType (shopping + other → 0.5 each)."""
        result = build_matrix(_toy_network(), _toy_feedlinks(), self._zones_with_bbt(), workers=1)
        ab = next(
            f
            for f in result["features"]
            if f["properties"]["fromZoneId"] == "A" and f["properties"]["toZoneId"] == "B"
        )
        ratio = ab["properties"]["motifRatio"]
        assert ratio.get("shopping") == pytest.approx(0.5, abs=1e-4)
        assert ratio.get("other") == pytest.approx(0.5, abs=1e-4)
        assert "house" not in ratio

    def test_motif_ratio_fallback_to_origin_when_dest_boundary(self):
        """When destination is BOUNDARY, ratio falls back to origin zone's buildingByType."""
        zones = _fc(
            [
                _zone_polygon_with_bbt("A", _ZONE_A_RING, {"house": 4000.0, "work": 1000.0}),
                _zone_polygon_with_bbt("B", _ZONE_B_RING, {}, zone_class="BOUNDARY"),
            ]
        )
        result = build_matrix(_toy_network(), _toy_feedlinks(), zones, workers=1)
        ab = next(
            (
                f
                for f in result["features"]
                if f["properties"]["fromZoneId"] == "A" and f["properties"]["toZoneId"] == "B"
            ),
            None,
        )
        if ab is None:
            pytest.skip("A→B pair not routable in this fixture")
        ratio = ab["properties"]["motifRatio"]
        # Must use origin A's buildingByType: house=4000, work=1000 → 0.8 / 0.2
        assert ratio.get("house") == pytest.approx(0.8, abs=1e-4)
        assert ratio.get("work") == pytest.approx(0.2, abs=1e-4)

    def test_motif_ratio_no_bbt_gives_unclassified(self):
        """Zones without buildingByType produce motifRatio = {"unclassified": 1.0}."""
        result = build_matrix(_toy_network(), _toy_feedlinks(), _toy_zones(), workers=1)
        for feat in result["features"]:
            ratio = feat["properties"]["motifRatio"]
            assert ratio == {"unclassified": 1.0}, f"Expected unclassified fallback, got {ratio}"


# ---------------------------------------------------------------------------
# Real Spectrum HB OD override tests
# ---------------------------------------------------------------------------


class TestHbOverride:
    """hb_od replaces absolute trips for internal pairs; others stay synthetic."""

    def test_hb_pair_overrides_absolute_trips(self):
        """An internal pair present in hb_od gets trips + tripSource from Spectrum."""
        hb_od = {("A", "B"): 123.0}
        result = build_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(), workers=1, hb_od=hb_od
        )
        ab = next(
            (
                f
                for f in result["features"]
                if f["properties"]["fromZoneId"] == "A" and f["properties"]["toZoneId"] == "B"
            ),
            None,
        )
        assert ab is not None, "A→B pair not routable"
        assert ab["properties"]["trips"] == pytest.approx(123.0)
        assert ab["properties"]["tripSource"] == "spectrum-hb"

    def test_missing_internal_pair_falls_back_to_synthetic(self):
        """An internal pair absent from hb_od keeps the synthetic estimate."""
        hb_od = {("A", "B"): 123.0}
        result = build_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(), workers=1, hb_od=hb_od
        )
        ba = next(
            (
                f
                for f in result["features"]
                if f["properties"]["fromZoneId"] == "B" and f["properties"]["toZoneId"] == "A"
            ),
            None,
        )
        assert ba is not None, "B→A pair not routable"
        assert ba["properties"]["tripSource"] == "synthetic"

    def test_boundary_pair_not_overridden(self):
        """A BOUNDARY destination is never overridden even if present in hb_od."""
        zones = _fc(
            [
                _zone_polygon("A", _ZONE_A_RING),
                _zone_polygon_with_bbt("B", _ZONE_B_RING, {}, zone_class="BOUNDARY"),
            ]
        )
        hb_od = {("A", "B"): 999.0}
        result = build_matrix(_toy_network(), _toy_feedlinks(), zones, workers=1, hb_od=hb_od)
        ab = next(
            (
                f
                for f in result["features"]
                if f["properties"]["fromZoneId"] == "A" and f["properties"]["toZoneId"] == "B"
            ),
            None,
        )
        if ab is None:
            pytest.skip("A→B pair not routable in this fixture")
        assert ab["properties"]["tripSource"] == "synthetic"

    def test_no_hb_od_all_synthetic(self):
        """Without hb_od every feature must be tagged synthetic."""
        result = build_matrix(_toy_network(), _toy_feedlinks(), _toy_zones(), workers=1)
        for feat in result["features"]:
            assert feat["properties"]["tripSource"] == "synthetic"
            assert "trips" in feat["properties"]
