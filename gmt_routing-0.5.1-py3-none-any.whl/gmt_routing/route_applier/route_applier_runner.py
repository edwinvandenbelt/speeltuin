"""Local debug runner for route_applier.

Adds OD trip flows onto network link flow values and writes the updated
network GeoJSON.  No Lambda handler involved.

Usage
-----
    python -m route_applier.route_applier_runner \\
        --network-file output/deventer/AREA_ID-NETWORK-CAR.parquet \\
        --od-file      output/deventer/AREA_ID-OD-CAR.parquet

    # Write to a different output location:
    python -m route_applier.route_applier_runner \\
        --network-file output/deventer/AREA_ID-NETWORK-CAR.parquet \\
        --od-file      output/deventer/AREA_ID-OD-CAR.parquet \\
        --output-geojson output/deventer/AREA_ID-NETWORK-ASSIGNED-CAR.parquet

    # Only update links with ≥ 1 accumulated trip:
    python -m route_applier.route_applier_runner \\
        --network-file ... --od-file ... --min-link-trips 1.0

Prerequisites
-------------
* AWS credentials available in the environment or a .env file
  (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for route_applier.  Adds OD trip flows onto network link flow values."
        )
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="URI of the network GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--od-file",
        required=True,
        metavar="URI",
        help="URI of the OD matrix GeoJSON file (output of route_explorer / matrix_builder).",
    )
    parser.add_argument(
        "--output-geojson",
        default=None,
        metavar="URI",
        help=(
            "URI for the updated network GeoJSON output.  "
            "Defaults to --network-file (overwrites in place)."
        ),
    )
    parser.add_argument(
        "--min-link-trips",
        type=float,
        default=0.0,
        metavar="FLOAT",
        help="Minimum accumulated trips to update a link (default 0 = update all).",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_routing.route_applier.core.route_applier_core import add_od_flows

    # 1. Read inputs
    print(f"Reading network : {args.network_file}")
    network_fc = from_geoparquet(_read_uri(args.network_file))
    print(f"Reading OD      : {args.od_file}")
    od_fc = from_geoparquet(_read_uri(args.od_file))

    # 2. Run core
    print(f"Applying OD flows (min_link_trips={args.min_link_trips}) ...")
    updated_fc, route_report = add_od_flows(network_fc, od_fc, args.min_link_trips)

    n_links_updated = sum(
        1
        for feat in (updated_fc.get("features") or [])
        if (feat.get("properties") or {}).get("addedFlow") is not None
    )
    print(f"  Routes assigned : {len(route_report)}")
    print(f"  Links updated   : {n_links_updated}")

    if route_report:
        print("  Top 5 routes by trips:")
        for r in route_report[:5]:
            print(
                f"    {r['fromId']} → {r['toId']}  "
                f"trips={r['trips']:.4f}  "
                f"links={len(r.get('linkPath') or [])}"
            )

    # 3. Write output (default: overwrite the input network file)
    out_uri = args.output_geojson if args.output_geojson else args.network_file
    print(f"Writing output  : {out_uri}")
    _write_uri(out_uri, to_geoparquet(updated_fc))
    print("Done.")


if __name__ == "__main__":
    main()
