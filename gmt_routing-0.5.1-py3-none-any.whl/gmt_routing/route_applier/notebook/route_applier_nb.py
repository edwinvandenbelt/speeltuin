# Databricks notebook source
# ---------------------------------------------------------------------------
# route_applier_nb.py — Databricks notebook interface for OD flow assignment.
#
# This notebook:
#   1. Reads widget parameters (network_uri, od_uri, output_uri, min_link_trips).
#   2. Reads the network and OD GeoJSON files (s3:// or local path).
#   3. Calls add_od_flows to add OD trip flows onto network link flow values.
#   4. Writes the updated network GeoJSON to output_uri.
#   5. Prints a summary of assigned routes and updated links.
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("route_applier_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()
except Exception:
    pass

dbutils.widgets.text(
    "network_uri",
    "",
    "Full URI of the input network GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(
    "od_uri",
    "",
    "Full URI of the OD matrix GeoJSON (output of route_explorer / matrix_builder)",
)
dbutils.widgets.text(
    "output_uri",
    "",
    "Full URI for the output network GeoJSON (leave blank to overwrite network_uri)",
)
dbutils.widgets.text(
    "min_link_trips",
    "0",
    "Minimum accumulated trips required to update a link (default 0 = update all)",
)
dbutils.widgets.text(
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_routing.route_applier.core.route_applier_core import add_od_flows

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

NETWORK_URI = dbutils.widgets.get("network_uri").strip()
OD_URI = dbutils.widgets.get("od_uri").strip()
OUTPUT_URI = dbutils.widgets.get("output_uri").strip() or NETWORK_URI
MIN_LINK_TRIPS = float(dbutils.widgets.get("min_link_trips").strip() or "0")

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty — provide a full network URI.")
if not OD_URI:
    raise ValueError("Widget 'od_uri' is empty — provide a full OD matrix URI.")

logger.info(
    "network_uri=%s  od_uri=%s  output_uri=%s  min_link_trips=%s",
    NETWORK_URI,
    OD_URI,
    OUTPUT_URI,
    MIN_LINK_TRIPS,
)

# COMMAND ----------
# ── S3 helpers ────────────────────────────────────────────────────────────────

import boto3


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Route Applier
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
print(f"Starting  {_t_start.isoformat()}")
print(f"min_link_trips={MIN_LINK_TRIPS}")
print()

_network_fc = json.loads(_read_uri(NETWORK_URI))
_od_fc = json.loads(_read_uri(OD_URI))

_updated_fc, _route_report = add_od_flows(_network_fc, _od_fc, MIN_LINK_TRIPS)

_payload = json.dumps(_updated_fc, ensure_ascii=False).encode("utf-8")
_write_uri(OUTPUT_URI, _payload)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("Done in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60
_n_routes = len(_route_report)
_n_links_updated = sum(
    1
    for feat in (_updated_fc.get("features") or [])
    if (feat.get("properties") or {}).get("addedFlow") is not None
)

print(_SEP)
print(f"Route applier complete — {_total_elapsed:.1f}s total")
print(_SEP)
print()
print(f"  Routes assigned  : {_n_routes}")
print(f"  Links updated    : {_n_links_updated}")
print(f"  min_link_trips   : {MIN_LINK_TRIPS}")
print(f"  Output URI       : {OUTPUT_URI}")
print()

if _route_report:
    print("  Top 5 routes by trips:")
    for _r in _route_report[:5]:
        print(
            f"    {_r['fromId']} → {_r['toId']}  "
            f"trips={_r['trips']:.4f}  "
            f"links={len(_r.get('linkPath') or [])}"
        )

print()
print(_SEP)
