"""Pure-Python route_applier core — no I/O, no boto3, no external deps.

Adds OD trip flows onto the ``flow`` property of network links.

For each OD pair **all** routes are walked.  Each route contributes
``route["trips"]`` trips to every network link on its ``nodePath``.  Feedlink
edges (virtual zone nodes) carry no ``flow`` and are silently skipped.

After summing the increments across all routes and OD pairs, a per-link
``min_link_trips`` threshold is applied: links whose total added trips fall
below the threshold are left unchanged.

The assignment is **additive**: existing ``flow`` values are preserved and the
new demand is added on top.  This differs from ``all_or_nothing_assigner``,
which resets all flows to zero before assigning.

Public API
----------
add_od_flows(network_fc, od_fc, min_link_trips=0.0) -> tuple[dict, list[dict]]
    Returns a tuple of:
    - A new FeatureCollection with updated ``flow`` and ``addedFlow`` values.
    - A report: list of dicts, one per changed link, with keys
      ``fromNode``, ``toNode``, ``linkId``, ``originalFlow``,
      ``addedFlow``, ``newFlow``.
"""

from __future__ import annotations

import copy
import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Output field definitions (authoritative)
# ---------------------------------------------------------------------------

ROUTE_APPLIER_PROPERTIES: tuple[str, ...] = (
    "fromNode",
    "toNode",
    "flow",
    "addedFlow",
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _build_link_index(network_fc: dict) -> dict[tuple[str, str], int]:
    """Return ``{(fromNode, toNode): feature_index}`` for all network links."""
    index: dict[tuple[str, str], int] = {}
    for i, feat in enumerate(network_fc.get("features", [])):
        props = feat.get("properties") or {}
        fn = str(props.get("fromNode", "")).strip()
        tn = str(props.get("toNode", "")).strip()
        if fn and tn:
            index[(fn, tn)] = i
    return index


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def add_od_flows(
    network_fc: dict,
    od_fc: dict,
    min_link_trips: float = 0.0,
) -> tuple[dict, list[dict]]:
    """Add OD trip flows onto network link ``flow`` values.

    For each OD feature **all** routes are walked edge by edge.  Each route's
    ``nodePath`` is used together with its own ``trips`` value (the per-route
    share produced by ``route_explorer``).  The contributions from all
    routes and all OD pairs are **summed per link** before being written.

    A link is only updated when its total accumulated trips meet or exceed
    *min_link_trips*.  This threshold is applied at **link level** — after
    full summation — so a small per-route contribution that is part of a
    larger aggregate is never discarded prematurely.

    Each updated link receives:

    * ``flow``      — original flow + added trips (rounded to 6 decimal places)
    * ``addedFlow`` — the trips added in this call (rounded to 6 decimal
      places); absent on links that were not updated.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection.  Links must have ``fromNode``,
        ``toNode``, and ``flow`` properties.  ``flow`` may be absent (treated
        as 0).
    od_fc:
        OD GeoJSON FeatureCollection as produced by ``route_explorer``.
        Each route inside ``properties.routes`` must have a ``nodePath`` list
        and a ``trips`` value.  Routes without a ``nodePath`` are skipped.
    min_link_trips:
        Minimum total added trips required for a link to be updated.  Links
        below this threshold keep their original ``flow`` and receive no
        ``addedFlow`` property.  Defaults to ``0.0`` (all links updated).

    Returns
    -------
    tuple[dict, list[dict]]
        A 2-tuple of:

        * The updated GeoJSON FeatureCollection (new object, original not
          mutated).
        * A report list — one entry per **assigned route** — sorted descending
          by ``trips``.  Each entry is a dict with keys:

          - ``fromId``     — OD pair origin ID (read from ``fromZoneId``)
          - ``toId``       — OD pair destination ID (read from ``toZoneId``)
          - ``trips``      — trips assigned via this route (may be negative)
          - ``travelTime`` — route travel time in seconds (``None`` if absent)
          - ``distance``   — route distance in metres (``None`` if absent)
          - ``linkPath``   — list of link IDs traversed (may be empty)
          - ``nodePath``   — list of node IDs traversed

          Routes whose ``trips`` are zero are skipped.  Negative trips reduce
          link flows.  The ``min_link_trips`` threshold applies only to
          positive deltas; negative deltas are always applied.
    """
    link_index = _build_link_index(network_fc)

    # Accumulate flow increments by feature index and build route report
    flow_delta: dict[int, float] = {}
    route_report: list[dict] = []

    n_routes_skipped = 0

    for feat in od_fc.get("features", []):
        props = feat.get("properties") or {}
        from_id = props.get("fromZoneId", "")
        to_id = props.get("toZoneId", "")
        routes = props.get("routes") or []

        for route in routes:
            route_trips = float(route.get("trips") or 0.0)
            if route_trips == 0.0:
                continue

            node_path: list[str] = route.get("nodePath") or []
            if len(node_path) < 2:
                n_routes_skipped += 1
                logger.debug(
                    "OD pair (%s → %s) has a route with no usable nodePath — skipped.",
                    from_id,
                    to_id,
                )
                continue

            for i in range(len(node_path) - 1):
                u = str(node_path[i])
                v = str(node_path[i + 1])
                idx = link_index.get((u, v))
                if idx is not None:
                    flow_delta[idx] = flow_delta.get(idx, 0.0) + route_trips

            route_report.append(
                {
                    "fromId": from_id,
                    "toId": to_id,
                    "trips": round(route_trips, 4),
                    "travelTime": route.get("travelTime"),
                    "distance": route.get("distance"),
                    "linkPath": route.get("linkPath") or [],
                    "nodePath": node_path,
                }
            )

    route_report.sort(key=lambda r: r["trips"], reverse=True)

    # Apply minimum threshold at link level
    if min_link_trips > 0.0:
        flow_delta = {idx: d for idx, d in flow_delta.items() if d >= min_link_trips or d < 0.0}

    logger.info(
        "add_od_flows: %d routes assigned, %d skipped (no nodePath), "
        "%d links updated (min_link_trips=%.4g)",
        len(route_report),
        n_routes_skipped,
        len(flow_delta),
        min_link_trips,
    )

    if not flow_delta:
        return dict(network_fc), route_report

    # Deep-copy features so the original is not mutated
    features = copy.deepcopy(network_fc.get("features", []))

    for idx, delta in flow_delta.items():
        feat_props = features[idx]["properties"]
        original = float(feat_props.get("flow") or 0.0)
        feat_props["flow"] = round(original + delta, 6)
        feat_props["addedFlow"] = round(delta, 6)

    out_props = dict(network_fc.get("properties") or {})
    existing = list(out_props.get("fields") or [])
    for field in ROUTE_APPLIER_PROPERTIES:
        if field not in existing:
            existing.append(field)
    out_props["fields"] = existing

    return {**network_fc, "features": features, "properties": out_props}, route_report
