"""Request models for the od_support_matrices_creator Lambda."""

from __future__ import annotations

from pydantic import BaseModel, Field


class HandlerInput(BaseModel):
    """Validated input for the od_support_matrices_creator handler."""

    network_file: str = Field(..., description="S3 URI or local path of the network GeoJSON file.")
    feedlink_file: str = Field(
        ..., description="S3 URI or local path of the feedlinks GeoJSON file."
    )
    zone_file: str | None = Field(
        None,
        description=(
            "S3 URI or local path of the zones GeoJSON file. "
            "Required in standalone mode; not used in enrichment mode (od_file provided)."
        ),
    )
    od_file: str | None = Field(
        None,
        description=(
            "S3 URI or local path of an existing OD GeoJSON to enrich with remainingCap. "
            "When provided, activates enrichment mode: remainingCap is added to each OD "
            "feature and the result is written back to output_geojson (or od_file if omitted). "
            "zone_file is not required in this mode."
        ),
    )
    output_csv: str | None = Field(
        None, description="(Standalone mode only) S3 URI or local path for the output CSV file."
    )
    output_geojson: str | None = Field(
        None,
        description=(
            "S3 URI or local path for the output GeoJSON file. "
            "In enrichment mode, defaults to od_file (in-place overwrite). "
            "In standalone mode, omit to skip GeoJSON output."
        ),
    )
