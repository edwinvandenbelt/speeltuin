"""Local debug runner for od_support_matrices_creator.

Calls od_support_matrices_creator_core functions directly — no Lambda handler involved.

Two modes of operation
----------------------

**Standalone mode** (default — no ``--od-file``):
    Builds a full OD support matrix from scratch using ``--network-file``,
    ``--feedlink-file``, and ``--zone-file``, then writes the result to
    ``--output-csv`` and/or ``--output-geojson``.

    python -m od_support_matrices_creator.od_support_matrices_creator_runner \\
        --network-file /tmp/deventer-centrum-NETWORK-CAR.geojson \\
        --feedlink-file /tmp/deventer-centrum-FEEDLINK-CAR.geojson \\
        --zone-file /tmp/deventer-centrum-ZONE-CAR.geojson \\
        --output-csv /tmp/matrix.csv \\
        --output-geojson /tmp/matrix.geojson

**Enrichment mode** (``--od-file`` provided):
    Reads an existing OD GeoJSON, routes through the network to compute
    ``remainingCap`` for each OD pair, and writes the enriched GeoJSON back
    to ``--od-file`` (or ``--output-geojson`` if specified).  ``--zone-file``
    is not required in this mode.

    python -m od_support_matrices_creator.od_support_matrices_creator_runner \\
        --network-file /tmp/deventer-centrum-NETWORK-CAR.geojson \\
        --feedlink-file /tmp/deventer-centrum-FEEDLINK-CAR.geojson \\
        --od-file /tmp/deventer-centrum-OD-CAR.geojson

    # S3 inputs and outputs:
    python -m od_support_matrices_creator.od_support_matrices_creator_runner \\
        --network-file s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.geojson \\
        --feedlink-file s3://gmp-networks/network/deventer-centrum-FEEDLINK-CAR.geojson \\
        --od-file s3://gmp-networks/od/deventer-centrum-OD-CAR.geojson

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for od_support_matrices_creator (calls core directly). "
            "When --od-file is provided, runs in enrichment mode: adds remainingCap "
            "to each OD feature and writes the result back in place. "
            "Otherwise runs in standalone mode: builds a full support matrix from scratch."
        )
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="Full URI of the plain network GeoJSON file (no feedlinks; s3:// or local path).",
    )
    parser.add_argument(
        "--feedlink-file",
        required=True,
        metavar="URI",
        help="Full URI of the feedlinks GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--zone-file",
        default=None,
        metavar="URI",
        help=(
            "Full URI of the zones GeoJSON file (s3:// or local path). "
            "Required in standalone mode; not used in enrichment mode (--od-file)."
        ),
    )
    parser.add_argument(
        "--od-file",
        default=None,
        metavar="URI",
        help=(
            "Full URI of an existing OD GeoJSON to enrich with remainingCap. "
            "When provided, activates enrichment mode: the file is read, enriched, "
            "and written back to this URI (or --output-geojson if specified). "
            "--zone-file is not required in this mode."
        ),
    )
    parser.add_argument(
        "--output-csv",
        default=None,
        metavar="URI",
        help="(Standalone mode only) URI for the output CSV file. Omit to skip CSV output.",
    )
    parser.add_argument(
        "--output-geojson",
        default=None,
        metavar="URI",
        help=(
            "URI for the output GeoJSON file. "
            "In enrichment mode, defaults to --od-file (in-place overwrite). "
            "In standalone mode, omit to skip GeoJSON output."
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    # ------------------------------------------------------------------
    # Enrichment mode
    # ------------------------------------------------------------------
    if args.od_file:
        from gmt_shared.geoparquet import from_geoparquet

        from gmt_routing.od_support_matrices_creator.core.od_support_matrices_creator_core import (
            enrich_od_geojson,
            enriched_od_to_csv,
        )

        output_uri = args.output_geojson or args.od_file

        print(f"Reading network  : {args.network_file}")
        network_fc = from_geoparquet(_read_uri(args.network_file))

        print(f"Reading feedlinks: {args.feedlink_file}")
        feedlinks_fc = from_geoparquet(_read_uri(args.feedlink_file))

        print(f"Reading OD       : {args.od_file}")
        od_fc = from_geoparquet(_read_uri(args.od_file))

        n_features = len(od_fc.get("features", []))
        print(f"Enriching {n_features} OD features with remainingCap ...")
        enriched_fc = enrich_od_geojson(od_fc, network_fc, feedlinks_fc)

        print(f"Writing GeoJSON  : {output_uri}")
        _write_uri(
            output_uri,
            json.dumps(enriched_fc, ensure_ascii=False).encode("utf-8"),
            "application/geo+json",
        )

        if args.output_csv:
            print(f"Writing CSV      : {args.output_csv}")
            csv_text = enriched_od_to_csv(enriched_fc)
            _write_uri(args.output_csv, csv_text.encode("utf-8"), "text/csv")

        print()
        print(f"Done. {n_features} OD features enriched.")
        return

    # ------------------------------------------------------------------
    # Standalone mode
    # ------------------------------------------------------------------
    if not args.zone_file:
        parser.error("--zone-file is required in standalone mode (when --od-file is not provided).")

    if not args.output_csv and not args.output_geojson:
        print(
            "[warning] Neither --output-csv nor --output-geojson specified. "
            "Matrix will be computed but no output will be written.",
            file=sys.stderr,
        )

    from gmt_shared.geoparquet import from_geoparquet

    from gmt_routing.od_support_matrices_creator.core.od_support_matrices_creator_core import (
        build_graph,
        compute_matrix,
        extract_zone_centroids,
        extract_zone_ids,
        records_to_csv,
        records_to_geojson,
    )

    print(f"Reading network  : {args.network_file}")
    network_fc = from_geoparquet(_read_uri(args.network_file))

    print(f"Reading feedlinks: {args.feedlink_file}")
    feedlinks_fc = from_geoparquet(_read_uri(args.feedlink_file))

    print(f"Reading zones    : {args.zone_file}")
    zones_fc = from_geoparquet(_read_uri(args.zone_file))

    print("Building graph ...")
    adj, zone_node_ids, zone_centroids = build_graph(network_fc, feedlinks_fc)

    # Enrich centroids from the zone file
    zone_centroids.update(extract_zone_centroids(zones_fc))
    zone_ids = extract_zone_ids(zones_fc)

    print(f"Computing matrix : {len(zone_ids)} zones ({len(zone_ids) ** 2} pairs) ...")
    records = compute_matrix(zone_ids, zone_node_ids, zone_centroids, adj)

    if args.output_csv:
        print(f"Writing CSV      : {args.output_csv}")
        csv_text = records_to_csv(records)
        _write_uri(args.output_csv, csv_text.encode("utf-8"), "text/csv")

    if args.output_geojson:
        print(f"Writing GeoJSON  : {args.output_geojson}")
        geojson_obj = records_to_geojson(records, zone_centroids)
        _write_uri(
            args.output_geojson,
            json.dumps(geojson_obj, ensure_ascii=False).encode("utf-8"),
            "application/geo+json",
        )

    n_reachable = sum(1 for r in records if r["travelTime"] is not None)
    n_pairs = len(records)
    print()
    print(
        f"Done. {n_pairs} pairs, {n_reachable} reachable "
        f"({n_pairs - n_reachable} unreachable / diagonal)."
    )


if __name__ == "__main__":
    main()
