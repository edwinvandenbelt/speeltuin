"""Pure-Python WKD (NDW Wegkenmerkendatabase) fetcher core — no I/O, no boto3.

Fetches road-width attributes from the Dutch NDW WKD dataset keyed by
``WVK_ID`` (the NWB road-segment identifier).  Because Spectrum ``linkId``
values do **not** necessarily equal ``WVK_ID``, matching is done spatially:
WKD segments are compared to network link geometries and attached when they
overlap within a tolerance.

Each enriched network link records the matched ``WVK_ID`` value(s) in a
``wvkIds`` list so future WKD datasets (speeds, bebouwde kom, crossings, …)
can be joined directly on those identifiers.

Public API
----------
build_wegbreedtes_sql(catalog, schema) -> str
    Return the parameterised Databricks SQL for WKD Wegbreedtes.
rows_to_wkd_features(rows, col_names) -> list[dict]
    Convert raw Databricks rows into GeoJSON WKD line features.
match_wkd_features_to_network(wkd_features, network_fc, max_distance_m) -> dict[int, dict]
    Return a mapping ``{link_id: {"width", "minWidth", "maxWidth",
    "reliability", "wvkIds"}}`` for the network links that match a WKD
    segment.
apply_wkd_road_widths(network_fc, lookup) -> dict
    Set ``roadWidthM`` / ``roadWidthMinM`` / ``roadWidthMaxM`` /
    ``roadWidthReliability`` / ``wvkIds`` on each matching network feature.
fetch_wkd_road_widths(cursor, polygon_json, *, catalog, schema) -> dict[int, dict]
    High-level entry: query + match, returning the link lookup.
"""

from __future__ import annotations

import json
import logging

from gmt_network_enrichment.wkd_fetcher.domain.sql import (
    DEFAULT_CATALOG,
    DEFAULT_SCHEMA,
    build_wegbreedtes_sql,
)

logger = logging.getLogger(__name__)

#: Approximate meters per degree at mid-latitudes (used for quick bounding).
_METERS_PER_DEGREE: float = 111000.0

#: Default maximum distance (in metres) between a WKD segment and a network link
#: for them to be considered a match.
DEFAULT_MATCH_TOLERANCE_M: float = 15.0


def rows_to_wkd_features(rows: list[tuple], col_names: list[str]) -> list[dict]:
    """Convert WKD Wegbreedtes query rows into GeoJSON LineString features.

    Columns expected: ``WVK_ID``, ``VAN``, ``TOT``, ``BREEDTE``,
    ``BRDT_MIN``, ``BRDT_MAX``, ``BETR``, ``geom`` (GeoJSON in EPSG:4326).
    Width columns arrive as strings from Databricks and are parsed to floats
    where possible.
    """
    cols = [c.lower() for c in col_names]

    def _idx(name: str) -> int | None:
        try:
            return cols.index(name)
        except ValueError:
            return None

    wvk_idx = _idx("wvk_id")
    van_idx = _idx("van")
    tot_idx = _idx("tot")
    breedte_idx = _idx("breedte")
    min_idx = _idx("brdt_min")
    max_idx = _idx("brdt_max")
    betr_idx = _idx("betr")
    geom_idx = _idx("geom")

    def _float(val):
        if val is None:
            return None
        try:
            return float(str(val).replace(",", "."))
        except (TypeError, ValueError):
            return None

    def _str(val):
        if val is None:
            return None
        return str(val)

    features: list[dict] = []
    for row in rows:
        if wvk_idx is None:
            continue
        wvk_id = row[wvk_idx]
        if wvk_id is None:
            continue

        geom_val = row[geom_idx] if geom_idx is not None else None
        geom = json.loads(geom_val) if isinstance(geom_val, str) else geom_val
        if not geom:
            continue

        van = row[van_idx] if van_idx is not None else 0
        tot = row[tot_idx] if tot_idx is not None else 0
        span = (int(tot) if tot is not None else 0) - (int(van) if van is not None else 0)

        features.append(
            {
                "type": "Feature",
                "geometry": geom,
                "properties": {
                    "wvkId": int(wvk_id),
                    "van": int(van) if van is not None else 0,
                    "tot": int(tot) if tot is not None else 0,
                    "span": span,
                    "width": _float(row[breedte_idx]) if breedte_idx is not None else None,
                    "minWidth": _float(row[min_idx]) if min_idx is not None else None,
                    "maxWidth": _float(row[max_idx]) if max_idx is not None else None,
                    "reliability": _str(row[betr_idx]) if betr_idx is not None else None,
                },
            }
        )

    return features


def _linestring_from_feature(feat: dict):
    """Return a shapely LineString for a GeoJSON feature, or None."""
    try:
        from shapely import LineString
    except ImportError:
        return None

    geom = feat.get("geometry") or {}
    coords = geom.get("coordinates") or []
    if geom.get("type") != "LineString" or len(coords) < 2:
        return None
    try:
        return LineString([(float(c[0]), float(c[1])) for c in coords])
    except (TypeError, ValueError):
        return None


def match_wkd_features_to_network(
    wkd_features: list[dict],
    network_fc: dict,
    max_distance_m: float = DEFAULT_MATCH_TOLERANCE_M,
) -> dict[int, dict]:
    """Spatially match WKD line segments to network links.

    For each network link, all WKD segments within *max_distance_m* are
    collected.  The segment with the largest linear span (``TOT - VAN``) is
    chosen as the representative width for that link.  The set of matching
    ``WVK_ID`` values is always recorded on the link as ``wvkIds``.

    Returns a mapping ``{link_id: {"width", "minWidth", "maxWidth",
    "reliability", "wvkIds"}}``.  Only links with at least one match are
    included.
    """
    try:
        from shapely.geometry.base import BaseGeometry as _BaseGeometry
    except ImportError:
        logger.warning("shapely not available; skipping WKD network matching")
        return {}

    max_distance_deg = max_distance_m / _METERS_PER_DEGREE

    # Build shapely LineStrings for network links; keep only integer link IDs.
    network_lines: list[tuple[int, _BaseGeometry, dict]] = []
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        link_id_raw = props.get("linkId")
        if link_id_raw is None:
            continue
        try:
            link_id = int(link_id_raw)
        except (TypeError, ValueError):
            continue

        line = _linestring_from_feature(feat)
        if line is None:
            continue
        network_lines.append((link_id, line, props))

    if not network_lines:
        logger.warning("No LineString links found in network; skipping WKD matching")
        return {}

    # Collect candidate WKD matches per network link.
    candidates: dict[int, list[tuple[int, dict]]] = {}
    for wkd in wkd_features:
        wkd_line = _linestring_from_feature(wkd)
        if wkd_line is None:
            continue
        wprops = wkd.get("properties") or {}
        span = wprops.get("span", 0) or 0

        for link_id, net_line, _ in network_lines:
            distance = wkd_line.distance(net_line)
            if distance <= max_distance_deg:
                candidates.setdefault(link_id, []).append((span, wprops))

    # Pick the best (largest span) WKD segment per link and gather wvkIds.
    lookup: dict[int, dict] = {}
    for link_id, spans_and_props in candidates.items():
        spans_and_props.sort(key=lambda x: x[0], reverse=True)
        best = spans_and_props[0][1]
        wvk_ids = sorted(
            {int(wvk_id) for _, p in spans_and_props if (wvk_id := p.get("wvkId")) is not None}  # type: ignore[arg-type]
        )

        entry = {
            "width": best.get("width"),
            "minWidth": best.get("minWidth"),
            "maxWidth": best.get("maxWidth"),
            "reliability": best.get("reliability"),
            "wvkIds": wvk_ids,
        }
        if entry["width"] is None and entry["minWidth"] is None and entry["maxWidth"] is None:
            # Keep the wvkIds entry even if width values happen to be missing.
            entry = {"wvkIds": wvk_ids}
        lookup[link_id] = entry

    logger.info(
        "Matched %d/%d network links to WKD segments within %.1f m",
        len(lookup),
        len(network_lines),
        max_distance_m,
    )
    return lookup


def apply_wkd_road_widths(
    network_fc: dict,
    lookup: dict[int, dict],
    *,
    match_tolerance_m: float = DEFAULT_MATCH_TOLERANCE_M,
) -> dict:
    """Apply *lookup* to *network_fc* in place and return the enriched FC.

    Only features whose ``mode`` is ``"CAR"`` or ``"BIKE"`` and whose
    ``linkId`` can be parsed as an integer are considered.  When a matching
    entry exists the following properties are set/extended:

    - ``roadWidthM`` — median width (m).
    - ``roadWidthMinM`` — minimum width (m).
    - ``roadWidthMaxM`` — maximum width (m).
    - ``roadWidthReliability`` — WKD reliability class.
    - ``wvkIds`` — list of matched ``WVK_ID`` values.

    The ``wvkIds`` list is extended with any new IDs from the lookup; existing
    values are preserved.
    """
    features = network_fc.get("features") or []
    if not features or not lookup:
        return network_fc

    matched = 0
    for feat in features:
        props = feat.get("properties") or {}
        if props.get("mode") not in ("CAR", "BIKE"):
            continue
        link_id_raw = props.get("linkId")
        if link_id_raw is None:
            continue
        try:
            link_id = int(link_id_raw)
        except (TypeError, ValueError):
            continue

        entry = lookup.get(link_id)
        if entry is None:
            continue

        if entry.get("width") is not None:
            props["roadWidthM"] = entry["width"]
        if entry.get("minWidth") is not None:
            props["roadWidthMinM"] = entry["minWidth"]
        if entry.get("maxWidth") is not None:
            props["roadWidthMaxM"] = entry["maxWidth"]
        if entry.get("reliability") is not None:
            props["roadWidthReliability"] = entry["reliability"]

        wvk_ids = entry.get("wvkIds") or []
        existing = set(props.get("wvkIds") or [])
        new_ids = [wvk_id for wvk_id in wvk_ids if wvk_id not in existing]
        if new_ids:
            props["wvkIds"] = sorted(props.get("wvkIds", []) + new_ids)

        matched += 1

    print(
        f"  {matched}/{len(features)} network links matched to WKD Wegbreedtes "
        f"(tolerance={match_tolerance_m:.0f}m)"
    )
    return network_fc


def fetch_wkd_road_widths(
    cursor,
    polygon_json: str,
    network_fc: dict,
    *,
    catalog: str = DEFAULT_CATALOG,
    schema: str = DEFAULT_SCHEMA,
    match_tolerance_m: float = DEFAULT_MATCH_TOLERANCE_M,
) -> dict[int, dict]:
    """Fetch WKD Wegbreedtes for *polygon_json* and match them to *network_fc*.

    Parameters
    ----------
    cursor:
        A Databricks cursor with an ``execute(sql, params) -> fetchall()`` API.
    polygon_json:
        GeoJSON polygon geometry string (WGS-84).
    network_fc:
        Network FeatureCollection that the WKD segments will be matched against.
    catalog:
        Unity Catalog name for the NWB/WKD tables.
    schema:
        Schema / dataset version for the NWB/WKD tables.
    match_tolerance_m:
        Maximum distance in metres between a WKD segment and a network link for
        a match.

    Returns
    -------
    dict[int, dict]
        Mapping ``link_id -> {"width", "minWidth", "maxWidth",
        "reliability", "wvkIds"}``.
    """
    sql = build_wegbreedtes_sql(catalog, schema)
    cursor.execute(sql, (polygon_json,))
    cols = [d[0] for d in cursor.description]
    rows = cursor.fetchall()
    wkd_features = rows_to_wkd_features(rows, cols)
    return match_wkd_features_to_network(wkd_features, network_fc, match_tolerance_m)
