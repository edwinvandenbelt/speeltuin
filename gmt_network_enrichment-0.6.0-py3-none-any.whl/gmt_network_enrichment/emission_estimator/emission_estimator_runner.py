"""Local debug runner for emission_estimator (air-pollutant emission per link).

Reads a network GeoParquet (as produced by the prepare pipeline, e.g.
``{area_id}-NETWORK-{mode_label}.parquet``), computes the road-traffic
emissions per link on-the-fly by calling the pure core, and - optionally -
writes the enriched FeatureCollection back as GeoParquet.

By default the fast stage 1 model runs (factor times vehicle-km).  Pass
``--detailed`` for the slower, elaborate stage 2 model (speed-dependent
factors, vehicle mix, day-part split).

Writing is optional by design: without ``--output`` the runner only prints a
summary, matching the on-the-fly nature of the core (``fc -> fc``).

Usage
-----
    python -m emission_estimator.emission_estimator_runner \\
        --network output/deventer/abc123-NETWORK-CAR.parquet \\
        --output  output/deventer/abc123-NETWORK-EMISSION-CAR.parquet

    # Elaborate stage 2, in-memory only:
    python -m emission_estimator.emission_estimator_runner \\
        --network output/deventer/abc123-NETWORK-CAR.parquet --detailed

Prerequisites
-------------
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri.removeprefix("file://"), "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Estimate per-link road-traffic air-pollutant emissions for a network."
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="Input network GeoParquet URI (s3://bucket/key or local path).",
    )
    parser.add_argument(
        "--output",
        default=None,
        metavar="URI",
        help=(
            "Optional output GeoParquet URI for the emission-enriched network. "
            "When omitted, nothing is written (in-memory only)."
        ),
    )
    parser.add_argument(
        "--detailed",
        action="store_true",
        help="Run the elaborate stage 2 model instead of the fast stage 1 model.",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        metavar="PATH",
        help="Path to .env file for factors/credentials (auto-discovered if omitted).",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_network_enrichment.emission_estimator.core.emission_estimator_core import (
        estimate_emissions,
        estimate_emissions_detailed,
    )

    print(f"Reading  : {args.network}")
    fc = from_geoparquet(_read_uri(args.network))

    if args.detailed:
        print("Model    : stage 2 (detailed)")
        fc_out = estimate_emissions_detailed(fc)
    else:
        print("Model    : stage 1 (fast)")
        fc_out = estimate_emissions(fc)

    features = fc_out.get("features") or []
    total_co2 = sum((f.get("properties") or {}).get("co2Kg", 0.0) for f in features)
    print(f"Links    : {len(features):,}  (total CO2 {total_co2:,.1f} kg/day)")

    if args.output:
        print(f"Writing  : {args.output}")
        _write_uri(args.output, to_geoparquet(fc_out))
    else:
        print("No --output given; in-memory only (nothing written).")
    print("Done.")


if __name__ == "__main__":
    main()
