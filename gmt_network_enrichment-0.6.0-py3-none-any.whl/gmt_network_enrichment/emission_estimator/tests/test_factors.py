"""Tests for emission_estimator.domain.factors."""

from __future__ import annotations

import importlib

from gmt_network_enrichment.emission_estimator.domain import factors


def test_pollutants_keys() -> None:
    assert factors.POLLUTANTS == ("co2", "nox", "pm10", "pm25")
    for p in factors.POLLUTANTS:
        assert p in factors.EMISSION_FACTORS
        assert factors.EMISSION_FACTORS[p] > 0.0


def test_env_float_default_and_override(monkeypatch) -> None:
    monkeypatch.delenv("EMISSION_FACTOR_CO2", raising=False)
    assert factors._env_float("EMISSION_FACTOR_CO2", 120.0) == 120.0

    monkeypatch.setenv("EMISSION_FACTOR_CO2", "150.5")
    assert factors._env_float("EMISSION_FACTOR_CO2", 120.0) == 150.5

    monkeypatch.setenv("EMISSION_FACTOR_CO2", "not-a-number")
    assert factors._env_float("EMISSION_FACTOR_CO2", 120.0) == 120.0


def test_env_override_applied_on_reload(monkeypatch) -> None:
    monkeypatch.setenv("EMISSION_FACTOR_NOX", "0.9")
    reloaded = importlib.reload(factors)
    try:
        assert reloaded.EMISSION_FACTORS["nox"] == 0.9
    finally:
        monkeypatch.delenv("EMISSION_FACTOR_NOX", raising=False)
        importlib.reload(factors)


def test_combined_factor_between_light_and_heavy() -> None:
    light = factors.EMISSION_FACTORS["co2"]
    heavy = factors.EMISSION_FACTORS_HEAVY["co2"]
    combined = factors.combined_factor("co2")
    assert min(light, heavy) <= combined <= max(light, heavy)


def test_speed_multiplier_is_one_at_reference() -> None:
    assert factors.speed_multiplier(factors.SPEED_REF) == 1.0


def test_speed_multiplier_rises_away_from_reference() -> None:
    at_ref = factors.speed_multiplier(factors.SPEED_REF)
    slow = factors.speed_multiplier(factors.SPEED_REF / 2.0)
    fast = factors.speed_multiplier(factors.SPEED_REF * 2.0)
    assert slow > at_ref
    assert fast > at_ref


def test_speed_multiplier_non_positive_falls_back() -> None:
    assert factors.speed_multiplier(0.0) == 1.0
    assert factors.speed_multiplier(-10.0) == 1.0
