"""Shared spatial matching utilities for OSM asset features.

Provides network-link matching for point- or line-based asset features.
Matching attaches ``linkId`` and ``nodeId`` (the destination ``toNode`` of the
matched link) to each feature so downstream consumers can relate assets back to
the network graph.
"""

from __future__ import annotations

import logging
import math
from collections.abc import Callable

logger = logging.getLogger(__name__)


# Approximate meters per degree at mid-latitudes (used for quick bounding).
_METERS_PER_DEGREE: float = 111000.0


def _point_from_feature(feature: dict) -> tuple[float, float] | None:
    """Extract a single representative (lon, lat) point from a feature.

    For Point geometries the point itself is returned.  For LineStrings the
    midpoint of the coordinates is returned.  For Polygons the centroid is
    returned.
    """
    geometry = feature.get("geometry") or {}
    geom_type = geometry.get("type")
    coords = geometry.get("coordinates") or []

    if geom_type == "Point" and coords:
        return (float(coords[0]), float(coords[1]))

    if geom_type == "LineString" and len(coords) >= 2:
        lon1, lat1 = coords[0]
        lon2, lat2 = coords[-1]
        return ((lon1 + lon2) / 2.0, (lat1 + lat2) / 2.0)

    if geom_type == "Polygon" and coords:
        from shapely.geometry import Polygon

        polygon = Polygon(coords[0])
        centroid = polygon.centroid
        return (centroid.x, centroid.y)

    return None


def match_features_to_network(
    features: list[dict],
    network_fc: dict,
    max_distance_m: float = 20.0,
    point_extractor: Callable[[dict], tuple[float, float] | None] | None = None,
) -> list[dict]:
    """Attach ``linkId`` and ``nodeId`` to features via spatial matching.

    For each feature, find the nearest network link within *max_distance_m* and
    attach its ``linkId`` and ``toNode``.  Features that already have a
    non-``None`` ``linkId`` are left untouched.

    Parameters
    ----------
    features:
        Asset features to match.
    network_fc:
        Network FeatureCollection with LineString link features.  Each link must
        have ``properties.linkId`` and ``properties.toNode``.
    max_distance_m:
        Maximum search distance in meters.
    point_extractor:
        Optional callable ``feature -> (lon, lat) | None``.  Defaults to the
        midpoint of Point/LineString geometries.

    Returns
    -------
    list[dict]
        Updated features with ``linkId`` and ``nodeId`` populated where matched.
    """
    try:
        from shapely.geometry import LineString, Point
    except ImportError:
        logger.warning("shapely not available; skipping network matching")
        return features

    if point_extractor is None:
        point_extractor = _point_from_feature

    network_links: list[tuple[list[tuple[float, float]], dict]] = []
    for link in network_fc.get("features") or []:
        geom = link.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coords = [
            (float(c[0]), float(c[1])) for c in (geom.get("coordinates") or []) if len(c) >= 2
        ]
        if len(coords) < 2:
            continue
        network_links.append((coords, link.get("properties") or {}))

    if not network_links:
        logger.warning("No LineString links found in network; skipping matching")
        return features

    max_distance_deg = max_distance_m / _METERS_PER_DEGREE
    matched_count = 0
    updated: list[dict] = []

    for feature in features:
        props = feature.get("properties") or {}
        if props.get("linkId") is not None:
            updated.append(feature)
            continue

        point = point_extractor(feature)
        if point is None:
            updated.append(feature)
            continue

        lane_point = Point(point[0], point[1])
        nearest_props: dict | None = None
        nearest_distance = float("inf")

        for coords, link_props in network_links:
            try:
                link_line = LineString(coords)
            except (TypeError, ValueError):
                logger.debug("Skipping malformed network link geometry")
                continue
            distance = lane_point.distance(link_line)
            if distance < nearest_distance and distance <= max_distance_deg:
                nearest_distance = distance
                nearest_props = link_props

        if nearest_props is not None:
            props["linkId"] = nearest_props.get("linkId")
            props["nodeId"] = nearest_props.get("toNode")
            matched_count += 1

        updated.append(feature)

    logger.info(
        "Matched %d/%d features to network within %.1f m",
        matched_count,
        len(features),
        max_distance_m,
    )
    return updated


def match_features_to_network_with_fallback(
    features: list[dict],
    network_fc: dict,
    *,
    max_distance_m: float = 20.0,
    fallback_distance_m: float = 50.0,
    point_extractor: Callable[[dict], tuple[float, float] | None] | None = None,
) -> list[dict]:
    """Match features to the network, with a second pass for unmatched ones.

    First runs :func:`match_features_to_network` with *max_distance_m*.  Any
    feature that remains without a ``linkId`` is then retried with the larger
    *fallback_distance_m* buffer.  This catches assets that are slightly further
    from the network line than the strict default threshold, e.g. refuge islands
    mapped on a sidewalk or offset after bidirectional splitting.
    """
    features = match_features_to_network(
        features, network_fc, max_distance_m=max_distance_m, point_extractor=point_extractor
    )
    unmatched = [f for f in features if (f.get("properties") or {}).get("linkId") is None]
    if not unmatched:
        return features

    features_by_id = {id(f): f for f in features}
    rematched = match_features_to_network(
        unmatched, network_fc, max_distance_m=fallback_distance_m, point_extractor=point_extractor
    )
    for f in rematched:
        features_by_id[id(f)] = f
    return list(features_by_id.values())


def haversine_meters(
    lon1: float,
    lat1: float,
    lon2: float,
    lat2: float,
) -> float:
    """Return the haversine distance between two (lon, lat) points in meters."""
    earth_radius_m = 6371000.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)
    a = (
        math.sin(delta_phi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return earth_radius_m * c
