"""Pure-Python parking_area_fetcher core — fetches parking-area polygons.

Fetches parking-area (parkeervlak) polygons for a bounding box from two
sources and merges them into a single GeoJSON ``FeatureCollection`` tagged
``assetType = "parkingArea"``:

* **BGT** (Dutch ``wegdeel`` collection) — features whose ``functie`` equals
  ``"parkeervlak"``, fetched from the PDOK OGC API Features service.  Covers the
  Netherlands only; tagged ``source = "BGT"``.
* **OSM** (Overpass ``amenity=parking`` / ``park_ride`` ways) — surface lots and
  garages worldwide, fetched in tiles; tagged ``source = "OSM"``.

The OSM leg is **fail-safe**: any error talking to Overpass is logged and
swallowed, so the fetch degrades gracefully to BGT-only (or an empty collection
outside NL) rather than failing the whole prepare pipeline.

Original polygon geometry is preserved so the result can be merged into the
combined ``{area_id}-TRAFFIC-ASSETS.parquet`` produced by the prepare pipeline.

Public API
----------
filter_parking_areas(features) -> list[dict]
    Keep BGT wegdeel features with functie == "parkeervlak", tag parkingArea.
osm_elements_to_features(elements) -> list[dict]
    Convert Overpass parking ways to GeoJSON Polygon features.
build_parking_query(bbox, *, timeout) -> str
    Build the Overpass QL query for parking ways.
fetch_parking_areas(bbox, *, ...) -> tuple[dict, dict]
    High-level entry: BGT + (fail-safe) OSM, merged.  Returns (fc, stats).
"""

from __future__ import annotations

import logging

from gmt_shared.geo import is_netherlands
from gmt_shared.overpass import DEFAULT_OVERPASS_URL

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached parking-area output.
PARKING_QUERY_VER: int = 1

#: Asset-type tag written on produced features.
ASSET_TYPE_PARKING: str = "parkingArea"

#: BGT collection id on the PDOK OGC API Features service.
COLLECTION_WEGDEEL: str = "wegdeel"

#: BGT wegdeel field + value identifying a parking area.  In BGT the parking
#: classification lives in the coarse ``functie`` attribute (unlike speed bumps,
#: which live in ``plus_functie``).
FUNCTIE_FIELD: str = "functie"
FUNCTIE_PARKEERVLAK: str = "parkeervlak"

#: Default NxN Overpass tile grid.  The bbox is split into tiles so no single
#: Overpass request has to return the whole area at once (which risks
#: server-side timeouts / rate-limiting).  All tiles are merged.
OVERPASS_GRID: int = 5

#: Default Overpass query timeout (seconds) embedded in the QL query.
DEFAULT_TIMEOUT: int = 90


# ---------------------------------------------------------------------------
# BGT filtering / tagging
# ---------------------------------------------------------------------------


def filter_parking_areas(features: list[dict]) -> list[dict]:
    """Return BGT ``wegdeel`` features that are parking areas, tagged.

    Keeps features whose ``properties.functie`` equals ``"parkeervlak"``.  The
    original polygon geometry is preserved; every kept feature is tagged
    ``properties.assetType = "parkingArea"`` and ``properties.source = "BGT"``.
    """
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        if props.get(FUNCTIE_FIELD) != FUNCTIE_PARKEERVLAK:
            continue
        local_id = props.get("lokaal_id") or props.get("lokaalID") or props.get("gml_id")
        new_props = {
            **props,
            "assetType": ASSET_TYPE_PARKING,
            "source": "BGT",
        }
        if local_id is not None:
            new_props["parkingId"] = f"bgt_{local_id}"
        result.append({**feat, "properties": new_props})
    return result


# ---------------------------------------------------------------------------
# OSM query + conversion
# ---------------------------------------------------------------------------


def build_parking_query(bbox: list[float], *, timeout: int = DEFAULT_TIMEOUT) -> str:
    """Build an Overpass QL query for parking ways in *bbox*.

    Fetches ``amenity=parking`` and ``park_ride`` ways (polygons).  ``out geom;``
    returns full way geometry so tiling only affects the fetch, not the result.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    timeout:
        Overpass query timeout in seconds.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    bb = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    return (
        f"[out:json][timeout:{timeout}];\n"
        f"(\n"
        f'  way["amenity"="parking"]({bb});\n'
        f'  way["park_ride"]({bb});\n'
        f");\n"
        f"out geom;\n"
    )


def _extract_capacity(tags: dict[str, str]) -> int:
    """Return the OSM ``capacity`` tag as a non-negative int, else 0."""
    raw = str(tags.get("capacity", "")).strip()
    if not raw:
        return 0
    try:
        return max(0, int(raw))
    except (ValueError, TypeError):
        return 0


def osm_elements_to_features(elements: list[dict]) -> list[dict]:
    """Convert Overpass parking ways to GeoJSON Polygon features.

    Only ``way`` elements with usable geometry are converted (parkeervlakken are
    areas, so standalone parking nodes are ignored).  Each feature is tagged
    ``assetType = "parkingArea"``, ``source = "OSM"``, and carries a
    ``parkingId`` and ``parkingCapacity`` (from the OSM ``capacity`` tag, else 0).
    """
    features: list[dict] = []
    for el in elements:
        if el.get("type") != "way":
            continue
        geom = el.get("geometry") or []
        if len(geom) < 3:
            continue
        ring = [[float(p["lon"]), float(p["lat"])] for p in geom]
        if ring[0] != ring[-1]:
            ring.append(ring[0])  # close the ring
        tags = el.get("tags") or {}
        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Polygon", "coordinates": [ring]},
                "properties": {
                    "parkingId": f"osm_{el.get('id')}",
                    "assetType": ASSET_TYPE_PARKING,
                    "source": "OSM",
                    "parkingCapacity": _extract_capacity(tags),
                    **{f"tag_{k}": v for k, v in tags.items()},
                },
            }
        )
    return features


def _fetch_bgt_parking(
    bbox: list[float],
    *,
    bgt_url: str | None,
    timeout: int,
) -> list[dict]:
    """Fetch BGT parking-area features (NL only).  Fail-safe: [] on any error.

    The BGT leg talks to the PDOK OGC API Features service over HTTP; transient
    network errors there (e.g. a reset connection mid-pagination) must not abort
    the whole parking fetch, otherwise the OSM leg — which may read from a local
    ``.osm.pbf`` — never runs.
    """
    if not is_netherlands(bbox):
        logger.info("bbox centroid outside NL — skipping BGT parking fetch.")
        return []
    try:
        from gmt_shared.ogc_features import DEFAULT_BGT_URL, fetch_collection_items

        base_url = bgt_url if bgt_url is not None else DEFAULT_BGT_URL
        raw = fetch_collection_items(COLLECTION_WEGDEEL, bbox, url=base_url, timeout=timeout)
        bgt_features = filter_parking_areas(raw)
        logger.info("BGT parking areas: %d (from %d wegdeel features)", len(bgt_features), len(raw))
        return bgt_features
    except Exception as exc:
        logger.warning("BGT parking fetch failed (continuing with OSM only): %s", exc)
        print(f"  [parking] BGT fetch failed, continuing without it: {exc}")
        return []


def _fetch_osm_parking(
    bbox: list[float],
    *,
    overpass_url: str,
    timeout: int,
    tiles: int,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> list[dict]:
    """Fetch OSM parking-area features.  Fail-safe: returns [] on any error."""
    try:
        from gmt_shared.overpass import fetch_overpass_tiled

        data = fetch_overpass_tiled(
            lambda b: build_parking_query(b, timeout=timeout),
            bbox,
            tiles=(tiles, tiles),
            url=overpass_url,
            timeout=timeout,
            osm_path=osm_path,
            osm_workers=osm_workers,
        )
        return osm_elements_to_features(data.get("elements") or [])
    except Exception as exc:
        logger.warning("OSM parking fetch failed (continuing with BGT only): %s", exc)
        print(f"  [parking] OSM fetch failed, continuing without it: {exc}")
        return []


# ---------------------------------------------------------------------------
# High-level entry point
# ---------------------------------------------------------------------------


def fetch_parking_areas(
    bbox: list[float],
    *,
    bgt_url: str | None = None,
    overpass_url: str = DEFAULT_OVERPASS_URL,
    timeout: int = 60,
    tiles: int = OVERPASS_GRID,
    use_bgt: bool = True,
    use_osm: bool = True,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> tuple[dict, dict]:
    """Fetch parking-area polygons for *bbox* from BGT (NL) and/or OSM.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    bgt_url:
        OGC API Features base URL.  Defaults to the shared client default
        (``PDOK_BGT_URL`` env var or the public PDOK BGT endpoint).
    overpass_url:
        Overpass API endpoint URL.
    timeout:
        HTTP request timeout in seconds.
    tiles:
        NxN Overpass tile grid for the OSM leg.
    use_bgt:
        Fetch BGT parking areas (only effective inside the Netherlands).
    use_osm:
        Fetch OSM parking areas.  This leg is fail-safe — errors are logged and
        swallowed so the result degrades to BGT-only.
    osm_path:
        Optional path to a local ``.osm.pbf`` extract.  When set (or via the
        ``OSM_PBF_PATH`` env var) the OSM leg reads from the local file instead
        of the Overpass HTTP API.

    Returns
    -------
    fc:
        A GeoJSON ``FeatureCollection`` of parking-area polygons, each tagged
        ``properties.assetType == "parkingArea"`` and ``properties.source`` in
        ``{"BGT", "OSM"}``.
    stats:
        ``{"parkingArea": int, "bgt": int, "osm": int, "total": int,
        "tiles": int, "source": str}``.
    """
    bgt_features: list[dict] = []
    if use_bgt:
        bgt_features = _fetch_bgt_parking(bbox, bgt_url=bgt_url, timeout=timeout)

    osm_features: list[dict] = []
    if use_osm:
        osm_features = _fetch_osm_parking(
            bbox,
            overpass_url=overpass_url,
            timeout=timeout,
            tiles=tiles,
            osm_path=osm_path,
            osm_workers=osm_workers,
        )
        logger.info("OSM parking areas: %d", len(osm_features))

    features = bgt_features + osm_features
    sources = sorted({str(f["properties"].get("source")) for f in features})
    source_label = "+".join(sources) if sources else "none"

    fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"_qv": PARKING_QUERY_VER, "source": source_label},
    }
    stats = {
        "parkingArea": len(features),
        "bgt": len(bgt_features),
        "osm": len(osm_features),
        "total": len(features),
        "tiles": tiles * tiles,
        "source": source_label,
    }
    return fc, stats
