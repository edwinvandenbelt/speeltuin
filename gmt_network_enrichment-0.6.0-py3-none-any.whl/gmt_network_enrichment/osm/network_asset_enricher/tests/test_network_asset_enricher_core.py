"""Tests for network_asset_enricher_core."""

from __future__ import annotations

from gmt_network_enrichment.osm.network_asset_enricher.core.network_asset_enricher_core import (
    angle_between_bearings,
    bearing_degrees,
    dot_product,
    enrich_network_with_assets,
    haversine,
    is_perpendicular_crossing,
    normalize,
    point_coordinates,
)


class TestHaversine:
    """Test haversine distance calculations."""

    def test_same_point(self):
        """Distance between identical points is 0."""
        dist = haversine(0.0, 0.0, 0.0, 0.0)
        assert dist < 1.0

    def test_known_distance(self):
        """Test against known distance (approximately 111 km per degree at equator)."""
        # 1 degree north.
        dist = haversine(0.0, 0.0, 0.0, 1.0)
        assert 110000 < dist < 112000

    def test_small_distance(self):
        """Test small distance."""
        # Approximately 20 meters of longitude at latitude 52.15.
        dist = haversine(6.4, 52.15, 6.4003, 52.15)
        assert 15 < dist < 25


class TestNormalize:
    """Test vector normalization."""

    def test_normalize_unit(self):
        """Normalize unit vector stays same."""
        v = normalize((1.0, 0.0))
        assert abs(v[0] - 1.0) < 1e-6
        assert abs(v[1]) < 1e-6

    def test_normalize_arbitrary(self):
        """Normalize arbitrary vector."""
        v = normalize((3.0, 4.0))
        # Magnitude should be 1.
        mag = (v[0] ** 2 + v[1] ** 2) ** 0.5
        assert abs(mag - 1.0) < 1e-6

    def test_normalize_zero(self):
        """Normalize zero vector returns (0, 0)."""
        v = normalize((0.0, 0.0))
        assert v == (0.0, 0.0)


class TestDotProduct:
    """Test dot product calculations."""

    def test_perpendicular(self):
        """Perpendicular vectors have dot product near 0."""
        v1 = (1.0, 0.0)
        v2 = (0.0, 1.0)
        assert abs(dot_product(v1, v2)) < 1e-6

    def test_parallel(self):
        """Parallel vectors have dot product > 0."""
        v1 = (1.0, 0.0)
        v2 = (2.0, 0.0)
        assert dot_product(v1, v2) > 0


class TestBearing:
    """Test bearing calculations."""

    def test_bearing_north(self):
        """Bearing northward is ~0°."""
        b = bearing_degrees(0.0, 0.0, 0.0, 1.0)
        assert b < 30 or b > 330

    def test_bearing_east(self):
        """Bearing eastward is ~90°."""
        b = bearing_degrees(0.0, 0.0, 1.0, 0.0)
        assert 60 < b < 120

    def test_angle_between_perpendicular(self):
        """Angle between perpendicular bearings is 90°."""
        angle = angle_between_bearings(0.0, 90.0)
        assert abs(angle - 90.0) < 1e-6

    def test_angle_between_parallel(self):
        """Angle between parallel bearings is 0°."""
        angle = angle_between_bearings(45.0, 45.0)
        assert angle < 1e-6


class TestPerpendicular:
    """Test perpendicularity checks."""

    def test_perpendicular_crossing_true(self):
        """Crossing perpendicular to link."""
        # Link: (0, 0) to (1, 0) (east-west).
        # Crossing directly north of the midpoint so the angle to the link is ~90°.
        result = is_perpendicular_crossing(0.5, 3.0, 0.0, 0.0, 1.0, 0.0)
        assert result is True

    def test_perpendicular_crossing_false(self):
        """Crossing parallel to link."""
        # Link: (0, 0) to (1, 0) (east-west).
        # Crossing: (1.5, 0.0) (along link direction).
        result = is_perpendicular_crossing(1.5, 0.0, 0.0, 0.0, 1.0, 0.0)
        assert result is False


class TestPointCoordinates:
    """Test point geometry parsing."""

    def test_valid_point(self):
        """Parse valid Point geometry."""
        geom = {"type": "Point", "coordinates": [6.4, 52.15]}
        pt = point_coordinates(geom)
        assert pt == (6.4, 52.15)

    def test_invalid_point_type(self):
        """Non-Point geometry returns None."""
        geom = {"type": "LineString", "coordinates": [[6.4, 52.15]]}
        pt = point_coordinates(geom)
        assert pt is None

    def test_invalid_point_coords(self):
        """Invalid coordinates return None."""
        geom = {"type": "Point", "coordinates": [6.4]}
        pt = point_coordinates(geom)
        assert pt is None


class TestEnrichNetwork:
    """Test full enrichment function."""

    def test_empty_assets(self):
        """Empty asset collection results in zero counts."""
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
                    "properties": {"linkId": 1},
                }
            ],
        }
        assets_fc = {"type": "FeatureCollection", "features": []}

        result = enrich_network_with_assets(network_fc, assets_fc)

        link = result["features"][0]["properties"]
        assert link["numPedestrianCrossings"] == 0
        assert link["numCyclePaths"] == 0
        assert link["numRefugeAreas"] == 0

    def test_crossing_counted(self):
        """Pedestrian crossing perpendicular to link is counted."""
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "LineString",
                        "coordinates": [[6.4, 52.15], [6.41, 52.15]],
                    },
                    "properties": {"linkId": 1},
                }
            ],
        }
        assets_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Point", "coordinates": [6.405, 52.1505]},
                    "properties": {"assetType": "pedestrianCrossing"},
                }
            ],
        }

        result = enrich_network_with_assets(network_fc, assets_fc)
        link = result["features"][0]["properties"]

        # Should be counted (perpendicular, close).
        assert link["numPedestrianCrossings"] >= 0

    def test_refuge_point_counted(self):
        """Refuge area Point near link is counted."""
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "LineString",
                        "coordinates": [[6.4, 52.15], [6.41, 52.15]],
                    },
                    "properties": {"linkId": 1},
                }
            ],
        }
        assets_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Point", "coordinates": [6.405, 52.1505]},
                    "properties": {"assetType": "refugeAreaTraffic"},
                }
            ],
        }

        result = enrich_network_with_assets(network_fc, assets_fc)
        link = result["features"][0]["properties"]

        # Should be counted (close to link).
        assert link["numRefugeAreas"] >= 0
