"""Resolve and download the Geofabrik ``.osm.pbf`` extracts that cover a network.

Only the smallest ("leaf") extracts are used: Dutch provinces plus the
neighbouring Belgian / German extracts.  When a network straddles the border of
two extracts, *both* are returned instead of escalating to a larger extract
(e.g. ``netherlands``), which keeps downloads and PBF scans small.

Extracts are chosen against the actual link geometries (not the bbox), so a bbox
corner sticking into a neighbouring province does not trigger a download.

Files are cached in ``$OSM_PBF_CACHE_DIR`` (default ``<tempdir>/geofabrik_pbf``)
as ``<slug>.poly`` / ``<slug>.osm.pbf``.
"""

from __future__ import annotations

import logging
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from collections.abc import Iterable

logger = logging.getLogger(__name__)

GEOFABRIK_BASE = "https://download.geofabrik.de"
OSM_PBF_CACHE_DIR_ENV_VAR = "OSM_PBF_CACHE_DIR"

#: Remaining uncovered link length (degrees) treated as fully covered.
_COVER_TOLERANCE_DEG = 1e-7


@dataclass(frozen=True)
class Extract:
    slug: str
    path: str

    @property
    def poly_url(self) -> str:
        return f"{GEOFABRIK_BASE}/{self.path}.poly"

    @property
    def pbf_url(self) -> str:
        return f"{GEOFABRIK_BASE}/{self.path}-latest.osm.pbf"


#: Leaf extracts only — never a country that is itself split into regions here.
LEAF_EXTRACTS: tuple[Extract, ...] = (
    Extract("drenthe", "europe/netherlands/drenthe"),
    Extract("flevoland", "europe/netherlands/flevoland"),
    Extract("friesland", "europe/netherlands/friesland"),
    Extract("gelderland", "europe/netherlands/gelderland"),
    Extract("groningen", "europe/netherlands/groningen"),
    Extract("limburg", "europe/netherlands/limburg"),
    Extract("noord-brabant", "europe/netherlands/noord-brabant"),
    Extract("noord-holland", "europe/netherlands/noord-holland"),
    Extract("overijssel", "europe/netherlands/overijssel"),
    Extract("utrecht", "europe/netherlands/utrecht"),
    Extract("zeeland", "europe/netherlands/zeeland"),
    Extract("zuid-holland", "europe/netherlands/zuid-holland"),
    Extract("belgium", "europe/belgium"),
    Extract("niedersachsen", "europe/germany/niedersachsen"),
    Extract("nordrhein-westfalen", "europe/germany/nordrhein-westfalen"),
)


def default_cache_dir() -> Path:
    env = os.environ.get(OSM_PBF_CACHE_DIR_ENV_VAR, "").strip()
    return Path(env) if env else Path(tempfile.gettempdir()) / "geofabrik_pbf"


# ---------------------------------------------------------------------------
# I/O (module-level so tests can monkeypatch them)
# ---------------------------------------------------------------------------


def _download(url: str, dest: Path, timeout: int = 600) -> None:
    """Stream *url* to *dest* atomically (via a ``.part`` file)."""
    import requests

    dest.parent.mkdir(parents=True, exist_ok=True)
    part = dest.with_name(dest.name + ".part")
    logger.info("Downloading %s", url)
    print(f"  [Geofabrik] downloading {url}")
    with requests.get(url, stream=True, timeout=timeout) as resp:
        resp.raise_for_status()
        with part.open("wb") as fh:
            for chunk in resp.iter_content(chunk_size=1 << 20):
                fh.write(chunk)
    part.replace(dest)


def parse_poly(text: str):
    """Parse an Osmosis/Geofabrik ``.poly`` file into a shapely geometry.

    Rings whose header starts with ``!`` are holes of the preceding ring.
    """
    from shapely.geometry import MultiPolygon, Polygon

    lines = [ln.strip() for ln in text.strip().splitlines()]
    shells: list[tuple[list, list]] = []
    idx = 1  # first line is the region name
    while idx < len(lines):
        header = lines[idx]
        idx += 1
        if header == "END":
            break
        if not header:
            continue
        ring: list[tuple[float, float]] = []
        while idx < len(lines) and lines[idx] != "END":
            parts = lines[idx].split()
            idx += 1
            if len(parts) >= 2:
                ring.append((float(parts[0]), float(parts[1])))
        idx += 1  # skip ring END
        if len(ring) < 3:
            continue
        if header.startswith("!") and shells:
            shells[-1][1].append(ring)
        else:
            shells.append((ring, []))
    if not shells:
        raise ValueError("no valid rings found in .poly file")
    polygons = [Polygon(shell, holes) for shell, holes in shells]
    return polygons[0] if len(polygons) == 1 else MultiPolygon(polygons)


def load_poly(extract: Extract, cache_dir: Path):
    path = cache_dir / f"{extract.slug}.poly"
    if not path.is_file():
        _download(extract.poly_url, path, timeout=60)
    return parse_poly(path.read_text(encoding="utf-8"))


def ensure_pbf(extract: Extract, cache_dir: Path) -> Path:
    """Return the cached ``.osm.pbf`` of *extract*, downloading it when missing."""
    path = cache_dir / f"{extract.slug}.osm.pbf"
    if not path.is_file():
        _download(extract.pbf_url, path)
    return path


# ---------------------------------------------------------------------------
# Extract selection
# ---------------------------------------------------------------------------


def select_extracts(
    geometry: Any,
    *,
    cache_dir: Path | None = None,
    extracts: Iterable[Extract] = LEAF_EXTRACTS,
) -> list[Extract]:
    """Return the smallest set of leaf extracts that together cover *geometry*.

    Greedy set cover: repeatedly take the extract that covers most of the
    still-uncovered link length.

    Raises
    ------
    ValueError:
        When part of *geometry* lies outside every known leaf extract.
    """
    cache_dir = cache_dir or default_cache_dir()
    candidates = []
    for extract in extracts:
        poly = load_poly(extract, cache_dir)
        if poly.intersects(geometry):
            candidates.append((extract, poly))

    remaining = geometry
    chosen: list[Extract] = []
    while not remaining.is_empty and remaining.length > _COVER_TOLERANCE_DEG:
        best = max(
            candidates,
            key=lambda c: remaining.intersection(c[1]).length,
            default=None,
        )
        if best is None or remaining.intersection(best[1]).length <= 0.0:
            b = remaining.bounds
            raise ValueError(
                "Network is not fully covered by the known Geofabrik extracts; "
                f"uncovered part within bbox ({b[0]:.5f}, {b[1]:.5f}, {b[2]:.5f}, {b[3]:.5f})."
            )
        chosen.append(best[0])
        candidates.remove(best)
        remaining = remaining.difference(best[1])
    return chosen


def resolve_pbf_paths(
    geometry: Any,
    *,
    cache_dir: Path | str | None = None,
) -> list[Path]:
    """Select, download (if needed) and return the local PBF files for *geometry*."""
    cache = Path(cache_dir) if cache_dir else default_cache_dir()
    chosen = select_extracts(geometry, cache_dir=cache)
    logger.info("Geofabrik extracts for network: %s", [e.slug for e in chosen])
    print(f"  [Geofabrik] extracts: {', '.join(e.slug for e in chosen)}")
    return [ensure_pbf(e, cache) for e in chosen]
