"""Unit tests for geofabrik_pbf extract selection (no network access)."""

from __future__ import annotations

import pytest
from shapely.geometry import LineString, MultiLineString, box

from gmt_network_enrichment.osm.road_enricher.core import geofabrik_pbf
from gmt_network_enrichment.osm.road_enricher.core.geofabrik_pbf import (
    Extract,
    ensure_pbf,
    parse_poly,
    resolve_pbf_paths,
    select_extracts,
)

# Two adjacent "provinces" (slightly overlapping, like Geofabrik polys) and
# the country containing both.
_WEST = Extract("west", "europe/x/west")
_EAST = Extract("east", "europe/x/east")
_POLYS = {
    "west": box(0.0, 0.0, 1.01, 1.0),
    "east": box(0.99, 0.0, 2.0, 1.0),
}


@pytest.fixture
def fake_polys(monkeypatch):
    monkeypatch.setattr(geofabrik_pbf, "load_poly", lambda e, _cache_dir: _POLYS[e.slug])


def _lines(*coords_list) -> MultiLineString:
    return MultiLineString([LineString(c) for c in coords_list])


def test_network_inside_one_extract(fake_polys, tmp_path):
    geom = _lines([(0.2, 0.5), (0.6, 0.5)])
    assert select_extracts(geom, cache_dir=tmp_path, extracts=[_WEST, _EAST]) == [_WEST]


def test_network_on_border_uses_both_extracts(fake_polys, tmp_path):
    geom = _lines([(0.8, 0.5), (1.3, 0.5)])
    chosen = select_extracts(geom, cache_dir=tmp_path, extracts=[_WEST, _EAST])
    assert {e.slug for e in chosen} == {"west", "east"}


def test_bbox_corner_in_other_extract_is_not_selected(fake_polys, tmp_path):
    # The bbox of these links reaches into "east", but no link does.
    geom = _lines([(0.2, 0.1), (0.3, 0.1)], [(0.95, 0.9), (0.96, 0.9)])
    assert select_extracts(geom, cache_dir=tmp_path, extracts=[_WEST, _EAST]) == [_WEST]


def test_uncovered_network_raises(fake_polys, tmp_path):
    geom = _lines([(1.5, 0.5), (3.0, 0.5)])
    with pytest.raises(ValueError, match="not fully covered"):
        select_extracts(geom, cache_dir=tmp_path, extracts=[_WEST, _EAST])


def test_default_registry_has_no_country_with_provinces():
    slugs = {e.slug for e in geofabrik_pbf.LEAF_EXTRACTS}
    assert "netherlands" not in slugs
    assert "germany" not in slugs
    assert "europe" not in slugs


def test_ensure_pbf_uses_cache(monkeypatch, tmp_path):
    cached = tmp_path / "west.osm.pbf"
    cached.write_bytes(b"pbf")
    monkeypatch.setattr(geofabrik_pbf, "_download", lambda *_a, **_kw: pytest.fail("downloaded"))
    assert ensure_pbf(_WEST, tmp_path) == cached


def test_ensure_pbf_downloads_missing(monkeypatch, tmp_path):
    calls = []

    def _fake_download(url, dest, timeout=600):
        calls.append(url)
        dest.write_bytes(b"pbf")

    monkeypatch.setattr(geofabrik_pbf, "_download", _fake_download)
    path = ensure_pbf(_EAST, tmp_path)
    assert path.read_bytes() == b"pbf"
    assert calls == ["https://download.geofabrik.de/europe/x/east-latest.osm.pbf"]


def test_resolve_pbf_paths(fake_polys, monkeypatch, tmp_path):
    monkeypatch.setattr(geofabrik_pbf, "LEAF_EXTRACTS", (_WEST, _EAST))

    def _fake_select(_geometry, *, cache_dir):
        assert cache_dir == tmp_path
        return [_WEST, _EAST]

    monkeypatch.setattr(geofabrik_pbf, "select_extracts", _fake_select)
    monkeypatch.setattr(geofabrik_pbf, "ensure_pbf", lambda e, c: c / f"{e.slug}.osm.pbf")
    paths = resolve_pbf_paths(_lines([(0, 0), (1, 1)]), cache_dir=tmp_path)
    assert [p.name for p in paths] == ["west.osm.pbf", "east.osm.pbf"]


def test_parse_poly_with_hole():
    text = "\n".join(
        [
            "region",
            "1",
            "   0 0",
            "   10 0",
            "   10 10",
            "   0 10",
            "END",
            "!2",
            "   4 4",
            "   6 4",
            "   6 6",
            "   4 6",
            "END",
            "END",
        ]
    )
    poly = parse_poly(text)
    assert poly.area == pytest.approx(100 - 4)
