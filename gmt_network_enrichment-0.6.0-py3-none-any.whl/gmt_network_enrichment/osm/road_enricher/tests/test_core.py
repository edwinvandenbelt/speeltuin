"""Unit tests for road_enricher_core."""

from __future__ import annotations

import math

import pytest

from gmt_network_enrichment.osm.road_enricher.core.road_enricher_core import (
    enrich_network_with_road_attributes,
    fetch_osm_road_ways,
    road_query_for_bbox,
)

_LAT0 = 52.0
_LON0 = 6.0
_DEG_PER_M_LAT = 1.0 / 111_320.0
_DEG_PER_M_LON = 1.0 / (111_320.0 * math.cos(math.radians(_LAT0)))


def _pt(x_m: float, y_m: float) -> list[float]:
    """Point ``x_m`` east / ``y_m`` north of the test origin, as [lon, lat]."""
    return [_LON0 + x_m * _DEG_PER_M_LON, _LAT0 + y_m * _DEG_PER_M_LAT]


def _directed_net_link(link_id, coords, wvk_ids=None, reverse_link_ids=None) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "fromNode": 1,
            "toNode": 2,
            "mode": "CAR",
            "wvkIds": list(wvk_ids or []),
            "reverseLinkIds": list(reverse_link_ids or []),
        },
    }


def _osm_way(way_id, coords, tags) -> dict:
    return {
        "type": "way",
        "id": way_id,
        "geometry": [{"lon": c[0], "lat": c[1]} for c in coords],
        "tags": tags,
    }


def _wegvak(wvk_id=100, length_m=100.0) -> dict:
    """Bidirectional wegvak: heen + terug link along the x axis."""
    fwd = [_pt(0, 0), _pt(length_m, 0)]
    return {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(1, fwd, [wvk_id], [-1]),
            _directed_net_link(-1, fwd[::-1], [wvk_id], [1]),
        ],
    }


def _surfaces(fc) -> list:
    return [f["properties"]["surface"] for f in fc["features"]]


def test_parallel_way_sets_surface_on_both_directions():
    fc = _wegvak()
    osm = [
        _osm_way(1, [_pt(-20, 3), _pt(120, 3)], {"highway": "residential", "surface": "asphalt"})
    ]

    fc, stats = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _surfaces(fc) == ["asphalt", "asphalt"]
    assert fc["features"][0]["properties"]["surfaceConfidence"] == 1.0
    assert (stats["links"], stats["wegvakken"], stats["matched"]) == (2, 1, 2)
    assert stats["filled"]["surface"] == 2


def test_majority_by_overlap_length():
    fc = _wegvak()
    osm = [
        _osm_way(1, [_pt(0, 2), _pt(80, 2)], {"highway": "residential", "surface": "asphalt"}),
        _osm_way(2, [_pt(80, 2), _pt(100, 2)], {"highway": "residential", "surface": "sett"}),
    ]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _surfaces(fc) == ["asphalt", "asphalt"]
    assert fc["features"][0]["properties"]["surfaceConfidence"] == pytest.approx(0.8, abs=0.01)


def test_crossing_way_is_ignored():
    fc = _wegvak()
    osm = [_osm_way(1, [_pt(50, -50), _pt(50, 50)], {"highway": "primary", "surface": "sett"})]

    fc, stats = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _surfaces(fc) == [None, None]
    assert fc["features"][0]["properties"]["surfaceConfidence"] is None
    assert stats["matched"] == 0


def test_way_outside_buffer_is_ignored():
    fc = _wegvak()
    osm = [
        _osm_way(1, [_pt(0, 25), _pt(100, 25)], {"highway": "residential", "surface": "asphalt"})
    ]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _surfaces(fc) == [None, None]


def test_parallel_cycleway_does_not_set_road_surface():
    fc = _wegvak()
    osm = [
        _osm_way(1, [_pt(0, 0), _pt(30, 0)], {"highway": "residential", "surface": "asphalt"}),
        _osm_way(2, [_pt(0, 5), _pt(100, 5)], {"highway": "cycleway", "surface": "paving_stones"}),
    ]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _surfaces(fc) == ["asphalt", "asphalt"]


def test_way_continuing_past_link_end_does_not_leak():
    fc = _wegvak()
    osm = [
        _osm_way(1, [_pt(0, 0), _pt(100, 0)], {"highway": "residential", "surface": "asphalt"}),
        # Starts exactly at the link end and continues; must not count.
        _osm_way(2, [_pt(100, 0), _pt(300, 0)], {"highway": "residential", "surface": "sett"}),
    ]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert fc["features"][0]["properties"]["surfaceConfidence"] == 1.0


def test_tie_is_deterministic():
    fc = _wegvak()
    osm = [
        _osm_way(1, [_pt(50, 2), _pt(100, 2)], {"highway": "residential", "surface": "sett"}),
        _osm_way(2, [_pt(0, 2), _pt(50, 2)], {"highway": "residential", "surface": "asphalt"}),
    ]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _surfaces(fc) == ["asphalt", "asphalt"]


def test_votes_are_aggregated_per_wegvak():
    # Two consecutive links of one wegvak: wegvak-level majority wins on both.
    fc = {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(1, [_pt(0, 0), _pt(70, 0)], [100]),
            _directed_net_link(2, [_pt(70, 0), _pt(100, 0)], [100]),
            _directed_net_link(3, [_pt(100, 0), _pt(200, 0)], [200]),
        ],
    }
    osm = [
        _osm_way(1, [_pt(0, 2), _pt(70, 2)], {"highway": "residential", "surface": "asphalt"}),
        _osm_way(2, [_pt(70, 2), _pt(100, 2)], {"highway": "residential", "surface": "sett"}),
    ]

    fc, stats = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _surfaces(fc) == ["asphalt", "asphalt", None]
    assert stats["wegvakken"] == 2


def test_rerun_resets_previous_values():
    fc = _wegvak()
    for feat in fc["features"]:
        feat["properties"]["surface"] = "gravel"

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=[])

    assert _surfaces(fc) == [None, None]


def test_surface_query():
    q = road_query_for_bbox([6.0, 52.0, 6.1, 52.1])
    assert q == '[out:json];(way["highway"](52.0,6.0,52.1,6.1););out geom;'


def test_fetch_reads_all_covering_pbfs_and_dedupes(monkeypatch, tmp_path):
    from gmt_shared import _osm_pbf

    from gmt_network_enrichment.osm.road_enricher.core import geofabrik_pbf

    pbfs = [tmp_path / "gelderland.osm.pbf", tmp_path / "overijssel.osm.pbf"]
    per_file = {
        pbfs[0].name: [{"type": "way", "id": 1}, {"type": "way", "id": 2}],
        pbfs[1].name: [{"type": "way", "id": 2}, {"type": "way", "id": 3}],
    }
    scanned = []

    def _fake_resolve(geometry, *, cache_dir=None):
        assert not geometry.is_empty
        return pbfs

    def _fake_fetch_from_pbf(query, pbf_path, *, workers=None):
        scanned.append((pbf_path.name, query))
        return {"elements": per_file[pbf_path.name]}

    def _no_overpass(*_a, **_kw):
        raise AssertionError("Overpass must not be used")

    monkeypatch.setattr(geofabrik_pbf, "resolve_pbf_paths", _fake_resolve)
    monkeypatch.setattr(_osm_pbf, "fetch_from_pbf", _fake_fetch_from_pbf)
    monkeypatch.setattr("gmt_shared.overpass.fetch_overpass", _no_overpass)
    monkeypatch.setattr("gmt_shared.overpass.fetch_overpass_tiled", _no_overpass)

    elements = fetch_osm_road_ways(_wegvak())

    assert sorted(e["id"] for e in elements) == [1, 2, 3]
    assert [name for name, _ in scanned] == ["gelderland.osm.pbf", "overijssel.osm.pbf"]
    assert all('way["highway"]' in q for _, q in scanned)


def test_fetch_empty_network_returns_nothing():
    assert fetch_osm_road_ways({"type": "FeatureCollection", "features": []}) == []


# ---------------------------------------------------------------------------
# Road attributes beyond surface
# ---------------------------------------------------------------------------


def _props(fc, i):
    return fc["features"][i]["properties"]


def test_side_and_direction_tags_follow_link_direction():
    # OSM way drawn west -> east, same as the heen link (index 0).
    fc = _wegvak()
    tags = {
        "highway": "tertiary",
        "cycleway:right": "lane",
        "cycleway:left": "no",
        "sidewalk": "right",
        "parking:left": "lane",
        "maxspeed": "50",
        "maxspeed:backward": "30",
        "lanes": "2",
        "lanes:forward": "1",
        "lanes:backward": "1",
        "name": "Dorpsstraat",
        "ref": "N123",
        "lit": "yes",
        "width": "6,5 m",
    }
    osm = [_osm_way(1, [_pt(-10, 1), _pt(110, 1)], tags)]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)
    heen, terug = _props(fc, 0), _props(fc, 1)

    assert (heen["cyclewayRight"], heen["cyclewayLeft"]) == ("lane", "no")
    assert (terug["cyclewayRight"], terug["cyclewayLeft"]) == ("no", "lane")
    assert (heen["sidewalkRight"], heen["sidewalkLeft"]) == ("yes", "no")
    assert (terug["sidewalkRight"], terug["sidewalkLeft"]) == ("no", "yes")
    assert (heen["parkingLeft"], terug["parkingRight"]) == ("lane", "lane")
    assert (heen["osmMaxspeed"], terug["osmMaxspeed"]) == (50, 30)
    assert heen["osmLanes"] == terug["osmLanes"] == 2
    assert heen["osmLanesInDirection"] == terug["osmLanesInDirection"] == 1
    assert heen["osmName"] == "Dorpsstraat"
    assert heen["osmRef"] == "N123"
    assert heen["osmHighway"] == "tertiary"
    assert heen["lit"] == "yes"
    assert heen["osmWidth"] == 6.5
    assert heen["osmOneway"] is False
    assert heen["osmMatchRatio"] == 1.0


def test_untagged_attributes_stay_empty():
    fc = _wegvak()
    osm = [_osm_way(1, [_pt(0, 1), _pt(100, 1)], {"highway": "residential"})]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)
    heen = _props(fc, 0)

    assert heen["osmHighway"] == "residential"
    for col in ("surface", "sidewalkLeft", "cyclewayRight", "osmMaxspeed", "busway"):
        assert heen[col] is None


def test_separately_mapped_sidewalk_and_cycle_track():
    # Road along y=0 (heen = eastbound); sidewalk 8 m north, cycle track 12 m south.
    fc = _wegvak()
    osm = [
        _osm_way(1, [_pt(0, 0), _pt(100, 0)], {"highway": "residential", "sidewalk": "no"}),
        _osm_way(2, [_pt(-5, 8), _pt(105, 8)], {"highway": "footway", "footway": "sidewalk"}),
        _osm_way(3, [_pt(-5, -12), _pt(105, -12)], {"highway": "cycleway"}),
    ]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)
    heen, terug = _props(fc, 0), _props(fc, 1)

    # North is left of the eastbound heen link, right of the westbound terug link.
    assert heen["sidewalkLeft"] == "separate"
    assert heen["sidewalkRight"] == "no"
    assert heen["cyclewayRight"] == "track"
    assert heen["cyclewayLeft"] is None
    assert terug["sidewalkRight"] == "separate"
    assert terug["cyclewayLeft"] == "track"


def test_separate_path_of_closer_other_road_is_not_assigned():
    # A parallel street 20 m north (not in the network) with its own sidewalk
    # 3 m from it: the sidewalk belongs to that street, not to the link.
    fc = _wegvak()
    osm = [
        _osm_way(1, [_pt(0, 0), _pt(100, 0)], {"highway": "residential"}),
        _osm_way(2, [_pt(0, 20), _pt(100, 20)], {"highway": "residential"}),
        _osm_way(3, [_pt(0, 17), _pt(100, 17)], {"highway": "footway", "footway": "sidewalk"}),
    ]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _props(fc, 0)["sidewalkLeft"] is None
    assert _props(fc, 1)["sidewalkRight"] is None


def test_separate_path_goes_to_nearest_network_link():
    # Two parallel network roads 20 m apart, sidewalk 4 m from the southern one.
    fc = {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(1, [_pt(0, 0), _pt(100, 0)], [100]),
            _directed_net_link(2, [_pt(0, 20), _pt(100, 20)], [200]),
        ],
    }
    osm = [_osm_way(3, [_pt(0, 4), _pt(100, 4)], {"highway": "footway", "footway": "sidewalk"})]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _props(fc, 0)["sidewalkLeft"] == "separate"
    assert _props(fc, 1)["sidewalkRight"] is None


def test_perpendicular_footway_is_not_a_sidewalk():
    fc = _wegvak()
    osm = [_osm_way(3, [_pt(50, -20), _pt(50, 20)], {"highway": "footway", "footway": "sidewalk"})]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _props(fc, 0)["sidewalkLeft"] is None
    assert _props(fc, 0)["sidewalkRight"] is None


def test_oneway_way_drawn_against_link():
    # One-way OSM way drawn east -> west; the network link runs west -> east.
    fc = {
        "type": "FeatureCollection",
        "features": [_directed_net_link(1, [_pt(0, 0), _pt(100, 0)], [100])],
    }
    tags = {"highway": "secondary", "oneway": "-1", "lanes": "2", "busway:left": "lane"}
    osm = [_osm_way(1, [_pt(100, 1), _pt(0, 1)], tags)]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)
    props = _props(fc, 0)

    assert props["osmOneway"] is True
    assert props["osmLanesInDirection"] == 2
    # The way's left side is the link's right side.
    assert props["busway"] == "lane"


def test_link_spanning_several_wegvakken_votes_over_all_of_them():
    # Aggregated network: link 1 spans wegvakken 10 and 20.  Wegvak 10 also
    # covers link 3 (no surface tag, long), wegvak 20 also covers link 2 (sett).
    fc = {
        "type": "FeatureCollection",
        "features": [
            _directed_net_link(1, [_pt(0, 0), _pt(100, 0)], [10, 20]),
            _directed_net_link(2, [_pt(100, 0), _pt(130, 0)], [20]),
            _directed_net_link(3, [_pt(0, 200), _pt(100, 200)], [10]),
        ],
    }
    osm = [
        _osm_way(1, [_pt(0, 1), _pt(100, 1)], {"highway": "residential"}),
        _osm_way(2, [_pt(100, 1), _pt(130, 1)], {"highway": "residential", "surface": "sett"}),
        _osm_way(3, [_pt(0, 201), _pt(100, 201)], {"highway": "residential"}),
    ]

    fc, _ = enrich_network_with_road_attributes(fc, osm_elements=osm)

    assert _surfaces(fc) == ["sett", "sett", None]
