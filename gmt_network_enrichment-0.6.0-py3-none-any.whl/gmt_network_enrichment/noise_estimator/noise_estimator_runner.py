"""Local debug runner for noise_estimator (phase A - emission per link).

Reads a network GeoParquet (as produced by the prepare pipeline, e.g.
``{area_id}-NETWORK-{mode_label}.parquet``), computes the road-traffic noise
emission per link on-the-fly by calling the pure core, and - optionally -
writes the enriched FeatureCollection back as GeoParquet.

Writing is optional by design: without ``--output`` the runner only prints a
summary, matching the on-the-fly nature of the core (``fc -> fc``).

Usage
-----
    python -m noise_estimator.noise_estimator_runner \\
        --network output/deventer/abc123-NETWORK-CAR.parquet \\
        --output  output/deventer/abc123-NETWORK-NOISE-CAR.parquet

    # In-memory only (no file written), just print the summary:
    python -m noise_estimator.noise_estimator_runner \\
        --network output/deventer/abc123-NETWORK-CAR.parquet

Prerequisites
-------------
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri.removeprefix("file://"), "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Estimate per-link road-traffic noise emission (phase A) for a network."
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="Input network GeoParquet URI (s3://bucket/key or local path).",
    )
    parser.add_argument(
        "--output",
        default=None,
        metavar="URI",
        help=(
            "Optional output GeoParquet URI for the noise-enriched network. "
            "When omitted, nothing is written (in-memory only)."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        metavar="PATH",
        help="Path to .env file for AWS credentials (auto-discovered if omitted).",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_network_enrichment.noise_estimator.core.noise_estimator_core import (
        PROP_NOISE_LDEN,
        estimate_noise_emission,
    )

    print(f"Reading  : {args.network}")
    fc = from_geoparquet(_read_uri(args.network))

    fc_out = estimate_noise_emission(fc)

    features = fc_out.get("features") or []
    n_with_lden = sum(
        1 for f in features if (f.get("properties") or {}).get(PROP_NOISE_LDEN) is not None
    )
    print(f"Links    : {len(features):,} ({n_with_lden:,} with an Lden value)")

    if args.output:
        print(f"Writing  : {args.output}")
        _write_uri(args.output, to_geoparquet(fc_out))
    else:
        print("No --output given; in-memory only (nothing written).")
    print("Done.")


if __name__ == "__main__":
    main()
