"""Pure-Python noise_estimator core - no I/O, no boto3, no external deps.

Phase A of the two-stage noise model: estimates road-traffic noise **emission**
(source power) per network link, on-the-fly, straight from the traffic flows
carried on each link.  It works entirely in memory on a GeoJSON
``FeatureCollection`` (``fc -> fc``); reading and writing files is the job of
the runner / notebook wrappers, never of this core.

Per link the following properties are added:

    noiseDay        emission for the day period    (07-19 h), dB(A)
    noiseEvening    emission for the evening period (19-23 h), dB(A)
    noiseNight      emission for the night period   (23-07 h), dB(A)
    noiseLden       energy-weighted Lden value,               dB(A)
    noiseLnight     night emission (= noiseNight),            dB(A)
    noiseSourceType constant "road" (prepared for phase B)

The per-period emission may be ``None`` when the link carries (almost) no
traffic in that period; ``noiseSourceType`` is always set.

Input links are expected to carry the prepare / osm_flow_estimator flow schema:
``flow24hrs`` (vehicles/day) and ``speed`` (km/h).  Links without a positive
flow or speed receive ``None`` noise values.

Public API
----------
NOISE_PROPERTIES: tuple[str, ...]
    The property names this module writes onto each feature (authoritative).
compute_link_noise(props) -> dict
    Compute the noise properties for a single link's property dict.
estimate_noise_emission(fc) -> dict
    Enrich a whole FeatureCollection with per-link noise emission (phase A).
"""

from __future__ import annotations

import logging

from gmt_network_enrichment.noise_estimator.domain.diurnal_splitter import split_daily_flow
from gmt_network_enrichment.noise_estimator.domain.emission import combine_lden, emission_db

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Property names (authoritative - camelCase external field names)
# ---------------------------------------------------------------------------

PROP_NOISE_DAY: str = "noiseDay"
PROP_NOISE_EVENING: str = "noiseEvening"
PROP_NOISE_NIGHT: str = "noiseNight"
PROP_NOISE_LDEN: str = "noiseLden"
PROP_NOISE_LNIGHT: str = "noiseLnight"
PROP_NOISE_SOURCE_TYPE: str = "noiseSourceType"

#: All property names written by this module, in output order.
NOISE_PROPERTIES: tuple[str, ...] = (
    PROP_NOISE_DAY,
    PROP_NOISE_EVENING,
    PROP_NOISE_NIGHT,
    PROP_NOISE_LDEN,
    PROP_NOISE_LNIGHT,
    PROP_NOISE_SOURCE_TYPE,
)

#: Constant source type tag (only road traffic is modelled in phase A).
NOISE_SOURCE_TYPE_ROAD: str = "road"


# ---------------------------------------------------------------------------
# Input field names on the incoming network links
# ---------------------------------------------------------------------------

_FIELD_FLOW24HRS: str = "flow24hrs"
_FIELD_SPEED: str = "speed"


def _as_float(value: object) -> float:
    """Coerce *value* to a float, returning 0.0 for missing / invalid input."""
    if value is None:
        return 0.0
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0.0


def compute_link_noise(props: dict) -> dict:
    """Compute the noise properties for a single link.

    Parameters
    ----------
    props:
        The ``properties`` dict of one network link feature.  Read-only; the
        result is returned as a new dict of noise properties.

    Returns
    -------
    A dict with the keys in :data:`NOISE_PROPERTIES`.  The per-period and Lden
    values are floats in dB(A) or ``None`` when there is no meaningful source;
    ``noiseSourceType`` is always ``"road"``.
    """
    flow24hrs = _as_float(props.get(_FIELD_FLOW24HRS))
    speed = _as_float(props.get(_FIELD_SPEED))

    intensities = split_daily_flow(flow24hrs)
    l_day = emission_db(intensities["day"], speed)
    l_evening = emission_db(intensities["evening"], speed)
    l_night = emission_db(intensities["night"], speed)
    lden = combine_lden(l_day, l_evening, l_night)

    return {
        PROP_NOISE_DAY: l_day,
        PROP_NOISE_EVENING: l_evening,
        PROP_NOISE_NIGHT: l_night,
        PROP_NOISE_LDEN: lden,
        PROP_NOISE_LNIGHT: l_night,
        PROP_NOISE_SOURCE_TYPE: NOISE_SOURCE_TYPE_ROAD,
    }


def estimate_noise_emission(fc: dict) -> dict:
    """Enrich a network FeatureCollection with per-link noise emission.

    Phase A of the noise model.  Pure and on-the-fly: iterates over every
    feature, computes the emission properties from its traffic flow and speed,
    and returns a new FeatureCollection with those properties merged onto each
    feature.  Geometry and existing properties are preserved.

    Parameters
    ----------
    fc:
        A GeoJSON ``FeatureCollection`` of directed network links carrying the
        flow schema (``flow24hrs``, ``speed``).

    Returns
    -------
    A new ``FeatureCollection`` with the :data:`NOISE_PROPERTIES` added to each
    feature's ``properties``.  The top-level ``properties`` (if any) are copied
    through unchanged.
    """
    features_in = fc.get("features") or []
    features_out: list[dict] = []
    n_with_noise = 0

    for feat in features_in:
        props = dict(feat.get("properties") or {})
        noise = compute_link_noise(props)
        props.update(noise)
        if noise[PROP_NOISE_LDEN] is not None:
            n_with_noise += 1
        features_out.append(
            {
                "type": feat.get("type", "Feature"),
                "geometry": feat.get("geometry"),
                "properties": props,
            }
        )

    logger.info(
        "noise emission computed for %d/%d links (with an Lden value)",
        n_with_noise,
        len(features_out),
    )

    out: dict = {
        "type": "FeatureCollection",
        "features": features_out,
    }
    if "properties" in fc:
        out["properties"] = fc["properties"]
    return out
