"""Unit tests for noise_estimator.domain.emission."""

from __future__ import annotations

import math

import pytest

from gmt_network_enrichment.noise_estimator.domain.emission import (
    NIGHT_PENALTY_DB,
    NOISE_MIN_FLOW,
    combine_lden,
    emission_db,
)


def test_below_threshold_returns_none() -> None:
    assert emission_db(NOISE_MIN_FLOW, 50.0) is None
    assert emission_db(0.0, 50.0) is None


def test_non_positive_speed_returns_none() -> None:
    assert emission_db(100.0, 0.0) is None
    assert emission_db(100.0, -10.0) is None


def test_doubling_flow_adds_about_3db() -> None:
    a = emission_db(100.0, 50.0)
    b = emission_db(200.0, 50.0)
    assert a is not None
    assert b is not None
    assert b - a == pytest.approx(10.0 * math.log10(2.0), abs=0.05)


def test_monotonic_in_flow() -> None:
    low = emission_db(50.0, 50.0)
    high = emission_db(500.0, 50.0)
    assert low is not None
    assert high is not None
    assert high > low


def test_monotonic_in_speed() -> None:
    slow = emission_db(200.0, 30.0)
    fast = emission_db(200.0, 80.0)
    assert slow is not None
    assert fast is not None
    assert fast > slow


def test_combine_lden_all_none() -> None:
    assert combine_lden(None, None, None) is None


def test_combine_lden_matches_manual() -> None:
    l_day, l_eve, l_night = 60.0, 58.0, 55.0
    expected = 10.0 * math.log10(
        (
            12.0 * 10.0 ** (l_day / 10.0)
            + 4.0 * 10.0 ** ((l_eve + 5.0) / 10.0)
            + 8.0 * 10.0 ** ((l_night + 10.0) / 10.0)
        )
        / 24.0
    )
    assert combine_lden(l_day, l_eve, l_night) == pytest.approx(round(expected, 1))


def test_combine_lden_night_only_applies_penalty() -> None:
    # Only the night period contributes: Lden = 10log10(8*10^((L+10)/10)/24).
    l_night = 50.0
    expected = 10.0 * math.log10(8.0 * 10.0 ** ((l_night + NIGHT_PENALTY_DB) / 10.0) / 24.0)
    assert combine_lden(None, None, l_night) == pytest.approx(round(expected, 1))
