"""Unit tests for noise_estimator.core (pure fc -> fc)."""

from __future__ import annotations

from gmt_network_enrichment.noise_estimator.core.noise_estimator_core import (
    NOISE_PROPERTIES,
    NOISE_SOURCE_TYPE_ROAD,
    PROP_NOISE_DAY,
    PROP_NOISE_EVENING,
    PROP_NOISE_LDEN,
    PROP_NOISE_LNIGHT,
    PROP_NOISE_NIGHT,
    PROP_NOISE_SOURCE_TYPE,
    compute_link_noise,
    estimate_noise_emission,
)


def _link(flow24hrs: float | None, speed: float | None, extra: dict | None = None) -> dict:
    props: dict = {}
    if flow24hrs is not None:
        props["flow24hrs"] = flow24hrs
    if speed is not None:
        props["speed"] = speed
    if extra:
        props.update(extra)
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[6.4, 52.1], [6.41, 52.11]]},
        "properties": props,
    }


def _fc(features: list[dict], props: dict | None = None) -> dict:
    fc: dict = {"type": "FeatureCollection", "features": features}
    if props is not None:
        fc["properties"] = props
    return fc


def test_compute_link_noise_keys() -> None:
    out = compute_link_noise({"flow24hrs": 5000.0, "speed": 50.0})
    assert set(out) == set(NOISE_PROPERTIES)


def test_source_type_always_road() -> None:
    out = compute_link_noise({"flow24hrs": 0.0, "speed": 0.0})
    assert out[PROP_NOISE_SOURCE_TYPE] == NOISE_SOURCE_TYPE_ROAD


def test_zero_flow_gives_none_levels() -> None:
    out = compute_link_noise({"flow24hrs": 0.0, "speed": 50.0})
    assert out[PROP_NOISE_DAY] is None
    assert out[PROP_NOISE_EVENING] is None
    assert out[PROP_NOISE_NIGHT] is None
    assert out[PROP_NOISE_LDEN] is None
    assert out[PROP_NOISE_LNIGHT] is None


def test_lnight_equals_night() -> None:
    out = compute_link_noise({"flow24hrs": 10000.0, "speed": 50.0})
    assert out[PROP_NOISE_LNIGHT] == out[PROP_NOISE_NIGHT]


def test_missing_fields_are_safe() -> None:
    out = compute_link_noise({})
    assert out[PROP_NOISE_LDEN] is None
    assert out[PROP_NOISE_SOURCE_TYPE] == NOISE_SOURCE_TYPE_ROAD


def test_invalid_field_values_are_safe() -> None:
    out = compute_link_noise({"flow24hrs": "not-a-number", "speed": None})
    assert out[PROP_NOISE_LDEN] is None


def test_estimate_preserves_geometry_and_existing_props() -> None:
    fc = _fc([_link(8000.0, 50.0, extra={"linkId": "L1", "mode": "CAR"})])
    out = estimate_noise_emission(fc)
    feat = out["features"][0]
    assert feat["geometry"] == fc["features"][0]["geometry"]
    assert feat["properties"]["linkId"] == "L1"
    assert feat["properties"]["mode"] == "CAR"
    for prop in NOISE_PROPERTIES:
        assert prop in feat["properties"]


def test_estimate_adds_exactly_the_noise_props() -> None:
    fc = _fc([_link(8000.0, 50.0, extra={"linkId": "L1"})])
    out = estimate_noise_emission(fc)
    in_props = set(fc["features"][0]["properties"])
    out_props = set(out["features"][0]["properties"])
    assert out_props - in_props == set(NOISE_PROPERTIES)


def test_estimate_returns_new_feature_collection() -> None:
    fc = _fc([_link(8000.0, 50.0)])
    out = estimate_noise_emission(fc)
    assert out["type"] == "FeatureCollection"
    # Original input feature must not be mutated.
    assert PROP_NOISE_LDEN not in fc["features"][0]["properties"]


def test_estimate_passes_through_top_level_properties() -> None:
    fc = _fc([_link(8000.0, 50.0)], props={"bbox": [6.4, 52.1, 6.5, 52.2], "modes": ["CAR"]})
    out = estimate_noise_emission(fc)
    assert out["properties"]["bbox"] == [6.4, 52.1, 6.5, 52.2]
    assert out["properties"]["modes"] == ["CAR"]


def test_estimate_empty_collection() -> None:
    out = estimate_noise_emission(_fc([]))
    assert out["features"] == []


def test_busy_fast_road_is_louder_than_quiet_slow_road() -> None:
    busy = compute_link_noise({"flow24hrs": 20000.0, "speed": 80.0})
    quiet = compute_link_noise({"flow24hrs": 500.0, "speed": 30.0})
    assert busy[PROP_NOISE_LDEN] > quiet[PROP_NOISE_LDEN]
