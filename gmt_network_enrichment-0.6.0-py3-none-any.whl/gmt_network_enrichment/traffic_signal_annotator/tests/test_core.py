"""Unit tests for traffic_signal_annotator_core — pure functions, no I/O."""

from __future__ import annotations

import math

from gmt_network_enrichment.traffic_signal_annotator.core.traffic_signal_annotator_core import (
    annotate_network,
    build_signal_query,
    parse_signal_elements,
    signals_to_features,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_M_PER_DEG_LAT = 111_320.0


def _offset_coords(lon: float, lat: float, delta_m: float) -> tuple[float, float]:
    """Shift *lon* eastward by *delta_m* metres (flat-earth approximation)."""
    cos_lat = math.cos(math.radians(lat))
    d_lon = delta_m / (_M_PER_DEG_LAT * cos_lat)
    return lon + d_lon, lat


def _make_fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features), "properties": {}}


def _make_link(to_lon: float, to_lat: float) -> dict:
    """Minimal directed LineString feature ending at *(to_lon, to_lat)*."""
    from_lon, from_lat = to_lon - 0.001, to_lat
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [[from_lon, from_lat], [to_lon, to_lat]],
        },
        "properties": {},
    }


# ---------------------------------------------------------------------------
# build_signal_query
# ---------------------------------------------------------------------------


def test_build_signal_query_contains_tag() -> None:
    query = build_signal_query([6.0, 52.0, 6.2, 52.1])
    assert 'highway"="traffic_signals' in query


def test_build_signal_query_bbox_order() -> None:
    # Overpass uses (south, west, north, east) — i.e. lat_min first.
    query = build_signal_query([6.0, 52.0, 6.2, 52.1])
    # The coord string must start with minLat (52.0), not minLon (6.0).
    assert "52.0,6.0,52.1,6.2" in query


def test_build_signal_query_timeout() -> None:
    query = build_signal_query([6.0, 52.0, 6.2, 52.1], timeout=30)
    assert "timeout:30" in query


# ---------------------------------------------------------------------------
# parse_signal_elements
# ---------------------------------------------------------------------------


def test_parse_signal_elements_basic() -> None:
    elements = [
        {"type": "node", "id": 1, "lat": 52.0, "lon": 6.0},
        {"type": "node", "id": 2, "lat": 52.1, "lon": 6.1},
    ]
    result = parse_signal_elements(elements)
    assert result == [(6.0, 52.0), (6.1, 52.1)]


def test_parse_signal_elements_skips_ways() -> None:
    elements = [
        {"type": "way", "id": 99},
        {"type": "node", "id": 1, "lat": 52.0, "lon": 6.0},
    ]
    result = parse_signal_elements(elements)
    assert len(result) == 1


def test_parse_signal_elements_skips_missing_coords() -> None:
    elements = [
        {"type": "node", "id": 1, "lat": 52.0},  # missing lon
        {"type": "node", "id": 2, "lat": 52.1, "lon": 6.1},
    ]
    result = parse_signal_elements(elements)
    assert len(result) == 1
    assert result[0] == (6.1, 52.1)


def test_parse_signal_elements_empty() -> None:
    assert parse_signal_elements([]) == []


# ---------------------------------------------------------------------------
# annotate_network — spatial matching
# ---------------------------------------------------------------------------


def test_annotate_exact_match() -> None:
    """toNode coincides exactly with a signal node → trafficSignal=True."""
    to_lon, to_lat = 6.1234, 52.0456
    fc = _make_fc(_make_link(to_lon, to_lat))
    signal_coords = [(to_lon, to_lat)]

    result_fc, stats = annotate_network(fc, signal_coords, tolerance_m=15.0)

    assert result_fc["features"][0]["properties"]["trafficSignal"] is True
    assert stats["annotated"] == 1
    assert stats["total"] == 1
    assert stats["signal_nodes_found"] == 1


def test_annotate_within_tolerance() -> None:
    """toNode 10 m from a signal node, tolerance 15 m → True."""
    to_lon, to_lat = 6.1234, 52.0456
    sig_lon, sig_lat = _offset_coords(to_lon, to_lat, 10.0)
    fc = _make_fc(_make_link(to_lon, to_lat))
    signal_coords = [(sig_lon, sig_lat)]

    result_fc, stats = annotate_network(fc, signal_coords, tolerance_m=15.0)

    assert result_fc["features"][0]["properties"]["trafficSignal"] is True
    assert stats["annotated"] == 1


def test_annotate_outside_tolerance() -> None:
    """toNode 20 m from a signal node, tolerance 15 m → False."""
    to_lon, to_lat = 6.1234, 52.0456
    sig_lon, sig_lat = _offset_coords(to_lon, to_lat, 20.0)
    fc = _make_fc(_make_link(to_lon, to_lat))
    signal_coords = [(sig_lon, sig_lat)]

    result_fc, stats = annotate_network(fc, signal_coords, tolerance_m=15.0)

    assert result_fc["features"][0]["properties"]["trafficSignal"] is False
    assert stats["annotated"] == 0


def test_annotate_exactly_on_tolerance_boundary() -> None:
    """Distance equals tolerance exactly → True (inclusive boundary)."""
    to_lon, to_lat = 6.1234, 52.0456
    sig_lon, sig_lat = _offset_coords(to_lon, to_lat, 15.0)
    fc = _make_fc(_make_link(to_lon, to_lat))
    signal_coords = [(sig_lon, sig_lat)]

    result_fc, _ = annotate_network(fc, signal_coords, tolerance_m=15.0)

    assert result_fc["features"][0]["properties"]["trafficSignal"] is True


def test_annotate_multiple_links() -> None:
    """Only the link whose toNode is near the signal is marked True."""
    to_lon, to_lat = 6.1234, 52.0456
    far_lon, far_lat = 6.2000, 52.1000  # >1 km away

    fc = _make_fc(
        _make_link(to_lon, to_lat),  # near signal
        _make_link(far_lon, far_lat),  # far from signal
    )
    signal_coords = [(to_lon, to_lat)]

    result_fc, stats = annotate_network(fc, signal_coords, tolerance_m=15.0)

    assert result_fc["features"][0]["properties"]["trafficSignal"] is True
    assert result_fc["features"][1]["properties"]["trafficSignal"] is False
    assert stats["annotated"] == 1
    assert stats["total"] == 2


def test_annotate_no_signal_coords() -> None:
    """Empty signal list → all links False, no crash."""
    fc = _make_fc(_make_link(6.1, 52.0))
    result_fc, stats = annotate_network(fc, [], tolerance_m=15.0)

    assert result_fc["features"][0]["properties"]["trafficSignal"] is False
    assert stats["annotated"] == 0
    assert stats["signal_nodes_found"] == 0


def test_annotate_empty_network() -> None:
    """Empty network → stats all zero, no crash."""
    fc = _make_fc()
    result_fc, stats = annotate_network(fc, [(6.1, 52.0)], tolerance_m=15.0)

    assert result_fc["features"] == []
    assert stats["total"] == 0
    assert stats["annotated"] == 0


def test_annotate_preserves_existing_properties() -> None:
    """Pre-existing feature properties must not be removed."""
    to_lon, to_lat = 6.1234, 52.0456
    feat = _make_link(to_lon, to_lat)
    feat["properties"]["speed"] = 50
    feat["properties"]["capacity"] = 1200

    fc = _make_fc(feat)
    result_fc, _ = annotate_network(fc, [(to_lon, to_lat)], tolerance_m=15.0)

    props = result_fc["features"][0]["properties"]
    assert props["speed"] == 50
    assert props["capacity"] == 1200
    assert "trafficSignal" in props


def test_annotate_picks_nearest_signal() -> None:
    """When multiple signal nodes exist, the nearest one determines the result."""
    to_lon, to_lat = 6.1234, 52.0456
    near_lon, near_lat = _offset_coords(to_lon, to_lat, 8.0)  # 8 m away
    far_lon, far_lat = _offset_coords(to_lon, to_lat, 100.0)  # 100 m away

    fc = _make_fc(_make_link(to_lon, to_lat))
    signal_coords = [(far_lon, far_lat), (near_lon, near_lat)]

    result_fc, stats = annotate_network(fc, signal_coords, tolerance_m=15.0)

    assert result_fc["features"][0]["properties"]["trafficSignal"] is True
    assert stats["annotated"] == 1


# ---------------------------------------------------------------------------
# signals_to_features
# ---------------------------------------------------------------------------


def test_signals_to_features_builds_tagged_points() -> None:
    feats = signals_to_features([(5.0, 52.0), (6.1, 52.5)])
    assert len(feats) == 2
    assert feats[0]["type"] == "Feature"
    assert feats[0]["geometry"] == {"type": "Point", "coordinates": [5.0, 52.0]}
    assert feats[0]["properties"]["assetType"] == "trafficSignal"


def test_signals_to_features_empty() -> None:
    assert signals_to_features([]) == []


# ---------------------------------------------------------------------------
# fetch_signal_coords — Overpass banner is suppressed in local-PBF mode
# ---------------------------------------------------------------------------


def _patch_overpass(monkeypatch, *, pbf_path) -> None:
    """Stub the Overpass helpers so fetch_signal_coords does no real I/O."""
    import gmt_shared.overpass as _ov

    monkeypatch.setattr(_ov, "_resolve_pbf_path", lambda _osm_path: pbf_path)
    monkeypatch.setattr(_ov, "fetch_overpass", lambda *_a, **_k: {"elements": []}, raising=True)


def test_fetch_signal_coords_prints_http_banner_without_pbf(monkeypatch, capsys) -> None:
    from gmt_network_enrichment.traffic_signal_annotator.core.traffic_signal_annotator_core import (
        fetch_signal_coords,
    )

    _patch_overpass(monkeypatch, pbf_path=None)
    fetch_signal_coords([5.0, 52.0, 5.1, 52.1])
    out = capsys.readouterr().out
    assert "[Overpass] endpoint" in out
    assert "[Overpass] query" in out


def test_fetch_signal_coords_suppresses_http_banner_with_pbf(monkeypatch, capsys) -> None:
    from pathlib import Path

    from gmt_network_enrichment.traffic_signal_annotator.core.traffic_signal_annotator_core import (
        fetch_signal_coords,
    )

    _patch_overpass(monkeypatch, pbf_path=Path("dummy.osm.pbf"))
    fetch_signal_coords([5.0, 52.0, 5.1, 52.1], osm_path="dummy.osm.pbf")
    out = capsys.readouterr().out
    assert "[Overpass] endpoint" not in out
    assert "[Overpass] query" not in out
