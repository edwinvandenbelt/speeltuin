"""Local debug runner for traffic_sign_fetcher.

Determines a bounding box (either passed explicitly with ``--bbox`` or derived
from a network parquet given with ``--network``), fetches traffic-sign point
features (NDW when in the Netherlands and ``--ndw-data`` is supplied, otherwise
OSM Overpass), and writes them as a GeoParquet ``FeatureCollection``.

Usage
-----
    python -m traffic_sign_fetcher.traffic_sign_fetcher_runner \\
        --network output/deventer/abc123-NETWORK-CAR.parquet \\
        --ndw-data data/ndw_traffic_signs.json \\
        --output output/deventer/abc123-TRAFFIC-ASSETS.parquet

    python -m traffic_sign_fetcher.traffic_sign_fetcher_runner \\
        --bbox 4.9 52.0 5.0 52.1 \\
        --output out/signs.parquet

Prerequisites
-------------
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri.removeprefix("file://"), "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


def _bbox_from_network(uri: str) -> list[float]:
    from gmt_shared.geoparquet import from_geoparquet

    fc = from_geoparquet(_read_uri(uri))
    bbox: list[float] | None = (fc.get("properties") or {}).get("bbox")
    if bbox and len(bbox) >= 4:
        return [float(v) for v in bbox[:4]]
    lons: list[float] = []
    lats: list[float] = []
    for feat in fc.get("features") or []:
        for coord in (feat.get("geometry") or {}).get("coordinates") or []:
            lons.append(float(coord[0]))
            lats.append(float(coord[1]))
    if not lons:
        raise ValueError("Cannot determine bounding box — network has no geometry.")
    return [min(lons), min(lats), max(lons), max(lats)]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Fetch traffic-sign point features (NDW or OSM Overpass) to a GeoParquet."
    )
    src = parser.add_mutually_exclusive_group(required=True)
    src.add_argument(
        "--network",
        metavar="URI",
        help="Network parquet URI to derive the bbox from (s3://bucket/key or local path).",
    )
    src.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Explicit bounding box in WGS-84 decimal degrees.",
    )
    parser.add_argument(
        "--ndw-data",
        default=None,
        metavar="URI",
        help="Pre-provisioned NDW GeoJSON dataset URI (used when bbox is in the Netherlands).",
    )
    parser.add_argument(
        "--output",
        required=True,
        metavar="URI",
        help="Output GeoParquet URI for the traffic-sign FeatureCollection.",
    )
    parser.add_argument(
        "--tiles",
        type=int,
        default=3,
        metavar="N",
        help="NxN Overpass tile grid (default: 3).",
    )
    parser.add_argument(
        "--overpass-timeout",
        type=int,
        default=40,
        metavar="SECONDS",
        help="Overpass HTTP + server-side timeout in seconds (default: 40).",
    )
    parser.add_argument(
        "--osm-path",
        dest="osm_path",
        default=None,
        metavar="PATH",
        help=(
            "Path to a local .osm.pbf extract to read instead of querying the "
            "Overpass HTTP API. Falls back to the OSM_PBF_PATH environment "
            "variable / .env when omitted."
        ),
    )
    parser.add_argument(
        "--osm-workers",
        dest="osm_workers",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Worker processes for reading the local .osm.pbf extract. Defaults "
            "to the OSM_PBF_WORKERS environment variable / CPU count (capped at 8)."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        metavar="PATH",
        help="Path to .env file for AWS credentials (auto-discovered if omitted).",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import to_geoparquet

    from gmt_network_enrichment.traffic_sign_fetcher.core.traffic_sign_fetcher_core import (
        fetch_sign_features,
    )

    bbox = list(args.bbox) if args.bbox else _bbox_from_network(args.network)
    print(f"Bbox     : {bbox}")

    ndw_data: dict | None = None
    if args.ndw_data:
        print(f"NDW data : {args.ndw_data}")
        ndw_data = json.loads(_read_uri(args.ndw_data))

    fc, stats = fetch_sign_features(
        bbox,
        ndw_data=ndw_data,
        tiles=args.tiles,
        timeout=args.overpass_timeout,
        osm_path=args.osm_path,
        osm_workers=args.osm_workers,
    )
    print(f"Stats    : {stats}")

    print(f"Writing  : {args.output}")
    _write_uri(args.output, to_geoparquet(fc))
    print("Done.")


if __name__ == "__main__":
    main()
