"""Unit tests for logistiek_prepare (Databricks and heavy steps mocked)."""

from __future__ import annotations

import contextlib
from pathlib import Path

import pytest

from logistiek.logistiek_prepare.core import logistiek_prepare_core as core
from logistiek.logistiek_prepare.core.logistiek_prepare_core import (
    restore_probe_attributes,
    run_pipeline,
)

_NL_BBOX = (5.60, 52.02, 5.70, 52.06)
_NON_NL_BBOX = (7.00, 51.00, 7.10, 51.05)


def _raw_link(wvk_id, coords, from_node, to_node, *, heen=True, terug=True, traces=0):
    daily = traces * 2.0
    n_open = int(heen) + int(terug)
    flow = (
        {
            "work": 0.0,
            "recreational": 0.0,
            "education": 0.0,
            "shopping": 0.0,
            "unknown": daily / n_open,
        }
        if traces
        else {}
    )
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": wvk_id,
            "mode": "CAR",
            "fromNode": from_node,
            "toNode": to_node,
            "rijrichting_heen": heen,
            "rijrichting_terug": terug,
            "cap_heen": None,
            "cap_terug": None,
            "rijstroken_heen": 1 if heen else None,
            "rijstroken_terug": 1 if terug else None,
            "max_snelheid_heen": 50 if heen else 0,
            "max_snelheid_terug": 50 if terug else 0,
            "flow_heen": flow if heen else {},
            "flow_terug": flow if terug else {},
            "flow_dp_heen": {},
            "flow_dp_terug": {},
            "length": 700.0,
            "wvkIds": [wvk_id],
            "name": "Industrieweg",
            "streetName": "Industrieweg",
            "roadNumber": None,
            "roadType": "weg",
            "probeTraceCount": traces,
            "probeMeanSpeedKmh": 42.0 if traces else None,
        },
    }


def _raw_network() -> dict:
    return {
        "type": "FeatureCollection",
        "features": [
            _raw_link(11, [[5.61, 52.03], [5.62, 52.03]], 1, 2, traces=6),
            _raw_link(12, [[5.62, 52.03], [5.63, 52.03]], 2, 3, heen=False, traces=3),
            _raw_link(13, [[5.62, 52.03], [5.62, 52.04]], 2, 4),
        ],
        "properties": {"source": "Logistiek-Bridgestone", "traceDate": "2026-08-21"},
    }


# ---------------------------------------------------------------------------
# restore_probe_attributes
# ---------------------------------------------------------------------------


class TestRestoreProbeAttributes:
    def test_two_way_splits_count_one_way_keeps_it(self):
        network = {
            "features": [
                {"properties": {"linkId": 11}},
                {"properties": {"linkId": -11}},
                {"properties": {"linkId": -12}},
                {"properties": {"linkId": "-13"}},
                {"properties": {"linkId": 999}},
            ]
        }
        updated = restore_probe_attributes(network, _raw_network())
        props = [f["properties"] for f in network["features"]]
        assert updated == 4
        assert props[0]["probeTraceCount"] == props[1]["probeTraceCount"] == 3.0
        assert props[2]["probeTraceCount"] == 3.0  # one-way: full count
        assert props[0]["probeMeanSpeedKmh"] == 42.0
        assert props[3]["probeTraceCount"] == 0.0
        assert "probeTraceCount" not in props[4]

    def test_driven_speed_from_probes_limit_untouched(self):
        raw = _raw_network()
        raw["features"][1]["properties"]["probeMeanSpeedKmh"] = 3.0  # too low to trust
        network = {
            "features": [
                {"properties": {"linkId": 11, "speed": 50, "speedLimit": 50}},
                {"properties": {"linkId": -12, "speed": 50, "speedLimit": 50}},
                {"properties": {"linkId": 13, "speed": 50, "speedLimit": 50}},
            ]
        }
        restore_probe_attributes(network, raw)
        p11, p12, p13 = (f["properties"] for f in network["features"])
        assert (p11["speed"], p11["speedLimit"]) == (42.0, 50)
        assert (p12["speed"], p12["speedLimit"]) == (50, 50)  # 3 km/h ignored
        assert (p13["speed"], p13["speedLimit"]) == (50, 50)  # no traces


# ---------------------------------------------------------------------------
# run_pipeline — validation
# ---------------------------------------------------------------------------


class TestRunPipelineValidation:
    def test_non_nl_bbox_raises(self, tmp_path):
        with pytest.raises(ValueError, match="only covers the Netherlands"):
            run_pipeline(*_NON_NL_BBOX, tmp_path, trace_date="2026-08-21")

    def test_invalid_date_raises_before_databricks(self, tmp_path, monkeypatch):
        monkeypatch.setattr(core, "_fetch_spectrum_zones", lambda *_a, **_k: pytest.fail("called"))
        with pytest.raises(ValueError, match="ISO date"):
            run_pipeline(*_NL_BBOX, tmp_path, trace_date="21-08-2026")

    def test_existing_outputs_skip_pipeline(self, tmp_path, monkeypatch):
        for product in ("NETWORK", "FEEDLINK", "ZONE", "ROUTES"):
            (tmp_path / f"area1-{product}-CAR.parquet").write_bytes(b"x")
        monkeypatch.setattr(core, "_fetch_spectrum_zones", lambda *_a, **_k: pytest.fail("called"))
        assert run_pipeline(*_NL_BBOX, tmp_path, trace_date="2026-08-21") == "area1"


# ---------------------------------------------------------------------------
# run_pipeline — end to end with mocked Databricks / joiner / matrix
# ---------------------------------------------------------------------------


@pytest.fixture
def mocked_pipeline(monkeypatch):
    calls: dict = {}

    zones_fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [
                        [[5.60, 52.02], [5.70, 52.02], [5.70, 52.06], [5.60, 52.06], [5.60, 52.02]]
                    ],
                },
                "properties": {"zoneId": "A1", "zoneClass": "AREA"},
            }
        ],
        "properties": {},
    }
    monkeypatch.setattr(core, "_fetch_spectrum_zones", lambda *_a, **_k: zones_fc)

    @contextlib.contextmanager
    def _fake_connect():
        class _Conn:
            @contextlib.contextmanager
            def cursor(self):
                yield object()

        yield _Conn()

    monkeypatch.setattr("gmt_shared.databricks_sql.connect_from_env", _fake_connect)

    def _fake_fetch(_cursor, area_polygon_json, trace_date, **kwargs):
        calls["fetch"] = {"date": trace_date, "polygon": area_polygon_json, **kwargs}
        return _raw_network()

    monkeypatch.setattr(
        "logistiek.logistiek_network_fetcher.core.logistiek_network_fetcher_core."
        "fetch_logistiek_network",
        _fake_fetch,
    )

    def _fake_road(network_fc):
        calls["road"] = True
        return network_fc

    monkeypatch.setattr("prepare.core.prepare_core._apply_road_enricher", _fake_road)

    def _fake_feedlinks(_zones, _node_positions, _all_node_ids, vl_rows, mode):
        calls["feedlinks"] = {"vl_rows": vl_rows, "mode": mode}
        return {"type": "FeatureCollection", "features": []}

    monkeypatch.setattr(
        "gmt_network_core.feedlink_fetcher.core.feedlink_fetcher_core.build_feedlinks",
        _fake_feedlinks,
    )

    def _fake_join(zones, network_fc, **kwargs):
        calls["join"] = kwargs
        return [(None, network_fc, zones, {"features": []})]

    monkeypatch.setattr(
        "gmt_network_core.network_zone_joiner.core.network_zone_joiner_core.join_zones_to_network",
        _fake_join,
    )

    def _fake_matrix(_network_fc, _feedlinks_fc, _zone_fc, **kwargs):
        calls["matrix"] = kwargs
        return {"type": "FeatureCollection", "features": [], "properties": {}}

    monkeypatch.setattr(
        "gmt_routing.matrix_builder.core.matrix_builder_core.build_matrix", _fake_matrix
    )
    return calls


def test_run_pipeline_writes_outputs_with_freight_metadata(tmp_path: Path, mocked_pipeline):
    from gmt_shared.geoparquet import from_geoparquet

    area_id = run_pipeline(
        *_NL_BBOX,
        tmp_path,
        trace_date="2026-08-21",
        area_id="log1",
        name="Bridgestone",
        pae_per_truck=2.5,
    )

    assert area_id == "log1"
    for product in ("NETWORK", "FEEDLINK", "ZONE", "ROUTES"):
        assert (tmp_path / f"log1-{product}-CAR.parquet").exists()

    calls = mocked_pipeline
    assert calls["fetch"]["date"] == "2026-08-21"
    assert calls["fetch"]["pae_per_truck"] == 2.5
    assert calls["feedlinks"] == {"vl_rows": [], "mode": "CAR"}  # centroids only
    assert calls["matrix"]["hb_od"] is None  # synthetic OD
    assert calls["road"] is True

    network = from_geoparquet((tmp_path / "log1-NETWORK-CAR.parquet").read_bytes())
    props = network["properties"]
    assert props["source"] == "Logistiek-Bridgestone"
    assert props["flowKind"] == "freight"
    assert props["traceDate"] == "2026-08-21"
    assert props["modeLabel"] == "CAR"

    by_id = {f["properties"]["linkId"]: f["properties"] for f in network["features"]}
    # 11: two-way with traces, 12: one-way (terug only), 13: two-way without traces.
    assert set(by_id) == {11, -11, -12, 13, -13}
    assert by_id[11]["flow24hrs"] == 6.0
    assert by_id[11]["probeTraceCount"] == 3.0
    assert by_id[-12]["probeTraceCount"] == 3.0
    assert by_id[13]["flow24hrs"] == 0
    assert by_id[11]["speed"] == 42.0  # driven speed from probes
    assert by_id[11]["speedLimit"] == 50


def test_road_attributes_can_be_disabled(tmp_path: Path, mocked_pipeline):
    run_pipeline(
        *_NL_BBOX, tmp_path, trace_date="2026-08-21", area_id="log2", enrich_road_attributes=False
    )
    assert "road" not in mocked_pipeline


@pytest.mark.usefixtures("mocked_pipeline")
def test_empty_network_raises(tmp_path: Path, monkeypatch):
    monkeypatch.setattr(
        "logistiek.logistiek_network_fetcher.core.logistiek_network_fetcher_core."
        "fetch_logistiek_network",
        lambda *_a, **_k: {"type": "FeatureCollection", "features": [], "properties": {}},
    )
    with pytest.raises(ValueError, match="No logistics wegvakken"):
        run_pipeline(*_NL_BBOX, tmp_path, trace_date="2026-08-21", area_id="log3")
