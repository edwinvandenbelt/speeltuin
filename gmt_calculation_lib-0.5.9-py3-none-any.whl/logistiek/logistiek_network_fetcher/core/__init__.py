# src/logistiek/logistiek_network_fetcher/core/__init__.py
