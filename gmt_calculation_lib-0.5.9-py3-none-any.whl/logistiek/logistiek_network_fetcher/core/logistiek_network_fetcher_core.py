"""logistiek_network_fetcher core — logistics (Bridgestone) network from Databricks.

Reads the NWB wegvakken of an area from ``logistiek_bridgestone.silver`` and
attaches the freight flow of one day, derived from map-matched probe traces
(distinct traces per wegvak).  The result is a bidirectional NETWORK-RAW
FeatureCollection with the ``network_fetcher`` link schema.

The Databricks cursor is passed in by the caller (runner, notebook or
``logistiek_prepare``), so this module has no connection handling of its own.

Public API
----------
build_logistiek_network_sql(catalog, schema, ...) -> str
rows_to_feature_collection(rows, col_names, ...) -> dict
parse_trace_date(value) -> tuple[int, int, int]
fetch_logistiek_network(cursor, area_polygon_json, trace_date, ...) -> dict
"""

from __future__ import annotations

import datetime as _dt
from typing import Any

from logistiek.logistiek_network_fetcher.domain.network import (
    DEFAULT_PAE_PER_TRUCK,
    FLOW_KIND,
    LINK_PROPERTIES,
    SOURCE_LABEL,
    rows_to_feature_collection,
)
from logistiek.logistiek_network_fetcher.domain.sql import (
    DEFAULT_CATALOG,
    DEFAULT_SCHEMA,
    SEGMENTS_TABLE,
    TRACE_LINK_COLUMN,
    TRACES_TABLE,
    build_logistiek_network_sql,
)

__all__ = [
    "DEFAULT_CATALOG",
    "DEFAULT_PAE_PER_TRUCK",
    "DEFAULT_SCHEMA",
    "FLOW_KIND",
    "LINK_PROPERTIES",
    "SOURCE_LABEL",
    "build_logistiek_network_sql",
    "fetch_logistiek_network",
    "parse_trace_date",
    "rows_to_feature_collection",
]


def parse_trace_date(value: str | _dt.date) -> tuple[int, int, int]:
    """Return ``(year, month, day)`` for an ISO date string (``YYYY-MM-DD``) or date."""
    if isinstance(value, _dt.date):
        return value.year, value.month, value.day
    try:
        parsed = _dt.date.fromisoformat(str(value).strip())
    except ValueError as exc:
        raise ValueError(f"trace_date must be an ISO date (YYYY-MM-DD), got {value!r}") from exc
    return parsed.year, parsed.month, parsed.day


def fetch_logistiek_network(
    cursor: Any,
    area_polygon_json: str,
    trace_date: str | _dt.date,
    *,
    catalog: str = DEFAULT_CATALOG,
    schema: str = DEFAULT_SCHEMA,
    traces_table: str = TRACES_TABLE,
    segments_table: str = SEGMENTS_TABLE,
    link_column: str = TRACE_LINK_COLUMN,
    pae_per_truck: float = DEFAULT_PAE_PER_TRUCK,
    expansion_factor: float = 1.0,
) -> dict:
    """Fetch the logistics NETWORK-RAW for an area and one day.

    Parameters
    ----------
    cursor:
        Open DB-API cursor on Databricks.
    area_polygon_json:
        GeoJSON polygon (WGS-84) of the area; every wegvak intersecting it is
        returned completely.
    trace_date:
        Day of the probe traces (``YYYY-MM-DD``).
    catalog, schema, traces_table, segments_table, link_column:
        Location of the source tables (defaults: ``logistiek_bridgestone.silver``,
        traces matched to ``WVK_ID`` via ``candidate_link``).
    pae_per_truck, expansion_factor:
        Conversion from distinct probe traces to PAE / etmaal.
    """
    year, month, day = parse_trace_date(trace_date)
    sql = build_logistiek_network_sql(
        catalog,
        schema,
        traces_table=traces_table,
        segments_table=segments_table,
        link_column=link_column,
    )
    cursor.execute(sql, (area_polygon_json, year, month, day))
    col_names = [d[0] for d in cursor.description]
    rows = cursor.fetchall()
    fc: dict = rows_to_feature_collection(
        rows, col_names, pae_per_truck=pae_per_truck, expansion_factor=expansion_factor
    )
    fc["properties"]["traceDate"] = f"{year:04d}-{month:02d}-{day:02d}"
    return fc
