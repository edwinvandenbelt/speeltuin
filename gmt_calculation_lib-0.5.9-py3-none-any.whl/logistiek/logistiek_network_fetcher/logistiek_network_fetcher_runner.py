"""Local debug runner for logistiek_network_fetcher.

Fetches the logistics (Bridgestone) network for a bounding box and one day from
Databricks and writes a NETWORK-RAW FeatureCollection to disk or S3.

Usage
-----
    python -m logistiek.logistiek_network_fetcher.logistiek_network_fetcher_runner \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --date 2026-08-21 \\
        --output-folder ./out/ \\
        --area-id deventer-centrum

Output files
------------
``{output_folder}{area_id}-NETWORK-RAW-CAR.parquet``

Prerequisites
-------------
* Databricks credentials in the environment or a .env file (``tools/.env``),
  with SELECT rights on ``logistiek_bridgestone.silver``.
* AWS credentials (only needed for s3:// output URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from uuid import uuid4

# ---------------------------------------------------------------------------
# sys.path bootstrap  (allows running as a script without install)
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    from logistiek.logistiek_network_fetcher.domain.network import DEFAULT_PAE_PER_TRUCK
    from logistiek.logistiek_network_fetcher.domain.sql import DEFAULT_CATALOG, DEFAULT_SCHEMA

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for logistiek_network_fetcher — fetches the logistics "
            "(Bridgestone) network with probe-trace flows from Databricks and writes "
            "a NETWORK-RAW file."
        )
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        required=True,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box in WGS 84.",
    )
    parser.add_argument(
        "--date",
        required=True,
        metavar="YYYY-MM-DD",
        help="Day of the probe traces used for the 24-hour flow.",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help=(
            "Output folder URI (s3://bucket/prefix/ or local directory). "
            "Output file is named {area_id}-NETWORK-RAW-CAR.parquet."
        ),
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help="Area identifier for output file naming (UUID generated if absent).",
    )
    parser.add_argument(
        "--name", default=None, help="Human-readable area name stored in FC properties (optional)."
    )
    parser.add_argument(
        "--catalog",
        default=DEFAULT_CATALOG,
        help=f"Databricks catalog (default: {DEFAULT_CATALOG}).",
    )
    parser.add_argument(
        "--schema", default=DEFAULT_SCHEMA, help=f"Databricks schema (default: {DEFAULT_SCHEMA})."
    )
    parser.add_argument(
        "--pae-per-truck",
        type=float,
        default=DEFAULT_PAE_PER_TRUCK,
        help=f"PAE per probe vehicle (default: {DEFAULT_PAE_PER_TRUCK}).",
    )
    parser.add_argument(
        "--expansion-factor",
        type=float,
        default=1.0,
        help="Scale factor from probe sample to all freight traffic (default: 1.0).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.databricks_sql import connect_from_env
    from gmt_shared.geoparquet import to_geoparquet
    from gmt_zone_core.zone_fetcher.domain.sql import bbox_to_polygon_json

    from logistiek.logistiek_network_fetcher.core.logistiek_network_fetcher_core import (
        fetch_logistiek_network,
    )

    area_id = args.area_id or str(uuid4())
    bbox: list[float] = args.bbox
    output_folder = args.output_folder.rstrip("/") + "/"

    print(f"Area ID        : {area_id}")
    print(f"BBox           : {bbox}")
    print(f"Date           : {args.date}")
    print(f"Source         : {args.catalog}.{args.schema}")

    with connect_from_env() as conn, conn.cursor() as cur:
        fc = fetch_logistiek_network(
            cur,
            bbox_to_polygon_json(bbox),
            args.date,
            catalog=args.catalog,
            schema=args.schema,
            pae_per_truck=args.pae_per_truck,
            expansion_factor=args.expansion_factor,
        )
    fc["properties"].update(
        {"bbox": bbox, "area_id": area_id, **({"name": args.name} if args.name else {})}
    )
    features = fc.get("features") or []
    with_traces = sum(1 for f in features if f["properties"]["probeTraceCount"] > 0)
    print(f"\n{len(features)} wegvakken, {with_traces} with probe traces")

    out_uri = f"{output_folder}{area_id}-NETWORK-RAW-CAR.parquet"
    print(f"Writing        : {out_uri}")
    _write_uri(out_uri, to_geoparquet(fc))
    print("\nDone.")


if __name__ == "__main__":
    main()
