# Databricks notebook source
# ---------------------------------------------------------------------------
# logistiek_network_fetcher_nb.py — Databricks notebook for logistiek_network_fetcher.
#
# Fetches the logistics (Bridgestone) network for a bbox and one day:
# NWB wegvakken from logistiek_bridgestone.silver.nwb_road_segments with the
# freight flow from matched_probe_traces (distinct traces per wegvak).
#
# Output file (written to output_uri/)
# ────────────────────────────────────
#   {area_id}-NETWORK-RAW-CAR.parquet
# ---------------------------------------------------------------------------

# COMMAND ----------
import contextlib
import logging
import uuid

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("logistiek_network_fetcher_nb")

# COMMAND ----------
with contextlib.suppress(Exception):
    dbutils.widgets.removeAll()  # noqa: F821

dbutils.widgets.text("bbox", "5.60,52.02,5.70,52.06", "min_lon,min_lat,max_lon,max_lat")  # noqa: F821
dbutils.widgets.text("date", "", "Day of the probe traces (YYYY-MM-DD)")  # noqa: F821
dbutils.widgets.text("output_uri", "", "Output folder (/dbfs/... or /Volumes/...)")  # noqa: F821
dbutils.widgets.text("area_id", "", "Area ID (blank = uuid4)")  # noqa: F821
dbutils.widgets.text("catalog", "logistiek_bridgestone", "Catalog")  # noqa: F821
dbutils.widgets.text("schema", "silver", "Schema")  # noqa: F821
dbutils.widgets.text("pae_per_truck", "2.0", "PAE per probe vehicle")  # noqa: F821
dbutils.widgets.text("expansion_factor", "1.0", "Probe sample → all freight factor")  # noqa: F821

# COMMAND ----------
from pathlib import Path  # noqa: E402

from gmt_shared.databricks_sql import connect_from_env  # noqa: E402
from gmt_shared.geoparquet import to_geoparquet  # noqa: E402
from gmt_zone_core.zone_fetcher.domain.sql import bbox_to_polygon_json  # noqa: E402

from logistiek.logistiek_network_fetcher.core.logistiek_network_fetcher_core import (  # noqa: E402
    fetch_logistiek_network,
)

# COMMAND ----------
_bbox = [float(v) for v in dbutils.widgets.get("bbox").split(",")]  # noqa: F821
TRACE_DATE = dbutils.widgets.get("date").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()  # noqa: F821
AREA_ID = dbutils.widgets.get("area_id").strip() or str(uuid.uuid4())  # noqa: F821
if len(_bbox) != 4:
    raise ValueError("Widget 'bbox' must have exactly 4 values.")
if not TRACE_DATE or not OUTPUT_URI:
    raise ValueError("Widgets 'date' and 'output_uri' are required.")

with connect_from_env() as conn, conn.cursor() as cur:
    fc = fetch_logistiek_network(
        cur,
        bbox_to_polygon_json(_bbox),
        TRACE_DATE,
        catalog=dbutils.widgets.get("catalog").strip(),  # noqa: F821
        schema=dbutils.widgets.get("schema").strip(),  # noqa: F821
        pae_per_truck=float(dbutils.widgets.get("pae_per_truck") or "2.0"),  # noqa: F821
        expansion_factor=float(dbutils.widgets.get("expansion_factor") or "1.0"),  # noqa: F821
    )
fc["properties"].update({"bbox": _bbox, "area_id": AREA_ID})

_out = Path(OUTPUT_URI.removeprefix("file://"))
_out.mkdir(parents=True, exist_ok=True)
_path = _out / f"{AREA_ID}-NETWORK-RAW-CAR.parquet"
_path.write_bytes(to_geoparquet(fc))

_n = len(fc["features"])
_with = sum(1 for f in fc["features"] if f["properties"]["probeTraceCount"] > 0)
print(f"{_n} wegvakken ({_with} with probe traces) -> {_path}")
