"""Unit tests for logistiek_network_fetcher (no Databricks)."""

from __future__ import annotations

import datetime as dt
import json

import pytest

from logistiek.logistiek_network_fetcher.core.logistiek_network_fetcher_core import (
    FLOW_KIND,
    SOURCE_LABEL,
    build_logistiek_network_sql,
    fetch_logistiek_network,
    parse_trace_date,
    rows_to_feature_collection,
)
from logistiek.logistiek_network_fetcher.domain.network import (
    estimate_speed_limit,
    node_id,
    rijrichting_flags,
)

_COLS = [
    "wvk_id",
    "seg_idx",
    "rijrichting",
    "street_name",
    "wegnummer",
    "wegtype",
    "geom",
    "x_start_rd",
    "y_start_rd",
    "x_end_rd",
    "y_end_rd",
    "length",
    "trace_count",
    "mean_speed",
]


def _row(
    wvk_id,
    seg_idx,
    coords,
    rd_start,
    rd_end,
    *,
    rijrichting="B",
    length=100.0,
    trace_count=None,
    mean_speed=None,
    street="Industrieweg",
    wegnummer=None,
):
    geom = json.dumps({"type": "LineString", "coordinates": coords})
    return (
        wvk_id,
        seg_idx,
        rijrichting,
        street,
        wegnummer,
        "weg",
        geom,
        rd_start[0],
        rd_start[1],
        rd_end[0],
        rd_end[1],
        length,
        trace_count,
        mean_speed,
    )


def _fc(rows, **kwargs):
    return rows_to_feature_collection(rows, _COLS, **kwargs)


# ---------------------------------------------------------------------------
# SQL
# ---------------------------------------------------------------------------


class TestBuildSql:
    def test_has_four_parameters_in_order(self):
        sql = build_logistiek_network_sql()
        assert sql.count("?") == 4
        assert sql.index("ST_GeomFromGeoJSON(?)") < sql.index("t.year = ?")

    def test_uses_default_tables_and_link_column(self):
        sql = build_logistiek_network_sql()
        assert "`logistiek_bridgestone`.`silver`.`nwb_road_segments`" in sql
        assert "`logistiek_bridgestone`.`silver`.`matched_probe_traces`" in sql
        assert "COUNT(DISTINCT t.trace_id)" in sql
        assert "t.`candidate_link` IS NOT NULL" in sql

    def test_configurable_link_column(self):
        sql = build_logistiek_network_sql(link_column="candidate_mainlink")
        assert "t.`candidate_mainlink` = w.WVK_ID" in sql

    @pytest.mark.parametrize("bad", ["silver; DROP TABLE x", "a.b", "", "x`y"])
    def test_rejects_unsafe_identifiers(self, bad):
        with pytest.raises(ValueError, match="Invalid"):
            build_logistiek_network_sql(schema=bad)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@pytest.mark.parametrize(
    ("code", "expected"),
    [
        ("H", (True, False)),
        ("T", (False, True)),
        ("B", (True, True)),
        ("O", (True, True)),
        (None, (True, True)),
        (" h ", (True, False)),
    ],
)
def test_rijrichting_flags(code, expected):
    assert rijrichting_flags(code) == expected


def test_node_id_rounds_rd_metres():
    assert node_id(155000.4, 463000.6) == 155000 * 1_000_000 + 463001


@pytest.mark.parametrize(
    ("speed", "road_number", "expected"),
    [
        (23.0, None, 50),  # low urban truck speed never lowers the limit
        (58.0, None, 50),
        (65.0, None, 80),  # high truck speed raises it
        (84.0, None, 100),
        (None, "N224", 80),
        (40.0, "N224", 80),
        (None, "030", 100),  # numeric = rijksweg (A30)
        (30.0, "012", 100),
        (None, "", 50),
        (None, None, 50),
    ],
)
def test_estimate_speed_limit(speed, road_number, expected):
    assert estimate_speed_limit(speed, road_number) == expected


@pytest.mark.parametrize("value", ["2026-08-21", dt.date(2026, 8, 21), " 2026-08-21 "])
def test_parse_trace_date(value):
    assert parse_trace_date(value) == (2026, 8, 21)


def test_parse_trace_date_rejects_garbage():
    with pytest.raises(ValueError, match="ISO date"):
        parse_trace_date("21-08-2026")


# ---------------------------------------------------------------------------
# rows_to_feature_collection
# ---------------------------------------------------------------------------


class TestRowsToFeatureCollection:
    def test_segments_are_chained_into_one_link_per_wegvak(self):
        rows = [
            # Deliberately out of seg_idx order.
            _row(42, 1, [[5.1, 52.1], [5.2, 52.1]], (1000, 2000), (1100, 2000), length=60.0),
            _row(42, 0, [[5.0, 52.1], [5.1, 52.1]], (900, 2000), (1000, 2000), length=40.0),
        ]
        fc = _fc(rows)
        assert len(fc["features"]) == 1
        feat = fc["features"][0]
        assert feat["geometry"]["coordinates"] == [[5.0, 52.1], [5.1, 52.1], [5.2, 52.1]]
        props = feat["properties"]
        assert props["linkId"] == 42
        assert props["wvkIds"] == [42]
        assert props["fromNode"] == node_id(900, 2000)
        assert props["toNode"] == node_id(1100, 2000)
        assert props["length"] == 100.0
        assert props["mode"] == "CAR"

    def test_adjacent_wegvakken_share_a_node(self):
        rows = [
            _row(1, 0, [[5.0, 52.1], [5.1, 52.1]], (900, 2000), (1000.2, 2000.1)),
            _row(2, 0, [[5.1, 52.1], [5.2, 52.1]], (999.8, 1999.9), (1100, 2000)),
        ]
        a, b = (f["properties"] for f in _fc(rows)["features"])
        assert a["toNode"] == b["fromNode"]

    def test_two_way_flow_split_50_50_in_unknown_motive(self):
        rows = [_row(1, 0, [[5.0, 52.1], [5.1, 52.1]], (0, 0), (100, 0), trace_count=10)]
        props = _fc(rows, pae_per_truck=2.0)["features"][0]["properties"]
        assert props["flow_heen"]["unknown"] == 10.0
        assert props["flow_terug"]["unknown"] == 10.0
        assert props["flow_heen"]["work"] == 0.0
        assert props["flow_dp_heen"] == {"mrh": 10 / 24, "erh": 10 / 24, "rest": 10 / 24}
        assert props["probeTraceCount"] == 10

    def test_one_way_gets_full_flow_on_open_direction(self):
        rows = [
            _row(1, 0, [[5.0, 52.1], [5.1, 52.1]], (0, 0), (100, 0), rijrichting="T", trace_count=5)
        ]
        props = _fc(rows, pae_per_truck=2.0, expansion_factor=3.0)["features"][0]["properties"]
        assert props["rijrichting_heen"] is False
        assert props["flow_heen"] == {}
        assert props["flow_terug"]["unknown"] == 30.0
        assert props["max_snelheid_heen"] == 0
        assert props["rijstroken_heen"] is None

    def test_wegvak_without_traces_has_empty_flow_dicts(self):
        rows = [_row(1, 0, [[5.0, 52.1], [5.1, 52.1]], (0, 0), (100, 0))]
        props = _fc(rows)["features"][0]["properties"]
        assert props["flow_heen"] == {}
        assert props["flow_terug"] == {}
        assert props["probeTraceCount"] == 0
        assert props["probeMeanSpeedKmh"] is None

    def test_speed_lanes_and_capacity(self):
        rows = [
            _row(
                1,
                0,
                [[5.0, 52.1], [5.1, 52.1]],
                (0, 0),
                (100, 0),
                trace_count=3,
                mean_speed=85.0,
                wegnummer="A12",
            )
        ]
        props = _fc(rows)["features"][0]["properties"]
        assert props["max_snelheid_heen"] == props["max_snelheid_terug"] == 100
        assert props["rijstroken_heen"] == 2
        assert props["cap_heen"] is None  # estimated by the bidirectional_splitter
        assert props["roadNumber"] == "A12"
        assert props["probeMeanSpeedKmh"] == 85.0

    def test_collection_properties(self):
        fc = _fc([_row(1, 0, [[5.0, 52.1], [5.1, 52.1]], (0, 0), (100, 0))])
        assert fc["properties"]["source"] == SOURCE_LABEL
        assert fc["properties"]["flowKind"] == FLOW_KIND
        assert fc["properties"]["modes"] == ["CAR"]

    def test_degenerate_geometry_is_skipped(self):
        rows = [_row(1, 0, [[5.0, 52.1]], (0, 0), (0, 0))]
        assert _fc(rows)["features"] == []


# ---------------------------------------------------------------------------
# Compatibility with the bidirectional_splitter
# ---------------------------------------------------------------------------


class TestSplitterCompatibility:
    def _split(self, rows):
        from gmt_network_core.bidirectional_splitter.core.bidirectional_splitter_core import (
            post_process_features,
        )

        return post_process_features(_fc(rows)["features"])

    def test_wegvak_without_traces_is_kept_in_both_directions(self):
        directed = self._split([_row(7, 0, [[5.0, 52.1], [5.1, 52.1]], (0, 0), (100, 0))])
        assert sorted(f["properties"]["linkId"] for f in directed) == [-7, 7]
        assert all(f["properties"]["flow24hrs"] == 0 for f in directed)

    def test_flows_and_estimated_capacity_after_split(self):
        directed = self._split(
            [
                _row(
                    7,
                    0,
                    [[5.0, 52.1], [5.1, 52.1]],
                    (0, 0),
                    (100, 0),
                    trace_count=4,
                    mean_speed=45.0,
                )
            ]
        )
        by_id = {f["properties"]["linkId"]: f["properties"] for f in directed}
        assert by_id[7]["flow24hrs"] == 4.0
        assert by_id[-7]["flow24hrs"] == 4.0
        assert by_id[7]["speed"] == 50
        assert by_id[7]["capacity"] is not None
        assert by_id[7]["capacity"] > 0

    def test_one_way_wegvak_yields_single_directed_link(self):
        directed = self._split(
            [
                _row(
                    7,
                    0,
                    [[5.0, 52.1], [5.1, 52.1]],
                    (0, 0),
                    (100, 0),
                    rijrichting="H",
                    trace_count=2,
                )
            ]
        )
        assert [f["properties"]["linkId"] for f in directed] == [7]


# ---------------------------------------------------------------------------
# fetch_logistiek_network
# ---------------------------------------------------------------------------


class _FakeCursor:
    def __init__(self, rows):
        self._rows = rows
        self.executed: list = []
        self.description = [(c,) for c in _COLS]

    def execute(self, sql, params):
        self.executed.append((sql, params))

    def fetchall(self):
        return self._rows


def test_fetch_logistiek_network_executes_with_date_parameters():
    cur = _FakeCursor([_row(1, 0, [[5.0, 52.1], [5.1, 52.1]], (0, 0), (100, 0), trace_count=1)])
    fc = fetch_logistiek_network(cur, '{"type":"Polygon"}', "2026-08-21", pae_per_truck=1.0)
    _sql, params = cur.executed[0]
    assert params == ('{"type":"Polygon"}', 2026, 8, 21)
    assert fc["properties"]["traceDate"] == "2026-08-21"
    assert fc["features"][0]["properties"]["flow_heen"]["unknown"] == 0.5
