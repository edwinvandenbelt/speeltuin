# src/logistiek/logistiek_network_fetcher/tests/__init__.py
