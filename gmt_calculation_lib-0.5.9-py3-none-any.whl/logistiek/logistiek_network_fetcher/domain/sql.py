"""SQL construction for logistiek_network_fetcher — no I/O.

Builds the parameterised Databricks SQL that reads the logistics (Bridgestone)
network for an area:

* ``nwb_road_segments`` — NWB wegvakken split into segments (``WVK_ID`` +
  ``seg_idx``) with an RD geometry (``segment_geom``, EPSG:28992).
* ``matched_probe_traces`` — map-matched probe points; ``candidate_link`` is the
  matched NWB ``WVK_ID`` (``NULL`` for unmatched points).

Every wegvak that intersects the area polygon is returned *completely* (all its
segments), together with the number of distinct traces and their mean speed on
the requested day.
"""

from __future__ import annotations

import re

DEFAULT_CATALOG = "logistiek_bridgestone"
DEFAULT_SCHEMA = "silver"
TRACES_TABLE = "matched_probe_traces"
SEGMENTS_TABLE = "nwb_road_segments"

#: Trace column holding the matched NWB ``WVK_ID``.
TRACE_LINK_COLUMN = "candidate_link"

_IDENTIFIER_RE = re.compile(r"^[A-Za-z0-9_]+$")


def _identifier(value: str, what: str) -> str:
    """Validate a catalog / schema / table / column name (interpolated into SQL)."""
    if not _IDENTIFIER_RE.match(value or ""):
        raise ValueError(f"Invalid {what}: {value!r}")
    return value


def build_logistiek_network_sql(
    catalog: str = DEFAULT_CATALOG,
    schema: str = DEFAULT_SCHEMA,
    *,
    traces_table: str = TRACES_TABLE,
    segments_table: str = SEGMENTS_TABLE,
    link_column: str = TRACE_LINK_COLUMN,
) -> str:
    """Return the parameterised SQL for the logistics network of one day.

    Positional ``?`` parameters, in order:

    1. GeoJSON polygon of the area (WGS-84)
    2. year (int)
    3. month (int)
    4. day (int)

    One row per wegvak segment, ordered by ``wvk_id, seg_idx``.  Columns:
    ``wvk_id, seg_idx, rijrichting, street_name, wegnummer, wegtype, geom``
    (GeoJSON, WGS-84), ``x_start_rd, y_start_rd, x_end_rd, y_end_rd, length``
    (metres), ``trace_count`` and ``mean_speed`` (``NULL`` when no trace was
    matched to the wegvak that day).
    """
    db = f"`{_identifier(catalog, 'catalog')}`.`{_identifier(schema, 'schema')}`"
    segs = f"{db}.`{_identifier(segments_table, 'segments table')}`"
    traces = f"{db}.`{_identifier(traces_table, 'traces table')}`"
    link = f"`{_identifier(link_column, 'link column')}`"
    return f"""\
WITH area AS (
    SELECT ST_Transform(ST_GeomFromGeoJSON(?), 28992) AS geom
),
wegvakken AS (
    SELECT DISTINCT s.WVK_ID
    FROM   {segs} s
    JOIN   area a ON ST_Intersects(s.segment_geom, a.geom)
),
segments AS (
    SELECT s.*
    FROM   {segs} s
    JOIN   wegvakken w ON s.WVK_ID = w.WVK_ID
),
traces AS (
    SELECT t.{link}                     AS WVK_ID,
           COUNT(DISTINCT t.trace_id)   AS trace_count,
           ROUND(AVG(t.speed), 2)       AS mean_speed
    FROM   {traces} t
    JOIN   wegvakken w ON t.{link} = w.WVK_ID
    WHERE  t.year = ? AND t.month = ? AND t.day = ?
      AND  t.{link} IS NOT NULL
    GROUP  BY t.{link}
)
SELECT s.WVK_ID                                          AS wvk_id,
       s.seg_idx                                         AS seg_idx,
       s.RIJRICHTNG                                      AS rijrichting,
       s.STT_NAAM                                        AS street_name,
       s.WEGNUMMER                                       AS wegnummer,
       s.WEGTYPE                                         AS wegtype,
       ST_AsGeoJSON(ST_Transform(s.segment_geom, 4326))  AS geom,
       ST_X(ST_StartPoint(s.segment_geom))               AS x_start_rd,
       ST_Y(ST_StartPoint(s.segment_geom))               AS y_start_rd,
       ST_X(ST_EndPoint(s.segment_geom))                 AS x_end_rd,
       ST_Y(ST_EndPoint(s.segment_geom))                 AS y_end_rd,
       ST_Length(s.segment_geom)                         AS length,
       t.trace_count                                     AS trace_count,
       t.mean_speed                                      AS mean_speed
FROM   segments s
LEFT JOIN traces t ON s.WVK_ID = t.WVK_ID
ORDER  BY s.WVK_ID, s.seg_idx"""
