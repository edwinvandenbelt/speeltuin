"""GeoJSON network assembly for logistiek_network_fetcher — no I/O.

Converts the segment rows of :func:`..sql.build_logistiek_network_sql` into a
**bidirectional NETWORK-RAW** FeatureCollection with the same link properties as
``gmt_network_core.network_fetcher`` (``linkId``, ``fromNode``, ``toNode``,
``rijrichting_*``, ``cap_*``, ``rijstroken_*``, ``max_snelheid_*``,
``flow_*``, ``flow_dp_*``, ``length``, ``wvkIds``, …), so the downstream
network_cleaner, bidirectional_splitter and everything after it work unchanged.

* One link per NWB wegvak: the segments are chained in ``seg_idx`` order and
  ``linkId`` = ``WVK_ID``.
* Node ids are derived from the rounded RD start / end coordinates
  (``round(x) * 1_000_000 + round(y)``, same scheme as the pedestrian network in
  ``network_fetcher``), so wegvakken that meet at a junction share a node.
* Flow: distinct probe traces per day x ``pae_per_truck`` x ``expansion_factor``
  (PAE / etmaal), all in motive ``unknown``.  Split 50/50 over both directions
  when the wegvak is two-way, otherwise fully on the open direction.  Dayparts
  are uniform (``daily / 24`` PAE/h each), since the probe data has no profile.
* A wegvak without traces gets **empty** flow dicts: the bidirectional_splitter
  then keeps it based on ``rijrichting_*`` alone (a zero-sum dict would drop it,
  which would tear holes in a network built from sampled probe data).
* Capacity is left ``None``; the splitter estimates it from speed and lanes.
"""

from __future__ import annotations

import json
from typing import Any

#: Motive keys of the flow dicts — same order as ``network_fetcher``.
MOTIEF_KEYS: tuple[str, ...] = ("work", "recreational", "education", "shopping", "unknown")
DAYPART_KEYS: tuple[str, ...] = ("mrh", "erh", "rest")

#: Default PAE per probe vehicle (truck).
DEFAULT_PAE_PER_TRUCK = 2.0

#: Network-level marker so consumers can tell freight flows from passenger flows.
FLOW_KIND = "freight"
SOURCE_LABEL = "Logistiek-Bridgestone"

#: Speed limit (km/h) by road number: NWB ``WEGNUMMER`` is numeric for
#: rijkswegen (``"030"`` = A30), ``N…`` for provincial roads, empty otherwise.
_MOTORWAY_SPEED = 100
_N_ROAD_SPEED = 80
_DEFAULT_SPEED = 50

#: The mean probe (truck) speed may only *raise* the estimate: trucks brake at
#: junctions, stop and queue (median ~23 km/h on urban roads), so a low mean
#: says little about the limit, while a high mean does rule out a 50 road.
#: Thresholds: mean above the bound → at least that limit.
_RAISE_FROM_TRUCK_SPEED: tuple[tuple[float, int], ...] = (
    (78.0, _MOTORWAY_SPEED),
    (62.0, _N_ROAD_SPEED),
)

#: Properties on every NETWORK-RAW feature (``network_fetcher`` schema + extras).
LINK_PROPERTIES: tuple[str, ...] = (
    "linkId",
    "mode",
    "fromNode",
    "toNode",
    "rijrichting_heen",
    "cap_heen",
    "rijstroken_heen",
    "max_snelheid_heen",
    "flow_heen",
    "flow_dp_heen",
    "rijrichting_terug",
    "cap_terug",
    "rijstroken_terug",
    "max_snelheid_terug",
    "flow_terug",
    "flow_dp_terug",
    "length",
    "roadWidthM",
    "roadWidthMinM",
    "roadWidthMaxM",
    "roadWidthReliability",
    "wvkIds",
    "streetName",
    "name",
    "roadNumber",
    "roadType",
    "probeTraceCount",
    "probeMeanSpeedKmh",
)


def rijrichting_flags(value: Any) -> tuple[bool, bool]:
    """Map NWB ``RIJRICHTNG`` to ``(heen, terug)`` passability.

    ``H`` = only in digitising direction, ``T`` = only against it; anything else
    (``B`` both, ``O`` unknown, empty) is treated as two-way.
    """
    code = str(value or "").strip().upper()
    if code == "H":
        return True, False
    if code == "T":
        return False, True
    return True, True


def node_id(x_rd: float, y_rd: float) -> int:
    """Node id from RD coordinates (metre precision)."""
    return round(x_rd) * 1_000_000 + round(y_rd)


def estimate_speed_limit(mean_truck_speed: float | None, road_number: str | None) -> int:
    """Estimate the speed limit (km/h) of a wegvak.

    Base on the road number (rijksweg 100, N-weg 80, other 50); a high mean
    probe (truck) speed can raise it, a low one never lowers it.
    """
    number = str(road_number or "").strip().upper()
    if number.isdigit():
        speed = _MOTORWAY_SPEED
    elif number.startswith("N"):
        speed = _N_ROAD_SPEED
    else:
        speed = _DEFAULT_SPEED
    if mean_truck_speed is not None:
        for lower, limit in _RAISE_FROM_TRUCK_SPEED:
            if mean_truck_speed > lower:
                speed = max(speed, limit)
                break
    return speed


def _lanes_for_speed(speed: int) -> int:
    return 2 if speed >= _MOTORWAY_SPEED else 1


def _segment_coords(geom_val: Any) -> list[list[float]]:
    geom = json.loads(geom_val) if isinstance(geom_val, str) else (geom_val or {})
    coords = geom.get("coordinates") or []
    if geom.get("type") == "MultiLineString":
        return [list(c) for part in coords for c in part]
    if geom.get("type") == "LineString":
        return [list(c) for c in coords]
    return []


def _flow_dicts(
    daily_pae: float | None, open_dir: bool, n_open: int
) -> tuple[dict[str, float], dict[str, float]]:
    """``(flow, flow_dp)`` for one direction; empty dicts when there is no data."""
    if daily_pae is None or not open_dir or n_open == 0:
        return {}, {}
    share = daily_pae / n_open
    flow = dict.fromkeys(MOTIEF_KEYS, 0.0)
    flow["unknown"] = share
    return flow, dict.fromkeys(DAYPART_KEYS, share / 24.0)


def rows_to_feature_collection(
    rows: list[tuple],
    col_names: list[str],
    *,
    pae_per_truck: float = DEFAULT_PAE_PER_TRUCK,
    expansion_factor: float = 1.0,
) -> dict:
    """Build the NETWORK-RAW FeatureCollection from segment rows.

    Parameters
    ----------
    rows, col_names:
        Result rows and column names of the logistics network SQL.
    pae_per_truck:
        PAE per probe vehicle.
    expansion_factor:
        Scale factor from probe sample to all freight traffic (1.0 = raw probe
        counts).
    """
    by_wvk: dict[Any, list[dict]] = {}
    for row in rows:
        record = dict(zip(col_names, row, strict=False))
        by_wvk.setdefault(record["wvk_id"], []).append(record)

    features: list[dict] = []
    for wvk_id, segments in by_wvk.items():
        segments.sort(key=lambda r: r.get("seg_idx") or 0)
        coords: list[list[float]] = []
        for seg in segments:
            seg_coords = _segment_coords(seg.get("geom"))
            if coords and seg_coords and coords[-1] == seg_coords[0]:
                seg_coords = seg_coords[1:]
            coords.extend(seg_coords)
        if len(coords) < 2:
            continue

        first, last = segments[0], segments[-1]
        heen, terug = rijrichting_flags(first.get("rijrichting"))
        n_open = int(heen) + int(terug)
        trace_count = first.get("trace_count")
        mean_speed = first.get("mean_speed")
        daily_pae = (
            float(trace_count) * pae_per_truck * expansion_factor
            if trace_count is not None
            else None
        )
        flow_heen, flow_dp_heen = _flow_dicts(daily_pae, heen, n_open)
        flow_terug, flow_dp_terug = _flow_dicts(daily_pae, terug, n_open)

        road_number = first.get("wegnummer")
        speed = estimate_speed_limit(
            float(mean_speed) if mean_speed is not None else None, road_number
        )
        lanes = _lanes_for_speed(speed)
        street = first.get("street_name") or ""

        props: dict[str, Any] = {
            "linkId": int(wvk_id),
            "mode": "CAR",
            "fromNode": node_id(first["x_start_rd"], first["y_start_rd"]),
            "toNode": node_id(last["x_end_rd"], last["y_end_rd"]),
            "rijrichting_heen": heen,
            "cap_heen": None,
            "rijstroken_heen": lanes if heen else None,
            "max_snelheid_heen": speed if heen else 0,
            "flow_heen": flow_heen,
            "flow_dp_heen": flow_dp_heen,
            "rijrichting_terug": terug,
            "cap_terug": None,
            "rijstroken_terug": lanes if terug else None,
            "max_snelheid_terug": speed if terug else 0,
            "flow_terug": flow_terug,
            "flow_dp_terug": flow_dp_terug,
            "length": float(sum(float(s.get("length") or 0.0) for s in segments)),
            "roadWidthM": None,
            "roadWidthMinM": None,
            "roadWidthMaxM": None,
            "roadWidthReliability": None,
            "wvkIds": [int(wvk_id)],
            "streetName": street,
            "name": street,
            "roadNumber": road_number,
            "roadType": first.get("wegtype"),
            "probeTraceCount": int(trace_count) if trace_count is not None else 0,
            "probeMeanSpeedKmh": float(mean_speed) if mean_speed is not None else None,
        }
        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": coords},
                "properties": props,
            }
        )

    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "source": SOURCE_LABEL,
            "flowKind": FLOW_KIND,
            "modes": ["CAR"],
            "fields": list(LINK_PROPERTIES),
        },
    }
