"""Local debug runner for osm_flow_estimator.

Reads a directed network GeoParquet (output of parallel_link_finder) and a
zones GeoParquet (output of zone_population_estimator), estimates synthetic
24-hour traffic flow, and writes the enriched network back as GeoParquet.

Usage
-----
    python -m osm.osm_flow_estimator.osm_flow_estimator_runner \\
        --network-uri ./deventer-NETWORK-CAR.parquet \\
        --zones-uri   ./deventer-ZONE-CAR.parquet \\
        --output-folder ./output/ \\
        --area-id deventer-centrum

Output
------
``{output_folder}/{area_id}-NETWORK-CAR.parquet``
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        print(f"Written {len(data):,} bytes → s3://{bucket}/{key}")
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for osm_flow_estimator — estimates synthetic 24-hour "
            "traffic flow for every directed link in an OSM network."
        )
    )
    parser.add_argument(
        "--network-uri",
        required=True,
        metavar="URI",
        help="Full URI of the directed network GeoParquet (s3:// or local path).",
    )
    parser.add_argument(
        "--zones-uri",
        required=True,
        metavar="URI",
        help="Full URI of the zone GeoParquet (s3:// or local path).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder (s3://bucket/prefix/ or local directory).",
    )
    parser.add_argument(
        "--area-id",
        default=None,
        help="Area identifier used in the output filename (default: 'network').",
    )
    parser.add_argument("--trip-rate", type=float, default=3.5, help="Trips per person per day.")
    parser.add_argument("--local-radius", type=float, default=75.0, help="Local road radius (m).")
    parser.add_argument(
        "--collector-radius", type=float, default=200.0, help="Collector road radius (m)."
    )
    parser.add_argument(
        "--arterial-radius", type=float, default=500.0, help="Arterial road radius (m)."
    )
    parser.add_argument(
        "--highway-radius", type=float, default=1500.0, help="Highway road radius (m)."
    )
    parser.add_argument(
        "--absorption-factor",
        type=float,
        default=0.6,
        help="Fraction of lower-class flow absorbed by higher-class links.",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env
    if args.env_file:
        env_file_path = Path(args.env_file)
    else:
        env_file_path = Path(__file__).resolve().parent.parent.parent.parent / "tools" / ".env"
    for k, v in _read_env_file(env_file_path).items():
        os.environ.setdefault(k, v)

    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
        level=logging.INFO,
    )

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow

    area_id: str = args.area_id or "network"
    output_folder: str = args.output_folder.rstrip("/")

    print(f"Reading network  : {args.network_uri}")
    network_fc = from_geoparquet(_read_uri(args.network_uri))
    n_links = len(network_fc.get("features") or [])
    print(f"  {n_links:,} network link features loaded")

    print(f"Reading zones    : {args.zones_uri}")
    zones_fc = from_geoparquet(_read_uri(args.zones_uri))
    n_zones = len(zones_fc.get("features") or [])
    print(f"  {n_zones} zone features loaded")

    print("Estimating flow…")
    updated_fc, stats = estimate_flow(
        network_fc,
        zones_fc,
        trip_rate_per_person=args.trip_rate,
        local_radius_m=args.local_radius,
        collector_radius_m=args.collector_radius,
        arterial_radius_m=args.arterial_radius,
        highway_radius_m=args.highway_radius,
        absorption_factor=args.absorption_factor,
    )
    print(f"Stats : {stats}")

    parquet_bytes = to_geoparquet(updated_fc)
    out_uri = f"{output_folder}/{area_id}-NETWORK-CAR.parquet"
    _write_uri(out_uri, parquet_bytes)
    print("Done.")


if __name__ == "__main__":
    main()
