# Databricks notebook source
# ---------------------------------------------------------------------------
# osm_flow_estimator_nb.py — Databricks notebook for osm_flow_estimator.
#
# This notebook:
#   1. Reads widget parameters (network URI, zones URI, output URI, algo params).
#   2. Reads both GeoParquet files from S3 / local path.
#   3. Calls estimate_flow — no Spark I/O.
#   4. Writes the enriched network GeoParquet back to S3 / local path.
#   5. Prints a stats summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("osm_flow_estimator_nb")

# COMMAND ----------
# MAGIC %pip install boto3 shapely pyarrow geopandas

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uri",
    "",
    "Full URI of the directed network GeoParquet (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "zones_uri",
    "",
    "Full URI of the zone GeoParquet (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri",
    "",
    "Full output URI for the enriched network GeoParquet",
)
dbutils.widgets.text("trip_rate_per_person", "3.5", "Trips per person per day")  # noqa: F821
dbutils.widgets.text("local_radius_m", "75.0", "Local road assignment radius (m)")  # noqa: F821
dbutils.widgets.text("collector_radius_m", "200.0", "Collector road radius (m)")  # noqa: F821
dbutils.widgets.text("arterial_radius_m", "500.0", "Arterial road radius (m)")  # noqa: F821
dbutils.widgets.text("highway_radius_m", "1500.0", "Highway radius (m)")  # noqa: F821
dbutils.widgets.text("absorption_factor", "0.6", "Propagation absorption factor")  # noqa: F821
dbutils.widgets.text("LOG_LEVEL", "INFO", "Log level (DEBUG / INFO / WARNING / ERROR)")  # noqa: F821

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402

from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow  # noqa: E402

# COMMAND ----------
# ── Widget read + validation ────────────────────────────────────────────────

NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
ZONES_URI = dbutils.widgets.get("zones_uri").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()  # noqa: F821
TRIP_RATE = float(dbutils.widgets.get("trip_rate_per_person").strip())  # noqa: F821
LOCAL_R = float(dbutils.widgets.get("local_radius_m").strip())  # noqa: F821
COLLECTOR_R = float(dbutils.widgets.get("collector_radius_m").strip())  # noqa: F821
ARTERIAL_R = float(dbutils.widgets.get("arterial_radius_m").strip())  # noqa: F821
HIGHWAY_R = float(dbutils.widgets.get("highway_radius_m").strip())  # noqa: F821
ABSORPTION = float(dbutils.widgets.get("absorption_factor").strip())  # noqa: F821

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")
if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")

logger.info("network_uri=%s  zones_uri=%s  output_uri=%s", NETWORK_URI, ZONES_URI, OUTPUT_URI)

# COMMAND ----------
# ── S3 / local helpers ──────────────────────────────────────────────────────

import os  # noqa: E402

import boto3  # noqa: E402


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/octet-stream",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    logger.info("Wrote %s  (%d bytes)", path, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run OsmFlowEstimator
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ──────────────────────────────────────────────────────────

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")
print(f"Network   : {NETWORK_URI}")
print(f"Zones     : {ZONES_URI}")
print(f"Output    : {OUTPUT_URI}")
print()

_network_fc = from_geoparquet(_read_uri(NETWORK_URI))
_n_links = len(_network_fc.get("features") or [])
print(f"Loaded {_n_links:,} network link features")

_zones_fc = from_geoparquet(_read_uri(ZONES_URI))
_n_zones = len(_zones_fc.get("features") or [])
print(f"Loaded {_n_zones} zone features")

_updated_fc, _stats = estimate_flow(
    _network_fc,
    _zones_fc,
    trip_rate_per_person=TRIP_RATE,
    local_radius_m=LOCAL_R,
    collector_radius_m=COLLECTOR_R,
    arterial_radius_m=ARTERIAL_R,
    highway_radius_m=HIGHWAY_R,
    absorption_factor=ABSORPTION,
)

_parquet_bytes = to_geoparquet(_updated_fc)
_write_uri(OUTPUT_URI, _parquet_bytes)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ─────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"OsmFlowEstimator complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Network links   : {_stats.get('links_total', '?'):,}")
print(f"  Links assigned  : {_stats.get('links_assigned', '?'):,}")
print(f"  Links zero-flow : {_stats.get('links_zero', '?'):,}")
print(f"  Total daily trips: {_stats.get('total_daily_trips', 0.0):,.0f}")
print(f"  Zones used      : {_stats.get('zonesUsed', '?')}")
print(f"  Output URI      : {OUTPUT_URI}")
print(_SEP)
