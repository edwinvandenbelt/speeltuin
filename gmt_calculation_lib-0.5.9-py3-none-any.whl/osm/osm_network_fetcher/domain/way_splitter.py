"""OSM way-splitting algorithm for osm_network_fetcher.

Splits OSM ways at intersection nodes (nodes appearing in > 1 way) so that
each resulting segment runs between two topology nodes.  This is required for
correct graph construction in the downstream ``bidirectional_splitter``.

Public API
----------
haversine_m(lon1, lat1, lon2, lat2) -> float
    Great-circle distance in metres between two WGS 84 points.
segment_length_m(coords) -> float
    Total length of a linestring in metres.
split_way(way, node_use_count) -> list[dict]
    Split a single way at its intersection nodes.
split_all_ways(elements) -> list[dict]
    Split all way elements from an Overpass response.
"""

from __future__ import annotations

import math

# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------


def haversine_m(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """Return the great-circle distance in metres between two WGS 84 points."""
    R = 6_371_000.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2.0) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2.0) ** 2
    return 2.0 * R * math.asin(math.sqrt(min(a, 1.0)))


def segment_length_m(coords: list[tuple[float, float]]) -> float:
    """Return the total length of a linestring ``[(lon, lat), ...]`` in metres."""
    total = 0.0
    for i in range(len(coords) - 1):
        total += haversine_m(
            coords[i][0],
            coords[i][1],
            coords[i + 1][0],
            coords[i + 1][1],
        )
    return total


# ---------------------------------------------------------------------------
# Node counting
# ---------------------------------------------------------------------------


def _build_node_use_count(ways: list[dict]) -> dict[int, int]:
    """Count how many ways each node ID appears in.

    A node with count > 1 is an intersection node and triggers a way split.
    """
    count: dict[int, int] = {}
    for way in ways:
        for nid in way.get("nodes") or []:
            count[nid] = count.get(nid, 0) + 1
    return count


# ---------------------------------------------------------------------------
# Way splitting
# ---------------------------------------------------------------------------


def split_way(
    way: dict,
    node_use_count: dict[int, int],
) -> list[dict]:
    """Split a single OSM way at its intersection nodes.

    Uses ``way["nodes"]`` for topology and ``way["geometry"]`` for coordinates
    (both populated by Overpass ``out geom``).

    Parameters
    ----------
    way:
        Overpass way element.  Must have ``id``, ``nodes`` (list of ints),
        and ``geometry`` (list of ``{lat, lon}`` dicts).
    node_use_count:
        Mapping ``node_id → use_count`` across all ways in the query.

    Returns
    -------
    List of segment dicts, each with:
    - ``way_id``        (int) — original OSM way ID
    - ``segment_index`` (int) — 0-based index within the parent way
    - ``from_node_id``  (int) — start-node OSM ID
    - ``to_node_id``    (int) — end-node OSM ID
    - ``coords``        (list of (lon, lat) tuples)
    - ``tags``          (dict[str, str]) — inherited from parent way
    """
    way_id: int = way["id"]
    node_ids: list[int] = way.get("nodes") or []
    raw_geom: list[dict] = way.get("geometry") or []
    tags: dict[str, str] = way.get("tags") or {}

    if len(node_ids) < 2:
        return []

    # Convert geometry list to (lon, lat) tuples
    geom: list[tuple[float, float]] = [(g["lon"], g["lat"]) for g in raw_geom]

    # Geometry and node arrays must match; fall back to unsplit if they don't
    if len(geom) != len(node_ids):
        return [
            {
                "way_id": way_id,
                "segment_index": 0,
                "from_node_id": node_ids[0],
                "to_node_id": node_ids[-1],
                "coords": geom,
                "tags": tags,
            }
        ]

    segments: list[dict] = []
    seg_start = 0
    seg_index = 0

    for i in range(1, len(node_ids)):
        nid = node_ids[i]
        is_last = i == len(node_ids) - 1
        # Intermediate intersection nodes trigger a split
        is_intersection = (not is_last) and (node_use_count.get(nid, 0) > 1)

        if is_intersection or is_last:
            seg_coords = geom[seg_start : i + 1]
            if len(seg_coords) >= 2:
                segments.append(
                    {
                        "way_id": way_id,
                        "segment_index": seg_index,
                        "from_node_id": node_ids[seg_start],
                        "to_node_id": nid,
                        "coords": seg_coords,
                        "tags": tags,
                    }
                )
                seg_index += 1
            seg_start = i

    return segments


def split_all_ways(elements: list[dict]) -> list[dict]:
    """Split all way elements from an Overpass response at intersection nodes.

    Parameters
    ----------
    elements:
        Overpass API response elements (mix of ``node`` and ``way`` types).

    Returns
    -------
    Flat list of segment dicts (see :func:`split_way`).
    """
    ways = [e for e in elements if e.get("type") == "way"]
    node_use_count = _build_node_use_count(ways)
    result: list[dict] = []
    for way in ways:
        result.extend(split_way(way, node_use_count))
    return result
