"""Pure-Python OSM network fetcher core — no I/O beyond Overpass HTTP.

Fetches a road network from the Overpass API for a bounding box and converts
OSM ways into the NETWORK-RAW LINK_PROPERTIES schema so that the downstream
``bidirectional_splitter`` and subsequent pipeline steps work unchanged.

Public API
----------
build_raw_network(bbox, modes, *, overpass_url, timeout) -> dict
    Fetch OSM ways and produce a merged NETWORK-RAW FeatureCollection.
ways_to_features(elements, mode) -> list[dict]
    Convert Overpass elements to LINK_PROPERTIES features for one mode.
LINK_PROPERTIES: tuple[str, ...]
    Ordered property keys for every NETWORK-RAW feature.
"""

from __future__ import annotations

import datetime
import logging

from gmt_shared.overpass import DEFAULT_OVERPASS_URL, fetch_overpass

from osm.osm_network_fetcher.domain.network import (
    LINK_PROPERTIES,
    ways_to_features,
)
from osm.osm_network_fetcher.domain.overpass import (
    VALID_MODES,
    build_network_query,
)
from osm.osm_network_fetcher.domain.way_splitter import (  # noqa: F401
    haversine_m,
    segment_length_m,
    split_all_ways,
)

logger = logging.getLogger(__name__)


def build_raw_network(
    bbox: list[float],
    modes: list[str],
    *,
    overpass_url: str = DEFAULT_OVERPASS_URL,
    timeout: int = 90,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> dict:
    """Fetch OSM ways via Overpass API and produce a NETWORK-RAW FeatureCollection.

    The output is schema-compatible with ``network_fetcher.rows_to_feature_collection``
    and can be passed directly to ``bidirectional_splitter.post_process_features``.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS 84.
    modes:
        Subset of ``["CAR", "BIKE", "PEDESTRIAN"]``.
    overpass_url:
        Overpass API endpoint URL.
    timeout:
        HTTP request timeout in seconds.

    Returns
    -------
    GeoJSON FeatureCollection dict.  The ``"properties"`` dict contains:
    - ``"modes"``:   list of mode strings
    - ``"fields"``:  list of LINK_PROPERTIES keys
    - ``"origin"``:  ``"osm"``
    - ``"bbox"``:    the input bbox
    - ``"created"``: ISO-8601 UTC timestamp

    Raises
    ------
    ValueError:
        If *modes* contains unsupported values or is empty.
    urllib.error.URLError / RuntimeError:
        On Overpass API errors.
    """
    modes_upper = [m.upper() for m in modes]
    invalid = [m for m in modes_upper if m not in VALID_MODES]
    if invalid:
        raise ValueError(f"Unsupported modes: {invalid!r}. Valid modes: {sorted(VALID_MODES)}")

    query = build_network_query(bbox, modes_upper)
    logger.info("Fetching OSM network  bbox=%s  modes=%s", bbox, modes_upper)
    data = fetch_overpass(
        query, url=overpass_url, timeout=timeout, osm_path=osm_path, osm_workers=osm_workers
    )
    elements: list[dict] = data.get("elements") or []
    logger.info("Overpass returned %d elements", len(elements))

    all_features: list[dict] = []
    for mode in modes_upper:
        features = ways_to_features(elements, mode)
        logger.info("Mode %-12s → %d features", mode, len(features))
        all_features.extend(features)

    return {
        "type": "FeatureCollection",
        "crs": {
            "type": "name",
            "properties": {"name": "EPSG:4326"},
        },
        "features": all_features,
        "properties": {
            "modes": modes_upper,
            "fields": list(LINK_PROPERTIES),
            "origin": "osm",
            "bbox": bbox,
            "created": datetime.datetime.now(datetime.UTC).isoformat(),
        },
    }
