"""Unit tests for osm_network_fetcher core — pure Python, no I/O."""

from __future__ import annotations

import pytest

from osm_network_fetcher.domain.mode_filter import (
    is_bike_way,
    is_car_way,
    is_pedestrian_way,
    is_way_for_mode,
)
from osm_network_fetcher.domain.network import (
    LINK_MANDATORY_PROPERTIES,
    _bike_directions,
    _car_directions,
    _parse_width,
    build_feature,
    parse_maxspeed,
    ways_to_features,
)
from osm_network_fetcher.domain.overpass import VALID_MODES, build_network_query

# ---------------------------------------------------------------------------
# parse_maxspeed
# ---------------------------------------------------------------------------


class TestParseMaxspeed:
    def test_plain_integer(self):
        assert parse_maxspeed("50", "residential") == 50.0

    def test_mph_conversion(self):
        result = parse_maxspeed("30 mph", "residential")
        assert result == pytest.approx(30 * 1.60934, rel=1e-3)

    def test_mph_no_space(self):
        result = parse_maxspeed("60mph", "primary")
        assert result == pytest.approx(60 * 1.60934, rel=1e-3)

    def test_none_tag_returns_highway_default(self):
        assert parse_maxspeed(None, "motorway") == 120.0
        assert parse_maxspeed(None, "residential") == 30.0
        assert parse_maxspeed(None, "living_street") == 15.0

    def test_none_string_returns_none(self):
        assert parse_maxspeed("none", "motorway") is None

    def test_unlimited_returns_none(self):
        assert parse_maxspeed("unlimited", "motorway") is None

    def test_country_code_falls_back_to_highway_default(self):
        assert parse_maxspeed("DE:rural", "primary") == 80.0

    def test_walk_returns_7(self):
        assert parse_maxspeed("walk", "living_street") == 7.0

    def test_unknown_highway_with_no_tag_returns_none(self):
        assert parse_maxspeed(None, "unknown_highway") is None


# ---------------------------------------------------------------------------
# Speed defaults by highway class
# ---------------------------------------------------------------------------


class TestSpeedDefaultsByHighwayClass:
    @pytest.mark.parametrize(
        "hw,expected",
        [
            ("motorway", 120.0),
            ("motorway_link", 120.0),
            ("trunk", 100.0),
            ("trunk_link", 100.0),
            ("primary", 80.0),
            ("primary_link", 80.0),
            ("secondary", 60.0),
            ("secondary_link", 60.0),
            ("tertiary", 50.0),
            ("tertiary_link", 50.0),
            ("unclassified", 40.0),
            ("residential", 30.0),
            ("living_street", 15.0),
            ("service", 20.0),
        ],
    )
    def test_car_highway_default(self, hw, expected):
        assert parse_maxspeed(None, hw) == expected


# ---------------------------------------------------------------------------
# Car direction parsing
# ---------------------------------------------------------------------------


class TestCarDirections:
    def test_no_oneway_is_bidirectional(self):
        assert _car_directions({}) == (True, True)

    def test_oneway_yes_forward_only(self):
        assert _car_directions({"oneway": "yes"}) == (True, False)

    def test_oneway_1_forward_only(self):
        assert _car_directions({"oneway": "1"}) == (True, False)

    def test_oneway_minus1_backward_only(self):
        assert _car_directions({"oneway": "-1"}) == (False, True)

    def test_oneway_motor_vehicle_overrides(self):
        # oneway:motor_vehicle=yes even without oneway
        assert _car_directions({"oneway:motor_vehicle": "yes"}) == (True, False)


# ---------------------------------------------------------------------------
# Bike direction parsing
# ---------------------------------------------------------------------------


class TestBikeDirections:
    def test_normal_road_bidirectional(self):
        assert _bike_directions({}) == (True, True)

    def test_car_oneway_bike_forward_only(self):
        # Default: bikes follow car oneway
        assert _bike_directions({"oneway": "yes"}) == (True, False)

    def test_car_oneway_bike_exception_bidirectional(self):
        # oneway:bicycle=no → bikes can go both ways
        assert _bike_directions({"oneway": "yes", "oneway:bicycle": "no"}) == (True, True)

    def test_oneway_bicycle_minus1_backward_only(self):
        assert _bike_directions({"oneway:bicycle": "-1"}) == (False, True)

    def test_reverse_car_oneway_bike_can_go_forward(self):
        # oneway=-1: car backward only; bikes can go forward if oneway:bicycle=no
        assert _bike_directions({"oneway": "-1", "oneway:bicycle": "no"}) == (True, True)


# ---------------------------------------------------------------------------
# Mode filter
# ---------------------------------------------------------------------------


class TestModeFilter:
    def test_car_motorway_included(self):
        assert is_car_way({"highway": "motorway"})

    def test_car_cycleway_excluded(self):
        assert not is_car_way({"highway": "cycleway"})

    def test_bike_cycleway_included(self):
        assert is_bike_way({"highway": "cycleway"})

    def test_bike_path_without_bicycle_tag_excluded(self):
        assert not is_bike_way({"highway": "path"})

    def test_bike_path_with_bicycle_yes_included(self):
        assert is_bike_way({"highway": "path", "bicycle": "yes"})

    def test_bike_residential_included(self):
        assert is_bike_way({"highway": "residential"})

    def test_bike_residential_bicycle_no_excluded(self):
        assert not is_bike_way({"highway": "residential", "bicycle": "no"})

    def test_pedestrian_footway_included(self):
        assert is_pedestrian_way({"highway": "footway"})

    def test_pedestrian_path_foot_no_excluded(self):
        assert not is_pedestrian_way({"highway": "path", "foot": "no"})

    def test_pedestrian_path_no_foot_tag_included(self):
        assert is_pedestrian_way({"highway": "path"})

    def test_unknown_mode_raises(self):
        with pytest.raises(ValueError, match="Unknown mode"):
            is_way_for_mode({}, "TRAM")


# ---------------------------------------------------------------------------
# build_feature
# ---------------------------------------------------------------------------


def _seg(way_id=1, seg_idx=0, from_nid=10, to_nid=11, tags=None, n_coords=3):
    """Build a minimal segment dict for testing build_feature."""
    coords = [(6.0 + i * 0.001, 52.0) for i in range(n_coords)]
    return {
        "way_id": way_id,
        "segment_index": seg_idx,
        "from_node_id": from_nid,
        "to_node_id": to_nid,
        "coords": coords,
        "tags": tags or {"highway": "residential"},
    }


class TestBuildFeature:
    def test_car_link_id_first_segment_is_integer_way_id(self):
        feat = build_feature(_seg(way_id=123, seg_idx=0), "CAR")
        assert feat["properties"]["linkId"] == 123
        assert isinstance(feat["properties"]["linkId"], int)

    def test_car_link_id_second_segment_is_way_id_times_1000_plus_index(self):
        feat = build_feature(_seg(way_id=123, seg_idx=1), "CAR")
        assert feat["properties"]["linkId"] == 123 * 1000 + 1

    def test_car_mode_set_correctly(self):
        assert build_feature(_seg(), "CAR")["properties"]["mode"] == "CAR"

    def test_car_nodes_set(self):
        feat = build_feature(_seg(from_nid=10, to_nid=20), "CAR")
        p = feat["properties"]
        assert p["fromNode"] == 10
        assert p["toNode"] == 20

    def test_pedestrian_nodes_are_zero(self):
        feat = build_feature(_seg(), "PEDESTRIAN")
        p = feat["properties"]
        assert p["fromNode"] == 0
        assert p["toNode"] == 0

    def test_pedestrian_speed_is_5(self):
        feat = build_feature(_seg(), "PEDESTRIAN")
        assert feat["properties"]["max_snelheid_heen"] == 5.0
        assert feat["properties"]["max_snelheid_terug"] == 5.0

    def test_pedestrian_both_directions_passable(self):
        feat = build_feature(_seg(), "PEDESTRIAN")
        assert feat["properties"]["rijrichting_heen"] is True
        assert feat["properties"]["rijrichting_terug"] is True

    def test_pedestrian_all_flows_zero(self):
        feat = build_feature(_seg(), "PEDESTRIAN")
        assert all(v == 0 for v in feat["properties"]["flow_heen"].values())
        assert all(v == 0 for v in feat["properties"]["flow_terug"].values())

    def test_bike_oneway_flow_heen_has_unknown_1(self):
        seg = _seg(tags={"highway": "residential", "oneway": "yes"})
        feat = build_feature(seg, "BIKE")
        assert feat["properties"]["flow_heen"]["unknown"] == 1
        assert feat["properties"]["flow_terug"]["unknown"] == 0

    def test_bike_bidirectional_both_flows_unknown_1(self):
        seg = _seg(tags={"highway": "residential"})
        feat = build_feature(seg, "BIKE")
        assert feat["properties"]["flow_heen"]["unknown"] == 1
        assert feat["properties"]["flow_terug"]["unknown"] == 1

    def test_car_lanes_default_to_1_when_no_tag(self):
        """With no lane tags at all, rijstroken must be 1, never None or 0."""
        feat = build_feature(_seg(tags={"highway": "residential"}), "CAR")
        p = feat["properties"]
        assert p["rijstroken_heen"] == 1
        assert p["rijstroken_terug"] == 1

    def test_car_lanes_use_tag_when_present(self):
        feat = build_feature(_seg(tags={"highway": "primary", "lanes": "4"}), "CAR")
        p = feat["properties"]
        assert p["rijstroken_heen"] == 2
        assert p["rijstroken_terug"] == 2

    def test_car_cap_is_none(self):
        feat = build_feature(_seg(), "CAR")
        assert feat["properties"]["cap_heen"] is None
        assert feat["properties"]["cap_terug"] is None

    def test_all_mandatory_link_properties_present(self):
        feat = build_feature(_seg(), "CAR")
        for key in LINK_MANDATORY_PROPERTIES:
            assert key in feat["properties"], f"Missing mandatory property: {key}"

    def test_optional_properties_absent_when_tags_missing(self):
        feat = build_feature(_seg(tags={"highway": "residential"}), "CAR")
        from osm_network_fetcher.domain.network import LINK_OPTIONAL_PROPERTIES

        for key in LINK_OPTIONAL_PROPERTIES:
            assert key not in feat["properties"], f"Optional property should be absent: {key}"

    def test_geometry_is_linestring(self):
        feat = build_feature(_seg(), "CAR")
        assert feat["geometry"]["type"] == "LineString"
        assert len(feat["geometry"]["coordinates"]) >= 2

    def test_length_positive(self):
        feat = build_feature(_seg(), "CAR")
        assert feat["properties"]["length"] > 0


# ---------------------------------------------------------------------------
# _parse_width
# ---------------------------------------------------------------------------


class TestParseWidth:
    def test_integer_string(self):
        assert _parse_width("5") == pytest.approx(5.0)

    def test_decimal_dot(self):
        assert _parse_width("5.5") == pytest.approx(5.5)

    def test_decimal_comma(self):
        assert _parse_width("5,5") == pytest.approx(5.5)

    def test_with_unit_m(self):
        assert _parse_width("6 m") == pytest.approx(6.0)

    def test_with_unit_meters(self):
        assert _parse_width("7.2 meters") == pytest.approx(7.2)

    def test_none_returns_none(self):
        assert _parse_width(None) is None

    def test_empty_string_returns_none(self):
        assert _parse_width("") is None

    def test_non_numeric_returns_none(self):
        assert _parse_width("narrow") is None

    def test_text_with_semicolon_returns_none(self):
        assert _parse_width("5;6") is None


# ---------------------------------------------------------------------------
# build_feature — optional OSM attributes
# ---------------------------------------------------------------------------


class TestBuildFeatureOptionalTags:
    def test_surface_present_when_tag_set(self):
        seg = _seg(tags={"highway": "residential", "surface": "asphalt"})
        feat = build_feature(seg, "CAR")
        assert feat["properties"]["surface"] == "asphalt"

    def test_surface_absent_when_tag_missing(self):
        feat = build_feature(_seg(tags={"highway": "residential"}), "CAR")
        assert "surface" not in feat["properties"]

    def test_width_parsed_as_float(self):
        seg = _seg(tags={"highway": "residential", "width": "6.5"})
        feat = build_feature(seg, "CAR")
        assert feat["properties"]["width"] == pytest.approx(6.5)
        assert isinstance(feat["properties"]["width"], float)

    def test_width_with_unit_parsed(self):
        seg = _seg(tags={"highway": "primary", "width": "8 m"})
        feat = build_feature(seg, "CAR")
        assert feat["properties"]["width"] == pytest.approx(8.0)

    def test_width_non_numeric_omitted(self):
        seg = _seg(tags={"highway": "residential", "width": "narrow"})
        feat = build_feature(seg, "CAR")
        assert "width" not in feat["properties"]

    def test_width_absent_when_tag_missing(self):
        feat = build_feature(_seg(tags={"highway": "residential"}), "CAR")
        assert "width" not in feat["properties"]

    def test_lit_present(self):
        seg = _seg(tags={"highway": "residential", "lit": "yes"})
        feat = build_feature(seg, "CAR")
        assert feat["properties"]["lit"] == "yes"

    def test_bridge_present(self):
        seg = _seg(tags={"highway": "primary", "bridge": "yes"})
        feat = build_feature(seg, "CAR")
        assert feat["properties"]["bridge"] == "yes"

    def test_tunnel_present(self):
        seg = _seg(tags={"highway": "primary", "tunnel": "yes"})
        feat = build_feature(seg, "CAR")
        assert feat["properties"]["tunnel"] == "yes"

    def test_layer_present(self):
        seg = _seg(tags={"highway": "primary", "bridge": "yes", "layer": "1"})
        feat = build_feature(seg, "CAR")
        assert feat["properties"]["layer"] == "1"

    def test_sidewalk_present(self):
        seg = _seg(tags={"highway": "residential", "sidewalk": "both"})
        feat = build_feature(seg, "CAR")
        assert feat["properties"]["sidewalk"] == "both"

    def test_multiple_optional_tags_all_included(self):
        tags = {
            "highway": "primary",
            "surface": "cobblestone",
            "width": "7",
            "lit": "yes",
            "bridge": "yes",
            "layer": "1",
        }
        feat = build_feature(_seg(tags=tags), "CAR")
        p = feat["properties"]
        assert p["surface"] == "cobblestone"
        assert p["width"] == pytest.approx(7.0)
        assert p["lit"] == "yes"
        assert p["bridge"] == "yes"
        assert p["layer"] == "1"

    def test_optional_tags_present_on_bike_mode(self):
        seg = _seg(tags={"highway": "cycleway", "surface": "asphalt", "width": "2.5"})
        feat = build_feature(seg, "BIKE")
        assert feat["properties"]["surface"] == "asphalt"
        assert feat["properties"]["width"] == pytest.approx(2.5)


# ---------------------------------------------------------------------------
# ways_to_features
# ---------------------------------------------------------------------------


def _make_way_element(way_id, node_ids, tags=None, n_points=None):
    if n_points is None:
        n_points = len(node_ids)
    geom = [{"lon": 6.0 + i * 0.001, "lat": 52.0} for i in range(n_points)]
    return {
        "type": "way",
        "id": way_id,
        "nodes": node_ids,
        "geometry": geom,
        "tags": tags or {"highway": "residential"},
    }


class TestWaysToFeatures:
    def test_car_way_produces_features(self):
        elements = [_make_way_element(1, [1, 2, 3], {"highway": "residential"})]
        feats = ways_to_features(elements, "CAR")
        assert len(feats) >= 1

    def test_cycleway_excluded_from_car(self):
        elements = [_make_way_element(1, [1, 2, 3], {"highway": "cycleway"})]
        feats = ways_to_features(elements, "CAR")
        assert feats == []

    def test_cycleway_included_for_bike(self):
        elements = [_make_way_element(1, [1, 2, 3], {"highway": "cycleway"})]
        feats = ways_to_features(elements, "BIKE")
        assert len(feats) >= 1

    def test_all_features_have_correct_mode(self):
        elements = [
            _make_way_element(1, [1, 2, 3], {"highway": "residential"}),
            _make_way_element(2, [4, 5, 6], {"highway": "primary"}),
        ]
        for mode in ["CAR", "BIKE", "PEDESTRIAN"]:
            feats = ways_to_features(elements, mode)
            for f in feats:
                assert f["properties"]["mode"] == mode


# ---------------------------------------------------------------------------
# build_network_query
# ---------------------------------------------------------------------------


class TestBuildNetworkQuery:
    def test_car_query_contains_motorway(self):
        q = build_network_query([6.0, 52.0, 6.1, 52.1], ["CAR"])
        assert "motorway" in q

    def test_bike_query_contains_cycleway(self):
        q = build_network_query([6.0, 52.0, 6.1, 52.1], ["BIKE"])
        assert "cycleway" in q

    def test_pedestrian_query_contains_footway(self):
        q = build_network_query([6.0, 52.0, 6.1, 52.1], ["PEDESTRIAN"])
        assert "footway" in q

    def test_bbox_order_is_south_west_north_east(self):
        q = build_network_query([6.0, 52.0, 6.1, 52.1], ["CAR"])
        # Overpass coord format: south,west,north,east = 52.0,6.0,52.1,6.1
        assert "52.0,6.0,52.1,6.1" in q

    def test_empty_modes_raises(self):
        with pytest.raises(ValueError):
            build_network_query([6.0, 52.0, 6.1, 52.1], [])

    def test_all_modes_included(self):
        q = build_network_query([6.0, 52.0, 6.1, 52.1], ["CAR", "BIKE", "PEDESTRIAN"])
        assert "motorway" in q
        assert "cycleway" in q
        assert "footway" in q

    def test_valid_modes_set(self):
        assert "CAR" in VALID_MODES
        assert "BIKE" in VALID_MODES
        assert "PEDESTRIAN" in VALID_MODES
