# Databricks notebook source
# ---------------------------------------------------------------------------
# osm_network_fetcher_nb.py — Databricks notebook interface
#
# This notebook:
#   1. Leest widget-parameters.
#   2. Bouwt een Overpass QL-query voor de opgegeven bounding box en modes.
#   3. Haalt OSM-wegdata op via de Overpass API (internet vereist).
#   4. Converteert de data naar NETWORK-RAW GeoJSON per mode.
#   5. Schrijft de output terug naar S3 (of lokaal pad).
#   6. Drukt een samenvatting af.
#
# Vereisten:
#   - Databricks cluster heeft internettoegang (voor Overpass API).
#   - AWS-credentials beschikbaar voor S3-schrijfacties.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("osm_network_fetcher_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "modes",
    "CAR,BIKE",
    "Transport modes (comma-separated: CAR, BIKE, PEDESTRIAN)",
)
dbutils.widgets.text(  # noqa: F821
    "bbox",
    "6.143,52.248,6.184,52.272",
    "Bounding box: minLon,minLat,maxLon,maxLat",
)
dbutils.widgets.text(  # noqa: F821
    "output_folder",
    "",
    "S3 output folder URI (s3://bucket/prefix/) or local path",
)
dbutils.widgets.text(  # noqa: F821
    "area_id",
    "",
    "Area identifier (UUID generated if empty)",
)
dbutils.widgets.text(  # noqa: F821
    "name",
    "",
    "Human-readable area name (optional)",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_url",
    "https://overpass-api.de/api/interpreter",
    "Overpass API endpoint URL",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_timeout",
    "90",
    "Overpass request timeout in seconds",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
import sys  # noqa: E402

# Ensure the src directory is on the path so local imports work
for _candidate in ["/Workspace/src", "/dbfs/FileStore/gmt/src"]:
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────
import uuid  # noqa: E402

from gmt_shared.overpass import fetch_overpass  # noqa: E402

from osm_network_fetcher.domain.network import LINK_PROPERTIES, ways_to_features  # noqa: E402
from osm_network_fetcher.domain.overpass import VALID_MODES, build_network_query  # noqa: E402

_modes_raw = dbutils.widgets.get("modes").strip()  # noqa: F821
MODES = [m.strip().upper() for m in _modes_raw.split(",") if m.strip()]
if not MODES:
    raise ValueError("Widget 'modes' is empty — provide at least one mode.")
_invalid = [m for m in MODES if m not in VALID_MODES]
if _invalid:
    raise ValueError(f"Unknown mode(s): {_invalid}. Valid: {sorted(VALID_MODES)}")

_bbox_raw = dbutils.widgets.get("bbox").strip()  # noqa: F821
try:
    BBOX = [float(x.strip()) for x in _bbox_raw.split(",")]
    assert len(BBOX) == 4
except ValueError, AssertionError:
    raise ValueError(
        f"Widget 'bbox' must be 4 comma-separated floats (minLon,minLat,maxLon,maxLat). Got: {_bbox_raw!r}"
    )

OUTPUT_FOLDER = dbutils.widgets.get("output_folder").strip().rstrip("/") + "/"  # noqa: F821
if not OUTPUT_FOLDER.replace("/", ""):
    raise ValueError("Widget 'output_folder' is empty.")

AREA_ID = dbutils.widgets.get("area_id").strip() or str(uuid.uuid4())  # noqa: F821
NAME = dbutils.widgets.get("name").strip() or None  # noqa: F821
OVERPASS_URL = dbutils.widgets.get("overpass_url").strip()  # noqa: F821
OVERPASS_TIMEOUT = int(dbutils.widgets.get("overpass_timeout").strip() or "90")  # noqa: F821

logger.info("modes=%s  bbox=%s  area_id=%s", MODES, BBOX, AREA_ID)
logger.info("output_folder=%s  overpass_url=%s", OUTPUT_FOLDER, OVERPASS_URL)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402


def _parse_s3_uri(uri: str):
    """Split s3://bucket/key into (bucket, key)."""
    assert uri.startswith("s3://"), f"Expected s3:// URI, got: {uri!r}"
    rest = uri[5:]
    bucket, _, key = rest.partition("/")
    return bucket, key


def _write_output(uri: str, data: bytes) -> None:
    """Write bytes to S3 or local path."""
    if uri.startswith("s3://"):
        bucket, key = _parse_s3_uri(uri)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
    else:
        import os

        os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
        with open(uri, "wb") as _fh:
            _fh.write(data)
        logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run OSM Network Fetcher
# MAGIC
# MAGIC Pas de widget-waarden hierboven aan en **voer deze cel opnieuw uit** om
# MAGIC een andere bounding box of modeset te verwerken zonder widgets opnieuw te
# MAGIC registreren of bibliotheken opnieuw te laden.

# COMMAND ----------
# ── Overpass query ─────────────────────────────────────────────────────────────

_t_start = datetime.now(UTC)

print(f"Start       : {_t_start.isoformat()}")
print(f"Area ID     : {AREA_ID}")
print(f"BBox        : {BBOX}")
print(f"Modes       : {MODES}")
print()

_query = build_network_query(BBOX, MODES)
print("Querying Overpass API …")
_data = fetch_overpass(_query, url=OVERPASS_URL, timeout=OVERPASS_TIMEOUT)
_elements = _data.get("elements") or []
print(f"Overpass elements: {len(_elements)}")

# COMMAND ----------
# ── Feature conversion + write ─────────────────────────────────────────────────

_feature_counts = {}

for _mode in MODES:
    _features = ways_to_features(_elements, _mode)
    _feature_counts[_mode] = len(_features)
    print(f"\nMode {_mode}: {len(_features)} features")

    _fc: dict = {
        "type": "FeatureCollection",
        "crs": {"type": "name", "properties": {"name": "EPSG:4326"}},
        "features": _features,
        "properties": {
            "modes": [_mode],
            "fields": list(LINK_PROPERTIES),
            "origin": "osm",
            "bbox": BBOX,
            "area_id": AREA_ID,
            **({"name": NAME} if NAME else {}),
        },
    }

    _out_uri = f"{OUTPUT_FOLDER}{AREA_ID}-NETWORK-RAW-{_mode}.geojson"
    print(f"Writing : {_out_uri}")
    _write_output(_out_uri, json.dumps(_fc, ensure_ascii=False).encode("utf-8"))

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"OSM Network Fetcher complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Area ID       : {AREA_ID}")
print(f"  BBox          : {BBOX}")
print(f"  Output folder : {OUTPUT_FOLDER}")
for _m, _n in _feature_counts.items():
    print(f"  {_m:<14}: {_n:,} features")
print(_SEP)
