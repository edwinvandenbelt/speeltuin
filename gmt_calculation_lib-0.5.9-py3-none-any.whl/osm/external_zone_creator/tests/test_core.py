"""Tests for external_zone_creator_core.

The core creates external zones on the **boundary nodes** of a network — the
vertices of its convex/concave hull — filtered by daily traffic
(``flow24hrs``).  These tests build small networks whose hull membership is
deterministic under the convex hull (a square of four corner nodes), plus a
few concave-hull cases.

Directionality convention
-------------------------
For a boundary node N:
  * a link with ``fromNode == N`` carries traffic entering the network
    -> contributes to N's **production**;
  * a link with ``toNode == N`` carries traffic leaving the network
    -> contributes to N's **attraction**.
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from osm.external_zone_creator.core.external_zone_creator_core import (
    _HIGHWAY_WEIGHTS,
    DEFAULT_EXTERNAL_SHARE,
    DEFAULT_HULL_K,
    DEFAULT_HULL_TYPE,
    DEFAULT_MIN_DAILY_MOVEMENTS,
    EXTERNAL_FEEDLINK_PROPERTIES,
    EXTERNAL_ZONE_PROPERTIES,
    create_external_zones,
)

# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------

BBOX = [0.0, 0.0, 1.0, 1.0]  # centre (0.5, 0.5)

# Four corner nodes form a square; their convex hull is all four corners.
# C is the geometric centre and is strictly interior (never a boundary node).
NODE_COORDS: dict[str, tuple[float, float]] = {
    "SW": (0.0, 0.0),
    "SE": (1.0, 0.0),
    "NE": (1.0, 1.0),
    "NW": (0.0, 1.0),
    "C": (0.5, 0.5),
}


def _link(
    from_node: str,
    to_node: str,
    capacity: float = 1000.0,
    *,
    flow24hrs: float = 1000.0,
    highway: str = "",
    ref: str = "",
    name: str = "",
    speed: float = 50.0,
    coords=None,
) -> dict:
    if coords is None:
        coords = [list(NODE_COORDS[from_node]), list(NODE_COORDS[to_node])]
    props: dict = {
        "fromNode": from_node,
        "toNode": to_node,
        "capacity": capacity,
        "flow24hrs": flow24hrs,
        "speed": speed,
        "flow": 0.0,
        "length": 1000.0,
        "ref": ref,
        "name": name,
    }
    if highway:
        props["highway"] = highway
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": props,
    }


def _zone(zone_id: str, production: float) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [0.5, 0.5]},
        "properties": {
            "zoneId": zone_id,
            "centroidLon": 0.5,
            "centroidLat": 0.5,
            "production": production,
        },
    }


def _fc(features: list) -> dict:
    return {"type": "FeatureCollection", "features": features}


ZONES_FC = _fc([_zone("z0", 1000.0), _zone("z1", 500.0)])
EMPTY_FEEDLINKS = _fc([])


def _run(
    net_features: list,
    zones_fc: dict | None = None,
    *,
    min_daily_movements: float = 0.0,
    hull_type: str = "convex",
    **kwargs,
):
    """Run create_external_zones with deterministic-hull defaults.

    ``min_daily_movements`` defaults to 0 (filter disabled) and the hull type
    to ``"convex"`` so hull membership over a square of corner nodes is
    deterministic; individual tests override these where relevant.
    """
    if zones_fc is None:
        zones_fc = ZONES_FC
    return create_external_zones(
        _fc(net_features),
        zones_fc,
        EMPTY_FEEDLINKS,
        BBOX,
        min_daily_movements=min_daily_movements,
        hull_type=hull_type,
        **kwargs,
    )


def _ext_zones(zones_out: dict) -> list[dict]:
    return [f for f in zones_out["features"] if f["properties"].get("zoneClass") == "EXTERNAL"]


def _ext_by_id(zones_out: dict) -> dict[str, dict]:
    return {f["properties"]["zoneId"]: f["properties"] for f in _ext_zones(zones_out)}


# A square ring: every corner node is a hull vertex (boundary node).
RING = [
    _link("SW", "SE"),
    _link("SE", "NE"),
    _link("NE", "NW"),
    _link("NW", "SW"),
]

# A triangle among three corners that encloses the interior node C, leaving NE
# free to be exercised in isolation (its only links are the ones a test adds).
# NE remains a hull vertex because it lies outside the SW-SE-NW triangle.
TRI = [
    _link("SW", "SE"),
    _link("SE", "NW"),
    _link("NW", "SW"),
]


# ===========================================================================
# TestBasicBehavior
# ===========================================================================


class TestBasicBehavior:
    def test_returns_three_items(self) -> None:
        assert len(_run(RING)) == 3

    def test_creates_external_zone_for_boundary_node(self) -> None:
        zones_out, _, _ = _run(RING)
        ids = _ext_by_id(zones_out)
        assert "ext_NE" in ids

    def test_all_four_corners_become_zones(self) -> None:
        zones_out, _, _ = _run(RING)
        ids = set(_ext_by_id(zones_out))
        assert ids == {"ext_SW", "ext_SE", "ext_NE", "ext_NW"}

    def test_interior_node_gets_no_zone(self) -> None:
        # C is strictly inside the square; it must never receive a zone even
        # though it has an incident link.
        net = [*RING, _link("C", "NE")]
        zones_out, _, _ = _run(net)
        assert "ext_C" not in _ext_by_id(zones_out)

    def test_no_duplicate_zone_per_boundary_node(self) -> None:
        # NE appears in two links but must yield exactly one zone.
        net = [*RING, _link("SW", "NE"), _link("NE", "SE")]
        zones_out, _, _ = _run(net)
        ids = [f["properties"]["zoneId"] for f in _ext_zones(zones_out)]
        assert ids.count("ext_NE") == 1

    def test_existing_zones_preserved(self) -> None:
        zones_out, _, _ = _run(RING)
        original = {f["properties"]["zoneId"] for f in ZONES_FC["features"]}
        result = {f["properties"]["zoneId"] for f in zones_out["features"]}
        assert original.issubset(result)

    def test_existing_feedlinks_preserved(self) -> None:
        existing_fl = _fc(
            [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0.5, 0.5], [0.2, 0.2]]},
                    "properties": {
                        "zoneId": "z0",
                        "fromNode": "ZONE_z0",
                        "toNode": "A",
                        "length": 500.0,
                        "capacity": 9999.0,
                        "flow": 0.0,
                    },
                }
            ]
        )
        _, feedlinks_out, _ = create_external_zones(
            _fc(RING), ZONES_FC, existing_fl, BBOX, min_daily_movements=0.0, hull_type="convex"
        )
        assert any(f["properties"]["zoneId"] == "z0" for f in feedlinks_out["features"])

    def test_original_fcs_not_mutated(self) -> None:
        zc = len(ZONES_FC["features"])
        fc = len(EMPTY_FEEDLINKS["features"])
        _run(RING)
        assert len(ZONES_FC["features"]) == zc
        assert len(EMPTY_FEEDLINKS["features"]) == fc


# ===========================================================================
# TestBoundaryDetection
# ===========================================================================


class TestBoundaryDetection:
    def test_convex_hull_keeps_only_outer_nodes(self) -> None:
        # Square of corners plus a central node linked to a corner.  Only the
        # four corners are on the convex hull.
        net = [*RING, _link("C", "SW")]
        zones_out, _, _ = _run(net, hull_type="convex")
        assert set(_ext_by_id(zones_out)) == {"ext_SW", "ext_SE", "ext_NE", "ext_NW"}

    def test_concave_hull_default_type(self) -> None:
        assert DEFAULT_HULL_TYPE == "concave"
        assert DEFAULT_HULL_K == 3

    def test_concave_hull_square_returns_corners(self) -> None:
        # For a plain square + interior node, the concave hull equals the
        # convex hull: the four corners.
        net = [*RING, _link("C", "NW")]
        zones_out, _, _ = _run(net, hull_type="concave", hull_k=3)
        assert set(_ext_by_id(zones_out)) == {"ext_SW", "ext_SE", "ext_NE", "ext_NW"}

    def test_stats_report_hull_type(self) -> None:
        _, _, stats = _run(RING, hull_type="convex")
        assert stats["hullType"] == "convex"


# ===========================================================================
# TestMovementFilter
# ===========================================================================


class TestMovementFilter:
    def test_node_kept_when_incoming_daily_reaches_threshold(self) -> None:
        # NE has an incoming (fromNode) link with high daily flow -> kept.
        net = [
            _link("SW", "SE", flow24hrs=1000.0),
            _link("SE", "NE", flow24hrs=1000.0),
            _link("NE", "NW", flow24hrs=1000.0),
            _link("NW", "SW", flow24hrs=1000.0),
        ]
        zones_out, _, _ = create_external_zones(
            _fc(net),
            ZONES_FC,
            EMPTY_FEEDLINKS,
            BBOX,
            min_daily_movements=150.0,
            hull_type="convex",
        )
        assert "ext_NE" in _ext_by_id(zones_out)

    def test_node_dropped_when_both_directions_below_threshold(self) -> None:
        # Every ring link has flow 50 (< 150) -> all corners filtered out.
        low = [
            _link(a, b, flow24hrs=50.0)
            for a, b in (("SW", "SE"), ("SE", "NE"), ("NE", "NW"), ("NW", "SW"))
        ]
        zones_out, _, stats = create_external_zones(
            _fc(low),
            ZONES_FC,
            EMPTY_FEEDLINKS,
            BBOX,
            min_daily_movements=150.0,
            hull_type="convex",
        )
        assert _ext_zones(zones_out) == []
        assert stats["externalZones"] == 0

    def test_node_kept_when_only_one_direction_reaches_threshold(self) -> None:
        # NE: incoming (fromNode NE->SE) daily 500, outgoing (SW->NE) daily 10.
        # 500 >= 150 -> kept.
        net = [
            _link("NE", "SE", flow24hrs=500.0),
            _link("SW", "NE", flow24hrs=10.0),
            _link("SE", "NW", flow24hrs=1000.0),
            _link("NW", "SW", flow24hrs=1000.0),
        ]
        zones_out, _, _ = create_external_zones(
            _fc(net),
            ZONES_FC,
            EMPTY_FEEDLINKS,
            BBOX,
            min_daily_movements=150.0,
            hull_type="convex",
        )
        assert "ext_NE" in _ext_by_id(zones_out)

    def test_threshold_zero_keeps_all_boundary_nodes(self) -> None:
        low = [
            _link(a, b, flow24hrs=1.0)
            for a, b in (("SW", "SE"), ("SE", "NE"), ("NE", "NW"), ("NW", "SW"))
        ]
        zones_out, _, _ = create_external_zones(
            _fc(low),
            ZONES_FC,
            EMPTY_FEEDLINKS,
            BBOX,
            min_daily_movements=0.0,
            hull_type="convex",
        )
        assert set(_ext_by_id(zones_out)) == {"ext_SW", "ext_SE", "ext_NE", "ext_NW"}

    def test_default_threshold_is_300(self) -> None:
        assert DEFAULT_MIN_DAILY_MOVEMENTS == 300.0

    def test_default_threshold_filters_low_flow_nodes(self) -> None:
        # Call without min_daily_movements -> default 300 applies.
        low = [
            _link(a, b, flow24hrs=10.0)
            for a, b in (("SW", "SE"), ("SE", "NE"), ("NE", "NW"), ("NW", "SW"))
        ]
        _, _, stats = create_external_zones(
            _fc(low), ZONES_FC, EMPTY_FEEDLINKS, BBOX, hull_type="convex"
        )
        assert stats["externalZones"] == 0

    def test_stats_filtered_count(self) -> None:
        # Only NE carries high daily flow (via an interior link); the three
        # enclosing corners flow low -> 3 filtered, 1 kept.
        net = [
            _link("SW", "SE", flow24hrs=10.0),
            _link("SE", "NW", flow24hrs=10.0),
            _link("NW", "SW", flow24hrs=10.0),
            _link("NE", "C", flow24hrs=1000.0),
        ]
        _, _, stats = create_external_zones(
            _fc(net),
            ZONES_FC,
            EMPTY_FEEDLINKS,
            BBOX,
            min_daily_movements=150.0,
            hull_type="convex",
        )
        assert stats["boundaryNodes"] == 4
        assert stats["filteredNodes"] == 3
        assert stats["externalZones"] == 1

    def test_stats_min_daily_movements_echoed(self) -> None:
        _, _, stats = _run(RING, min_daily_movements=42.0)
        assert stats["minDailyMovements"] == 42.0


# ===========================================================================
# TestZoneProperties
# ===========================================================================


class TestZoneProperties:
    def _zone(self) -> dict:
        zones_out, _, _ = _run([*RING, _link("SW", "NE")])
        return _ext_by_id(zones_out)["ext_NE"]

    def test_zone_class_is_external(self) -> None:
        assert self._zone()["zoneClass"] == "EXTERNAL"

    def test_zone_id_format(self) -> None:
        assert self._zone()["zoneId"] == "ext_NE"

    def test_centroid_matches_node_coords(self) -> None:
        z = self._zone()
        assert z["centroidLon"] == pytest.approx(1.0)
        assert z["centroidLat"] == pytest.approx(1.0)

    def test_geometry_is_point(self) -> None:
        zones_out, _, _ = _run(RING)
        ext = next(f for f in _ext_zones(zones_out) if f["properties"]["zoneId"] == "ext_NE")
        assert ext["geometry"]["type"] == "Point"

    def test_n_buildings_is_zero(self) -> None:
        assert self._zone()["nBuildings"] == 0

    def test_all_expected_properties_present(self) -> None:
        z = self._zone()
        for key in EXTERNAL_ZONE_PROPERTIES:
            assert key in z, f"Missing property: {key}"


# ===========================================================================
# TestProduction
# ===========================================================================


class TestProduction:
    def test_production_proportional_to_capacity(self) -> None:
        # NE and NW both produce (fromNode links); NE has 3x NW's capacity.
        net = [
            _link("NE", "SW", capacity=3000.0),
            _link("NW", "SE", capacity=1000.0),
        ]
        zones_out, _, _ = _run(net, zones_fc=_fc([_zone("z0", 1000.0)]))
        ids = _ext_by_id(zones_out)
        assert ids["ext_NE"]["production"] == pytest.approx(
            ids["ext_NW"]["production"] * 3, rel=1e-3
        )

    def test_total_external_production_equals_share_times_population(self) -> None:
        net = [_link("NE", "SW"), _link("NW", "SE")]
        total_pop = 1500.0
        zones_out, _, _ = _run(net, external_share=0.40)
        ext_total = sum(p["production"] for p in _ext_by_id(zones_out).values())
        assert ext_total == pytest.approx(0.40 * total_pop, rel=1e-3)

    def test_custom_external_share(self) -> None:
        net = [_link("NE", "SW"), _link("NW", "SE")]
        total_pop = 1500.0
        zones_out, _, _ = _run(net, external_share=0.20)
        ext_total = sum(p["production"] for p in _ext_by_id(zones_out).values())
        assert ext_total == pytest.approx(0.20 * total_pop, rel=1e-3)

    def test_zero_population_gives_zero_production(self) -> None:
        net = [*TRI, _link("NE", "C")]
        zones_out, _, _ = _run(net, zones_fc=_fc([_zone("z0", 0.0)]))
        assert _ext_by_id(zones_out)["ext_NE"]["production"] == pytest.approx(0.0)


# ===========================================================================
# TestDirectionality
# ===========================================================================


class TestDirectionality:
    def test_fromnode_only_gives_production_no_attraction(self) -> None:
        # NE only ever appears as fromNode -> production only.
        net = [_link("NE", "SW"), _link("NE", "SE"), _link("NW", "SE")]
        zones_out, _, _ = _run(net, external_share=1.0)
        ne = _ext_by_id(zones_out)["ext_NE"]
        assert ne["production"] > 0.0
        assert ne["attraction"] == pytest.approx(0.0)

    def test_tonode_only_gives_attraction_no_production(self) -> None:
        # NE only ever appears as toNode -> attraction only.
        net = [_link("SW", "NE"), _link("SE", "NE"), _link("SW", "NW")]
        zones_out, _, _ = _run(net, external_share=1.0)
        ne = _ext_by_id(zones_out)["ext_NE"]
        assert ne["attraction"] > 0.0
        assert ne["production"] == pytest.approx(0.0)

    def test_bidirectional_node_has_both(self) -> None:
        net = [_link("NE", "SW"), _link("SW", "NE"), _link("NW", "SE")]
        zones_out, _, _ = _run(net, external_share=1.0)
        ne = _ext_by_id(zones_out)["ext_NE"]
        assert ne["production"] > 0.0
        assert ne["attraction"] > 0.0

    def test_attraction_proportional_to_capacity(self) -> None:
        # SW and SE both attract (toNode links); SW gets 3x SE's capacity.
        net = [
            _link("NE", "SW", capacity=3000.0),
            _link("NW", "SE", capacity=1000.0),
        ]
        zones_out, _, _ = _run(net, external_share=1.0)
        ids = _ext_by_id(zones_out)
        assert ids["ext_SW"]["attraction"] == pytest.approx(
            ids["ext_SE"]["attraction"] * 3, rel=1e-3
        )

    def test_total_attraction_equals_budget(self) -> None:
        net = [_link("NE", "SW"), _link("NW", "SE")]
        total_pop = 1500.0
        zones_out, _, _ = _run(net, external_share=0.40)
        ext_attr = sum(p["attraction"] for p in _ext_by_id(zones_out).values())
        assert ext_attr == pytest.approx(0.40 * total_pop, rel=1e-3)


# ===========================================================================
# TestFeedlinks
# ===========================================================================


class TestFeedlinks:
    def _ext_feedlinks(self, net: list) -> list[dict]:
        _, feedlinks_out, _ = _run(net)
        return [
            f for f in feedlinks_out["features"] if f["properties"]["zoneId"].startswith("ext_")
        ]

    def _ne_feedlinks(self, net: list) -> list[dict]:
        return [f for f in self._ext_feedlinks(net) if f["properties"]["zoneId"] == "ext_NE"]

    def test_two_feedlinks_per_external_zone(self) -> None:
        # One boundary node (NE); the rest interior -> exactly two feedlinks.
        net = [*RING, _link("SW", "NE")]
        fls = self._ne_feedlinks(net)
        assert len(fls) == 2

    def test_entry_feedlink_from_zone_node_to_boundary_node(self) -> None:
        fls = self._ne_feedlinks([*RING, _link("SW", "NE")])
        entry = next(f for f in fls if f["properties"]["fromNode"].startswith("ZONE_"))
        assert entry["properties"]["fromNode"] == "ZONE_ext_NE"
        assert entry["properties"]["toNode"] == "NE"

    def test_exit_feedlink_from_boundary_node_to_zone_node(self) -> None:
        fls = self._ne_feedlinks([*RING, _link("SW", "NE")])
        exit_fl = next(f for f in fls if not f["properties"]["fromNode"].startswith("ZONE_"))
        assert exit_fl["properties"]["fromNode"] == "NE"
        assert exit_fl["properties"]["toNode"] == "ZONE_ext_NE"

    def test_entry_feedlink_capacity_equals_incoming_capacity(self) -> None:
        # NE->C is a fromNode link at NE (C interior) -> entry capacity = 1500.
        fls = self._ne_feedlinks([*TRI, _link("NE", "C", capacity=1500.0)])
        entry = next(f for f in fls if f["properties"]["fromNode"].startswith("ZONE_"))
        assert entry["properties"]["capacity"] == pytest.approx(1500.0)

    def test_exit_feedlink_capacity_equals_outgoing_capacity(self) -> None:
        # C->NE is a toNode link at NE (C interior) -> exit capacity = 1800.
        fls = self._ne_feedlinks([*TRI, _link("C", "NE", capacity=1800.0)])
        exit_fl = next(f for f in fls if not f["properties"]["fromNode"].startswith("ZONE_"))
        assert exit_fl["properties"]["capacity"] == pytest.approx(1800.0)

    def test_feedlink_length_is_one(self) -> None:
        for fl in self._ne_feedlinks([*RING, _link("SW", "NE")]):
            assert fl["properties"]["length"] == pytest.approx(1.0)

    def test_feedlink_flow_is_zero(self) -> None:
        for fl in self._ne_feedlinks([*RING, _link("SW", "NE")]):
            assert fl["properties"]["flow"] == pytest.approx(0.0)

    def test_all_feedlink_properties_present(self) -> None:
        for fl in self._ne_feedlinks([*RING, _link("SW", "NE")]):
            for key in EXTERNAL_FEEDLINK_PROPERTIES:
                assert key in fl["properties"], f"Missing feedlink property: {key}"


# ===========================================================================
# TestStats
# ===========================================================================


class TestStats:
    def test_stats_keys_present(self) -> None:
        _, _, stats = _run(RING)
        for key in (
            "externalZones",
            "externalFeedlinks",
            "boundaryNodes",
            "filteredNodes",
            "hullType",
            "minDailyMovements",
            "totalExternalProduction",
            "totalExternalAttraction",
        ):
            assert key in stats, f"Missing stats key: {key}"

    def test_total_cut_links_key_removed(self) -> None:
        _, _, stats = _run(RING)
        assert "totalCutLinks" not in stats

    def test_external_zones_count(self) -> None:
        _, _, stats = _run(RING)
        assert stats["externalZones"] == 4

    def test_external_feedlinks_count(self) -> None:
        _, _, stats = _run(RING)
        assert stats["externalFeedlinks"] == 8

    def test_boundary_nodes_count(self) -> None:
        _, _, stats = _run([*RING, _link("C", "NE")])
        assert stats["boundaryNodes"] == 4

    def test_total_external_production(self) -> None:
        total_pop = 1500.0
        _, _, stats = _run([_link("NE", "SW"), _link("NW", "SE")])
        assert stats["totalExternalProduction"] == pytest.approx(
            DEFAULT_EXTERNAL_SHARE * total_pop, rel=1e-3
        )

    def test_total_external_attraction(self) -> None:
        total_pop = 1500.0
        _, _, stats = _run([_link("NE", "SW"), _link("NW", "SE")])
        assert stats["totalExternalAttraction"] == pytest.approx(
            DEFAULT_EXTERNAL_SHARE * total_pop, rel=1e-3
        )


# ===========================================================================
# TestEdgeCases
# ===========================================================================


class TestEdgeCases:
    def test_empty_network_returns_unchanged_fcs(self) -> None:
        zones_out, feedlinks_out, stats = _run([])
        assert len(zones_out["features"]) == len(ZONES_FC["features"])
        assert len(feedlinks_out["features"]) == 0
        assert stats["externalZones"] == 0

    def test_all_nodes_filtered_returns_unchanged_fcs(self) -> None:
        low = [
            _link(a, b, flow24hrs=1.0)
            for a, b in (("SW", "SE"), ("SE", "NE"), ("NE", "NW"), ("NW", "SW"))
        ]
        zones_out, feedlinks_out, stats = create_external_zones(
            _fc(low),
            ZONES_FC,
            EMPTY_FEEDLINKS,
            BBOX,
            min_daily_movements=150.0,
            hull_type="convex",
        )
        assert len(zones_out["features"]) == len(ZONES_FC["features"])
        assert len(feedlinks_out["features"]) == 0
        assert stats["externalZones"] == 0

    def test_single_node_network_is_degenerate_but_safe(self) -> None:
        # A single link between two coincident-ish nodes must not raise.
        net = [_link("SW", "NE")]
        _, _, stats = _run(net)
        assert stats["externalZones"] >= 0


# ===========================================================================
# TestHighwayWeighting
# ===========================================================================


class TestHighwayWeighting:
    """Production/attraction should weight capacity by road class, so zones on
    high-class roads pull more through-traffic than local-street zones."""

    def _productions(self, net: list, total_pop: float = 1000.0) -> dict[str, float]:
        zones_out, _, _ = _run(net, zones_fc=_fc([_zone("z0", total_pop)]), external_share=1.0)
        return {zid: p["production"] for zid, p in _ext_by_id(zones_out).items()}

    def test_motorway_node_outweighs_residential(self) -> None:
        net = [
            _link("NE", "SW", capacity=1000.0, highway="motorway"),
            _link("NW", "SE", capacity=1000.0, highway="residential"),
        ]
        prods = self._productions(net)
        assert prods["ext_NE"] == pytest.approx(prods["ext_NW"] * 8, rel=1e-3)

    def test_primary_node_outweighs_residential(self) -> None:
        net = [
            _link("NE", "SW", capacity=1000.0, highway="primary"),
            _link("NW", "SE", capacity=1000.0, highway="residential"),
        ]
        prods = self._productions(net)
        assert prods["ext_NE"] == pytest.approx(prods["ext_NW"] * 4, rel=1e-3)

    def test_tertiary_node_outweighs_residential(self) -> None:
        net = [
            _link("NE", "SW", capacity=1000.0, highway="tertiary"),
            _link("NW", "SE", capacity=1000.0, highway="residential"),
        ]
        prods = self._productions(net)
        assert prods["ext_NE"] == pytest.approx(prods["ext_NW"] * 2, rel=1e-3)

    def test_unknown_highway_falls_back_to_weight_one(self) -> None:
        net = [
            _link("NE", "SW", capacity=1000.0, highway="farm_track"),
            _link("NW", "SE", capacity=1000.0, highway="residential"),
        ]
        prods = self._productions(net)
        assert prods["ext_NE"] == pytest.approx(prods["ext_NW"], rel=1e-3)

    def test_total_production_unchanged_by_weighting(self) -> None:
        net = [
            _link("NE", "SW", capacity=1000.0, highway="motorway"),
            _link("NW", "SE", capacity=1000.0, highway="residential"),
        ]
        prods = self._productions(net, total_pop=1000.0)
        assert sum(prods.values()) == pytest.approx(1000.0, rel=1e-3)

    def test_highway_weights_dict_contains_expected_classes(self) -> None:
        assert _HIGHWAY_WEIGHTS["motorway"] == 8.0
        assert _HIGHWAY_WEIGHTS["trunk"] == 8.0
        assert _HIGHWAY_WEIGHTS["primary"] == 4.0
        assert _HIGHWAY_WEIGHTS["secondary"] == 4.0
        assert _HIGHWAY_WEIGHTS["tertiary"] == 2.0
        assert _HIGHWAY_WEIGHTS["unclassified"] == 2.0

    def test_multiple_links_same_node_weighted_capacity_summed(self) -> None:
        # NE: motorway (1000x8) + residential (1000x1) = 9000; NW residential = 1000.
        net = [
            _link("NE", "SW", capacity=1000.0, highway="motorway"),
            _link("NE", "SE", capacity=1000.0, highway="residential"),
            _link("NW", "SE", capacity=1000.0, highway="residential"),
        ]
        prods = self._productions(net)
        assert prods["ext_NE"] == pytest.approx(prods["ext_NW"] * 9, rel=1e-3)


# ===========================================================================
# TestZoneName
# ===========================================================================


class TestZoneName:
    """Tests for the 3-tier zone display-name logic and deduplication."""

    def _names(self, links: list, *, gisco_url: str = "https://example.test") -> dict[str, str]:
        # Enclose C with the TRI triangle so NE is a clean, isolated hull node
        # whose name derives only from the provided link(s).
        zones_out, _, _ = _run([*TRI, *links], gisco_url=gisco_url)
        return {zid: p["zoneName"] for zid, p in _ext_by_id(zones_out).items()}

    def test_tier1_motorway_uses_ref(self) -> None:
        net = [_link("NE", "C", highway="motorway", ref="A1", speed=120.0)]
        assert self._names(net)["ext_NE"].startswith("towards A1")

    def test_tier1_trunk_uses_ref(self) -> None:
        net = [_link("NE", "C", highway="trunk", ref="N50", speed=100.0)]
        assert "N50" in self._names(net)["ext_NE"]

    def test_tier1_no_ref_falls_back_to_motorway_label(self) -> None:
        net = [_link("NE", "C", highway="motorway", ref="", speed=120.0)]
        assert self._names(net)["ext_NE"].startswith("towards Motorway")

    def test_tier2_geocodes_municipality(self) -> None:
        net = [_link("NE", "C", highway="primary", speed=80.0)]
        mock_result = {"name": "Zwolle", "display_name": "Zwolle, Netherlands"}
        with patch(
            "osm.zone_population_estimator.domain.gisco.reverse_geocode",
            return_value=mock_result,
        ):
            names = self._names(net)
        assert "Zwolle" in names["ext_NE"]

    def test_tier2_geocode_failure_falls_back_to_boundary(self) -> None:
        net = [_link("NE", "C", highway="secondary", speed=70.0)]
        with patch(
            "osm.zone_population_estimator.domain.gisco.reverse_geocode",
            side_effect=OSError("timeout"),
        ):
            names = self._names(net)
        assert names["ext_NE"].startswith("boundary (")

    def test_tier3_residential_uses_name_tag(self) -> None:
        net = [_link("NE", "C", highway="residential", name="Dorpsstraat", speed=30.0)]
        assert "Dorpsstraat" in self._names(net)["ext_NE"]

    def test_tier3_no_name_tag_falls_back_to_boundary(self) -> None:
        net = [_link("NE", "C", highway="residential", name="", speed=30.0)]
        assert self._names(net)["ext_NE"].startswith("boundary (")

    def test_zone_name_contains_compass_label(self) -> None:
        # NE corner (1,1) is NE of the bbox centre (0.5, 0.5).
        net = [_link("NE", "C", highway="motorway", ref="A2", speed=120.0)]
        assert "(NE)" in self._names(net)["ext_NE"]

    def test_zone_name_present_on_every_zone(self) -> None:
        names = {zid: p["zoneName"] for zid, p in _ext_by_id(_run(RING)[0]).items()}
        assert len(names) == 4
        for n in names.values():
            assert n

    def test_duplicate_names_get_numeric_suffix(self) -> None:
        # Two motorway nodes far to the NE with the same ref -> same raw name.
        # C (at 1,1) is interior; SW/SE/NW enclose it; P1/P2 sit outside on the
        # hull.  Only P1 and P2 carry the motorway ref, so exactly two zones
        # share the name "towards A1 (NE)".
        net = [
            _link(
                "P1",
                "C",
                highway="motorway",
                ref="A1",
                speed=120.0,
                coords=[[2.0, 2.5], [1.0, 1.0]],
            ),
            _link(
                "P2",
                "C",
                highway="motorway",
                ref="A1",
                speed=120.0,
                coords=[[2.5, 2.0], [1.0, 1.0]],
            ),
            _link("SW", "SE", coords=[[0.0, 0.0], [3.0, 0.0]]),
            _link("SE", "NW", coords=[[3.0, 0.0], [0.0, 3.0]]),
            _link("NW", "SW", coords=[[0.0, 3.0], [0.0, 0.0]]),
        ]
        zones_out, _, _ = _run(net)
        names = [p["zoneName"] for p in _ext_by_id(zones_out).values()]
        a1_names = [n for n in names if n.startswith("towards A1")]
        assert len(a1_names) == 2
        assert len(set(a1_names)) == 2  # deduplicated
        assert any(n.endswith(" 2") for n in a1_names)
