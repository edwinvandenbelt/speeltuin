"""Local runner for external_zone_creator.

Reads a directed network, existing zones, and existing feedlinks; creates
external zones for boundary-crossing links; writes updated zones and feedlinks.

Usage
-----
    python -m osm.external_zone_creator.external_zone_creator_runner \\
        --network-file  path/to/NETWORK-CAR.parquet \\
        --zones-file    path/to/ZONE-CAR.parquet \\
        --feedlinks-file path/to/FEEDLINK-CAR.parquet \\
        --bbox 6.1 52.0 6.2 52.1 \\
        --output-zones     path/to/out/ZONE-CAR.parquet \\
        --output-feedlinks path/to/out/FEEDLINK-CAR.parquet
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Create external zones for boundary-crossing network links."
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="PATH",
        help="Path to the directed network GeoParquet file.",
    )
    parser.add_argument(
        "--zones-file",
        required=True,
        metavar="PATH",
        help="Path to the zones GeoParquet file.",
    )
    parser.add_argument(
        "--feedlinks-file",
        required=True,
        metavar="PATH",
        help="Path to the feedlinks GeoParquet file.",
    )
    parser.add_argument(
        "--bbox",
        required=True,
        nargs=4,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        type=float,
        help="Study area bounding box in decimal degrees (WGS-84).",
    )
    parser.add_argument(
        "--output-zones",
        required=True,
        metavar="PATH",
        help="Output path for updated zones GeoParquet file.",
    )
    parser.add_argument(
        "--output-feedlinks",
        required=True,
        metavar="PATH",
        help="Output path for updated feedlinks GeoParquet file.",
    )
    parser.add_argument(
        "--external-share",
        type=float,
        default=0.40,
        help="Fraction of total population to assign as external trips (default: 0.40).",
    )
    parser.add_argument(
        "--min-daily-movements",
        type=float,
        default=300.0,
        help=(
            "Minimum daily traffic (flow24hrs) a boundary node needs on its "
            "incoming or outgoing direction to receive a zone (default: 300)."
        ),
    )
    parser.add_argument(
        "--hull-type",
        choices=("concave", "convex"),
        default="concave",
        help="Network boundary detection method (default: concave).",
    )
    parser.add_argument(
        "--hull-k",
        type=int,
        default=3,
        help="Neighbour count for the concave hull (default: 3).",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for credentials.",
    )
    args = parser.parse_args()

    env_file = Path(args.env_file) if args.env_file else Path("tools/.env")
    for k, v in _read_env_file(env_file).items():
        os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from osm.external_zone_creator.core.external_zone_creator_core import (
        create_external_zones,
    )

    print(f"Reading network   : {args.network_file}")
    network_fc = from_geoparquet(Path(args.network_file).read_bytes())

    print(f"Reading zones     : {args.zones_file}")
    zones_fc = from_geoparquet(Path(args.zones_file).read_bytes())

    print(f"Reading feedlinks : {args.feedlinks_file}")
    feedlinks_fc = from_geoparquet(Path(args.feedlinks_file).read_bytes())

    zones_out, feedlinks_out, stats = create_external_zones(
        network_fc,
        zones_fc,
        feedlinks_fc,
        args.bbox,
        external_share=args.external_share,
        min_daily_movements=args.min_daily_movements,
        hull_type=args.hull_type,
        hull_k=args.hull_k,
    )

    print(f"Stats             : {stats}")

    out_zones = Path(args.output_zones)
    out_zones.parent.mkdir(parents=True, exist_ok=True)
    out_zones.write_bytes(to_geoparquet(zones_out))
    print(f"Written zones     : {out_zones}")

    out_fl = Path(args.output_feedlinks)
    out_fl.parent.mkdir(parents=True, exist_ok=True)
    out_fl.write_bytes(to_geoparquet(feedlinks_out))
    print(f"Written feedlinks : {out_fl}")
    print("Done.")


if __name__ == "__main__":
    main()
