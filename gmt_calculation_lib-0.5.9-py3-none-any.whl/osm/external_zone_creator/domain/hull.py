"""hull.py — convex and concave hull helpers for external_zone_creator.

Pure-Python, stdlib only.  Used to identify the *boundary nodes* of a road
network: the nodes that lie on the outer edge of the network's footprint.

The convex hull is computed with Andrew's monotone chain.  The concave hull
uses the k-nearest-neighbours approach (Moreira & Santos, 2007): it walks the
point set always taking the sharpest right-hand turn among the *k* nearest
unused neighbours, increasing *k* and retrying whenever the resulting polygon
would self-intersect or fail to enclose every point.  A smaller *k* follows the
network shape more tightly (more concave); a larger *k* smooths towards the
convex hull.

Coordinates are treated as planar ``(lon, lat)`` pairs.  At neighbourhood
scale this is accurate enough to decide hull topology.

Public API
----------
hull_vertices(points, *, hull_type="concave", k=3) -> list[list[float]]
    Return the *open* list of hull vertices (no repeated closing point).
convex_hull(points) -> list[list[float]]
    Closed convex-hull ring (first vertex repeated at the end), or ``[]``.
concave_hull(points, k=3) -> list[list[float]]
    Closed concave-hull ring, falling back to the convex hull when no valid
    concave polygon can be built.
"""

from __future__ import annotations

import math

from gmt_shared.geo import point_in_polygon

__all__ = ["hull_vertices", "convex_hull", "concave_hull"]


# ---------------------------------------------------------------------------
# Basic helpers
# ---------------------------------------------------------------------------


def _unique(points: list[list[float]]) -> list[list[float]]:
    """Return points with exact duplicate coordinates removed, order preserved."""
    seen: set[tuple[float, float]] = set()
    out: list[list[float]] = []
    for p in points:
        key = (float(p[0]), float(p[1]))
        if key not in seen:
            seen.add(key)
            out.append([key[0], key[1]])
    return out


def _cross(o: list[float], a: list[float], b: list[float]) -> float:
    """2D cross product of vectors OA and OB (>0 = counter-clockwise turn)."""
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _dist_sq(a: list[float], b: list[float]) -> float:
    dx = a[0] - b[0]
    dy = a[1] - b[1]
    return dx * dx + dy * dy


def _angle(a: list[float], b: list[float]) -> float:
    """Heading in radians from point *a* to point *b*."""
    return math.atan2(b[1] - a[1], b[0] - a[0])


def _segments_intersect(p1: list[float], p2: list[float], p3: list[float], p4: list[float]) -> bool:
    """Return True when segment p1-p2 properly intersects segment p3-p4.

    Shared endpoints do not count as an intersection (they are expected when
    chaining hull edges).
    """
    d1 = _cross(p3, p4, p1)
    d2 = _cross(p3, p4, p2)
    d3 = _cross(p1, p2, p3)
    d4 = _cross(p1, p2, p4)
    return ((d1 > 0 > d2) or (d1 < 0 < d2)) and ((d3 > 0 > d4) or (d3 < 0 < d4))


# ---------------------------------------------------------------------------
# Convex hull (Andrew's monotone chain)
# ---------------------------------------------------------------------------


def convex_hull(points: list[list[float]]) -> list[list[float]]:
    """Return a closed convex-hull ring for *points* (first vertex repeated).

    Returns ``[]`` when fewer than three distinct points are supplied.
    """
    pts = sorted({(float(p[0]), float(p[1])) for p in points})
    if len(pts) < 3:
        return []

    lower: list[tuple[float, float]] = []
    for p in pts:
        while len(lower) >= 2 and _cross(list(lower[-2]), list(lower[-1]), list(p)) <= 0:
            lower.pop()
        lower.append(p)

    upper: list[tuple[float, float]] = []
    for p in reversed(pts):
        while len(upper) >= 2 and _cross(list(upper[-2]), list(upper[-1]), list(p)) <= 0:
            upper.pop()
        upper.append(p)

    ring = lower[:-1] + upper[:-1]
    ring.append(ring[0])
    return [[x, y] for x, y in ring]


# ---------------------------------------------------------------------------
# Concave hull (k-nearest-neighbours)
# ---------------------------------------------------------------------------


def _nearest_k(candidates: list[list[float]], current: list[float], k: int) -> list[list[float]]:
    return sorted(candidates, key=lambda p: _dist_sq(current, p))[:k]


def _sort_by_right_turn(
    candidates: list[list[float]], current: list[float], back_angle: float
) -> list[list[float]]:
    """Order *candidates* by descending right-hand turn from the back direction.

    ``back_angle`` is the heading from *current* back towards the previously
    visited point.  Rotating clockwise from that back direction, the first
    candidate encountered needs the sharpest right-hand turn and is placed
    first — this traces the outer boundary clockwise.  Ties (collinear
    candidates) prefer the nearest point so points along a straight edge are
    all visited.
    """

    def key(p: list[float]) -> tuple[float, float]:
        turn = (back_angle - _angle(current, p)) % (2.0 * math.pi)
        return (-turn, _dist_sq(current, p))

    return sorted(candidates, key=key)


def concave_hull(points: list[list[float]], k: int = 3) -> list[list[float]]:
    """Return a closed concave-hull ring for *points*.

    Falls back to :func:`convex_hull` when *points* is (nearly) collinear or
    when no simple concave polygon can be constructed for any *k* up to the
    number of points.
    """
    dataset = _unique(points)
    n = len(dataset)
    if n < 3:
        return []
    if n == 3:
        ring = [list(p) for p in dataset]
        ring.append(list(dataset[0]))
        return ring

    kk = min(max(k, 3), n - 1)

    # Start from the lowest point (min lat, then min lon) — guaranteed on hull.
    first = min(dataset, key=lambda p: (p[1], p[0]))
    hull: list[list[float]] = [first]
    current = first
    # Virtual previous point directly west of the start, so the first move
    # heads clockwise (eastward) along the lower boundary.
    prev_point: list[float] = [first[0] - 1.0, first[1]]
    remaining = [p for p in dataset if p is not first]
    step = 2

    while (current != first or step == 2) and remaining:
        if step == 5:
            remaining.append(first)  # allow the polygon to close

        back_angle = _angle(current, prev_point)
        neighbours = _nearest_k(remaining, current, kk)
        candidates = _sort_by_right_turn(neighbours, current, back_angle)

        selected: list[float] | None = None
        for cand in candidates:
            # Reject a candidate whose new edge crosses any existing hull edge.
            crosses = False
            # Skip the last edge (shares the current endpoint) and, when the
            # candidate is the closing point, also the first edge.
            last_offset = 1 if cand == first else 0
            for i in range(1, len(hull) - 1 - last_offset):
                if _segments_intersect(current, cand, hull[i - 1], hull[i]):
                    crosses = True
                    break
            if not crosses:
                selected = cand
                break

        if selected is None:
            # Every candidate self-intersects — retry with a wider neighbourhood.
            if kk + 1 > n - 1:
                return convex_hull(dataset)
            return concave_hull(dataset, kk + 1)

        prev_point = current
        hull.append(selected)
        current = selected
        remaining.remove(selected)
        step += 1

    # Verify every point is enclosed; widen k and retry otherwise.
    ring = list(hull)
    if ring[0] != ring[-1]:
        ring.append(ring[0])
    for p in dataset:
        if p in hull:
            continue
        if not point_in_polygon(p[0], p[1], ring):
            if kk + 1 > n - 1:
                return convex_hull(dataset)
            return concave_hull(dataset, kk + 1)

    return ring


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def hull_vertices(
    points: list[list[float]], *, hull_type: str = "concave", k: int = 3
) -> list[list[float]]:
    """Return the open list of hull vertices (no repeated closing point).

    Parameters
    ----------
    points:
        List of ``[lon, lat]`` coordinates.
    hull_type:
        ``"concave"`` (default) or ``"convex"``.
    k:
        Neighbour count for the concave hull.  Ignored for ``"convex"``.
    """
    if (hull_type or "concave").strip().lower() == "convex":
        ring = convex_hull(points)
    else:
        ring = concave_hull(points, k)
    if not ring:
        return []
    # Drop the repeated closing vertex.
    if len(ring) >= 2 and ring[0] == ring[-1]:
        return [list(p) for p in ring[:-1]]
    return [list(p) for p in ring]
