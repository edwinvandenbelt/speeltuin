"""Domain helpers for external_zone_creator."""
