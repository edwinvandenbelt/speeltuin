# Databricks notebook source
# ---------------------------------------------------------------------------
# external_zone_creator_nb.py — Databricks notebook for external zone creation.
#
# Reads a directed network, zones, and feedlinks from S3.
# Creates external zones for boundary-crossing links.
# Writes updated zones and feedlinks back to S3.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s - %(message)s")
logger = logging.getLogger("external_zone_creator_nb")

# COMMAND ----------
# MAGIC %pip install boto3 geopandas pyarrow shapely

# COMMAND ----------
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text("area_id", "", "Area UUID (used in S3 key prefix)")  # noqa: F821
dbutils.widgets.text("bucket", "", "S3 bucket name (leave empty for local paths)")  # noqa: F821
dbutils.widgets.text("network_key", "", "S3 key of the NETWORK-CAR parquet file")  # noqa: F821
dbutils.widgets.text("zones_key", "", "S3 key of the ZONE-CAR parquet file")  # noqa: F821
dbutils.widgets.text("feedlinks_key", "", "S3 key of the FEEDLINK-CAR parquet file")  # noqa: F821
dbutils.widgets.text("bbox", "", "bbox as JSON array [min_lon, min_lat, max_lon, max_lat]")  # noqa: F821
dbutils.widgets.text("external_share", "0.40", "External trip share (fraction of total population)")  # noqa: F821
dbutils.widgets.text(
    "min_daily_movements", "300", "Min daily traffic (flow24hrs) for a boundary zone"
)
dbutils.widgets.text("hull_type", "concave", "Network boundary hull type (concave / convex)")  # noqa: F821
dbutils.widgets.text("hull_k", "3", "Neighbour count for the concave hull")  # noqa: F821
dbutils.widgets.text("LOG_LEVEL", "INFO", "Log level (DEBUG / INFO / WARNING / ERROR)")  # noqa: F821

# COMMAND ----------
_ll = getattr(logging, dbutils.widgets.get("LOG_LEVEL").strip().upper(), logging.INFO)  # noqa: F821
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
AREA_ID = dbutils.widgets.get("area_id").strip()  # noqa: F821
BUCKET = dbutils.widgets.get("bucket").strip()  # noqa: F821
NETWORK_KEY = dbutils.widgets.get("network_key").strip()  # noqa: F821
ZONES_KEY = dbutils.widgets.get("zones_key").strip()  # noqa: F821
FEEDLINKS_KEY = dbutils.widgets.get("feedlinks_key").strip()  # noqa: F821
BBOX_RAW = dbutils.widgets.get("bbox").strip()  # noqa: F821
EXTERNAL_SHARE = float(dbutils.widgets.get("external_share").strip() or "0.40")  # noqa: F821
MIN_DAILY_MOVEMENTS = float(dbutils.widgets.get("min_daily_movements").strip() or "300")  # noqa: F821
HULL_TYPE = dbutils.widgets.get("hull_type").strip() or "concave"  # noqa: F821
HULL_K = int(dbutils.widgets.get("hull_k").strip() or "3")  # noqa: F821

if not BBOX_RAW:
    raise ValueError("Widget 'bbox' is empty.")
BBOX = json.loads(BBOX_RAW)

# COMMAND ----------

import boto3  # noqa: E402


def _get_s3(bucket: str, key: str) -> bytes:
    body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
    logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
    return body


def _put_s3(bucket: str, key: str, data: bytes) -> None:
    boto3.client("s3").put_object(Bucket=bucket, Key=key, Body=data)
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _read(bucket: str, key: str) -> bytes:
    return _get_s3(bucket, key) if bucket else open(key, "rb").read()


def _write(bucket: str, key: str, data: bytes) -> None:
    if bucket:
        _put_s3(bucket, key, data)
    else:
        import os

        os.makedirs(os.path.dirname(key) or ".", exist_ok=True)
        open(key, "wb").write(data)


# COMMAND ----------
# MAGIC %md ## Run external_zone_creator

# COMMAND ----------
from gmt_shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402

from osm.external_zone_creator.core.external_zone_creator_core import (  # noqa: E402
    create_external_zones,
)

_t0 = datetime.now(UTC)

network_fc = from_geoparquet(_read(BUCKET, NETWORK_KEY))
zones_fc = from_geoparquet(_read(BUCKET, ZONES_KEY))
feedlinks_fc = from_geoparquet(_read(BUCKET, FEEDLINKS_KEY))

zones_out, feedlinks_out, stats = create_external_zones(
    network_fc,
    zones_fc,
    feedlinks_fc,
    BBOX,
    external_share=EXTERNAL_SHARE,
    min_daily_movements=MIN_DAILY_MOVEMENTS,
    hull_type=HULL_TYPE,
    hull_k=HULL_K,
)

_out_zones_key = (
    ZONES_KEY.replace(".parquet", "-ext.parquet")
    if ZONES_KEY
    else f"{AREA_ID}-ZONE-CAR-ext.parquet"
)
_out_fl_key = (
    FEEDLINKS_KEY.replace(".parquet", "-ext.parquet")
    if FEEDLINKS_KEY
    else f"{AREA_ID}-FEEDLINK-CAR-ext.parquet"
)

_write(BUCKET, _out_zones_key, to_geoparquet(zones_out))
_write(BUCKET, _out_fl_key, to_geoparquet(feedlinks_out))

_elapsed = (datetime.now(UTC) - _t0).total_seconds()

# COMMAND ----------
_SEP = "-" * 60
print(_SEP)
print(f"external_zone_creator complete - {_elapsed:.1f}s")
print(_SEP)
print(f"  External zones     : {stats['externalZones']}")
print(f"  External feedlinks  : {stats['externalFeedlinks']}")
print(f"  Boundary nodes      : {stats['boundaryNodes']}")
print(f"  Filtered nodes      : {stats['filteredNodes']}")
print(f"  Hull type           : {stats['hullType']}")
print(f"  Min daily movements : {stats['minDailyMovements']:.0f}")
print(f"  External production : {stats['totalExternalProduction']:.0f}")
print(f"  External attraction : {stats['totalExternalAttraction']:.0f}")
print(_SEP)
