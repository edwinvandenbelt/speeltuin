# Databricks notebook source
# ---------------------------------------------------------------------------
# osm_vegetation_fetcher_nb.py — Databricks notebook for osm_vegetation_fetcher.
#
# This notebook:
#   1. Reads widget parameters (bbox, output_folder, area_id, …).
#   2. Calls build_vegetation() to fetch OSM vegetation via Overpass.
#   3. Serialises the result as GeoParquet and writes it to S3 (or local).
#   4. Prints a summary table.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s - %(message)s")
logger = logging.getLogger("osm_vegetation_fetcher_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "bbox",
    "6.143,52.248,6.184,52.272",
    "Bounding box: minLon,minLat,maxLon,maxLat (comma-separated)",
)
dbutils.widgets.text(  # noqa: F821
    "output_folder",
    "",
    "Output folder: s3://bucket/prefix/ or local path",
)
dbutils.widgets.text(  # noqa: F821
    "area_id",
    "vegetation",
    "Area identifier — used in output filename ({area_id}-VEGETATION.parquet)",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_url",
    "https://overpass-api.de/api/interpreter",
    "Overpass API endpoint URL",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_timeout",
    "90",
    "Overpass query timeout in seconds",
)
dbutils.widgets.text(  # noqa: F821
    "max_points",
    "20000",
    "Cap on tree/shrub point features (0 disables)",
)
dbutils.widgets.dropdown(  # noqa: F821
    "fetch_bgt",
    "true",
    ["true", "false"],
    "Also fetch BGT begroeidterreindeel vegetation (NL only)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

_raw_bbox = dbutils.widgets.get("bbox").strip()  # noqa: F821
if not _raw_bbox:
    raise ValueError("Widget 'bbox' is empty.")
try:
    BBOX: list[float] = [float(v.strip()) for v in _raw_bbox.split(",")]
    if len(BBOX) != 4:
        raise ValueError(f"Expected 4 values, got {len(BBOX)}")
except ValueError as _exc:
    raise ValueError(f"Widget 'bbox' must be 'minLon,minLat,maxLon,maxLat': {_exc}") from _exc

OUTPUT_FOLDER = dbutils.widgets.get("output_folder").strip()  # noqa: F821
if not OUTPUT_FOLDER:
    raise ValueError("Widget 'output_folder' is empty.")

AREA_ID = dbutils.widgets.get("area_id").strip() or "vegetation"  # noqa: F821

OVERPASS_URL = dbutils.widgets.get("overpass_url").strip()  # noqa: F821
if not OVERPASS_URL:
    OVERPASS_URL = "https://overpass-api.de/api/interpreter"

try:
    OVERPASS_TIMEOUT = int(dbutils.widgets.get("overpass_timeout").strip())  # noqa: F821
except ValueError, TypeError:
    OVERPASS_TIMEOUT = 90

try:
    MAX_POINTS = int(dbutils.widgets.get("max_points").strip())  # noqa: F821
except ValueError, TypeError:
    MAX_POINTS = 20_000

FETCH_BGT = dbutils.widgets.get("fetch_bgt").strip().lower() == "true"  # noqa: F821

logger.info(
    "bbox=%s  area_id=%s  output_folder=%s  overpass_url=%s  timeout=%s  max_points=%s",
    BBOX,
    AREA_ID,
    OUTPUT_FOLDER,
    OVERPASS_URL,
    OVERPASS_TIMEOUT,
    MAX_POINTS,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402


def _put_s3(bucket: str, key: str, data: bytes) -> None:
    boto3.client("s3").put_object(
        Bucket=bucket,
        Key=key,
        Body=data,
        ContentType="application/octet-stream",
    )
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _write_file(uri: str, data: bytes) -> None:
    import os

    if uri.startswith("s3://"):
        parts = uri[5:].split("/", 1)
        bucket, key = parts[0], parts[1] if len(parts) > 1 else ""
        _put_s3(bucket, key, data)
    else:
        os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
        with open(uri, "wb") as _fh:
            _fh.write(data)
        logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run OSM Vegetation Fetcher
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to re-fetch without
# MAGIC re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from gmt_shared.geoparquet import to_geoparquet  # noqa: E402

from osm.osm_vegetation_fetcher.core.osm_vegetation_fetcher_core import (  # noqa: E402
    build_vegetation,
)

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")
print(f"bbox          : {BBOX}")
print(f"area_id       : {AREA_ID}")
print(f"output_folder : {OUTPUT_FOLDER}")
print()

_fc, _stats = build_vegetation(
    BBOX,
    overpass_url=OVERPASS_URL,
    timeout=OVERPASS_TIMEOUT,
    max_points=MAX_POINTS,
    bgt=FETCH_BGT,
)

_parquet_bytes = to_geoparquet(_fc)
_out_uri = f"{OUTPUT_FOLDER.rstrip('/')}/{AREA_ID}-VEGETATION.parquet"
_write_file(_out_uri, _parquet_bytes)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "-" * 64
print(_SEP)
print(f"OSM Vegetation Fetcher complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  area_id       : {AREA_ID}")
print(f"  bbox          : {BBOX}")
print(f"  output        : {_out_uri}")
print(f"  total         : {_stats['total']}")
print(f"  points        : {_stats['points']}")
print(f"  lines         : {_stats['lines']}")
print(f"  areas         : {_stats['areas']}")
print(f"  capped        : {_stats['capped']}")
print("  by type:")
for _vtype, _cnt in sorted(_stats.get("by_type", {}).items()):
    print(f"    {_vtype:<15} {_cnt:>6}")
print("  by source:")
for _src, _cnt in sorted(_stats.get("by_source", {}).items()):
    print(f"    {_src:<15} {_cnt:>6}")
print(_SEP)
