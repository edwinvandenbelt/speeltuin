"""BGT ``begroeidterreindeel`` -> vegetation normalisation helpers.

Adds the Dutch BGT (Basisregistratie Grootschalige Topografie) as a *second*
vegetation source next to OSM/Overpass.  BGT registers vegetated terrain as
``begroeidterreindeel`` polygons on the PDOK OGC API Features service, each
carrying a ``fysiek_voorkomen`` (and finer ``plus_fysiek_voorkomen``)
classification such as ``"loofbos"`` / ``"naaldbos"`` / ``"struiken"`` /
``"gras- en kruidachtigen"``.

Every BGT feature is normalised into the *same* vegetation schema produced by
the OSM path (``vegType``, ``height``, ``crown``, ``species``, ``leafType``,
``osmId``, ``source``) so both sources can be merged into a single
FeatureCollection / GeoParquet file.  BGT does not carry tree height, crown
diameter or species, so those fields are ``None``; ``leafType`` is inferred from
the forest classification (loofbos -> broadleaved, naaldbos -> needleleaved).

The PDOK BGT service serves GeoJSON in CRS84 (WGS-84 lon/lat) and only covers
the Netherlands, so no reprojection is required and callers should skip the BGT
fetch for bboxes outside NL.

Public API
----------
normalise_bgt_veg_type(props) -> str | None
    Map a BGT ``begroeidterreindeel`` classification to a normalised vegType.
bgt_leaf_type(props) -> str | None
    Infer ``leafType`` from the BGT forest classification.
bgt_feature_to_veg(feature) -> dict | None
    Convert a raw BGT GeoJSON feature to a normalised vegetation Feature.
"""

from __future__ import annotations

#: BGT collection id on the PDOK OGC API Features service that holds vegetated
#: terrain parts (polygons).
BGT_VEG_COLLECTION: str = "begroeidterreindeel"

#: Provenance tag written on produced features (``properties.source``).
SOURCE_BGT: str = "bgt"
SOURCE_OSM: str = "osm"

#: Candidate BGT property keys holding the physical-appearance classification,
#: from finest to coarsest.  Different PDOK deployments expose the attribute
#: under slightly different names, so all are probed in order.
_FYSIEK_KEYS: tuple[str, ...] = (
    "plus_fysiek_voorkomen",
    "plus_fysiekvoorkomen",
    "fysiek_voorkomen",
    "fysiekvoorkomen",
)

# Normalised vegetation labels (kept identical to ``domain.geometry``).
_VEG_TREE_ROW = "tree_row"
_VEG_SCRUB = "scrub"
_VEG_GRASS = "grass"
_VEG_WOOD = "wood"
_VEG_FOREST = "forest"

#: Exact-match map from a BGT ``fysiek_voorkomen`` value to a normalised vegType.
_BGT_VEG_MAP: dict[str, str] = {
    "loofbos": _VEG_FOREST,
    "naaldbos": _VEG_FOREST,
    "gemengd bos": _VEG_FOREST,
    "griend": _VEG_WOOD,
    "bosplantsoen": _VEG_WOOD,
    "boomteelt": _VEG_WOOD,
    "boomkwekerij": _VEG_WOOD,
    "fruitteelt": _VEG_WOOD,
    "houtwal": _VEG_TREE_ROW,
    "struiken": _VEG_SCRUB,
    "heide": _VEG_SCRUB,
    "rietland": _VEG_SCRUB,
    "moeras": _VEG_SCRUB,
    "duinvegetatie": _VEG_SCRUB,
    "gras- en kruidachtigen": _VEG_GRASS,
    "grasland agrarisch": _VEG_GRASS,
    "grasland overig": _VEG_GRASS,
    "groenvoorziening": _VEG_GRASS,
}


def _fysiek_value(props: dict) -> str | None:
    """Return the lower-cased BGT physical-appearance value, or ``None``."""
    for key in _FYSIEK_KEYS:
        raw = props.get(key)
        if raw:
            text = str(raw).strip().lower()
            if text:
                return text
    return None


def normalise_bgt_veg_type(props: dict) -> str | None:
    """Map a BGT ``begroeidterreindeel`` classification to a normalised vegType.

    Returns one of ``tree_row``, ``scrub``, ``grass``, ``wood``, ``forest`` — or
    ``None`` when the feature carries no usable ``fysiek_voorkomen`` value.
    Unrecognised (but present) classifications fall back to ``"scrub"`` since a
    ``begroeidterreindeel`` is, by definition, vegetated ground.
    """
    value = _fysiek_value(props)
    if value is None:
        return None
    if value in _BGT_VEG_MAP:
        return _BGT_VEG_MAP[value]
    # Substring heuristics for compound / plus-variant values (e.g.
    # "loofbos - dichte begroeiing").
    if "loofbos" in value or "naaldbos" in value or "bos" in value:
        return _VEG_FOREST
    if "gras" in value:
        return _VEG_GRASS
    if "struik" in value or "haag" in value:
        return _VEG_SCRUB
    return _VEG_SCRUB


def bgt_leaf_type(props: dict) -> str | None:
    """Infer ``leafType`` (broadleaved / needleleaved) from a BGT forest value."""
    value = _fysiek_value(props)
    if value is None:
        return None
    if "loofbos" in value:
        return "broadleaved"
    if "naaldbos" in value:
        return "needleleaved"
    return None


def _bgt_id(feature: dict, props: dict) -> str | None:
    """Return a stable BGT id (``"bgt/{lokaalid}"``) for provenance, or ``None``."""
    raw = (
        feature.get("id")
        or props.get("lokaal_id")
        or props.get("lokaalid")
        or props.get("gml_id")
        or props.get("identificatie")
    )
    return f"bgt/{raw}" if raw else None


def bgt_feature_to_veg(feature: dict) -> dict | None:
    """Convert a raw BGT ``begroeidterreindeel`` GeoJSON feature to vegetation.

    Parameters
    ----------
    feature:
        A GeoJSON Feature as returned by the PDOK OGC API Features service.

    Returns
    -------
    dict | None
        A GeoJSON Feature with the normalised vegetation schema
        (``vegType``, ``height``, ``crown``, ``species``, ``leafType``,
        ``osmId``, ``source``) — or ``None`` when the geometry is missing or the
        classification cannot be mapped.  The original BGT polygon geometry is
        preserved unchanged.
    """
    geometry = feature.get("geometry")
    if not geometry or not geometry.get("coordinates"):
        return None
    if geometry.get("type") not in {"Polygon", "MultiPolygon"}:
        return None

    props: dict = feature.get("properties") or {}
    veg_type = normalise_bgt_veg_type(props)
    if veg_type is None:
        return None

    new_props: dict = {
        "vegType": veg_type,
        "height": None,
        "crown": None,
        "species": None,
        "leafType": bgt_leaf_type(props),
        "osmId": _bgt_id(feature, props),
        "source": SOURCE_BGT,
    }
    return {"type": "Feature", "geometry": geometry, "properties": new_props}
