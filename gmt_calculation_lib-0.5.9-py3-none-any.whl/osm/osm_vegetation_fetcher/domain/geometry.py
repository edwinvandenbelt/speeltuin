"""Vegetation geometry + tag-normalisation helpers.

Converts raw Overpass elements (nodes, ways, relations) to GeoJSON Features
with normalised vegetation properties.

Public API
----------
normalise_veg_type(element) -> str | None
    Return the normalised vegetation label for an element, or ``None`` when the
    element carries no recognised vegetation tag.
element_to_feature(element, veg_type) -> dict | None
    Convert an Overpass element to a GeoJSON Feature, or ``None`` when a valid
    geometry cannot be built.
"""

from __future__ import annotations

# Normalised vegetation labels.
VEG_TREE = "tree"
VEG_TREE_ROW = "tree_row"
VEG_SHRUB = "shrub"
VEG_SCRUB = "scrub"
VEG_GRASS = "grass"
VEG_WOOD = "wood"
VEG_FOREST = "forest"

# Point vegetation labels (node geometry).
POINT_VEG_TYPES: frozenset[str] = frozenset({VEG_TREE, VEG_SHRUB})
# Line vegetation labels (LineString geometry).
LINE_VEG_TYPES: frozenset[str] = frozenset({VEG_TREE_ROW})
# Area vegetation labels (Polygon / MultiPolygon geometry).
AREA_VEG_TYPES: frozenset[str] = frozenset({VEG_SCRUB, VEG_GRASS, VEG_WOOD, VEG_FOREST})


def normalise_veg_type(element: dict) -> str | None:
    """Map an Overpass element's tags to a normalised vegetation label.

    Returns one of ``tree``, ``tree_row``, ``shrub``, ``scrub``, ``grass``,
    ``wood``, ``forest`` — or ``None`` when no recognised vegetation tag is
    present.

    Parameters
    ----------
    element:
        Overpass element dict with a ``tags`` mapping.
    """
    tags: dict[str, str] = element.get("tags") or {}
    natural = (tags.get("natural") or "").strip().lower()
    landuse = (tags.get("landuse") or "").strip().lower()

    if natural == "tree":
        return VEG_TREE
    if natural == "tree_row":
        return VEG_TREE_ROW
    if natural == "shrub":
        return VEG_SHRUB
    if natural == "scrub":
        return VEG_SCRUB
    if natural == "wood":
        return VEG_WOOD
    if landuse == "grass":
        return VEG_GRASS
    if landuse == "forest":
        return VEG_FOREST
    return None


def _parse_float_metres(raw: str | None) -> float | None:
    """Parse an OSM measurement (e.g. ``"12"``, ``"12 m"``, ``"12.5m"``).

    Returns a float in metres, or ``None`` when the value is absent or cannot
    be parsed.  Values expressed in other units (e.g. feet) are ignored.
    """
    if not raw:
        return None
    text = raw.strip().lower()
    if not text:
        return None
    # Strip a trailing metre unit; reject anything with other unit markers.
    for suffix in (" m", "m", " metre", " metres", " meter", " meters"):
        if text.endswith(suffix):
            text = text[: -len(suffix)].strip()
            break
    try:
        val = float(text)
    except ValueError, TypeError:
        return None
    if val <= 0:
        return None
    return val


def _extract_height(tags: dict[str, str]) -> float | None:
    """Return the tree/canopy height in metres from ``height`` or ``est_height``."""
    return _parse_float_metres(tags.get("height")) or _parse_float_metres(tags.get("est_height"))


def _extract_crown(tags: dict[str, str]) -> float | None:
    """Return the crown diameter in metres from ``diameter_crown``."""
    return _parse_float_metres(tags.get("diameter_crown"))


def _extract_species(tags: dict[str, str]) -> str | None:
    """Return a species / genus label from ``species`` or ``genus``."""
    species = (tags.get("species") or "").strip()
    if species:
        return species
    genus = (tags.get("genus") or "").strip()
    return genus or None


def _extract_leaf_type(tags: dict[str, str]) -> str | None:
    """Return the OSM ``leaf_type`` (broadleaved / needleleaved) or ``None``."""
    leaf = (tags.get("leaf_type") or "").strip().lower()
    if leaf in {"broadleaved", "needleleaved"}:
        return leaf
    return None


def _ring_from_geometry(geometry: list[dict]) -> list[list[float]] | None:
    """Build a closed coordinate ring from an Overpass ``geometry`` list.

    Returns ``None`` when the ring is degenerate (fewer than 3 distinct
    vertices).  The first coordinate is repeated at the end so the ring is
    explicitly closed (GeoJSON requirement).
    """
    coords = [[float(p["lon"]), float(p["lat"])] for p in geometry if p]
    if len(coords) < 3:
        return None
    if coords[0] != coords[-1]:
        coords.append(coords[0])
    # A valid closed ring needs at least 4 positions (3 distinct + closure).
    if len(coords) < 4:
        return None
    return coords


def _point_in_ring(point: list[float], ring: list[list[float]]) -> bool:
    """Ray-casting point-in-polygon test for a single ring (pure Python)."""
    x, y = point[0], point[1]
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside


def _multipolygon_from_relation(element: dict) -> dict | None:
    """Build a MultiPolygon geometry from an Overpass relation with geometry.

    Outer member ways become polygon outer rings; inner member ways become
    holes assigned to the first outer ring that contains their first vertex.
    Returns ``None`` when no valid outer ring can be built.
    """
    members = element.get("members") or []
    outer_rings: list[list[list[float]]] = []
    inner_rings: list[list[list[float]]] = []

    for member in members:
        if member.get("type") != "way":
            continue
        ring = _ring_from_geometry(member.get("geometry") or [])
        if ring is None:
            continue
        role = (member.get("role") or "outer").strip().lower()
        if role == "inner":
            inner_rings.append(ring)
        else:
            outer_rings.append(ring)

    if not outer_rings:
        return None

    polygons: list[list[list[list[float]]]] = [[ring] for ring in outer_rings]
    for inner in inner_rings:
        anchor = inner[0]
        for poly in polygons:
            if _point_in_ring(anchor, poly[0]):
                poly.append(inner)
                break

    return {"type": "MultiPolygon", "coordinates": polygons}


def _build_geometry(element: dict, veg_type: str) -> dict | None:
    """Build the GeoJSON geometry appropriate for *veg_type*.

    * point types (tree, shrub)  -> Point
    * line types (tree_row)      -> LineString
    * area types (scrub/grass/wood/forest) on a way   -> Polygon
    * area types on a relation                        -> MultiPolygon
    """
    etype = element.get("type")

    if veg_type in POINT_VEG_TYPES:
        if etype == "node":
            lon, lat = element.get("lon"), element.get("lat")
            if lon is None or lat is None:
                return None
            return {"type": "Point", "coordinates": [float(lon), float(lat)]}
        # A point veg_type on a way/relation: fall back to a representative point.
        geom = element.get("geometry") or []
        if not geom:
            return None
        return {"type": "Point", "coordinates": [float(geom[0]["lon"]), float(geom[0]["lat"])]}

    if veg_type in LINE_VEG_TYPES:
        geom = element.get("geometry") or []
        coords = [[float(p["lon"]), float(p["lat"])] for p in geom if p]
        if len(coords) < 2:
            return None
        return {"type": "LineString", "coordinates": coords}

    # area types
    if etype == "relation":
        return _multipolygon_from_relation(element)
    ring = _ring_from_geometry(element.get("geometry") or [])
    if ring is None:
        return None
    return {"type": "Polygon", "coordinates": [ring]}


def element_to_feature(element: dict, veg_type: str) -> dict | None:
    """Convert an Overpass element to a GeoJSON vegetation Feature.

    Parameters
    ----------
    element:
        Overpass element dict (node / way / relation).
    veg_type:
        Normalised vegetation label from :func:`normalise_veg_type`.

    Returns
    -------
    dict | None
        A GeoJSON Feature with properties ``vegType``, ``height``, ``crown``,
        ``species``, ``leafType``, ``osmId`` and ``source`` (``"osm"``) — or
        ``None`` when a valid geometry could not be constructed (the element is
        skipped).
    """
    geometry = _build_geometry(element, veg_type)
    if geometry is None:
        return None

    tags: dict[str, str] = element.get("tags") or {}
    props: dict = {
        "vegType": veg_type,
        "height": _extract_height(tags),
        "crown": _extract_crown(tags),
        "species": _extract_species(tags),
        "leafType": _extract_leaf_type(tags),
        "osmId": f"{element.get('type', '')}/{element.get('id', '')}",
        "source": "osm",
    }
    return {"type": "Feature", "geometry": geometry, "properties": props}
