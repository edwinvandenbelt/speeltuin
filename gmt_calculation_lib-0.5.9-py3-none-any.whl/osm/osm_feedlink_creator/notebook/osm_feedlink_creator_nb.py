# Databricks notebook source
# ---------------------------------------------------------------------------
# osm_feedlink_creator_nb.py — Databricks notebook for osm_feedlink_creator.
#
# This notebook:
#   1. Reads widget parameters (network URI, zones URI, output URI).
#   2. Reads both GeoParquet files from S3 / local path.
#   3. Calls create_feedlinks — no Spark I/O.
#   4. Writes the feedlinks GeoParquet back to S3 / local path.
#   5. Prints a stats summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("osm_feedlink_creator_nb")

# COMMAND ----------
# MAGIC %pip install boto3 shapely pyarrow geopandas

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uri",
    "",
    "Full URI of the directed network GeoParquet (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "zones_uri",
    "",
    "Full URI of the building zones GeoParquet (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri",
    "",
    "Full output URI for the feedlinks GeoParquet (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gmt_shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402

from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
    create_feedlinks,
)

# COMMAND ----------
# ── Widget read + validation ────────────────────────────────────────────────

NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
ZONES_URI = dbutils.widgets.get("zones_uri").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()  # noqa: F821

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")
if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty.")
if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")

logger.info("network_uri=%s  zones_uri=%s  output_uri=%s", NETWORK_URI, ZONES_URI, OUTPUT_URI)

# COMMAND ----------
# ── S3 / local helpers ──────────────────────────────────────────────────────

import os  # noqa: E402

import boto3  # noqa: E402


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/octet-stream",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    logger.info("Wrote %s  (%d bytes)", path, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run OsmFeedlinkCreator
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ──────────────────────────────────────────────────────────

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")
print(f"Network   : {NETWORK_URI}")
print(f"Zones     : {ZONES_URI}")
print(f"Output    : {OUTPUT_URI}")
print()

_network_fc = from_geoparquet(_read_uri(NETWORK_URI))
_n_links = len(_network_fc.get("features") or [])
print(f"Loaded {_n_links} network link features")

_zones_fc = from_geoparquet(_read_uri(ZONES_URI))
_n_zones = len(_zones_fc.get("features") or [])
print(f"Loaded {_n_zones} zone features")

_feedlinks_fc, _stats = create_feedlinks(_network_fc, _zones_fc)

_parquet_bytes = to_geoparquet(_feedlinks_fc)
_write_uri(OUTPUT_URI, _parquet_bytes)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ─────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"OsmFeedlinkCreator complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Network links  : {_n_links}")
print(f"  Input zones    : {_n_zones}")
print(f"  Feedlinks out  : {_stats['total']} ({_stats['total'] // 2} zone pairs)")
print(f"  Zones matched  : {_stats['zonesMatched']} (node inside polygon)")
print(f"  Zones fallback : {_stats['zonesFallback']} (nearest-node fallback)")
print(f"  Output URI     : {OUTPUT_URI}")
print(_SEP)
