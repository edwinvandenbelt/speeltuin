"""Tests for osm_feedlink_creator.

Covers:
- network_nodes.extract_nodes: coordinate extraction, score accumulation,
  directed-format and raw-format field support
- zone_matcher.find_best_node: polygon containment, score ranking, nearest fallback
- feedlink_builder.build_feedlink_pair: feature structure, properties, geometry
- core.create_feedlinks: full integration, stats, fallback counting
"""

from __future__ import annotations

import math

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _link(
    from_node: str,
    to_node: str,
    from_coord: list,
    to_coord: list,
    speed: float = 50.0,
    capacity: float = 1000.0,
) -> dict:
    """Build a minimal directed network link Feature."""
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [from_coord, to_coord]},
        "properties": {
            "fromNode": from_node,
            "toNode": to_node,
            "speed": speed,
            "capacity": capacity,
            "length": 100.0,
        },
    }


def _raw_link(
    from_node: str,
    to_node: str,
    from_coord: list,
    to_coord: list,
    speed_heen: float = 50.0,
    cap_heen: float = 1000.0,
) -> dict:
    """Build a raw-format (osm_network_fetcher) link Feature."""
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [from_coord, to_coord]},
        "properties": {
            "fromNode": from_node,
            "toNode": to_node,
            "max_snelheid_heen": speed_heen,
            "cap_heen": cap_heen,
            "length": 100.0,
        },
    }


def _network_fc(links: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": links}


def _square_zone(cx: float, cy: float, half: float = 0.01, zone_id: str = "zone_0") -> dict:
    """Build a square Polygon zone centred on (cx, cy)."""
    ring = [
        [cx - half, cy - half],
        [cx + half, cy - half],
        [cx + half, cy + half],
        [cx - half, cy + half],
        [cx - half, cy - half],
    ]
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {
            "zoneId": zone_id,
            "centroidLon": cx,
            "centroidLat": cy,
        },
    }


def _zones_fc(zones: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": zones}


# ===========================================================================
# TestExtractNodes
# ===========================================================================


class TestExtractNodes:
    def test_extracts_from_and_to_node_ids(self) -> None:
        from osm.osm_feedlink_creator.domain.network_nodes import extract_nodes

        net = _network_fc([_link("1", "2", [6.1, 52.0], [6.2, 52.1])])
        nodes = extract_nodes(net)
        assert "1" in nodes
        assert "2" in nodes

    def test_node_coordinates_from_linestring_endpoints(self) -> None:
        from osm.osm_feedlink_creator.domain.network_nodes import extract_nodes

        net = _network_fc([_link("A", "B", [6.10, 52.00], [6.20, 52.10])])
        nodes = extract_nodes(net)
        assert nodes["A"].lon == pytest.approx(6.10)
        assert nodes["A"].lat == pytest.approx(52.00)
        assert nodes["B"].lon == pytest.approx(6.20)
        assert nodes["B"].lat == pytest.approx(52.10)

    def test_score_is_speed_times_capacity(self) -> None:
        from osm.osm_feedlink_creator.domain.network_nodes import extract_nodes

        net = _network_fc([_link("1", "2", [6.1, 52.0], [6.2, 52.1], speed=80.0, capacity=1500.0)])
        nodes = extract_nodes(net)
        expected = 80.0 * 1500.0
        assert nodes["1"].score == pytest.approx(expected)
        assert nodes["2"].score == pytest.approx(expected)

    def test_score_accumulates_across_incident_links(self) -> None:
        from osm.osm_feedlink_creator.domain.network_nodes import extract_nodes

        # Node "HUB" is endpoint of two links with scores 50*1000 and 80*2000
        links = [
            _link("HUB", "A", [6.15, 52.05], [6.1, 52.0], speed=50.0, capacity=1000.0),
            _link("HUB", "B", [6.15, 52.05], [6.2, 52.1], speed=80.0, capacity=2000.0),
        ]
        nodes = extract_nodes(_network_fc(links))
        assert nodes["HUB"].score == pytest.approx(50.0 * 1000.0 + 80.0 * 2000.0)

    def test_raw_network_format_uses_heen_fields(self) -> None:
        from osm.osm_feedlink_creator.domain.network_nodes import extract_nodes

        net = _network_fc(
            [_raw_link("1", "2", [6.1, 52.0], [6.2, 52.1], speed_heen=70.0, cap_heen=1200.0)]
        )
        nodes = extract_nodes(net)
        assert nodes["1"].score == pytest.approx(70.0 * 1200.0)

    def test_missing_speed_or_capacity_yields_zero_score(self) -> None:
        from osm.osm_feedlink_creator.domain.network_nodes import extract_nodes

        link = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[6.1, 52.0], [6.2, 52.1]]},
            "properties": {"fromNode": "X", "toNode": "Y"},
        }
        nodes = extract_nodes(_network_fc([link]))
        assert nodes["X"].score == 0.0

    def test_skips_non_linestring_geometries(self) -> None:
        from osm.osm_feedlink_creator.domain.network_nodes import extract_nodes

        feat = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [6.1, 52.0]},
            "properties": {"fromNode": "X", "toNode": "Y"},
        }
        nodes = extract_nodes(_network_fc([feat]))
        assert len(nodes) == 0

    def test_empty_network_returns_empty_dict(self) -> None:
        from osm.osm_feedlink_creator.domain.network_nodes import extract_nodes

        assert extract_nodes({"type": "FeatureCollection", "features": []}) == {}


# ===========================================================================
# TestFindBestNode
# ===========================================================================


class TestFindBestNode:
    def _node_index(self, entries: list[tuple]) -> dict:
        """Build a nodes dict from (node_id, lon, lat, score) tuples."""
        from osm.osm_feedlink_creator.domain.network_nodes import NodeInfo

        return {e[0]: NodeInfo(node_id=e[0], lon=e[1], lat=e[2], score=e[3]) for e in entries}

    def test_returns_highest_score_node_inside_polygon(self) -> None:
        from osm.osm_feedlink_creator.domain.zone_matcher import find_best_node

        zone = _square_zone(6.15, 52.05, half=0.05)
        nodes = self._node_index(
            [
                ("low", 6.15, 52.05, 1000.0),
                ("high", 6.14, 52.04, 9000.0),
            ]
        )
        result = find_best_node(zone, nodes)
        assert result is not None
        assert result.node_id == "high"

    def test_ignores_nodes_outside_polygon(self) -> None:
        from osm.osm_feedlink_creator.domain.zone_matcher import find_best_node

        zone = _square_zone(6.15, 52.05, half=0.01)
        nodes = self._node_index(
            [
                ("inside", 6.15, 52.05, 1000.0),
                ("outside", 6.30, 52.30, 99999.0),  # high score but outside
            ]
        )
        result = find_best_node(zone, nodes)
        assert result is not None
        assert result.node_id == "inside"

    def test_fallback_to_nearest_when_no_node_inside(self) -> None:
        from osm.osm_feedlink_creator.domain.zone_matcher import find_best_node

        # Zone at 6.15, 52.05 — all nodes outside
        zone = _square_zone(6.15, 52.05, half=0.001)
        nodes = self._node_index(
            [
                ("far", 6.50, 52.50, 9000.0),
                ("close", 6.16, 52.06, 100.0),  # nearest
            ]
        )
        result = find_best_node(zone, nodes)
        assert result is not None
        assert result.node_id == "close"

    def test_returns_none_for_empty_node_index(self) -> None:
        from osm.osm_feedlink_creator.domain.zone_matcher import find_best_node

        zone = _square_zone(6.15, 52.05)
        assert find_best_node(zone, {}) is None

    def test_single_node_always_selected(self) -> None:
        from osm.osm_feedlink_creator.domain.zone_matcher import find_best_node

        zone = _square_zone(6.15, 52.05, half=0.001)
        nodes = self._node_index([("only", 6.50, 52.50, 5000.0)])
        result = find_best_node(zone, nodes)
        assert result is not None
        assert result.node_id == "only"


# ===========================================================================
# TestBuildFeedlinkPair
# ===========================================================================


class TestBuildFeedlinkPair:
    def _call(
        self,
        zone_id: str = "z0",
        clon: float = 6.15,
        clat: float = 52.05,
        nlon: float = 6.16,
        nlat: float = 52.06,
        score: float = 5000.0,
    ) -> list[dict]:
        from osm.osm_feedlink_creator.domain.feedlink_builder import (
            build_feedlink_pair,
        )
        from osm.osm_feedlink_creator.domain.network_nodes import NodeInfo

        node = NodeInfo(node_id="N1", lon=nlon, lat=nlat, score=score)
        return build_feedlink_pair(zone_id, clon, clat, node)

    def test_returns_two_features(self) -> None:
        pair = self._call()
        assert len(pair) == 2

    def test_both_features_are_linestrings(self) -> None:
        for feat in self._call():
            assert feat["geometry"]["type"] == "LineString"
            assert len(feat["geometry"]["coordinates"]) == 2

    def test_production_from_zone_to_node(self) -> None:
        production, _ = self._call(zone_id="abc")
        assert production["properties"]["fromNode"] == "ZONE_abc"
        assert production["properties"]["toNode"] == "N1"

    def test_attraction_from_node_to_zone(self) -> None:
        _, attraction = self._call(zone_id="abc")
        assert attraction["properties"]["fromNode"] == "N1"
        assert attraction["properties"]["toNode"] == "ZONE_abc"

    def test_zone_id_on_both_features(self) -> None:
        for feat in self._call(zone_id="myzone"):
            assert feat["properties"]["zoneId"] == "myzone"

    def test_capacity_is_9999(self) -> None:
        for feat in self._call():
            assert feat["properties"]["capacity"] == 9999.0

    def test_flow_is_zero(self) -> None:
        for feat in self._call():
            assert feat["properties"]["flow"] == 0.0

    def test_length_is_positive(self) -> None:
        for feat in self._call(clon=6.15, clat=52.05, nlon=6.16, nlat=52.06):
            assert feat["properties"]["length"] > 0.0

    def test_length_is_haversine_distance(self) -> None:

        clon, clat, nlon, nlat = 6.15, 52.05, 6.16, 52.06
        production, _ = self._call(clon=clon, clat=clat, nlon=nlon, nlat=nlat)
        r = 6_371_000.0
        phi1, phi2 = math.radians(clat), math.radians(nlat)
        a = (
            math.sin(math.radians(nlat - clat) / 2) ** 2
            + math.cos(phi1) * math.cos(phi2) * math.sin(math.radians(nlon - clon) / 2) ** 2
        )
        expected = round(2 * r * math.asin(math.sqrt(a)), 2)
        assert production["properties"]["length"] == pytest.approx(expected, abs=0.5)

    def test_production_geometry_starts_at_centroid(self) -> None:
        clon, clat = 6.15, 52.05
        production, _ = self._call(clon=clon, clat=clat, nlon=6.20, nlat=52.10)
        assert production["geometry"]["coordinates"][0] == [clon, clat]

    def test_attraction_geometry_ends_at_centroid(self) -> None:
        clon, clat = 6.15, 52.05
        _, attraction = self._call(clon=clon, clat=clat, nlon=6.20, nlat=52.10)
        assert attraction["geometry"]["coordinates"][1] == [clon, clat]


# ===========================================================================
# TestCreateFeedlinks (integration)
# ===========================================================================


class TestCreateFeedlinks:
    def _network(self) -> dict:
        """Small network with three nodes: hub at zone centre, A and B outside."""
        return _network_fc(
            [
                # Hub inside zone, high score
                _link("HUB", "A", [6.150, 52.050], [6.100, 52.000], speed=80.0, capacity=2000.0),
                _link("HUB", "B", [6.150, 52.050], [6.200, 52.100], speed=80.0, capacity=2000.0),
            ]
        )

    def _zones(self, n: int = 2) -> dict:
        zones = [_square_zone(6.15, 52.05, half=0.02, zone_id=f"zone_{i}") for i in range(n)]
        return _zones_fc(zones)

    def test_returns_feature_collection(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            create_feedlinks,
        )

        fc, _ = create_feedlinks(self._network(), self._zones(1))
        assert fc["type"] == "FeatureCollection"

    def test_two_features_per_zone(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            create_feedlinks,
        )

        fc, stats = create_feedlinks(self._network(), self._zones(3))
        assert len(fc["features"]) == 6
        assert stats["total"] == 6

    def test_stats_zones_matched(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            create_feedlinks,
        )

        # Hub is inside every zone (zones centred at hub coords, half=0.02)
        _, stats = create_feedlinks(self._network(), self._zones(2))
        assert stats["zonesMatched"] == 2
        assert stats["zonesFallback"] == 0

    def test_stats_fallback_when_nodes_outside_all_zones(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            create_feedlinks,
        )

        # Network nodes are far from zones
        net = _network_fc([_link("FAR", "ALSO_FAR", [10.0, 55.0], [10.1, 55.1])])
        zones = _zones_fc([_square_zone(6.15, 52.05, half=0.001, zone_id="z0")])
        _, stats = create_feedlinks(net, zones)
        assert stats["zonesFallback"] == 1
        assert stats["zonesMatched"] == 0

    def test_all_feedlinks_have_required_properties(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            FEEDLINK_PROPERTIES,
            create_feedlinks,
        )

        fc, _ = create_feedlinks(self._network(), self._zones(2))
        for feat in fc["features"]:
            for key in FEEDLINK_PROPERTIES:
                assert key in feat["properties"], f"Missing property: {key}"

    def test_zone_node_ids_not_in_network(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            create_feedlinks,
        )

        fc, _ = create_feedlinks(self._network(), self._zones(2))
        # Zone virtual node IDs must start with "ZONE_"
        for feat in fc["features"]:
            props = feat["properties"]
            from_n, to_n = props["fromNode"], props["toNode"]
            assert "ZONE_" in from_n or "ZONE_" in to_n

    def test_empty_network_returns_empty_fc(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            create_feedlinks,
        )

        fc, stats = create_feedlinks(
            {"type": "FeatureCollection", "features": []},
            self._zones(2),
        )
        assert fc["features"] == []
        assert stats["total"] == 0

    def test_skips_zones_without_zone_id(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            create_feedlinks,
        )

        no_id_zone = {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [[[6.1, 52.0], [6.2, 52.0], [6.2, 52.1], [6.1, 52.1], [6.1, 52.0]]],
            },
            "properties": {"centroidLon": 6.15, "centroidLat": 52.05},
        }
        fc, stats = create_feedlinks(self._network(), _zones_fc([no_id_zone]))
        assert stats["total"] == 0

    def test_hub_node_is_selected_for_inside_zone(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            create_feedlinks,
        )

        # Only HUB (6.15, 52.05) is inside the zone; A (6.1, 52.0) is outside
        fc, _ = create_feedlinks(self._network(), self._zones(1))
        zone_feedlinks = fc["features"]
        # Both features reference HUB as the network attachment node
        node_ids = {f["properties"]["fromNode"] for f in zone_feedlinks} | {
            f["properties"]["toNode"] for f in zone_feedlinks
        }
        assert "HUB" in node_ids

    def test_fields_metadata_on_fc(self) -> None:
        from osm.osm_feedlink_creator.core.osm_feedlink_creator_core import (
            FEEDLINK_PROPERTIES,
            create_feedlinks,
        )

        fc, _ = create_feedlinks(self._network(), self._zones(1))
        assert fc["properties"]["fields"] == list(FEEDLINK_PROPERTIES)
