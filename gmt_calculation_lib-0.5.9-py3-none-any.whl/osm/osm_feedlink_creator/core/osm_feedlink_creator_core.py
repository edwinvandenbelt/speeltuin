"""Pure-Python osm_feedlink_creator core — no I/O, no boto3, no external deps.

Creates feedlinks that connect every building zone (output of
``building_zone_creator``) to the most important network node within that
zone.  "Most important" is defined as the node with the highest cumulative
``speed × capacity`` score across all incident network links.  When no node
falls inside the zone polygon, the nearest node to the zone centroid is used
as a fallback.

Each zone produces exactly two feedlink features:
- **Production**: virtual zone-centroid node → network attachment node
- **Attraction**: network attachment node → virtual zone-centroid node

The output GeoJSON FeatureCollection is compatible with ``matrix_builder`` /
``od_support_matrices_creator.build_graph``, which expects feedlink features
with properties ``zoneId``, ``fromNode``, ``toNode``, ``length``,
``capacity``, and ``flow``.

Public API
----------
FEEDLINK_PROPERTIES: tuple[str, ...]
    Ordered property keys for every feedlink Feature.

create_feedlinks(network_fc, zones_fc) -> tuple[dict, dict]
    Build the feedlinks FeatureCollection and a stats summary dict.
    ``stats``: {"total": int, "zonesMatched": int, "zonesFallback": int}
"""

from __future__ import annotations

import logging

from osm.osm_feedlink_creator.domain.feedlink_builder import (
    FEEDLINK_PROPERTIES,
    build_feedlink_pair,
)
from osm.osm_feedlink_creator.domain.network_nodes import extract_nodes
from osm.osm_feedlink_creator.domain.zone_matcher import find_best_node

logger = logging.getLogger(__name__)

__all__ = ["FEEDLINK_PROPERTIES", "create_feedlinks"]


def create_feedlinks(
    network_fc: dict,
    zones_fc: dict,
) -> tuple[dict, dict]:
    """Create feedlinks connecting zone centroids to network attachment nodes.

    Parameters
    ----------
    network_fc:
        GeoJSON FeatureCollection of directed network links.  Each Feature
        must have a LineString geometry and properties ``fromNode``,
        ``toNode``, plus ``speed`` + ``capacity`` (directed format) or
        ``max_snelheid_heen`` + ``cap_heen`` (raw OSM format).
    zones_fc:
        GeoJSON FeatureCollection of building zones (output of
        ``building_zone_creator``).  Each Feature must have a Polygon geometry
        and properties ``zoneId``, ``centroidLon``, ``centroidLat``.

    Returns
    -------
    feedlinks_fc:
        GeoJSON FeatureCollection with two Features per zone.
    stats:
        ``{"total": int, "zonesMatched": int, "zonesFallback": int}``
        *total* is the number of feedlink Features (= 2 × zonesMatched).
        *zonesFallback* counts zones where no node was inside the polygon.
    """
    # Build node index once.
    nodes = extract_nodes(network_fc)
    logger.info("Network node index: %d nodes", len(nodes))

    if not nodes:
        logger.warning("No network nodes found — returning empty feedlinks")
        return (
            {
                "type": "FeatureCollection",
                "features": [],
                "properties": {"fields": list(FEEDLINK_PROPERTIES)},
            },
            {"total": 0, "zonesMatched": 0, "zonesFallback": 0},
        )

    features: list[dict] = []
    zones_matched = 0
    zones_fallback = 0

    for zone_feat in zones_fc.get("features", []):
        props = zone_feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "").strip()
        if not zone_id:
            logger.debug("Skipping zone feature with missing zoneId")
            continue

        centroid_lon = float(props.get("centroidLon") or 0.0)
        centroid_lat = float(props.get("centroidLat") or 0.0)

        # Determine whether any node falls inside the polygon (for stats).
        geom = zone_feat.get("geometry") or {}
        from osm.osm_feedlink_creator.domain.zone_matcher import _contains

        nodes_inside = [n for n in nodes.values() if _contains(geom, n.lon, n.lat)]
        is_fallback = len(nodes_inside) == 0

        node = find_best_node(zone_feat, nodes)
        if node is None:
            logger.warning("No node found for zone %s — skipping", zone_id)
            continue

        pair = build_feedlink_pair(zone_id, centroid_lon, centroid_lat, node)
        features.extend(pair)

        if is_fallback:
            zones_fallback += 1
            logger.debug("Zone %s: fallback to nearest node %s", zone_id, node.node_id)
        else:
            zones_matched += 1
            logger.debug(
                "Zone %s: matched to node %s (score=%.1f)", zone_id, node.node_id, node.score
            )

    feedlinks_fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"fields": list(FEEDLINK_PROPERTIES)},
    }
    stats = {
        "total": len(features),
        "zonesMatched": zones_matched,
        "zonesFallback": zones_fallback,
    }
    logger.info(
        "Feedlinks created: %d features, %d zones matched inside, %d fallback",
        stats["total"],
        stats["zonesMatched"],
        stats["zonesFallback"],
    )
    return feedlinks_fc, stats
