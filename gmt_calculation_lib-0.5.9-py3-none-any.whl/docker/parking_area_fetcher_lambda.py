"""ParkingAreaFetcher Lambda handler — thin I/O wrapper around core.

Fetches parking-area polygons (parkeervlakken) for a bounding box from BGT
(Netherlands, via PDOK) and/or OSM Overpass, and writes the merged result as a
GeoParquet FeatureCollection tagged ``assetType="parkingArea"``.

Environment variables
----------------------
LOG_LEVEL - DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "bbox":         [6.39, 52.14, 6.43, 52.17],  // required unless networkUri is given
        "networkUri":   "s3://bucket/NETWORK-CAR.parquet",  // alternative to bbox
        "outputUri":    "s3://bucket/PARKING.parquet",      // required
        "useBgt":       true,   // optional — default true
        "useOsm":       true,   // optional — default true
        "bgtUrl":       null,   // optional — PDOK OGC API Features base URL
        "overpassUrl":  null,   // optional — Overpass API endpoint
        "tiles":        5,      // optional — NxN Overpass tile grid
        "timeout":      60      // optional — HTTP timeout in seconds
    }
}

Response (direct invocation)
-----------------------------
{
    "statusCode": 200,
    "outputs": {
        "outputUri": "s3://bucket/PARKING.parquet",
        "parkingArea": 42,
        "bgt": 30,
        "osm": 12,
        "total": 42,
        "tiles": 5,
        "source": "BGT+OSM"
    }
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def _bbox_from_network(uri: str) -> list[float]:
    from gmt_shared.geoparquet import from_geoparquet

    fc = from_geoparquet(_read_uri(uri))
    bbox: list[float] | None = (fc.get("properties") or {}).get("bbox")
    if bbox and len(bbox) >= 4:
        return [float(v) for v in bbox[:4]]
    lons: list[float] = []
    lats: list[float] = []
    for feat in fc.get("features") or []:
        for coord in (feat.get("geometry") or {}).get("coordinates") or []:
            lons.append(float(coord[0]))
            lats.append(float(coord[1]))
    if not lons:
        raise ValueError("Cannot determine bounding box — network has no geometry.")
    return [min(lons), min(lats), max(lons), max(lats)]


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point. Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from gmt_network_enrichment.parking_area_fetcher.core.parking_area_fetcher_core import (
            OVERPASS_GRID,
            fetch_parking_areas,
        )
        from gmt_shared.geoparquet import to_geoparquet
        from gmt_shared.overpass import DEFAULT_OVERPASS_URL

        inputs: dict = event.get("inputs", {})

        output_uri: str = inputs.get("outputUri", "") or ""
        if not output_uri:
            raise ValueError("inputs.outputUri is required.")

        bbox: list[float] | None = inputs.get("bbox")
        network_uri: str | None = inputs.get("networkUri") or None
        if bbox:
            bbox = [float(v) for v in bbox]
        elif network_uri:
            bbox = _bbox_from_network(network_uri)
        else:
            raise ValueError("inputs.bbox is required unless inputs.networkUri is supplied.")

        logger.info("Fetching parking areas: bbox=%s", bbox)
        fc, stats = fetch_parking_areas(
            bbox,
            bgt_url=inputs.get("bgtUrl") or None,
            overpass_url=inputs.get("overpassUrl") or DEFAULT_OVERPASS_URL,
            timeout=int(inputs.get("timeout", 60)),
            tiles=int(inputs["tiles"]) if inputs.get("tiles") is not None else OVERPASS_GRID,
            use_bgt=bool(inputs.get("useBgt", True)),
            use_osm=bool(inputs.get("useOsm", True)),
        )

        logger.info("Writing output  : %s", output_uri)
        _write_uri(output_uri, to_geoparquet(fc))

        logger.info(
            "Invocation complete [request_id=%s]: %s",
            request_id,
            stats,
        )
        return {
            "statusCode": 200,
            "status": "successful",
            "outputs": {"outputUri": output_uri, **stats},
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id,
            exc,
            traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
