"""FlowScaler Lambda handler — thin I/O wrapper around flow_scaler_core.

Reads a network GeoJSON and scaling index files, applies demand-scaling indices,
and writes the scaled network.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "networkUri":       "s3://bucket/key or local path",  // required
        "purposeIndexUri":  "s3://bucket/indices/purpose_index.json",  // required
        "daylightIndexUri": "s3://bucket/indices/daylight.json",       // required
        "holidayIndexUri":  "s3://bucket/indices/holiday_indices.csv", // optional
        "date":             "2025-06-21T09:00:00Z",  // optional
        "temperature":      "medium",                // optional (default: medium)
        "weather":          "cloudy",                // optional (default: cloudy)
        "purpose":          "all",                   // optional (default: all)
        "bbox":             [minLon, minLat, maxLon, maxLat],  // optional
        "limit":            100,                     // optional (default: 100)
        "offset":           0,                       // optional (default: 0)
        "runCleaner":       true,                    // optional (default: true)
        "outputUri":        "s3://bucket/key"        // optional (default: overwrite networkUri)
    }
}

Response (200)
--------------
{
    "statusCode":   200,
    "status":       "successful",
    "outputUri":    "...",
    "features":     int,
    "mode":         "CAR",
    "temperature":  "medium",
    "weather":      "cloudy"
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

        from flow_scaler.core.flow_scaler_core import (
            Params,
            applyIndices,
            determineIndiceKeys,
            filterNetwork,
            load_purpose_index,
            normalise_temperature,
            normalise_weather,
            parse_date,
            read_indexes,
        )

        inputs: dict = event.get("inputs", {})

        network_uri: str = inputs.get("networkUri", "")
        purpose_index_uri: str = inputs.get("purposeIndexUri", "")
        daylight_index_uri: str = inputs.get("daylightIndexUri", "")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not purpose_index_uri:
            raise ValueError("inputs.purposeIndexUri is required.")
        if not daylight_index_uri:
            raise ValueError("inputs.daylightIndexUri is required.")

        holiday_index_uri: str = inputs.get(
            "holidayIndexUri", "s3://gmp-networks/indices/holiday_indices.csv"
        )
        date_str = inputs.get("date")
        temperature_raw: str = inputs.get("temperature", "medium")
        weather_raw: str = inputs.get("weather", "cloudy")
        purpose_raw: str = inputs.get("purpose", "all")
        bbox = inputs.get("bbox")
        limit: int = int(inputs.get("limit", 100))
        offset: int = int(inputs.get("offset", 0))
        run_cleaner: bool = bool(inputs.get("runCleaner", True))
        output_uri: str = inputs.get("outputUri", "") or network_uri

        logger.info("Reading network       : %s", network_uri)
        network = from_geoparquet(_read_uri(network_uri))

        net_modes = (network.get("properties") or {}).get("modes") or []
        if not net_modes:
            raise ValueError("Network has no 'modes' property — cannot derive transport mode.")
        mode = net_modes[0]

        logger.info("Reading purpose index : %s", purpose_index_uri)
        purpose_index_raw = json.loads(_read_uri(purpose_index_uri))

        logger.info("Reading daylight      : %s", daylight_index_uri)
        daylight_raw = json.loads(_read_uri(daylight_index_uri))

        dt = parse_date(date_str)
        temperature = normalise_temperature(temperature_raw)
        weather = normalise_weather(weather_raw, dt, daylight_raw)
        purpose = None if purpose_raw.lower() == "all" else purpose_raw.lower()

        purpose_index = load_purpose_index(purpose_index_raw)
        params = Params(
            mode=mode,
            dt=dt,
            temperature=temperature,
            weather=weather,
            regio=(network.get("properties") or {}).get("region") or "",
            purpose=purpose,
            holiday_index=holiday_index_uri,
        )

        filtered = filterNetwork(network, bbox, offset, limit)
        filtered.params = params
        keys = determineIndiceKeys(params, filtered.metadata)
        indexes = read_indexes(keys, purpose_index)
        result = applyIndices(filtered, indexes, run_cleaner=run_cleaner)

        result["properties"] = {
            "mode": mode,
            "date": date_str or None,
            "temperature": temperature,
            "weather": weather,
            "purpose": purpose_raw,
            "limit": limit,
            "offset": offset,
        }

        n_features = len(result.get("features", []))
        logger.info("Writing output : %s  (%d features)", output_uri, n_features)
        _write_uri(output_uri, to_geoparquet(result))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "outputUri": output_uri,
            "features": n_features,
            "mode": mode,
            "temperature": temperature,
            "weather": weather,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
