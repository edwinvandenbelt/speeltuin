"""ParquetExporter Lambda handler — thin I/O wrapper around parquet_exporter_core.

Converts a GeoParquet pipeline artifact to GeoJSON or GeoJSONL format.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "inputUri":              "s3://bucket/key or local path",  // required
        "format":                "geojson",                        // optional (geojson/geojsonl)
        "outputUri":             "s3://bucket/key or local path",  // optional (inline if omitted)
        "geojsonlIncludeMetadata": false                           // optional
    }
}

Response (200)
--------------
When outputUri is provided:
    { "statusCode": 200, "status": "successful", "outputUri": "...", "features": int }

When outputUri is omitted, the GeoJSON string is returned inline:
    { "statusCode": 200, "status": "successful", "content": "<geojson string>", "features": int }
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)

_FORMAT_CTYPE: dict[str, str] = {
    "geojson": "application/geo+json",
    "geojsonl": "application/x-ndjson",
}


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data, content_type)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from gmt_shared.geoparquet import from_geoparquet
        from gmt_utils.parquet_exporter.core.parquet_exporter_core import (
            export_to_geojson,
            export_to_geojsonl,
        )

        inputs: dict = event.get("inputs", {})

        input_uri: str = inputs.get("inputUri", "")
        if not input_uri:
            raise ValueError("inputs.inputUri is required.")

        fmt: str = inputs.get("format", "geojson").lower()
        if fmt not in _FORMAT_CTYPE:
            raise ValueError(f"inputs.format must be 'geojson' or 'geojsonl', got {fmt!r}")
        output_uri: str = inputs.get("outputUri", "")
        include_metadata: bool = bool(inputs.get("geojsonlIncludeMetadata", False))

        logger.info("Reading : %s", input_uri)
        fc = from_geoparquet(_read_uri(input_uri))
        feature_count = len(fc.get("features") or [])

        if fmt == "geojson":
            content = export_to_geojson(fc)
        else:
            content = export_to_geojsonl(fc, include_metadata=include_metadata)

        content_bytes = content.encode("utf-8")

        if output_uri:
            logger.info("Writing : %s", output_uri)
            _write_uri(output_uri, content_bytes, _FORMAT_CTYPE[fmt])
            logger.info("Invocation complete [request_id=%s]", request_id)
            return {
                "statusCode": 200,
                "status": "successful",
                "outputUri": output_uri,
                "features": feature_count,
                "format": fmt,
                "bytes": len(content_bytes),
            }

        # Inline response
        logger.info("Invocation complete [request_id=%s] (inline)", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "content": content,
            "features": feature_count,
            "format": fmt,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
