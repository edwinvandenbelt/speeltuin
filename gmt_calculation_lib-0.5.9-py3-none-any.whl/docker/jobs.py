"""OGC job state management — S3 or local filesystem backend.

The storage backend is selected by the ``JOBS_BUCKET`` environment variable:

* Plain bucket name (e.g. ``my-bucket``) → S3: ``s3://my-bucket/.jobs/…``
* ``s3://…`` URI                          → S3 (URI used as-is as base)
* Absolute path (e.g. ``/tmp/gmt-jobs``) → local filesystem
* ``file:///…`` URI                       → local filesystem

This means local development needs no AWS credentials:

    docker run -p 8080:8080 \\
        -v /tmp/gmt-jobs:/jobs \\
        -e JOBS_BUCKET=/jobs \\
        gmt-calculation-service

Environment variables
---------------------
JOBS_BUCKET  – Storage location for job state (see above).
"""

from __future__ import annotations

import json
import logging
import os
from datetime import UTC, datetime
from pathlib import Path

logger = logging.getLogger(__name__)

_JOB_PREFIX = ".jobs"


# ---------------------------------------------------------------------------
# Backend detection
# ---------------------------------------------------------------------------


def _jobs_base() -> str:
    """Derive the base URI / path for job state from ``JOBS_BUCKET``.

    Returns an empty string when ``JOBS_BUCKET`` is unset.
    """
    raw = os.environ.get("JOBS_BUCKET", "").strip()
    if not raw:
        return ""
    # Explicit URI schemes
    if raw.startswith(("s3://", "file://", "mem://")):
        return raw.rstrip("/")
    # Absolute or relative local path (works on both Unix and Windows)
    if raw.startswith((".", "~")) or Path(raw).is_absolute():
        return raw.rstrip("/\\")
    # Plain bucket name → S3
    return f"s3://{raw}"


def _is_local(base: str) -> bool:
    return base != "" and not base.startswith("s3://")


def _job_uri(base: str, job_id: str) -> str:
    if _is_local(base):
        # Use pathlib so bare paths and file:// both work
        root = Path(base.removeprefix("file://"))
        return str(root / _JOB_PREFIX / job_id / "status.json")
    return f"{base}/{_JOB_PREFIX}/{job_id}/status.json"


# ---------------------------------------------------------------------------
# Low-level I/O
# ---------------------------------------------------------------------------


def _put(base: str, job_id: str, data: dict) -> None:
    from gmt_shared.uri import write_uri

    uri = _job_uri(base, job_id)
    write_uri(uri, json.dumps(data, ensure_ascii=False).encode("utf-8"),
              content_type="application/json")


def _get_raw(base: str, job_id: str) -> dict | None:
    from gmt_shared.uri import read_uri

    uri = _job_uri(base, job_id)
    try:
        return json.loads(read_uri(uri))
    except Exception:
        return None


def _list_job_ids(base: str, limit: int) -> list[str]:
    """Return up to *limit* job IDs from the storage backend."""
    if _is_local(base):
        root = Path(base.removeprefix("file://")) / _JOB_PREFIX
        if not root.exists():
            return []
        return [
            p.parent.name
            for p in sorted(root.glob("*/status.json"))[:limit]
        ]
    # S3 backend
    bucket, prefix = _s3_bucket_prefix(base)
    try:
        import boto3

        s3 = boto3.client("s3")
        response = s3.list_objects_v2(
            Bucket=bucket,
            Prefix=f"{prefix}/",
            Delimiter="/",
        )
        return [
            p["Prefix"].rstrip("/").rsplit("/", 1)[-1]
            for p in (response.get("CommonPrefixes") or [])
        ][:limit]
    except Exception:
        logger.exception("list_jobs S3 listing failed")
        return []


def _s3_bucket_prefix(base: str) -> tuple[str, str]:
    """Split ``s3://bucket[/extra]`` into ``(bucket, prefix)``."""
    without_scheme = base.removeprefix("s3://")
    parts = without_scheme.split("/", 1)
    bucket = parts[0]
    extra = parts[1] if len(parts) > 1 else ""
    prefix = f"{extra}/{_JOB_PREFIX}".lstrip("/") if extra else _JOB_PREFIX
    return bucket, prefix


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _now_iso() -> str:
    return datetime.now(UTC).isoformat(timespec="seconds").replace("+00:00", "Z")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def create_job(job_id: str, process_id: str, base_url: str = "") -> dict:
    """Create a new job in 'accepted' state, persist it, and return the status dict."""
    base = _jobs_base()
    now = _now_iso()
    status: dict = {
        "jobID": job_id,
        "processID": process_id,
        "status": "accepted",
        "created": now,
        "updated": now,
        "started": None,
        "finished": None,
        "progress": 0,
        "message": "Job accepted.",
        "links": [
            {
                "rel": "self",
                "type": "application/json",
                "href": f"{base_url}/v1/jobs/{job_id}",
                "title": "Job status",
            },
            {
                "rel": "http://www.opengis.net/def/rel/ogc/1.0/results",
                "type": "application/json",
                "href": f"{base_url}/v1/jobs/{job_id}/results",
                "title": "Job results",
            },
        ],
    }
    _put(base, job_id, status)
    return status


def update_job(
    job_id: str,
    status: str,
    *,
    message: str | None = None,
    progress: int | None = None,
    results: dict | None = None,
) -> None:
    """Read the current job state, apply updates, and write it back."""
    base = _jobs_base()
    current = _get_raw(base, job_id) or {}
    now = _now_iso()
    current["status"] = status
    current["updated"] = now

    if message is not None:
        current["message"] = message
    if progress is not None:
        current["progress"] = progress
    if status == "running" and not current.get("started"):
        current["started"] = now
    if status in ("successful", "failed", "dismissed"):
        current["finished"] = now
        if status == "successful":
            current["progress"] = 100
    if results is not None:
        current["results"] = results

    _put(base, job_id, current)


def get_job(job_id: str) -> dict | None:
    """Return the job status dict, or None if not found."""
    base = _jobs_base()
    if not base:
        return None
    return _get_raw(base, job_id)


def list_jobs(limit: int = 100) -> list[dict]:
    """Return a list of all job status objects (up to *limit*)."""
    base = _jobs_base()
    if not base:
        return []
    jobs: list[dict] = []
    for jid in _list_job_ids(base, limit):
        entry = _get_raw(base, jid)
        if entry is not None:
            jobs.append(entry)
    return jobs
