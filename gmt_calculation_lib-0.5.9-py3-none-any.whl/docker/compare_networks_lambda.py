"""CompareNetworks Lambda handler — thin I/O wrapper around compare_networks_core.

Reads two network GeoJSON FeatureCollections, computes a diff FeatureCollection,
and either returns it inline or writes it to an output URI.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "networkAUri":       "s3://bucket/key or local path",  // required
        "networkBUri":       "s3://bucket/key or local path",  // required
        "fields":            ["speed", "capacity"],            // optional
        "asBandwidths":      false,                            // optional (default: false)
        "bandwidthScale":    1.0,                              // optional
        "excludeUnchanged":  false,                            // optional (default: false)
        "outputUri":         "s3://bucket/key or local path"   // optional (inline if omitted)
    }
}

Response (200)
--------------
When outputUri is provided:
    { "statusCode": 200, "status": "successful", "outputUri": "..." }

When outputUri is omitted, the diff FeatureCollection is returned inline:
    { "statusCode": 200, "status": "successful", "type": "FeatureCollection", ... }
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

        from compare_networks.core.compare_networks_core import (
            compare_networks,
        )

        inputs: dict = event.get("inputs", {})

        network_a_uri: str = inputs.get("networkAUri", "")
        network_b_uri: str = inputs.get("networkBUri", "")
        if not network_a_uri:
            raise ValueError("inputs.networkAUri is required.")
        if not network_b_uri:
            raise ValueError("inputs.networkBUri is required.")

        fields = inputs.get("fields") or None
        as_bandwidths: bool = bool(inputs.get("asBandwidths", False))
        bandwidth_scale: float = float(inputs.get("bandwidthScale", 1.0))
        exclude_unchanged: bool = bool(inputs.get("excludeUnchanged", False))
        output_uri: str = inputs.get("outputUri", "")

        logger.info("Reading network A : %s", network_a_uri)
        fc_a = from_geoparquet(_read_uri(network_a_uri))

        logger.info("Reading network B : %s", network_b_uri)
        fc_b = from_geoparquet(_read_uri(network_b_uri))

        result_fc = compare_networks(
            fc_a,
            fc_b,
            fields=fields,
            as_bandwidths=as_bandwidths,
            bandwidth_scale=bandwidth_scale,
            exclude_unchanged=exclude_unchanged,
        )

        if output_uri:
            logger.info("Writing output  : %s", output_uri)
            _write_uri(output_uri, to_geoparquet(result_fc))
            logger.info("Invocation complete [request_id=%s]", request_id)
            return {
                "statusCode": 200,
                "status": "successful",
                "outputUri": output_uri,
                "features": len(result_fc.get("features", [])),
            }

        # Inline response (outputTransmission: value)
        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            **result_fc,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
