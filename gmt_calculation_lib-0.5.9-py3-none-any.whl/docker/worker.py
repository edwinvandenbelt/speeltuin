"""Background job executor — ThreadPoolExecutor with max 2 concurrent async jobs.

Each async process (prepare, adjust) is submitted here.  The worker calls the
module's Lambda handler directly in a background thread, then persists the
outcome to S3 via docker.jobs.
"""

from __future__ import annotations

import logging
import traceback
from collections.abc import Callable
from concurrent.futures import ThreadPoolExecutor
from typing import Any

from docker import jobs as _jobs

logger = logging.getLogger(__name__)

# Two concurrent async jobs maximum — aligns with the Fargate task sizing.
_executor = ThreadPoolExecutor(max_workers=2, thread_name_prefix="gmt-worker")


def submit_job(
    job_id: str,
    handler: Callable[[dict, Any], dict],
    inputs: dict,
) -> None:
    """Submit an async job to the thread pool.

    Returns immediately; the job runs in a background thread.
    """
    _executor.submit(_run_job, job_id, handler, inputs)


def _run_job(
    job_id: str,
    handler: Callable[[dict, Any], dict],
    inputs: dict,
) -> None:
    """Run a Lambda handler in a background thread and persist the result to S3."""
    logger.info("Job %s: starting.", job_id)
    _jobs.update_job(job_id, "running", message="Job is running.")
    try:
        result = handler({"inputs": inputs}, None)
        status_code: int = result.get("statusCode", 500)
        if status_code == 200:
            _jobs.update_job(
                job_id,
                "successful",
                message="Job completed successfully.",
                progress=100,
                results=result,
            )
            logger.info("Job %s: completed successfully.", job_id)
        else:
            _jobs.update_job(
                job_id,
                "failed",
                message=result.get("message") or f"Handler returned statusCode {status_code}.",
            )
            logger.warning("Job %s: failed (statusCode=%s).", job_id, status_code)
    except Exception as exc:
        logger.error(
            "Job %s: unhandled exception: %s\n%s",
            job_id, exc, traceback.format_exc(),
        )
        _jobs.update_job(
            job_id,
            "failed",
            message=f"Unhandled exception: {exc}",
        )
