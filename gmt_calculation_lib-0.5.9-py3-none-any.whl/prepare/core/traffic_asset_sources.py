"""Per-source registration and incremental fetching of traffic assets.

The combined ``{area_id}-TRAFFIC-ASSETS.parquet`` is assembled from several
independent sources (OSM objects, BGT objects, traffic signs, traffic signals,
parking areas).  This module makes it possible to add a single source to an
already-prepared area later on, without overwriting the features of the other
sources:

* every feature carries ``properties.src`` naming the source that produced it;
* the parquet footer (FeatureCollection ``properties``) holds a ``sources``
  register: ``{source: {"fetchedAt", "count", "via"}}``.  A source is only
  registered after a successful fetch, also when it returned zero features, so
  callers can tell "not fetched yet" apart from "fetched, nothing there".

Files written before this register existed have no ``sources`` key; their
sources are inferred from the features (see :func:`infer_feature_source`).

Only the traffic-assets file is touched — the NETWORK is never modified here.
"""

from __future__ import annotations

import datetime as _dt
import json
import os
import tempfile
from collections.abc import Iterable
from pathlib import Path

#: Property on each feature naming the source that produced it.
SRC_PROP = "src"

SOURCE_OSM = "osm"
SOURCE_BGT = "bgt"
SOURCE_SIGNS = "signs"
SOURCE_SIGNALS = "signals"
SOURCE_PARKING = "parking"
#: Give-way markers derived from the network (not fetchable on demand).
SOURCE_DERIVED = "derived"

ALL_SOURCES: tuple[str, ...] = (
    SOURCE_OSM,
    SOURCE_BGT,
    SOURCE_SIGNS,
    SOURCE_SIGNALS,
    SOURCE_PARKING,
)

_BGT_ONLY_TYPES = frozenset(
    {"screen", "bridge", "tunnel", "bak", "sidewalk", "bikePath", "trafficIsland"}
)

#: assetType values each fetchable source can produce.
SOURCE_ASSET_TYPES: dict[str, frozenset[str]] = {
    SOURCE_OSM: frozenset(
        {
            "pedestrianCrossing",
            "speedBump",
            "stopSign",
            "miniRoundabout",
            "mailbox",
            "busShelter",
            "mast",
            "bikeGate",
            "infoBoard",
            "trashBin",
            "busStop",
            "streetLight",
            "cyclePath",
            "footPath",
            "stoppingLane",
            "laneMarkArrow",
            "refugeAreaCrossing",
            "refugeAreaFootway",
            "refugeAreaTraffic",
        }
    ),
    SOURCE_BGT: _BGT_ONLY_TYPES | {"speedBump"},
    SOURCE_SIGNS: frozenset({"trafficSign"}),
    SOURCE_SIGNALS: frozenset({"trafficSignal"}),
    SOURCE_PARKING: frozenset({"parkingArea"}),
}


def available_sources(in_nl: bool) -> list[str]:
    """Sources that can be fetched for an area (BGT only covers the Netherlands)."""
    return [s for s in ALL_SOURCES if in_nl or s != SOURCE_BGT]


def sources_for_asset_types(asset_types: Iterable[str] | None, in_nl: bool) -> set[str]:
    """Return the fetchable sources needed to provide *asset_types*.

    ``None`` means "all asset types".  In the Netherlands BGT is authoritative
    for speed bumps, so ``speedBump`` maps to BGT there and to OSM elsewhere —
    the same rule the prepare pipeline applies.
    """
    sources = available_sources(in_nl)
    if asset_types is None:
        return set(sources)
    needed: set[str] = set()
    for t in asset_types:
        for src in sources:
            if t not in SOURCE_ASSET_TYPES[src]:
                continue
            if t == "speedBump" and src == (SOURCE_OSM if in_nl else SOURCE_BGT):
                continue
            needed.add(src)
    return needed


def infer_feature_source(props: dict) -> str | None:
    """Best-effort source of a feature from a file without ``src`` tags."""
    if props.get(SRC_PROP):
        return props[SRC_PROP]
    t = props.get("assetType")
    if t == "trafficSignal":
        return SOURCE_SIGNALS
    if t == "trafficSign":
        return SOURCE_SIGNS
    if t == "parkingArea":
        return SOURCE_PARKING
    if t == "giveWay":
        return SOURCE_DERIVED
    if t in _BGT_ONLY_TYPES:
        return SOURCE_BGT
    if t == "speedBump":
        return SOURCE_OSM if _has_value(props.get("osm_id")) else SOURCE_BGT
    if t in SOURCE_ASSET_TYPES[SOURCE_OSM]:
        return SOURCE_OSM
    return None


def _has_value(v) -> bool:
    return v is not None and v != "" and not (isinstance(v, float) and v != v)


def _now_iso() -> str:
    return _dt.datetime.now(_dt.UTC).isoformat(timespec="seconds")


def _legacy_register(features: Iterable[dict]) -> dict[str, dict]:
    counts: dict[str, int] = {}
    for f in features:
        src = infer_feature_source(f.get("properties") or {})
        if src:
            counts[src] = counts.get(src, 0) + 1
    return {src: {"count": n, "legacy": True} for src, n in counts.items()}


def read_sources(path: str | Path) -> dict[str, dict]:
    """Return the sources register of a traffic-assets parquet.

    Reads only the footer when a register is present.  For older files without
    one, the register is inferred from the ``assetType``/``osm_id``/``src``
    columns (marked ``"legacy": True``).  A missing file yields ``{}``.
    """
    import pyarrow.parquet as pq

    path = Path(path)
    if not path.exists():
        return {}
    schema = pq.read_schema(path)
    props = json.loads((schema.metadata or {}).get(b"gmt_properties", b"{}"))
    if isinstance(props.get("sources"), dict):
        return props["sources"]
    cols = [c for c in ("assetType", "osm_id", SRC_PROP) if c in schema.names]
    if "assetType" not in cols:
        return {}
    rows = pq.read_table(path, columns=cols).to_pylist()
    return _legacy_register({"properties": r} for r in rows)


def tag_features(features: Iterable[dict], src: str) -> list[dict]:
    """Set ``properties.src`` on every feature (in place) and return them as a list."""
    out = []
    for f in features:
        props = f.get("properties")
        if props is None:
            props = f["properties"] = {}
        props[SRC_PROP] = src
        out.append(f)
    return out


def register_entry(count: int, via: str) -> dict:
    """A single register entry for a successfully fetched source."""
    return {"fetchedAt": _now_iso(), "count": count, "via": via}


def write_traffic_assets_atomic(path: str | Path, fc: dict) -> None:
    """Write *fc* as GeoParquet via a temp file + ``os.replace``.

    Readers that cache on mtime never see a half-written file.
    """
    from gmt_shared.geoparquet import to_geoparquet

    path = Path(path)
    data = to_geoparquet(fc)
    fd, tmp = tempfile.mkstemp(prefix=path.name + ".", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def _via_osm(osm_path: str | None) -> str:
    return f"pbf:{Path(osm_path).name}" if osm_path else "overpass"


def _fetch_source(
    src: str,
    bbox: list[float],
    *,
    in_nl: bool,
    network_fc: dict | None,
    osm_path: str | None,
    osm_workers: int | None,
    ndw_data_uri: str | None,
    bgt_url: str | None,
    timeout: int,
) -> tuple[list[dict], str]:
    """Fetch one source; returns ``(features, via)``.  Errors propagate."""
    if src == SOURCE_OSM:
        from gmt_network_enrichment.osm_asset_fetcher.core.osm_asset_fetcher_core import (
            DEFAULT_KINDS,
            KIND_SPEED_BUMP,
            elements_to_asset_features,
            fetch_osm_assets,
        )

        kinds = [k for k in DEFAULT_KINDS if not (in_nl and k == KIND_SPEED_BUMP)]
        fc, _stats = fetch_osm_assets(
            bbox, kinds=kinds, timeout=timeout, osm_path=osm_path, osm_workers=osm_workers
        )
        features = fc.get("features") or []
        elements = (fc.get("properties") or {}).get("_elements") or []
        if network_fc is not None and elements:
            # linkId/nodeId matching only — the network itself is not modified.
            features = elements_to_asset_features(elements, kinds, network_fc=network_fc)
        return features, _via_osm(osm_path)

    if src == SOURCE_BGT:
        from gmt_network_enrichment.bgt_fetcher.core.bgt_fetcher_core import fetch_bgt_assets

        fc, _stats = fetch_bgt_assets(bbox, url=bgt_url, timeout=max(timeout, 180))
        return fc.get("features") or [], "pdok"

    if src == SOURCE_SIGNS:
        from gmt_network_enrichment.traffic_sign_fetcher.core.traffic_sign_fetcher_core import (
            fetch_sign_features,
        )

        ndw_data = None
        if ndw_data_uri and in_nl:
            from gmt_shared.uri import read_uri

            ndw_data = json.loads(read_uri(ndw_data_uri))
        fc, stats = fetch_sign_features(
            bbox, ndw_data=ndw_data, timeout=timeout, osm_path=osm_path, osm_workers=osm_workers
        )
        return fc.get("features") or [], str(stats.get("source") or "")

    if src == SOURCE_SIGNALS:
        from gmt_network_enrichment.traffic_signal_annotator.core import (
            traffic_signal_annotator_core as _sig,
        )

        fetch_signal_coords = _sig.fetch_signal_coords
        signals_to_features = _sig.signals_to_features

        coords = fetch_signal_coords(
            bbox, timeout=timeout, osm_path=osm_path, osm_workers=osm_workers
        )
        return signals_to_features(coords), _via_osm(osm_path)

    if src == SOURCE_PARKING:
        from gmt_network_enrichment.parking_area_fetcher.core.parking_area_fetcher_core import (
            fetch_parking_areas,
        )

        fc, _stats = fetch_parking_areas(
            bbox,
            bgt_url=bgt_url,
            timeout=max(timeout, 180),
            use_bgt=in_nl,
            osm_path=osm_path,
            osm_workers=osm_workers,
        )
        return fc.get("features") or [], "bgt+osm" if in_nl else _via_osm(osm_path)

    raise ValueError(f"Unknown traffic-asset source: {src!r}")


def add_traffic_asset_sources(
    traffic_assets_path: str | Path,
    *,
    area_id: str,
    bbox: list[float],
    sources: Iterable[str],
    network_fc: dict | None = None,
    osm_path: str | None = None,
    osm_workers: int | None = None,
    ndw_data_uri: str | None = None,
    bgt_url: str | None = None,
    timeout: int = 60,
    in_nl: bool | None = None,
) -> dict[str, dict]:
    """Fetch *sources* and merge them into the traffic-assets parquet.

    Features of a fetched source replace that source's existing features; all
    other features are kept.  When BGT is added, OSM speed bumps are dropped
    (BGT is authoritative for speed bumps in the Netherlands).  Each
    successfully fetched source is registered in the footer, also with zero
    features.  If a source fails, the successful ones are still written and the
    first error is re-raised afterwards; the failed source stays unregistered.

    *network_fc* is only used to attach ``linkId``/``nodeId`` to OSM features.

    Returns the updated sources register.
    """
    from gmt_shared.geoparquet import from_geoparquet

    if in_nl is None:
        from gmt_network_enrichment.traffic_sign_fetcher.core.traffic_sign_fetcher_core import (
            is_netherlands,
        )

        in_nl = is_netherlands(bbox)

    path = Path(traffic_assets_path)
    if path.exists():
        existing = from_geoparquet(path.read_bytes())
        features = existing.get("features") or []
        fc_props = dict(existing.get("properties") or {})
        register = fc_props.get("sources")
        if not isinstance(register, dict):
            register = _legacy_register(features)
        # Make every existing feature carry its source so merges stay exact.
        for f in features:
            props = f.setdefault("properties", {})
            if not props.get(SRC_PROP):
                src = infer_feature_source(props)
                if src:
                    props[SRC_PROP] = src
    else:
        features, fc_props, register = [], {}, {}

    wanted = [s for s in dict.fromkeys(sources) if s in available_sources(in_nl)]
    first_error: BaseException | None = None
    changed = False
    for src in wanted:
        try:
            new_feats, via = _fetch_source(
                src,
                bbox,
                in_nl=in_nl,
                network_fc=network_fc,
                osm_path=osm_path,
                osm_workers=osm_workers,
                ndw_data_uri=ndw_data_uri,
                bgt_url=bgt_url,
                timeout=timeout,
            )
        except Exception as exc:
            print(f"  [{src}] WARNING: fetch failed ({exc}); source not registered.")
            if first_error is None:
                first_error = exc
            continue

        def _keep(f: dict, src: str = src) -> bool:
            props = f.get("properties") or {}
            if props.get(SRC_PROP) == src:
                return False
            return not (
                src == SOURCE_BGT
                and props.get(SRC_PROP) == SOURCE_OSM
                and props.get("assetType") == "speedBump"
            )

        features = [f for f in features if _keep(f)] + tag_features(new_feats, src)
        register[src] = register_entry(len(new_feats), via)
        changed = True
        print(f"  [{src}] {len(new_feats)} features ({via})")

    if changed:
        # Keep counts exact (e.g. OSM speed bumps dropped in favour of BGT).
        for src, entry in register.items():
            entry["count"] = sum(
                1 for f in features if (f.get("properties") or {}).get(SRC_PROP) == src
            )
        fc_props.update({"area_id": area_id, "bbox": bbox, "sources": register})
        write_traffic_assets_atomic(
            path, {"type": "FeatureCollection", "features": features, "properties": fc_props}
        )
    if first_error is not None:
        raise first_error
    return register
