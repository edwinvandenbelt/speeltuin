"""Unit tests for measure_set_creator core — pure Python, no I/O."""

from __future__ import annotations

import pytest

from measure_set_creator.core.measure_set_creator_core import create_measure_sets


def _link(link_id, coords):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {"linkId": link_id},
    }


def _square_polygon(min_lon, min_lat, max_lon, max_lat, properties=None):
    return {
        "type": "Feature",
        "geometry": {
            "type": "Polygon",
            "coordinates": [
                [
                    [min_lon, min_lat],
                    [max_lon, min_lat],
                    [max_lon, max_lat],
                    [min_lon, max_lat],
                    [min_lon, min_lat],
                ]
            ],
        },
        "properties": properties or {},
    }


class TestCreateMeasureSets:
    def test_closes_fully_covered_link(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [_link(1, [[0.0, 0.0], [1.0, 1.0]])],
        }
        polygon = _square_polygon(-1, -1, 2, 2, {"naam": "Hoofdstraat"})
        result = create_measure_sets(network_fc, [polygon], "Wegafsluitingen", "naam")

        assert len(result) == 1
        assert result[0]["name"] == "Wegafsluitingen, Hoofdstraat"
        assert result[0]["changes"] == [{"linkId": 1, "capacity": "0"}]

    def test_partially_overlapping_link_not_closed(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [_link(1, [[0.0, 0.0], [5.0, 5.0]])],
        }
        # Polygon only covers half the link.
        polygon = _square_polygon(-1, -1, 2, 2, {"naam": "Hoofdstraat"})
        result = create_measure_sets(network_fc, [polygon], "Wegafsluitingen", "naam")

        assert len(result) == 1
        assert result[0]["changes"] == []

    def test_multiple_links_multiple_polygons(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                _link(1, [[0.0, 0.0], [1.0, 1.0]]),
                _link(2, [[10.0, 10.0], [11.0, 11.0]]),
            ],
        }
        polygons = [
            _square_polygon(-1, -1, 2, 2, {"naam": "Zone A"}),
            _square_polygon(9, 9, 12, 12, {"naam": "Zone B"}),
        ]
        result = create_measure_sets(network_fc, polygons, "Zones", "naam")

        assert len(result) == 2
        by_name = {ms["name"]: ms for ms in result}
        assert by_name["Zones, Zone A"]["changes"] == [{"linkId": 1, "capacity": "0"}]
        assert by_name["Zones, Zone B"]["changes"] == [{"linkId": 2, "capacity": "0"}]

    def test_skips_feature_without_field_value(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [_link(1, [[0.0, 0.0], [1.0, 1.0]])],
        }
        polygons = [
            _square_polygon(-1, -1, 2, 2, {"naam": None}),
            _square_polygon(-1, -1, 2, 2, {}),
            _square_polygon(-1, -1, 2, 2, {"naam": "Geldige naam"}),
        ]
        result = create_measure_sets(network_fc, polygons, "Zones", "naam")

        assert len(result) == 1
        assert result[0]["name"] == "Zones, Geldige naam"

    def test_empty_measure_set_when_no_links_covered(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [_link(1, [[100.0, 100.0], [101.0, 101.0]])],
        }
        polygon = _square_polygon(-1, -1, 2, 2, {"naam": "Leeg gebied"})
        result = create_measure_sets(network_fc, [polygon], "Zones", "naam")

        assert len(result) == 1
        assert result[0]["name"] == "Zones, Leeg gebied"
        assert result[0]["changes"] == []

    def test_multiple_links_covered_by_one_polygon(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                _link(1, [[0.0, 0.0], [1.0, 1.0]]),
                _link(2, [[0.5, 0.5], [1.5, 1.5]]),
            ],
        }
        polygon = _square_polygon(-1, -1, 3, 3, {"naam": "Groot gebied"})
        result = create_measure_sets(network_fc, [polygon], "Zones", "naam")

        assert len(result) == 1
        link_ids = {c["linkId"] for c in result[0]["changes"]}
        assert link_ids == {1, 2}

    def test_boundary_touching_link_is_covered(self):
        # Link endpoint exactly on the polygon boundary should still count
        # (covers, not strict contains).
        network_fc = {
            "type": "FeatureCollection",
            "features": [_link(1, [[0.0, 0.0], [1.0, 0.0]])],
        }
        polygon = _square_polygon(0.0, 0.0, 1.0, 1.0, {"naam": "Rand"})
        result = create_measure_sets(network_fc, [polygon], "Zones", "naam")

        assert result[0]["changes"] == [{"linkId": 1, "capacity": "0"}]

    def test_empty_layer_features_returns_empty_list(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [_link(1, [[0.0, 0.0], [1.0, 1.0]])],
        }
        result = create_measure_sets(network_fc, [], "Zones", "naam")
        assert result == []

    def test_raises_on_invalid_network_fc(self):
        with pytest.raises(ValueError, match="FeatureCollection"):
            create_measure_sets({"type": "Feature"}, [], "Zones", "naam")

    def test_raises_on_missing_layer_name(self):
        network_fc = {"type": "FeatureCollection", "features": []}
        with pytest.raises(ValueError, match="layer_name"):
            create_measure_sets(network_fc, [], "", "naam")

    def test_raises_on_missing_field_name(self):
        network_fc = {"type": "FeatureCollection", "features": []}
        with pytest.raises(ValueError, match="field_name"):
            create_measure_sets(network_fc, [], "Zones", "")

    def test_link_without_link_id_is_ignored(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [1.0, 1.0]]},
                    "properties": {},
                }
            ],
        }
        polygon = _square_polygon(-1, -1, 2, 2, {"naam": "Zone"})
        result = create_measure_sets(network_fc, [polygon], "Zones", "naam")
        assert result[0]["changes"] == []
