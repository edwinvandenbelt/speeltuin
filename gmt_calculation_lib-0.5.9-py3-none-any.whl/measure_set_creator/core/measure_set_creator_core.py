"""Pure-Python measure_set_creator core — no I/O, no boto3, no external deps.

Given a directed network FeatureCollection and a set of polygon features (from
one layer of a user-uploaded GeoPackage), derive one "maatregelset" (measure
set) per polygon feature: a named, `adjust`-compatible list of link-closure
changes (``{"linkId": ..., "capacity": "0"}``) for every network link whose
full geometry is covered by that polygon.

Public API
----------
create_measure_sets(network_fc, layer_features, layer_name, field_name) -> list[dict]
    Build one measure set per polygon feature.
"""

from __future__ import annotations

import logging

from measure_set_creator.domain.matching import (
    find_fully_covered_link_ids,
    index_network_links,
)

logger = logging.getLogger(__name__)

__all__ = ["create_measure_sets"]


def _measure_set_name(layer_name: str, field_value: object) -> str:
    """Return the composite measure-set name: ``"{layer_name}, {field_value}"``."""
    return f"{layer_name}, {field_value}"


def create_measure_sets(
    network_fc: dict,
    layer_features: list[dict],
    layer_name: str,
    field_name: str,
) -> list[dict]:
    """Build one measure set per polygon feature in *layer_features*.

    Parameters
    ----------
    network_fc:
        GeoJSON FeatureCollection of directed network links.  Each feature
        must have a ``properties.linkId``.
    layer_features:
        GeoJSON polygon (or multipolygon) features from a single GeoPackage
        layer, already reprojected to WGS-84 (EPSG:4326).
    layer_name:
        Name of the source layer, used as the first part of every measure-set
        name.
    field_name:
        Property key on each polygon feature whose value forms the second
        part of the measure-set name.

    Returns
    -------
    list[dict]
        One entry per polygon feature that has a usable *field_name* value:
        ``{"name": "<layer_name>, <field_value>", "changes": [...]}``.
        Features without a usable *field_name* value are skipped.  A polygon
        that does not fully cover any network link still yields a measure set
        with an empty ``"changes"`` list.
    """
    if network_fc.get("type") != "FeatureCollection":
        raise ValueError("network_fc must be a GeoJSON FeatureCollection.")
    if not isinstance(layer_features, list):
        raise ValueError("layer_features must be a list of GeoJSON features.")
    if not layer_name:
        raise ValueError("layer_name must be a non-empty string.")
    if not field_name:
        raise ValueError("field_name must be a non-empty string.")

    network_index = index_network_links(network_fc)
    logger.info("Indexed %d network links", len(network_index))

    measure_sets: list[dict] = []
    skipped = 0

    for feature in layer_features:
        props = feature.get("properties") or {}
        field_value = props.get(field_name)
        if field_value is None or field_value == "":
            skipped += 1
            logger.warning("Skipping feature without a usable '%s' field value", field_name)
            continue

        name = _measure_set_name(layer_name, field_value)
        link_ids = find_fully_covered_link_ids(feature.get("geometry"), network_index)
        changes = [{"linkId": link_id, "capacity": "0"} for link_id in link_ids]

        measure_sets.append({"name": name, "changes": changes})

    logger.info(
        "Built %d measure set(s) from %d feature(s) (%d skipped)",
        len(measure_sets),
        len(layer_features),
        skipped,
    )
    return measure_sets
