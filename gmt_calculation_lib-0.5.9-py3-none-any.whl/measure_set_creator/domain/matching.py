"""Pure-Python spatial matching for measure_set_creator — no I/O, no boto3.

Matches network link geometries against polygon features to determine which
links are entirely covered by a given polygon (``polygon.covers(link)``).
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def _to_shapely_geometry(geom: dict | None):
    """Return a shapely geometry object for a GeoJSON geometry dict, or None."""
    if not geom:
        return None
    try:
        from shapely.geometry import shape
    except ImportError:
        logger.warning("shapely not available; cannot build geometry")
        return None
    try:
        return shape(geom)
    except ValueError, TypeError:
        return None


def index_network_links(network_fc: dict) -> list[tuple[object, object]]:
    """Return a list of ``(linkId, shapely_geometry)`` for every network link.

    Features without a usable ``linkId`` or geometry are skipped.
    """
    index: list[tuple[object, object]] = []
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        link_id = props.get("linkId")
        if link_id is None:
            continue
        geom = _to_shapely_geometry(feat.get("geometry"))
        if geom is None or geom.is_empty:
            continue
        index.append((link_id, geom))
    return index


def find_fully_covered_link_ids(
    polygon_geom: dict | None,
    network_index: list[tuple[object, object]],
) -> list[object]:
    """Return the ``linkId`` values whose full geometry is covered by *polygon_geom*.

    Uses ``polygon.covers(link)`` (contains + boundary-touching allowed) so
    links whose endpoints exactly touch the polygon boundary still count as
    fully covered.
    """
    polygon = _to_shapely_geometry(polygon_geom)
    if polygon is None or polygon.is_empty:
        return []

    covered: list[object] = []
    for link_id, link_geom in network_index:
        try:
            if polygon.covers(link_geom):
                covered.append(link_id)
        except Exception:  # malformed geometry, skip defensively
            logger.debug("Skipping malformed link geometry for linkId=%s", link_id)
            continue
    return covered
