# Databricks notebook source
# ---------------------------------------------------------------------------
# adjust_nb.py — Databricks notebook interface for the GMT node-adjustment pipeline.
#
# This notebook:
#   1. Reads widget parameters (folder, changes, output folder, …).
#   2. Installs gmt-calculation-lib from Nexus (if not already present).
#   3. Calls adjust.core.adjust_core.run_pipeline directly.
#
# Requirements (Databricks cluster):
#   pip install gmt-calculation-lib
# ---------------------------------------------------------------------------

# COMMAND ----------
# MAGIC %pip install --quiet gmt-calculation-lib

# COMMAND ----------
import logging
from pathlib import Path

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("adjust_nb")

# COMMAND ----------
dbutils.widgets.text("folder", "/tmp/gmt_area", "Source folder")  # noqa: F821
dbutils.widgets.text("routes_file", "", "ROUTES file path")  # noqa: F821
dbutils.widgets.text("changes", "[]", "Changes (JSON or path)")  # noqa: F821
dbutils.widgets.text("output_folder", "", "Output folder (empty = scenario-name subfolder)")  # noqa: F821
dbutils.widgets.text("scenario_name", "scenario_a", "Scenario name")  # noqa: F821
dbutils.widgets.text("min_link_trips", "1.0", "Min link trips")  # noqa: F821
dbutils.widgets.dropdown("debug", "false", ["true", "false"], "Debug mode")  # noqa: F821

# COMMAND ----------
folder = Path(dbutils.widgets.get("folder").strip())  # noqa: F821
routes_file = dbutils.widgets.get("routes_file").strip()  # noqa: F821
changes = dbutils.widgets.get("changes").strip()  # noqa: F821
_out = dbutils.widgets.get("output_folder").strip()  # noqa: F821
scenario_name = dbutils.widgets.get("scenario_name").strip()  # noqa: F821
min_link_trips = float(dbutils.widgets.get("min_link_trips"))  # noqa: F821
debug = dbutils.widgets.get("debug") == "true"  # noqa: F821

output_folder = Path(_out) if _out else folder / scenario_name

# Resolve routes_path: explicit widget value or auto-detect from folder
if routes_file:
    routes_path = Path(routes_file)
else:
    from adjust.core.adjust_core import _detect_mode, _discover_area_id

    _area_id = _discover_area_id(folder)
    _mode = _detect_mode(folder, _area_id)
    routes_path = folder / f"{_area_id}-ROUTES-{_mode}.parquet"

logger.info("Adjust pipeline: folder=%s routes=%s output=%s", folder, routes_path, output_folder)

# COMMAND ----------
from adjust.core.adjust_core import run_pipeline  # noqa: E402

run_pipeline(
    folder=folder,
    changes=changes,
    output_folder=output_folder,
    routes_path=routes_path,
    min_link_trips=min_link_trips,
    debug=debug,
    scenario_name=scenario_name or None,
)
