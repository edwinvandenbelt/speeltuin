"""
adjust_core.py — GMT node- and link-adjustment pipeline orchestration logic.

Import and call ``run_pipeline`` from a local runner, notebook, or Lambda handler.
"""

from __future__ import annotations

import copy
import json
import math
import sys
from pathlib import Path
from uuid import uuid4

# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def _discover_area_id(folder: str | Path) -> str:
    """Discover the area UUID from ``{uuid}-NETWORK-{MODE}.parquet`` in *folder*.

    Only "clean" network files are considered — derived variants such as
    ``{uuid}-NETWORK-RAW-CAR.parquet`` or ``{uuid}-NETWORK-SIMPLE-CAR.parquet``
    are excluded by the same hyphen-in-mode check used in :func:`_detect_mode`.
    Falls back to any ``*-NETWORK-*.parquet`` when no clean file exists.

    *folder* may be a local :class:`~pathlib.Path`, a ``file://`` URI, or a
    ``mem://`` URI (in-process memory store).
    """
    folder_str = str(folder)

    if folder_str.startswith("mem://"):
        from gmt_shared.uri import mem_list

        prefix = folder_str.rstrip("/") + "/"
        all_uris = mem_list(prefix)
        stems = [
            u.rsplit("/", 1)[-1].removesuffix(".parquet")
            for u in all_uris
            if u.endswith(".parquet")
        ]
        clean = [s for s in stems if "-NETWORK-" in s and "-" not in s.split("-NETWORK-", 1)[1]]
        if not clean:
            clean = [s for s in stems if "-NETWORK-" in s]
        if not clean:
            raise FileNotFoundError(
                f"No *-NETWORK-*.parquet entry found in memory store under {folder_str!r}\n"
                "Seed the store with mem_put() before calling run_pipeline()."
            )
        return sorted(clean)[0].split("-NETWORK-", 1)[0]

    folder_path = Path(folder_str.removeprefix("file://"))
    matches = [
        p
        for p in sorted(folder_path.glob("*-NETWORK-*.parquet"))
        if "-" not in p.stem.split("-NETWORK-", 1)[1]
    ]
    if not matches:
        matches = sorted(folder_path.glob("*-NETWORK-*.parquet"))
    if not matches:
        raise FileNotFoundError(
            f"No *-NETWORK-*.parquet file found in {folder_path}\n"
            "Check that FOLDER is correct and the preparation pipeline has been "
            "run at least once."
        )
    return matches[0].stem.split("-NETWORK-", 1)[0]


def _detect_mode(folder: str | Path, area_id: str) -> str:
    """Infer transport mode from ``{area_id}-NETWORK-{MODE}.parquet`` in *folder*.

    *folder* may be a local :class:`~pathlib.Path`, a ``file://`` URI, or a
    ``mem://`` URI (in-process memory store).
    """
    prefix = f"{area_id}-NETWORK-"
    folder_str = str(folder)

    if folder_str.startswith("mem://"):
        from gmt_shared.uri import mem_list

        candidate_prefix = folder_str.rstrip("/") + "/" + prefix
        all_uris = mem_list(candidate_prefix)
        stems = [
            u.rsplit("/", 1)[-1].removesuffix(".parquet")
            for u in all_uris
            if u.endswith(".parquet")
        ]
        clean = [s for s in stems if s.startswith(prefix) and "-" not in s[len(prefix) :]]
        if not clean:
            raise FileNotFoundError(
                f"Could not find {prefix}*.parquet in memory store under {folder_str!r}\n"
                "Check that FOLDER and AREA_ID are correct."
            )
        return sorted(clean)[0][len(prefix) :]

    folder_path = Path(folder_str.removeprefix("file://"))
    matches = [
        p for p in folder_path.glob(f"{prefix}*.parquet") if "-" not in p.stem[len(prefix) :]
    ]
    if not matches:
        raise FileNotFoundError(
            f"Could not find {folder_path / (prefix + '*.parquet')}\n"
            "Check that FOLDER and AREA_ID are correct."
        )
    return matches[0].stem[len(prefix) :]


# ---------------------------------------------------------------------------
# Changes loader
# ---------------------------------------------------------------------------


def _routes_mode_from_path(routes_path, fallback: str) -> str:
    """Return the mode token embedded in a routes filename.

    The expected pattern is ``{area_id}-ROUTES-{MODE}.parquet``.  When the
    filename does not match (e.g. a custom name), *fallback* is returned so
    that the caller can use the network mode instead.
    """
    stem = Path(routes_path).stem  # e.g. "abc-123-ROUTES-CAR"
    marker = "-ROUTES-"
    if marker in stem:
        return stem[stem.rfind(marker) + len(marker) :]
    return fallback


def _load_changes(value: str) -> list[dict]:
    """Load adjustment entries from an inline JSON string or a ``.json`` file path."""
    stripped = value.strip()
    p = Path(stripped)
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return json.loads(stripped)


def _split_changes(
    changes: list[dict],
) -> tuple[list[dict], list[dict], list[dict], list[dict], list[dict]]:
    """Split a flat list of change entries into node/zone, link, OD, flow, and
    zone-explode adjustments.

    **Zone-explode adjustment** — has an ``"explodeInto"`` key.  Must also have
    a non-empty ``"zoneId"``, and ``"explodeInto"`` must be an integer >= 2.
    Identified before every other check, since its only required key
    (``explodeInto``) cannot collide with any other change shape.

    **Flow adjustment** — must have ``"linkId"`` (or ``"fromNode"`` + ``"toNode"``)
    **and** a ``"flow"`` key (absolute or delta string).  Identified before the
    link-capacity/speed check.

    **OD adjustment** — must have both ``"fromZoneId"`` and ``"toZoneId"`` keys.
    At least one of ``"tripFraction"`` or ``"motifRatio"`` must be present.

    **Link adjustment** — must have a ``"linkId"`` **or** both ``"fromNode"``
    and ``"toNode"`` fields, and at least one of ``"capacity"`` or ``"speed"``
    (but **not** both).

    All other entries are treated as **node/zone adjustments**.

    Returns
    -------
    (node_adjustments, link_adjustments, od_adjustments, flow_adjustments,
    zone_explode_adjustments)
    """
    node_adjustments: list[dict] = []
    link_adjustments: list[dict] = []
    od_adjustments: list[dict] = []
    flow_adjustments: list[dict] = []
    zone_explode_adjustments: list[dict] = []

    for entry in changes:
        if "explodeInto" in entry:
            zone_id = str(entry.get("zoneId") or "").strip()
            if not zone_id:
                raise ValueError(f"Zone explode entry must have a non-empty 'zoneId': {entry}")
            try:
                n = int(entry["explodeInto"])
            except (TypeError, ValueError) as exc:
                raise ValueError(
                    f"Zone explode entry 'explodeInto' must be an integer: {entry}"
                ) from exc
            if n < 2:
                raise ValueError(f"Zone explode entry 'explodeInto' must be >= 2: {entry}")
            zone_explode_adjustments.append(entry)
            continue

        has_link_id = bool(str(entry.get("linkId") or "").strip())
        has_from_to = bool(str(entry.get("fromNode") or "").strip()) and bool(
            str(entry.get("toNode") or "").strip()
        )
        is_link = has_link_id or has_from_to

        if is_link:
            has_cap = "capacity" in entry
            has_speed = "speed" in entry
            has_flow = "flow" in entry

            if has_flow:
                # Flow injection entry — directed link with a 24-hour flow target
                flow_adjustments.append(entry)
            elif has_cap and has_speed:
                raise ValueError(
                    f"Link adjustment entry may set 'capacity' OR 'speed', not both: {entry}"
                )
            elif not has_cap and not has_speed:
                raise ValueError(
                    f"Link adjustment entry must have 'capacity', 'speed', or 'flow': {entry}"
                )
            else:
                link_adjustments.append(entry)
        elif bool(str(entry.get("fromZoneId") or "").strip()) and bool(
            str(entry.get("toZoneId") or "").strip()
        ):
            if "tripFraction" not in entry and "motifRatio" not in entry:
                raise ValueError(
                    f"OD adjustment entry must have 'tripFraction' and/or 'motifRatio': {entry}"
                )
            od_adjustments.append(entry)
        else:
            node_adjustments.append(entry)

    return node_adjustments, link_adjustments, od_adjustments, flow_adjustments, zone_explode_adjustments


# ---------------------------------------------------------------------------
# Speed → capacity category table
# ---------------------------------------------------------------------------

# Capacity per lane (pae/hr) per legal speed category.
# Matches bidirectional_splitter.domain.network._estimate_capacity.
_SPEED_CAP_TABLE: tuple[tuple[float, int], ...] = (
    (30.0, 1500),
    (50.0, 1700),
    (60.0, 1750),
    (80.0, 1800),
    (100.0, 2100),
)
_SPEED_CAP_DEFAULT: int = 2200  # > 100 km/h


def _remaining_cap(capacity: float | None, props: dict) -> float | None:
    """Return ``capacity − effective peak flow`` or ``None`` when capacity unknown.

    The effective peak is ``max(flowsPerDaypart)``.  When all daypart flows are
    zero but ``flow24hrs`` is positive, ``flow24hrs / 12`` is used as a fallback
    so that remaining capacity is not overstated.
    """
    if capacity is None:
        return None
    dp = props.get("flowsPerDaypart")
    peak = max(dp.values()) if isinstance(dp, dict) and dp else 0.0
    if peak == 0.0:
        flow24 = float(props.get("flow24hrs") or 0.0)
        if flow24 > 0.0:
            peak = flow24 / 12.0
    return capacity - peak


def _capacity_for_speed(speed_kmh: float, lanes: int) -> float:
    """Return estimated capacity (pae/hr) for *speed_kmh* and *lanes*.

    Uses the same category table as ``bidirectional_splitter``.
    """
    n = max(lanes, 1)
    for limit, per_lane in _SPEED_CAP_TABLE:
        if speed_kmh <= limit:
            return float(per_lane * n)
    return float(_SPEED_CAP_DEFAULT * n)


def _parse_value(raw: str, current: float) -> float:
    """Apply an absolute or delta value string to *current*.

    ``"+50"`` / ``"-20"`` → delta; plain numeric → absolute override.
    """
    raw = raw.strip()
    if raw.startswith("+"):
        return current + float(raw[1:])
    if raw.startswith("-"):
        return current - float(raw[1:])
    return float(raw)


# ---------------------------------------------------------------------------
# Link adjustment
# ---------------------------------------------------------------------------


def apply_link_adjustments(
    network_fc: dict,
    link_adjustments: list[dict],
) -> tuple[dict, list[tuple[str, str]]]:
    """Apply link property adjustments to a copy of *network_fc*.

    Each entry in *link_adjustments* must identify a link by ``"linkId"`` or
    by ``"fromNode"`` + ``"toNode"``, and specify either ``"capacity"`` or
    ``"speed"`` (not both).

    When ``"speed"`` is changed the capacity is automatically recalculated from
    the speed-category table (matching ``bidirectional_splitter``):

    ======= ================
    speed   cap/lane (pae/h)
    ≤ 30    1 500
    ≤ 50    1 700
    ≤ 60    1 750
    ≤ 80    1 800
    ≤ 100   2 100
    > 100   2 200
    ======= ================

    If ``"bidirectional": true`` is set on an entry the reverse direction
    (toNode → fromNode) is adjusted with the same values.

    Parameters
    ----------
    network_fc:
        Original network GeoJSON FeatureCollection.
    link_adjustments:
        List of link adjustment dicts (as produced by ``_split_changes``).

    Returns
    -------
    adjusted_fc:
        Deep copy of *network_fc* with the requested link properties updated.
    affected_edges:
        List of ``(fromNode, toNode)`` tuples for every link that was changed
        (used by the pipeline to know which OD pairs to recompute).
    """
    adjusted_fc = copy.deepcopy(network_fc)
    features = adjusted_fc.get("features") or []
    affected_edges: list[tuple[str, str]] = []

    # Build lookup indices
    by_link_id: dict[str, list[int]] = {}
    by_from_to: dict[tuple[str, str], int] = {}

    for i, feat in enumerate(features):
        props = feat.get("properties") or {}
        lid = str(props.get("linkId") or "").strip()
        fn = str(props.get("fromNode") or "").strip()
        tn = str(props.get("toNode") or "").strip()
        if lid:
            by_link_id.setdefault(lid, []).append(i)
        if fn and tn:
            by_from_to[(fn, tn)] = i

    def _adjust_feature(idx: int, entry: dict) -> None:
        props = features[idx].get("properties") or {}
        fn = str(props.get("fromNode") or "").strip()
        tn = str(props.get("toNode") or "").strip()

        if "speed" in entry:
            old_speed = float(props.get("speed") or 0.0)
            new_speed = max(_parse_value(str(entry["speed"]), old_speed), 0.0)
            lanes = int(props.get("lanes") or 1)
            new_cap = _capacity_for_speed(new_speed, lanes) if new_speed > 0.0 else 0.0
            features[idx]["properties"]["speed"] = new_speed
            features[idx]["properties"]["capacity"] = new_cap
        else:
            old_cap = float(props.get("capacity") or 0.0)
            new_cap = max(_parse_value(str(entry["capacity"]), old_cap), 0.0)
            features[idx]["properties"]["capacity"] = new_cap

        features[idx]["properties"]["remainingCap"] = _remaining_cap(new_cap, props)

        affected_edges.append((fn, tn))

    for entry in link_adjustments:
        link_id = str(entry.get("linkId") or "").strip()
        from_n = str(entry.get("fromNode") or "").strip()
        to_n = str(entry.get("toNode") or "").strip()
        bidir = bool(entry.get("bidirectional", False))

        matched: list[int] = []

        if link_id:
            matched = by_link_id.get(link_id, [])
            if not matched:
                raise ValueError(f"Link adjustment: linkId {link_id!r} not found in network.")
        elif from_n and to_n:
            idx = by_from_to.get((from_n, to_n))
            if idx is None:
                raise ValueError(f"Link adjustment: edge ({from_n} → {to_n}) not found in network.")
            matched = [idx]
        else:
            raise ValueError(
                f"Link adjustment entry has no valid linkId or fromNode/toNode: {entry}"
            )

        for idx in matched:
            _adjust_feature(idx, entry)

        # Bidirectional: also adjust the reverse direction(s)
        if bidir:
            if link_id:
                # For linkId entries, find reverse links from affected_edges
                reversed_pairs = [(tn, fn) for fn, tn in affected_edges[-len(matched) :]]
                for rfn, rtn in reversed_pairs:
                    rev_idx = by_from_to.get((rfn, rtn))
                    if rev_idx is not None:
                        _adjust_feature(rev_idx, entry)
            elif from_n and to_n:
                rev_idx = by_from_to.get((to_n, from_n))
                if rev_idx is not None:
                    _adjust_feature(rev_idx, entry)

    return adjusted_fc, affected_edges


# ---------------------------------------------------------------------------
# Zone explode (split a zone into N sub-zones)
#
# Pure-Python, stdlib-only geometry — deliberately self-contained in
# ``adjust`` rather than depending on ``gmt_zone_core``'s ``zone_refiner``
# (which performs the same 2-way, road-based ring split as a one-off,
# offline step during area preparation and has no notion of ROUTES/OD
# pairs).  The helpers below generalize that same chord-cut algorithm to an
# arbitrary number of sub-zones and additionally wire the result back into
# the adjust pipeline's node/zone-adjustment machinery.
# ---------------------------------------------------------------------------

_ZONE_M_PER_DEG_LAT = 111_320.0  # metres per degree latitude (approximately)

#: Zone properties copied unchanged rather than scaled by road-length fraction.
_ZONE_EXPLODE_NON_SCALED_PROPS = frozenset(
    {
        "zoneId",
        "parentZoneId",
        "zoneClass",
        "zoneClassCode",
        "zoneName",
        "municipalityCode",
        "municipalityName",
        "centroidLon",
        "centroidLat",
        "fromNodeProportions",
        "toNodeProportions",
        "gid",
        "mode",
    }
)


def _zone_seg_length_m(ax: float, ay: float, bx: float, by: float) -> float:
    """Approximate WGS-84 distance in metres using a flat-earth model."""
    dlat = (by - ay) * _ZONE_M_PER_DEG_LAT
    mid_lat = (ay + by) / 2.0
    dlon = (bx - ax) * _ZONE_M_PER_DEG_LAT * math.cos(math.radians(mid_lat))
    return math.sqrt(dlat * dlat + dlon * dlon)


def _zone_ring_bbox_size(ring: list) -> float:
    """Return the larger of the ring's bounding-box width and height in degrees."""
    lons = [p[0] for p in ring]
    lats = [p[1] for p in ring]
    return max(max(lons) - min(lons), max(lats) - min(lats))


def _zone_segment_intersect_t(
    ax: float, ay: float, bx: float, by: float, cx: float, cy: float, dx: float, dy: float
) -> float | None:
    """Return parametric *t* of the intersection of segment A→B with C→D, or ``None``."""
    denom = (bx - ax) * (dy - cy) - (by - ay) * (dx - cx)
    if abs(denom) < 1e-15:
        return None
    t = ((cx - ax) * (dy - cy) - (cy - ay) * (dx - cx)) / denom
    u = ((cx - ax) * (by - ay) - (cy - ay) * (bx - ax)) / denom
    if 0.0 <= t <= 1.0 and 0.0 <= u <= 1.0:
        return t
    return None


def _zone_intersections_with_ring(
    ax: float, ay: float, bx: float, by: float, ring: list
) -> list[tuple[float, float, float, int]]:
    """Return sorted, deduplicated ``(t, ix, iy, edge_k)`` for A→B vs. *ring*."""
    hits: list[tuple[float, float, float, int]] = []
    n = len(ring)
    for k in range(n - 1):
        cx, cy = ring[k][0], ring[k][1]
        dx, dy = ring[k + 1][0], ring[k + 1][1]
        t = _zone_segment_intersect_t(ax, ay, bx, by, cx, cy, dx, dy)
        if t is not None:
            ix = ax + t * (bx - ax)
            iy = ay + t * (by - ay)
            hits.append((t, ix, iy, k))
    hits.sort(key=lambda h: h[0])
    deduped: list[tuple[float, float, float, int]] = []
    for hit in hits:
        if deduped and abs(hit[0] - deduped[-1][0]) < 1e-10:
            continue
        deduped.append(hit)
    return deduped


def _zone_point_in_polygon(px: float, py: float, ring: list) -> bool:
    """Ray-casting point-in-polygon test for a closed GeoJSON ring."""
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > py) != (yj > py):
            if px < (xj - xi) * (py - yi) / (yj - yi) + xi:
                inside = not inside
        j = i
    return inside


def _zone_clip_length_in_ring(coords: list, ring: list) -> float:
    """Return the total length in metres of *coords* clipped to *ring*."""
    if len(coords) < 2:
        return 0.0
    total = 0.0
    cur_inside = _zone_point_in_polygon(coords[0][0], coords[0][1], ring)
    for seg_i in range(len(coords) - 1):
        ax, ay = coords[seg_i][0], coords[seg_i][1]
        bx, by = coords[seg_i + 1][0], coords[seg_i + 1][1]
        hits = _zone_intersections_with_ring(ax, ay, bx, by, ring)
        last_x, last_y = ax, ay
        for _t, ix, iy, _ek in hits:
            if cur_inside:
                total += _zone_seg_length_m(last_x, last_y, ix, iy)
            last_x, last_y = ix, iy
            cur_inside = not cur_inside
        if cur_inside:
            total += _zone_seg_length_m(last_x, last_y, bx, by)
    return total


def _zone_find_split_hits(ring: list, link_coords: list) -> tuple[tuple, tuple] | None:
    """Find two ring-boundary crossings for splitting *ring* along *link_coords*.

    Extends the link's direction vector far beyond the ring so the extended
    line is guaranteed to cross the boundary.  Returns ``(hit1, hit2)`` — each
    ``(t, ix, iy, edge_k)`` — or ``None`` when fewer than two crossings exist.
    """
    if len(link_coords) < 2:
        return None
    ax, ay = link_coords[0][0], link_coords[0][1]
    bx, by = link_coords[-1][0], link_coords[-1][1]
    dx = bx - ax
    dy = by - ay
    seg_len_deg = math.sqrt(dx * dx + dy * dy)
    if seg_len_deg < 1e-10:
        return None

    dx /= seg_len_deg
    dy /= seg_len_deg
    mx = (ax + bx) / 2.0
    my = (ay + by) / 2.0

    bbox_size = _zone_ring_bbox_size(ring)
    k = max(bbox_size * 20.0, 1e-4)

    x0, y0 = mx - k * dx, my - k * dy
    x1, y1 = mx + k * dx, my + k * dy

    hits = _zone_intersections_with_ring(x0, y0, x1, y1, ring)
    if len(hits) < 2:
        return None
    return (hits[0], hits[-1])


def _zone_split_ring_by_chord(
    ring: list, hit1: tuple, hit2: tuple
) -> tuple[list, list] | tuple[None, None]:
    """Split *ring* at two boundary intersection points into two sub-rings."""
    _, x1, y1, e1 = hit1
    _, x2, y2, e2 = hit2

    if e1 > e2 or (e1 == e2 and hit1[0] > hit2[0]):
        x1, y1, e1, x2, y2, e2 = x2, y2, e2, x1, y1, e1

    if e1 == e2:
        return None, None

    n = len(ring) - 1

    ring_a: list = [[x1, y1]]
    for i in range(e1 + 1, e2 + 1):
        ring_a.append(list(ring[i]))
    ring_a.append([x2, y2])
    ring_a.append([x1, y1])

    ring_b: list = [[x2, y2]]
    for i in range(e2 + 1, n):
        ring_b.append(list(ring[i]))
    for i in range(0, e1 + 1):
        ring_b.append(list(ring[i]))
    ring_b.append([x1, y1])
    ring_b.append([x2, y2])

    if len(ring_a) < 4 or len(ring_b) < 4:
        return None, None

    return ring_a, ring_b


def _zone_ring_area(ring: list) -> float:
    """Return the absolute (shoelace) area of a closed ring, in degree² units."""
    n = len(ring)
    if n < 4:
        return 0.0
    signed_area = 0.0
    for i in range(n - 1):
        xi, yi = ring[i][0], ring[i][1]
        xn, yn = ring[i + 1][0], ring[i + 1][1]
        signed_area += xi * yn - xn * yi
    return abs(signed_area) / 2.0


def _explode_ring_n_way(ring: list, link_coords_list: list[list], n: int) -> list[list] | None:
    """Split *ring* into *n* sub-rings by repeatedly cutting along dominant roads.

    At each of the ``n - 1`` iterations, the current piece with the greatest
    total clipped road length that still yields a usable, non-degenerate split
    is cut in two along its own longest contained road (extended to the piece
    boundary) — the same chord-cut method ``zone_refiner`` uses for a single
    2-way split.  A candidate split is rejected as degenerate when either
    resulting sub-ring's area is below ``1e-6`` of the piece being cut — this
    specifically guards against re-selecting a road that lies exactly on a
    boundary created by an earlier cut (collinear with that edge), which would
    otherwise "succeed" with a zero-width sliver ring.

    Returns ``None`` when not even one cut can be made; otherwise returns
    however many pieces could actually be produced, which may be fewer than
    *n* when the zone runs out of usable road geometry partway through — the
    caller decides whether that shortfall is acceptable.
    """
    pieces: list[list] = [ring]
    for _ in range(n - 1):
        best_idx: int | None = None
        best_len = -1.0
        best_split: tuple[list, list] | None = None
        for i, piece in enumerate(pieces):
            candidates = sorted(
                ((_zone_clip_length_in_ring(coords, piece), coords) for coords in link_coords_list),
                key=lambda c: c[0],
                reverse=True,
            )
            total_len = sum(clen for clen, _ in candidates if clen > 0.0)
            if total_len <= best_len:
                continue
            piece_area = _zone_ring_area(piece)
            min_area = piece_area * 1e-6
            split: tuple[list, list] | None = None
            for clen, coords in candidates:
                if clen <= 0.0:
                    break
                hits = _zone_find_split_hits(piece, coords)
                if hits is None:
                    continue
                ring_a, ring_b = _zone_split_ring_by_chord(piece, hits[0], hits[1])
                if ring_a is None:
                    continue
                if _zone_ring_area(ring_a) < min_area or _zone_ring_area(ring_b) < min_area:
                    continue  # degenerate sliver — try the next candidate road
                split = (ring_a, ring_b)
                break
            if split is not None:
                best_idx, best_len, best_split = i, total_len, split
        if best_idx is None:
            break
        pieces.pop(best_idx)
        pieces.append(best_split[0])
        pieces.append(best_split[1])
    return pieces if len(pieces) > 1 else None


def _scale_zone_properties(
    props: dict, fraction: float, new_zone_id: str, parent_zone_id: str
) -> dict:
    """Return a copy of *props* for one exploded sub-zone.

    Mirrors ``zone_refiner``'s convention: numeric properties (``production``,
    ``attraction``, CBS demographic counts, ``originalProduction``/
    ``originalAttraction`` when present, ...) are scaled by *fraction*;
    identity/classification fields in ``_ZONE_EXPLODE_NON_SCALED_PROPS`` are
    copied unchanged; ``fromNodeProportions``/``toNodeProportions`` are reset
    to ``{}`` (stale after a geometry change — recomputed downstream by
    ``network_zone_joiner``); ``gid`` is cleared (no Databricks row exists for
    a derived zone).
    """
    out: dict = {}
    for key, val in props.items():
        if key == "zoneId":
            out["zoneId"] = new_zone_id
        elif key in ("fromNodeProportions", "toNodeProportions"):
            out[key] = {}
        elif key == "gid":
            out["gid"] = None
        elif key in _ZONE_EXPLODE_NON_SCALED_PROPS:
            out[key] = val
        elif isinstance(val, (int, float)) and not isinstance(val, bool):
            out[key] = val * fraction
        else:
            out[key] = val
    out["parentZoneId"] = parent_zone_id
    return out


def _largest_remainder(total: int, fractions: list[float]) -> list[int]:
    """Split integer *total* over *fractions* so the integer shares sum to *total*."""
    raw = [total * f for f in fractions]
    shares = [math.floor(r) for r in raw]
    order = sorted(range(len(raw)), key=lambda i: raw[i] - shares[i], reverse=True)
    for i in order[: total - sum(shares)]:
        shares[i] += 1
    return shares


def _integer_shares(props: dict, fractions: list[float]) -> dict[str, list[int]]:
    """Return whole-number per-sub-zone values for count-like zone properties.

    ``production``/``attraction`` are always split as whole numbers (rounded
    parent total, largest-remainder method so the children add up to it);
    any other numeric property that is already an ``int`` on the parent (CBS
    counts) is split the same way.  Float properties (ratios, ...) are left to
    ``_scale_zone_properties``'s plain scaling.
    """
    out: dict[str, list[int]] = {}
    for key, val in props.items():
        if key in _ZONE_EXPLODE_NON_SCALED_PROPS or isinstance(val, bool):
            continue
        if key in ("production", "attraction") and isinstance(val, (int, float)):
            out[key] = _largest_remainder(round(val), fractions)
        elif isinstance(val, int):
            out[key] = _largest_remainder(val, fractions)
    return out


def _sub_zone_feedlinks(
    parent_props: dict,
    children: list[dict],
    feedlinks_fc: dict,
    node_positions: dict,
    all_node_ids: set,
    mode: str,
    next_fid: int,
) -> tuple[list[dict], int]:
    """Build the feedlinks of an exploded zone's sub-zones.

    Every feedlink of the parent zone is handed to exactly one sub-zone: the
    one containing its network node (the nearest sub-zone when the node lies
    outside all of them).  Zone end and ``zoneId`` are rewritten to the
    sub-zone, the geometry is redrawn from the sub-zone centroid, and the
    capacity becomes the sub-zone's own production (production feedlinks) or
    attraction (attraction feedlinks), shared pro rata over that sub-zone's
    feedlinks in that direction.

    A sub-zone left without a feedlink in a direction gets one from
    ``build_feedlinks``'s offline fallback (highest-flow node among the
    nearest nodes to its centroid), so every sub-zone is attached to real
    network nodes in both directions.

    Returns ``(feedlink features, next free feedlinkId)``.
    """
    from gmt_network_core.feedlink_fetcher.core.feedlink_fetcher_core import build_feedlinks
    from shapely.geometry import Point, shape

    parent_id = str(parent_props.get("zoneId") or "")
    gid = parent_props.get("gid")
    parent_nodes = {parent_id}
    if isinstance(gid, (int, float)) and not isinstance(gid, bool):
        parent_nodes |= {str(gid), str(int(gid))}
    # Node ids may be ints in the network; feedlinks carry them as strings.
    positions = {str(k): v for k, v in node_positions.items()}
    shapes = [shape(c["geometry"]) for c in children]

    def child_for(lon: float, lat: float) -> int:
        pt = Point(lon, lat)
        for i, geom in enumerate(shapes):
            if geom.covers(pt):
                return i
        return min(range(len(shapes)), key=lambda i: shapes[i].distance(pt))

    # (child index, is_production) -> [(network node, original capacity, props)]
    assigned: dict[tuple[int, bool], list[tuple[str, float, dict]]] = {}
    for feat in feedlinks_fc.get("features") or []:
        props = feat.get("properties") or {}
        if str(props.get("zoneId") or "") != parent_id:
            continue
        from_node = str(props.get("fromNode") or "")
        to_node = str(props.get("toNode") or "")
        if to_node in positions and (from_node not in positions or from_node in parent_nodes):
            net_node, is_production = to_node, True
        elif from_node in positions and (to_node not in positions or to_node in parent_nodes):
            net_node, is_production = from_node, False
        else:
            continue  # not attached to the network — useless for the sub-zones
        lon, lat = positions[net_node]
        key = (child_for(lon, lat), is_production)
        assigned.setdefault(key, []).append((net_node, float(props.get("capacity") or 0.0), props))

    out: list[dict] = []
    for ci, child in enumerate(children):
        cprops = child["properties"]
        child_id = str(cprops["zoneId"])
        clon, clat = float(cprops["centroidLon"]), float(cprops["centroidLat"])
        missing = [p for p in (True, False) if (ci, p) not in assigned]
        if missing:
            # build_feedlinks skips zones without an integer gid; mint a
            # throwaway negative one (never stored on the sub-zone).
            fallback_gid = -(abs(hash(child_id)) % 10**9) - 1
            fallback = build_feedlinks(
                {"features": [{**child, "properties": {**cprops, "gid": fallback_gid}}]},
                node_positions,
                all_node_ids,
                [],
                mode,
            )
            for f in fallback.get("features") or []:
                fprops = f["properties"]
                is_production = str(fprops["fromNode"]) == str(fallback_gid)
                if is_production not in missing:
                    continue
                net_node = str(fprops["toNode"] if is_production else fprops["fromNode"])
                if net_node not in positions:
                    continue
                assigned.setdefault((ci, is_production), []).append((net_node, 0.0, fprops))

        for is_production in (True, False):
            links = assigned.get((ci, is_production)) or []
            total = float(cprops.get("production" if is_production else "attraction") or 0.0)
            orig_sum = sum(cap for _n, cap, _p in links)
            for net_node, cap, props in links:
                share = cap / orig_sum if orig_sum > 0 else 1.0 / len(links)
                lon, lat = positions[net_node]
                coords = [[clon, clat], [lon, lat]]
                if not is_production:
                    coords.reverse()
                out.append(
                    {
                        "type": "Feature",
                        "geometry": {"type": "LineString", "coordinates": coords},
                        "properties": {
                            **props,
                            "feedlinkId": next_fid,
                            "reverseLinkIds": [],
                            "zoneId": child_id,
                            "fromNode": child_id if is_production else net_node,
                            "toNode": net_node if is_production else child_id,
                            "length": round(_zone_seg_length_m(clon, clat, lon, lat), 1),
                            "capacity": total * share,
                            "mode": props.get("mode") or mode,
                        },
                    }
                )
                next_fid += 1
    return out, next_fid


def apply_zone_explosions(
    zones_fc: dict,
    network_fc: dict,
    zone_explode_adjustments: list[dict],
    feedlinks_fc: dict,
    mode: str,
    buildings_fc: dict | None = None,
) -> tuple[dict, dict, list[dict]]:
    """Split one or more zones into N smaller sub-zones.

    Each entry in *zone_explode_adjustments* must have ``"zoneId"`` (the zone
    to split) and ``"explodeInto"`` (the number of sub-zones, >= 2) — shape
    already validated by ``_split_changes``.

    **Methodiek** — the zone is cut into street blocks along the network's
    roads and adjacent blocks are merged into *n* sub-zones (delegated to
    ``gmt_zone_core.zone_splitter.core.zone_splitter_core.split_zone_by_roads``),
    so sub-zone boundaries follow the actual road geometry.  Blocks are
    balanced, and numeric zone properties (``production``, ``attraction``, CBS
    demographic counts, ...) distributed, by registered building floor area
    (m²) when *buildings_fc* is provided (the prepare pipeline's
    ``{area_id}-BUILDINGS.parquet`` output) and the zone has buildings; by
    area otherwise.  ``production``/``attraction`` and integer counts are
    split into whole numbers that add up to the parent's (rounded) totals.

    Sub-zone ``i`` (1-based) gets ``zoneId`` ``"<parent zoneId>-<i>"`` —
    deterministic, so every mode of a MIXED run produces the same ids —
    ``zoneName`` ``"<parent zoneName> (<i>)"`` and a ``parentZoneId``
    pointing at the original zone. ``fromNodeProportions``/
    ``toNodeProportions`` are recomputed by a scoped call to
    ``gmt_network_core.network_zone_joiner.core.network_zone_joiner_core.join_zones_to_network``
    (restricted to the new sub-zone features, so no other zone is touched).
    The feedlinks are built by ``_sub_zone_feedlinks``: each of the original
    zone's feedlinks moves to the sub-zone containing its network node, and a
    sub-zone still lacking a production or attraction feedlink gets one from
    ``gmt_network_core.feedlink_fetcher.core.feedlink_fetcher_core.build_feedlinks``'s
    offline centroid-to-nearest-node method.  The original zone's own
    feedlink entries are removed from *feedlinks_fc* (it no longer exists).

    A ``BOUNDARY`` zone cannot be exploded — it has no demographic/production
    data of its own (it carries the flow of the network link it represents at
    the edge of the study area) and splitting its geometry would not be
    meaningful.

    Parameters
    ----------
    zones_fc:
        Original ZONE GeoJSON FeatureCollection.
    network_fc:
        NETWORK GeoJSON FeatureCollection — source of the split lines and of
        the feedlink/proportion recomputation.
    zone_explode_adjustments:
        List of ``{"zoneId": ..., "explodeInto": N}`` entries.
    feedlinks_fc:
        Original FEEDLINK GeoJSON FeatureCollection — used to reuse/partition
        each exploded zone's existing feedlinks among its new sub-zones.
    mode:
        Transport mode (e.g. ``"CAR"``) — only used by the offline
        centroid-fallback feedlink method.
    buildings_fc:
        Optional area-wide buildings GeoJSON FeatureCollection. When given,
        drives building-m²-based weighting instead of area weighting (see
        above).

    Returns
    -------
    (zones_fc_out, feedlinks_fc_out, node_adjustments)
        *zones_fc_out* — a copy of *zones_fc* with each exploded zone replaced
        by its sub-zones (with recomputed ``fromNodeProportions``/
        ``toNodeProportions``).
        *feedlinks_fc_out* — a copy of *feedlinks_fc* with each exploded
        zone's old feedlinks removed and its new sub-zones' feedlinks added.
        *node_adjustments* — synthetic node/zone-adjustment entries (one
        absolute production+attraction entry per new sub-zone, plus a
        ``production=0``/``attraction=0`` tombstone for the original zone) to
        feed into ``build_od_matrix`` so that OD pairs are generated for the
        new zones, and the original zone's existing pairs — as either origin
        or destination — are evaporated.
    """
    zone_features: list[dict] = list(zones_fc.get("features") or [])
    by_zone_id: dict[str, int] = {}
    for i, feat in enumerate(zone_features):
        zid = str((feat.get("properties") or {}).get("zoneId") or "")
        if zid:
            by_zone_id[zid] = i

    removed_indices: set[int] = set()
    removed_zone_ids: set[str] = set()
    new_features: list[dict] = []
    node_adjustments: list[dict] = []
    # (parent properties, child zone ids) per exploded zone.
    explosions: list[tuple[dict, list[str]]] = []

    for entry in zone_explode_adjustments:
        zone_id = str(entry.get("zoneId") or "").strip()
        n = int(entry["explodeInto"])

        idx = by_zone_id.get(zone_id)
        if idx is None:
            raise ValueError(f"Zone explode: zoneId {zone_id!r} not found in zones.")

        feat = zone_features[idx]
        props = feat.get("properties") or {}
        zone_class = str(props.get("zoneClass") or "")
        if zone_class == "BOUNDARY":
            raise ValueError(
                f"Zone explode: zoneId {zone_id!r} is a BOUNDARY zone and cannot be exploded."
            )

        if (feat.get("geometry") or {}).get("type") not in ("Polygon", "MultiPolygon"):
            raise ValueError(f"Zone explode: zoneId {zone_id!r} has no valid polygon geometry.")

        from gmt_zone_core.zone_splitter.core.zone_splitter_core import split_zone_by_roads
        from shapely.geometry import shape

        pieces, fractions, split_stats = split_zone_by_roads(feat, network_fc, buildings_fc, n)
        if buildings_fc is not None:
            print(
                f"       zone {zone_id}: {split_stats['totalBuildingSqm']:.0f} m2 registered "
                f"buildings / {n} -> target {split_stats['targetSqmPerZone']:.0f} m2/zone"
            )

        if pieces is None:
            raise ValueError(
                f"Zone explode: zoneId {zone_id!r} could not be split "
                "(no usable road geometry inside the zone)."
            )
        if len(pieces) < n:
            raise ValueError(
                f"Zone explode: zoneId {zone_id!r} could only be split into {len(pieces)} of "
                f"the requested {n} part(s) — not enough distinct road geometry inside the zone."
            )

        parent_name = str(props.get("zoneName") or zone_id)
        int_shares = _integer_shares(props, fractions)
        child_ids: list[str] = []
        for i, (piece, fraction) in enumerate(zip(pieces, fractions), start=1):
            new_id = f"{zone_id}-{i}"
            child_ids.append(new_id)
            piece_shape = shape(piece)
            centroid = piece_shape.centroid
            if not piece_shape.contains(centroid):
                centroid = piece_shape.representative_point()
            new_props = _scale_zone_properties(props, fraction, new_id, zone_id)
            for key, shares in int_shares.items():
                new_props[key] = shares[i - 1]
            new_props["zoneName"] = f"{parent_name} ({i})"
            new_props["centroidLon"] = centroid.x
            new_props["centroidLat"] = centroid.y
            new_features.append({"type": "Feature", "geometry": piece, "properties": new_props})
            node_adjustments.append(
                {
                    "zoneId": new_id,
                    "production": str(new_props.get("production") or 0),
                    "attraction": str(new_props.get("attraction") or 0),
                }
            )
        explosions.append((props, child_ids))

        # Tombstone the original zone: zeroing both production and attraction
        # makes build_od_matrix emit empty-route features for every existing
        # pair that had this zone as origin OR destination, evaporating them
        # (see route_explorer_core.build_od_matrix's zone-tombstone handling).
        node_adjustments.append({"zoneId": zone_id, "production": "0", "attraction": "0"})
        removed_indices.add(idx)
        removed_zone_ids.add(zone_id)

    remaining_features = [feat for i, feat in enumerate(zone_features) if i not in removed_indices]
    zones_fc_out = {**zones_fc, "features": [*remaining_features, *new_features]}

    # ------------------------------------------------------------------
    # Recompute feedlinks/proportions for the new sub-zones and drop the
    # exploded zones' old feedlinks.
    # ------------------------------------------------------------------
    new_feedlink_features: list[dict] = []
    if new_features:
        from gmt_network_core.feedlink_fetcher.core.feedlink_fetcher_core import (
            parse_network_geojson,
        )

        node_positions, all_node_ids = parse_network_geojson(network_fc)
        children_by_id = {f["properties"]["zoneId"]: f for f in new_features}
        existing_fids = [
            (f.get("properties") or {}).get("feedlinkId")
            for f in feedlinks_fc.get("features") or []
        ]
        next_fid = (
            max(
                (
                    int(fid)
                    for fid in existing_fids
                    if isinstance(fid, (int, float)) and not isinstance(fid, bool)
                ),
                default=0,
            )
            + 1
        )
        for parent_props, child_ids in explosions:
            fl_feats, next_fid = _sub_zone_feedlinks(
                parent_props,
                [children_by_id[cid] for cid in child_ids],
                feedlinks_fc,
                node_positions,
                all_node_ids,
                mode,
                next_fid,
            )
            new_feedlink_features.extend(fl_feats)

        # fromNodeProportions/toNodeProportions follow the sub-zones' own
        # feedlinks (capacity share per network node).  Not derived via
        # join_zones_to_network: on road-following polygons with many
        # vertices its pure-Python clipping takes minutes per zone, and its
        # node ids are clipped-network pseudo nodes anyway.
        for fl in new_feedlink_features:
            fprops = fl["properties"]
            child = children_by_id[fprops["zoneId"]]["properties"]
            if fprops["fromNode"] == fprops["zoneId"]:
                key, node = "fromNodeProportions", str(fprops["toNode"])
            else:
                key, node = "toNodeProportions", str(fprops["fromNode"])
            child[key][node] = child[key].get(node, 0.0) + float(fprops["capacity"] or 0.0)
        for child_feat in new_features:
            cprops = child_feat["properties"]
            for key in ("fromNodeProportions", "toNodeProportions"):
                weights = cprops[key]
                total = sum(weights.values())
                cprops[key] = {
                    node: (w / total if total > 0 else 1.0 / len(weights))
                    for node, w in weights.items()
                }

    feedlinks_fc_out = {
        **feedlinks_fc,
        "features": [
            f
            for f in feedlinks_fc.get("features") or []
            if str((f.get("properties") or {}).get("zoneId") or "") not in removed_zone_ids
        ]
        + new_feedlink_features,
    }

    return zones_fc_out, feedlinks_fc_out, node_adjustments


# ---------------------------------------------------------------------------
# Report printer
# ---------------------------------------------------------------------------


def _print_flow_report(report: list[dict]) -> None:
    """Print a formatted table of flow delta entries, sorted by |delta| descending."""
    print()
    if not report:
        print("  No flow changes.")
        return

    w_link = max(len(str(r["linkId"])) for r in report)
    w_link = max(w_link, 6)

    header = f"  {'linkId':<{w_link}}  {'flow_before':>12}  {'flow_after':>10}  {'delta':>10}"
    sep = "  " + "-" * (len(header) - 2)
    print(f"  {len(report)} link(s) with flow changes:")
    print(sep)
    print(header)
    print(sep)
    for r in sorted(report, key=lambda x: abs(x["flow_delta"]), reverse=True):
        print(
            f"  {r['linkId']!s:<{w_link}}"
            f"  {r['flow_before']:>12.4f}"
            f"  {r['flow_after']:>10.4f}"
            f"  {r['flow_delta']:>+10.4f}"
        )
    print(sep)
    print()


# ---------------------------------------------------------------------------
# ROUTES helpers
# ---------------------------------------------------------------------------


def _find_affected_link_ids(
    network_fc: dict,
    affected_edges: list[tuple[str, str]],
) -> set[str]:
    """Return the set of ``linkId`` values for the given ``(fromNode, toNode)`` edges."""
    edge_set = set(affected_edges)
    link_ids: set[str] = set()
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        fn = str(props.get("fromNode") or "").strip()
        tn = str(props.get("toNode") or "").strip()
        lid = str(props.get("linkId") or "").strip()
        if (fn, tn) in edge_set and lid:
            link_ids.add(lid)
    return link_ids


def _find_pairs_using_links(
    routes_fc: dict,
    affected_link_ids: set[str],
) -> list[dict]:
    """Return pair dicts for every OD feature whose route(s) use an affected link.

    Each returned dict has keys ``fromId``, ``toId``, ``fromType``, ``toType``,
    ``tripFraction`` — suitable as input to ``recompute_routes_for_pairs``.
    """
    pairs: list[dict] = []
    for feat in routes_fc.get("features", []):
        props = feat.get("properties") or {}
        routes = props.get("routes") or []
        uses_affected = any(
            lid in affected_link_ids for route in routes for lid in (route.get("linkPath") or [])
        )
        if uses_affected:
            pairs.append(
                {
                    "fromId": str(props.get("fromZoneId") or ""),
                    "toId": str(props.get("toZoneId") or ""),
                    "fromType": str(props.get("fromType") or "zone"),
                    "toType": str(props.get("toType") or "zone"),
                    "tripFraction": float(props.get("tripFraction") or 0.0),
                }
            )
    return pairs


def _get_closed_link_ids(network_fc: dict, affected_link_ids: set[str]) -> set[str]:
    """Return the subset of *affected_link_ids* whose ``capacity`` is 0 in *network_fc*.

    A link is considered closed when its ``properties.capacity`` equals ``0.0``
    after link adjustments have been applied.
    """
    closed: set[str] = set()
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        lid = str(props.get("linkId") or "")
        if lid in affected_link_ids and float(props.get("capacity") or 0.0) == 0.0:
            closed.add(lid)
    return closed


def _redistribute_routes(
    routes_fc: dict,
    affected_link_ids: set[str],
    closed_link_ids: set[str],
    zones_fc: dict,
    min_trips_per_pair: float = 2.0,
) -> tuple[dict, list[dict]]:
    """Attempt local redistribution of routes for OD pairs affected by link closures.

    For each OD pair that uses at least one link in *affected_link_ids*:

    * If it uses **only non-closed** adjusted links → send to ``pairs_for_recompute``
      (speed/partial-capacity change, needs full re-routing).
    * If it uses **closed** links (capacity == 0):

      * **Evaporation**: if ``tripFraction × production < min_trips_per_pair``
        → include in *redistributed_fc* with ``routes=[]`` (pair is removed from
        the network; ``tripFraction`` is left unchanged per convention).
      * **Local redistribution**: if ``remaining_routes >= 2``,
        or ``N == 2`` and ``remaining_routes == 1`` → redistribute the blocked
        trips proportionally over the remaining routes (blocked routes are removed).
        ``sum(route.trips)`` equals the original ``tripFraction`` after redistribution.
      * **Needs re-routing**: otherwise → send to ``pairs_for_recompute``.

    OD pairs that do not use any affected link are not included in either output.

    Parameters
    ----------
    routes_fc:
        Base ROUTES GeoJSON FeatureCollection.
    affected_link_ids:
        Set of all link IDs that were modified.
    closed_link_ids:
        Subset of *affected_link_ids* whose capacity was set to 0.
    zones_fc:
        ZONE GeoJSON FeatureCollection used to look up zone production.
    min_trips_per_pair:
        Minimum absolute trips (``tripFraction × production``) below which an OD
        pair is considered evaporated.

    Returns
    -------
    (redistributed_fc, pairs_for_recompute)
        *redistributed_fc* contains features whose routes were locally resolved
        (redistribution or evaporation).  *pairs_for_recompute* is a list of pair
        dicts suitable for ``recompute_routes_for_pairs``.
    """
    # Build zone production lookup: zoneId → production
    zone_production: dict[str, float] = {}
    for feat in zones_fc.get("features", []):
        props = feat.get("properties") or {}
        zid = str(props.get("zoneId") or "")
        if zid:
            zone_production[zid] = float(props.get("production") or 0.0)

    redistributed_features: list[dict] = []
    pairs_for_recompute: list[dict] = []

    for feat in routes_fc.get("features", []):
        props = feat.get("properties") or {}
        routes: list[dict] = list(props.get("routes") or [])

        # Collect all link IDs used by this OD pair
        all_link_ids: set[str] = {lid for route in routes for lid in (route.get("linkPath") or [])}

        uses_affected = bool(all_link_ids & affected_link_ids)
        if not uses_affected:
            continue  # not affected — pass through unchanged

        uses_closed = bool(all_link_ids & closed_link_ids)

        from_id = str(props.get("fromZoneId") or "")
        to_id = str(props.get("toZoneId") or "")
        from_type = str(props.get("fromType") or "zone")
        to_type = str(props.get("toType") or "zone")
        trip_frac = float(props.get("tripFraction") or 0.0)

        pair_dict = {
            "fromId": from_id,
            "toId": to_id,
            "fromType": from_type,
            "toType": to_type,
            "tripFraction": trip_frac,
        }

        if not uses_closed:
            # Only non-closed link changes (speed/capacity tweak) → full re-route
            pairs_for_recompute.append(pair_dict)
            continue

        # Determine production for evaporation check.
        # Node-type origins are not zone-production-scaled (factor = 1.0).
        if from_type == "zone":
            production = zone_production.get(from_id, 0.0)
        else:
            production = 1.0

        total_trips = trip_frac * production

        # Evaporation: absolute trips below threshold
        if total_trips < min_trips_per_pair:
            evap_feat = {
                "type": "Feature",
                "geometry": feat.get("geometry"),
                "properties": {
                    **props,
                    "routes": [],
                },
            }
            redistributed_features.append(evap_feat)
            continue

        # Classify routes as blocked / remaining
        blocked: list[dict] = []
        remaining: list[dict] = []
        for route in routes:
            link_path = route.get("linkPath") or []
            if any(lid in closed_link_ids for lid in link_path):
                blocked.append(route)
            else:
                remaining.append(route)

        n = len(routes)
        n_remaining = len(remaining)

        # Can we redistribute locally?
        can_redistribute = (n_remaining >= 2) or (n == 2 and n_remaining == 1)

        if not can_redistribute:
            pairs_for_recompute.append(pair_dict)
            continue

        # Proportional redistribution: blocked trips spread over remaining routes
        blocked_fraction = sum(float(r.get("trips") or 0.0) for r in blocked)
        remaining_total = sum(float(r.get("trips") or 0.0) for r in remaining)

        if remaining_total <= 0.0:
            # Degenerate case: all remaining trips are zero → re-route
            pairs_for_recompute.append(pair_dict)
            continue

        new_routes: list[dict] = []
        for r in remaining:
            old_trips = float(r.get("trips") or 0.0)
            new_trips = old_trips + (old_trips / remaining_total) * blocked_fraction
            new_routes.append({**r, "trips": new_trips})

        redist_feat = {
            "type": "Feature",
            "geometry": feat.get("geometry"),
            "properties": {
                **props,
                "routes": new_routes,
            },
        }
        redistributed_features.append(redist_feat)

    redistributed_fc: dict = {"type": "FeatureCollection", "features": redistributed_features}
    return redistributed_fc, pairs_for_recompute


def _normalize_od_fc_to_fractions(od_fc: dict) -> dict:
    """Convert a ``build_od_matrix`` output from absolute trips to fraction convention.

    ``build_od_matrix`` bakes zone production directly into ``tripFraction`` and
    ``route.trips`` (they are absolute trip counts).  The ROUTES output file
    requires the *fraction convention* where:

    .. code-block:: text

        originProduction × route.trips  = actual trips on this path
        Σ route.trips  (all paths & OD-pairs for an origin zone)  ≈ 1.0

    For each origin zone in *od_fc*:

    .. code-block:: text

        zone_total       = Σ route.trips  (all OD pairs + routes for this origin)
        originProduction = zone_total
        tripFraction    /= zone_total   (per OD pair)
        route.trips     /= zone_total   (per individual route)

    Origins with zero total trips are left unchanged.
    """
    features = list(od_fc.get("features") or [])

    # Pass 1: compute zone_total per origin
    zone_total: dict[str, float] = {}
    for feat in features:
        p = feat.get("properties") or {}
        from_id = str(p.get("fromZoneId") or "")
        for route in p.get("routes") or []:
            zone_total[from_id] = zone_total.get(from_id, 0.0) + float(route.get("trips") or 0.0)

    # Pass 2: normalize
    new_features = []
    for feat in features:
        p = feat.get("properties") or {}
        from_id = str(p.get("fromZoneId") or "")
        total = zone_total.get(from_id, 0.0)
        if total <= 0.0:
            new_features.append(feat)
            continue
        new_routes = [
            {**r, "trips": round(float(r.get("trips") or 0.0) / total, 6)}
            for r in (p.get("routes") or [])
        ]
        new_features.append(
            {
                **feat,
                "properties": {
                    **p,
                    "originProduction": round(total, 4),
                    "tripFraction": round(float(p.get("tripFraction") or 0.0) / total, 6),
                    "routes": new_routes,
                },
            }
        )

    return {**od_fc, "features": new_features}


def _validate_od_adjustments(od_adjustments: list[dict]) -> None:
    """Validate OD adjustment entries; raise ``ValueError`` on the first violation.

    Rules
    -----
    * ``fromZoneId`` and ``toZoneId`` must be non-empty strings.
    * ``tripFraction``, if present, must be a non-negative number.
    * ``motifRatio``, if present, must be a dict of non-negative values that sum
      to 1.0 (tolerance ± 0.01).
    * At least one of ``tripFraction`` or ``motifRatio`` must be present.
    """
    for entry in od_adjustments:
        origin = str(entry.get("fromZoneId") or "").strip()
        dest = str(entry.get("toZoneId") or "").strip()
        if not origin or not dest:
            raise ValueError(f"OD entry must have non-empty 'fromZoneId' and 'toZoneId': {entry}")

        if "tripFraction" not in entry and "motifRatio" not in entry:
            raise ValueError(f"OD entry must have at least 'tripFraction' or 'motifRatio': {entry}")

        if "tripFraction" in entry:
            try:
                trips_val = float(entry["tripFraction"])
            except (TypeError, ValueError) as exc:
                raise ValueError(f"OD entry 'tripFraction' must be a number: {entry}") from exc
            if trips_val < 0:
                raise ValueError(f"OD entry 'tripFraction' must be >= 0: {entry}")

        if "motifRatio" in entry:
            ratio = entry["motifRatio"]
            if not isinstance(ratio, dict) or not ratio:
                raise ValueError(f"OD entry 'motifRatio' must be a non-empty dict: {entry}")
            for k, v in ratio.items():
                try:
                    fv = float(v)
                except (TypeError, ValueError) as exc:
                    raise ValueError(
                        f"OD entry 'motifRatio' values must be numbers (key {k!r}): {entry}"
                    ) from exc
                if fv < 0:
                    raise ValueError(
                        f"OD entry 'motifRatio' values must be >= 0 (key {k!r}): {entry}"
                    )
            total = sum(float(v) for v in ratio.values())
            if abs(total - 1.0) > 0.01:
                raise ValueError(
                    f"OD entry 'motifRatio' values must sum to 1.0 (got {total:.4f}): {entry}"
                )


def _apply_od_adjustments(
    od_adjustments: list[dict],
    base_routes_fc: dict,
) -> dict:
    """Build an update FeatureCollection from explicit OD pair adjustments.

    For each entry in *od_adjustments* the matching pair is looked up in
    *base_routes_fc* (matched on ``origin``/``destination`` → ``fromZoneId``/
    ``toZoneId``) and a new feature is produced with:

    * **``trips`` present** — the existing routes are rescaled so that
      ``originProduction = trips`` (absolute) and ``route.trips`` fractions sum
      to 1.0, preserving the relative split between alternative routes.
    * **``motifRatio`` present** — ``motifRatio`` on the feature is overwritten.
      If ``trips`` is absent the volume (``originProduction``, ``tripFraction``,
      ``route.trips``) is left unchanged.
    * **Only ``motifRatio``** — volume unchanged; only the motive distribution
      is updated; no flow delta is contributed to the network links.

    If the pair is not found in *base_routes_fc* a ``ValueError`` is raised
    (re-routing a brand-new pair requires ``build_od_matrix``).

    Returns
    -------
    dict
        GeoJSON FeatureCollection ready to be passed to ``merge_routes``.
        Features use the fraction convention (``originProduction`` holds the
        absolute trips; ``route.trips`` fractions sum to 1.0 per OD pair).
    """
    # Build lookup: (fromZoneId, toZoneId) → feature
    base_index: dict[tuple[str, str], dict] = {}
    for feat in base_routes_fc.get("features") or []:
        p = feat.get("properties") or {}
        key = (
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId") or ""),
        )
        base_index[key] = feat

    new_features: list[dict] = []

    for entry in od_adjustments:
        origin = str(entry["origin"]).strip()
        dest = str(entry["destination"]).strip()
        key = (origin, dest)

        base_feat = base_index.get(key)
        if base_feat is None:
            raise ValueError(
                f"OD pair ({origin!r} → {dest!r}) not found in the base ROUTES file. "
                "Only existing pairs can be adjusted; use node/zone adjustments to "
                "route new pairs."
            )

        base_props = dict(base_feat.get("properties") or {})
        new_props = dict(base_props)  # start from a copy of the base

        if "trips" in entry:
            new_trips_abs = float(entry["trips"])

            base_routes: list[dict] = list(base_props.get("routes") or [])
            if not base_routes:
                # Pair exists but has no routes (tombstone) — nothing to rescale
                new_props["originProduction"] = round(new_trips_abs, 4)
                new_props["tripFraction"] = 1.0
            else:
                # Preserve the relative split between alternative routes; normalise
                # so all route.trips fractions sum to 1.0.
                route_weights = [float(r.get("trips") or 0.0) for r in base_routes]
                weight_total = sum(route_weights)

                if weight_total > 0.0:
                    new_routes = [
                        {**r, "trips": round(w / weight_total, 6)}
                        for r, w in zip(base_routes, route_weights)
                    ]
                else:
                    # Degenerate: all weights zero — distribute evenly
                    n = len(base_routes)
                    new_routes = [{**r, "trips": round(1.0 / n, 6)} for r in base_routes]

                new_props["routes"] = new_routes
                new_props["originProduction"] = round(new_trips_abs, 4)
                # tripFraction: this mini-FC has one pair per origin, so fraction = 1.0
                new_props["tripFraction"] = 1.0

        if "motifRatio" in entry:
            new_props["motifRatio"] = {k: float(v) for k, v in entry["motifRatio"].items()}

        new_features.append(
            {
                "type": "Feature",
                "geometry": base_feat.get("geometry"),
                "properties": new_props,
            }
        )

    return {"type": "FeatureCollection", "features": new_features}


def apply_od_adjustments(
    routes_fc: dict,
    od_adjustments: list[dict],
) -> dict:
    """Apply explicit OD-pair adjustments using the ``tripFraction`` convention.

    For each entry in *od_adjustments* the matching pair is looked up in
    *routes_fc* (matched on ``fromZoneId`` / ``toZoneId``) and a new feature is
    produced with:

    * **``tripFraction`` present** — ``route.trips`` values are scaled by the
      factor ``new_frac / old_frac``, and ``tripFraction`` is updated to
      ``new_frac``.  ``originProduction`` is preserved unchanged.  This keeps
      the absolute flow compatible with the ``_compute_link_flow_delta``
      ``extra_od_fcs`` path (which multiplies ``route.trips × originProduction``).
    * **``motifRatio`` present** — ``motifRatio`` on the feature is overwritten.
      If ``tripFraction`` is absent the volume is left unchanged.

    Only features whose OD pair is found in *routes_fc* are included in the
    output.  If a pair is not found a ``ValueError`` is raised.

    Parameters
    ----------
    routes_fc:
        Base ROUTES FeatureCollection.
    od_adjustments:
        List of adjustment entries with ``fromZoneId``, ``toZoneId``, and at
        least one of ``tripFraction`` or ``motifRatio``.

    Returns
    -------
    dict
        GeoJSON FeatureCollection containing only the adjusted features.
    """
    # Build lookup: (fromZoneId, toZoneId) → feature
    base_index: dict[tuple[str, str], dict] = {}
    for feat in routes_fc.get("features") or []:
        p = feat.get("properties") or {}
        key = (
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId") or ""),
        )
        base_index[key] = feat

    new_features: list[dict] = []

    for entry in od_adjustments:
        from_id = str(entry.get("fromZoneId") or "").strip()
        to_id = str(entry.get("toZoneId") or "").strip()
        key = (from_id, to_id)

        base_feat = base_index.get(key)
        if base_feat is None:
            raise ValueError(
                f"OD pair ({from_id!r} → {to_id!r}) not found in the base ROUTES file. "
                "Only existing pairs can be adjusted; use node/zone adjustments to "
                "route new pairs."
            )

        base_props = dict(base_feat.get("properties") or {})
        new_props = dict(base_props)

        if "tripFraction" in entry:
            new_frac = float(entry["tripFraction"])
            old_frac = float(base_props.get("tripFraction") or 0.0)

            base_routes: list[dict] = list(base_props.get("routes") or [])
            if base_routes and old_frac > 0.0:
                scale = new_frac / old_frac
                new_routes = [
                    {**r, "trips": round(float(r.get("trips") or 0.0) * scale, 6)}
                    for r in base_routes
                ]
                new_props["routes"] = new_routes
            elif base_routes and old_frac == 0.0 and new_frac > 0.0:
                # Degenerate: old fraction was zero — distribute evenly
                n = len(base_routes)
                new_routes = [{**r, "trips": round(new_frac / n, 6)} for r in base_routes]
                new_props["routes"] = new_routes

            new_props["tripFraction"] = round(new_frac, 6)
            # originProduction is intentionally preserved

        if "motifRatio" in entry:
            new_props["motifRatio"] = {k: float(v) for k, v in entry["motifRatio"].items()}

        new_features.append(
            {
                "type": "Feature",
                "geometry": base_feat.get("geometry"),
                "properties": new_props,
            }
        )

    return {"type": "FeatureCollection", "features": new_features}


def _restore_origin_productions(fc: dict, base_fc: dict) -> dict:
    """Restore ``originProduction`` in *fc* from matching features in *base_fc*.

    ``recompute_routes_for_pairs`` does not receive zone production data so it
    leaves ``originProduction`` at ``0.0`` in every output feature.  When those
    features are merged back into the base ROUTES file the ``originProduction``
    would be overwritten with ``0.0``, breaking the frontend invariant
    ``originProduction > 0``.

    This function copies the ``originProduction`` value from the matching base
    ROUTES feature (matched on ``fromZoneId`` + ``toZoneId`` + ``fromType`` +
    ``toType``) for every feature in *fc* that currently has
    ``originProduction == 0.0``.  Features with ``originProduction > 0.0``
    and features with no match in *base_fc* are left unchanged.
    """
    base_prod: dict[tuple[str, str, str, str], float] = {}
    for feat in base_fc.get("features") or []:
        p = feat.get("properties") or {}
        key = (
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId") or ""),
            str(p.get("fromType") or "zone"),
            str(p.get("toType") or "zone"),
        )
        val = float(p.get("originProduction") or 0.0)
        if val > 0.0:
            base_prod[key] = val

    new_features = []
    for feat in fc.get("features") or []:
        p = feat.get("properties") or {}
        if float(p.get("originProduction") or 0.0) == 0.0:
            key = (
                str(p.get("fromZoneId") or ""),
                str(p.get("toZoneId") or ""),
                str(p.get("fromType") or "zone"),
                str(p.get("toType") or "zone"),
            )
            prod = base_prod.get(key, 0.0)
            if prod > 0.0:
                feat = {**feat, "properties": {**p, "originProduction": prod}}
        new_features.append(feat)

    return {**fc, "features": new_features}


def _evaporate_unroutable_pairs(
    pairs_to_recompute: list[dict],
    full_recomputed_fc: dict,
    routes_fc: dict,
) -> list[dict]:
    """Build tombstone (``routes=[]``) features for pairs that could not be re-routed.

    ``recompute_routes_for_pairs`` silently omits any pair for which no
    alternative path exists in the (adjusted) network — e.g. all remaining
    paths would have to cross a link that was just closed.  Left unhandled,
    the original stale route (which still traverses the now-closed link) would
    remain untouched in the merged ROUTES output, because ``merge_routes``
    only overwrites pairs that are actually present in the update
    FeatureCollection.

    This function detects those "lost" pairs — present in *pairs_to_recompute*
    but absent from *full_recomputed_fc* — and returns tombstone features
    (``routes=[]``) copied from the matching base *routes_fc* feature, so the
    now-unreachable trips are evaporated instead of silently kept on an
    invalid route.

    Why this lives here and not in ``gmt-routing``
    -----------------------------------------------
    ``recompute_routes_for_pairs`` is a deliberately generic, side-effect-free
    routing primitive: given a network and a list of OD pairs, it finds paths
    or reports that none exist.  It has no notion of "evaporation",
    ``tripFraction``/``originProduction`` conventions, or tombstone features —
    those are ``adjust``-pipeline concepts.  Its docstring states the contract
    explicitly: unreachable pairs are omitted, and *the caller* decides what
    that means (keep the stale route? evaporate it? raise? redistribute the
    trips elsewhere?).

    The ``adjust`` pipeline is the only current caller of
    ``recompute_routes_for_pairs`` and already owns the evaporation
    convention — see ``_redistribute_routes``, which evaporates pairs whose
    remaining trip volume drops below ``min_trips_per_pair`` using the exact
    same ``routes=[]`` tombstone shape.  Keeping this function next to that
    one (rather than pushing evaporation semantics down into the shared
    routing library) keeps ``gmt-routing`` reusable for callers that might
    want different behaviour for unreachable pairs.
    """
    recomputed_keys: set[tuple[str, str, str, str]] = {
        (
            str((f.get("properties") or {}).get("fromZoneId") or ""),
            str((f.get("properties") or {}).get("toZoneId") or ""),
            str((f.get("properties") or {}).get("fromType") or "zone"),
            str((f.get("properties") or {}).get("toType") or "zone"),
        )
        for f in full_recomputed_fc.get("features") or []
    }

    base_by_key: dict[tuple[str, str, str, str], dict] = {}
    for feat in routes_fc.get("features") or []:
        p = feat.get("properties") or {}
        key = (
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId") or ""),
            str(p.get("fromType") or "zone"),
            str(p.get("toType") or "zone"),
        )
        base_by_key[key] = feat

    evaporated: list[dict] = []
    for pair in pairs_to_recompute:
        key = (
            str(pair.get("fromId") or ""),
            str(pair.get("toId") or ""),
            str(pair.get("fromType") or "zone"),
            str(pair.get("toType") or "zone"),
        )
        if key in recomputed_keys:
            continue  # successfully re-routed

        base_feat = base_by_key.get(key)
        if base_feat is None:
            continue  # nothing to tombstone

        base_props = base_feat.get("properties") or {}
        evaporated.append(
            {
                "type": "Feature",
                "geometry": base_feat.get("geometry"),
                "properties": {
                    **base_props,
                    "routes": [],
                },
            }
        )

    return evaporated


def _stamp_area_ids(
    fc: dict,
    new_area_id: str,
    base_area_id: str,
    *,
    name: str | None = None,
) -> dict:
    """Return a shallow copy of *fc* with ``$.properties`` updated for the new area.

    Sets / overwrites:

    * ``areaId``     → *new_area_id*   (glossary meta field)
    * ``baseAreaId`` → *base_area_id*  (glossary meta field; the area this was derived from)
    * ``name``       → *name*          (human-readable scenario label; set only when provided)

    Any legacy ``area_id`` (snake_case) key is removed to ensure all outputs
    use the authoritative camelCase names from the glossary.
    """
    fc = {**fc}  # shallow copy so we don't mutate the caller's dict
    existing: dict = dict(fc.get("properties") or {})

    existing.pop("area_id", None)  # remove legacy snake_case key
    existing["areaId"] = new_area_id
    existing["baseAreaId"] = base_area_id
    if name is not None:
        existing["name"] = name

    fc["properties"] = existing
    return fc


def merge_routes(
    base_fc: dict,
    *update_fcs: dict,
) -> dict:
    """Merge one or more update FeatureCollections into a base ROUTES FeatureCollection.

    For every feature in each *update_fc*, the matching feature in *base_fc*
    (matched on ``fromZoneId`` + ``toZoneId`` + ``fromType`` + ``toType``) is
    replaced.  New pairs (not present in *base_fc*) are appended.

    The ``properties.fields`` list of the base is preserved;
    any extra keys from update FCs are union-merged into it.

    Parameters
    ----------
    base_fc:
        The existing ROUTES GeoJSON FeatureCollection to update.
    *update_fcs:
        One or more FeatureCollections whose features should replace/extend
        the base.  Applied in order — later updates win over earlier ones.

    Returns
    -------
    dict
        Updated FeatureCollection.
    """
    # Build mutable index: (fromId, toId, fromType, toType) -> list position
    features = list(base_fc.get("features") or [])
    index: dict[tuple[str, str, str, str], int] = {}
    for i, feat in enumerate(features):
        p = feat.get("properties") or {}
        key = (
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId") or ""),
            str(p.get("fromType") or "zone"),
            str(p.get("toType") or "zone"),
        )
        index[key] = i

    for upd_fc in update_fcs:
        for feat in upd_fc.get("features") or []:
            p = feat.get("properties") or {}
            key = (
                str(p.get("fromZoneId") or ""),
                str(p.get("toZoneId") or ""),
                str(p.get("fromType") or "zone"),
                str(p.get("toType") or "zone"),
            )
            if key in index:
                features[index[key]] = feat
            else:
                index[key] = len(features)
                features.append(feat)

    # Merge fields lists
    base_lp: list[str] = list((base_fc.get("properties") or {}).get("fields") or [])
    for upd_fc in update_fcs:
        for lp_key in (upd_fc.get("properties") or {}).get("fields") or []:
            if lp_key not in base_lp:
                base_lp.append(lp_key)

    fc_props = dict(base_fc.get("properties") or {})
    fc_props["fields"] = base_lp

    return {"type": "FeatureCollection", "features": features, "properties": fc_props}


# ---------------------------------------------------------------------------
# Flow delta helpers
# ---------------------------------------------------------------------------


def _compute_link_flow_delta(
    old_routes_fc: dict,
    recomputed_fc: dict,
    od_fc_new: dict,
    zones_fc: dict,
    *extra_od_fcs: dict,
    relative_origin_ids: frozenset[str] | set[str] = frozenset(),
) -> dict[str, tuple[float, float]]:
    """Compute per-link ``{linkId: (flow_before, flow_after)}`` from route changes.

    All inputs use the *fraction convention*:

    * **Base ROUTES / recomputed_fc** — ``route.trips`` is a *fraction* of the
      origin zone's production.  Actual trips = ``route.trips × zone_production``
      where ``zone_production`` is read from *zones_fc*.
    * **od_fc_new** / **extra_od_fcs** — normalized fraction convention; each
      feature's ``originProduction`` holds the absolute adjustment value.
      Actual trips = ``route.trips × originProduction``.

    The algorithm (per affected pair):

    .. code-block:: text

        # base ROUTES / recomputed_fc  (fraction convention):
        flows[linkId] += route.trips × zone_production   (from zones_fc)

        # od_fc_new  (normalized fraction convention):
        flows[linkId] += route.trips × originProduction  (from feature props)

        delta[linkId] = add_flows − remove_flows

    Parameters
    ----------
    old_routes_fc:
        The original ROUTES FeatureCollection (before any adjustments).
    recomputed_fc:
        Re-routed OD pairs for case (c): pairs whose route passed through an
        adjusted link.  These replace their counterparts in *old_routes_fc*.
    od_fc_new:
        Newly routed OD pairs for cases (a) and (b): node/zone adjustments
        produced by ``build_od_matrix`` and normalized to fraction convention
        by ``_normalize_od_fc_to_fractions``.  ``route.trips`` are fractions;
        ``originProduction`` holds the absolute adjustment value.
    zones_fc:
        Zone GeoJSON FeatureCollection — used to look up ``production`` per
        zone (keyed by ``zoneId``).  Applied to base-ROUTES / recomputed-FC
        pairs only.
    relative_origin_ids:
        Zone/node IDs whose node adjustment used a *relative* delta (e.g.
        ``"+191"``) rather than an absolute value (e.g. ``"500"``, or ``"0"``
        for a tombstone).  For these origins, a pre-existing OD pair's old
        flow is **not** subtracted — only the incremental ``od_fc_new``
        contribution is added — since a relative change must add on top of
        the existing routes rather than replace them.

    Returns
    -------
    dict mapping linkId → (flow_before, flow_after)
        Only links with at least one non-zero entry are included.
    """
    # Build zone-production lookup
    zone_production: dict[str, float] = {}

    for feat in zones_fc.get("features") or []:
        p = feat.get("properties") or {}
        zid = str(p.get("zoneId") or "").strip()
        if zid:
            zone_production[zid] = float(p.get("production") or 0.0)

    def _origin_production(p: dict) -> float:
        """Return the absolute production for the origin of an OD feature."""
        from_id = str(p.get("fromZoneId") or "").strip()
        from_type = str(p.get("fromType") or "zone").strip()
        if from_type == "zone":
            return zone_production.get(from_id, 0.0)
        # For node-type origins the route.trips fraction is already in absolute
        # trip units (build_od_matrix stores absolute trips for node adjustments).
        return 1.0

    before: dict[str, float] = {}
    after: dict[str, float] = {}

    def _pair_key(p: dict) -> tuple[str, str, str, str]:
        return (
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId") or ""),
            str(p.get("fromType") or "zone"),
            str(p.get("toType") or "zone"),
        )

    # Build key→feature index of old routes for O(1) replacement lookup.
    old_routes_index: dict[tuple[str, str, str, str], dict] = {}
    for feat in old_routes_fc.get("features") or []:
        old_routes_index[_pair_key(feat.get("properties") or {})] = feat

    # Build a set of keys for re-routed pairs
    recomputed_keys: set[tuple[str, str, str, str]] = set()
    for feat in recomputed_fc.get("features") or []:
        recomputed_keys.add(_pair_key(feat.get("properties") or {}))

    # Before: sum trips from old routes for every re-routed pair
    for feat in old_routes_fc.get("features") or []:
        p = feat.get("properties") or {}
        if _pair_key(p) not in recomputed_keys:
            continue
        production = _origin_production(p)
        for route in p.get("routes") or []:
            trips = float(route.get("trips") or 0.0) * production
            for lid in route.get("linkPath") or []:
                before[lid] = before.get(lid, 0.0) + trips

    # After: sum trips from re-routed pairs (new routes)
    for feat in recomputed_fc.get("features") or []:
        p = feat.get("properties") or {}
        production = _origin_production(p)
        for route in p.get("routes") or []:
            trips = float(route.get("trips") or 0.0) * production
            for lid in route.get("linkPath") or []:
                after[lid] = after.get(lid, 0.0) + trips

    # Before+After: node/zone-adjustment pairs.
    # When a pair in od_fc_new replaces an existing pair in old_routes_fc, the old
    # flows must be subtracted (flow_before) so the delta correctly removes them.
    # This is the mechanism that enables production=0 / attraction=0 tombstones to
    # reduce link flows when they override previously computed routes.
    #
    # NOTE on trip conventions:
    #   • Pairs from the base ROUTES file (old_routes_fc) and recomputed_fc store
    #     route.trips as a *fraction* of the origin zone's production.  Multiplying
    #     by zone production (from zones_fc) converts to absolute trips.
    #   • Pairs from od_fc_new (normalized by _normalize_od_fc_to_fractions) also
    #     store route.trips as a *fraction*, with originProduction holding the
    #     absolute adjustment value.  Multiplying by originProduction converts to
    #     absolute trips.
    for feat in od_fc_new.get("features") or []:
        p = feat.get("properties") or {}
        key = _pair_key(p)
        from_id = str(p.get("fromZoneId") or "").strip()

        # Before: if this pair already exists in the base ROUTES file and has NOT
        # been handled by the recomputed_fc path, accumulate its old trips as "before".
        # The base ROUTES pair stores fractions → multiply by its origin production.
        #
        # Skip this for origins whose adjustment was a *relative* delta
        # ("+191"): od_fc_new's route.trips/originProduction for those only
        # represent the incremental change, not a full replacement, so the
        # pair's existing flow must be left untouched and the new trips simply
        # added on top (see "After" below). Only an absolute adjustment (e.g.
        # "500", or "0" for a tombstone) is meant to replace the old flow.
        is_relative = from_id in relative_origin_ids
        if key in old_routes_index and key not in recomputed_keys and not is_relative:
            old_p = old_routes_index[key].get("properties") or {}
            prod_old = _origin_production(old_p)
            for route in old_p.get("routes") or []:
                trips = float(route.get("trips") or 0.0) * prod_old
                for lid in route.get("linkPath") or []:
                    before[lid] = before.get(lid, 0.0) + trips

        # After: new trips from od_fc_new — normalized fraction convention.
        # Multiply route.trips (fraction) × originProduction (absolute adjustment
        # value) to obtain the absolute flow contribution for each link.
        origin_prod = float(p.get("originProduction") or 0.0)
        for route in p.get("routes") or []:
            trips = float(route.get("trips") or 0.0) * origin_prod
            for lid in route.get("linkPath") or []:
                after[lid] = after.get(lid, 0.0) + trips

    # Extra OD FCs (e.g. od_adjust_fc from explicit OD adjustments).
    # These follow the same normalized fraction convention as od_fc_new:
    # route.trips × originProduction = absolute trips.
    for extra_fc in extra_od_fcs:
        for feat in extra_fc.get("features") or []:
            p = feat.get("properties") or {}
            key = _pair_key(p)

            # Before: strip old trips for this pair if it existed in the base ROUTES
            # and was NOT already handled by recomputed_fc.
            # Base ROUTES features store route.trips as fractions; the absolute
            # scale is carried by originProduction on the feature itself (not
            # from zones_fc), since _apply_od_adjustments preserves this convention.
            if key in old_routes_index and key not in recomputed_keys:
                old_p = old_routes_index[key].get("properties") or {}
                prod_old = float(old_p.get("originProduction") or 0.0)
                for route in old_p.get("routes") or []:
                    trips = float(route.get("trips") or 0.0) * prod_old
                    for lid in route.get("linkPath") or []:
                        before[lid] = before.get(lid, 0.0) + trips

            # After: use new originProduction × route.trips.
            # If only motifRatio changed (no trips in entry) originProduction equals
            # the base value → delta cancels out → no link flow change. Correct.
            origin_prod = float(p.get("originProduction") or 0.0)
            for route in p.get("routes") or []:
                trips = float(route.get("trips") or 0.0) * origin_prod
                for lid in route.get("linkPath") or []:
                    after[lid] = after.get(lid, 0.0) + trips

    all_link_ids = set(before.keys()) | set(after.keys())
    return {lid: (before.get(lid, 0.0), after.get(lid, 0.0)) for lid in all_link_ids}


def _apply_flow_delta(
    network_fc: dict,
    delta: dict[str, tuple[float, float]],
) -> tuple[dict, list[dict]]:
    """Apply a per-link flow delta to a copy of *network_fc*.

    For each link in *delta*, ``flow_change = flow_after - flow_before`` is
    added to the ``flow`` and ``flow24hrs`` properties.  The ``flowsPerDaypart``
    and ``flowsPerMotive`` sub-dicts are scaled proportionally so that their
    sum matches the new ``flow`` value.

    Parameters
    ----------
    network_fc:
        Original network GeoJSON FeatureCollection.
    delta:
        Mapping of ``linkId → (flow_before, flow_after)`` as produced by
        ``_compute_link_flow_delta``.

    Returns
    -------
    (adjusted_fc, report)
        *adjusted_fc* is a deep copy of *network_fc* with updated flow fields.
        *report* is a list of dicts with ``{linkId, flow_before, flow_after,
        flow_delta}`` for each link that was changed.
    """
    adjusted_fc = copy.deepcopy(network_fc)
    report: list[dict] = []

    for feat in adjusted_fc.get("features") or []:
        props = feat.get("properties") or {}
        lid = str(props.get("linkId") or "").strip()
        if lid not in delta:
            continue

        flow_before_route, flow_after_route = delta[lid]
        flow_change = flow_after_route - flow_before_route
        if flow_change == 0.0:
            continue

        orig_flow = float(props.get("flow") or 0.0)
        orig_flow24 = float(props.get("flow24hrs") or 0.0)
        new_flow = max(orig_flow + flow_change, 0.0)
        new_flow24 = max(orig_flow24 + flow_change, 0.0)

        feat["properties"]["flow"] = new_flow
        feat["properties"]["flow24hrs"] = new_flow24

        # Proportional scaling for sub-dicts
        if orig_flow > 0.0:
            scale = new_flow / orig_flow
            if isinstance(props.get("flowsPerDaypart"), dict):
                feat["properties"]["flowsPerDaypart"] = {
                    k: max(v * scale, 0.0) for k, v in props["flowsPerDaypart"].items()
                }
            if isinstance(props.get("flowsPerMotive"), dict):
                feat["properties"]["flowsPerMotive"] = {
                    k: max(v * scale, 0.0) for k, v in props["flowsPerMotive"].items()
                }

        # Update remainingCap: capacity - max(flowsPerDaypart) after scaling
        feat["properties"]["remainingCap"] = _remaining_cap(
            feat["properties"].get("capacity"), feat["properties"]
        )

        report.append(
            {
                "linkId": lid,
                "flow_before": orig_flow,
                "flow_after": new_flow,
                "flow_delta": flow_change,
            }
        )

    return adjusted_fc, report


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


def _uri_name(uri: str) -> str:
    """Return the last path component of *uri* (works for local paths and all URI schemes)."""
    return uri.replace("\\", "/").rsplit("/", 1)[-1]


def run_pipeline(
    folder: str | Path,
    changes: str,
    output_folder: str | Path,
    *,
    routes_path: str | Path,
    new_area_id: str | None = None,
    min_link_trips: float,
    debug: bool,
    compare: bool = False,
    scenario_name: str | None = None,
) -> str:
    """Run the GMT node- and link-adjustment pipeline.

    Parameters
    ----------
    folder:
        Directory (local path, ``file://``, ``s3://``, or ``mem://`` URI)
        containing the prepared source files (network, zones, feedlinks).  If
        a ``{area_id}-BOTTLENECK-{mode}.parquet`` file (produced by
        ``bottleneck_detector``) is also present, its structural-bottleneck
        edges are passed to the route-finding calls below so that, where
        possible, an alternative route that avoids a known bottleneck is kept
        instead of letting every route for an affected OD pair evaporate.
        Optional — omitted entirely when the file is absent. If a
        ``{area_id}-BUILDINGS.parquet`` file (produced by the prepare
        pipeline's OSM building fetch) is also present, it is used to weight
        any zone-explode adjustment by registered building floor area (m²)
        instead of road length; also optional.
    changes:
        Inline JSON array **or** path to a ``.json`` file describing adjustments.
        Each entry is a **node/zone**, **link**, **OD-pair**, **flow**, or
        **zone-explode** adjustment (see ``_split_changes`` for the exact
        classification rules):

        Node/zone adjustment — must have ``"nodeId"`` **or** ``"zoneId"`` (not
        both), plus ``"production"`` and/or ``"attraction"``.

        Link adjustment — must have ``"linkId"`` **or** both ``"fromNode"`` and
        ``"toNode"``, plus **either** ``"capacity"`` or ``"speed"`` (not both).
        Values follow the delta convention: ``"+50"``, ``"-20"``, or an absolute
        numeric string.  If ``"bidirectional": true`` the reverse direction is
        also adjusted.  When ``"speed"`` is changed, capacity is automatically
        recalculated from the speed-category table (speed × lanes).

        Zone-explode adjustment — must have ``"zoneId"`` (a non-``BOUNDARY``
        zone) and ``"explodeInto"`` (an integer >= 2).  Splits the zone's
        polygon into that many sub-zones along its dominant roads, scales its
        numeric properties (production, attraction, ...) across the pieces,
        and regenerates OD pairs for the new zones via ``build_od_matrix``
        (see ``apply_zone_explosions``) — like a node/zone production
        adjustment, this always triggers a full OD-matrix/routes
        recomputation for the affected zones, not a cheap geometry-only edit.
        When a ``{area_id}-BUILDINGS.parquet`` file exists for the area (the
        prepare pipeline's registered-building output), the split is weighted
        by each piece's share of registered building floor area (m²) instead
        of road length — the target size per sub-zone is the zone's total
        registered m² divided by ``explodeInto``. Falls back to road-length
        weighting when no buildings file is present.

        Example::

            [
              {"nodeId": "1234", "production": "+500"},
              {"linkId": "9876", "capacity": "0", "bidirectional": true},
              {"fromNode": "111", "toNode": "222", "speed": "30"},
              {"zoneId": "BU0599001", "explodeInto": 3}
            ]

    routes_path:
        Path or URI to the existing ``{area_id}-ROUTES-{mode}.parquet`` file
        produced by ``matrix_builder``.  The file is updated in the output
        folder: affected OD pairs (those whose routes pass through adjusted
        links) are re-routed on the modified network; pairs introduced by
        node/zone adjustments are appended.
    output_folder:
        Destination directory (local path, ``file://``, ``s3://``, or
        ``mem://`` URI) for the adjusted network, zones, feedlinks and the
        updated routes file.
    new_area_id:
        UUID to use for the output files.  When *None* a fresh UUID is generated.
    min_link_trips:
        Minimum absolute flow change required to update a link (applied as a
        threshold on ``|flow_delta|``).
    debug:
        Print the per-link flow report to stdout.
    compare:
        Write a bandwidth-comparison GeoJSON (``{new_area_id}-COMPARE-{mode}.geojson``)
        to *output_folder*.  Skipped by default.
    scenario_name:
        Human-readable label stored as ``name`` in ``$.properties`` of every output
        FeatureCollection.  When *None* the existing ``name`` from the source files is
        preserved unchanged.

    Returns
    -------
    str
        The area-ID (UUID) used for all output files in *output_folder*.
    """
    from gmt_routing.route_explorer.core.route_explorer_core import (
        build_od_matrix,
        recompute_routes_for_pairs,
    )
    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet
    from gmt_shared.uri import (
        ensure_folder,
        join_uri,
        read_uri,
        uri_exists,
        write_uri,
    )

    area_id = _discover_area_id(folder)
    mode = _detect_mode(folder, area_id)

    network_path = join_uri(folder, f"{area_id}-NETWORK-{mode}.parquet")
    zones_path = join_uri(folder, f"{area_id}-ZONE-{mode}.parquet")
    feedlinks_path = join_uri(folder, f"{area_id}-FEEDLINK-{mode}.parquet")
    routes_uri = str(routes_path)

    # Derive the routes output mode from the routes *input* filename so that a
    # CAR routes file fed into a MIXED-network adjustment still produces a
    # ROUTES-CAR output (not ROUTES-MIXED).
    routes_mode = _routes_mode_from_path(routes_path, fallback=mode)

    for uri in (network_path, zones_path, feedlinks_path, routes_uri):
        if not uri_exists(uri):
            print(f"ERROR: required input file not found: {uri}", file=sys.stderr)
            sys.exit(1)

    # Structural-bottleneck edges (bridges), if a bottleneck_detector run was
    # ever stored alongside the source files — optional, not part of the
    # required-files check above, so areas prepared before this feature
    # existed keep working unchanged (bottleneck_edges stays None, fully
    # inert).  Always read from the *source* folder, never recomputed on the
    # already-adjusted network — otherwise a bridge that was just closed
    # would vanish from its own bottleneck set.
    bottleneck_path = join_uri(folder, f"{area_id}-BOTTLENECK-{mode}.parquet")
    bottleneck_edges: set[tuple[str, str]] | None = None
    if uri_exists(bottleneck_path):
        from gmt_routing.bottleneck_detector.core.bottleneck_detector_core import (
            bottleneck_edge_set,
        )

        bottleneck_fc = from_geoparquet(read_uri(bottleneck_path))
        bottleneck_edges = bottleneck_edge_set(bottleneck_fc)
        print(f"      Loaded {len(bottleneck_edges)} bottleneck edge(s) from {bottleneck_path}")

    # Area-wide registered buildings (prepare pipeline's stage-5 output), if
    # present — optional, mode-independent (no {mode} token), used only by
    # zone-explode adjustments to weight the split by registered building
    # floor area (m²) instead of road length.  Areas prepared without OSM
    # building fetching keep the road-length-weighted zone-explode behavior
    # unchanged (buildings_fc stays None, fully inert).
    buildings_path = join_uri(folder, f"{area_id}-BUILDINGS.parquet")
    buildings_fc: dict | None = None
    if uri_exists(buildings_path):
        buildings_fc = from_geoparquet(read_uri(buildings_path))
        print(
            f"      Loaded {len(buildings_fc.get('features', []))} building(s) "
            f"from {buildings_path}"
        )

    new_area_id = new_area_id or str(uuid4())
    all_changes = _load_changes(changes)
    if not all_changes:
        print("No adjustments provided — nothing to do.")
        sys.exit(0)

    node_adjustments, link_adjustments, od_adjustments, flow_adjustments, zone_explode_adjustments = (
        _split_changes(all_changes)
    )

    if (
        not node_adjustments
        and not link_adjustments
        and not od_adjustments
        and not flow_adjustments
        and not zone_explode_adjustments
    ):
        print("No valid adjustments found — nothing to do.")
        sys.exit(0)

    if od_adjustments:
        _validate_od_adjustments(od_adjustments)

    print()
    print("============================================================")
    print(" GMT Adjustment Pipeline")
    print(f" source area-id    : {area_id}")
    print(f" new area-id       : {new_area_id}")
    print(f" mode              : {mode}")
    print(f" routes mode       : {routes_mode}")
    print(f" source folder     : {folder}")
    print(f" output folder     : {output_folder}")
    print(f" routes file       : {routes_path}")
    print(f" node adjustments  : {node_adjustments}")
    print(f" link adjustments  : {link_adjustments}")
    print(f" od adjustments    : {od_adjustments}")
    print(f" flow adjustments  : {flow_adjustments}")
    print(f" zone explode adj. : {zone_explode_adjustments}")
    print(f" min link trips    : {min_link_trips}")
    print("============================================================")

    # ------------------------------------------------------------------
    # [1/7] Load source files
    # ------------------------------------------------------------------
    print()
    print("[1/7] Loading source files ...")
    network_fc = from_geoparquet(read_uri(network_path))
    zones_fc = from_geoparquet(read_uri(zones_path))
    feedlinks_fc = from_geoparquet(read_uri(feedlinks_path))
    routes_fc = from_geoparquet(read_uri(routes_uri))
    print(
        f"      network: {len(network_fc.get('features', []))} links, "
        f"zones: {len(zones_fc.get('features', []))}, "
        f"feedlinks: {len(feedlinks_fc.get('features', []))}, "
        f"routes: {len(routes_fc.get('features', []))} OD pairs"
    )

    # ------------------------------------------------------------------
    # [1b/7] Apply zone explosions (split a zone into N sub-zones)
    # ------------------------------------------------------------------
    if zone_explode_adjustments:
        print(f"[1b/7] Applying {len(zone_explode_adjustments)} zone explosion(s) ...")
        zones_fc, feedlinks_fc, explode_node_adjustments = apply_zone_explosions(
            zones_fc, network_fc, zone_explode_adjustments, feedlinks_fc, mode, buildings_fc
        )
        node_adjustments = [*node_adjustments, *explode_node_adjustments]
        print(
            f"       zones: {len(zones_fc.get('features', []))} after explosion, "
            f"feedlinks: {len(feedlinks_fc.get('features', []))}."
        )
    else:
        print("[1b/7] No zone explosions.")

    # ------------------------------------------------------------------
    # [2/7] Apply link adjustments (capacity / speed)
    # ------------------------------------------------------------------
    if link_adjustments:
        print(f"[2/7] Applying {len(link_adjustments)} link adjustment(s) ...")
        original_network_fc = network_fc
        network_fc, affected_edges = apply_link_adjustments(network_fc, link_adjustments)
        print(f"      {len(affected_edges)} edge(s) adjusted: {affected_edges}")
    else:
        print("[2/7] No link adjustments — network unchanged.")
        original_network_fc = network_fc
        affected_edges = []

    # ------------------------------------------------------------------
    # [2b/7] Apply OD-pair direct adjustments (no re-routing needed)
    # ------------------------------------------------------------------
    od_adjusted_fc: dict = {"type": "FeatureCollection", "features": []}
    if od_adjustments:
        print(f"[2b/7] Applying {len(od_adjustments)} OD-pair adjustment(s) ...")
        od_adjusted_fc = apply_od_adjustments(routes_fc, od_adjustments)
        print(f"       {len(od_adjusted_fc.get('features', []))} pair(s) modified.")
    else:
        print("[2b/7] No OD-pair adjustments.")

    # ------------------------------------------------------------------
    # [2c/7] Apply flow adjustments (selected-link distribution)
    # ------------------------------------------------------------------
    # Save the original routes before [2c] modifies routes_fc.  The original
    # is used as `old_routes_fc` in _compute_link_flow_delta so that the
    # "before" flow reflects the pre-adjustment state.
    original_routes_fc = routes_fc

    od_flow_delta_fc: dict = {"type": "FeatureCollection", "features": []}
    if flow_adjustments:
        from flow_adjuster.core.flow_adjuster_core import (
            apply_flow_adjustments as _apply_flow_adj,
        )

        print(f"[2c/7] Applying {len(flow_adjustments)} flow adjustment(s) ...")
        routes_fc, zones_fc, od_flow_delta_fc, _flow_stats = _apply_flow_adj(
            network_fc, routes_fc, zones_fc, flow_adjustments
        )
        for _s in _flow_stats:
            if "warning" in _s:
                print(f"       WARNING link {_s['linkId']!r}: {_s['warning']}")
            else:
                print(
                    f"       link {_s['linkId']!r}: "
                    f"flow {_s['flow_before']:.0f} → {_s['flow_after']:.0f} "
                    f"(Δ{_s['flow_delta']:+.0f}), "
                    f"{_s['affected_pairs']} OD pair(s) scaled."
                )
    else:
        print("[2c/7] No flow adjustments.")

    # ------------------------------------------------------------------
    # [3/7] Determine affected OD pairs
    #   (a) node/zone adjustments  → build_od_matrix
    #   (b) O or D not yet in route set (handled by build_od_matrix)
    #   (c) existing routes pass through adjusted links → recompute_routes_for_pairs
    # ------------------------------------------------------------------
    print("[3/7] Determining affected OD pairs ...")

    # (a)+(b) node/zone adjustments
    if not node_adjustments:
        print("      (a/b) SKIPPED — no node/zone adjustments.")
        od_fc = {"type": "FeatureCollection", "features": []}
    else:
        print(f"      (a/b) build_od_matrix for {len(node_adjustments)} node/zone change(s) ...")
        od_fc = build_od_matrix(
            network_fc=network_fc,
            feedlinks_fc=feedlinks_fc,
            zones_fc=zones_fc,
            node_adjustments=node_adjustments,
            bottleneck_edges=bottleneck_edges,
        )
        # Normalize to fraction convention: route.trips → fraction,
        # originProduction → zone_total (absolute adjustment value).
        # This matches the base ROUTES convention expected by the frontend.
        od_fc = _normalize_od_fc_to_fractions(od_fc)
        print(f"      (a/b) {len(od_fc.get('features', []))} pair(s) built.")

    # (c) existing OD pairs whose routes use adjusted links
    # First try local redistribution for closed links; only call the expensive
    # recompute_routes_for_pairs for pairs that truly need full re-routing.
    recomputed_fc: dict = {"type": "FeatureCollection", "features": []}
    if affected_edges:
        affected_link_ids = _find_affected_link_ids(original_network_fc, affected_edges)
        closed_link_ids = _get_closed_link_ids(network_fc, affected_link_ids)

        if closed_link_ids:
            print(
                f"      (c)   {len(closed_link_ids)} closed link(s) out of "
                f"{len(affected_link_ids)} adjusted — attempting local redistribution ..."
            )
        else:
            print(
                f"      (c)   {len(affected_link_ids)} adjusted link(s), "
                "none closed — all affected pairs will be fully re-routed."
            )

        redistributed_fc, pairs_to_recompute = _redistribute_routes(
            routes_fc=routes_fc,
            affected_link_ids=affected_link_ids,
            closed_link_ids=closed_link_ids,
            zones_fc=zones_fc,
        )

        n_redist = len(redistributed_fc.get("features", []))
        n_rerout = len(pairs_to_recompute)

        if n_redist:
            print(f"      (c)   {n_redist} pair(s) resolved locally (redistribution/evaporation).")
        if n_rerout:
            print(f"      (c)   {n_rerout} pair(s) require full re-routing ...")
            full_recomputed_fc = recompute_routes_for_pairs(
                network_fc=network_fc,
                feedlinks_fc=feedlinks_fc,
                zones_fc=zones_fc,
                pairs=pairs_to_recompute,
                bottleneck_edges=bottleneck_edges,
            )
            # recompute_routes_for_pairs does not set originProduction; restore
            # it from the base ROUTES file so the merged output keeps the correct
            # value and satisfies the frontend's originProduction > 0 invariant.
            full_recomputed_fc = _restore_origin_productions(full_recomputed_fc, routes_fc)
            print(f"      (c)   {len(full_recomputed_fc.get('features', []))} pair(s) re-routed.")

            # Pairs for which recompute_routes_for_pairs found no alternative
            # path at all (fully blocked in the adjusted network) are silently
            # omitted by that function.  Without further action the original
            # stale route — which still traverses the now-closed link(s) — would
            # remain unchanged in the final ROUTES output.  Evaporate them instead.
            evaporated_features = _evaporate_unroutable_pairs(
                pairs_to_recompute, full_recomputed_fc, routes_fc
            )
            if evaporated_features:
                print(
                    f"      (c)   {len(evaporated_features)} pair(s) had no viable "
                    "alternative route — evaporated."
                )
                full_recomputed_fc = {
                    "type": "FeatureCollection",
                    "features": [
                        *full_recomputed_fc.get("features", []),
                        *evaporated_features,
                    ],
                }
        else:
            full_recomputed_fc = {"type": "FeatureCollection", "features": []}
            if not n_redist:
                print("      (c)   No existing pairs use the adjusted links.")

        recomputed_fc = {
            "type": "FeatureCollection",
            "features": [
                *redistributed_fc.get("features", []),
                *full_recomputed_fc.get("features", []),
            ],
        }
    else:
        print("      (c)   SKIPPED — no link adjustments.")

    # ------------------------------------------------------------------
    # [3d/7] Re-route pairs whose routes reference links that no longer
    #        exist in the network (e.g. links split by network_link_inserter).
    #        These pairs must be fully re-routed regardless of any explicit
    #        capacity/speed changes.
    # ------------------------------------------------------------------
    _net_link_ids: set[str] = {
        str((f.get("properties") or {}).get("linkId") or "") for f in network_fc.get("features", [])
    }
    _net_link_ids.discard("")

    _orphan_link_ids: set[str] = {
        lid
        for feat in routes_fc.get("features", [])
        for route in (feat.get("properties") or {}).get("routes") or []
        for lid in (route.get("linkPath") or [])
        if lid not in _net_link_ids
    }

    if _orphan_link_ids:
        # Pairs already handled by step (c) need not be re-routed again.
        _handled_keys: set[tuple[str, str, str, str]] = {
            (
                str((f.get("properties") or {}).get("fromZoneId") or ""),
                str((f.get("properties") or {}).get("toZoneId") or ""),
                str((f.get("properties") or {}).get("fromType") or "zone"),
                str((f.get("properties") or {}).get("toType") or "zone"),
            )
            for f in recomputed_fc.get("features", [])
        }
        _orphan_pairs = [
            p
            for p in _find_pairs_using_links(routes_fc, _orphan_link_ids)
            if (p["fromId"], p["toId"], p["fromType"], p["toType"]) not in _handled_keys
        ]
        if _orphan_pairs:
            print(
                f"      (d)   {len(_orphan_link_ids)} removed link(s) found in existing routes — "
                f"re-routing {len(_orphan_pairs)} pair(s) through new topology ..."
            )
            _orphan_recomputed_fc = recompute_routes_for_pairs(
                network_fc=network_fc,
                feedlinks_fc=feedlinks_fc,
                zones_fc=zones_fc,
                pairs=_orphan_pairs,
                bottleneck_edges=bottleneck_edges,
            )
            _orphan_recomputed_fc = _restore_origin_productions(_orphan_recomputed_fc, routes_fc)
            print(
                f"      (d)   {len(_orphan_recomputed_fc.get('features', []))} pair(s) re-routed."
            )
            recomputed_fc = {
                "type": "FeatureCollection",
                "features": [
                    *recomputed_fc.get("features", []),
                    *_orphan_recomputed_fc.get("features", []),
                ],
            }
        else:
            print(
                f"      (d)   {len(_orphan_link_ids)} removed link(s) found — all pairs already handled."
            )
    else:
        print("      (d)   SKIPPED — all route link-paths are valid in the current network.")

    # ------------------------------------------------------------------
    # [4/7] Re-compute routes → build revised ROUTES file
    # ------------------------------------------------------------------
    print("[4/7] Updating ROUTES file ...")

    # Build an index of existing route keys so tombstone features that don't
    # match any existing pair are silently dropped rather than appended as junk.
    existing_route_keys: set[tuple[str, str, str, str]] = {
        (
            str((f.get("properties") or {}).get("fromZoneId") or ""),
            str((f.get("properties") or {}).get("toZoneId") or ""),
            str((f.get("properties") or {}).get("fromType") or "zone"),
            str((f.get("properties") or {}).get("toType") or "zone"),
        )
        for f in (routes_fc.get("features") or [])
    }

    def _od_key(feat: dict) -> tuple[str, str, str, str]:
        p = feat.get("properties") or {}
        return (
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId") or ""),
            str(p.get("fromType") or "zone"),
            str(p.get("toType") or "zone"),
        )

    # Keep a feature if it has actual routes (non-empty) OR if it replaces a pair
    # that already exists in the base ROUTES file (tombstone replacing old routes).
    od_fc_for_merge_feats = [
        f
        for f in (od_fc.get("features") or [])
        if (f.get("properties") or {}).get("routes") or _od_key(f) in existing_route_keys
    ]
    od_fc_for_merge: dict = {**od_fc, "features": od_fc_for_merge_feats}

    updates: list[dict] = []
    if recomputed_fc.get("features"):
        updates.append(recomputed_fc)
    if od_fc_for_merge.get("features"):
        updates.append(od_fc_for_merge)
        n_new = sum(1 for f in od_fc_for_merge_feats if (f.get("properties") or {}).get("routes"))
        n_removed = len(od_fc_for_merge_feats) - n_new
        if n_new:
            print(f"      Adding {n_new} node/zone-adjustment pair(s).")
        if n_removed:
            print(f"      Removing {n_removed} existing pair(s) (production/attraction zeroed).")
    if od_adjusted_fc.get("features"):
        updates.append(od_adjusted_fc)
        print(f"      Updating {len(od_adjusted_fc['features'])} OD-pair direct adjustment(s).")

    if updates:
        updated_routes_fc = merge_routes(routes_fc, *updates)
        print(
            f"      ROUTES: {len(updated_routes_fc.get('features', []))} total pairs "
            f"(was {len(routes_fc.get('features', []))})."
        )
    else:
        updated_routes_fc = routes_fc
        print("      No ROUTES changes required.")

    # ------------------------------------------------------------------
    # [5/7] Apply flow delta to the NETWORK file
    #
    # Compute the per-link (flow_before, flow_after) from local route trips,
    # then add the delta proportionally to all flow sub-fields (flow, flow24hrs,
    # flowsPerDaypart, flowsPerMotive).  The base flow (Databricks source data)
    # is preserved; only the local route contribution is adjusted.
    # ------------------------------------------------------------------
    print("[5/7] Applying flow delta to NETWORK ...")
    od_fc_for_delta: dict = {
        "type": "FeatureCollection",
        "features": [
            *(od_fc.get("features") or []),
            *(od_adjusted_fc.get("features") or []),
        ],
    }
    # od_flow_delta_fc carries the before/after fractions for flow-adjusted pairs;
    # it is passed as an *extra_od_fc* so that the delta propagates to all links
    # on the affected routes (not only to the directly targeted link).
    # NOTE: original_routes_fc (pre-[2c]) is used as old_routes_fc so that the
    # "before" flow correctly reflects the state before any flow adjustments.
    #
    # Node/zone adjustments given as a relative delta ("+191"/"-50") must only
    # ADD their incremental flow on top of a pair's existing routes, not
    # replace it — only an absolute adjustment (e.g. "500", or "0" for a
    # tombstone) is meant to fully replace the pair's prior flow.
    relative_origin_ids: set[str] = set()
    for entry in node_adjustments:
        origin_id = str(entry.get("zoneId") or entry.get("nodeId") or "").strip()
        if not origin_id:
            continue
        prod_str = str(entry.get("production") or "").strip()
        attr_str = str(entry.get("attraction") or "").strip()
        if prod_str.startswith(("+", "-")) or attr_str.startswith(("+", "-")):
            relative_origin_ids.add(origin_id)

    delta = _compute_link_flow_delta(
        original_routes_fc,
        recomputed_fc,
        od_fc_for_delta,
        zones_fc,
        od_flow_delta_fc,
        relative_origin_ids=relative_origin_ids,
    )

    # Filter out links whose absolute change is below the threshold
    if min_link_trips > 0.0:
        delta = {lid: (fb, fa) for lid, (fb, fa) in delta.items() if abs(fa - fb) >= min_link_trips}

    adjusted_fc, report = _apply_flow_delta(network_fc, delta)
    print(f"      {len(report)} link(s) updated.")

    if debug:
        _print_flow_report(report)

    # ------------------------------------------------------------------
    # Write outputs
    # ------------------------------------------------------------------
    ensure_folder(output_folder)

    out_network = join_uri(output_folder, f"{new_area_id}-NETWORK-{mode}.parquet")
    out_zones = join_uri(output_folder, f"{new_area_id}-ZONE-{mode}.parquet")
    out_feedlinks = join_uri(output_folder, f"{new_area_id}-FEEDLINK-{mode}.parquet")
    out_routes = join_uri(output_folder, f"{new_area_id}-ROUTES-{routes_mode}.parquet")

    # Stamp all output FeatureCollections with the new areaId and baseAreaId
    zones_fc_out = _stamp_area_ids(zones_fc, new_area_id, area_id, name=scenario_name)
    feedlinks_fc_out = _stamp_area_ids(feedlinks_fc, new_area_id, area_id, name=scenario_name)
    adjusted_fc_out = _stamp_area_ids(adjusted_fc, new_area_id, area_id, name=scenario_name)
    routes_fc_out = _stamp_area_ids(updated_routes_fc, new_area_id, area_id, name=scenario_name)

    write_uri(out_network, to_geoparquet(adjusted_fc_out))
    write_uri(out_zones, to_geoparquet(zones_fc_out))
    write_uri(out_feedlinks, to_geoparquet(feedlinks_fc_out))
    write_uri(out_routes, to_geoparquet(routes_fc_out))

    # ------------------------------------------------------------------
    # [7/7] Compare (opt-in via compare=True)
    # ------------------------------------------------------------------
    if compare:
        from compare_networks.core.compare_networks_core import compare_networks

        print("[7/7] compare_networks (bandwidths) ...")
        compare_fc = compare_networks(
            network_fc,
            adjusted_fc,
            fields=["flow"],
            as_bandwidths=True,
            bandwidth_scale=0.01,
            exclude_unchanged=True,
        )
        out_compare = join_uri(output_folder, f"{new_area_id}-COMPARE-{mode}.geojson")
        write_uri(
            out_compare,
            json.dumps(compare_fc, ensure_ascii=False).encode(),
            content_type="application/geo+json",
        )
        print(f"      Bandwidth comparison written: {_uri_name(out_compare)}")
    else:
        out_compare = None
        print("[7/7] compare_networks ... SKIPPED (use --compare to enable)")

    print()
    print("============================================================")
    print(" Adjustment pipeline complete.")
    print(f" Output folder     : {output_folder}")
    print(f" Network           : {_uri_name(out_network)}")
    print(f" Zones             : {_uri_name(out_zones)}")
    print(f" Feedlinks         : {_uri_name(out_feedlinks)}")
    print(f" Routes            : {_uri_name(out_routes)}")
    if out_compare is not None:
        print(f" Compare           : {_uri_name(out_compare)}")
    print("============================================================")

    return new_area_id
