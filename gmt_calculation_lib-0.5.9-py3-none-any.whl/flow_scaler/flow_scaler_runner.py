"""Local debug runner for flow_scaler.

Calls the flow_scaler pipeline (core + segments) directly — no Lambda handler involved.
Mode and area-id are derived automatically from the network file's properties.

Usage
-----
    python -m flow_scaler.flow_scaler_runner \\
        --network s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.geojson \\
        --purpose-index s3://gmp-networks/indices/purpose_index.json \\
        --daylight-index s3://gmp-networks/indices/daylight.json \\
        --date 2025-06-21T09:00:00Z \\
        --output-folder s3://gmp-networks/scaled/

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for flow_scaler (calls core pipeline directly)."
    )

    # Network and index file locations (all required, all full URIs)
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="Full URI for the input network GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--purpose-index",
        required=True,
        metavar="URI",
        help="Full URI for purpose_index.json (s3:// or local path).",
    )
    parser.add_argument(
        "--daylight-index",
        required=True,
        metavar="URI",
        help="Full URI for daylight.json (s3:// or local path).",
    )
    parser.add_argument(
        "--holiday-index",
        default="s3://gmp-networks/indices/holiday_indices.csv",
        metavar="URI",
        help="Full URI for holiday_indices.csv (s3:// or local path).",
    )

    # Scaling parameters
    parser.add_argument("--date",        default=None,     help="ISO-8601 datetime, e.g. 2025-01-14T08:00:00Z.")
    parser.add_argument("--temperature", default="medium", help="high / medium / low (default: medium).")
    parser.add_argument("--weather",     default="cloudy", help="sunny / cloudy / dry / rainy (default: cloudy).")
    parser.add_argument(
        "--purpose", default="all",
        help="work / education / shopping / recreational / unknown / all (default: all).",
    )
    parser.add_argument(
        "--bbox", nargs=4, type=float, default=None,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box filter as four floats.",
    )
    parser.add_argument("--limit",  type=int, default=100, help="Page size (default: 100).")
    parser.add_argument("--offset", type=int, default=0,   help="Page offset (default: 0).")
    parser.add_argument(
        "--run-cleaner", action=argparse.BooleanOptionalAction, default=True,
        help=(
            "Strip all feature properties except flow and linkId after scaling "
            "(default: enabled).  Pass --no-run-cleaner to retain all properties."
        ),
    )

    # Output
    parser.add_argument(
        "--output-folder", metavar="URI", default=None,
        help="Output folder URI (s3://bucket/prefix/ or local dir). File named {area_id}-SCALED-NETWORK-{mode}.geojson.",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    output_uri = None  # resolved later after mode/area_id are known

    # Imports (after sys.path is set)
    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from flow_scaler.core.flow_scaler_core import (
        Params,
        applyIndices,
        determineIndiceKeys,
        filterNetwork,
        load_purpose_index,
        normalise_temperature,
        normalise_weather,
        parse_date,
        read_indexes,
    )

    # 1. Read inputs
    print(f"Reading network       : {args.network}")
    network = from_geoparquet(_read_uri(args.network))

    net_modes = (network.get("properties") or {}).get("modes") or []
    if not net_modes:
        parser.error("Network has no 'modes' property — cannot derive transport mode.")
    mode = net_modes[0]
    print(f"Mode                  : {mode}")

    # Resolve area_id from network properties
    area_id = (network.get("properties") or {}).get("area_id")
    if not area_id:
        from uuid import uuid4
        area_id = str(uuid4())
        print(f"area_id auto-generated: {area_id}")

    from gmt_shared.output_path import build_output_path

    print(f"Reading purpose index : {args.purpose_index}")
    purpose_index_raw = json.loads(_read_uri(args.purpose_index))

    print(f"Reading daylight      : {args.daylight_index}")
    daylight_raw = json.loads(_read_uri(args.daylight_index))

    # 2. Pure pipeline
    dt          = parse_date(args.date)
    temperature = normalise_temperature(args.temperature)
    weather     = normalise_weather(args.weather, dt, daylight_raw)
    purpose     = None if args.purpose.lower() == "all" else args.purpose.lower()

    purpose_index = load_purpose_index(purpose_index_raw)

    params = Params(
        mode=mode,
        dt=dt,
        temperature=temperature,
        weather=weather,
        regio=(network.get("properties") or {}).get("region") or "",
        purpose=purpose,
        holiday_index=args.holiday_index,
    )

    filtered        = filterNetwork(network, args.bbox, args.offset, args.limit)
    filtered.params = params
    keys            = determineIndiceKeys(params, filtered.metadata)
    indexes         = read_indexes(keys, purpose_index)
    result          = applyIndices(filtered, indexes, run_cleaner=args.run_cleaner)

    result["properties"] = {
        "mode":        mode,
        "date":        args.date or None,
        "temperature": temperature,
        "weather":     weather,
        "purpose":     args.purpose,
        "limit":       args.limit,
        "offset":      args.offset,
    }

    n_features = len(result.get("features", []))
    print(f"\nScaled features : {n_features}")

    # 3. Write output
    if args.output_folder:
        output_uri = build_output_path(args.output_folder, area_id, "SCALED-NETWORK", mode)
    else:
        output_uri = args.network
    print(f"Writing         : {output_uri}")
    _write_uri(output_uri, to_geoparquet(result))

    print()
    print(f"Mode        : {mode}")
    print(f"Date        : {args.date or '(none)'}")
    print(f"Temperature : {temperature}")
    print(f"Weather     : {weather}")
    print(f"Purpose     : {args.purpose}")


if __name__ == "__main__":
    main()
