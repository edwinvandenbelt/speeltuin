"""
Smoke tests for the flow-scaler core pipeline.

The tests exercise the complete calculation pipeline (filterNetwork →
determineIndiceKeys → read_indexes → applyIndices) via a thin
``_run_pipeline`` helper that mirrors the Lambda handler contract, but
without any AWS / Lambda infrastructure dependency.

Run with:  pytest tests/test_smoke.py -v
"""
from __future__ import annotations

from urllib.parse import parse_qs, urlencode, urlparse, urlunparse

import pytest

from flow_scaler.core.flow_scaler_core import (
    Params,
    applyIndices,
    filterNetwork,
    load_purpose_index,
    normalise_temperature,
    normalise_weather,
    parse_date,
    resolve_indexes_by_mode,
)

# ---------------------------------------------------------------------------
# _run_pipeline: mirrors the Lambda handler interface using core functions
# ---------------------------------------------------------------------------

def _build_href(base_url: str, offset: int, limit: int) -> str:
    """Build a pagination URL by replacing offset/limit query params."""
    parsed = urlparse(base_url)
    params = parse_qs(parsed.query, keep_blank_values=True)
    params["offset"] = [str(offset)]
    params["limit"] = [str(limit)]
    new_query = urlencode({k: v[0] for k, v in sorted(params.items())})
    return urlunparse(parsed._replace(query=new_query))


def _run_pipeline(event: dict, _context: object = None) -> dict:
    """Run the full flow-scaler pipeline using core functions directly.

    Accepts the same event shape as the Lambda handler in direct-invocation
    mode:
        network            – list of GeoJSON Feature dicts
        indices            – {"purpose_index": [...], "daylight": [...]}
        mode, date, temperature, weather, purpose, bbox, limit, offset,
        base_url, regio, holiday_index_uri, run_cleaner
    """
    network_list = event.get("network", [])
    network: dict = {"type": "FeatureCollection", "features": network_list}

    indices: dict = event.get("indices", {})
    purpose_index_raw: list = indices.get("purpose_index", [])
    daylight_raw: list = indices.get("daylight", [])

    mode: str = str(event.get("mode", "CAR")).upper()
    date_str: str | None = event.get("date")
    temperature_raw: str = str(event.get("temperature", "medium"))
    weather_raw: str = str(event.get("weather", "cloudy"))
    purpose_raw: str | None = event.get("purpose")
    bbox: list[float] | None = event.get("bbox")
    limit: int = int(event.get("limit", 100))
    offset: int = int(event.get("offset", 0))
    base_url: str | None = event.get("base_url")
    # Default run_cleaner=False so that all computed properties survive
    run_cleaner: bool = bool(event.get("run_cleaner", False))
    regio: str = str(event.get("regio", "midden"))
    holiday_index_uri: str = str(event.get("holiday_index_uri", ""))

    # Core pipeline
    dt = parse_date(date_str)
    normalised_temp = normalise_temperature(temperature_raw)
    normalised_weather = normalise_weather(weather_raw, dt, daylight_raw)
    purpose_norm: str | None = (
        None
        if (not purpose_raw or str(purpose_raw).lower() == "all")
        else str(purpose_raw).lower()
    )
    purpose_index = load_purpose_index(purpose_index_raw)

    params = Params(
        mode=mode,
        dt=dt,
        temperature=normalised_temp,
        weather=normalised_weather,
        regio=regio,
        purpose=purpose_norm,
        holiday_index=holiday_index_uri,
    )

    filtered = filterNetwork(network, bbox, offset, limit)
    filtered.params = params
    indexes_by_mode = resolve_indexes_by_mode(params, filtered, purpose_index)
    result = applyIndices(filtered, indexes_by_mode, run_cleaner=run_cleaner)

    # Enrich result properties with request context (matches handler output)
    result.setdefault("properties", {}).update({
        "mode": mode,
        "date": date_str,
        "temperature": normalised_temp,
        "weather": normalised_weather,
        "purpose": purpose_raw or "all",
        "limit": limit,
        "offset": offset,
    })

    # Pagination links
    if base_url:
        number_matched = filtered.metadata.number_matched
        number_returned = filtered.metadata.number_returned
        more_pages = offset + number_returned < number_matched
        links = []
        if offset > 0:
            prev_offset = max(0, offset - limit)
            links.append({"rel": "prev", "href": _build_href(base_url, prev_offset, limit)})
        if more_pages:
            links.append({"rel": "next", "href": _build_href(base_url, offset + limit, limit)})
        if links:
            result["links"] = links

    return result


# Alias so all test classes call ``handler(event, None)`` unchanged
handler = _run_pipeline


# ---------------------------------------------------------------------------
# Shared fixtures
# ---------------------------------------------------------------------------

def _make_feature(
    seg_id: str = "seg_001",
    lon: float = 4.9,
    lat: float = 52.3,
    length: float = 500.0,
    cap_heen: int = 1800,
    cap_terug: int = 1800,
    max_heen: int = 100,
    max_terug: int = 100,
    rij_heen: int = 2,
    rij_terug: int = 2,
    flow_heen: dict | None = None,
    flow_terug: dict | None = None,
) -> dict:
    if flow_heen is None:
        flow_heen = {"work": 100.0, "education": 50.0, "shopping": 30.0,
                     "recreational": 20.0, "unknown": 10.0}
    if flow_terug is None:
        flow_terug = {"work": 80.0, "education": 40.0, "shopping": 20.0,
                      "recreational": 15.0, "unknown": 5.0}
    return {
        "type": "Feature",
        "id": seg_id,
        "geometry": {
            "type": "LineString",
            "coordinates": [[lon, lat], [lon + 0.001, lat + 0.001]],
        },
        "properties": {
            "linkId": seg_id,
            "length": length,
            "cap_heen": cap_heen,
            "cap_terug": cap_terug,
            "max_snelheid_heen": max_heen,
            "max_snelheid_terug": max_terug,
            "rijstroken_heen": rij_heen,
            "rijstroken_terug": rij_terug,
            "flow_heen": flow_heen,
            "flow_terug": flow_terug,
        },
    }


PURPOSE_INDEX = [
    {"key": "work|CAR|1|8|Medium|Cloudy Light",         "index": 2.0},
    {"key": "education|CAR|1|8|Medium|Cloudy Light",    "index": 1.5},
    {"key": "shopping|CAR|1|8|Medium|Cloudy Light",     "index": 0.8},
    {"key": "recreational|CAR|1|8|Medium|Cloudy Light", "index": 0.5},
    {"key": "unknown|CAR|1|8|Medium|Cloudy Light",      "index": 1.0},
]

# 2025-01-13 is a Monday → java_day=1; 07:00Z = 08:00 CET (UTC+1) → hour=8
BASE_EVENT = {
    "mode": "CAR",
    "date": "2025-01-13T07:00:00Z",
    "temperature": "medium",
    "weather": "cloudy",
    "purpose": "all",
    "limit": 100,
    "offset": 0,
    "base_url": "https://api.example.com/collections/segments/items",
    "indices": {
        "purpose_index": PURPOSE_INDEX,
        "daylight": [{"month": 1, "sunrise_hour": 8, "sunset_hour": 17}],
    },
}


# ---------------------------------------------------------------------------
# Test 1: Basic response structure
# ---------------------------------------------------------------------------

class TestResponseStructure:
    def test_type_is_feature_collection(self):
        event = {**BASE_EVENT, "network": [_make_feature()]}
        result = handler(event, None)
        assert result["type"] == "FeatureCollection"

    def test_crs_present(self):
        event = {**BASE_EVENT, "network": [_make_feature()]}
        result = handler(event, None)
        assert result["crs"]["properties"]["name"] == "EPSG:4326"

    def test_number_matched_returned(self):
        features = [_make_feature(f"seg_{i}", lon=4.9 + i * 0.001) for i in range(5)]
        event = {**BASE_EVENT, "network": features}
        result = handler(event, None)
        assert result["number_matched"] == 5
        assert result["number_returned"] == 5

    def test_features_list_present(self):
        event = {**BASE_EVENT, "network": [_make_feature()]}
        result = handler(event, None)
        assert isinstance(result["features"], list)
        assert len(result["features"]) == 1


# ---------------------------------------------------------------------------
# Test 2: addValues — directional → unified
# ---------------------------------------------------------------------------

class TestAddValues:
    def test_capacity_summed(self):
        event = {**BASE_EVENT, "network": [_make_feature(cap_heen=1800, cap_terug=1800)]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["capacity"] == 3600

    def test_max_speed(self):
        event = {**BASE_EVENT, "network": [_make_feature(max_heen=100, max_terug=80)]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["speed"] == 100

    def test_lanes_summed(self):
        event = {**BASE_EVENT, "network": [_make_feature(rij_heen=2, rij_terug=2)]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["lanes"] == 4

    def test_raw_fields_stripped(self):
        event = {**BASE_EVENT, "network": [_make_feature()]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        for key in ("cap_heen", "cap_terug", "max_snelheid_heen",
                    "max_snelheid_terug", "rijstroken_heen", "rijstroken_terug"):
            assert key not in props, f"{key} should be stripped"


# ---------------------------------------------------------------------------
# Test 3: Flow calculation
# ---------------------------------------------------------------------------

class TestFlow:
    def test_flow_attributes_present(self):
        event = {**BASE_EVENT, "network": [_make_feature()]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        for attr in ("flow", "flowWork", "flowEducation", "flowShopping",
                     "flowRecreational", "flowUnknown", "kilometers", "flowTemporalUnit"):
            assert attr in props, f"Missing attribute: {attr}"
        assert "flowTotal" not in props, "flowTotal must not be in output"

    def test_flow_temporal_unit_is_1(self):
        event = {**BASE_EVENT, "network": [_make_feature()]}
        result = handler(event, None)
        for f in result["features"]:
            assert f["properties"]["flowTemporalUnit"] == 1

    def test_flow_not_exact_zero(self):
        """flow == 0 should be replaced with 1e-5 (Java mirror)."""
        event = {
            **BASE_EVENT,
            "network": [_make_feature(
                flow_heen={"work": 0.0},
                flow_terug={"work": 0.0},
            )],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["flow"] == pytest.approx(1e-5)

    def test_flow_indexed(self):
        """flow should use the index factor from purpose_index."""
        # work: (100 + 80) * 2.0 = 360.0
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **BASE_EVENT,
            "purpose": "work",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["flow"] == pytest.approx(360.0)
        assert props["flowWork"] == pytest.approx(360.0)

    def test_kilometers_computed(self):
        """kilometers = (length / 1000) * flow."""
        fh = {"work": 100.0}
        ft = {"work": 0.0}
        event = {
            **BASE_EVENT,
            "purpose": "work",
            "network": [_make_feature(length=1000.0, flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        # flow = 100 * 2.0 = 200; kilometers = 1.0 * 200 = 200
        assert props["kilometers"] == pytest.approx(200.0)

    def test_raw_flow_maps_stripped(self):
        event = {**BASE_EVENT, "network": [_make_feature()]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert "flow_heen" not in props
        assert "flow_terug" not in props

    def test_all_five_motives_always_present(self):
        """All 5 known motive attributes must be present even if flow=0."""
        event = {
            **BASE_EVENT,
            "network": [_make_feature(
                flow_heen={"work": 100.0},
                flow_terug={"work": 50.0},
            )],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        for attr in ("flowWork", "flowEducation", "flowShopping",
                     "flowRecreational", "flowUnknown"):
            assert attr in props

    def test_no_date_uses_raw_flow(self):
        """When date=None, no index is applied; raw flows are summed."""
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **{k: v for k, v in BASE_EVENT.items() if k != "date"},
            "date": None,
            "purpose": "work",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        # No index: flow = 100 + 80 = 180
        assert props["flow"] == pytest.approx(180.0)


# ---------------------------------------------------------------------------
# Test 4: Bbox filtering
# ---------------------------------------------------------------------------

class TestBboxFilter:
    def test_inside_bbox_included(self):
        feature = _make_feature(lon=4.9, lat=52.3)
        event = {**BASE_EVENT, "network": [feature], "bbox": [4.8, 52.2, 5.0, 52.4]}
        result = handler(event, None)
        assert result["number_matched"] == 1

    def test_outside_bbox_excluded(self):
        feature = _make_feature(lon=4.9, lat=52.3)
        event = {**BASE_EVENT, "network": [feature], "bbox": [5.5, 53.0, 6.0, 54.0]}
        result = handler(event, None)
        assert result["number_matched"] == 0

    def test_no_bbox_returns_all(self):
        features = [_make_feature(f"seg_{i}", lon=4.0 + i) for i in range(3)]
        event = {**BASE_EVENT, "network": features}
        result = handler(event, None)
        assert result["number_matched"] == 3


# ---------------------------------------------------------------------------
# Test 5: Pagination
# ---------------------------------------------------------------------------

class TestPagination:
    def test_limit_and_offset(self):
        features = [_make_feature(f"seg_{i}", lon=4.9, lat=52.3 + i * 0.001)
                    for i in range(10)]
        event = {**BASE_EVENT, "network": features, "limit": 3, "offset": 2}
        result = handler(event, None)
        assert result["number_matched"] == 10
        assert result["number_returned"] == 3

    def test_next_link_present_when_more_pages(self):
        features = [_make_feature(f"seg_{i}", lon=4.9, lat=52.3 + i * 0.001)
                    for i in range(10)]
        event = {**BASE_EVENT, "network": features, "limit": 3, "offset": 0}
        result = handler(event, None)
        assert "links" in result
        assert any(lnk["rel"] == "next" for lnk in result["links"])

    def test_no_next_link_on_last_page(self):
        features = [_make_feature(f"seg_{i}", lon=4.9, lat=52.3 + i * 0.001)
                    for i in range(5)]
        event = {**BASE_EVENT, "network": features, "limit": 10, "offset": 0}
        result = handler(event, None)
        assert "links" not in result or not any(
            lnk["rel"] == "next" for lnk in result.get("links", [])
        )

    def test_next_link_href_has_correct_offset(self):
        features = [_make_feature(f"seg_{i}", lon=4.9, lat=52.3 + i * 0.001)
                    for i in range(10)]
        event = {**BASE_EVENT, "network": features, "limit": 3, "offset": 0}
        result = handler(event, None)
        next_link = next(lnk for lnk in result["links"] if lnk["rel"] == "next")
        assert "offset=3" in next_link["href"]


# ---------------------------------------------------------------------------
# Test 6: Holiday remapping
# ---------------------------------------------------------------------------

class TestHoliday:
    def test_holiday_remaps_monday_to_saturday(self, monkeypatch):
        """With is_holiday_period returning True on a Monday, day becomes 6 (Saturday).
        The index key changes; if no key found, raw flow is used."""
        monkeypatch.setattr(
            "flow_scaler.core.flow_scaler_core.is_holiday_period", lambda *_, **__: True
        )
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **BASE_EVENT,
            "purpose": "work",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        # Saturday key "work|CAR|6|8|Medium|Cloudy Light" is not in PURPOSE_INDEX
        # → no factor, raw flow used → 180.0
        assert props["flow"] == pytest.approx(180.0)

    def test_no_holiday_uses_monday_key(self, monkeypatch):
        """Without holiday, Monday (day=1) key is found → index applied."""
        monkeypatch.setattr(
            "flow_scaler.core.flow_scaler_core.is_holiday_period", lambda *_, **__: False
        )
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **BASE_EVENT,
            "purpose": "work",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["flow"] == pytest.approx(360.0)  # 180 * 2.0


# ---------------------------------------------------------------------------
# Test 7: UTC → Amsterdam timezone conversion in parse_date
# ---------------------------------------------------------------------------

class TestTimezoneConversion:
    """parse_date must convert UTC timestamps to Amsterdam local time so that
    .hour and .weekday() reflect Dutch local time when building index keys."""

    def test_utc_offset_used_for_hour_lookup(self):
        """2025-06-21T05:00:00Z is 07:00 CEST (UTC+2) on a Saturday.
        The index key should use hour=7; the factor must be applied."""
        # Saturday (java_day=6), CEST hour=7
        summer_index = [
            {"key": "work|CAR|6|7|Medium|Cloudy Light", "index": 3.0},
        ]
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **BASE_EVENT,
            "date": "2025-06-21T05:00:00Z",  # UTC 05:00 = Amsterdam 07:00 (CEST)
            "purpose": "work",
            "weather": "cloudy",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
            "indices": {
                **BASE_EVENT["indices"],
                "purpose_index": summer_index,
            },
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        # flow = (100 + 80) * 3.0 = 540 — proves hour=7 (local) was used, not hour=5 (UTC)
        assert props["flow"] == pytest.approx(540.0), (
            "Index was not applied — parse_date likely used UTC hour (5) instead of "
            "Amsterdam local hour (7)"
        )
        assert props["index"] == pytest.approx(3.0)

    def test_utc_naive_datetime_treated_as_local(self):
        """A naïve datetime string (no Z / offset) is treated as Amsterdam local
        time and returned unchanged — hour=8 on a Monday finds the index row."""
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **BASE_EVENT,
            "date": "2025-01-13T08:00:00",  # naïve — treated as CET 08:00
            "purpose": "work",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["flow"] == pytest.approx(360.0)  # 180 * 2.0

    def test_explicit_offset_converted_to_local(self):
        """A +02:00 offset timestamp is equivalent to the same UTC value —
        2025-06-21T07:00:00+02:00 = 05:00 UTC = 07:00 CEST, same as the Z test."""
        summer_index = [
            {"key": "work|CAR|6|7|Medium|Cloudy Light", "index": 3.0},
        ]
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **BASE_EVENT,
            "date": "2025-06-21T07:00:00+02:00",
            "purpose": "work",
            "weather": "cloudy",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
            "indices": {
                **BASE_EVENT["indices"],
                "purpose_index": summer_index,
            },
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["flow"] == pytest.approx(540.0)
        assert props["index"] == pytest.approx(3.0)

    def test_custom_timezone_parameter(self):
        """parse_date accepts a custom tz argument; the returned hour reflects
        that timezone, not Amsterdam."""
        from zoneinfo import ZoneInfo

        from flow_scaler.core.flow_scaler_core import parse_date

        # 2025-06-21T05:00:00Z = 07:00 CEST = 13:00 JST (UTC+8)
        dt_amsterdam = parse_date("2025-06-21T05:00:00Z")
        dt_tokyo     = parse_date("2025-06-21T05:00:00Z", tz=ZoneInfo("Asia/Tokyo"))

        assert dt_amsterdam is not None
        assert dt_tokyo is not None
        assert dt_amsterdam.hour == 7   # CEST (UTC+2)
        assert dt_tokyo.hour     == 14  # JST  (UTC+9)


# ---------------------------------------------------------------------------
# Test 7b: index property
# ---------------------------------------------------------------------------

class TestIndex:
    """The 'index' property must reflect the true scaling factor applied."""

    def test_index_present_on_every_feature(self):
        """Every output feature must have an 'index' property."""
        event = {**BASE_EVENT, "network": [_make_feature()]}
        result = handler(event, None)
        for f in result["features"]:
            assert "index" in f["properties"], "Missing 'index' property on feature"

    def test_index_is_one_when_no_date(self):
        """When date is absent, no scaling is applied → index must be 1.0."""
        event = {
            **{k: v for k, v in BASE_EVENT.items() if k != "date"},
            "date": None,
            "network": [_make_feature()],
        }
        result = handler(event, None)
        assert result["features"][0]["properties"]["index"] == pytest.approx(1.0)

    def test_index_equals_purpose_factor_for_specific_purpose(self):
        """For purpose='work' with factor 2.0, index must be 2.0."""
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **BASE_EVENT,
            "purpose": "work",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        assert result["features"][0]["properties"]["index"] == pytest.approx(2.0)

    def test_index_is_weighted_average_for_all_purposes(self):
        """For purpose='all', index must be the flow-weighted average of per-motiv factors.

        PURPOSE_INDEX factors (for CAR, Monday, hour=8, Medium, Cloudy Light):
          work=2.0, education=1.5, shopping=0.8, recreational=0.5, unknown=1.0

        Flow (heen only, terug=0 to keep maths simple):
          work=100, education=50, shopping=20, recreational=10, unknown=20

        Weighted average = (100*2.0 + 50*1.5 + 20*0.8 + 10*0.5 + 20*1.0)
                         / (100 + 50 + 20 + 10 + 20)
                         = (200 + 75 + 16 + 5 + 20) / 200
                         = 316 / 200
                         = 1.58
        """
        fh = {"work": 100.0, "education": 50.0, "shopping": 20.0,
              "recreational": 10.0, "unknown": 20.0}
        ft = {}  # zero terug to keep calculation simple
        event = {
            **BASE_EVENT,
            "purpose": "all",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        expected = (100 * 2.0 + 50 * 1.5 + 20 * 0.8 + 10 * 0.5 + 20 * 1.0) / 200.0
        assert result["features"][0]["properties"]["index"] == pytest.approx(expected)

    def test_index_not_one_when_factors_differ(self):
        """Regression: index must NOT be 1.0 when real scaling factors are applied."""
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **BASE_EVENT,
            "purpose": "work",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        # factor for work is 2.0 — index must definitely not be 1.0
        assert result["features"][0]["properties"]["index"] != pytest.approx(1.0)

    def test_index_all_purposes_not_one_when_factors_differ(self):
        """Regression for 'all' purpose: index must NOT always be 1.0."""
        fh = {"work": 100.0, "education": 50.0}
        ft = {}
        event = {
            **BASE_EVENT,
            "purpose": "all",
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        # work=2.0, education=1.5 → weighted avg = (200+75)/150 ≈ 1.833
        assert result["features"][0]["properties"]["index"] != pytest.approx(1.0)

    def test_index_fallback_to_one_when_key_missing(self):
        """When no purpose_index key exists for the given params, index defaults to 1.0."""
        fh = {"work": 100.0}
        ft = {"work": 80.0}
        event = {
            **BASE_EVENT,
            "purpose": "work",
            # Override with an empty purpose_index so no key is found
            "indices": {"purpose_index": [], "daylight": BASE_EVENT["indices"]["daylight"]},
            "network": [_make_feature(flow_heen=fh, flow_terug=ft)],
        }
        result = handler(event, None)
        assert result["features"][0]["properties"]["index"] == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# Test 8: Weather normalisation
# ---------------------------------------------------------------------------

class TestWeatherNormalisation:
    def test_cloudy_normalised(self):
        event = {**BASE_EVENT, "weather": "cloudy", "network": [_make_feature()]}
        result = handler(event, None)
        assert result["properties"]["weather"] == "Cloudy Light"

    def test_sunny_normalised(self):
        event = {**BASE_EVENT, "weather": "sunny", "network": [_make_feature()]}
        result = handler(event, None)
        assert result["properties"]["weather"] == "Sunny Light"

    def test_missing_weather_defaults_to_cloudy(self):
        event = {k: v for k, v in BASE_EVENT.items() if k != "weather"}
        event["network"] = [_make_feature()]
        result = handler(event, None)
        assert result["properties"]["weather"] == "Cloudy Light"


# ---------------------------------------------------------------------------
# Test 8: Lane-based dataset
# ---------------------------------------------------------------------------

class TestLaneDataset:
    def test_positive_lane_uses_heen_fields(self):
        feature = _make_feature(cap_heen=1800, cap_terug=900)
        feature["properties"]["lane"] = 1  # positive → heen
        event = {**BASE_EVENT, "network": [feature]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["capacity"] == 1800

    def test_negative_lane_uses_terug_fields(self):
        feature = _make_feature(cap_heen=1800, cap_terug=900)
        feature["properties"]["lane"] = -1  # negative → terug
        event = {**BASE_EVENT, "network": [feature]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["capacity"] == 900


# ---------------------------------------------------------------------------
# Test 9: Unidirectional (intersector) format
# Features have a single 'flow' dict instead of flow_heen / flow_terug.
# ---------------------------------------------------------------------------

def _make_unidirectional_feature(
    seg_id: int = 42,
    lon: float = 4.9,
    lat: float = 52.3,
    length: float = 500.0,
    flow: dict | None = None,
) -> dict:
    """Minimal intersector-style feature: no flow_heen/flow_terug, one 'flow' dict."""
    if flow is None:
        flow = {"work": 100.0, "education": 50.0, "shopping": 30.0,
                "recreational": 20.0, "unknown": 10.0}
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [[lon, lat], [lon + 0.001, lat + 0.001]],
        },
        "properties": {
            "spectrumId": seg_id,
            "linkId":  seg_id,
            "mode":        "CAR",
            "fromNode":   1,
            "toNode":     2,
            "capacity":    1500,
            "lanes":       1,
            "speed":       50.0,
            "flowsPerMotive": flow,
            "flow":        sum(flow.values()),
            "flow24hrs": sum(flow.values()),
            "length":      length,
            "heading":     90.0,
            "reverseLinkIds": [],
        },
    }


class TestUnidirectionalFormat:
    def test_flow_attributes_present(self):
        """All standard flow attributes must be written for unidirectional features."""
        event = {**BASE_EVENT, "network": [_make_unidirectional_feature()]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        for attr in ("flow", "flowWork", "flowEducation", "flowShopping",
                     "flowRecreational", "flowUnknown", "kilometers"):
            assert attr in props, f"Missing attribute: {attr}"
        assert "flowTotal" not in props, "flowTotal must not be in output"

    def test_flow_is_scalar_not_dict(self):
        """The 'flow' output must be a scalar, not the original dict."""
        event = {**BASE_EVENT, "network": [_make_unidirectional_feature()]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert isinstance(props["flow"], float), (
            f"flow should be float, got {type(props['flow'])}"
        )

    def test_flow_total_equals_sum_of_flow_dict(self):
        """flow24hrs = sum of the input 'flow' dict values (unindexed raw total)."""
        flow = {"work": 100.0, "education": 50.0, "shopping": 30.0,
                "recreational": 20.0, "unknown": 10.0}
        event = {**BASE_EVENT, "network": [_make_unidirectional_feature(flow=flow)]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["flow24hrs"] == pytest.approx(sum(flow.values()))  # 210.0
        assert "flowTotal" not in props

    def test_flow_indexed(self):
        """Index factor must be applied to the 'flow' dict (purpose=work, factor=2.0)."""
        flow = {"work": 100.0}
        event = {
            **BASE_EVENT,
            "purpose": "work",
            "network": [_make_unidirectional_feature(flow=flow)],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["flow"] == pytest.approx(200.0)       # 100 * 2.0
        assert props["flowWork"] == pytest.approx(200.0)

    def test_no_date_uses_raw_flow(self):
        """Without a date, the raw 'flow' values are used unchanged."""
        flow = {"work": 75.0}
        event = {
            **{k: v for k, v in BASE_EVENT.items() if k != "date"},
            "date": None,
            "purpose": "work",
            "network": [_make_unidirectional_feature(flow=flow)],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["flow"] == pytest.approx(75.0)

    def test_kilometers_computed(self):
        """kilometers = (length / 1000) * flow (indexed)."""
        flow = {"work": 100.0}
        event = {
            **BASE_EVENT,
            "purpose": "work",
            "network": [_make_unidirectional_feature(flow=flow, length=2000.0)],
        }
        result = handler(event, None)
        props = result["features"][0]["properties"]
        # flow = 100 * 2.0 = 200; kilometers = 2.0 * 200 = 400
        assert props["kilometers"] == pytest.approx(400.0)

    def test_passthrough_fields_preserved(self):
        """spectrumId, linkId, capacity, lanes, speed, heading, reverseLinkIds pass through."""
        event = {**BASE_EVENT, "network": [_make_unidirectional_feature()]}
        result = handler(event, None)
        props = result["features"][0]["properties"]
        assert props["spectrumId"] == 42
        assert props["linkId"]  == 42
        assert props["capacity"]    == 1500
        assert props["lanes"]       == 1
        assert props["speed"]       == 50.0
        assert props["heading"]     == 90.0
        assert props["reverseLinkIds"] == []


# ---------------------------------------------------------------------------
# Test 10: Pagination – previous link and external URL
# ---------------------------------------------------------------------------

class TestPaginationPrevAndExternalUrl:
    """Verify previous link and that next/previous hrefs use the configured base_url."""

    def _make_features(self, n: int) -> list[dict]:
        return [_make_feature(f"seg_{i}", lon=4.9, lat=52.3 + i * 0.001) for i in range(n)]

    # --- previous link ---

    def test_prev_link_present_when_offset_gt_0(self):
        event = {**BASE_EVENT, "network": self._make_features(10),
                 "limit": 3, "offset": 3}
        result = handler(event, None)
        assert "links" in result
        assert any(lnk["rel"] == "prev" for lnk in result["links"])

    def test_prev_link_absent_on_first_page(self):
        event = {**BASE_EVENT, "network": self._make_features(10),
                 "limit": 3, "offset": 0}
        result = handler(event, None)
        assert not any(
            lnk["rel"] == "prev" for lnk in result.get("links", [])
        )

    def test_prev_link_href_has_correct_offset(self):
        """Previous page offset = current_offset - limit (= 3 - 3 = 0)."""
        event = {**BASE_EVENT, "network": self._make_features(10),
                 "limit": 3, "offset": 3}
        result = handler(event, None)
        prev_link = next(lnk for lnk in result["links"] if lnk["rel"] == "prev")
        assert "offset=0" in prev_link["href"]

    def test_prev_link_href_clamps_to_zero(self):
        """When offset < limit, previous offset must be 0 (never negative)."""
        event = {**BASE_EVENT, "network": self._make_features(10),
                 "limit": 5, "offset": 3}
        result = handler(event, None)
        prev_link = next(lnk for lnk in result["links"] if lnk["rel"] == "prev")
        assert "offset=0" in prev_link["href"]

    def test_both_prev_and_next_on_middle_page(self):
        event = {**BASE_EVENT, "network": self._make_features(10),
                 "limit": 3, "offset": 3}
        result = handler(event, None)
        rels = {lnk["rel"] for lnk in result.get("links", [])}
        assert "prev" in rels
        assert "next" in rels

    # --- external URL in hrefs ---

    def test_links_use_provided_base_url(self):
        """next and prev hrefs must be based on the supplied base_url."""
        ext_url = "https://mobilitytwin.goudappel.nl/collections/segments/items"
        event = {
            **BASE_EVENT,
            "base_url": ext_url,
            "network": self._make_features(10),
            "limit": 3,
            "offset": 3,
        }
        result = handler(event, None)
        for lnk in result.get("links", []):
            assert lnk["href"].startswith(ext_url.split("?")[0]), (
                f"Link href {lnk['href']!r} does not start with {ext_url!r}"
            )


# ---------------------------------------------------------------------------
# Mixed-modal network scaling
# ---------------------------------------------------------------------------

def _make_mixed_feature(
    seg_id: str,
    mode: str,
    flow_heen: dict | None = None,
    flow_terug: dict | None = None,
) -> dict:
    """Minimal bidirectional feature with an explicit ``mode`` property."""
    if flow_heen is None:
        flow_heen = {"work": 100.0, "unknown": 10.0}
    if flow_terug is None:
        flow_terug = {"work": 80.0, "unknown": 5.0}
    return {
        "type": "Feature",
        "id": seg_id,
        "geometry": {
            "type": "LineString",
            "coordinates": [[4.9, 52.3], [4.901, 52.301]],
        },
        "properties": {
            "linkId": seg_id,
            "mode": mode,
            "length": 500.0,
            "cap_heen": 1800,
            "cap_terug": 1800,
            "max_snelheid_heen": 100,
            "max_snelheid_terug": 100,
            "rijstroken_heen": 2,
            "rijstroken_terug": 2,
            "flow_heen": flow_heen,
            "flow_terug": flow_terug,
        },
    }


# Purpose index with distinct factors per mode:
#   CAR work → ×2.0   BIKE work → ×3.0
MIXED_PURPOSE_INDEX = [
    {"key": "work|CAR|1|8|Medium|Cloudy Light",     "index": 2.0},
    {"key": "unknown|CAR|1|8|Medium|Cloudy Light",  "index": 1.0},
    {"key": "work|BIKE|1|8|Medium|Cloudy Light",    "index": 3.0},
    {"key": "unknown|BIKE|1|8|Medium|Cloudy Light", "index": 1.0},
]

# 2025-01-13 = Monday → java_day=1, 07:00Z = 08:00 CET → hour=8
_MIXED_BASE = {
    "mode": "MIXED",
    "date": "2025-01-13T07:00:00Z",
    "temperature": "medium",
    "weather": "cloudy",
    "purpose": "work",
    "indices": {"purpose_index": MIXED_PURPOSE_INDEX, "daylight": []},
}


class TestMixedModeScaling:
    """Flow-scaler applies per-link mode indices for MIXED networks."""

    def test_car_link_gets_car_factor(self):
        """A CAR link is scaled with the CAR index (×2.0)."""
        result = _run_pipeline({
            **_MIXED_BASE,
            "network": [_make_mixed_feature("car1", "CAR", {"work": 10.0}, {"work": 0.0})],
        })
        flow = result["features"][0]["properties"]["flow"]
        assert flow == pytest.approx(10.0 * 2.0, rel=1e-6)

    def test_bike_link_gets_bike_factor(self):
        """A BIKE link is scaled with the BIKE index (×3.0)."""
        result = _run_pipeline({
            **_MIXED_BASE,
            "network": [_make_mixed_feature("bike1", "BIKE", {"work": 10.0}, {"work": 0.0})],
        })
        flow = result["features"][0]["properties"]["flow"]
        assert flow == pytest.approx(10.0 * 3.0, rel=1e-6)

    def test_car_and_bike_in_same_network_get_different_factors(self):
        """CAR and BIKE links co-existing in one MIXED network each get their own factor."""
        network = [
            _make_mixed_feature("car1",  "CAR",  {"work": 10.0}, {"work": 0.0}),
            _make_mixed_feature("bike1", "BIKE", {"work": 10.0}, {"work": 0.0}),
        ]
        result = _run_pipeline({**_MIXED_BASE, "network": network})
        flows = {f["properties"]["linkId"]: f["properties"]["flow"]
                 for f in result["features"]}
        assert flows["car1"]  == pytest.approx(10.0 * 2.0, rel=1e-6)
        assert flows["bike1"] == pytest.approx(10.0 * 3.0, rel=1e-6)

    def test_mixed_network_car_only_matches_pure_car_call(self):
        """A pure CAR network scaled via mode='MIXED' gives the same result as mode='CAR'."""
        network = [_make_mixed_feature("car1", "CAR", {"work": 10.0}, {"work": 0.0})]
        result_car   = _run_pipeline({**_MIXED_BASE, "mode": "CAR",   "network": network})
        result_mixed = _run_pipeline({**_MIXED_BASE, "mode": "MIXED", "network": network})
        assert (result_car["features"][0]["properties"]["flow"] ==
                pytest.approx(result_mixed["features"][0]["properties"]["flow"], rel=1e-6))

    def test_mode_property_preserved_on_output_feature(self):
        """The link-level ``mode`` property must survive scaling (run_cleaner=False)."""
        result = _run_pipeline({
            **_MIXED_BASE,
            "network": [_make_mixed_feature("car1", "CAR")],
            "run_cleaner": False,
        })
        assert result["features"][0]["properties"].get("mode") == "CAR"

    def test_no_date_returns_raw_flow_for_all_modes(self):
        """Without a date, no index is applied regardless of link mode."""
        network = [
            _make_mixed_feature("car1",  "CAR",  {"work": 10.0}, {"work": 5.0}),
            _make_mixed_feature("bike1", "BIKE", {"work": 10.0}, {"work": 5.0}),
        ]
        result = _run_pipeline({
            "mode": "MIXED",
            "purpose": "work",
            "indices": {"purpose_index": MIXED_PURPOSE_INDEX, "daylight": []},
            "network": network,
        })
        for feature in result["features"]:
            assert feature["properties"]["flow"] == pytest.approx(15.0, rel=1e-6)

    def test_unknown_link_mode_falls_back_to_identity(self):
        """A link with a mode not in the index gets factor=1.0 (identity)."""
        # "TRAM" → mode_key → "OV" — not in MIXED_PURPOSE_INDEX → factor=1.0
        result = _run_pipeline({
            **_MIXED_BASE,
            "network": [_make_mixed_feature("tram1", "TRAM", {"work": 10.0}, {"work": 0.0})],
        })
        flow = result["features"][0]["properties"]["flow"]
        assert flow == pytest.approx(10.0 * 1.0, rel=1e-6)
