
import pytest

import flow_scaler.core.flow_scaler_core as _checker


@pytest.fixture(autouse=True)
def _mock_holiday_csv(monkeypatch):
    """Prevent any S3 calls from is_holiday_period during flow_scaler tests.

    Patches _load_csv to return an empty list and clears the CSV cache before
    and after each test.  With no rows, is_holiday_period always returns False,
    which is equivalent to the old holiday=False default.
    """
    _checker._clear_csv_cache()
    monkeypatch.setattr(_checker, "_load_csv", lambda *_args, **_kwargs: [])
    yield
    _checker._clear_csv_cache()
