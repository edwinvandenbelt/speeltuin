"""Tests for shared.geo — point_in_polygon / is_netherlands / is_bbox_fully_in_netherlands."""

from __future__ import annotations

import pytest

from gmt_shared.geo import is_bbox_fully_in_netherlands, is_netherlands, point_in_polygon


class TestPointInPolygon:
    def test_point_inside_square(self):
        square = [[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0]]
        assert point_in_polygon(1.0, 1.0, square) is True

    def test_point_outside_square(self):
        square = [[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0]]
        assert point_in_polygon(3.0, 3.0, square) is False


class TestIsNetherlands:
    def test_centroid_well_inside_nl_is_true(self):
        # Utrecht-ish bbox, fully inside the NL outline.
        assert is_netherlands([5.0, 52.0, 5.2, 52.15]) is True

    def test_centroid_far_outside_nl_is_false(self):
        assert is_netherlands([10.0, 50.0, 10.2, 50.15]) is False

    def test_border_straddling_bbox_with_centroid_inside_is_true(self):
        # Centroid lies just inside NL even though the bbox extends past the
        # eastern border — is_netherlands only looks at the centroid.
        assert is_netherlands([6.5, 52.1, 7.0, 52.3]) is True


class TestIsBboxFullyInNetherlands:
    def test_bbox_fully_inside_nl_is_true(self):
        assert is_bbox_fully_in_netherlands([5.0, 52.0, 5.2, 52.15]) is True

    def test_bbox_fully_outside_nl_is_false(self):
        assert is_bbox_fully_in_netherlands([10.0, 50.0, 10.2, 50.15]) is False

    def test_border_straddling_bbox_is_false_even_with_centroid_inside(self):
        # Same bbox as the is_netherlands centroid-true case above: the
        # centroid is inside NL, but the east edge crosses the border, so the
        # strict corners-based check must return False.
        bbox = [6.5, 52.1, 7.0, 52.3]
        assert is_netherlands(bbox) is True
        assert is_bbox_fully_in_netherlands(bbox) is False

    # Regression: the former coarse outline cut off large parts of the country,
    # so areas like these were wrongly routed to the OSM pipeline.
    @pytest.mark.parametrize(
        ("lon", "lat"),
        [
            pytest.param(5.69, 50.85, id="Maastricht"),
            pytest.param(5.98, 50.89, id="Heerlen"),
            pytest.param(6.17, 51.37, id="Venlo"),
            pytest.param(6.89, 52.22, id="Enschede"),
            pytest.param(6.72, 51.97, id="Winterswijk"),
            pytest.param(5.30, 53.40, id="Terschelling"),
            pytest.param(4.80, 53.08, id="Texel"),
            pytest.param(3.50, 51.56, id="Domburg"),
            pytest.param(3.83, 51.33, id="Terneuzen"),
        ],
    )
    def test_dutch_towns_near_border_or_coast_are_inside(self, lon, lat):
        assert is_bbox_fully_in_netherlands([lon - 0.02, lat - 0.02, lon + 0.02, lat + 0.02])

    @pytest.mark.parametrize(
        ("lon", "lat"),
        [
            pytest.param(4.40, 51.22, id="Antwerpen"),
            pytest.param(5.79, 51.09, id="Maaseik"),
            pytest.param(6.08, 50.78, id="Aachen"),
            pytest.param(6.14, 51.79, id="Kleve"),
            pytest.param(7.04, 52.21, id="Gronau"),
            pytest.param(7.07, 52.43, id="Nordhorn"),
            pytest.param(7.21, 53.37, id="Emden"),
        ],
    )
    def test_foreign_towns_near_border_are_outside(self, lon, lat):
        assert not is_bbox_fully_in_netherlands([lon - 0.02, lat - 0.02, lon + 0.02, lat + 0.02])
