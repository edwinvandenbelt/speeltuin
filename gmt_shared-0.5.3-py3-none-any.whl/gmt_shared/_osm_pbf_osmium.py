"""pyosmium-backed scan for the local ``.osm.pbf`` backend.

Alternative to :mod:`gmt_shared._osm_pbf_scan` / :mod:`gmt_shared._osm_pbf_reader`
that lets libosmium (C++) decode the file and pre-filter entities, so only
candidate objects cross into Python.  Selector matching and bbox semantics stay
in Python (:class:`~gmt_shared._osm_ql.Selector`), so the output is identical
to the pure-Python backend.

Up to three streaming passes are made, each filtered in C++:

1. tagged entities carrying any key a selector requires (``KeyFilter``),
2. member ways of matched relations (``IdFilter``) — only if needed,
3. coordinates of every referenced node (``IdFilter``) — only if needed.

No node-location index is built, so memory stays proportional to the matched
data rather than to the size of the extract.

Public API
----------
available() -> bool
    True when ``osmium`` can be imported.
scan(path, node_sels, way_sels, rel_sels) -> OsmiumResult
    Run the passes and return everything ``fetch_from_pbf`` needs.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any, NamedTuple

from gmt_shared._osm_ql import OP_ABSENT, Selector

_MEMBER_TYPES = {"n": "NODE", "w": "WAY", "r": "RELATION"}


class OsmiumResult(NamedTuple):
    """Matched entities plus resolved geometry for :func:`fetch_from_pbf`."""

    node_elements: list[dict]
    matched_ways: dict  # id -> (tags, refs, bbox)
    matched_rels: dict  # id -> (tags, members, bbox)
    member_way_refs: dict[int, tuple[int, ...]]
    node_coords: dict[int, tuple[float, float]]  # id -> (lon, lat)


def available() -> bool:
    """Return True when pyosmium is importable."""
    try:
        import osmium  # noqa: F401
    except ImportError:
        return False
    return True


def _required_keys(selectors: list[Selector]) -> set[str] | None:
    """Keys of which at least one must be present for any selector to match.

    Returns None when some selector has no positive key filter (it could match
    any tagged object), in which case no key pre-filter can be applied.
    """
    keys: set[str] = set()
    for sel in selectors:
        positive = [f.key for f in sel.filters if f.op != OP_ABSENT]
        if not positive:
            return None
        # Any one positive key is a valid necessary condition; take the first.
        keys.add(positive[0])
    return keys


def _match(selectors: list[Selector], tags: dict) -> Selector | None:
    for sel in selectors:
        if sel.matches(tags):
            return sel
    return None


def _in_bbox(lon: float, lat: float, bbox: tuple[float, float, float, float] | None) -> bool:
    if bbox is None:
        return True
    south, west, north, east = bbox
    return west <= lon <= east and south <= lat <= north


def scan(
    path: Path,
    node_sels: list[Selector],
    way_sels: list[Selector],
    rel_sels: list[Selector],
) -> OsmiumResult:
    """Evaluate the selectors against *path* using pyosmium."""
    import osmium
    from osmium import filter as ofilter
    from osmium.osm import NODE, NOTHING, RELATION, WAY

    node_elements: list[dict] = []
    matched_ways: dict = {}
    matched_rels: dict = {}
    needed_nodes: set[int] = set()
    needed_ways: set[int] = set()

    # --- Pass 1: matched tagged entities -------------------------------------
    entities = NOTHING
    for sels, bit in ((node_sels, NODE), (way_sels, WAY), (rel_sels, RELATION)):
        if sels:
            entities |= bit
    if entities != NOTHING:
        keys = _required_keys(node_sels + way_sels + rel_sels)
        fp = osmium.FileProcessor(str(path), entities).with_filter(ofilter.EmptyTagFilter())
        if keys is not None:
            fp = fp.with_filter(ofilter.KeyFilter(*sorted(keys)))
        obj: Any
        for obj in fp:
            tags = {t.k: t.v for t in obj.tags}
            if obj.is_node():
                sel = _match(node_sels, tags)
                if sel is not None:
                    loc = obj.location
                    lon, lat = loc.lon, loc.lat
                    if _in_bbox(lon, lat, sel.bbox):
                        node_elements.append(
                            {"type": "node", "id": obj.id, "lat": lat, "lon": lon, "tags": tags}
                        )
            elif obj.is_way():
                sel = _match(way_sels, tags)
                if sel is not None:
                    refs = tuple(n.ref for n in obj.nodes)
                    matched_ways[obj.id] = (tags, refs, sel.bbox)
                    needed_nodes.update(refs)
            else:
                sel = _match(rel_sels, tags)
                if sel is not None:
                    members = [(m.ref, _MEMBER_TYPES[m.type], m.role) for m in obj.members]
                    matched_rels[obj.id] = (tags, members, sel.bbox)
                    for ref, mtype, _role in members:
                        if mtype == "WAY":
                            needed_ways.add(ref)
                        elif mtype == "NODE":
                            needed_nodes.add(ref)

    # --- Pass 2: node refs of relation member ways ---------------------------
    member_way_refs: dict[int, tuple[int, ...]] = {}
    if needed_ways:
        fp = osmium.FileProcessor(str(path), WAY).with_filter(ofilter.IdFilter(needed_ways))
        way: Any
        for way in fp:
            refs = tuple(n.ref for n in way.nodes)
            member_way_refs[way.id] = refs
            needed_nodes.update(refs)

    # --- Pass 3: coordinates of every referenced node ------------------------
    node_coords: dict[int, tuple[float, float]] = {}
    if needed_nodes:
        fp = osmium.FileProcessor(str(path), NODE).with_filter(ofilter.IdFilter(needed_nodes))
        node: Any
        for node in fp:
            loc = node.location
            node_coords[node.id] = (loc.lon, loc.lat)

    return OsmiumResult(node_elements, matched_ways, matched_rels, member_way_refs, node_coords)
