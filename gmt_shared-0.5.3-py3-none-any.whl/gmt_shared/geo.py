"""geo.py — tiny pure-Python geometry helpers shared across GMT modules.

No external dependencies (stdlib only) so that ``*_core`` modules can import it
while staying pure.

Public API
----------
point_in_polygon(lon, lat, polygon) -> bool
    Ray-casting point-in-polygon test.
is_netherlands(bbox) -> bool
    True when the centroid of *bbox* lies inside an outline of the
    Netherlands.
is_bbox_fully_in_netherlands(bbox) -> bool
    True when all four corners of *bbox* lie inside an outline of the
    Netherlands.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Outline of the Netherlands incl. territorial waters, WGS-84 [lon, lat]
# vertices.  Derived from the Geofabrik ``netherlands.poly`` extract
# (tools/overpass_local/osm/netherlands.poly in gmt-calculation-lib), buffered
# by 0.005 deg and simplified with a 0.01 deg tolerance (~1 km), so the land
# borders with Belgium and Germany are followed closely (Zeeuws-Vlaanderen,
# Limburg, Achterhoek, Twente, Wadden islands are all covered).  Ordered as a
# single closed ring.
# ---------------------------------------------------------------------------
_NL_POLYGON: list[list[float]] = [
    [3.376, 51.337],
    [3.303, 51.427],
    [2.928, 51.588],
    [4.360, 53.309],
    [5.529, 54.023],
    [6.352, 53.771],
    [6.642, 53.585],
    [6.933, 53.460],
    [6.959, 53.398],
    [7.010, 53.334],
    [7.193, 53.339],
    [7.221, 53.191],
    [7.244, 53.179],
    [7.208, 53.169],
    [7.188, 53.135],
    [7.211, 53.117],
    [7.227, 53.006],
    [7.188, 52.937],
    [7.097, 52.848],
    [7.079, 52.807],
    [7.062, 52.638],
    [7.041, 52.624],
    [6.873, 52.645],
    [6.745, 52.638],
    [6.726, 52.627],
    [6.728, 52.593],
    [6.775, 52.556],
    [6.699, 52.543],
    [6.714, 52.523],
    [6.707, 52.491],
    [6.755, 52.472],
    [6.859, 52.468],
    [6.941, 52.444],
    [6.972, 52.472],
    [7.000, 52.471],
    [7.017, 52.435],
    [7.064, 52.406],
    [7.080, 52.375],
    [7.080, 52.348],
    [7.035, 52.289],
    [7.075, 52.245],
    [7.067, 52.228],
    [6.992, 52.218],
    [6.956, 52.174],
    [6.914, 52.169],
    [6.858, 52.113],
    [6.767, 52.111],
    [6.754, 52.077],
    [6.703, 52.063],
    [6.696, 52.048],
    [6.832, 52.001],
    [6.841, 51.973],
    [6.806, 51.952],
    [6.794, 51.924],
    [6.722, 51.888],
    [6.682, 51.909],
    [6.472, 51.845],
    [6.408, 51.862],
    [6.419, 51.856],
    [6.411, 51.819],
    [6.346, 51.843],
    [6.302, 51.841],
    [6.279, 51.866],
    [6.208, 51.861],
    [6.156, 51.897],
    [6.138, 51.894],
    [6.175, 51.867],
    [6.172, 51.832],
    [6.067, 51.855],
    [6.037, 51.835],
    [5.960, 51.825],
    [6.000, 51.789],
    [5.996, 51.760],
    [5.966, 51.747],
    [6.053, 51.722],
    [6.036, 51.704],
    [6.040, 51.680],
    [6.125, 51.662],
    [6.102, 51.610],
    [6.220, 51.517],
    [6.232, 51.469],
    [6.216, 51.408],
    [6.238, 51.406],
    [6.224, 51.386],
    [6.236, 51.358],
    [6.202, 51.328],
    [6.175, 51.325],
    [6.131, 51.269],
    [6.084, 51.239],
    [6.096, 51.217],
    [6.077, 51.214],
    [6.086, 51.180],
    [6.166, 51.203],
    [6.187, 51.192],
    [6.162, 51.172],
    [6.183, 51.154],
    [6.002, 51.077],
    [5.961, 51.027],
    [5.934, 51.028],
    [5.912, 51.057],
    [5.882, 51.044],
    [5.886, 51.023],
    [5.914, 51.007],
    [5.912, 50.986],
    [6.031, 50.991],
    [6.025, 50.942],
    [6.106, 50.925],
    [6.085, 50.896],
    [6.096, 50.871],
    [6.080, 50.839],
    [6.026, 50.839],
    [6.032, 50.809],
    [6.006, 50.794],
    [6.037, 50.778],
    [6.029, 50.748],
    [5.911, 50.742],
    [5.882, 50.760],
    [5.848, 50.743],
    [5.841, 50.755],
    [5.805, 50.748],
    [5.772, 50.774],
    [5.742, 50.748],
    [5.677, 50.750],
    [5.688, 50.803],
    [5.649, 50.813],
    [5.631, 50.846],
    [5.638, 50.877],
    [5.674, 50.888],
    [5.695, 50.919],
    [5.718, 50.917],
    [5.735, 50.941],
    [5.740, 50.952],
    [5.710, 50.962],
    [5.760, 51.003],
    [5.750, 51.037],
    [5.768, 51.070],
    [5.790, 51.068],
    [5.798, 51.113],
    [5.840, 51.143],
    [5.826, 51.157],
    [5.776, 51.142],
    [5.764, 51.176],
    [5.655, 51.177],
    [5.555, 51.215],
    [5.548, 51.261],
    [5.511, 51.288],
    [5.487, 51.292],
    [5.419, 51.254],
    [5.351, 51.267],
    [5.339, 51.255],
    [5.236, 51.253],
    [5.217, 51.267],
    [5.232, 51.301],
    [5.200, 51.314],
    [5.127, 51.310],
    [5.124, 51.343],
    [5.061, 51.392],
    [5.095, 51.432],
    [5.075, 51.463],
    [5.031, 51.475],
    [5.010, 51.438],
    [4.922, 51.385],
    [4.888, 51.407],
    [4.766, 51.408],
    [4.764, 51.438],
    [4.818, 51.433],
    [4.831, 51.474],
    [4.776, 51.496],
    [4.675, 51.439],
    [4.677, 51.420],
    [4.641, 51.414],
    [4.575, 51.425],
    [4.531, 51.414],
    [4.522, 51.451],
    [4.537, 51.472],
    [4.478, 51.470],
    [4.401, 51.446],
    [4.395, 51.418],
    [4.439, 51.379],
    [4.437, 51.356],
    [4.385, 51.346],
    [4.337, 51.350],
    [4.329, 51.369],
    [4.236, 51.366],
    [4.253, 51.352],
    [4.170, 51.286],
    [4.064, 51.237],
    [4.015, 51.237],
    [3.885, 51.192],
    [3.785, 51.207],
    [3.783, 51.250],
    [3.752, 51.262],
    [3.595, 51.295],
    [3.585, 51.279],
    [3.531, 51.274],
    [3.537, 51.241],
    [3.423, 51.237],
    [3.367, 51.274],
    [3.355, 51.299],
    [3.347, 51.316],
    [3.376, 51.337],
]


def point_in_polygon(lon: float, lat: float, polygon: list[list[float]]) -> bool:
    """Return True when point ``(lon, lat)`` lies inside *polygon*.

    Uses the standard ray-casting (even-odd) algorithm.  *polygon* is a list of
    ``[lon, lat]`` vertices; it may be open or closed (the ring is treated as
    closed regardless).
    """
    inside = False
    n = len(polygon)
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i][0], polygon[i][1]
        xj, yj = polygon[j][0], polygon[j][1]
        if ((yi > lat) != (yj > lat)) and (lon < (xj - xi) * (lat - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside


def is_netherlands(bbox: list[float]) -> bool:
    """Return True when the centroid of *bbox* lies inside the Netherlands.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    """
    cx = (bbox[0] + bbox[2]) / 2.0
    cy = (bbox[1] + bbox[3]) / 2.0
    return point_in_polygon(cx, cy, _NL_POLYGON)


def is_bbox_fully_in_netherlands(bbox: list[float]) -> bool:
    """Return True when *bbox* lies entirely inside the Netherlands.

    Unlike :func:`is_netherlands` (which only checks the bbox centroid), this
    checks all four corners — a bbox straddling the border returns False even
    when its centroid happens to fall inside the outline.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    corners = [
        (min_lon, min_lat),
        (min_lon, max_lat),
        (max_lon, min_lat),
        (max_lon, max_lat),
    ]
    return all(point_in_polygon(lon, lat, _NL_POLYGON) for lon, lat in corners)
