"""Local ``.osm.pbf`` backend for the shared Overpass client.

Serves the exact JSON element shape that Overpass ``out geom;`` / ``out body;``
produces, but by reading a local OpenStreetMap PBF extract instead of hitting an
Overpass server.  This lets every ``osm*`` fetcher run fully offline against a
Geofabrik download.

The query is parsed by :mod:`shared._osm_ql` into a list of selectors; the PBF
is then scanned and elements matching any selector (within its bbox) are emitted
in Overpass JSON form:

* node     -> ``{"type": "node", "id", "lat", "lon", "tags"}``
* way      -> ``{"type": "way", "id", "tags", "nodes": [...], "geometry": [{"lat","lon"}, ...]}``
* relation -> ``{"type": "relation", "id", "tags", "members": [{"type","ref","role","geometry"}]}``

``nodes`` (the node-id list) *and* ``geometry`` are both populated on ways
because the network splitter relies on shared node ids to detect intersections.

The PBF is decoded by the repo's own dependency-free reader
(:mod:`shared._osm_pbf_reader`) — a hand-written varint decoder that is ~5x
faster than the pure-Python ``google.protobuf`` runtime and pulls in no
third-party packages.  A single pass collects both the matched entities *and* a
per-block ``(max_id, offset, datasize)`` index, so referenced node/way ids are
resolved by re-reading only the relevant blocks instead of scanning the whole
file a second time.

When ``pyosmium`` is installed it is used instead (C++ decoding and tag
pre-filtering, see :mod:`gmt_shared._osm_pbf_osmium`); set
``OSM_PBF_BACKEND=python`` to force the built-in reader.

Public API
----------
fetch_from_pbf(query, pbf_path) -> dict
    Parse *query*, scan *pbf_path*, and return ``{"elements": [...]}``.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from gmt_shared._osm_ql import Selector, parse_overpass_ql

logger = logging.getLogger(__name__)


def _in_bbox(lon: float, lat: float, bbox: tuple[float, float, float, float] | None) -> bool:
    """Return True when ``(lon, lat)`` lies inside *bbox* (south,west,north,east)."""
    if bbox is None:
        return True
    south, west, north, east = bbox
    return west <= lon <= east and south <= lat <= north


def _way_intersects_bbox(
    coords: list[tuple[float, float]],
    bbox: tuple[float, float, float, float] | None,
) -> bool:
    """Return True when any vertex of *coords* falls inside *bbox*.

    Overpass returns any way with at least one node in the bounding box; this
    vertex test is a close-enough approximation for the local backend.
    """
    if bbox is None:
        return True
    return any(_in_bbox(lon, lat, bbox) for lon, lat in coords)


def _match(selectors: list[Selector], tags: dict) -> Selector | None:
    """Return the first selector whose filters all match *tags*, else None."""
    for sel in selectors:
        if sel.matches(tags):
            return sel
    return None


#: Env var selecting the decoder: ``osmium``, ``python`` or unset/``auto``
#: (osmium when importable, else the built-in pure-Python reader).
BACKEND_ENV = "OSM_PBF_BACKEND"


def _use_osmium() -> bool:
    """Decide whether to use the pyosmium backend (see :data:`BACKEND_ENV`)."""
    from gmt_shared import _osm_pbf_osmium

    choice = os.environ.get(BACKEND_ENV, "").strip().lower()
    if choice == "python":
        return False
    if choice == "osmium":
        if not _osm_pbf_osmium.available():
            raise ImportError(f"{BACKEND_ENV}=osmium but the 'osmium' package is not installed")
        return True
    if choice not in ("", "auto"):
        raise ValueError(f"Unsupported {BACKEND_ENV} value: {choice!r}")
    return _osm_pbf_osmium.available()


def fetch_from_pbf(
    query: str, pbf_path: str | Path, *, workers: int | None = None
) -> dict[str, Any]:
    """Evaluate an Overpass QL *query* against a local ``.osm.pbf`` file.

    Parameters
    ----------
    query:
        Overpass QL string produced by one of the repo's ``build_*_query``
        helpers.  Parsed by :mod:`shared._osm_ql`.
    pbf_path:
        Path to a local OpenStreetMap PBF extract (e.g. a Geofabrik download).
    workers:
        Explicit worker-process count for the parallel scan (from
        ``--osm-workers``).  ``None`` falls back to the ``OSM_PBF_WORKERS``
        environment variable / CPU-count default.  Always capped and bounded
        by the available CPUs.

    Returns
    -------
    Dict with an ``"elements"`` key holding the matched elements in Overpass
    ``out geom;`` JSON shape.

    Raises
    ------
    FileNotFoundError:
        If *pbf_path* does not exist.
    NotImplementedError:
        If *query* uses a QL construct outside the supported subset.
    """
    from gmt_shared import _osm_pbf_reader as reader
    from gmt_shared import _osm_pbf_scan as scan
    from gmt_shared import _osm_session as session

    path = Path(pbf_path)
    if not path.is_file():
        raise FileNotFoundError(f"OSM PBF file not found: {path}")

    selectors = parse_overpass_ql(query)
    node_sels = [s for s in selectors if s.kind == "node"]
    way_sels = [s for s in selectors if s.kind == "way"]
    rel_sels = [s for s in selectors if s.kind == "relation"]

    use_osmium = _use_osmium()
    if use_osmium:
        from gmt_shared import _osm_pbf_osmium

        ores = _osm_pbf_osmium.scan(path, node_sels, way_sels, rel_sels)
        node_elements = ores.node_elements
        matched_ways = ores.matched_ways
        matched_rels = ores.matched_rels
        member_way_refs = ores.member_way_refs
        node_coords = ores.node_coords
    else:
        # --- Pass 1: gather matched entities + a per-block index --------------
        # With the session cache enabled (default) the file is scanned once per
        # process and every fetcher's query is answered from memory; otherwise
        # a single targeted scan (serial or process-parallel) runs per query.
        n_workers = (
            scan._default_workers()
            if workers is None
            else scan.resolve_workers(str(workers), os.cpu_count())
        )
        if session.sessions_enabled():
            result = session.query_session(
                session.get_session(path, workers=n_workers), node_sels, way_sels, rel_sels
            )
        else:
            result = scan.scan(path, node_sels, way_sels, rel_sels, workers=n_workers)
        node_elements = result.node_elements
        matched_ways = result.matched_ways
        matched_rels = result.matched_rels
        needed_nodes = set(result.needed_nodes)
        needed_ways = result.needed_ways

        # --- Resolve referenced member ways, then all referenced node coords --
        member_way_refs = {}
        if needed_ways:
            member_way_refs = reader.resolve_way_refs(path, result.way_index, needed_ways)
            for refs in member_way_refs.values():
                needed_nodes.update(refs)

        node_coords = {}
        if needed_nodes:
            node_coords = reader.resolve_node_coords(path, result.node_index, needed_nodes)

    # --- Build way elements ---------------------------------------------------
    way_elements: list[dict] = []
    for way_id, (tags, refs, bbox) in matched_ways.items():
        coords = [node_coords[r] for r in refs if r in node_coords]
        if not _way_intersects_bbox(coords, bbox):
            continue
        way_elements.append(
            {
                "type": "way",
                "id": way_id,
                "tags": tags,
                "nodes": list(refs),
                "geometry": [{"lat": lat, "lon": lon} for lon, lat in coords],
            }
        )

    # --- Build relation elements ---------------------------------------------
    rel_elements: list[dict] = []
    for rel_id, (tags, members, bbox) in matched_rels.items():
        member_dicts: list[dict] = []
        any_in_bbox = bbox is None
        for ref, mtype, role in members:
            member: dict[str, Any] = {
                "type": mtype.lower(),
                "ref": ref,
                "role": role,
            }
            if mtype == "WAY" and ref in member_way_refs:
                coords = [node_coords[r] for r in member_way_refs[ref] if r in node_coords]
                member["geometry"] = [{"lat": lat, "lon": lon} for lon, lat in coords]
                if not any_in_bbox and _way_intersects_bbox(coords, bbox):
                    any_in_bbox = True
            elif mtype == "NODE" and ref in node_coords:
                lon, lat = node_coords[ref]
                member["lat"] = lat
                member["lon"] = lon
                if not any_in_bbox and _in_bbox(lon, lat, bbox):
                    any_in_bbox = True
            member_dicts.append(member)
        if not any_in_bbox:
            continue
        rel_elements.append(
            {
                "type": "relation",
                "id": rel_id,
                "tags": tags,
                "members": member_dicts,
            }
        )

    elements = node_elements + way_elements + rel_elements
    logger.info(
        "PBF backend (%s): %d nodes, %d ways, %d relations from %s",
        "osmium" if use_osmium else "python",
        len(node_elements),
        len(way_elements),
        len(rel_elements),
        path.name,
    )
    return {"elements": elements}
