"""Local debug runner for network_zone_joiner.

Reads a zones GeoJSON file and a network GeoJSON file, clips the network to
the requested zone(s), and writes a single NETWORK, ZONE, and FEEDLINK output
file.  By default the input network and feedlinks files are overwritten in place,
consistent with other modules in this pipeline.

Usage
-----
    # Overwrite inputs in place (default):
    python -m network_zone_joiner.network_zone_joiner_runner \\
        --zones-file  path/to/{areaId}-ZONES.geojson \\
        --network-file path/to/{areaId}-NETWORK-CAR.geojson \\
        --feedlinks-file path/to/{areaId}-FEEDLINK-CAR.geojson \\
        --zone-output path/to/{areaId}-ZONE-CAR.geojson

    # Explicit output files:
    python -m network_zone_joiner.network_zone_joiner_runner \\
        --zones-file zones.geojson --network-file network.geojson \\
        --feedlinks-file feedlinks.geojson \\
        --network-output out/network-joined.geojson \\
        --zone-output out/zones-joined.geojson \\
        --feedlinks-output out/feedlinks-joined.geojson
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Clip a network to zone polygon(s) and write merged NETWORK, ZONE, "
            "and FEEDLINK output files.  By default the input network and feedlinks "
            "files are overwritten in place."
        )
    )
    parser.add_argument(
        "--zones-file", required=True, metavar="URI",
        help="URI of the input zones GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--network-file", required=True, metavar="URI",
        help="URI of the input network GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--feedlinks-file", default=None, metavar="URI",
        help=(
            "Optional URI of a feedlinks GeoJSON file (from feedlink_fetcher). "
            "When provided, filtered existing feedlinks and synthetic boundary-node "
            "feedlinks are written to the feedlinks output."
        ),
    )
    parser.add_argument(
        "--network-output", default=None, metavar="URI",
        help=(
            "URI to write the clipped network GeoJSON. "
            "Defaults to overwriting --network-file."
        ),
    )
    parser.add_argument(
        "--zone-output", required=True, metavar="URI",
        help="URI to write the zone GeoJSON output (s3:// or local path).",
    )
    parser.add_argument(
        "--feedlinks-output", default=None, metavar="URI",
        help=(
            "URI to write the extended feedlinks GeoJSON. "
            "Defaults to overwriting --feedlinks-file when that argument is provided."
        ),
    )
    parser.add_argument(
        "--area-id", default=None, metavar="ID",
        help="Override the area ID read from the zones file properties.",
    )
    parser.add_argument(
        "--mode", default=None, metavar="MODE",
        help="Override the transport mode read from the network file properties.",
    )
    parser.add_argument(
        "--zone-classes",
        nargs="+",
        default=None,
        metavar="CLASS",
        help=(
            "Only process zones whose zoneClass matches one of these values "
            "(e.g. AREA STUDY INFLUENCE).  Processes all classes when omitted."
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from network_zone_joiner.core.network_zone_joiner_core import (  # noqa: PLC0415
        join_zones_to_network,
    )

    # Read inputs
    print(f"Reading zones    : {args.zones_file}")
    zones_fc: dict = json.loads(_read_uri(args.zones_file))

    print(f"Reading network  : {args.network_file}")
    network_fc: dict = json.loads(_read_uri(args.network_file))

    feedlinks_fc: dict | None = None
    if args.feedlinks_file:
        print(f"Reading feedlinks: {args.feedlinks_file}")
        feedlinks_fc = json.loads(_read_uri(args.feedlinks_file))

    # Resolve area_id and mode
    zones_props = zones_fc.get("properties") or {}
    network_props = network_fc.get("properties") or {}

    area_id = args.area_id or zones_props.get("areaId") or network_props.get("area_id") or "unknown"
    modes = network_props.get("modes") or []
    mode = args.mode or (modes[0] if modes else None) or "UNKNOWN"

    print(f"Area ID          : {area_id}")
    print(f"Mode             : {mode}")
    print(f"Zone features    : {len(zones_fc.get('features') or [])}")
    print(f"Network links    : {len(network_fc.get('features') or [])}")

    # Resolve output URIs
    net_out_uri      = args.network_output  or args.network_file
    zone_out_uri     = args.zone_output
    feedlink_out_uri = args.feedlinks_output or args.feedlinks_file

    # Run the join
    zone_classes_filter = set(args.zone_classes) if args.zone_classes else None
    results = join_zones_to_network(
        zones_fc, network_fc,
        zone_classes=zone_classes_filter,
        feedlinks_fc=feedlinks_fc,
    )

    print(f"\nProcessed {len(results)} zones:")
    for zone_feat, clipped_net_fc, zone_fc, ext_feedlinks_fc in results:
        zone_props = zone_feat.get("properties") or {}
        zone_id    = zone_props.get("zoneId") or ""
        zone_class = zone_props.get("zoneClass") or ""
        n_links    = len(clipped_net_fc.get("features") or [])
        n_feedlinks = len(ext_feedlinks_fc.get("features") or [])
        print(f"  {zone_class:10s} {zone_id!r:40s} -> {n_links} links, {n_feedlinks} feedlinks")

    # Merge all results into single output FeatureCollections.
    # For the common single-AREA-zone case this is a no-op merge.
    all_net_features: list[dict] = []
    all_zone_features: list[dict] = []
    all_feedlink_features: list[dict] = []

    for _zone_feat, clipped_net_fc, zone_fc, ext_feedlinks_fc in results:
        all_net_features.extend(clipped_net_fc.get("features") or [])
        all_zone_features.extend(zone_fc.get("features") or [])
        all_feedlink_features.extend(ext_feedlinks_fc.get("features") or [])

    merged_net_fc: dict = {**network_fc, "features": all_net_features}
    merged_zone_fc: dict = {
        "type": "FeatureCollection",
        "features": all_zone_features,
        "properties": {
            **(zones_fc.get("properties") or {}),
            "modes": (network_fc.get("properties") or {}).get("modes") or [],
        },
    }
    feedlinks_base_props = (feedlinks_fc.get("properties") or {}) if feedlinks_fc else {}
    merged_feedlinks_fc: dict = {
        "type": "FeatureCollection",
        "features": all_feedlink_features,
        "properties": {**feedlinks_base_props},
    }

    _write_uri(net_out_uri,  json.dumps(merged_net_fc,       ensure_ascii=False).encode("utf-8"))
    _write_uri(zone_out_uri, json.dumps(merged_zone_fc,      ensure_ascii=False).encode("utf-8"))
    if feedlink_out_uri:
        _write_uri(feedlink_out_uri, json.dumps(merged_feedlinks_fc, ensure_ascii=False).encode("utf-8"))

    print("\nDone.")


if __name__ == "__main__":
    main()
