"""
prepare_core.py — GMT preparation pipeline orchestration logic.

Contains the full 10-step pipeline (zone_fetcher → matrix_builder) plus all
supporting helpers.  Import and call ``run_pipeline`` from a local runner,
notebook, or Lambda handler.

All steps execute in-process (no subprocess).  Only the four final outputs are
written to disk:

  {area_id}-NETWORK-{modeLabel}.parquet
  {area_id}-FEEDLINK-{modeLabel}.parquet
  {area_id}-ZONE-{mode}.parquet         (one file per mode — never MIXED)
  {area_id}-ROUTES-{mode}.parquet       (one file per mode — never MIXED)

For PEDESTRIAN mode (single mode only) the pipeline ends after step 7
(parallel_link_finder) and writes:

  {area_id}-NETWORK-PEDESTRIAN.parquet
  {area_id}-ZONE-PEDESTRIAN.parquet

Multimodal networks
-------------------
Pass a list of two or more modes together with an external label:

  run_pipeline(..., modes=["CAR", "BIKE"], mode_label="MIXED")

Each road segment in the combined network retains its own ``"mode"`` property
(``"CAR"`` or ``"BIKE"``).  The FeatureCollection-level ``"modes"`` list and
the ``"modeLabel"`` property identify the combination.  PEDESTRIAN cannot be
combined with other modes.  The external label must not contain a hyphen
(the adjust pipeline uses hyphens to distinguish derived artefacts).

Intermediate results are kept in memory and optionally snapshotted as
``STEP_{n}_…`` files when *debug=True*.
"""

from __future__ import annotations

import concurrent.futures
import csv
import json
import uuid
from pathlib import Path

from shared.geoparquet import to_geoparquet

# ---------------------------------------------------------------------------
# Repo-root paths
# ---------------------------------------------------------------------------

_CORE_FILE = Path(__file__).resolve()
_REPO_ROOT  = _CORE_FILE.parent.parent.parent.parent  # src/prepare/core/ -> repo root
ARTIFACTS   = _REPO_ROOT / "artifacts"

# ---------------------------------------------------------------------------
# Step constants
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# PT mode set
# ---------------------------------------------------------------------------

_PT_MODES = {"BUS", "TRAM", "METRO", "TRAIN"}

# ---------------------------------------------------------------------------
# UUID helpers
# ---------------------------------------------------------------------------

# Product-type markers that separate the area-id prefix from the rest of a
# filename.  Listed in rough "most likely to be present" order.
_ID_MARKERS = (
    "-NETWORK-",
    "-ROUTES-",
    "-ZONE-",
    "-FEEDLINK-",
    "-ZONES.",
    "-SIMPLIFIED-NODES-",
)


def _discover_or_create_area_id(out_dir: Path, area_id: str | None = None) -> str:
    """Return the area UUID to use for *out_dir*.

    Priority
    --------
    1. Explicit *area_id* override (passed by the caller / ``--area-id`` CLI arg).
    2. UUID prefix of the first ``.parquet`` file in *out_dir* whose stem
       contains a known product-type marker (re-run of an existing area).
    3. Fresh :func:`uuid.uuid4` (first run / empty folder).

    No sidecar file is read or written.
    """
    if area_id:
        return area_id
    for f in sorted(out_dir.glob("*.parquet")):
        stem = f.stem
        for marker in _ID_MARKERS:
            idx = stem.find(marker)
            if idx > 0:
                return stem[:idx]
    return str(uuid.uuid4())


# ---------------------------------------------------------------------------
# Debug snapshot helper
# ---------------------------------------------------------------------------


def _snapshot(step_num: int, area_id: str, out_dir: Path, **named_fcs: dict) -> None:
    """Write named in-memory FeatureCollections to ``STEP_{n}_{area_id}_{PRODUCT}.geojson``."""
    for product, fc in named_fcs.items():
        if fc is None:
            print(f"  [debug] snapshot skipped — {product} is None")
            continue
        dst = out_dir / f"STEP_{step_num}_{area_id}_{product}.geojson"
        dst.write_text(json.dumps(fc, ensure_ascii=False), encoding="utf-8")
        n = len((fc.get("features") or []))
        print(f"  [debug] snapshot -> {dst.name}  ({n} features)")


# ---------------------------------------------------------------------------
# Mode-filter helper
# ---------------------------------------------------------------------------


def _filter_fc_by_mode(fc: dict, mode: str) -> dict:
    """Return a shallow copy of *fc* containing only features with ``mode == mode``.

    Used by the matrix-builder step to build a per-mode routing graph from a
    combined (MIXED) network FeatureCollection.  Features whose ``mode`` property
    is absent or does not match are excluded.
    """
    features = [
        f for f in (fc.get("features") or [])
        if (f.get("properties") or {}).get("mode") == mode
    ]
    return {**fc, "features": features}


# ---------------------------------------------------------------------------
# Zone-fetcher geometry helpers
# ---------------------------------------------------------------------------


def _bbox_polygon_geom(
    min_lon: float, min_lat: float, max_lon: float, max_lat: float
) -> dict:
    """Return a GeoJSON Polygon geometry dict for the given bounding box."""
    return {
        "type": "Polygon",
        "coordinates": [[
            [min_lon, min_lat],
            [max_lon, min_lat],
            [max_lon, max_lat],
            [min_lon, max_lat],
            [min_lon, min_lat],
        ]],
    }


def _extract_area_polygon_json(zones_fc: dict) -> str:
    """Return the GeoJSON geometry string of the AREA feature in *zones_fc*.

    Raises ``ValueError`` when no AREA feature is found.
    """
    for feature in zones_fc.get("features", []):
        if (feature.get("properties") or {}).get("zoneClass") == "AREA":
            return json.dumps(feature["geometry"])
    raise ValueError("No AREA feature found in zones FeatureCollection")


def _make_pedestrian_stub_zones(
    area_id: str,
    min_lon: float, min_lat: float, max_lon: float, max_lat: float,
) -> dict:
    """Return a minimal ZONES FeatureCollection with only an AREA feature (bbox polygon).

    This satisfies :func:`_extract_area_polygon_json` so that the
    network_fetcher polygon argument can be derived without a real
    Databricks zone query.
    """
    fc = {
        "type": "FeatureCollection",
        "features": [{
            "type": "Feature",
            "geometry": _bbox_polygon_geom(min_lon, min_lat, max_lon, max_lat),
            "properties": {
                "zoneId":    area_id,
                "zoneClass": "AREA",
                "zoneName":  "Area",
            },
        }],
        "properties": {"areaId": area_id},
    }
    print("  [pedestrian] stub zones created (AREA bbox only)")
    return fc


def _make_pedestrian_zones(
    network_fc: dict,
    area_id: str,
    min_lon: float, min_lat: float, max_lon: float, max_lat: float,
) -> dict:
    """Derive pedestrian zones from the cleaned network nodes.

    Each unique node (``fromNode`` / ``toNode``) in the directed network
    becomes one ``NODE``-class zone feature.  Production is the sum of
    ``flow`` on outgoing links; attraction is the sum of ``flow`` on
    incoming links.  The AREA feature (bbox polygon) is included so that
    downstream steps can still find it.
    """
    features = network_fc.get("features") or []

    node_pos: dict[str, tuple[float, float]] = {}
    node_prod: dict[str, float] = {}
    node_attr: dict[str, float] = {}

    for feat in features:
        props  = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords:
            continue

        from_node = str(props.get("fromNode") or "")
        to_node   = str(props.get("toNode")   or "")
        flow      = float(props.get("flow")    or 0.0)

        if from_node:
            lon, lat = float(coords[0][0]), float(coords[0][1])
            node_pos.setdefault(from_node, (lon, lat))
            node_prod[from_node] = node_prod.get(from_node, 0.0) + flow

        if to_node and len(coords) >= 2:
            lon, lat = float(coords[-1][0]), float(coords[-1][1])
            node_pos.setdefault(to_node, (lon, lat))
            node_attr[to_node] = node_attr.get(to_node, 0.0) + flow

    zone_features: list[dict] = [{
        "type": "Feature",
        "geometry": _bbox_polygon_geom(min_lon, min_lat, max_lon, max_lat),
        "properties": {
            "zoneId":    area_id,
            "zoneClass": "AREA",
            "zoneName":  "Area",
        },
    }]

    for node_id, (lon, lat) in sorted(node_pos.items()):
        production = round(node_prod.get(node_id, 0.0), 4)
        attraction = round(node_attr.get(node_id, 0.0), 4)
        zone_features.append({
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [lon, lat]},
            "properties": {
                "zoneId":      node_id,
                "zoneClass":   "NODE",
                "zoneName":    f"node_{node_id}",
                "centroidLon": lon,
                "centroidLat": lat,
                "production":  production,
                "attraction":  attraction,
            },
        })

    out_fc = {
        "type": "FeatureCollection",
        "features": zone_features,
        "properties": {"areaId": area_id},
    }
    n_nodes = len(zone_features) - 1
    print(f"  [pedestrian] {n_nodes} node zones derived")
    return out_fc


# ---------------------------------------------------------------------------
# Deduplication helpers (originally in network_zone_joiner_runner.py)
# ---------------------------------------------------------------------------


def _dedup_zone_features(features: list[dict]) -> list[dict]:
    """Return *features* with duplicates removed by ``zoneId`` (first occurrence wins).

    When both an AREA zone and individual STUDY/INFLUENCE zones are processed,
    every non-AREA zone appears in *all_zone_features* twice: once inside the AREA
    zone's ``zone_fc`` and once from its own result tuple.  This function keeps
    the first occurrence of each ``zoneId``.
    """
    seen: dict[str, dict] = {}
    for feat in features:
        zid = (feat.get("properties") or {}).get("zoneId") or ""
        if zid not in seen:
            seen[zid] = feat
    return list(seen.values())


def _dedup_net_features(features: list[dict]) -> list[dict]:
    """Return *features* with duplicates removed by ``(linkId, fromNode, toNode)``.

    Links that fall inside an individual zone's polygon are also present in the
    AREA zone's clipped network.  This function keeps the first occurrence of
    each ``(linkId, fromNode, toNode)`` triple, which is the AREA zone's version
    (the most complete clip).
    """
    seen: set[tuple] = set()
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        key = (
            str(props.get("linkId") or props.get("spectrumId") or ""),
            str(props.get("fromNode") or ""),
            str(props.get("toNode") or ""),
        )
        if key not in seen:
            seen.add(key)
            result.append(feat)
    return result


# ---------------------------------------------------------------------------
# NVP CSV writer (originally in nvp_mapper_runner.py)
# ---------------------------------------------------------------------------


def _write_nvp_csv(match_rows: list, output_path: Path) -> None:
    """Write NVP match rows to a CSV file.

    Columns: linkId, nvpLinkIds, nvpTripIds.
    List values (nvpLinkIds, nvpTripIds) are serialised as pipe-separated strings.
    """
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w", newline="", encoding="utf-8") as fh:
        writer = csv.writer(fh)
        writer.writerow(["linkId", "nvpLinkIds", "nvpTripIds"])
        for row in match_rows:
            writer.writerow([
                row["linkId"],
                "|".join(row["nvpLinkIds"]),
                "|".join(row["nvpTripIds"]),
            ])
    print(f"  Written {len(match_rows):,} NVP rows -> {output_path.name}")


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


def _validate_modes(modes: list[str], mode_label: str) -> None:
    """Validate *modes* and *mode_label* for :func:`run_pipeline`.

    Raises
    ------
    ValueError
        - *modes* is empty.
        - Any mode is not a recognised transport mode.
        - ``"PEDESTRIAN"`` is combined with other modes.
        - *mode_label* contains a hyphen (breaks ``_detect_mode()`` in the
          adjust pipeline, which rejects mode labels that contain hyphens).
    """
    from network_fetcher.domain.sql import VALID_MODES  # noqa: PLC0415

    if not modes:
        raise ValueError("At least one transport mode must be specified.")

    invalid = [m for m in modes if m not in VALID_MODES]
    if invalid:
        raise ValueError(
            f"Unsupported mode(s): {', '.join(repr(m) for m in invalid)}. "
            f"Valid modes: {', '.join(sorted(VALID_MODES))}."
        )

    if len(modes) > 1 and "PEDESTRIAN" in modes:
        raise ValueError(
            "PEDESTRIAN cannot be combined with other modes — it uses a different "
            "network schema and has no feedlinks or OD matrix."
        )

    if "-" in mode_label:
        raise ValueError(
            f"mode_label {mode_label!r} must not contain hyphens.  "
            "The adjust pipeline identifies the mode label as the part after "
            "'-NETWORK-' in the filename and rejects any value that contains a hyphen."
        )


def run_pipeline(
    min_lon: float,
    min_lat: float,
    max_lon: float,
    max_lat: float,
    modes: list[str],
    name: str,
    out_dir: Path,
    *,
    mode_label: str | None = None,
    catalog: str,
    schema: str,
    refresh: bool,
    debug: bool,
    exclude_zones: list[str] | None = None,
    max_routes: int = 2,
    nvp_table: str | None = None,
    nvp_year: int | None = None,
    area_id: str | None = None,
) -> str:
    """Run the full GMT preparation pipeline entirely in-process.

    Per-mode steps (network_fetcher, network_simplifier, network_cleaner,
    feedlink_fetcher) run in parallel using a ``ThreadPoolExecutor`` — one
    thread per requested mode.  Cross-mode steps (network_fuser,
    bidirectional_splitter, parallel_link_finder, network_zone_joiner) run
    sequentially afterward, followed by a second parallel round of
    matrix_builder (one per mode).

    Parameters
    ----------
    min_lon, min_lat, max_lon, max_lat:
        Bounding box in decimal degrees (WGS-84).
    modes:
        One or more transport modes, e.g. ``["CAR"]`` or ``["CAR", "BIKE"]``.
        All modes must be recognised (see ``VALID_MODES``).  ``"PEDESTRIAN"``
        cannot be combined with other modes.
    name:
        Human-readable area name passed to network_fetcher.
    out_dir:
        Output directory; created automatically if it does not exist.
    mode_label:
        External name used in output filenames, e.g. ``"MIXED"``.  Defaults to
        ``"MIXED"`` when more than one mode is given, or ``modes[0]`` for a
        single mode.  Must not contain a hyphen.
    catalog:
        Databricks Unity Catalog name.
    schema:
        Databricks schema / dataset version.
    refresh:
        Re-run all steps even when the final output files already exist.
    debug:
        Write in-memory FeatureCollections after each step to
        ``STEP_{n}_…`` snapshot files.
    exclude_zones:
        Optional list of ``zoneId`` strings to exclude from the zone fetch.
    max_routes:
        Maximum number of k-shortest routes per OD pair produced by
        matrix_builder.  Default is ``2``.
    nvp_table:
        Fully qualified Databricks NVP table name.  When provided (together
        with *nvp_year*) an optional step runs ``nvp_mapper`` to produce
        a ``{area_id}-NVP-ROUTES-{m}.csv`` for each eligible mode
        (``"CAR"`` and ``"BIKE"``).  Silently skipped for other modes.
    nvp_year:
        NVP ``location_year`` value to filter on (e.g. ``2025``).  Required
        when *nvp_table* is set.
    area_id:
        Optional area UUID override.  When omitted the UUID is discovered from
        existing files in *out_dir*, or a fresh ``uuid4()`` is generated for a
        new area.

    Returns
    -------
    str
        The area UUID used for this run.
    """
    # Normalise and validate
    modes = [m.strip().upper() for m in modes]
    if mode_label is None:
        mode_label = "MIXED" if len(modes) > 1 else modes[0]
    else:
        mode_label = mode_label.strip().upper()
    _validate_modes(modes, mode_label)

    _is_pedestrian = modes == ["PEDESTRIAN"]
    out_dir.mkdir(parents=True, exist_ok=True)
    area_id = _discover_or_create_area_id(out_dir, area_id)

    # Final output paths (the only files written to disk)
    network_path   = out_dir / f"{area_id}-NETWORK-{mode_label}.parquet"
    feedlinks_path = out_dir / f"{area_id}-FEEDLINK-{mode_label}.parquet"
    # Zones use the same mode_label as network/feedlinks — they are not mode-specific.
    zone_path: Path = out_dir / f"{area_id}-ZONE-{mode_label}.parquet"
    routes_paths: dict[str, Path] = {
        m: out_dir / f"{area_id}-ROUTES-{m}.parquet" for m in modes
    }

    bbox = [min_lon, min_lat, max_lon, max_lat]

    print()
    print("============================================================")
    print(" GMT Pipeline (in-process)")
    print(f" bbox       : {min_lon} {min_lat} {max_lon} {max_lat}")
    print(f" modes      : {', '.join(modes)}")
    print(f" mode-label : {mode_label}")
    print(f" name       : {name}")
    print(f" area-id    : {area_id}")
    print(f" out        : {out_dir}")
    print(f" refresh    : {'yes' if refresh else 'no (skipping when final outputs exist)'}")
    print(f" debug      : {'yes (snapshots enabled)' if debug else 'no'}")
    print("============================================================")

    # ------------------------------------------------------------------
    # Early exit: all final outputs exist and refresh=False
    # ------------------------------------------------------------------
    if not refresh:
        finals = (
            [network_path, zone_path]
            if _is_pedestrian
            else [network_path, feedlinks_path, zone_path, *routes_paths.values()]
        )
        if all(f.exists() for f in finals):
            print()
            print("All final outputs already exist — skipping pipeline (use --refresh to force).")
            return area_id

    # Shared Databricks connector — called per-thread inside per-mode tracks.
    from shared.databricks_sql import connect_from_env  # noqa: PLC0415

    # ======================================================================
    # STEP 1 — zone_fetcher  (sequential, shared across all modes)
    # ======================================================================
    print()
    print("[1] zone_fetcher ...")
    if _is_pedestrian:
        zones_fc = _make_pedestrian_stub_zones(area_id, min_lon, min_lat, max_lon, max_lat)
    else:
        from zone_fetcher.domain.sql import (  # noqa: PLC0415
            bbox_to_polygon_json,
            build_fetch_zones_sql,
        )
        from zone_fetcher.domain.zone import (  # noqa: PLC0415
            rows_to_feature_collection as _zones_rows_to_fc,
        )

        _zf_polygon = bbox_to_polygon_json(bbox)
        _zf_sql = build_fetch_zones_sql(catalog, schema)
        with connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute(_zf_sql, (_zf_polygon,))
                _zf_cols = [d[0] for d in cur.description]
                _zf_rows = cur.fetchall()
        zones_fc = _zones_rows_to_fc(
            _zf_rows, _zf_cols, area_id, bbox,
            exclude_zone_ids=set(exclude_zones) if exclude_zones else None,
        )
        zones_fc.setdefault("properties", {})["name"] = name
        print(f"  {len(zones_fc.get('features') or [])} zone features fetched")

    if debug:
        _snapshot(1, area_id, out_dir, ZONES=zones_fc)

    # Shared inputs derived from zones_fc — all read-only for the mode threads.
    _area_polygon_json = _extract_area_polygon_json(zones_fc)

    from shared.region import determine_region  # noqa: PLC0415

    _region: str | None = None
    _holiday_path = ARTIFACTS / "indices" / "holiday_regions.geojson"
    if _holiday_path.exists():
        _hfc = json.loads(_holiday_path.read_text(encoding="utf-8"))
        _region = determine_region(bbox, _hfc.get("features") or [])

    # gids used by feedlink_fetcher — derived once, shared across threads.
    _gids: list[int] = [
        int(feat["properties"]["gid"])
        for feat in (zones_fc.get("features") or [])
        if (feat.get("properties") or {}).get("zoneClass") != "AREA"
        and (feat.get("properties") or {}).get("gid") is not None
    ]

    # ======================================================================
    # PER-MODE PARALLEL TRACKS
    # Each track: network_fetcher → network_simplifier → network_cleaner →
    #             feedlink_fetcher
    # Returns: (mode, network_fc, feedlink_features)
    # ======================================================================
    def _run_mode_track(
        mode: str,
    ) -> tuple[str, dict, list[dict]]:
        from network_fetcher.core.network_fetcher_core import (  # noqa: PLC0415
            build_intersection_sql,
            get_pt_params,
            rows_to_feature_collection as _net_rows_to_fc,
        )
        from network_simplifier.core.network_simplifier_core import (  # noqa: PLC0415
            simplify_network,
        )
        from network_cleaner.core.network_cleaner_core import clean_network  # noqa: PLC0415

        # ── network_fetcher ──────────────────────────────────────────────
        print(f"  [{mode}] network_fetcher ...")
        _net_sql = build_intersection_sql(mode, catalog, schema)
        with connect_from_env() as _conn:
            with _conn.cursor() as _cur:
                if mode in _PT_MODES:
                    _link_mode, _modaliteit = get_pt_params(mode)
                    _cur.execute(_net_sql, (_link_mode, _area_polygon_json, _modaliteit, mode))
                else:
                    _cur.execute(_net_sql, (_area_polygon_json,))
                _net_cols = [d[0] for d in _cur.description]
                _net_rows = _cur.fetchall()
        _net_fc = _net_rows_to_fc(_net_rows, _net_cols, mode)
        print(f"  [{mode}] {len(_net_fc.get('features') or []):,} links fetched")

        # ── network_simplifier ───────────────────────────────────────────
        print(f"  [{mode}] network_simplifier ...")
        _net_fc, _simplify_stats = simplify_network(_net_fc)
        print(f"  [{mode}] {len(_net_fc.get('features') or [])} links after simplification")

        # ── network_cleaner ──────────────────────────────────────────────
        print(f"  [{mode}] network_cleaner ...")
        _net_fc, _clean_stats = clean_network(_net_fc)
        print(
            f"  [{mode}] {_clean_stats['kept']} kept, "
            f"{_clean_stats['removed']} removed"
        )

        # ── feedlink_fetcher  (skipped for PEDESTRIAN) ───────────────────
        _feedlink_features: list[dict] = []
        if not _is_pedestrian:
            from feedlink_fetcher.core.feedlink_fetcher_core import (  # noqa: PLC0415
                VOEDINGSLINKS_TABLE,
                build_feedlinks,
                build_voedingslinks_sql,
                parse_network_geojson,
            )
            print(f"  [{mode}] feedlink_fetcher ...")
            _node_positions, _all_node_ids = parse_network_geojson(_net_fc)
            _vl_table = VOEDINGSLINKS_TABLE.get(mode)
            _fl_rows: list[dict] = []
            if _vl_table:
                _fl_sql = build_voedingslinks_sql(catalog, schema, _vl_table, _gids)
                with connect_from_env() as _conn:
                    with _conn.cursor() as _cur:
                        _cur.execute(_fl_sql)
                        _fl_cols = [d[0] for d in _cur.description]
                        _fl_rows = [dict(zip(_fl_cols, row)) for row in _cur.fetchall()]
                print(f"  [{mode}] {len(_fl_rows)} voedingslinks rows fetched")
            else:
                print(f"  [{mode}] no voedingslinks table — feedlinks from zone centroids only")
            _fl_fc = build_feedlinks(
                zones_fc, _node_positions, _all_node_ids, _fl_rows, mode,
            )
            _feedlink_features = _fl_fc.get("features") or []

        return mode, _net_fc, _feedlink_features

    # Run all mode tracks in parallel (single mode = no overhead, still correct).
    print()
    print(f"[parallel] per-mode tracks ({', '.join(modes)}) ...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(modes)) as _pool:
        _futures = {m: _pool.submit(_run_mode_track, m) for m in modes}
    # Collect in mode-insertion order; futures are already done after the with-block.
    _track_results: dict[str, tuple] = {m: _futures[m].result() for m in modes}

    # Unpack per-mode results.
    _mode_fcs: list[dict] = [_track_results[m][1] for m in modes]
    _all_feedlink_features: list[dict] = [
        feat for m in modes for feat in _track_results[m][2]
    ]

    # Merge per-mode networks into a single FeatureCollection.
    from network_fetcher.core.network_fetcher_core import (  # noqa: PLC0415
        merge_network_feature_collections,
    )
    network_fc = merge_network_feature_collections(_mode_fcs)
    network_fc.setdefault("properties", {}).update({
        "bbox":      bbox,
        "region":    _region,
        "area_id":   area_id,
        "name":      name,
        "modeLabel": mode_label,
    })
    print(f"  {len(network_fc.get('features') or []):,} network links total")

    if debug:
        _snapshot(2, area_id, out_dir, NETWORK_RAW=network_fc)

    # ======================================================================
    # STEP 2 — network_fuser (multi-mode only)
    # Must run BEFORE bidirectional_splitter so that undirected link pairs
    # are trivially available and reverseLinkIds is not yet needed.
    # The splitter applies its own per-direction lateral displacement after.
    # ======================================================================
    if len(modes) > 1:
        print()
        print("[2] network_fuser ...")

        from network_fuser.core.network_fuser_core import fuse_networks  # noqa: PLC0415

        network_fc, _node_map, _link_pairs, _fuser_stats = fuse_networks(
            network_fc,
            max_lateral_dist_m=2.0,
        )
        print(
            f"  car_links={_fuser_stats['car_links']}  "
            f"bike_eligible={_fuser_stats['bike_eligible']}  "
            f"link_pairs={_fuser_stats['link_pairs']}  "
            f"(reversed={_fuser_stats['reverse_matches']}  "
            f"fused={_fuser_stats['fused_bike']})  "
            f"skipped_wegtype={_fuser_stats['skipped_wegtype']}"
        )

        if debug:
            _snapshot(3, area_id, out_dir, NETWORK_FUSED=network_fc)
    else:
        print()
        print("[2] network_fuser ... SKIPPED (single mode)")

    # ======================================================================
    # STEP 3 — bidirectional_splitter
    # ======================================================================
    print()
    print("[3] bidirectional_splitter ...")

    from bidirectional_splitter.core.bidirectional_splitter_core import (  # noqa: PLC0415
        post_process_features,
    )

    _split_features = post_process_features(network_fc.get("features") or [])
    network_fc = {
        "type": "FeatureCollection",
        "features": _split_features,
        "properties": network_fc.get("properties") or {},
    }
    print(f"  {len(_split_features)} links after bidirectional split")

    if debug:
        _snapshot(4, area_id, out_dir, NETWORK_SPLIT=network_fc)

    # ======================================================================
    # STEP 4 — parallel_link_finder
    # Run per mode so that CAR links are only matched against other CAR links,
    # and BIKE links only against BIKE links.  Running on the combined network
    # would cause the KD-tree to assign cross-mode matches (a CAR link stealing
    # the mapping slot from the nearest BIKE link) even when the mode filter in
    # the core rejects the final pairing.
    # ======================================================================
    print()
    print("[4] parallel_link_finder ...")

    from parallel_link_finder.core.parallel_link_finder_core import (  # noqa: PLC0415
        find_parallel_links,
    )

    _enriched_features: list[dict] = []
    for _m in modes:
        _mode_fc = _filter_fc_by_mode(network_fc, _m)
        _mode_enriched, _parallel_stats = find_parallel_links(_mode_fc)
        _enriched_features.extend(_mode_enriched.get("features") or [])
        print(
            f"  [{_m}] enriched={_parallel_stats['features_enriched']}  "
            f"skipped={_parallel_stats['features_skipped']}"
        )
    network_fc = {**network_fc, "features": _enriched_features}

    if debug:
        _snapshot(5, area_id, out_dir, NETWORK=network_fc)

    # ======================================================================
    # PEDESTRIAN early exit — derive node zones, write network + zones
    # ======================================================================
    if _is_pedestrian:
        print()
        print("[pedestrian] node-zone derivation ...")
        zones_fc = _make_pedestrian_zones(network_fc, area_id, min_lon, min_lat, max_lon, max_lat)
        if debug:
            _snapshot(6, area_id, out_dir, ZONES_PEDESTRIAN=zones_fc)

        network_path.write_bytes(to_geoparquet(network_fc))
        zone_path.write_bytes(to_geoparquet(zones_fc))

        print()
        print("============================================================")
        print(" Pipeline complete (PEDESTRIAN — network cutout only).")
        print(f" Network : {network_path}")
        print(f" Zones   : {zone_path}")
        print("============================================================")
        return area_id

    # ======================================================================
    # STEP 4/opt — nvp_mapper  (per eligible mode, sequential)
    # ======================================================================
    _nvp_eligible = [m for m in modes if m in ("CAR", "BIKE")]
    if nvp_table is not None and nvp_year is not None and _nvp_eligible:
        from nvp_mapper.domain.sql import fetch_nvp  # noqa: PLC0415
        from nvp_mapper.core.nvp_mapper_core import map_nvp_trips  # noqa: PLC0415

        _nvp_bbox = (network_fc.get("properties") or {}).get("bbox") or bbox
        _nvp_min_lon, _nvp_min_lat, _nvp_max_lon, _nvp_max_lat = (float(v) for v in _nvp_bbox)
        _nvp_polygon = json.dumps(
            _bbox_polygon_geom(_nvp_min_lon, _nvp_min_lat, _nvp_max_lon, _nvp_max_lat)
        )

        for _nvp_m in _nvp_eligible:
            print()
            print(f"[4/opt] nvp_mapper ({_nvp_m}) ...")
            _nvp_conn = connect_from_env()
            _nvp_links, _nvp_vertlengths, _nvp_vertxys, _nvp_vertdxys, _linktrips1 = fetch_nvp(
                _nvp_conn.cursor(), nvp_table, _nvp_polygon, _nvp_m, nvp_year
            )
            _nvp_conn.close()

            _nvp_stats, _match_rows = map_nvp_trips(
                network_fc,
                nvp_links=_nvp_links,
                nvp_vertlengths=_nvp_vertlengths,
                nvp_vertxys=_nvp_vertxys,
                nvp_vertdxys=_nvp_vertdxys,
                linktrips1=_linktrips1,
            )
            _write_nvp_csv(_match_rows, out_dir / f"{area_id}-NVP-ROUTES-{_nvp_m}.csv")
            print(
                f"  matched {_nvp_stats.get('matched_links', '?')} / "
                f"{_nvp_stats.get('spectrum_links', '?')} links"
            )

    # ======================================================================
    # STEP 5 — network_zone_joiner
    # ======================================================================
    print()
    print("[5] network_zone_joiner ...")

    feedlinks_fc = {
        "type": "FeatureCollection",
        "features": _all_feedlink_features,
        "properties": {"area_id": area_id},
    }
    print(f"  {len(_all_feedlink_features)} feedlinks total")

    from network_zone_joiner.core.network_zone_joiner_core import (  # noqa: PLC0415
        join_zones_to_network,
    )

    _joiner_zones = zones_fc

    results = join_zones_to_network(
        _joiner_zones, network_fc,
        zone_classes={"AREA"},
        feedlinks_fc=feedlinks_fc,
        adjust_boundary_demands=True,
    )

    _all_net_feats: list[dict] = []
    _all_zone_feats: list[dict] = []
    _all_fl_feats: list[dict] = []

    for _zone_feat, _clipped_net_fc, _zone_fc_result, _ext_fl_fc in results:
        _all_net_feats.extend(_clipped_net_fc.get("features") or [])
        _all_zone_feats.extend(_zone_fc_result.get("features") or [])
        _all_fl_feats.extend(_ext_fl_fc.get("features") or [])

    _deduped_zones = _dedup_zone_features(_all_zone_feats)
    if len(_deduped_zones) < len(_all_zone_feats):
        print(
            f"  Deduplication: removed {len(_all_zone_feats) - len(_deduped_zones)} "
            f"duplicate zone feature(s)"
        )

    _deduped_net = _dedup_net_features(_all_net_feats)
    if len(_deduped_net) < len(_all_net_feats):
        print(
            f"  Deduplication: removed {len(_all_net_feats) - len(_deduped_net)} "
            f"duplicate network link(s)"
        )

    network_fc = {**network_fc, "features": _deduped_net}
    zone_fc = {
        "type": "FeatureCollection",
        "features": _deduped_zones,
        "properties": {
            **(zones_fc.get("properties") or {}),
            "modes": (network_fc.get("properties") or {}).get("modes") or [],
        },
    }
    _fl_base_props = feedlinks_fc.get("properties") or {}
    feedlinks_fc = {
        "type": "FeatureCollection",
        "features": _all_fl_feats,
        "properties": {**_fl_base_props},
    }

    print(
        f"  Joined: {len(_deduped_net)} net links, "
        f"{len(_deduped_zones)} zones, {len(_all_fl_feats)} feedlinks"
    )

    if debug:
        _snapshot(6, area_id, out_dir, NETWORK=network_fc, ZONE=zone_fc, FEEDLINKS=feedlinks_fc)

    # ======================================================================
    # STEP 6 — matrix_builder  (per mode — routes are never labelled MIXED)
    # Runs in parallel, one thread per mode.
    # ======================================================================
    print()
    print(f"[parallel] matrix_builder ({', '.join(modes)}) ...")

    from matrix_builder.core.matrix_builder_core import build_matrix  # noqa: PLC0415

    def _build_mode_matrix(mode: str) -> tuple[str, dict]:
        _mode_network_fc = _filter_fc_by_mode(network_fc, mode)
        # zone_fc already contains refined (split) zones for BIKE — zone_refiner
        # ran in the per-mode track and the joiner used those geometries directly.
        _routes_fc = build_matrix(
            _mode_network_fc, feedlinks_fc, zone_fc, max_routes=max_routes,
        )
        return mode, _routes_fc

    with concurrent.futures.ThreadPoolExecutor(max_workers=len(modes)) as _pool:
        _mb_futures = {m: _pool.submit(_build_mode_matrix, m) for m in modes}
    routes_by_mode: dict[str, dict] = {m: _mb_futures[m].result()[1] for m in modes}

    for _m, _rfc in routes_by_mode.items():
        print(f"  [{_m}] {len(_rfc.get('features') or []):,} route features built")

    if debug:
        _snapshot(7, area_id, out_dir,
                  **{f"ROUTES_{_m}": _fc for _m, _fc in routes_by_mode.items()})

    # ======================================================================
    # Write final outputs
    # ======================================================================
    network_path.write_bytes(to_geoparquet(network_fc))
    feedlinks_path.write_bytes(to_geoparquet(feedlinks_fc))
    zone_path.write_bytes(to_geoparquet(zone_fc))
    for _m, _routes_fc in routes_by_mode.items():
        routes_paths[_m].write_bytes(to_geoparquet(_routes_fc))

    print()
    print("============================================================")
    print(" Pipeline complete.")
    print(f" Network            : {network_path}")
    print(f" Feedlinks          : {feedlinks_path}")
    print(f" Zones              : {zone_path}")
    for _m, _rpath in routes_paths.items():
        print(f" OD matrix ({_m:<12}): {_rpath}")
    print("============================================================")

    return area_id
