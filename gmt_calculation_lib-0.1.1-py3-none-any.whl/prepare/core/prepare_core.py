"""
prepare_core.py — GMT preparation pipeline orchestration logic.

Contains the full 10-step pipeline (zone_fetcher → matrix_builder) plus all
supporting helpers.  Import and call ``run_pipeline`` from a local runner,
notebook, or Lambda handler.
"""

from __future__ import annotations

import json
import shutil
import subprocess
import sys
import uuid
from pathlib import Path

# ---------------------------------------------------------------------------
# Repo-root paths
# ---------------------------------------------------------------------------

_CORE_FILE  = Path(__file__).resolve()
REPO_ROOT   = _CORE_FILE.parent.parent.parent.parent  # src/prepare/core/ -> src/prepare/ -> src/ -> repo root
SCRIPTS_DIR = REPO_ROOT / "scripts"
ARTIFACTS   = REPO_ROOT / "artifacts"

# ---------------------------------------------------------------------------
# Step constants
# ---------------------------------------------------------------------------

N_STEPS = 10
_STEP_ORDER = ("1", "2", "3", "4", "5", "6", "7", "8", "9", "10")


# ---------------------------------------------------------------------------
# UUID helpers
# ---------------------------------------------------------------------------


def _load_or_create_area_id(out_dir: Path) -> str:
    """Read .area-uuid from *out_dir*, creating it (with a fresh UUID) if absent."""
    uuid_file = out_dir / ".area-uuid"
    if uuid_file.exists():
        return uuid_file.read_text(encoding="utf-8").strip()
    area_id = str(uuid.uuid4())
    uuid_file.write_text(area_id, encoding="utf-8")
    return area_id


# ---------------------------------------------------------------------------
# Step-range helpers
# ---------------------------------------------------------------------------


def _done(current: str, until: str | None) -> bool:
    """Return True when *current* is the last step that should run."""
    if until is None:
        return False
    try:
        return _STEP_ORDER.index(current) >= _STEP_ORDER.index(until)
    except ValueError:
        return False


def _skip(current: str, start: str | None) -> bool:
    """Return True when *current* step should be skipped (it precedes *start*)."""
    if start is None:
        return False
    try:
        return _STEP_ORDER.index(current) < _STEP_ORDER.index(start)
    except ValueError:
        return False


# ---------------------------------------------------------------------------
# Subprocess step runner
# ---------------------------------------------------------------------------


def _run_step(
    label: str,
    module: str,
    args: list[str],
    output: Path | None = None,
    *,
    refresh: bool,
) -> None:
    """Run one pipeline step as a subprocess.

    If *output* is given and already exists and *refresh* is False the step is
    skipped.  On failure the VS Code launch.json is updated and ``SystemExit``
    is raised.
    """
    print()
    if output is not None and output.exists() and not refresh:
        print(f"{label} ... SKIPPED (output exists)")
        return

    print(f"{label} ...")
    src_dir   = str(REPO_ROOT / "src")
    bootstrap = (
        f"import sys; sys.path.insert(0, {src_dir!r}); "
        f"import runpy; runpy.run_module({module!r}, run_name='__main__', alter_sys=True)"
    )
    cmd    = [sys.executable, "-c", bootstrap, *args]
    result = subprocess.run(cmd)
    if result.returncode != 0:
        print(f"ERROR in {label}", file=sys.stderr)
        _update_launch_json(label, module, args)
        sys.exit(result.returncode)


def _update_launch_json(label: str, module: str, module_args: list[str]) -> None:
    update_script = SCRIPTS_DIR / "update_launch_json.py"
    subprocess.run([sys.executable, str(update_script), label, module, *module_args])


# ---------------------------------------------------------------------------
# Debug snapshot helper
# ---------------------------------------------------------------------------


def _snapshot(step_num: int, area_id: str, out_dir: Path, *files: Path) -> None:
    """Copy *files* into debug snapshots named ``STEP_{n}_{area_id}_{PRODUCT}_{MODE}.geojson``."""
    for src in files:
        if not src.exists():
            print(f"  [debug] snapshot skipped — {src.name} does not exist")
            continue
        suffix = src.stem.removeprefix(f"{area_id}-").replace("-", "_")
        dst = out_dir / f"STEP_{step_num}_{area_id}_{suffix}.geojson"
        shutil.copy2(src, dst)
        print(f"  [debug] snapshot -> {dst.name}")


# ---------------------------------------------------------------------------
# Zone-fetcher geometry extractor
# ---------------------------------------------------------------------------


def _bbox_polygon_geom(
    min_lon: float, min_lat: float, max_lon: float, max_lat: float
) -> dict:
    """Return a GeoJSON Polygon geometry dict for the given bounding box."""
    return {
        "type": "Polygon",
        "coordinates": [[
            [min_lon, min_lat],
            [max_lon, min_lat],
            [max_lon, max_lat],
            [min_lon, max_lat],
            [min_lon, min_lat],
        ]],
    }


def _make_pedestrian_stub_zones(
    area_id: str,
    min_lon: float, min_lat: float, max_lon: float, max_lat: float,
    zones_path: Path,
) -> None:
    """Write a minimal ZONES GeoJSON with only an AREA feature (bbox polygon).

    This satisfies :func:`_extract_area_polygon_json` so that the
    network_fetcher polygon argument can be derived without a real
    Databricks zone query.
    """
    fc = {
        "type": "FeatureCollection",
        "features": [{
            "type": "Feature",
            "geometry": _bbox_polygon_geom(min_lon, min_lat, max_lon, max_lat),
            "properties": {
                "zoneId":    area_id,
                "zoneClass": "AREA",
                "zoneName":  "Area",
            },
        }],
        "properties": {"areaId": area_id},
    }
    zones_path.write_text(json.dumps(fc, ensure_ascii=False), encoding="utf-8")
    print(f"  [pedestrian] stub zones written -> {zones_path.name}")


def _make_pedestrian_zones(
    network_path: Path,
    area_id: str,
    min_lon: float, min_lat: float, max_lon: float, max_lat: float,
    zones_path: Path,
) -> None:
    """Derive pedestrian zones from the cleaned network nodes.

    Each unique node (``fromNode`` / ``toNode``) in the directed network
    becomes one ``NODE``-class zone feature.  Production is the sum of
    ``flow`` on outgoing links; attraction is the sum of ``flow`` on
    incoming links.  The AREA feature (bbox polygon) is included so that
    downstream steps can still find it.
    """
    fc = json.loads(network_path.read_text(encoding="utf-8"))
    features = fc.get("features") or []

    node_pos: dict[str, tuple[float, float]] = {}
    node_prod: dict[str, float] = {}
    node_attr: dict[str, float] = {}

    for feat in features:
        props  = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords:
            continue

        from_node = str(props.get("fromNode") or "")
        to_node   = str(props.get("toNode")   or "")
        flow      = float(props.get("flow")    or 0.0)

        if from_node:
            lon, lat = float(coords[0][0]), float(coords[0][1])
            node_pos.setdefault(from_node, (lon, lat))
            node_prod[from_node] = node_prod.get(from_node, 0.0) + flow

        if to_node and len(coords) >= 2:
            lon, lat = float(coords[-1][0]), float(coords[-1][1])
            node_pos.setdefault(to_node, (lon, lat))
            node_attr[to_node] = node_attr.get(to_node, 0.0) + flow

    zone_features: list[dict] = [{
        "type": "Feature",
        "geometry": _bbox_polygon_geom(min_lon, min_lat, max_lon, max_lat),
        "properties": {
            "zoneId":    area_id,
            "zoneClass": "AREA",
            "zoneName":  "Area",
        },
    }]

    for node_id, (lon, lat) in sorted(node_pos.items()):
        production = round(node_prod.get(node_id, 0.0), 4)
        attraction = round(node_attr.get(node_id, 0.0), 4)
        zone_features.append({
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [lon, lat]},
            "properties": {
                "zoneId":      node_id,
                "zoneClass":   "NODE",
                "zoneName":    f"node_{node_id}",
                "centroidLon": lon,
                "centroidLat": lat,
                "production":  production,
                "attraction":  attraction,
            },
        })

    out_fc = {
        "type": "FeatureCollection",
        "features": zone_features,
        "properties": {"areaId": area_id},
    }
    zones_path.write_text(json.dumps(out_fc, ensure_ascii=False), encoding="utf-8")
    n_nodes = len(zone_features) - 1
    print(f"  [pedestrian] {n_nodes} node zones derived -> {zones_path.name}")


def _extract_area_polygon_json(zones_file: Path) -> str:
    """Return the GeoJSON geometry string of the AREA feature in *zones_file*.

    Raises ``ValueError`` when no AREA feature is found.
    """
    fc = json.loads(zones_file.read_text(encoding="utf-8"))
    for feature in fc.get("features", []):
        if (feature.get("properties") or {}).get("zoneClass") == "AREA":
            return json.dumps(feature["geometry"])
    raise ValueError(f"No AREA feature found in {zones_file}")


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


def run_pipeline(
    min_lon: float,
    min_lat: float,
    max_lon: float,
    max_lat: float,
    mode: str,
    name: str,
    out_dir: Path,
    *,
    catalog: str,
    schema: str,
    refresh: bool,
    debug: bool,
    start_step: str | None = None,
    until_step: str | None = None,
    repair_gaps: bool = False,
    exclude_zones: list[str] | None = None,
    max_routes: int = 2,
) -> None:
    """Run the full GMT preparation pipeline (10 steps).

    Parameters
    ----------
    min_lon, min_lat, max_lon, max_lat:
        Bounding box in decimal degrees (WGS-84).
    mode:
        Transport mode, e.g. ``"CAR"``, ``"BIKE"``.
    name:
        Human-readable area name passed to ``network_fetcher``.
    out_dir:
        Output directory; created automatically if it does not exist.
    catalog:
        Databricks Unity Catalog name (default: ``"spectrum"``).
    schema:
        Databricks schema / dataset version (default: ``"2023_01"``).
    refresh:
        Re-run steps even when their output file already exists.
    debug:
        Copy outputs after each step to ``STEP_{n}_…`` snapshot files.
    start_step:
        Skip all steps before this one (1-based string, e.g. ``"3"``).
    until_step:
        Stop after this step and skip the rest.
    repair_gaps:
        Run gap_detector (step 4) and insert bridging links for detected gaps.
        When ``False`` (default) step 4 is skipped entirely.
    exclude_zones:
        Optional list of ``zoneId`` strings to exclude from the zone fetch
        (step 1).  Excluded zones are removed before the BFS adjacency filter
        and therefore absent from all downstream steps.
    max_routes:
        Maximum number of k-shortest routes per OD pair produced by
        matrix_builder (step 10).  Default is ``2``.
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    area_id = _load_or_create_area_id(out_dir)

    # Derived artifact paths
    od_file          = out_dir / f"{area_id}-ROUTES-{mode}.geojson"
    zones_fetched    = out_dir / f"{area_id}-ZONES.geojson"
    network_raw      = out_dir / f"{area_id}-NETWORK-RAW-{mode}.geojson"
    network_simple   = out_dir / f"{area_id}-NETWORK-SIMPLE-{mode}.geojson"
    simplified_nodes = out_dir / f"{area_id}-SIMPLIFIED-NODES-{mode}.geojson"
    network          = out_dir / f"{area_id}-NETWORK-{mode}.geojson"
    gaps_report      = out_dir / f"{area_id}-GAPS-{mode}.json"
    feedlinks        = out_dir / f"{area_id}-FEEDLINK-{mode}.geojson"
    zone_file        = out_dir / f"{area_id}-ZONE-{mode}.geojson"

    print()
    print("============================================================")
    print(" GMT Pipeline")
    print(f" bbox    : {min_lon} {min_lat} {max_lon} {max_lat}")
    print(f" mode    : {mode}")
    print(f" name    : {name}")
    print(f" area-id : {area_id}")
    print(f" out     : {out_dir}")
    print(f" refresh : {'yes' if refresh else 'no (skipping existing outputs)'}")
    print(f" steps   : {N_STEPS}")
    print(f" from    : step {start_step}" if start_step else " from    : step 1")
    print(f" until   : step {until_step}" if until_step else " until   : all steps")
    print(f" debug   : {'yes (snapshots enabled)' if debug else 'no'}")
    print("============================================================")

    # STEP 1 — zone_fetcher  (PEDESTRIAN: stub zones, no Databricks query)
    if not _skip("1", start_step):
        if mode == "PEDESTRIAN":
            print()
            if not zones_fetched.exists() or refresh:
                print(f"[1/{N_STEPS}] zone_fetcher (pedestrian stub) ...")
                _make_pedestrian_stub_zones(
                    area_id, min_lon, min_lat, max_lon, max_lat, zones_fetched
                )
            else:
                print(f"[1/{N_STEPS}] zone_fetcher (pedestrian stub) ... SKIPPED (output exists)")
        else:
            _run_step(
                f"[1/{N_STEPS}] zone_fetcher",
                "zone_fetcher.zone_fetcher_runner",
                [
                    "--bbox",          str(min_lon), str(min_lat), str(max_lon), str(max_lat),
                    "--output-folder", str(out_dir),
                    "--area-id",       area_id,
                    "--name",          name,
                    "--catalog",       catalog,
                    "--schema",        schema,
                    *(["--exclude-zones", *exclude_zones] if exclude_zones else []),
                ],
                output=zones_fetched,
                refresh=refresh,
            )
        if debug:
            _snapshot(1, area_id, out_dir, zones_fetched)
    if _done("1", until_step):
        return

    area_polygon_json = _extract_area_polygon_json(zones_fetched)
    if debug:
        area_polygon_file = out_dir / f"{area_id}-AREA-POLYGON.geojson"
        area_polygon_file.write_text(area_polygon_json, encoding="utf-8")
        polygon_arg = str(area_polygon_file)
    else:
        polygon_arg = area_polygon_json

    # STEP 2 — network_fetcher
    if not _skip("2", start_step):
        _run_step(
            f"[2/{N_STEPS}] network_fetcher",
            "network_fetcher.network_fetcher_runner",
            [
                "--modes",         mode,
                "--polygon",       polygon_arg,
                "--output-folder", str(out_dir),
                "--area-id",       area_id,
                "--name",          name,
                "--catalog",       catalog,
                "--schema",        schema,
                "--regions-uri",   str(ARTIFACTS / "indices" / "holiday_regions.geojson"),
                *(["--debug"] if debug else []),
            ],
            output=network_raw,
            refresh=refresh,
        )
        if debug:
            _snapshot(2, area_id, out_dir, network_raw)
    if _done("2", until_step):
        return

    # STEP 3 — network_simplifier
    if not _skip("3", start_step):
        _run_step(
            f"[3/{N_STEPS}] network_simplifier",
            "network_simplifier.network_simplifier_runner",
            [
                "--network-file", str(network_raw),
                "--output-file",  str(network_simple),
                *(["--nodes-file", str(simplified_nodes)] if debug else []),
            ],
            output=network_simple,
            refresh=refresh,
        )
    if _done("3", until_step):
        return

    # STEP 4 — gap_detector (opt-in; skipped unless repair_gaps=True)
    if not _skip("4", start_step) and repair_gaps:
        _run_step(
            f"[4/{N_STEPS}] gap_detector",
            "gap_detector.gap_detector_runner",
            [
                "--network-file", str(network_simple),
                "--repair", "--output-file", str(network_simple),
                *(["--gaps-file", str(gaps_report)] if debug else []),
            ],
            output=None,
            refresh=refresh,
        )
        if debug:
            _snapshot(4, area_id, out_dir, gaps_report)
    if _done("4", until_step):
        return

    # STEP 5 — bidirectional_splitter
    if not _skip("5", start_step):
        _run_step(
            f"[5/{N_STEPS}] bidirectional_splitter",
            "bidirectional_splitter.bidirectional_splitter_runner",
            [
                "--input-uri",  str(network_simple),
                "--output-uri", str(network),
            ],
            output=network,
            refresh=refresh,
        )
        if debug:
            _snapshot(5, area_id, out_dir, network)
    if _done("5", until_step):
        return

    # STEP 6 — network_cleaner
    if not _skip("6", start_step):
        _run_step(
            f"[6/{N_STEPS}] network_cleaner",
            "network_cleaner.network_cleaner_runner",
            ["--networks", str(network)],
            output=None,
            refresh=refresh,
        )
        if debug:
            _snapshot(6, area_id, out_dir, network)
    if _done("6", until_step):
        return

    # STEP 7 — parallel_link_finder
    if not _skip("7", start_step):
        _run_step(
            f"[7/{N_STEPS}] parallel_link_finder",
            "parallel_link_finder.parallel_link_finder_runner",
            ["--networks", str(network)],
            output=None,
            refresh=refresh,
        )
        if debug:
            _snapshot(7, area_id, out_dir, network)
    if _done("7", until_step):
        return

    # PEDESTRIAN ends here — network is clean and split; derive node zones
    if mode == "PEDESTRIAN":
        print()
        print(f"[7.5/{N_STEPS}] pedestrian node-zone derivation ...")
        _make_pedestrian_zones(
            network, area_id, min_lon, min_lat, max_lon, max_lat, zones_fetched
        )
        if debug:
            _snapshot(7, area_id, out_dir, zones_fetched)
        print()
        print("============================================================")
        print(" Pipeline complete (PEDESTRIAN — network cutout only).")
        print(f" Network : {network}")
        print(f" Zones   : {zones_fetched}")
        print("============================================================")
        if not debug:
            _intermediates = [network_raw, network_simple, simplified_nodes, gaps_report]
            removed = [f for f in _intermediates if f.exists()]
            for f in removed:
                f.unlink()
            if removed:
                print()
                print(f" Cleaned up {len(removed)} intermediate file(s):")
                for f in removed:
                    print(f"   - {f.name}")
        return

    # STEP 8 — feedlink_fetcher
    if not _skip("8", start_step):
        _run_step(
            f"[8/{N_STEPS}] feedlink_fetcher",
            "feedlink_fetcher.feedlink_fetcher_runner",
            [
                "--zones-file",    str(zones_fetched),
                "--network-file",  str(network),
                "--output-folder", str(out_dir),
                "--area-id",       area_id,
                "--mode",          mode,
                "--catalog",       catalog,
                "--schema",        schema,
            ],
            output=feedlinks,
            refresh=refresh,
        )
        if debug:
            _snapshot(8, area_id, out_dir, feedlinks)
    if _done("8", until_step):
        return

    # STEP 9 — network_zone_joiner
    if not _skip("9", start_step):
        zone_classes_arg = "AREA"
        _run_step(
            f"[9/{N_STEPS}] network_zone_joiner",
            "network_zone_joiner.network_zone_joiner_runner",
            [
                "--zones-file",     str(zones_fetched),
                "--network-file",   str(network),
                "--feedlinks-file", str(feedlinks),
                "--zone-output",    str(zone_file),
                "--area-id",        area_id,
                "--mode",           mode,
                "--zone-classes",   zone_classes_arg,
            ],
            output=zone_file,
            refresh=refresh,
        )
        if debug:
            _snapshot(9, area_id, out_dir, network, zone_file, feedlinks)

    # STEP 10 — matrix_builder
    if not _skip("10", start_step):
        _run_step(
            f"[10/{N_STEPS}] matrix_builder",
            "matrix_builder.matrix_builder_runner",
            [
                "--network-file",   str(network),
                "--feedlinks-file", str(feedlinks),
                "--zone-file",      str(zone_file),
                "--output-folder",  str(out_dir),
                "--area-id",        area_id,
                "--mode",           mode,
                "--max-routes",     str(max_routes),
            ],
            output=None,  # always re-run: Dijkstra must always determine routes
            refresh=refresh,
        )
        if debug:
            _snapshot(10, area_id, out_dir, od_file)

    print()
    print("============================================================")
    print(" Pipeline complete.")
    print(f" Network            : {network}")
    print(f" Feedlinks          : {feedlinks}")
    print(f" Zone               : {zone_file}")
    print(f" OD matrix          : {od_file}")
    print("============================================================")

    # ── Cleanup intermediate files (skipped when debug=True) ──────────────────
    if not debug:
        _intermediates = [
            zones_fetched,
            network_raw,
            network_simple,
            simplified_nodes,
            gaps_report,
        ]
        removed = []
        for _f in _intermediates:
            if _f.exists():
                _f.unlink()
                removed.append(_f.name)
        if removed:
            print()
            print(f" Cleaned up {len(removed)} intermediate file(s):")
            for _name in removed:
                print(f"   - {_name}")
