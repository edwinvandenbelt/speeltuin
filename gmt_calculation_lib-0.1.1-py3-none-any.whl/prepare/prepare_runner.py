"""
prepare_runner.py — CLI entry point for the GMT preparation pipeline.

Usage
-----
    python -m prepare.prepare_runner <minLon> <minLat> <maxLon> <maxLat> \\
        <MODE> <NAME> <OUT_DIR> [--refresh] [--debug] \\
        [--catalog CATALOG] [--schema SCHEMA] \\
        [--repair-gaps] [--nvp-table TABLE --nvp-year YEAR]
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Ensure src/ is on sys.path when run directly (not via -m from repo root).
_RUNNER_FILE = Path(__file__).resolve()
_REPO_ROOT   = _RUNNER_FILE.parent.parent.parent  # src/prepare/ -> repo root
_SRC_DIR     = str(_REPO_ROOT / "src")
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

from prepare.core.prepare_core import run_pipeline  # noqa: E402


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


def _resolve_out_dir(raw: str) -> Path:
    """Return an absolute Path for OUT_DIR, relative to repo root if not absolute."""
    p = Path(raw)
    if p.is_absolute():
        return p
    return _REPO_ROOT / raw


def main() -> None:
    parser = argparse.ArgumentParser(
        description="GMT preparation pipeline — 10 fixed steps."
    )
    parser.add_argument("min_lon",  type=float, help="Western bbox boundary (decimal degrees).")
    parser.add_argument("min_lat",  type=float, help="Southern bbox boundary (decimal degrees).")
    parser.add_argument("max_lon",  type=float, help="Eastern bbox boundary (decimal degrees).")
    parser.add_argument("max_lat",  type=float, help="Northern bbox boundary (decimal degrees).")
    parser.add_argument("mode",     help="Transport mode, e.g. CAR, BIKE, PEDESTRIAN.")
    parser.add_argument("name",     help="Human-readable area name passed to network_fetcher.")
    parser.add_argument("out_dir",  help="Output directory (relative to repo root or absolute).")
    parser.add_argument("--refresh",  action="store_true",
                        help="Overwrite existing output files.")
    parser.add_argument("--debug",    action="store_true",
                        help="Copy outputs after each step to STEP_x_… snapshot files.")
    parser.add_argument("--catalog",  default="spectrum",
                        help="Databricks Unity Catalog name.  Default: spectrum.")
    parser.add_argument("--schema",   default="2023_01",
                        help="Databricks schema / dataset version.  Default: 2023_01.")
    parser.add_argument(
        "--repair-gaps", action="store_true", default=False,
        help="Run gap_detector (step 4) and insert bridging links for detected gaps (default: off, step 4 is skipped).",
    )
    parser.add_argument(
        "--max-routes",
        type=int,
        default=2,
        metavar="N",
        help="Maximum k-shortest routes per OD pair for matrix_builder (step 10). Default: 2.",
    )
    parser.add_argument(
        "--exclude-zones",
        nargs="+",
        default=[],
        metavar="ZONE_ID",
        help="One or more zoneId values to exclude from the zone fetch (step 1).",
    )
    parser.add_argument(
        "--nvp-table",
        default=None,
        metavar="TABLE",
        help=(
            "(Optional) Fully qualified Databricks NVP table name for step 7.5, "
            "e.g. nvp_experimental.silver.vw_segments.  "
            "When omitted, step 7.5 is skipped entirely."
        ),
    )
    parser.add_argument(
        "--nvp-year",
        type=int,
        default=None,
        metavar="YEAR",
        help=(
            "NVP location_year value to filter on (e.g. 2025).  "
            "Required when --nvp-table is set."
        ),
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="UUID",
        help=(
            "Pin the area UUID instead of auto-discovering it from existing files.  "
            "Useful when you want to re-use a specific ID for a new output folder."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        metavar="PATH",
        help="Path to .env file for Databricks + AWS credentials (auto-discovered if omitted).",
    )
    args = parser.parse_args()

    # Load credentials from .env (auto-discover tools/.env walking up from the runner file).
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    os.environ.setdefault("PYTHONPATH", _SRC_DIR)

    run_pipeline(
        min_lon=args.min_lon,
        min_lat=args.min_lat,
        max_lon=args.max_lon,
        max_lat=args.max_lat,
        mode=args.mode,
        name=args.name,
        out_dir=_resolve_out_dir(args.out_dir),
        catalog=args.catalog,
        schema=args.schema,
        refresh=args.refresh,
        debug=args.debug,
        repair_gaps=args.repair_gaps,
        exclude_zones=args.exclude_zones or None,
        max_routes=args.max_routes,
        nvp_table=args.nvp_table or None,
        nvp_year=args.nvp_year,
        area_id=args.area_id or None,
    )


if __name__ == "__main__":
    main()
