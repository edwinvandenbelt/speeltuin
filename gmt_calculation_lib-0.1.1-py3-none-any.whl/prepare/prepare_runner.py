"""
prepare_runner.py — CLI entry point for the GMT preparation pipeline.

Usage
-----
    python -m prepare.prepare_runner <minLon> <minLat> <maxLon> <maxLat> \\
        <MODE> <NAME> <OUT_DIR> [--refresh] [--debug] \\
        [--catalog CATALOG] [--schema SCHEMA] \\
        [--start-step STEP] [--until-step STEP] [--repair-gaps]
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

# Ensure src/ is on sys.path when run directly (not via -m from repo root).
_RUNNER_FILE = Path(__file__).resolve()
_REPO_ROOT   = _RUNNER_FILE.parent.parent.parent  # src/prepare/ -> repo root
_SRC_DIR     = str(_REPO_ROOT / "src")
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

from prepare.core.prepare_core import REPO_ROOT, _STEP_ORDER, run_pipeline  # noqa: E402


def _resolve_out_dir(raw: str) -> Path:
    """Return an absolute Path for OUT_DIR, relative to REPO_ROOT if not absolute."""
    p = Path(raw)
    if p.is_absolute():
        return p
    return REPO_ROOT / raw


def main() -> None:
    parser = argparse.ArgumentParser(
        description="GMT preparation pipeline — 10 fixed steps."
    )
    parser.add_argument("min_lon",  type=float, help="Western bbox boundary (decimal degrees).")
    parser.add_argument("min_lat",  type=float, help="Southern bbox boundary (decimal degrees).")
    parser.add_argument("max_lon",  type=float, help="Eastern bbox boundary (decimal degrees).")
    parser.add_argument("max_lat",  type=float, help="Northern bbox boundary (decimal degrees).")
    parser.add_argument("mode",     help="Transport mode, e.g. CAR, BIKE, PEDESTRIAN.")
    parser.add_argument("name",     help="Human-readable area name passed to network_fetcher.")
    parser.add_argument("out_dir",  help="Output directory (relative to repo root or absolute).")
    parser.add_argument("--refresh",  action="store_true",
                        help="Overwrite existing output files.")
    parser.add_argument("--debug",    action="store_true",
                        help="Copy outputs after each step to STEP_x_… snapshot files.")
    parser.add_argument("--catalog",  default="spectrum",
                        help="Databricks Unity Catalog name.  Default: spectrum.")
    parser.add_argument("--schema",   default="2023_01",
                        help="Databricks schema / dataset version.  Default: 2023_01.")
    parser.add_argument(
        "--start-step", default=None, choices=_STEP_ORDER, metavar="STEP",
        help=(
            f"Skip all steps before this step.  "
            f"Valid values: {', '.join(_STEP_ORDER)}.  Default: start from step 1."
        ),
    )
    parser.add_argument(
        "--until-step", default=None, choices=_STEP_ORDER, metavar="STEP",
        help=(
            f"Stop after this step and skip the rest.  "
            f"Valid values: {', '.join(_STEP_ORDER)}.  Default: run all steps."
        ),
    )
    parser.add_argument(
        "--repair-gaps", action="store_true", default=False,
        help="Run gap_detector (step 4) and insert bridging links for detected gaps (default: off, step 4 is skipped).",
    )
    parser.add_argument(
        "--max-routes",
        type=int,
        default=2,
        metavar="N",
        help="Maximum k-shortest routes per OD pair for matrix_builder (step 10). Default: 2.",
    )
    parser.add_argument(
        "--exclude-zones",
        nargs="+",
        default=[],
        metavar="ZONE_ID",
        help="One or more zoneId values to exclude from the zone fetch (step 1).",
    )
    args = parser.parse_args()

    os.environ.setdefault("PYTHONPATH", _SRC_DIR)

    run_pipeline(
        min_lon=args.min_lon,
        min_lat=args.min_lat,
        max_lon=args.max_lon,
        max_lat=args.max_lat,
        mode=args.mode,
        name=args.name,
        out_dir=_resolve_out_dir(args.out_dir),
        catalog=args.catalog,
        schema=args.schema,
        refresh=args.refresh,
        debug=args.debug,
        until_step=args.until_step,
        start_step=args.start_step,
        repair_gaps=args.repair_gaps,
        exclude_zones=args.exclude_zones or None,
        max_routes=args.max_routes,
    )


if __name__ == "__main__":
    main()
