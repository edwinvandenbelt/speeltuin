"""Unit tests for prepare.core.prepare_core — pure helper functions only."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from prepare.core.prepare_core import (
    _STEP_ORDER,
    _discover_or_create_area_id,
    _done,
    _extract_area_polygon_json,
    _skip,
)


# ---------------------------------------------------------------------------
# _done / _skip
# ---------------------------------------------------------------------------


class TestDone:
    def test_none_never_done(self):
        assert _done("3", None) is False

    def test_current_equals_until(self):
        assert _done("5", "5") is True

    def test_current_after_until(self):
        assert _done("6", "5") is True

    def test_current_before_until(self):
        assert _done("3", "5") is False

    def test_invalid_step_returns_false(self):
        assert _done("99", "5") is False

    def test_last_step(self):
        assert _done("10", "10") is True


class TestSkip:
    def test_none_never_skips(self):
        assert _skip("1", None) is False

    def test_current_equals_start(self):
        assert _skip("3", "3") is False

    def test_current_before_start(self):
        assert _skip("2", "5") is True

    def test_current_after_start(self):
        assert _skip("6", "5") is False

    def test_invalid_step_returns_false(self):
        assert _skip("99", "3") is False


# ---------------------------------------------------------------------------
# _discover_or_create_area_id
# ---------------------------------------------------------------------------


class TestDiscoverOrCreateAreaId:
    def test_generates_fresh_uuid_for_empty_dir(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            area_id = _discover_or_create_area_id(out_dir)
            assert len(area_id) == 36  # UUID format

    def test_discovers_from_existing_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "my-fixed-id-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _discover_or_create_area_id(out_dir) == "my-fixed-id"

    def test_stable_across_calls(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "stable-id-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            id1 = _discover_or_create_area_id(out_dir)
            id2 = _discover_or_create_area_id(out_dir)
            assert id1 == id2

    def test_explicit_override_takes_priority(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "other-id-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _discover_or_create_area_id(out_dir, area_id="forced-id") == "forced-id"


# ---------------------------------------------------------------------------
# _extract_area_polygon_json
# ---------------------------------------------------------------------------


class TestExtractAreaPolygonJson:
    def _make_zones_file(self, tmp: Path, features: list[dict]) -> Path:
        path = tmp / "zones.geojson"
        path.write_text(
            json.dumps({"type": "FeatureCollection", "features": features}),
            encoding="utf-8",
        )
        return path

    def test_extracts_area_geometry(self):
        with tempfile.TemporaryDirectory() as tmp:
            geom = {"type": "Polygon", "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 0]]]}
            path = self._make_zones_file(Path(tmp), [
                {"type": "Feature", "properties": {"zoneClass": "STUDY"}, "geometry": {}},
                {"type": "Feature", "properties": {"zoneClass": "AREA"}, "geometry": geom},
            ])
            result = json.loads(_extract_area_polygon_json(path))
            assert result == geom

    def test_raises_when_no_area_feature(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self._make_zones_file(Path(tmp), [
                {"type": "Feature", "properties": {"zoneClass": "STUDY"}, "geometry": {}},
            ])
            with pytest.raises(ValueError, match="No AREA feature"):
                _extract_area_polygon_json(path)

    def test_raises_on_empty_feature_collection(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self._make_zones_file(Path(tmp), [])
            with pytest.raises(ValueError):
                _extract_area_polygon_json(path)


# ---------------------------------------------------------------------------
# _STEP_ORDER sanity
# ---------------------------------------------------------------------------


def test_step_order_is_complete():
    assert _STEP_ORDER == ("1", "2", "3", "4", "5", "6", "7", "8", "9", "10")
