"""Unit tests for prepare.core.prepare_core — pure helper functions only."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from prepare.core.prepare_core import (
    _discover_or_create_area_id,
    _extract_area_polygon_json,
)


# ---------------------------------------------------------------------------
# _discover_or_create_area_id
# ---------------------------------------------------------------------------


class TestDiscoverOrCreateAreaId:
    def test_generates_fresh_uuid_for_empty_dir(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            area_id = _discover_or_create_area_id(out_dir)
            assert len(area_id) == 36  # UUID format

    def test_discovers_from_existing_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "my-fixed-id-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _discover_or_create_area_id(out_dir) == "my-fixed-id"

    def test_stable_across_calls(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "stable-id-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            id1 = _discover_or_create_area_id(out_dir)
            id2 = _discover_or_create_area_id(out_dir)
            assert id1 == id2

    def test_explicit_override_takes_priority(self):
        with tempfile.TemporaryDirectory() as tmp:
            out_dir = Path(tmp)
            (out_dir / "other-id-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _discover_or_create_area_id(out_dir, area_id="forced-id") == "forced-id"


# ---------------------------------------------------------------------------
# _extract_area_polygon_json
# ---------------------------------------------------------------------------


class TestExtractAreaPolygonJson:
    def _make_zones_fc(self, features: list[dict]) -> dict:
        return {"type": "FeatureCollection", "features": features}

    def test_extracts_area_geometry(self):
        geom = {"type": "Polygon", "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 0]]]}
        zones_fc = self._make_zones_fc([
            {"type": "Feature", "properties": {"zoneClass": "STUDY"}, "geometry": {}},
            {"type": "Feature", "properties": {"zoneClass": "AREA"}, "geometry": geom},
        ])
        result = json.loads(_extract_area_polygon_json(zones_fc))
        assert result == geom

    def test_raises_when_no_area_feature(self):
        zones_fc = self._make_zones_fc([
            {"type": "Feature", "properties": {"zoneClass": "STUDY"}, "geometry": {}},
        ])
        with pytest.raises(ValueError, match="No AREA feature"):
            _extract_area_polygon_json(zones_fc)

    def test_raises_on_empty_feature_collection(self):
        with pytest.raises(ValueError):
            _extract_area_polygon_json(self._make_zones_fc([]))

