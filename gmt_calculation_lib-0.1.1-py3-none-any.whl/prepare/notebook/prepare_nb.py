# Databricks notebook source
# ---------------------------------------------------------------------------
# prepare_nb.py — Databricks notebook interface for the GMT preparation pipeline.
#
# This notebook:
#   1. Reads widget parameters (bbox, mode, name, catalog, schema, …).
#   2. Installs gmt-calculation-lib from Nexus (if not already present).
#   3. Calls prepare.core.prepare_core.run_pipeline directly.
#
# Requirements (Databricks cluster):
#   pip install gmt-calculation-lib
# ---------------------------------------------------------------------------

# COMMAND ----------
# MAGIC %pip install --quiet gmt-calculation-lib

# COMMAND ----------
import json
import logging
from pathlib import Path

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("prepare_nb")

# COMMAND ----------
# Widget definitions — edit defaults here or via the Databricks widget UI.
dbutils.widgets.text("min_lon",      "6.143",          "Min longitude")   # noqa: F821
dbutils.widgets.text("min_lat",      "52.248",         "Min latitude")    # noqa: F821
dbutils.widgets.text("max_lon",      "6.184",          "Max longitude")   # noqa: F821
dbutils.widgets.text("max_lat",      "52.272",         "Max latitude")    # noqa: F821
dbutils.widgets.text("mode",         "CAR",            "Transport mode")  # noqa: F821
dbutils.widgets.text("name",         "MyArea",         "Area name")       # noqa: F821
dbutils.widgets.text("out_dir",      "/tmp/gmt_prep",  "Output directory") # noqa: F821
dbutils.widgets.text("catalog",      "spectrum",       "Databricks catalog") # noqa: F821
dbutils.widgets.text("schema",       "2023_01",        "Databricks schema")  # noqa: F821
dbutils.widgets.text("start_step",   "",               "Start step (1-10, empty = 1)")  # noqa: F821
dbutils.widgets.text("until_step",   "",               "Until step (1-10, empty = all)") # noqa: F821
dbutils.widgets.dropdown("refresh",  "false", ["true", "false"], "Refresh")  # noqa: F821
dbutils.widgets.dropdown("debug",    "false", ["true", "false"], "Debug")    # noqa: F821
dbutils.widgets.dropdown("repair_gaps", "false", ["true", "false"], "Repair gaps (runs gap detector, step 4)") # noqa: F821
dbutils.widgets.text("exclude_zones", "", "Exclude zones (comma-separated zoneId values, optional)") # noqa: F821

# COMMAND ----------
min_lon     = float(dbutils.widgets.get("min_lon"))      # noqa: F821
min_lat     = float(dbutils.widgets.get("min_lat"))      # noqa: F821
max_lon     = float(dbutils.widgets.get("max_lon"))      # noqa: F821
max_lat     = float(dbutils.widgets.get("max_lat"))      # noqa: F821
mode        = dbutils.widgets.get("mode").strip().upper()  # noqa: F821
name        = dbutils.widgets.get("name").strip()          # noqa: F821
out_dir     = Path(dbutils.widgets.get("out_dir").strip()) # noqa: F821
catalog     = dbutils.widgets.get("catalog").strip()       # noqa: F821
schema      = dbutils.widgets.get("schema").strip()        # noqa: F821
_start      = dbutils.widgets.get("start_step").strip() or None  # noqa: F821
_until      = dbutils.widgets.get("until_step").strip() or None  # noqa: F821
refresh     = dbutils.widgets.get("refresh") == "true"    # noqa: F821
debug       = dbutils.widgets.get("debug") == "true"      # noqa: F821
repair_gaps = dbutils.widgets.get("repair_gaps") == "true" # noqa: F821
_excl_raw   = dbutils.widgets.get("exclude_zones").strip() # noqa: F821
exclude_zones = [z.strip() for z in _excl_raw.split(",") if z.strip()] or None

logger.info(
    "Preparation pipeline: bbox=(%s %s %s %s) mode=%s name=%s out=%s",
    min_lon, min_lat, max_lon, max_lat, mode, name, out_dir,
)

# COMMAND ----------
from prepare.core.prepare_core import run_pipeline  # noqa: E402

run_pipeline(
    min_lon=min_lon,
    min_lat=min_lat,
    max_lon=max_lon,
    max_lat=max_lat,
    mode=mode,
    name=name,
    out_dir=out_dir,
    catalog=catalog,
    schema=schema,
    refresh=refresh,
    debug=debug,
    start_step=_start,
    until_step=_until,
    repair_gaps=repair_gaps,
    exclude_zones=exclude_zones,
)
