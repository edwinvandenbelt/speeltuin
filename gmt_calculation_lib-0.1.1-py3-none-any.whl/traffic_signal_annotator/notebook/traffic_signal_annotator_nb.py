# Databricks notebook source
# ---------------------------------------------------------------------------
# traffic_signal_annotator_nb.py — Databricks notebook interface.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads the network GeoParquet from S3.
#   3. Queries Overpass for traffic-signal nodes within the network bbox.
#   4. Annotates each link with trafficSignal=True/False.
#   5. Writes the enriched parquet back to S3 (in-place update).
#   6. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("traffic_signal_annotator_nb")

# COMMAND ----------
# MAGIC %pip install boto3 numpy

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uri",
    "",
    "Network GeoParquet URI (s3://bucket/key or local path) — updated in-place",
)
dbutils.widgets.text(  # noqa: F821
    "tolerance_m",
    "15.0",
    "Max distance in metres to match a toNode to a traffic-signal node",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_timeout",
    "60",
    "Overpass HTTP + server-side timeout in seconds",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from traffic_signal_annotator.core.traffic_signal_annotator_core import (  # noqa: E402, PLC0415
    annotate_network,
    fetch_signal_coords,
)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")

TOLERANCE_M = float(dbutils.widgets.get("tolerance_m").strip() or "15.0")  # noqa: F821
OVERPASS_TIMEOUT = int(dbutils.widgets.get("overpass_timeout").strip() or "60")  # noqa: F821

logger.info(
    "network_uri=%s  tolerance_m=%.1f  overpass_timeout=%d",
    NETWORK_URI,
    TOLERANCE_M,
    OVERPASS_TIMEOUT,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/octet-stream",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    import os  # noqa: PLC0415

    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run TrafficSignalAnnotator
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402, PLC0415

_t_start = datetime.now(timezone.utc)
print(f"Starting  {_t_start.isoformat()}")
print(f"Network   : {NETWORK_URI}")
print()

# Read network parquet
_raw = _read_uri(NETWORK_URI)
_fc = from_geoparquet(_raw)
_feature_count = len(_fc.get("features") or [])
print(f"Features  : {_feature_count:,}")

# Derive bounding box
_bbox = (_fc.get("properties") or {}).get("bbox")
if not _bbox or len(_bbox) < 4:
    _lons, _lats = [], []
    for _f in _fc.get("features") or []:
        for _c in (_f.get("geometry") or {}).get("coordinates") or []:
            _lons.append(float(_c[0]))
            _lats.append(float(_c[1]))
    _bbox = [min(_lons), min(_lats), max(_lons), max(_lats)]
print(f"Bbox      : {_bbox}")

# Fetch traffic-signal nodes from Overpass
print(f"Querying Overpass (timeout={OVERPASS_TIMEOUT}s) …")
_signal_coords = fetch_signal_coords(_bbox, timeout=OVERPASS_TIMEOUT)
print(f"Signals   : {len(_signal_coords):,} nodes found")

# Annotate
print(f"Annotating (tolerance={TOLERANCE_M} m) …")
_annotated_fc, _stats = annotate_network(_fc, _signal_coords, tolerance_m=TOLERANCE_M)

# Write back in-place
_payload = to_geoparquet(_annotated_fc)
_write_uri(NETWORK_URI, _payload)

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"TrafficSignalAnnotator complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Network URI      : {NETWORK_URI}")
print(f"  Total links      : {_stats['total']:,}")
print(f"  Signal links     : {_stats['annotated']:,}")
print(f"  OSM nodes found  : {_stats['signal_nodes_found']:,}")
print(f"  Tolerance        : {TOLERANCE_M} m")
print(_SEP)
