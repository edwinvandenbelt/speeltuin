"""
adjust_runner.py — CLI entry point for the GMT adjustment pipeline.

Usage
-----
    python -m adjust.adjust_runner <FOLDER> <CHANGES> --routes <ROUTES_FILE> \\
        (--output-folder OUTPUT_FOLDER | --scenario-name SCENARIO_NAME) \\
        [--min-link-trips FLOAT] [--debug]
"""

from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path

_RUNNER_FILE = Path(__file__).resolve()
_REPO_ROOT   = _RUNNER_FILE.parent.parent.parent  # src/adjust/ -> repo root
_SRC_DIR     = str(_REPO_ROOT / "src")
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

from adjust.core.adjust_core import run_pipeline  # noqa: E402


def _resolve_folder(raw: str) -> Path:
    p = Path(raw)
    if p.is_absolute():
        return p
    return _REPO_ROOT / raw


def main() -> None:
    parser = argparse.ArgumentParser(
        description="GMT adjustment pipeline — applies node/link changes, updates ROUTES, and adds flows."
    )
    parser.add_argument(
        "folder",
        help=(
            "Directory containing the prepared source files (network, zones, feedlinks). "
            "The source area ID is discovered from {uuid}-NETWORK-{MODE}.geojson files."
        ),
    )
    parser.add_argument(
        "changes",
        help=(
            "Inline JSON array or path to a .json file describing adjustments. "
            "Node/zone entries: 'nodeId'/'zoneId' + 'production'/'attraction'. "
            "Link entries: 'linkId' or 'fromNode'+'toNode', plus 'capacity' OR 'speed'. "
            "Example: [{\"nodeId\": \"417346001\", \"production\": \"+300\"}, "
            "{\"linkId\": \"9876\", \"capacity\": \"0\", \"bidirectional\": true}]"
        ),
    )
    parser.add_argument(
        "--routes",
        required=True,
        metavar="ROUTES_FILE",
        help=(
            "Path to the existing {area_id}-ROUTES-{mode}.geojson file produced by "
            "matrix_builder.  The file is updated with re-routed and new OD pairs and "
            "written to the output folder."
        ),
    )
    parser.add_argument(
        "--output-folder",
        default=None,
        metavar="OUTPUT_FOLDER",
        help="Path for the output directory.  Mutually exclusive with --scenario-name.",
    )
    parser.add_argument(
        "--scenario-name",
        default=None,
        metavar="SCENARIO_NAME",
        help=(
            "Name of the scenario.  A subdirectory with this name is created inside FOLDER. "
            "Mutually exclusive with --output-folder."
        ),
    )
    parser.add_argument(
        "--new-area-id",
        default=None,
        metavar="UUID",
        help=(
            "UUID to use for the output files.  "
            "When omitted a fresh UUID is generated automatically."
        ),
    )
    parser.add_argument(
        "--min-link-trips",
        type=float,
        default=1.0,
        help="Minimum added trips required to update a link.  Default: 1.0.",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help=(
            "Print per-route flow report and write {newAreaId}-COMPARE-{mode}.geojson "
            "to the output folder."
        ),
    )
    args = parser.parse_args()

    if args.output_folder and args.scenario_name:
        parser.error("--output-folder and --scenario-name are mutually exclusive.")
    if not args.output_folder and not args.scenario_name:
        parser.error("One of --output-folder or --scenario-name must be supplied.")

    source_folder = _resolve_folder(args.folder)
    if args.output_folder:
        output_folder = _resolve_folder(args.output_folder)
    else:
        output_folder = source_folder / args.scenario_name

    run_pipeline(
        folder=source_folder,
        changes=args.changes,
        output_folder=output_folder,
        routes_path=_resolve_folder(args.routes),
        new_area_id=args.new_area_id,
        min_link_trips=args.min_link_trips,
        debug=args.debug,
    )

    # Copy the changes file (with its original name) to the output folder.
    changes_path = Path(args.changes)
    if changes_path.is_file():
        output_folder.mkdir(parents=True, exist_ok=True)
        dest = output_folder / changes_path.name
        shutil.copy2(changes_path, dest)
        print(f"Copied changes file to {dest}")


if __name__ == "__main__":
    main()
