"""Unit tests for adjust.core.adjust_core — pure helper functions only."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from adjust.core.adjust_core import (
    _detect_mode,
    _load_changes,
    _read_area_id,
)


# ---------------------------------------------------------------------------
# _read_area_id
# ---------------------------------------------------------------------------


class TestReadAreaId:
    def test_reads_existing_uuid(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / ".area-uuid").write_text("test-uuid-1234", encoding="utf-8")
            assert _read_area_id(folder) == "test-uuid-1234"

    def test_raises_when_file_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _read_area_id(Path(tmp))

    def test_raises_when_file_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / ".area-uuid").write_text("", encoding="utf-8")
            with pytest.raises(ValueError):
                _read_area_id(folder)


# ---------------------------------------------------------------------------
# _detect_mode
# ---------------------------------------------------------------------------


class TestDetectMode:
    def test_detects_car(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder  = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _detect_mode(folder, area_id) == "CAR"

    def test_detects_bike(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder  = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-BIKE.geojson").write_text("{}", encoding="utf-8")
            assert _detect_mode(folder, area_id) == "BIKE"

    def test_raises_when_no_network_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _detect_mode(Path(tmp), "missing-id")

    def test_ignores_non_mode_files(self):
        """Files like {id}-NETWORK-RAW-CAR.geojson must not be matched."""
        with tempfile.TemporaryDirectory() as tmp:
            folder  = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-RAW-CAR.geojson").write_text("{}", encoding="utf-8")
            (folder / f"{area_id}-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _detect_mode(folder, area_id) == "CAR"


# ---------------------------------------------------------------------------
# _load_changes
# ---------------------------------------------------------------------------


class TestLoadChanges:
    def test_parses_inline_json(self):
        changes = '[{"nodeId": "123", "production": "+100"}]'
        result  = _load_changes(changes)
        assert result == [{"nodeId": "123", "production": "+100"}]

    def test_reads_from_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "changes.json"
            data = [{"zoneId": "z1", "attraction": "200"}]
            path.write_text(json.dumps(data), encoding="utf-8")
            assert _load_changes(str(path)) == data

    def test_empty_array(self):
        assert _load_changes("[]") == []

    def test_raises_on_invalid_json(self):
        with pytest.raises(json.JSONDecodeError):
            _load_changes("{not valid json}")
