"""Unit tests for adjust.core.adjust_core — pure helper functions only."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from adjust.core.adjust_core import (
    _apply_flow_delta,
    _compute_link_flow_delta,
    _detect_mode,
    _discover_area_id,
    _get_closed_link_ids,
    _load_changes,
    _normalize_od_fc_to_fractions,
    _redistribute_routes,
    _restore_origin_productions,
    apply_link_adjustments,
)
from shared.uri import mem_clear, mem_put


# ---------------------------------------------------------------------------
# _discover_area_id
# ---------------------------------------------------------------------------


class TestDiscoverAreaId:
    def test_discovers_from_clean_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "test-uuid-1234-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_area_id(folder) == "test-uuid-1234"

    def test_raises_when_no_network_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _discover_area_id(Path(tmp))

    def test_prefers_clean_over_raw(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "my-uuid-5678-NETWORK-RAW-CAR.parquet").write_bytes(b"")
            (folder / "my-uuid-5678-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_area_id(folder) == "my-uuid-5678"

    def test_falls_back_to_raw_when_no_clean(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "my-uuid-5678-NETWORK-RAW-CAR.parquet").write_bytes(b"")
            assert _discover_area_id(folder) == "my-uuid-5678"


# ---------------------------------------------------------------------------
# _detect_mode
# ---------------------------------------------------------------------------


class TestDetectMode:
    def test_detects_car(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder  = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-CAR.parquet").write_bytes(b"")
            assert _detect_mode(folder, area_id) == "CAR"

    def test_detects_bike(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder  = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-BIKE.parquet").write_bytes(b"")
            assert _detect_mode(folder, area_id) == "BIKE"

    def test_raises_when_no_network_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _detect_mode(Path(tmp), "missing-id")

    def test_ignores_non_mode_files(self):
        """Files like {id}-NETWORK-RAW-CAR.parquet must not be matched."""
        with tempfile.TemporaryDirectory() as tmp:
            folder  = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-RAW-CAR.parquet").write_bytes(b"")
            (folder / f"{area_id}-NETWORK-CAR.parquet").write_bytes(b"")
            assert _detect_mode(folder, area_id) == "CAR"


# ---------------------------------------------------------------------------
# _discover_area_id — mem:// store
# ---------------------------------------------------------------------------


class TestDiscoverAreaIdMem:
    def teardown_method(self):
        mem_clear()

    def test_discovers_from_clean_network(self):
        mem_put("mem://testfolder/my-uuid-1111-NETWORK-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder") == "my-uuid-1111"

    def test_raises_when_store_empty(self):
        with pytest.raises(FileNotFoundError):
            _discover_area_id("mem://empty")

    def test_prefers_clean_over_raw(self):
        mem_put("mem://testfolder/my-uuid-5678-NETWORK-RAW-CAR.parquet", b"")
        mem_put("mem://testfolder/my-uuid-5678-NETWORK-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder") == "my-uuid-5678"

    def test_falls_back_to_raw_when_no_clean(self):
        mem_put("mem://testfolder/my-uuid-5678-NETWORK-RAW-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder") == "my-uuid-5678"

    def test_trailing_slash_in_folder_ignored(self):
        mem_put("mem://testfolder/my-uuid-9999-NETWORK-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder/") == "my-uuid-9999"


# ---------------------------------------------------------------------------
# _detect_mode — mem:// store
# ---------------------------------------------------------------------------


class TestDetectModeMem:
    def teardown_method(self):
        mem_clear()

    def test_detects_car(self):
        mem_put("mem://testfolder/abc-123-NETWORK-CAR.parquet", b"")
        assert _detect_mode("mem://testfolder", "abc-123") == "CAR"

    def test_detects_bike(self):
        mem_put("mem://testfolder/abc-123-NETWORK-BIKE.parquet", b"")
        assert _detect_mode("mem://testfolder", "abc-123") == "BIKE"

    def test_raises_when_not_found(self):
        with pytest.raises(FileNotFoundError):
            _detect_mode("mem://testfolder", "missing-id")

    def test_ignores_raw_variants(self):
        mem_put("mem://testfolder/abc-123-NETWORK-RAW-CAR.parquet", b"")
        mem_put("mem://testfolder/abc-123-NETWORK-CAR.parquet", b"")
        assert _detect_mode("mem://testfolder", "abc-123") == "CAR"


# ---------------------------------------------------------------------------
# _load_changes
# ---------------------------------------------------------------------------


class TestLoadChanges:
    def test_parses_inline_json(self):
        changes = '[{"nodeId": "123", "production": "+100"}]'
        result  = _load_changes(changes)
        assert result == [{"nodeId": "123", "production": "+100"}]

    def test_reads_from_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "changes.json"
            data = [{"zoneId": "z1", "attraction": "200"}]
            path.write_text(json.dumps(data), encoding="utf-8")
            assert _load_changes(str(path)) == data

    def test_empty_array(self):
        assert _load_changes("[]") == []

    def test_raises_on_invalid_json(self):
        with pytest.raises(json.JSONDecodeError):
            _load_changes("{not valid json}")


# ---------------------------------------------------------------------------
# apply_link_adjustments
# ---------------------------------------------------------------------------


def _net_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _link(link_id, from_node, to_node, speed, capacity, lanes=1, flow=50.0):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "speed": speed,
            "capacity": capacity,
            "lanes": lanes,
            "flow": flow,
            "flow24hrs": flow,
            "flowsPerDaypart": {"mrh": flow * 0.2, "erh": flow * 0.1},
            "flowsPerMotive": {"work": flow * 0.8, "other": flow * 0.2},
        },
    }


class TestApplyLinkAdjustments:
    def test_capacity_zero_preserves_flow(self):
        """Closing a link (capacity=0) must NOT reset flow fields.

        Flow adjustment is handled by _apply_flow_delta in the pipeline;
        apply_link_adjustments only changes capacity/speed.
        """
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        adjusted_fc, affected = apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 0}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 0.0
        assert props["flow"] == pytest.approx(70.5)
        assert props["flow24hrs"] == pytest.approx(70.5)
        assert affected == [("1", "2")]

    def test_partial_capacity_preserves_flow(self):
        """Reducing capacity (but not to zero) must NOT reset flows."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        adjusted_fc, _ = apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 300}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 300.0
        assert props["flow"] == pytest.approx(70.5)

    def test_speed_zero_preserves_flow(self):
        """Setting speed=0 (results in capacity=0) must NOT reset flow fields."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=35.0))
        adjusted_fc, _ = apply_link_adjustments(fc, [{"linkId": "LK1", "speed": 0}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 0.0
        assert props["flow"] == pytest.approx(35.0)

    def test_original_network_not_mutated(self):
        """apply_link_adjustments must return a deep copy; original must be unchanged."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 0}])
        assert fc["features"][0]["properties"]["flow"] == pytest.approx(70.5)
        assert fc["features"][0]["properties"]["capacity"] == 500.0


# ---------------------------------------------------------------------------
# _compute_link_flow_delta
# ---------------------------------------------------------------------------


def _routes_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _zones_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _zone(zone_id, production):
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {"zoneId": zone_id, "production": production},
    }


def _od_feature(from_id, to_id, routes, *, from_type="zone", to_type="zone", origin_production=None):
    """Minimal OD FeatureCollection feature.

    Pass *origin_production* to set ``originProduction`` on the feature
    (required for ``od_fc_new`` inputs that use the normalized fraction
    convention: actual trips = ``route.trips × originProduction``).
    """
    props = {
        "fromZoneId": from_id,
        "toZoneId": to_id,
        "fromType": from_type,
        "toType": to_type,
        "tripFraction": sum(r.get("trips", 0) for r in routes),
        "routes": routes,
    }
    if origin_production is not None:
        props["originProduction"] = origin_production
    return {"type": "Feature", "geometry": None, "properties": props}


def _route(trips, *link_ids):
    return {"trips": trips, "linkPath": list(link_ids)}


class TestComputeLinkFlowDelta:
    def test_re_routed_pair_scales_by_production(self):
        """route.trips is a fraction; actual flow = route.trips * origin production."""
        # Zone Z1 has production=100; route.trips=0.1 → 10 actual trips
        zones     = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A", "B")])
        )
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "B", "C")])
        )
        od_new = _routes_fc()

        delta = _compute_link_flow_delta(old_routes, recomputed, od_new, zones)

        assert delta["A"] == pytest.approx((10.0, 0.0))   # removed from A
        assert delta["B"] == pytest.approx((10.0, 10.0))  # same share on B
        assert delta["C"] == pytest.approx((0.0, 10.0))   # added to C

    def test_new_zone_adjustment_pair_has_zero_before(self):
        """Newly added OD pairs have flow_before=0 for all their links.

        od_fc_new uses the normalized fraction convention after
        ``_normalize_od_fc_to_fractions``: route.trips is a fraction and
        originProduction holds the absolute value.
        """
        zones  = _zones_fc(_zone("Z3", 200.0), _zone("Z4", 80.0))
        od_new = _routes_fc(
            _od_feature("Z3", "Z4", [_route(1.0, "X", "Y")], origin_production=10.0)
        )

        delta = _compute_link_flow_delta(_routes_fc(), _routes_fc(), od_new, zones)

        assert delta["X"] == pytest.approx((0.0, 10.0))
        assert delta["Y"] == pytest.approx((0.0, 10.0))

    def test_unaffected_pair_not_in_delta(self):
        """Pairs not in recomputed_fc must not contribute to the delta."""
        zones     = _zones_fc(_zone("Z1", 100.0), _zone("Z3", 100.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")]),
            _od_feature("Z3", "Z4", [_route(0.1, "B")]),
        )
        # Only Z1→Z2 is re-routed
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "C")])
        )

        delta = _compute_link_flow_delta(old_routes, recomputed, _routes_fc(), zones)

        assert "A" in delta
        assert "B" not in delta

    def test_empty_inputs_return_empty_delta(self):
        empty = _routes_fc()
        delta = _compute_link_flow_delta(empty, empty, empty, _zones_fc())
        assert delta == {}

    def test_node_type_origin_uses_factor_one(self):
        """For node-type origins in od_fc_new, actual trips = route.trips × originProduction."""
        zones     = _zones_fc()  # no zone data — node adjustments bypass zone lookup
        od_new    = _routes_fc(
            _od_feature("NODE_42", "Z1", [_route(1.0, "X")], from_type="node", origin_production=5.0)
        )

        delta = _compute_link_flow_delta(_routes_fc(), _routes_fc(), od_new, zones)

        assert delta["X"] == pytest.approx((0.0, 5.0))

    def test_od_replacement_subtracts_old_flows(self):
        """When od_fc_new replaces an existing base pair, old flows are flow_before.

        The old pair (from base ROUTES) uses the fraction convention: trips × production.
        The new od_fc_new pair uses the normalized fraction convention: route.trips ×
        originProduction — yielding the same 10 absolute trips.
        """
        zones      = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A", "B")])  # fraction: 0.1 × 100 = 10 trips
        )
        # New routes for same pair — normalized fraction: route.trips=1.0 × originProduction=10.0.
        od_new = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "B", "C")], origin_production=10.0)
        )

        delta = _compute_link_flow_delta(old_routes, _routes_fc(), od_new, zones)

        assert delta["A"] == pytest.approx((10.0, 0.0))   # old link removed
        assert delta["B"] == pytest.approx((10.0, 10.0))  # same trips, no net change
        assert delta["C"] == pytest.approx((0.0, 10.0))   # new link added

    def test_tombstone_in_od_removes_old_flows(self):
        """A tombstone (routes=[]) replacing an existing pair zeroes out its links."""
        zones     = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "X", "Y")])  # 10 trips on X, Y
        )
        tombstone = _routes_fc(
            _od_feature("Z1", "Z2", [])  # trips=0, replaces old pair
        )

        delta = _compute_link_flow_delta(old_routes, _routes_fc(), tombstone, zones)

        assert delta["X"] == pytest.approx((10.0, 0.0))  # fully removed
        assert delta["Y"] == pytest.approx((10.0, 0.0))


# ---------------------------------------------------------------------------
# _apply_flow_delta
# ---------------------------------------------------------------------------


class TestApplyFlowDelta:
    def test_positive_delta_increases_flow(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        delta = {"LK1": (0.0, 10.0)}  # +10 new trips
        adj, report = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        assert props["flow"] == pytest.approx(110.0)
        assert props["flow24hrs"] == pytest.approx(110.0)
        assert len(report) == 1
        assert report[0]["flow_delta"] == pytest.approx(10.0)

    def test_negative_delta_decreases_flow(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        delta = {"LK1": (10.0, 0.0)}  # 10 trips removed
        adj, report = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        assert props["flow"] == pytest.approx(90.0)

    def test_flow_clamped_to_zero(self):
        """Flow must never go negative."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=5.0))
        delta = {"LK1": (20.0, 0.0)}  # remove 20 trips from a link with only 5
        adj, _ = _apply_flow_delta(fc, delta)

        assert adj["features"][0]["properties"]["flow"] == pytest.approx(0.0)

    def test_sub_dicts_scaled_proportionally(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        # flow 100 → 110 (+10%), all sub-values should scale by 1.1
        delta = {"LK1": (0.0, 10.0)}
        adj, _ = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        # Original: mrh=20, erh=10, work=80, other=20
        assert props["flowsPerDaypart"]["mrh"] == pytest.approx(22.0)
        assert props["flowsPerDaypart"]["erh"] == pytest.approx(11.0)
        assert props["flowsPerMotive"]["work"]  == pytest.approx(88.0)
        assert props["flowsPerMotive"]["other"] == pytest.approx(22.0)

    def test_zero_delta_link_not_in_report(self):
        """Links with flow_before == flow_after must not appear in the report."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=50.0))
        delta = {"LK1": (5.0, 5.0)}  # no change
        _, report = _apply_flow_delta(fc, delta)
        assert report == []

    def test_original_network_not_mutated(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=50.0))
        delta = {"LK1": (0.0, 20.0)}
        _apply_flow_delta(fc, delta)
        assert fc["features"][0]["properties"]["flow"] == pytest.approx(50.0)


# ---------------------------------------------------------------------------
# _get_closed_link_ids
# ---------------------------------------------------------------------------


def _net_link(link_id: str, capacity: float) -> dict:
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {"linkId": link_id, "capacity": capacity},
    }


class TestGetClosedLinkIds:
    def test_returns_only_zero_capacity_links(self):
        fc = {"type": "FeatureCollection", "features": [
            _net_link("A", 0.0),
            _net_link("B", 100.0),
            _net_link("C", 0.0),
        ]}
        result = _get_closed_link_ids(fc, {"A", "B", "C"})
        assert result == {"A", "C"}

    def test_ignores_links_not_in_affected_set(self):
        fc = {"type": "FeatureCollection", "features": [
            _net_link("A", 0.0),
            _net_link("B", 0.0),
        ]}
        result = _get_closed_link_ids(fc, {"A"})
        assert result == {"A"}

    def test_empty_when_no_zero_capacity(self):
        fc = {"type": "FeatureCollection", "features": [_net_link("A", 50.0)]}
        assert _get_closed_link_ids(fc, {"A"}) == set()

    def test_empty_network(self):
        assert _get_closed_link_ids({"type": "FeatureCollection", "features": []}, {"A"}) == set()


# ---------------------------------------------------------------------------
# _redistribute_routes
# ---------------------------------------------------------------------------

_AFFECTED = {"LK_CLOSED"}
_CLOSED   = {"LK_CLOSED"}


class TestRedistributeRoutes:

    # ------------------------------------------------------------------
    # N=2, B=1 → all flow to remaining route; trips sum == tripFraction
    # ------------------------------------------------------------------
    def test_n2_b1_all_to_remaining(self):
        # production=100, tripFraction=0.3+0.2=0.5 → total_trips=50 ≥ 2
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature("Z1", "Z2", [
            _route(0.3, "LK_CLOSED"),
            _route(0.2, "LK_OTHER"),
        ])
        tf = feat["properties"]["tripFraction"]
        redist_fc, recompute = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        assert recompute == []
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert len(result_routes) == 1
        assert result_routes[0]["trips"] == pytest.approx(tf)

    # ------------------------------------------------------------------
    # N=3, B=1 → proportional redistribution to 2 remaining; sum preserved
    # ------------------------------------------------------------------
    def test_n3_b1_proportional(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature("Z1", "Z2", [
            _route(0.2, "LK_CLOSED"),
            _route(0.1, "LK_A"),
            _route(0.3, "LK_B"),
        ])
        tf = feat["properties"]["tripFraction"]
        redist_fc, recompute = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        assert recompute == []
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert len(result_routes) == 2
        assert sum(r["trips"] for r in result_routes) == pytest.approx(tf)

    # ------------------------------------------------------------------
    # N=3, B=2 → only 1 remaining, N≠2 → re-route
    # ------------------------------------------------------------------
    def test_n3_b2_needs_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature("Z1", "Z2", [
            _route(0.2, "LK_CLOSED"),
            _route(0.2, "LK_CLOSED"),
            _route(0.1, "LK_OTHER"),
        ])
        redist_fc, recompute = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        assert redist_fc["features"] == []
        assert len(recompute) == 1
        assert recompute[0]["fromId"] == "Z1"

    # ------------------------------------------------------------------
    # N=4, B=2 → 2 remaining ≥ 2 → local redistribution
    # ------------------------------------------------------------------
    def test_n4_b2_proportional(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature("Z1", "Z2", [
            _route(0.2, "LK_CLOSED"),
            _route(0.2, "LK_CLOSED"),
            _route(0.2, "LK_A"),
            _route(0.2, "LK_B"),
        ])
        tf = feat["properties"]["tripFraction"]
        redist_fc, recompute = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        assert recompute == []
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert len(result_routes) == 2
        assert sum(r["trips"] for r in result_routes) == pytest.approx(tf)

    # ------------------------------------------------------------------
    # N=4, B=3 → only 1 remaining, N≠2 → re-route
    # ------------------------------------------------------------------
    def test_n4_b3_needs_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature("Z1", "Z2", [
            _route(0.2, "LK_CLOSED"),
            _route(0.2, "LK_CLOSED"),
            _route(0.2, "LK_CLOSED"),
            _route(0.2, "LK_OTHER"),
        ])
        redist_fc, recompute = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        assert redist_fc["features"] == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # N=1, B=1 → 0 remaining → re-route
    # ------------------------------------------------------------------
    def test_n1_b1_needs_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature("Z1", "Z2", [
            _route(0.3, "LK_CLOSED"),
        ])
        redist_fc, recompute = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        assert redist_fc["features"] == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # Evaporation: total trips below threshold → routes=[], not re-routed
    # ------------------------------------------------------------------
    def test_evaporated_below_min_trips(self):
        # production=10, tripFraction=0.1 → total_trips=1.0 < default 2.0
        zones = _zones_fc(_zone("Z1", 10.0))
        feat = _od_feature("Z1", "Z2", [
            _route(0.1, "LK_CLOSED"),
        ])
        redist_fc, recompute = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        assert recompute == []
        assert len(redist_fc["features"]) == 1
        assert redist_fc["features"][0]["properties"]["routes"] == []

    # ------------------------------------------------------------------
    # Non-closed adjusted link → pair must go to recompute (speed tweak)
    # ------------------------------------------------------------------
    def test_non_closed_adjusted_link_to_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature("Z1", "Z2", [
            _route(0.2, "LK_SPEED"),
            _route(0.2, "LK_OTHER"),
        ])
        redist_fc, recompute = _redistribute_routes(
            _routes_fc(feat), {"LK_SPEED"}, set(), zones
        )
        assert redist_fc["features"] == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # tripFraction invariant: sum(new_trips) == tripFraction after redistribution
    # ------------------------------------------------------------------
    def test_tripfraction_preserved_after_redistribution(self):
        zones = _zones_fc(_zone("Z1", 200.0))
        feat = _od_feature("Z1", "Z2", [
            _route(0.3, "LK_CLOSED"),
            _route(0.4, "LK_A"),
            _route(0.2, "LK_B"),
        ])
        tf = feat["properties"]["tripFraction"]
        redist_fc, _ = _redistribute_routes(
            _routes_fc(feat), _AFFECTED, _CLOSED, zones
        )
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert sum(r["trips"] for r in result_routes) == pytest.approx(tf)


# ---------------------------------------------------------------------------
# _normalize_od_fc_to_fractions
# ---------------------------------------------------------------------------


class TestNormalizeOdFcToFractions:
    def test_single_origin_single_route_sets_origin_production(self):
        """Single origin with one route: trips become 1.0, originProduction = total."""
        od = _routes_fc(_od_feature("Z1", "Z2", [_route(42.0, "A")]))
        result = _normalize_od_fc_to_fractions(od)
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(42.0)
        assert props["routes"][0]["trips"] == pytest.approx(1.0)
        assert props["tripFraction"] == pytest.approx(1.0)

    def test_single_origin_multiple_routes_splits_proportionally(self):
        """Two routes: trips normalized by total; Σ route.trips == 1.0."""
        od = _routes_fc(_od_feature("Z1", "Z2", [_route(30.0, "A"), _route(20.0, "B")]))
        result = _normalize_od_fc_to_fractions(od)
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(50.0)
        assert props["routes"][0]["trips"] == pytest.approx(0.6)
        assert props["routes"][1]["trips"] == pytest.approx(0.4)
        assert sum(r["trips"] for r in props["routes"]) == pytest.approx(1.0)

    def test_multiple_pairs_same_origin_normalized_together(self):
        """Two OD pairs from Z1: total=10, each pair's route.trips normalized by 10."""
        od = _routes_fc(
            _od_feature("Z1", "Z2", [_route(6.0, "A")]),
            _od_feature("Z1", "Z3", [_route(4.0, "B")]),
        )
        result = _normalize_od_fc_to_fractions(od)
        for feat in result["features"]:
            assert feat["properties"]["originProduction"] == pytest.approx(10.0)
        trips_sum = sum(
            r["trips"]
            for feat in result["features"]
            for r in feat["properties"]["routes"]
        )
        assert trips_sum == pytest.approx(1.0)

    def test_multiple_origins_normalized_independently(self):
        """Z1 (total=100) and Z2 (total=50) are each normalized to Σ=1.0."""
        od = _routes_fc(
            _od_feature("Z1", "Z2", [_route(100.0, "A")]),
            _od_feature("Z2", "Z3", [_route(50.0, "B")]),
        )
        result = _normalize_od_fc_to_fractions(od)
        feats = result["features"]
        assert feats[0]["properties"]["originProduction"] == pytest.approx(100.0)
        assert feats[0]["properties"]["routes"][0]["trips"] == pytest.approx(1.0)
        assert feats[1]["properties"]["originProduction"] == pytest.approx(50.0)
        assert feats[1]["properties"]["routes"][0]["trips"] == pytest.approx(1.0)

    def test_zero_total_trips_left_unchanged(self):
        """Feature with no routes (zero total) is left as-is without originProduction."""
        od = _routes_fc(_od_feature("Z1", "Z2", []))
        result = _normalize_od_fc_to_fractions(od)
        props = result["features"][0]["properties"]
        assert props.get("originProduction", 0.0) == pytest.approx(0.0)

    def test_trips_sum_to_one_per_origin_zone(self):
        """Invariant: Σ route.trips per origin zone ≈ 1.0 after normalization."""
        od = _routes_fc(
            _od_feature("Z1", "Z2", [_route(300.0, "A"), _route(200.0, "B")]),
            _od_feature("Z1", "Z3", [_route(100.0, "C")]),
            _od_feature("Z2", "Z4", [_route(75.0, "D")]),
        )
        result = _normalize_od_fc_to_fractions(od)
        origin_sums: dict[str, float] = {}
        for feat in result["features"]:
            props = feat["properties"]
            from_id = props["fromZoneId"]
            for route in props["routes"]:
                origin_sums[from_id] = origin_sums.get(from_id, 0.0) + route["trips"]
        for from_id, total in origin_sums.items():
            assert total == pytest.approx(1.0), f"Origin {from_id}: Σ route.trips = {total}"


# ---------------------------------------------------------------------------
# _restore_origin_productions
# ---------------------------------------------------------------------------


class TestRestoreOriginProductions:
    def test_restores_zero_origin_production_from_base(self):
        """A recomputed feature with originProduction=0 gets the base value."""
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0)
        )
        base = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=500.0)
        )
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"]["originProduction"] == pytest.approx(500.0)

    def test_does_not_overwrite_nonzero_origin_production(self):
        """A recomputed feature with originProduction > 0 is left unchanged."""
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=200.0)
        )
        base = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=999.0)
        )
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"]["originProduction"] == pytest.approx(200.0)

    def test_no_match_in_base_leaves_feature_unchanged(self):
        """A key not present in base leaves originProduction at 0.0."""
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0)
        )
        base = _routes_fc(
            _od_feature("Z9", "Z8", [_route(0.1, "A")], origin_production=777.0)
        )
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"].get("originProduction", 0.0) == pytest.approx(0.0)

    def test_base_with_zero_production_not_restored(self):
        """If base feature also has originProduction=0.0, recomputed stays at 0.0."""
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0)
        )
        base = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0)
        )
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"].get("originProduction", 0.0) == pytest.approx(0.0)

