"""Unit tests for adjust.core.adjust_core — pure helper functions only."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from adjust.core.adjust_core import (
    _apply_flow_delta,
    _compute_link_flow_delta,
    _detect_mode,
    _load_changes,
    _read_area_id,
    apply_link_adjustments,
)


# ---------------------------------------------------------------------------
# _read_area_id
# ---------------------------------------------------------------------------


class TestReadAreaId:
    def test_reads_existing_uuid(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / ".area-uuid").write_text("test-uuid-1234", encoding="utf-8")
            assert _read_area_id(folder) == "test-uuid-1234"

    def test_raises_when_file_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _read_area_id(Path(tmp))

    def test_raises_when_file_empty(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / ".area-uuid").write_text("", encoding="utf-8")
            with pytest.raises(ValueError):
                _read_area_id(folder)


# ---------------------------------------------------------------------------
# _detect_mode
# ---------------------------------------------------------------------------


class TestDetectMode:
    def test_detects_car(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder  = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _detect_mode(folder, area_id) == "CAR"

    def test_detects_bike(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder  = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-BIKE.geojson").write_text("{}", encoding="utf-8")
            assert _detect_mode(folder, area_id) == "BIKE"

    def test_raises_when_no_network_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _detect_mode(Path(tmp), "missing-id")

    def test_ignores_non_mode_files(self):
        """Files like {id}-NETWORK-RAW-CAR.geojson must not be matched."""
        with tempfile.TemporaryDirectory() as tmp:
            folder  = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-RAW-CAR.geojson").write_text("{}", encoding="utf-8")
            (folder / f"{area_id}-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _detect_mode(folder, area_id) == "CAR"


# ---------------------------------------------------------------------------
# _load_changes
# ---------------------------------------------------------------------------


class TestLoadChanges:
    def test_parses_inline_json(self):
        changes = '[{"nodeId": "123", "production": "+100"}]'
        result  = _load_changes(changes)
        assert result == [{"nodeId": "123", "production": "+100"}]

    def test_reads_from_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "changes.json"
            data = [{"zoneId": "z1", "attraction": "200"}]
            path.write_text(json.dumps(data), encoding="utf-8")
            assert _load_changes(str(path)) == data

    def test_empty_array(self):
        assert _load_changes("[]") == []

    def test_raises_on_invalid_json(self):
        with pytest.raises(json.JSONDecodeError):
            _load_changes("{not valid json}")


# ---------------------------------------------------------------------------
# apply_link_adjustments
# ---------------------------------------------------------------------------


def _net_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _link(link_id, from_node, to_node, speed, capacity, lanes=1, flow=50.0):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "speed": speed,
            "capacity": capacity,
            "lanes": lanes,
            "flow": flow,
            "flow24hrs": flow,
            "flowsPerDaypart": {"mrh": flow * 0.2, "erh": flow * 0.1},
            "flowsPerMotive": {"work": flow * 0.8, "other": flow * 0.2},
        },
    }


class TestApplyLinkAdjustments:
    def test_capacity_zero_preserves_flow(self):
        """Closing a link (capacity=0) must NOT reset flow fields.

        Flow adjustment is handled by _apply_flow_delta in the pipeline;
        apply_link_adjustments only changes capacity/speed.
        """
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        adjusted_fc, affected = apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 0}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 0.0
        assert props["flow"] == pytest.approx(70.5)
        assert props["flow24hrs"] == pytest.approx(70.5)
        assert affected == [("1", "2")]

    def test_partial_capacity_preserves_flow(self):
        """Reducing capacity (but not to zero) must NOT reset flows."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        adjusted_fc, _ = apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 300}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 300.0
        assert props["flow"] == pytest.approx(70.5)

    def test_speed_zero_preserves_flow(self):
        """Setting speed=0 (results in capacity=0) must NOT reset flow fields."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=35.0))
        adjusted_fc, _ = apply_link_adjustments(fc, [{"linkId": "LK1", "speed": 0}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 0.0
        assert props["flow"] == pytest.approx(35.0)

    def test_original_network_not_mutated(self):
        """apply_link_adjustments must return a deep copy; original must be unchanged."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 0}])
        assert fc["features"][0]["properties"]["flow"] == pytest.approx(70.5)
        assert fc["features"][0]["properties"]["capacity"] == 500.0


# ---------------------------------------------------------------------------
# _compute_link_flow_delta
# ---------------------------------------------------------------------------


def _routes_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _zones_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _zone(zone_id, production):
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {"zoneId": zone_id, "production": production},
    }


def _od_feature(from_id, to_id, routes, *, from_type="zone", to_type="zone"):
    """Minimal OD FeatureCollection feature."""
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {
            "fromZoneId": from_id,
            "toZoneId": to_id,
            "fromType": from_type,
            "toType": to_type,
            "tripFraction": sum(r.get("trips", 0) for r in routes),
            "routes": routes,
        },
    }


def _route(trips, *link_ids):
    return {"trips": trips, "linkPath": list(link_ids)}


class TestComputeLinkFlowDelta:
    def test_re_routed_pair_scales_by_production(self):
        """route.trips is a fraction; actual flow = route.trips * origin production."""
        # Zone Z1 has production=100; route.trips=0.1 → 10 actual trips
        zones     = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A", "B")])
        )
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "B", "C")])
        )
        od_new = _routes_fc()

        delta = _compute_link_flow_delta(old_routes, recomputed, od_new, zones)

        assert delta["A"] == pytest.approx((10.0, 0.0))   # removed from A
        assert delta["B"] == pytest.approx((10.0, 10.0))  # same share on B
        assert delta["C"] == pytest.approx((0.0, 10.0))   # added to C

    def test_new_zone_adjustment_pair_has_zero_before(self):
        """Newly added OD pairs have flow_before=0 for all their links."""
        zones     = _zones_fc(_zone("Z3", 200.0), _zone("Z4", 80.0))
        od_new    = _routes_fc(
            _od_feature("Z3", "Z4", [_route(0.05, "X", "Y")])  # 0.05 * 200 = 10 trips
        )

        delta = _compute_link_flow_delta(_routes_fc(), _routes_fc(), od_new, zones)

        assert delta["X"] == pytest.approx((0.0, 10.0))
        assert delta["Y"] == pytest.approx((0.0, 10.0))

    def test_unaffected_pair_not_in_delta(self):
        """Pairs not in recomputed_fc must not contribute to the delta."""
        zones     = _zones_fc(_zone("Z1", 100.0), _zone("Z3", 100.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")]),
            _od_feature("Z3", "Z4", [_route(0.1, "B")]),
        )
        # Only Z1→Z2 is re-routed
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "C")])
        )

        delta = _compute_link_flow_delta(old_routes, recomputed, _routes_fc(), zones)

        assert "A" in delta
        assert "B" not in delta

    def test_empty_inputs_return_empty_delta(self):
        empty = _routes_fc()
        delta = _compute_link_flow_delta(empty, empty, empty, _zones_fc())
        assert delta == {}

    def test_node_type_origin_uses_factor_one(self):
        """For node-type origins, route.trips is treated as absolute (factor=1.0)."""
        zones     = _zones_fc()  # no zone data — node adjustments bypass zone lookup
        od_new    = _routes_fc(
            _od_feature("NODE_42", "Z1", [_route(5.0, "X")], from_type="node")
        )

        delta = _compute_link_flow_delta(_routes_fc(), _routes_fc(), od_new, zones)

        assert delta["X"] == pytest.approx((0.0, 5.0))


# ---------------------------------------------------------------------------
# _apply_flow_delta
# ---------------------------------------------------------------------------


class TestApplyFlowDelta:
    def test_positive_delta_increases_flow(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        delta = {"LK1": (0.0, 10.0)}  # +10 new trips
        adj, report = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        assert props["flow"] == pytest.approx(110.0)
        assert props["flow24hrs"] == pytest.approx(110.0)
        assert len(report) == 1
        assert report[0]["flow_delta"] == pytest.approx(10.0)

    def test_negative_delta_decreases_flow(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        delta = {"LK1": (10.0, 0.0)}  # 10 trips removed
        adj, report = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        assert props["flow"] == pytest.approx(90.0)

    def test_flow_clamped_to_zero(self):
        """Flow must never go negative."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=5.0))
        delta = {"LK1": (20.0, 0.0)}  # remove 20 trips from a link with only 5
        adj, _ = _apply_flow_delta(fc, delta)

        assert adj["features"][0]["properties"]["flow"] == pytest.approx(0.0)

    def test_sub_dicts_scaled_proportionally(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        # flow 100 → 110 (+10%), all sub-values should scale by 1.1
        delta = {"LK1": (0.0, 10.0)}
        adj, _ = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        # Original: mrh=20, erh=10, work=80, other=20
        assert props["flowsPerDaypart"]["mrh"] == pytest.approx(22.0)
        assert props["flowsPerDaypart"]["erh"] == pytest.approx(11.0)
        assert props["flowsPerMotive"]["work"]  == pytest.approx(88.0)
        assert props["flowsPerMotive"]["other"] == pytest.approx(22.0)

    def test_zero_delta_link_not_in_report(self):
        """Links with flow_before == flow_after must not appear in the report."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=50.0))
        delta = {"LK1": (5.0, 5.0)}  # no change
        _, report = _apply_flow_delta(fc, delta)
        assert report == []

    def test_original_network_not_mutated(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=50.0))
        delta = {"LK1": (0.0, 20.0)}
        _apply_flow_delta(fc, delta)
        assert fc["features"][0]["properties"]["flow"] == pytest.approx(50.0)
