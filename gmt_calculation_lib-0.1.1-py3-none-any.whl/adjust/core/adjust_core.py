"""
adjust_core.py — GMT node- and link-adjustment pipeline orchestration logic.

Import and call ``run_pipeline`` from a local runner, notebook, or Lambda handler.
"""

from __future__ import annotations

import copy
import json
import sys
from pathlib import Path
from uuid import uuid4


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def _read_area_id(folder: Path) -> str:
    """Read the area UUID from ``folder/.area-uuid``."""
    uuid_file = folder / ".area-uuid"
    if not uuid_file.exists():
        raise FileNotFoundError(
            f"Could not find {uuid_file}\n"
            "Check that FOLDER is correct and the preparation pipeline has been "
            "run at least once."
        )
    area_id = uuid_file.read_text(encoding="utf-8").strip()
    if not area_id:
        raise ValueError(f"{uuid_file} is empty.")
    return area_id


def _detect_mode(folder: Path, area_id: str) -> str:
    """Infer transport mode from ``{area_id}-NETWORK-{MODE}.geojson`` in *folder*."""
    prefix  = f"{area_id}-NETWORK-"
    matches = [
        p for p in folder.glob(f"{prefix}*.geojson")
        if "-" not in p.stem[len(prefix):]
    ]
    if not matches:
        raise FileNotFoundError(
            f"Could not find {folder / (prefix + '*.geojson')}\n"
            "Check that FOLDER and AREA_ID are correct."
        )
    return matches[0].stem[len(prefix):]


# ---------------------------------------------------------------------------
# Changes loader
# ---------------------------------------------------------------------------


def _load_changes(value: str) -> list[dict]:
    """Load adjustment entries from an inline JSON string or a ``.json`` file path."""
    stripped = value.strip()
    p = Path(stripped)
    if p.exists():
        return json.loads(p.read_text(encoding="utf-8"))
    return json.loads(stripped)


def _split_changes(
    changes: list[dict],
) -> tuple[list[dict], list[dict]]:
    """Split a flat list of change entries into node/zone adjustments and link adjustments.

    A link adjustment entry must have a ``"linkId"`` **or** both ``"fromNode"``
    and ``"toNode"`` fields, and at least one of ``"capacity"`` or ``"speed"``
    (but **not** both).  All other entries are treated as node/zone adjustments.

    Returns
    -------
    (node_adjustments, link_adjustments)
    """
    node_adjustments: list[dict] = []
    link_adjustments: list[dict] = []

    for entry in changes:
        has_link_id  = bool(str(entry.get("linkId") or "").strip())
        has_from_to  = (
            bool(str(entry.get("fromNode") or "").strip())
            and bool(str(entry.get("toNode") or "").strip())
        )
        is_link = has_link_id or has_from_to

        if is_link:
            has_cap   = "capacity" in entry
            has_speed = "speed" in entry
            if has_cap and has_speed:
                raise ValueError(
                    f"Link adjustment entry may set 'capacity' OR 'speed', not both: {entry}"
                )
            if not has_cap and not has_speed:
                raise ValueError(
                    f"Link adjustment entry must have 'capacity' or 'speed': {entry}"
                )
            link_adjustments.append(entry)
        else:
            node_adjustments.append(entry)

    return node_adjustments, link_adjustments


# ---------------------------------------------------------------------------
# Speed → capacity category table
# ---------------------------------------------------------------------------

# Capacity per lane (pae/hr) per legal speed category.
# Matches bidirectional_splitter.domain.network._estimate_capacity.
_SPEED_CAP_TABLE: tuple[tuple[float, int], ...] = (
    (30.0,  1500),
    (50.0,  1700),
    (60.0,  1750),
    (80.0,  1800),
    (100.0, 2100),
)
_SPEED_CAP_DEFAULT: int = 2200  # > 100 km/h


def _remaining_cap(capacity: float | None, props: dict) -> float | None:
    """Return ``capacity − max(flowsPerDaypart)`` or ``None`` when capacity unknown."""
    if capacity is None:
        return None
    dp = props.get("flowsPerDaypart")
    peak = max(dp.values()) if isinstance(dp, dict) and dp else 0.0
    return capacity - peak


def _capacity_for_speed(speed_kmh: float, lanes: int) -> float:
    """Return estimated capacity (pae/hr) for *speed_kmh* and *lanes*.

    Uses the same category table as ``bidirectional_splitter``.
    """
    n = max(lanes, 1)
    for limit, per_lane in _SPEED_CAP_TABLE:
        if speed_kmh <= limit:
            return float(per_lane * n)
    return float(_SPEED_CAP_DEFAULT * n)


def _parse_value(raw: str, current: float) -> float:
    """Apply an absolute or delta value string to *current*.

    ``"+50"`` / ``"-20"`` → delta; plain numeric → absolute override.
    """
    raw = raw.strip()
    if raw.startswith("+"):
        return current + float(raw[1:])
    if raw.startswith("-"):
        return current - float(raw[1:])
    return float(raw)


# ---------------------------------------------------------------------------
# Link adjustment
# ---------------------------------------------------------------------------


def apply_link_adjustments(
    network_fc: dict,
    link_adjustments: list[dict],
) -> tuple[dict, list[tuple[str, str]]]:
    """Apply link property adjustments to a copy of *network_fc*.

    Each entry in *link_adjustments* must identify a link by ``"linkId"`` or
    by ``"fromNode"`` + ``"toNode"``, and specify either ``"capacity"`` or
    ``"speed"`` (not both).

    When ``"speed"`` is changed the capacity is automatically recalculated from
    the speed-category table (matching ``bidirectional_splitter``):

    ======= ================
    speed   cap/lane (pae/h)
    ≤ 30    1 500
    ≤ 50    1 700
    ≤ 60    1 750
    ≤ 80    1 800
    ≤ 100   2 100
    > 100   2 200
    ======= ================

    If ``"bidirectional": true`` is set on an entry the reverse direction
    (toNode → fromNode) is adjusted with the same values.

    Parameters
    ----------
    network_fc:
        Original network GeoJSON FeatureCollection.
    link_adjustments:
        List of link adjustment dicts (as produced by ``_split_changes``).

    Returns
    -------
    adjusted_fc:
        Deep copy of *network_fc* with the requested link properties updated.
    affected_edges:
        List of ``(fromNode, toNode)`` tuples for every link that was changed
        (used by the pipeline to know which OD pairs to recompute).
    """
    adjusted_fc  = copy.deepcopy(network_fc)
    features     = adjusted_fc.get("features") or []
    affected_edges: list[tuple[str, str]] = []

    # Build lookup indices
    by_link_id: dict[str, list[int]]            = {}
    by_from_to: dict[tuple[str, str], int]      = {}

    for i, feat in enumerate(features):
        props = feat.get("properties") or {}
        lid   = str(props.get("linkId") or "").strip()
        fn    = str(props.get("fromNode") or "").strip()
        tn    = str(props.get("toNode") or "").strip()
        if lid:
            by_link_id.setdefault(lid, []).append(i)
        if fn and tn:
            by_from_to[(fn, tn)] = i

    def _adjust_feature(idx: int, entry: dict) -> None:
        props = features[idx].get("properties") or {}
        fn    = str(props.get("fromNode") or "").strip()
        tn    = str(props.get("toNode")   or "").strip()

        if "speed" in entry:
            old_speed = float(props.get("speed") or 0.0)
            new_speed = max(_parse_value(str(entry["speed"]), old_speed), 0.0)
            lanes     = int(props.get("lanes") or 1)
            new_cap   = _capacity_for_speed(new_speed, lanes) if new_speed > 0.0 else 0.0
            features[idx]["properties"]["speed"]    = new_speed
            features[idx]["properties"]["capacity"] = new_cap
        else:
            old_cap = float(props.get("capacity") or 0.0)
            new_cap = max(_parse_value(str(entry["capacity"]), old_cap), 0.0)
            features[idx]["properties"]["capacity"] = new_cap

        cur_flow = float(props.get("flow") or 0.0)
        features[idx]["properties"]["remainingCap"] = _remaining_cap(new_cap, props)

        affected_edges.append((fn, tn))

    for entry in link_adjustments:
        link_id  = str(entry.get("linkId") or "").strip()
        from_n   = str(entry.get("fromNode") or "").strip()
        to_n     = str(entry.get("toNode")   or "").strip()
        bidir    = bool(entry.get("bidirectional", False))

        matched: list[int] = []

        if link_id:
            matched = by_link_id.get(link_id, [])
            if not matched:
                raise ValueError(f"Link adjustment: linkId {link_id!r} not found in network.")
        elif from_n and to_n:
            idx = by_from_to.get((from_n, to_n))
            if idx is None:
                raise ValueError(
                    f"Link adjustment: edge ({from_n} → {to_n}) not found in network."
                )
            matched = [idx]
        else:
            raise ValueError(f"Link adjustment entry has no valid linkId or fromNode/toNode: {entry}")

        for idx in matched:
            _adjust_feature(idx, entry)

        # Bidirectional: also adjust the reverse direction(s)
        if bidir:
            if link_id:
                # For linkId entries, find reverse links from affected_edges
                reversed_pairs = [
                    (tn, fn)
                    for fn, tn in affected_edges[-len(matched):]
                ]
                for rfn, rtn in reversed_pairs:
                    rev_idx = by_from_to.get((rfn, rtn))
                    if rev_idx is not None:
                        _adjust_feature(rev_idx, entry)
            elif from_n and to_n:
                rev_idx = by_from_to.get((to_n, from_n))
                if rev_idx is not None:
                    _adjust_feature(rev_idx, entry)

    return adjusted_fc, affected_edges


# ---------------------------------------------------------------------------
# Report printer
# ---------------------------------------------------------------------------


def _print_flow_report(report: list[dict]) -> None:
    """Print a formatted table of flow delta entries, sorted by |delta| descending."""
    print()
    if not report:
        print("  No flow changes.")
        return

    w_link = max(len(str(r["linkId"])) for r in report)
    w_link = max(w_link, 6)

    header = (
        f"  {'linkId':<{w_link}}"
        f"  {'flow_before':>12}  {'flow_after':>10}  {'delta':>10}"
    )
    sep = "  " + "-" * (len(header) - 2)
    print(f"  {len(report)} link(s) with flow changes:")
    print(sep)
    print(header)
    print(sep)
    for r in sorted(report, key=lambda x: abs(x["flow_delta"]), reverse=True):
        print(
            f"  {str(r['linkId']):<{w_link}}"
            f"  {r['flow_before']:>12.4f}"
            f"  {r['flow_after']:>10.4f}"
            f"  {r['flow_delta']:>+10.4f}"
        )
    print(sep)
    print()


# ---------------------------------------------------------------------------
# ROUTES helpers
# ---------------------------------------------------------------------------


def _find_affected_link_ids(
    network_fc: dict,
    affected_edges: list[tuple[str, str]],
) -> set[str]:
    """Return the set of ``linkId`` values for the given ``(fromNode, toNode)`` edges."""
    edge_set = set(affected_edges)
    link_ids: set[str] = set()
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        fn  = str(props.get("fromNode") or "").strip()
        tn  = str(props.get("toNode")   or "").strip()
        lid = str(props.get("linkId")   or "").strip()
        if (fn, tn) in edge_set and lid:
            link_ids.add(lid)
    return link_ids


def _find_pairs_using_links(
    routes_fc: dict,
    affected_link_ids: set[str],
) -> list[dict]:
    """Return pair dicts for every OD feature whose route(s) use an affected link.

    Each returned dict has keys ``fromId``, ``toId``, ``fromType``, ``toType``,
    ``tripFraction`` — suitable as input to ``recompute_routes_for_pairs``.
    """
    pairs: list[dict] = []
    for feat in routes_fc.get("features", []):
        props = feat.get("properties") or {}
        routes = props.get("routes") or []
        uses_affected = any(
            lid in affected_link_ids
            for route in routes
            for lid in (route.get("linkPath") or [])
        )
        if uses_affected:
            pairs.append({
                "fromId":       str(props.get("fromZoneId") or ""),
                "toId":         str(props.get("toZoneId")   or ""),
                "fromType":     str(props.get("fromType")   or "zone"),
                "toType":       str(props.get("toType")     or "zone"),
                "tripFraction": float(props.get("tripFraction") or 0.0),
            })
    return pairs


def _get_closed_link_ids(network_fc: dict, affected_link_ids: set[str]) -> set[str]:
    """Return the subset of *affected_link_ids* whose ``capacity`` is 0 in *network_fc*.

    A link is considered closed when its ``properties.capacity`` equals ``0.0``
    after link adjustments have been applied.
    """
    closed: set[str] = set()
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        lid = str(props.get("linkId") or "")
        if lid in affected_link_ids and float(props.get("capacity") or 0.0) == 0.0:
            closed.add(lid)
    return closed


def _redistribute_routes(
    routes_fc: dict,
    affected_link_ids: set[str],
    closed_link_ids: set[str],
    zones_fc: dict,
    min_trips_per_pair: float = 2.0,
) -> tuple[dict, list[dict]]:
    """Attempt local redistribution of routes for OD pairs affected by link closures.

    For each OD pair that uses at least one link in *affected_link_ids*:

    * If it uses **only non-closed** adjusted links → send to ``pairs_for_recompute``
      (speed/partial-capacity change, needs full re-routing).
    * If it uses **closed** links (capacity == 0):

      * **Evaporation**: if ``tripFraction × production < min_trips_per_pair``
        → include in *redistributed_fc* with ``routes=[]`` (pair is removed from
        the network; ``tripFraction`` is left unchanged per convention).
      * **Local redistribution**: if ``remaining_routes >= 2``,
        or ``N == 2`` and ``remaining_routes == 1`` → redistribute the blocked
        trips proportionally over the remaining routes (blocked routes are removed).
        ``sum(route.trips)`` equals the original ``tripFraction`` after redistribution.
      * **Needs re-routing**: otherwise → send to ``pairs_for_recompute``.

    OD pairs that do not use any affected link are not included in either output.

    Parameters
    ----------
    routes_fc:
        Base ROUTES GeoJSON FeatureCollection.
    affected_link_ids:
        Set of all link IDs that were modified.
    closed_link_ids:
        Subset of *affected_link_ids* whose capacity was set to 0.
    zones_fc:
        ZONE GeoJSON FeatureCollection used to look up zone production.
    min_trips_per_pair:
        Minimum absolute trips (``tripFraction × production``) below which an OD
        pair is considered evaporated.

    Returns
    -------
    (redistributed_fc, pairs_for_recompute)
        *redistributed_fc* contains features whose routes were locally resolved
        (redistribution or evaporation).  *pairs_for_recompute* is a list of pair
        dicts suitable for ``recompute_routes_for_pairs``.
    """
    # Build zone production lookup: zoneId → production
    zone_production: dict[str, float] = {}
    for feat in zones_fc.get("features", []):
        props = feat.get("properties") or {}
        zid = str(props.get("zoneId") or "")
        if zid:
            zone_production[zid] = float(props.get("production") or 0.0)

    redistributed_features: list[dict] = []
    pairs_for_recompute: list[dict] = []

    for feat in routes_fc.get("features", []):
        props = feat.get("properties") or {}
        routes: list[dict] = list(props.get("routes") or [])

        # Collect all link IDs used by this OD pair
        all_link_ids: set[str] = {
            lid
            for route in routes
            for lid in (route.get("linkPath") or [])
        }

        uses_affected = bool(all_link_ids & affected_link_ids)
        if not uses_affected:
            continue  # not affected — pass through unchanged

        uses_closed = bool(all_link_ids & closed_link_ids)

        from_id    = str(props.get("fromZoneId") or "")
        to_id      = str(props.get("toZoneId")   or "")
        from_type  = str(props.get("fromType")   or "zone")
        to_type    = str(props.get("toType")     or "zone")
        trip_frac  = float(props.get("tripFraction") or 0.0)

        pair_dict = {
            "fromId":       from_id,
            "toId":         to_id,
            "fromType":     from_type,
            "toType":       to_type,
            "tripFraction": trip_frac,
        }

        if not uses_closed:
            # Only non-closed link changes (speed/capacity tweak) → full re-route
            pairs_for_recompute.append(pair_dict)
            continue

        # Determine production for evaporation check.
        # Node-type origins are not zone-production-scaled (factor = 1.0).
        if from_type == "zone":
            production = zone_production.get(from_id, 0.0)
        else:
            production = 1.0

        total_trips = trip_frac * production

        # Evaporation: absolute trips below threshold
        if total_trips < min_trips_per_pair:
            evap_feat = {
                "type":     "Feature",
                "geometry": feat.get("geometry"),
                "properties": {
                    **props,
                    "routes": [],
                },
            }
            redistributed_features.append(evap_feat)
            continue

        # Classify routes as blocked / remaining
        blocked:   list[dict] = []
        remaining: list[dict] = []
        for route in routes:
            link_path = route.get("linkPath") or []
            if any(lid in closed_link_ids for lid in link_path):
                blocked.append(route)
            else:
                remaining.append(route)

        n = len(routes)
        n_remaining = len(remaining)

        # Can we redistribute locally?
        can_redistribute = (n_remaining >= 2) or (n == 2 and n_remaining == 1)

        if not can_redistribute:
            pairs_for_recompute.append(pair_dict)
            continue

        # Proportional redistribution: blocked trips spread over remaining routes
        blocked_fraction  = sum(float(r.get("trips") or 0.0) for r in blocked)
        remaining_total   = sum(float(r.get("trips") or 0.0) for r in remaining)

        if remaining_total <= 0.0:
            # Degenerate case: all remaining trips are zero → re-route
            pairs_for_recompute.append(pair_dict)
            continue

        new_routes: list[dict] = []
        for r in remaining:
            old_trips = float(r.get("trips") or 0.0)
            new_trips = old_trips + (old_trips / remaining_total) * blocked_fraction
            new_routes.append({**r, "trips": new_trips})

        redist_feat = {
            "type":     "Feature",
            "geometry": feat.get("geometry"),
            "properties": {
                **props,
                "routes": new_routes,
            },
        }
        redistributed_features.append(redist_feat)

    redistributed_fc: dict = {"type": "FeatureCollection", "features": redistributed_features}
    return redistributed_fc, pairs_for_recompute


def _stamp_area_ids(fc: dict, new_area_id: str, base_area_id: str) -> dict:
    """Return a shallow copy of *fc* with ``$.properties`` updated for the new area.

    Sets / overwrites:

    * ``areaId``     → *new_area_id*   (glossary meta field)
    * ``baseAreaId`` → *base_area_id*  (glossary meta field; the area this was derived from)

    Any legacy ``area_id`` (snake_case) key is removed to ensure all outputs
    use the authoritative camelCase names from the glossary.
    """
    fc = {**fc}  # shallow copy so we don't mutate the caller's dict
    existing: dict = dict(fc.get("properties") or {})

    existing.pop("area_id", None)          # remove legacy snake_case key
    existing["areaId"]     = new_area_id
    existing["baseAreaId"] = base_area_id

    fc["properties"] = existing
    return fc


def merge_routes(
    base_fc: dict,
    *update_fcs: dict,
) -> dict:
    """Merge one or more update FeatureCollections into a base ROUTES FeatureCollection.

    For every feature in each *update_fc*, the matching feature in *base_fc*
    (matched on ``fromZoneId`` + ``toZoneId`` + ``fromType`` + ``toType``) is
    replaced.  New pairs (not present in *base_fc*) are appended.

    The ``properties.fields`` list of the base is preserved;
    any extra keys from update FCs are union-merged into it.

    Parameters
    ----------
    base_fc:
        The existing ROUTES GeoJSON FeatureCollection to update.
    *update_fcs:
        One or more FeatureCollections whose features should replace/extend
        the base.  Applied in order — later updates win over earlier ones.

    Returns
    -------
    dict
        Updated FeatureCollection.
    """
    # Build mutable index: (fromId, toId, fromType, toType) -> list position
    features = list(base_fc.get("features") or [])
    index: dict[tuple[str, str, str, str], int] = {}
    for i, feat in enumerate(features):
        p  = feat.get("properties") or {}
        key = (
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId")   or ""),
            str(p.get("fromType")   or "zone"),
            str(p.get("toType")     or "zone"),
        )
        index[key] = i

    for upd_fc in update_fcs:
        for feat in upd_fc.get("features") or []:
            p  = feat.get("properties") or {}
            key = (
                str(p.get("fromZoneId") or ""),
                str(p.get("toZoneId")   or ""),
                str(p.get("fromType")   or "zone"),
                str(p.get("toType")     or "zone"),
            )
            if key in index:
                features[index[key]] = feat
            else:
                index[key] = len(features)
                features.append(feat)

    # Merge fields lists
    base_lp: list[str] = list((base_fc.get("properties") or {}).get("fields") or [])
    for upd_fc in update_fcs:
        for lp_key in (upd_fc.get("properties") or {}).get("fields") or []:
            if lp_key not in base_lp:
                base_lp.append(lp_key)

    fc_props = dict(base_fc.get("properties") or {})
    fc_props["fields"] = base_lp

    return {"type": "FeatureCollection", "features": features, "properties": fc_props}


# ---------------------------------------------------------------------------
# Flow delta helpers
# ---------------------------------------------------------------------------


def _compute_link_flow_delta(
    old_routes_fc: dict,
    recomputed_fc: dict,
    od_fc_new: dict,
    zones_fc: dict,
) -> dict[str, tuple[float, float]]:
    """Compute per-link ``{linkId: (flow_before, flow_after)}`` from route changes.

    ``route.trips`` in a routes feature is a *fraction* of the origin's total
    production (i.e. it sums to ``tripFraction`` across all routes for a pair).
    To obtain actual trip counts the fraction is multiplied by the origin
    zone's ``production`` value looked up from *zones_fc*.

    The algorithm (per affected pair):

    .. code-block:: text

        remove_flows[linkId] += route.trips * O.production   (old routes)
        add_flows[linkId]    += route.trips * O.production   (new routes)
        delta[linkId]        = add_flows - remove_flows

    Parameters
    ----------
    old_routes_fc:
        The original ROUTES FeatureCollection (before any adjustments).
    recomputed_fc:
        Re-routed OD pairs for case (c): pairs whose route passed through an
        adjusted link.  These replace their counterparts in *old_routes_fc*.
    od_fc_new:
        Newly routed OD pairs for cases (a) and (b): node/zone adjustments.
        These have no old routes (flow_before = 0 for their links).
    zones_fc:
        Zone GeoJSON FeatureCollection — used to look up ``production`` per
        zone (keyed by ``zoneId``).  For node-type origins the production
        defaults to 1.0 (no scaling).

    Returns
    -------
    dict mapping linkId → (flow_before, flow_after)
        Only links with at least one non-zero entry are included.
    """
    # Build zone-production lookup
    zone_production: dict[str, float] = {}
    for feat in zones_fc.get("features") or []:
        p   = feat.get("properties") or {}
        zid = str(p.get("zoneId") or "").strip()
        if zid:
            zone_production[zid] = float(p.get("production") or 0.0)

    def _origin_production(p: dict) -> float:
        """Return the absolute production for the origin of an OD feature."""
        from_id   = str(p.get("fromZoneId") or "").strip()
        from_type = str(p.get("fromType")   or "zone").strip()
        if from_type == "zone":
            return zone_production.get(from_id, 0.0)
        # For node-type origins the route.trips fraction is already in absolute
        # trip units (build_od_matrix stores absolute trips for node adjustments).
        return 1.0

    before: dict[str, float] = {}
    after:  dict[str, float] = {}

    # Build a set of keys for re-routed pairs
    recomputed_keys: set[tuple[str, str, str, str]] = set()
    for feat in recomputed_fc.get("features") or []:
        p = feat.get("properties") or {}
        recomputed_keys.add((
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId")   or ""),
            str(p.get("fromType")   or "zone"),
            str(p.get("toType")     or "zone"),
        ))

    # Before: sum trips from old routes for every re-routed pair
    for feat in old_routes_fc.get("features") or []:
        p = feat.get("properties") or {}
        key = (
            str(p.get("fromZoneId") or ""),
            str(p.get("toZoneId")   or ""),
            str(p.get("fromType")   or "zone"),
            str(p.get("toType")     or "zone"),
        )
        if key not in recomputed_keys:
            continue
        production = _origin_production(p)
        for route in (p.get("routes") or []):
            trips = float(route.get("trips") or 0.0) * production
            for lid in (route.get("linkPath") or []):
                before[lid] = before.get(lid, 0.0) + trips

    # After: sum trips from re-routed pairs (new routes)
    for feat in recomputed_fc.get("features") or []:
        p = feat.get("properties") or {}
        production = _origin_production(p)
        for route in (p.get("routes") or []):
            trips = float(route.get("trips") or 0.0) * production
            for lid in (route.get("linkPath") or []):
                after[lid] = after.get(lid, 0.0) + trips

    # After: sum trips from new node/zone-adjustment pairs (flow_before = 0)
    for feat in od_fc_new.get("features") or []:
        p = feat.get("properties") or {}
        production = _origin_production(p)
        for route in (p.get("routes") or []):
            trips = float(route.get("trips") or 0.0) * production
            for lid in (route.get("linkPath") or []):
                after[lid] = after.get(lid, 0.0) + trips

    all_link_ids = set(before.keys()) | set(after.keys())
    return {lid: (before.get(lid, 0.0), after.get(lid, 0.0)) for lid in all_link_ids}


def _apply_flow_delta(
    network_fc: dict,
    delta: dict[str, tuple[float, float]],
) -> tuple[dict, list[dict]]:
    """Apply a per-link flow delta to a copy of *network_fc*.

    For each link in *delta*, ``flow_change = flow_after - flow_before`` is
    added to the ``flow`` and ``flow24hrs`` properties.  The ``flowsPerDaypart``
    and ``flowsPerMotive`` sub-dicts are scaled proportionally so that their
    sum matches the new ``flow`` value.

    Parameters
    ----------
    network_fc:
        Original network GeoJSON FeatureCollection.
    delta:
        Mapping of ``linkId → (flow_before, flow_after)`` as produced by
        ``_compute_link_flow_delta``.

    Returns
    -------
    (adjusted_fc, report)
        *adjusted_fc* is a deep copy of *network_fc* with updated flow fields.
        *report* is a list of dicts with ``{linkId, flow_before, flow_after,
        flow_delta}`` for each link that was changed.
    """
    adjusted_fc = copy.deepcopy(network_fc)
    report: list[dict] = []

    for feat in adjusted_fc.get("features") or []:
        props = feat.get("properties") or {}
        lid   = str(props.get("linkId") or "").strip()
        if lid not in delta:
            continue

        flow_before_route, flow_after_route = delta[lid]
        flow_change = flow_after_route - flow_before_route
        if flow_change == 0.0:
            continue

        orig_flow   = float(props.get("flow")     or 0.0)
        orig_flow24 = float(props.get("flow24hrs") or 0.0)
        new_flow    = max(orig_flow   + flow_change, 0.0)
        new_flow24  = max(orig_flow24 + flow_change, 0.0)

        feat["properties"]["flow"]     = new_flow
        feat["properties"]["flow24hrs"] = new_flow24

        # Proportional scaling for sub-dicts
        if orig_flow > 0.0:
            scale = new_flow / orig_flow
            if isinstance(props.get("flowsPerDaypart"), dict):
                feat["properties"]["flowsPerDaypart"] = {
                    k: max(v * scale, 0.0)
                    for k, v in props["flowsPerDaypart"].items()
                }
            if isinstance(props.get("flowsPerMotive"), dict):
                feat["properties"]["flowsPerMotive"] = {
                    k: max(v * scale, 0.0)
                    for k, v in props["flowsPerMotive"].items()
                }

        # Update remainingCap: capacity - max(flowsPerDaypart) after scaling
        feat["properties"]["remainingCap"] = _remaining_cap(
            feat["properties"].get("capacity"), feat["properties"]
        )

        report.append({
            "linkId":       lid,
            "flow_before":  orig_flow,
            "flow_after":   new_flow,
            "flow_delta":   flow_change,
        })

    return adjusted_fc, report


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


def run_pipeline(
    folder: Path,
    changes: str,
    output_folder: Path,
    *,
    routes_path: Path,
    new_area_id: str | None = None,
    min_link_trips: float,
    refresh: bool,
    debug: bool,
) -> None:
    """Run the GMT node- and link-adjustment pipeline.

    Parameters
    ----------
    folder:
        Directory containing prepared source files (network, zones, feedlinks).
    changes:
        Inline JSON array **or** path to a ``.json`` file describing adjustments.
        Each entry is either a **node/zone adjustment** or a **link adjustment**:

        Node/zone adjustment — must have ``"nodeId"`` **or** ``"zoneId"`` (not
        both), plus ``"production"`` and/or ``"attraction"``.

        Link adjustment — must have ``"linkId"`` **or** both ``"fromNode"`` and
        ``"toNode"``, plus **either** ``"capacity"`` or ``"speed"`` (not both).
        Values follow the delta convention: ``"+50"``, ``"-20"``, or an absolute
        numeric string.  If ``"bidirectional": true`` the reverse direction is
        also adjusted.  When ``"speed"`` is changed, capacity is automatically
        recalculated from the speed-category table (speed × lanes).

        Example::

            [
              {"nodeId": "1234", "production": "+500"},
              {"linkId": "9876", "capacity": "0", "bidirectional": true},
              {"fromNode": "111", "toNode": "222", "speed": "30"}
            ]

    routes_path:
        Path to the existing ``{area_id}-ROUTES-{mode}.geojson`` file produced
        by ``matrix_builder``.  The file is updated in the output folder:
        affected OD pairs (those whose routes pass through adjusted links) are
        re-routed on the modified network; pairs introduced by node/zone
        adjustments are appended.
    output_folder:
        Destination directory for the adjusted network, zones, feedlinks and
        the updated routes file.
    new_area_id:
        UUID to use for the output files.  When *None* a fresh UUID is generated.
    min_link_trips:
        Minimum absolute flow change required to update a link (applied as a
        threshold on ``|flow_delta|``).
    refresh:
        Rebuild the partial OD matrix even if the cache already exists.
    debug:
        Print the per-link flow report and write a bandwidth-comparison GeoJSON.
    """
    from route_explorer.core.route_explorer_core import (                                # noqa: PLC0415
        build_od_matrix,
        recompute_routes_for_pairs,
    )
    from compare_networks.core.compare_networks_core import compare_networks             # noqa: PLC0415

    area_id = _read_area_id(folder)
    mode    = _detect_mode(folder, area_id)

    network_path   = folder / f"{area_id}-NETWORK-{mode}.geojson"
    zones_path     = folder / f"{area_id}-ZONE-{mode}.geojson"
    feedlinks_path = folder / f"{area_id}-FEEDLINK-{mode}.geojson"

    for path in (network_path, zones_path, feedlinks_path, routes_path):
        if not path.exists():
            print(f"ERROR: required input file not found: {path}", file=sys.stderr)
            sys.exit(1)

    new_area_id  = new_area_id or str(uuid4())
    all_changes  = _load_changes(changes)
    if not all_changes:
        print("No adjustments provided — nothing to do.")
        sys.exit(0)

    node_adjustments, link_adjustments = _split_changes(all_changes)

    if not node_adjustments and not link_adjustments:
        print("No valid adjustments found — nothing to do.")
        sys.exit(0)

    print()
    print("============================================================")
    print(" GMT Adjustment Pipeline")
    print(f" source area-id    : {area_id}")
    print(f" new area-id       : {new_area_id}")
    print(f" mode              : {mode}")
    print(f" source folder     : {folder}")
    print(f" output folder     : {output_folder}")
    print(f" routes file       : {routes_path}")
    print(f" node adjustments  : {node_adjustments}")
    print(f" link adjustments  : {link_adjustments}")
    print(f" min link trips    : {min_link_trips}")
    print(f" refresh           : {'yes' if refresh else 'no (skipping existing outputs)'}")
    print("============================================================")

    # ------------------------------------------------------------------
    # [1/6] Load source files
    # ------------------------------------------------------------------
    print()
    print("[1/6] Loading source files ...")
    network_fc   = json.loads(network_path.read_text(encoding="utf-8"))
    zones_fc     = json.loads(zones_path.read_text(encoding="utf-8"))
    feedlinks_fc = json.loads(feedlinks_path.read_text(encoding="utf-8"))
    routes_fc    = json.loads(routes_path.read_text(encoding="utf-8"))
    print(
        f"      network: {len(network_fc.get('features', []))} links, "
        f"zones: {len(zones_fc.get('features', []))}, "
        f"feedlinks: {len(feedlinks_fc.get('features', []))}, "
        f"routes: {len(routes_fc.get('features', []))} OD pairs"
    )

    # ------------------------------------------------------------------
    # [2/6] Apply link adjustments (capacity / speed)
    # ------------------------------------------------------------------
    if link_adjustments:
        print(f"[2/6] Applying {len(link_adjustments)} link adjustment(s) ...")
        original_network_fc = network_fc
        network_fc, affected_edges = apply_link_adjustments(network_fc, link_adjustments)
        print(f"      {len(affected_edges)} edge(s) adjusted: {affected_edges}")
        if not refresh and (folder / f"_adjust-od-cache-{mode}.geojson").exists():
            print("      Link adjustments detected — OD cache invalidated (will rebuild).")
        refresh = True  # always rebuild when links change
    else:
        print("[2/6] No link adjustments — network unchanged.")
        original_network_fc = network_fc
        affected_edges = []

    # ------------------------------------------------------------------
    # [3/6] Determine affected OD pairs
    #   (a) node/zone adjustments  → build_od_matrix
    #   (b) O or D not yet in route set (handled by build_od_matrix)
    #   (c) existing routes pass through adjusted links → recompute_routes_for_pairs
    # ------------------------------------------------------------------
    od_cache_path = folder / f"_adjust-od-cache-{mode}.geojson"

    print("[3/6] Determining affected OD pairs ...")

    # (a)+(b) node/zone adjustments
    if not node_adjustments:
        print("      (a/b) SKIPPED — no node/zone adjustments.")
        od_fc = {"type": "FeatureCollection", "features": []}
    elif od_cache_path.exists() and not refresh:
        print("      (a/b) SKIPPED — cache exists (use --refresh to rebuild).")
        od_fc = json.loads(od_cache_path.read_text(encoding="utf-8"))
    else:
        print(f"      (a/b) build_od_matrix for {len(node_adjustments)} node/zone change(s) ...")
        od_fc = build_od_matrix(
            network_fc=network_fc,
            feedlinks_fc=feedlinks_fc,
            zones_fc=zones_fc,
            node_adjustments=node_adjustments,
        )
        od_cache_path.write_text(json.dumps(od_fc, ensure_ascii=False), encoding="utf-8")
        print(f"      (a/b) {len(od_fc.get('features', []))} pair(s) built; cached at {od_cache_path}")

    # (c) existing OD pairs whose routes use adjusted links
    # First try local redistribution for closed links; only call the expensive
    # recompute_routes_for_pairs for pairs that truly need full re-routing.
    recomputed_fc: dict = {"type": "FeatureCollection", "features": []}
    if affected_edges:
        affected_link_ids = _find_affected_link_ids(original_network_fc, affected_edges)
        closed_link_ids   = _get_closed_link_ids(network_fc, affected_link_ids)

        if closed_link_ids:
            print(
                f"      (c)   {len(closed_link_ids)} closed link(s) out of "
                f"{len(affected_link_ids)} adjusted — attempting local redistribution ..."
            )
        else:
            print(
                f"      (c)   {len(affected_link_ids)} adjusted link(s), "
                "none closed — all affected pairs will be fully re-routed."
            )

        redistributed_fc, pairs_to_recompute = _redistribute_routes(
            routes_fc=routes_fc,
            affected_link_ids=affected_link_ids,
            closed_link_ids=closed_link_ids,
            zones_fc=zones_fc,
        )

        n_redist  = len(redistributed_fc.get("features", []))
        n_rerout  = len(pairs_to_recompute)

        if n_redist:
            print(f"      (c)   {n_redist} pair(s) resolved locally (redistribution/evaporation).")
        if n_rerout:
            print(f"      (c)   {n_rerout} pair(s) require full re-routing ...")
            full_recomputed_fc = recompute_routes_for_pairs(
                network_fc=network_fc,
                feedlinks_fc=feedlinks_fc,
                zones_fc=zones_fc,
                pairs=pairs_to_recompute,
            )
            print(f"      (c)   {len(full_recomputed_fc.get('features', []))} pair(s) re-routed.")
        else:
            full_recomputed_fc = {"type": "FeatureCollection", "features": []}
            if not n_redist:
                print("      (c)   No existing pairs use the adjusted links.")

        recomputed_fc = {
            "type":     "FeatureCollection",
            "features": [
                *redistributed_fc.get("features", []),
                *full_recomputed_fc.get("features", []),
            ],
        }
    else:
        print("      (c)   SKIPPED — no link adjustments.")

    # ------------------------------------------------------------------
    # [4/6] Re-compute routes → build revised ROUTES file
    # ------------------------------------------------------------------
    print("[4/6] Updating ROUTES file ...")
    updates: list[dict] = []
    if recomputed_fc.get("features"):
        updates.append(recomputed_fc)
    if od_fc.get("features"):
        updates.append(od_fc)
        print(f"      Adding {len(od_fc['features'])} node/zone-adjustment pair(s).")

    if updates:
        updated_routes_fc = merge_routes(routes_fc, *updates)
        print(
            f"      ROUTES: {len(updated_routes_fc.get('features', []))} total pairs "
            f"(was {len(routes_fc.get('features', []))})."
        )
    else:
        updated_routes_fc = routes_fc
        print("      No ROUTES changes required.")

    # ------------------------------------------------------------------
    # [5/6] Apply flow delta to the NETWORK file
    #
    # Compute the per-link (flow_before, flow_after) from local route trips,
    # then add the delta proportionally to all flow sub-fields (flow, flow24hrs,
    # flowsPerDaypart, flowsPerMotive).  The base flow (Databricks source data)
    # is preserved; only the local route contribution is adjusted.
    # ------------------------------------------------------------------
    print("[5/6] Applying flow delta to NETWORK ...")
    delta = _compute_link_flow_delta(routes_fc, recomputed_fc, od_fc, zones_fc)

    # Filter out links whose absolute change is below the threshold
    if min_link_trips > 0.0:
        delta = {
            lid: (fb, fa)
            for lid, (fb, fa) in delta.items()
            if abs(fa - fb) >= min_link_trips
        }

    adjusted_fc, report = _apply_flow_delta(network_fc, delta)
    print(f"      {len(report)} link(s) updated.")

    if debug:
        _print_flow_report(report)

    # ------------------------------------------------------------------
    # Write outputs
    # ------------------------------------------------------------------
    output_folder.mkdir(parents=True, exist_ok=True)

    out_network   = output_folder / f"{new_area_id}-NETWORK-{mode}.geojson"
    out_zones     = output_folder / f"{new_area_id}-ZONE-{mode}.geojson"
    out_feedlinks = output_folder / f"{new_area_id}-FEEDLINK-{mode}.geojson"
    out_routes    = output_folder / f"{new_area_id}-ROUTES-{mode}.geojson"
    out_uuid_file = output_folder / ".area-uuid"

    # Stamp all output FeatureCollections with the new areaId and baseAreaId
    zones_fc_out    = _stamp_area_ids(zones_fc,     new_area_id, area_id)
    feedlinks_fc_out = _stamp_area_ids(
        json.loads(feedlinks_path.read_text(encoding="utf-8")), new_area_id, area_id
    )
    adjusted_fc_out  = _stamp_area_ids(adjusted_fc,       new_area_id, area_id)
    routes_fc_out    = _stamp_area_ids(updated_routes_fc,  new_area_id, area_id)

    out_network.write_text(  json.dumps(adjusted_fc_out,   ensure_ascii=False), encoding="utf-8")
    out_zones.write_text(    json.dumps(zones_fc_out,      ensure_ascii=False), encoding="utf-8")
    out_feedlinks.write_text(json.dumps(feedlinks_fc_out,  ensure_ascii=False), encoding="utf-8")
    out_routes.write_text(   json.dumps(routes_fc_out,     ensure_ascii=False), encoding="utf-8")
    out_uuid_file.write_text(new_area_id, encoding="utf-8")

    # ------------------------------------------------------------------
    # [6/6] Compare (always)
    # ------------------------------------------------------------------
    print("[6/6] compare_networks (bandwidths) ...")
    compare_fc = compare_networks(
        network_fc,
        adjusted_fc,
        fields=["flow"],
        as_bandwidths=True,
        bandwidth_scale=0.01,
    )
    out_compare = output_folder / f"{new_area_id}-COMPARE-{mode}.geojson"
    out_compare.write_text(json.dumps(compare_fc, ensure_ascii=False), encoding="utf-8")
    print(f"      Bandwidth comparison written: {out_compare.name}")

    print()
    print("============================================================")
    print(" Adjustment pipeline complete.")
    print(f" Output folder     : {output_folder}")
    print(f" Network           : {out_network.name}")
    print(f" Zones             : {out_zones.name}")
    print(f" Feedlinks         : {out_feedlinks.name}")
    print(f" Routes            : {out_routes.name}")
    print(f" Compare           : {out_compare.name}")
    print("============================================================")
