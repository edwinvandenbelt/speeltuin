# Databricks notebook source
# ---------------------------------------------------------------------------
# zone_fetcher_nb.py — Databricks notebook interface for zone_fetcher.
#
# This notebook:
#   1. Reads widget parameters (bbox, area_id, catalog, schema, output_folder).
#   2. Executes the zone-fetch SQL via build_fetch_zones_sql.
#   3. Assembles STUDY / INFLUENCE / AREA features via rows_to_feature_collection.
#      (BFS adjacency filter and convex-hull AREA are applied in Python.)
#   4. Writes the resulting GeoJSON FeatureCollection to S3.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("zone_fetcher_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text("bbox", "6.143,52.248,6.184,52.272", "Bounding box: minLon,minLat,maxLon,maxLat")  # noqa: F821
dbutils.widgets.text("area_id", "", "Area identifier (UUID generated if empty)")  # noqa: F821
dbutils.widgets.text("catalog", "spectrum", "Databricks Unity Catalog")  # noqa: F821
dbutils.widgets.text("schema", "2024_01", "Databricks schema / dataset version")  # noqa: F821
dbutils.widgets.text("output_folder", "s3://gmp-networks/zones/", "Output folder URI")  # noqa: F821
dbutils.widgets.text("LOG_LEVEL", "INFO", "Log level (DEBUG / INFO / WARNING / ERROR)")  # noqa: F821

# COMMAND ----------
_ll = getattr(logging, dbutils.widgets.get("LOG_LEVEL").strip().upper(), logging.INFO)  # noqa: F821
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
import uuid

BBOX      = [float(x) for x in dbutils.widgets.get("bbox").split(",")]  # noqa: F821
AREA_ID   = dbutils.widgets.get("area_id").strip() or str(uuid.uuid4())  # noqa: F821
CATALOG   = dbutils.widgets.get("catalog").strip()  # noqa: F821
SCHEMA    = dbutils.widgets.get("schema").strip()  # noqa: F821
OUT_FOLDER = dbutils.widgets.get("output_folder").strip().rstrip("/") + "/"  # noqa: F821

if len(BBOX) != 4:
    raise ValueError(f"Widget 'bbox' must have 4 comma-separated values, got {len(BBOX)}.")

logger.info(
    "bbox=%s  area_id=%s  catalog=%s  schema=%s",
    BBOX, AREA_ID, CATALOG, SCHEMA,
)

# COMMAND ----------
import sys

sys.path.insert(0, "/Workspace/Shared/gmt-calculation-lib/src")

from zone_fetcher.domain.sql import build_fetch_zones_sql, bbox_to_polygon_json  # noqa: E402
from zone_fetcher.domain.zone import rows_to_feature_collection  # noqa: E402

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run ZoneFetcher
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess.

# COMMAND ----------
import boto3  # noqa: E402, PLC0415


def _put_s3(uri: str, data: bytes) -> None:
    assert uri.startswith("s3://"), f"Expected s3:// URI, got {uri!r}"
    rest = uri[5:]
    bucket, _, key = rest.partition("/")
    boto3.client("s3").put_object(
        Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json"
    )
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


_t_start      = datetime.now(timezone.utc)
_polygon_json = bbox_to_polygon_json(BBOX)
_sql          = build_fetch_zones_sql(CATALOG, SCHEMA)
_params       = (_polygon_json,)

logger.info("Executing zone-fetch SQL ...")
_rows     = spark.sql(_sql, _params).collect()  # noqa: F821
_col_names = list(_rows[0].__fields__) if _rows else []

_fc = rows_to_feature_collection(
    [tuple(r) for r in _rows],
    _col_names,
    AREA_ID,
    BBOX,
)

_out_uri = f"{OUT_FOLDER}{AREA_ID}-ZONES.geojson"
_put_s3(_out_uri, json.dumps(_fc, ensure_ascii=False).encode("utf-8"))

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
_SEP = "─" * 60
print(_SEP)
print(f"ZoneFetcher complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Area ID        : {AREA_ID}")
print(f"  STUDY zones    : {_fc['properties']['studyCount']}")
print(f"  INFLUENCE zones: {_fc['properties']['influenceCount']}")
print(f"  Total features : {len(_fc['features'])}  (includes 1 AREA feature)")
print(f"  Output         : {_out_uri}")
print(_SEP)
