"""Local debug runner for zone_fetcher.

Fetches STUDY, INFLUENCE, and AREA zone features from Databricks and writes
a GeoJSON FeatureCollection to disk or S3.

Usage
-----
    # Using a bounding box:
    python -m zone_fetcher.zone_fetcher_runner \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder s3://gmp-networks/zones/ \\
        --area-id deventer-centrum \\
        --catalog spectrum --schema 2024_01

Prerequisites
-------------
* Databricks credentials in a .env file or os.environ
  (DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID, DATABRICKS_TOKEN).
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from uuid import uuid4


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Local runner for zone_fetcher (fetches zone features from Databricks)."
    )
    parser.add_argument(
        "--bbox", nargs=4, type=float, required=True,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box as four floats.",
    )
    parser.add_argument(
        "--output-folder", required=True, metavar="URI",
        help=(
            "Output folder URI (s3://bucket/prefix/ or local directory). "
            "Output file is named {area_id}-ZONES.geojson."
        ),
    )
    parser.add_argument("--area-id", default=None, metavar="ID",
                        help="Area identifier (UUID generated if not provided).")
    parser.add_argument("--name", default=None,
                        help="Human-readable area name stored in FC properties (optional).")
    parser.add_argument("--catalog", default="spectrum",
                        help="Databricks Unity Catalog name")
    parser.add_argument("--schema", default="2024_01",
                        help="Databricks schema / dataset version")
    parser.add_argument(
        "--exclude-zones",
        nargs="+",
        default=[],
        metavar="ZONE_ID",
        help="One or more zoneId values to exclude from the output (applied before BFS filter).",
    )
    parser.add_argument("--env-file", default=None,
                        help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from zone_fetcher.domain.sql import (  # noqa: PLC0415
        build_fetch_zones_sql,
        bbox_to_polygon_json,
    )
    from zone_fetcher.domain.zone import rows_to_feature_collection  # noqa: PLC0415
    import shared.databricks_sql as databricks_sql  # noqa: PLC0415

    bbox: list[float] = args.bbox
    polygon_json = bbox_to_polygon_json(bbox)
    area_id = args.area_id or str(uuid4())

    sql = build_fetch_zones_sql(args.catalog, args.schema)
    params = (polygon_json,)

    print(f"Area ID        : {area_id}")
    print(f"BBox           : {bbox}")

    with databricks_sql.connect_from_env() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, params)
            col_names = [d[0] for d in cur.description]
            rows = cur.fetchall()

    print(f"Raw rows       : {len(rows)}")

    fc = rows_to_feature_collection(
        rows, col_names, area_id, bbox,
        exclude_zone_ids=set(args.exclude_zones) if args.exclude_zones else None,
    )

    if args.name:
        fc["properties"]["name"] = args.name

    study_count    = fc["properties"]["studyCount"]
    influence_count = fc["properties"]["influenceCount"]
    total          = len(fc["features"])

    print(f"STUDY zones    : {study_count}")
    print(f"INFLUENCE zones: {influence_count}")
    print(f"Total features : {total}  (includes 1 AREA feature)")

    output_folder = args.output_folder.rstrip("/") + "/"
    out_uri = f"{output_folder}{area_id}-ZONES.geojson"
    print(f"Writing        : {out_uri}")
    _write_uri(out_uri, json.dumps(fc, ensure_ascii=False).encode("utf-8"))

    print("\nDone.")


if __name__ == "__main__":
    main()
