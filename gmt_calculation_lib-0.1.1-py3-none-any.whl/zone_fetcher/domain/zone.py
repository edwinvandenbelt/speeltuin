"""Zone row parsing and feature assembly for zone_fetcher — no I/O, no boto3.

Converts raw Databricks result rows into a GeoJSON FeatureCollection with:
  - STUDY features     — zones intersecting the input bbox
  - INFLUENCE features — zones reachable from a study zone via contiguous
                         zone boundaries (BFS adjacency filter)
  - AREA feature       — convex hull of all kept zone geometries
"""

from __future__ import annotations

import json
import logging

from zone_fetcher.domain.sql import _CBS_COLS, ZONE_FETCH_PROPERTIES

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Production / attraction formulae  (same as zone_intersector)
# ---------------------------------------------------------------------------

_LEERLING_COLS: tuple[str, ...] = (
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)


def _calc_production(r: dict) -> float:
    """Return production for a zone.

    production = (7 × huishoudens + 2.3 × inwoners) / 2
    """
    huishoudens = float(r.get("huishoudens") or 0.0)
    inwoners    = float(r.get("inwoners")    or 0.0)
    return (7.0 * huishoudens + 2.3 * inwoners) / 2.0


def _calc_attraction(r: dict) -> float:
    """Return attraction for a zone.

    attraction = 2 × (arbeidsplaatsen + Σ leerlingplaatsen_*)
    """
    arbeidsplaatsen = float(r.get("arbeidsplaatsen") or 0.0)
    leerling        = sum(float(r.get(c) or 0.0) for c in _LEERLING_COLS)
    return 2.0 * (arbeidsplaatsen + leerling)


# ---------------------------------------------------------------------------
# Row → Feature
# ---------------------------------------------------------------------------

def _parse_geom(raw: str | None, gid: object) -> dict | None:
    """Parse a GeoJSON geometry string, returning None on failure."""
    if not raw:
        logger.debug("Zone gid=%s — no geometry", gid)
        return None
    try:
        return json.loads(raw)
    except (json.JSONDecodeError, TypeError) as exc:
        logger.warning("Zone gid=%s — bad geometry JSON: %s", gid, exc)
        return None


_ZONE_CLASS_CODE: dict[str, int] = {
    "STUDY":     1,
    "INFLUENCE": 2,
}


def _zone_row_to_feature(r: dict) -> dict:
    """Convert a STUDY or INFLUENCE zone row dict to a GeoJSON Feature."""
    geom       = _parse_geom(r.get("geom_json"), r.get("gid"))
    zone_class = r.get("zoneClass") or ""
    props: dict = {
        "gid":            r.get("gid"),
        "zoneId":         r.get("zoneId"),
        "zoneName":       r.get("zoneName"),
        "municipalityCode": r.get("municipalityCode"),
        "municipalityName": r.get("municipalityName"),
        "zoneClass":      zone_class,
        "zoneClassCode":  _ZONE_CLASS_CODE.get(zone_class),
        "centroidLon":    r.get("centroidLon"),
        "centroidLat":    r.get("centroidLat"),
        "production":     _calc_production(r),
        "attraction":     _calc_attraction(r),
    }
    for col in _CBS_COLS:
        props[col] = r.get(col)
    return {"type": "Feature", "geometry": geom, "properties": props}


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _collect_coords(geometry: dict | None) -> list[list[float]]:
    """Recursively collect all [lon, lat] pairs from a GeoJSON geometry."""
    if not geometry:
        return []
    gtype  = geometry.get("type", "")
    coords = geometry.get("coordinates")
    if gtype == "Point":
        return [list(coords)] if coords else []
    if gtype in ("MultiPoint", "LineString"):
        return [list(p) for p in coords] if coords else []
    if gtype in ("MultiLineString", "Polygon"):
        return [list(p) for ring in (coords or []) for p in ring]
    if gtype == "MultiPolygon":
        return [list(p) for poly in (coords or []) for ring in poly for p in ring]
    if gtype == "GeometryCollection":
        result: list[list[float]] = []
        for g in geometry.get("geometries", []):
            result.extend(_collect_coords(g))
        return result
    return []


def _geom_bbox(geometry: dict | None) -> tuple[float, float, float, float] | None:
    """Return (min_lon, min_lat, max_lon, max_lat) for a GeoJSON geometry."""
    pts = _collect_coords(geometry)
    if not pts:
        return None
    lons = [p[0] for p in pts]
    lats = [p[1] for p in pts]
    return min(lons), min(lats), max(lons), max(lats)


def _bboxes_touch_or_overlap(
    a: tuple[float, float, float, float],
    b: tuple[float, float, float, float],
    tol: float = 1e-6,
) -> bool:
    """Return True when two bounding boxes touch or overlap (within *tol* degrees)."""
    return not (
        a[2] + tol < b[0] or   # a entirely left of b
        b[2] + tol < a[0] or   # b entirely left of a
        a[3] + tol < b[1] or   # a entirely below b
        b[3] + tol < a[1]      # b entirely below a
    )


# ---------------------------------------------------------------------------
# BFS adjacency filter
# ---------------------------------------------------------------------------

def _build_adjacency_graph(
    features: list[dict],
) -> dict[str, set[str]]:
    """Build a zone-adjacency graph based on bounding-box overlap / touching.

    Returns a dict mapping ``zoneId → set of adjacent zoneIds``.
    Only features with a parsable geometry and a ``zoneId`` are included.
    """
    # Precompute bbox per feature
    zone_ids: list[str] = []
    bboxes:   list[tuple[float, float, float, float]] = []
    for f in features:
        zid  = (f.get("properties") or {}).get("zoneId")
        bbox = _geom_bbox(f.get("geometry"))
        if zid and bbox:
            zone_ids.append(zid)
            bboxes.append(bbox)

    n = len(zone_ids)
    graph: dict[str, set[str]] = {zid: set() for zid in zone_ids}
    for i in range(n):
        for j in range(i + 1, n):
            if _bboxes_touch_or_overlap(bboxes[i], bboxes[j]):
                graph[zone_ids[i]].add(zone_ids[j])
                graph[zone_ids[j]].add(zone_ids[i])
    return graph


def _filter_influence_by_adjacency(features: list[dict]) -> list[dict]:
    """Return only STUDY features plus INFLUENCE features that directly border a study zone.

    An influence zone is kept only if its bounding box touches or overlaps the bounding
    box of at least one study zone (1-hop adjacency).  Influence zones that only touch
    other influence zones are dropped.
    """
    study_ids: set[str] = set()
    for f in features:
        props = f.get("properties") or {}
        if props.get("zoneClass") == "STUDY":
            zid = props.get("zoneId")
            if zid:
                study_ids.add(zid)

    if not study_ids:
        # No study zones — return everything unchanged (degenerate case)
        return features

    graph = _build_adjacency_graph(features)

    # Direct neighbours of study zones only (1 hop — no BFS propagation)
    visited: set[str] = set(study_ids)
    for study_id in study_ids:
        for neighbour in graph.get(study_id, ()):
            visited.add(neighbour)

    # Keep study zones unconditionally; keep influence zones only if BFS-reached
    kept: list[dict] = []
    dropped = 0
    for f in features:
        props    = f.get("properties") or {}
        zone_cls = props.get("zoneClass")
        zid      = props.get("zoneId")
        if zone_cls == "STUDY":
            kept.append(f)
        elif zone_cls == "INFLUENCE":
            if zid in visited:
                kept.append(f)
            else:
                dropped += 1
                logger.debug(
                    "BFS: dropped isolated INFLUENCE zone %s (%s)",
                    zid,
                    props.get("zoneName"),
                )
        else:
            kept.append(f)   # unexpected class — pass through

    if dropped:
        logger.info("BFS adjacency filter: dropped %d isolated influence zone(s)", dropped)

    return kept


# ---------------------------------------------------------------------------
# Convex hull AREA feature
# ---------------------------------------------------------------------------

def _cross(o: tuple, a: tuple, b: tuple) -> float:
    """2-D cross product of vectors OA and OB."""
    return (a[0] - o[0]) * (b[1] - o[1]) - (a[1] - o[1]) * (b[0] - o[0])


def _convex_hull_ring(points: list[list[float]]) -> list[list[float]]:
    """Return a closed GeoJSON ring (convex hull) for *points*.

    Uses the Andrew monotone chain algorithm.  Returns ``[]`` when there are
    fewer than 3 distinct points.
    """
    pts = sorted({(p[0], p[1]) for p in points})
    n = len(pts)
    if n < 3:
        return []

    # Lower hull
    lower: list[tuple] = []
    for p in pts:
        while len(lower) >= 2 and _cross(lower[-2], lower[-1], p) <= 0:
            lower.pop()
        lower.append(p)

    # Upper hull
    upper: list[tuple] = []
    for p in reversed(pts):
        while len(upper) >= 2 and _cross(upper[-2], upper[-1], p) <= 0:
            upper.pop()
        upper.append(p)

    # Concatenate (drop duplicate endpoints) and close the ring
    hull = lower[:-1] + upper[:-1]
    hull.append(hull[0])
    return [[p[0], p[1]] for p in hull]


def _build_area_feature(features: list[dict], area_id: str) -> dict:
    """Build a GeoJSON Feature with ``zoneClass = 'AREA'`` from the convex hull
    of all coordinates in *features*.

    Returns a Feature with ``geometry = None`` when fewer than 3 distinct
    coordinate pairs are available.
    """
    all_pts: list[list[float]] = []
    for f in features:
        all_pts.extend(_collect_coords(f.get("geometry")))

    ring = _convex_hull_ring(all_pts)
    geometry: dict | None = (
        {"type": "Polygon", "coordinates": [ring]} if ring else None
    )
    return {
        "type": "Feature",
        "geometry": geometry,
        "properties": {"zoneId": area_id, "zoneClass": "AREA"},
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def rows_to_feature_collection(
    rows: list,
    col_names: list[str],
    area_id: str,
    bbox: list[float],
    *,
    exclude_zone_ids: set[str] | None = None,
) -> dict:
    """Convert raw Databricks result rows into a GeoJSON FeatureCollection.

    Parameters
    ----------
    rows:
        Raw row tuples returned by the Databricks cursor.
    col_names:
        Column names corresponding to each position in *rows*.
    area_id:
        UUID string used as ``id`` on the FeatureCollection and to identify the
        AREA union feature.
    bbox:
        Normalised ``[lon_min, lat_min, lon_max, lat_max]`` stored in
        ``FeatureCollection.properties.bbox``.
    exclude_zone_ids:
        Optional set of ``zoneId`` strings to drop before any further
        processing.  Excluded zones are removed from STUDY and INFLUENCE
        features, which also affects the BFS adjacency filter and the AREA
        convex hull.

    Returns
    -------
    dict
        GeoJSON FeatureCollection with STUDY, INFLUENCE, and AREA features.

    Notes
    -----
    The SQL query returns only STUDY and candidate-INFLUENCE rows.  This
    function applies a BFS adjacency filter (see ``_filter_influence_by_adjacency``)
    to remove isolated influence zones, then computes the AREA feature as the
    convex hull of all kept zone geometries.
    """
    raw_features: list[dict] = []
    for row in rows:
        r = dict(zip(col_names, row))
        zone_class = r.get("zoneClass") or ""
        if zone_class in ("STUDY", "INFLUENCE"):
            raw_features.append(_zone_row_to_feature(r))
        else:
            logger.warning(
                "Unexpected zoneClass %r for gid=%s — skipping", zone_class, r.get("gid")
            )

    # Apply explicit exclusions before the BFS adjacency filter so that excluded
    # zones are also absent from the adjacency graph and the AREA convex hull.
    if exclude_zone_ids:
        before = len(raw_features)
        raw_features = [
            f for f in raw_features
            if (f.get("properties") or {}).get("zoneId") not in exclude_zone_ids
        ]
        dropped = before - len(raw_features)
        if dropped:
            logger.info("exclude_zone_ids: dropped %d zone(s) matching %s", dropped, sorted(exclude_zone_ids))

    # BFS: remove influence zones not reachable from any study zone
    kept_features = _filter_influence_by_adjacency(raw_features)

    # Build counts
    study_count    = sum(
        1 for f in kept_features if (f.get("properties") or {}).get("zoneClass") == "STUDY"
    )
    influence_count = sum(
        1 for f in kept_features if (f.get("properties") or {}).get("zoneClass") == "INFLUENCE"
    )

    # Append convex-hull AREA feature
    area_feature = _build_area_feature(kept_features, area_id)
    all_features = kept_features + [area_feature]

    return {
        "type": "FeatureCollection",
        "id": area_id,
        "features": all_features,
        "properties": {
            "areaId":          area_id,
            "bbox":            bbox,
            "studyCount":      study_count,
            "influenceCount":  influence_count,
            "fields": list(ZONE_FETCH_PROPERTIES),
        },
    }
