"""SQL construction for zone_fetcher — no I/O, no boto3.

Builds the Databricks SQL query that:
 1. Finds STUDY zones (zones where ≥ 80 % of the zone area overlaps the input bbox).
 2. Falls back to the zone containing the bbox centre when the bbox contains
    no zone centroids at all.
 3. Finds candidate INFLUENCE zones: all zones whose centroid lies within 12 km of
    the bbox centroid (fast point-to-point distance).  A Python-side BFS then
    filters this broad candidate set down to only zones that are reachable from a
    study zone via a chain of touching/overlapping zone bboxes.

The returned SQL has **one** positional ``?`` placeholder:
    1. bbox GeoJSON polygon string  (used for spatial intersection)

The AREA feature (convex hull of all kept zones) is computed in Python by
``rows_to_feature_collection`` — it is no longer produced by the SQL query.
"""

from __future__ import annotations

import json

# ---------------------------------------------------------------------------
# CBS demographic columns — identical to zone_intersector._CBS_COLS
# ---------------------------------------------------------------------------

_CBS_COLS: tuple[str, ...] = (
    "inwoners",
    "huishoudens",
    "arbeidsplaatsen",
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)

# Output property keys present on every STUDY / INFLUENCE feature.
ZONE_FETCH_PROPERTIES: tuple[str, ...] = (
    "gid",
    "zoneId",
    "zoneName",
    "municipalityCode",
    "municipalityName",
    "zoneClass",
    "zoneClassCode",
    "centroidLon",
    "centroidLat",
    "production",
    "attraction",
    *_CBS_COLS,
)

# ---------------------------------------------------------------------------
# SQL fragments
# ---------------------------------------------------------------------------

_CBS_SELECT = ",\n        ".join(f"z.{c}" for c in _CBS_COLS)
_CBS_NULLS = ",\n    ".join(f"CAST(NULL AS DOUBLE) AS {c}" for c in _CBS_COLS)


def build_fetch_zones_sql(catalog: str, schema: str) -> str:
    """Return the zone-fetch SQL for *catalog* and *schema*.

    Placeholders (in order)
    -----------------------
    1. bbox GeoJSON polygon string
    """
    db = f"`{catalog}`.`{schema}`"
    return f"""\
WITH
bbox_rd AS (
    SELECT ST_Transform(ST_GeomFromGeoJSON(?), 28992) AS poly
),

-- Zones where at least 80 % of the zone area lies within the input bbox (primary study area)
study_intersect_gids AS (
    SELECT z.gid
    FROM   {db}.d030_zones_met_centroids z
    CROSS JOIN bbox_rd
    WHERE  ST_Intersects(ST_GeomFromEWKB(z.zone_geometrie), poly)
      AND  ST_Area(ST_Intersection(ST_GeomFromEWKB(z.zone_geometrie), poly))
             / NULLIF(ST_Area(ST_GeomFromEWKB(z.zone_geometrie)), 0) >= 0.8
),

-- Fallback: zone containing the bbox centre (used only when no zones intersect the bbox)
study_center_gids AS (
    SELECT z.gid
    FROM   {db}.d030_zones_met_centroids z
    CROSS JOIN bbox_rd
    WHERE  NOT EXISTS (SELECT 1 FROM study_intersect_gids)
      AND  ST_Contains(ST_GeomFromEWKB(z.zone_geometrie), ST_Centroid(poly))
    LIMIT 1
),

study_gids AS (
    SELECT gid FROM study_intersect_gids
    UNION ALL
    SELECT gid FROM study_center_gids
),

-- Centre point of the input bbox (reference point for influence radius)
bbox_centroid_rd AS (
    SELECT ST_Centroid(poly) AS pt FROM bbox_rd
),

-- Broad candidate influence zones: centroid within 12 km of the bbox centroid.
-- Python-side BFS (in rows_to_feature_collection) then prunes this set to only
-- zones reachable from a study zone via a contiguous chain of touching zones.
candidate_influence_gids AS (
    SELECT z.gid
    FROM   {db}.d030_zones_met_centroids z
    CROSS JOIN bbox_centroid_rd
    WHERE  z.gid NOT IN (SELECT gid FROM study_gids)
      AND  ST_DWithin(ST_GeomFromEWKB(z.centroid_geometrie), bbox_centroid_rd.pt, 12000)
),

relevant AS (
    SELECT gid, 'STUDY'     AS zone_class FROM study_gids
    UNION ALL
    SELECT gid, 'INFLUENCE' AS zone_class FROM candidate_influence_gids
),

zone_data AS (
    SELECT
        z.gid,
        z.zone_id                                                                AS zoneId,
        z.zone_naam                                                              AS zoneName,
        z.gemeente_code                                                          AS municipalityCode,
        z.gemeente_naam                                                          AS municipalityName,
        {_CBS_SELECT},
        ST_AsGeoJSON(ST_Transform(ST_GeomFromEWKB(z.zone_geometrie), 4326))     AS geom_json,
        ST_X(ST_Transform(ST_GeomFromEWKB(z.centroid_geometrie), 4326))         AS centroidLon,
        ST_Y(ST_Transform(ST_GeomFromEWKB(z.centroid_geometrie), 4326))         AS centroidLat,
        r.zone_class                                                             AS zoneClass
    FROM   {db}.d030_zones_met_centroids z
    JOIN   relevant r USING (gid)
)

SELECT
    gid,
    zoneId,
    zoneName,
    municipalityCode,
    municipalityName,
    {_CBS_SELECT.replace("z.", "")},
    geom_json,
    centroidLon,
    centroidLat,
    zoneClass
FROM zone_data
"""


def bbox_to_polygon_json(bbox: list[float]) -> str:
    """Convert ``[lon_min, lat_min, lon_max, lat_max]`` to a GeoJSON Polygon string."""
    lon_min, lat_min, lon_max, lat_max = bbox[0], bbox[1], bbox[2], bbox[3]
    coords = [
        [lon_min, lat_min],
        [lon_max, lat_min],
        [lon_max, lat_max],
        [lon_min, lat_max],
        [lon_min, lat_min],
    ]
    return json.dumps({"type": "Polygon", "coordinates": [coords]})
