"""Pure-Python network cleaner core — no I/O, no boto3, no external deps.

Public API
----------
build_adjacency, node_positions, find_seed_node, clean_network
"""

from __future__ import annotations

import logging

from network_cleaner.domain.graph import build_adjacency, find_seed_node, node_positions

logger = logging.getLogger(__name__)

__all__ = ["build_adjacency", "node_positions", "find_seed_node", "clean_network"]


def clean_network(fc: dict) -> tuple[dict, dict]:
    """Remove dead links from a network FeatureCollection.

    Starting from the seed node (the node nearest to the centre of the bounding
    box), links are added iteratively: any link that shares a node with the
    current live set is kept.  This continues until no new links can be added.
    Links without a usable ``fromNode`` (e.g. pedestrian links with node 0) are
    always kept unconditionally.
    """
    features: list[dict] = fc.get("features") or []
    bbox: list[float] = (fc.get("properties") or {}).get("bbox") or []

    if not features:
        logger.warning("clean_network called on empty FeatureCollection — nothing to clean.")
        return dict(fc), {"total": 0, "kept": 0, "removed": 0, "seed_node": None}

    if not bbox or len(bbox) < 4:
        logger.warning("clean_network: bbox missing from FC properties — deriving from geometry.")
        all_lons: list[float] = []
        all_lats: list[float] = []
        for feat in features:
            for c in (feat.get("geometry") or {}).get("coordinates") or []:
                all_lons.append(c[0])
                all_lats.append(c[1])
        if not all_lons:
            raise ValueError("Cannot determine bbox: no feature coordinates found.")
        bbox = [min(all_lons), min(all_lats), max(all_lons), max(all_lats)]

    seed = find_seed_node(features, bbox)
    logger.info("Cleaning network: %d features, seed_node=%d", len(features), seed)

    # Seed node is the starting point of the live set.
    live_nodes: set[int] = {seed}
    kept: list[dict] = []
    candidates: list[dict] = []

    # Features without a usable fromNode (e.g. pedestrian, fromNode=0) are
    # always kept; all others start as candidates.
    for feat in features:
        props = feat.get("properties") or {}
        try:
            fn = int(props.get("fromNode"))  # type: ignore[arg-type]
        except (ValueError, TypeError):
            fn = None
        if fn is None or fn == 0:
            kept.append(feat)
        else:
            candidates.append(feat)

    # Flood-fill: iteratively keep any candidate link that shares a node with
    # the live set, adding its nodes to the live set so the next wave can grow.
    changed = True
    while changed and candidates:
        changed = False
        still_dead: list[dict] = []
        for feat in candidates:
            props = feat.get("properties") or {}
            try:
                fn = int(props.get("fromNode"))  # type: ignore[arg-type]
            except (ValueError, TypeError):
                fn = None
            try:
                tn = int(props.get("toNode"))  # type: ignore[arg-type]
            except (ValueError, TypeError):
                tn = None
            if (fn and fn in live_nodes) or (tn and tn in live_nodes):
                kept.append(feat)
                if fn and fn != 0:
                    live_nodes.add(fn)
                if tn and tn != 0:
                    live_nodes.add(tn)
                changed = True
            else:
                still_dead.append(feat)
        candidates = still_dead

    removed = len(candidates)
    logger.info(
        "Cleaning complete: %d kept, %d removed (seed_node=%d)",
        len(kept), removed, seed,
    )

    cleaned_fc = {
        "type": "FeatureCollection",
        "features": kept,
        "properties": fc.get("properties"),
    }

    stats = {
        "total": len(features),
        "kept": len(kept),
        "removed": removed,
        "seed_node": seed,
    }
    return cleaned_fc, stats
