"""Pure-Python all-or-nothing traffic assignment core — no I/O, no boto3, no external deps.

Assigns OD-matrix trip demand to network links using the All-or-Nothing algorithm:
for each OD pair, find the shortest path (Dijkstra with BPR-style cost) and load
the trip count onto every regular link along that path.

Public API
----------
assign_all_or_nothing(network_fc, feedlinks_fc, od_fc, alpha, beta)
    -> tuple[dict, dict]
    Returns (output_fc, stats) where output_fc is a copy of network_fc with
    ``flow`` overwritten on each link.
    stats: {"totalTrips": float, "assignedTrips": float, "links": int}
"""

from __future__ import annotations

import heapq
import logging
import math

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Output field definitions (authoritative)
# ---------------------------------------------------------------------------

ALL_OR_NOTHING_PROPERTIES: tuple[str, ...] = (
    "linkId",
    "fromNode",
    "toNode",
    "flow",
)


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

_Adjacency = dict[str, list[tuple[str, float, str]]]  # node -> [(neighbour, cost, link_id)]


# ---------------------------------------------------------------------------
# BPR cost
# ---------------------------------------------------------------------------

def _link_cost(
    length_m: float,
    speed_kmh: float,
    flow: float,
    capacity: float,
    alpha: float,
    beta: float,
) -> float:
    """Compute BPR travel-time cost for a single link in seconds."""
    if speed_kmh <= 0:
        return math.inf
    travel_time = (length_m / 1000.0) / speed_kmh * 3600.0
    if capacity <= 0:
        return math.inf
    return travel_time * (1.0 + alpha * ((flow / capacity) ** beta))


# ---------------------------------------------------------------------------
# Graph construction
# ---------------------------------------------------------------------------

def _build_adjacency(
    network_features: list[dict],
    feedlink_features: list[dict],
    alpha: float,
    beta: float,
) -> _Adjacency:
    """Build directed adjacency list from network + feedlink features.

    Feedlinks are included so that Dijkstra can start from centroid nodes.
    """
    adj: _Adjacency = {}

    def _add(from_node: str, to_node: str, cost: float, link_id: str) -> None:
        adj.setdefault(from_node, []).append((to_node, cost, link_id))

    for feat in network_features:
        props = feat.get("properties") or {}
        from_node = str(props.get("fromNode", ""))
        to_node = str(props.get("toNode", ""))
        if not from_node or not to_node:
            continue
        link_id = str(props.get("linkId", ""))
        length_m = float(props.get("length") or 0.0)
        speed_kmh = float(props.get("speed") or 0.0)
        flow = float(props.get("flow") or 0.0)
        capacity = float(props.get("capacity") or 0.0)
        cost = _link_cost(length_m, speed_kmh, flow, capacity, alpha, beta)
        _add(from_node, to_node, cost, link_id)

    for feat in feedlink_features:
        props = feat.get("properties") or {}
        from_node = str(props.get("fromNode", ""))
        to_node = str(props.get("toNode", ""))
        if not from_node or not to_node:
            continue
        link_id = str(props.get("linkId", ""))
        # Feedlinks: free-flow cost only — capacity is not applicable
        length_m = float(props.get("length") or 0.0)
        speed_kmh = float(props.get("speed") or 50.0)
        if speed_kmh <= 0:
            cost = math.inf
        else:
            cost = (length_m / 1000.0) / speed_kmh * 3600.0
        _add(from_node, to_node, cost, link_id)

    return adj


# ---------------------------------------------------------------------------
# Zone → centroid node mapping
# ---------------------------------------------------------------------------

def _parse_zone_nodes(
    feedlink_features: list[dict],
) -> tuple[dict[str, str], dict[str, str]]:
    """Map zoneId -> origin/destination nodes from feedlinks.

    Priority: inner feedlinks (``ringIndex == -1``) are preferred.  For zones
    that have **no** inner feedlink (e.g. ``cross_*`` and ``cluster_*`` outer
    zones), the first-seen ``ringIndex == 0`` feedlink is used as a fallback.

    For both inner and outer feedlinks the production feedlink convention is:
    - ``fromNode`` = zone centroid  → ``origin_nodes``
    - ``toNode``   = network attachment → ``dest_nodes``

    Only the **first-seen** feedlink per zone and per ring-group is recorded so
    that the attraction feedlink (same zone, reversed direction, built second by
    feedlink_creator) does not overwrite the production feedlink.

    Returns
    -------
    origin_nodes:
        zoneId -> centroid node.  Used as the Dijkstra start node.
    dest_nodes:
        zoneId -> network attachment node.  Used as the Dijkstra target.
    """
    inner: dict[str, tuple[str, str]] = {}   # zoneId -> (fromNode, toNode)
    outer: dict[str, tuple[str, str]] = {}   # fallback for zones without inner feedlink

    for feat in feedlink_features:
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId", ""))
        if not zone_id:
            continue
        from_node = str(props.get("fromNode", ""))
        to_node = str(props.get("toNode", ""))
        if not from_node or not to_node:
            continue
        ring_index = props.get("ringIndex")
        if ring_index == -1:
            if zone_id not in inner:
                inner[zone_id] = (from_node, to_node)
        else:
            if zone_id not in outer:
                outer[zone_id] = (from_node, to_node)

    # Merge: inner takes precedence; outer is used only when no inner exists
    origin_nodes: dict[str, str] = {}
    dest_nodes:   dict[str, str] = {}
    for zone_id, (frm, to) in {**outer, **inner}.items():
        origin_nodes[zone_id] = frm
        dest_nodes[zone_id]   = to

    return origin_nodes, dest_nodes


# ---------------------------------------------------------------------------
# Dijkstra
# ---------------------------------------------------------------------------

def _dijkstra(adj: _Adjacency, source: str) -> tuple[dict[str, float], dict[str, str | None]]:
    """Single-source Dijkstra.

    Returns
    -------
    dist  : node -> shortest distance from source
    prev  : node -> previous node on shortest path (None for source)
    """
    dist: dict[str, float] = {source: 0.0}
    prev: dict[str, str | None] = {source: None}
    heap: list[tuple[float, str]] = [(0.0, source)]

    while heap:
        d, u = heapq.heappop(heap)
        if d > dist.get(u, math.inf):
            continue
        for v, w, _link_id in adj.get(u, []):
            nd = d + w
            if nd < dist.get(v, math.inf):
                dist[v] = nd
                prev[v] = u
                heapq.heappush(heap, (nd, v))

    return dist, prev


def _reconstruct_path(prev: dict[str, str | None], target: str) -> list[str]:
    """Return ordered list of nodes from source to target, or [] if unreachable."""
    path: list[str] = []
    node: str | None = target
    while node is not None:
        path.append(node)
        node = prev.get(node)
    path.reverse()
    # If the path does not start at a known source (prev[source] is None) it is
    # unreachable — the reconstructed list will still start at source because
    # source maps to None in prev.  An unreachable target has no entry in prev.
    if target not in prev:
        return []
    return path


# ---------------------------------------------------------------------------
# Link-id lookup along a node path
# ---------------------------------------------------------------------------

def _build_link_index(
    network_features: list[dict],
) -> dict[tuple[str, str], str]:
    """Build (fromNode, toNode) -> linkId index for regular (non-feedlink) links."""
    index: dict[tuple[str, str], str] = {}
    for feat in network_features:
        props = feat.get("properties") or {}
        link_type = str(props.get("type", "")).lower()
        if link_type == "feedlink":
            continue
        from_node = str(props.get("fromNode", ""))
        to_node = str(props.get("toNode", ""))
        link_id = str(props.get("linkId", ""))
        if from_node and to_node and link_id:
            index[(from_node, to_node)] = link_id
    return index


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def assign_all_or_nothing(
    network_fc: dict,
    feedlinks_fc: dict,
    od_fc: dict,
    alpha: float = 0.15,
    beta: float = 4.0,
) -> tuple[dict, dict]:
    """All-or-Nothing traffic assignment.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection.  Each feature must have properties:
        ``linkId``, ``fromNode``, ``toNode``, ``length`` (m), ``speed`` (km/h),
        ``flow``, ``capacity``.
    feedlinks_fc:
        Feedlinks GeoJSON FeatureCollection.  Inner feedlinks (``ringIndex == -1``)
        define the zone centroid node mapping.
    od_fc:
        OD-matrix GeoJSON FeatureCollection.  Each feature must have properties:
        ``fromZoneId``, ``toZoneId``, ``trips``.
    alpha:
        BPR alpha coefficient (default 0.15).
    beta:
        BPR beta exponent (default 4.0).

    Returns
    -------
    output_fc:
        Copy of network_fc with ``flow`` reset and set to the newly assigned value on each link.
    stats:
        ``totalTrips``, ``assignedTrips``, ``unassignedTrips``,
        ``links``, ``assignedPairs``, ``totalPairs``.
    """
    network_features: list[dict] = (network_fc.get("features") or [])
    feedlink_features: list[dict] = (feedlinks_fc.get("features") or [])
    od_features: list[dict] = (od_fc.get("features") or [])

    logger.info(
        "assign_all_or_nothing: %d network links, %d feedlinks, %d OD pairs",
        len(network_features), len(feedlink_features), len(od_features),
    )

    # Build adjacency (network + feedlinks merged)
    adj = _build_adjacency(network_features, feedlink_features, alpha, beta)

    # Zone -> centroid node mapping (for origins) and network-attachment node (for destinations)
    origin_nodes, dest_nodes = _parse_zone_nodes(feedlink_features)
    logger.debug("Zone origin nodes: %d  dest nodes: %d", len(origin_nodes), len(dest_nodes))

    # Build link index for flow accumulation (regular links only)
    link_index = _build_link_index(network_features)

    # Accumulate flow on link_id -> additional_flow
    flow_delta: dict[str, float] = {}

    total_trips = 0.0
    assigned_trips = 0.0
    assigned_pairs = 0
    total_pairs = 0

    # Group OD pairs by origin zone to run Dijkstra once per origin
    od_by_origin: dict[str, list[tuple[str, float]]] = {}
    for feat in od_features:
        props = feat.get("properties") or {}
        from_zone = str(props.get("fromZoneId", ""))
        to_zone = str(props.get("toZoneId", ""))
        trips = float(props.get("trips") or 0.0)
        if not from_zone or not to_zone or trips <= 0:
            continue
        total_trips += trips
        total_pairs += 1
        od_by_origin.setdefault(from_zone, []).append((to_zone, trips))

    for from_zone, destinations in od_by_origin.items():
        origin_node = origin_nodes.get(from_zone)
        if origin_node is None:
            logger.debug("No centroid node for origin zone %s — skipping", from_zone)
            for _, trips in destinations:
                pass  # already counted in total_trips
            continue

        _dist, prev = _dijkstra(adj, origin_node)

        for to_zone, trips in destinations:
            dest_node = dest_nodes.get(to_zone)
            if dest_node is None:
                logger.debug(
                    "No network attachment node for destination zone %s — skipping", to_zone
                )
                continue
            if dest_node not in prev:
                logger.debug(
                    "Zone %s -> %s: destination unreachable", from_zone, to_zone
                )
                continue

            path = _reconstruct_path(prev, dest_node)
            if len(path) < 2:
                continue

            # Walk edges along path, add flow to regular links
            for i in range(len(path) - 1):
                edge_key = (path[i], path[i + 1])
                lid = link_index.get(edge_key)
                if lid:
                    flow_delta[lid] = flow_delta.get(lid, 0.0) + trips

            assigned_trips += trips
            assigned_pairs += 1

    logger.info(
        "Assignment complete: %.0f / %.0f trips assigned (%d / %d pairs)",
        assigned_trips, total_trips, assigned_pairs, total_pairs,
    )

    # Build output FeatureCollection with updated flow values.
    # Flow is always reset to the freshly assigned delta — pre-existing flow
    # values are discarded so that every run is a clean reassignment from scratch.
    output_features: list[dict] = []
    for feat in network_features:
        props = dict(feat.get("properties") or {})
        link_id = str(props.get("linkId", ""))
        props["flow"] = flow_delta.get(link_id, 0.0)
        output_features.append({**feat, "properties": props})

    in_props = network_fc.get("properties") or {}
    out_props = dict(in_props)
    out_props["link_properties"] = list(ALL_OR_NOTHING_PROPERTIES)
    output_fc: dict = {
        "type": "FeatureCollection",
        "features": output_features,
        "properties": out_props,
    }
    stats: dict = {
        "totalTrips": total_trips,
        "assignedTrips": assigned_trips,
        "unassignedTrips": total_trips - assigned_trips,
        "links": len(network_features),
        "assignedPairs": assigned_pairs,
        "totalPairs": total_pairs,
    }
    return output_fc, stats
