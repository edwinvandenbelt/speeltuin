"""Tests for janitor_core and cleaner — including expression evaluation."""

from __future__ import annotations

import math
import pytest

from janitor.domain.cleaner import evaluate_expression, clean_features
from janitor.core.janitor_core import clean_geojson


# ---------------------------------------------------------------------------
# evaluate_expression
# ---------------------------------------------------------------------------

class TestEvaluateExpression:
    def test_simple_division(self):
        result = evaluate_expression("=flow/capacity", {"flow": 100.0, "capacity": 200.0})
        assert result == pytest.approx(0.5)

    def test_simple_multiplication(self):
        result = evaluate_expression("=speed * 3.6", {"speed": 10.0})
        assert result == pytest.approx(36.0)

    def test_addition_and_subtraction(self):
        result = evaluate_expression("=a + b - c", {"a": 10.0, "b": 5.0, "c": 3.0})
        assert result == pytest.approx(12.0)

    def test_power_operator(self):
        result = evaluate_expression("=x**2", {"x": 4.0})
        assert result == pytest.approx(16.0)

    def test_math_function_sqrt(self):
        result = evaluate_expression("=sqrt(flow)", {"flow": 9.0})
        assert result == pytest.approx(3.0)

    def test_math_function_log(self):
        result = evaluate_expression("=log(flow)", {"flow": math.e})
        assert result == pytest.approx(1.0)

    def test_builtin_round(self):
        result = evaluate_expression("=round(flow/capacity, 2)", {"flow": 100.0, "capacity": 300.0})
        assert result == pytest.approx(0.33)

    def test_builtin_min_clamp_lower(self):
        result = evaluate_expression("=max(flow/capacity, 0.1)", {"flow": 0.0, "capacity": 200.0})
        assert result == pytest.approx(0.1)

    def test_builtin_max_clamp_upper(self):
        result = evaluate_expression("=min(flow/capacity, 1.0)", {"flow": 300.0, "capacity": 200.0})
        assert result == pytest.approx(1.0)

    def test_combined_clamp_and_round(self):
        # Clamp to [0, 1] then round to 3 decimals
        result = evaluate_expression(
            "=round(min(max(flow/capacity, 0.0), 1.0), 3)",
            {"flow": 100.0, "capacity": 300.0},
        )
        assert result == pytest.approx(0.333)

    def test_literal_constant(self):
        result = evaluate_expression("=42.5", {})
        assert result == pytest.approx(42.5)

    def test_missing_property_returns_none(self):
        result = evaluate_expression("=flow/capacity", {"flow": 100.0})
        assert result is None

    def test_none_property_returns_none(self):
        result = evaluate_expression("=flow/capacity", {"flow": None, "capacity": 200.0})
        assert result is None

    def test_division_by_zero_returns_none(self):
        result = evaluate_expression("=flow/capacity", {"flow": 1.0, "capacity": 0.0})
        assert result is None

    def test_expression_without_equals_raises(self):
        with pytest.raises(ValueError, match="must start with '='"):
            evaluate_expression("flow/capacity", {"flow": 1.0, "capacity": 2.0})

    def test_empty_expression_returns_none(self):
        result = evaluate_expression("=", {})
        assert result is None

    def test_nan_result_returns_none(self):
        result = evaluate_expression("=sqrt(-1)", {})
        assert result is None

    def test_extra_whitespace(self):
        result = evaluate_expression("=  flow  /  capacity  ", {"flow": 50.0, "capacity": 100.0})
        assert result == pytest.approx(0.5)


# ---------------------------------------------------------------------------
# clean_features
# ---------------------------------------------------------------------------

def _make_feature(props: dict) -> dict:
    return {"type": "Feature", "geometry": None, "properties": props}


class TestCleanFeatures:
    def test_expression_basic(self):
        features = [_make_feature({"flow": 100.0, "capacity": 200.0})]
        schema = {"saturation": {"expression": "=flow/capacity"}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["saturation"] == pytest.approx(0.5)

    def test_expression_with_round(self):
        features = [_make_feature({"flow": 100.0, "capacity": 300.0})]
        schema = {"saturation": {"expression": "=round(flow/capacity, 2)"}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["saturation"] == pytest.approx(0.33)

    def test_expression_with_min_clamp(self):
        features = [_make_feature({"flow": 0.0, "capacity": 200.0})]
        schema = {"saturation": {"expression": "=max(flow/capacity, 0.1)"}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["saturation"] == pytest.approx(0.1)

    def test_expression_with_max_clamp(self):
        features = [_make_feature({"flow": 300.0, "capacity": 200.0})]
        schema = {"saturation": {"expression": "=min(flow/capacity, 1.0)"}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["saturation"] == pytest.approx(1.0)

    def test_expression_missing_property_gives_none(self):
        features = [_make_feature({"flow": 100.0})]
        schema = {"saturation": {"expression": "=flow/capacity"}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["saturation"] is None

    def test_expression_none_property_gives_none(self):
        features = [_make_feature({"flow": None, "capacity": 200.0})]
        schema = {"saturation": {"expression": "=flow/capacity"}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["saturation"] is None

    def test_expression_coexists_with_plain_field(self):
        features = [_make_feature({"flow": 80.0, "capacity": 200.0, "speed": 50.0})]
        schema = {
            "speed": None,
            "saturation": {"expression": "=round(flow/capacity, 2)"},
        }
        result = clean_features(features, schema)
        props = result[0]["properties"]
        assert props["speed"] == 50.0
        assert props["saturation"] == pytest.approx(0.4)
        assert set(props.keys()) == {"speed", "saturation"}

    def test_expression_multiple_features(self):
        features = [
            _make_feature({"flow": 50.0,  "capacity": 200.0}),
            _make_feature({"flow": 200.0, "capacity": 200.0}),
            _make_feature({"flow": 0.0,   "capacity": 200.0}),
        ]
        schema = {"saturation": {"expression": "=flow/capacity"}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["saturation"] == pytest.approx(0.25)
        assert result[1]["properties"]["saturation"] == pytest.approx(1.0)
        assert result[2]["properties"]["saturation"] == pytest.approx(0.0)

    def test_source_field_name_rename(self):
        features = [_make_feature({"oldName": 42.0})]
        schema = {"newName": {"source_field_name": "oldName"}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["newName"] == 42.0
        assert "oldName" not in result[0]["properties"]

    def test_source_field_name_absent_gives_none(self):
        features = [_make_feature({"other": 1.0})]
        schema = {"newName": {"source_field_name": "oldName"}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["newName"] is None

    def test_null_spec_keeps_value(self):
        features = [_make_feature({"speed": 80.0, "noise": "drop"})]
        schema = {"speed": None}
        result = clean_features(features, schema)
        assert result[0]["properties"] == {"speed": 80.0}

    def test_null_spec_missing_gives_none(self):
        features = [_make_feature({"noise": "drop"})]
        schema = {"speed": None}
        result = clean_features(features, schema)
        assert result[0]["properties"]["speed"] is None

    def test_default_value_empty_object(self):
        features = [_make_feature({"flow": 10.0}), _make_feature({"flow": 20.0})]
        schema = {"flow_terug": {"default_value": {}}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["flow_terug"] == {}
        assert result[1]["properties"]["flow_terug"] == {}

    def test_default_value_scalar(self):
        features = [_make_feature({"flow": 10.0})]
        schema = {"lanes": {"default_value": 1}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["lanes"] == 1

    def test_default_value_overrides_source_property(self):
        """default_value should ignore whatever is already on the feature."""
        features = [_make_feature({"flow_terug": {"existing": True}})]
        schema = {"flow_terug": {"default_value": {}}}
        result = clean_features(features, schema)
        assert result[0]["properties"]["flow_terug"] == {}

    def test_default_value_mixed_with_other_fields(self):
        features = [_make_feature({"flow": 50.0})]
        schema = {
            "flow": None,
            "lanes": {"default_value": 2},
            "flow_terug": {"default_value": {}},
        }
        result = clean_features(features, schema)
        props = result[0]["properties"]
        assert props["flow"] == 50.0
        assert props["lanes"] == 2
        assert props["flow_terug"] == {}

    def test_geometry_preserved(self):
        geom = {"type": "LineString", "coordinates": [[0, 0], [1, 1]]}
        features = [{"type": "Feature", "geometry": geom, "properties": {"x": 1.0}}]
        schema = {"x": None}
        result = clean_features(features, schema)
        assert result[0]["geometry"] == geom


# ---------------------------------------------------------------------------
# clean_geojson — end-to-end
# ---------------------------------------------------------------------------

class TestCleanGeoJson:
    def test_end_to_end_with_expression(self):
        fc = {
            "type": "FeatureCollection",
            "features": [
                _make_feature({"flow": 60.0, "capacity": 200.0, "noise": "drop me"}),
            ],
        }
        schema = {
            "saturation": {"expression": "=round(flow/capacity, 3)"},
        }
        cleaned, stats = clean_geojson(fc, schema)
        assert stats == {"total": 1, "cleaned": 1, "schema_fields": 1}
        feat = cleaned["features"][0]
        assert set(feat["properties"].keys()) == {"saturation"}
        assert feat["properties"]["saturation"] == pytest.approx(0.3)
        assert cleaned["properties"]["link_properties"] == ["saturation"]

    def test_empty_featurecollection(self):
        fc = {"type": "FeatureCollection", "features": []}
        schema = {"speed": None}
        cleaned, stats = clean_geojson(fc, schema)
        assert stats["total"] == 0
        assert cleaned["features"] == []
        assert "speed" in cleaned["properties"]["link_properties"]
