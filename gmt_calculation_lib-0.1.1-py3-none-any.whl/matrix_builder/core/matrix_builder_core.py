"""Pure-Python matrix_builder core — no I/O, no boto3, no external deps.

Builds a **complete** zone × zone OD route set by assigning unit production
(+1.0) to every zone.

Ratio-distribution semantics
-----------------------------
Because each zone receives production = 1.0, the ``trips`` value on every
output feature represents the *proportional share* of one unit of production
that flows from origin zone O to destination zone D:

    trips(O → D)  =  zone_attractions[D] / Σ zone_attractions[all reachable D′]

Summing ``trips`` over all destinations for a single origin always equals 1.0
(subject to routing coverage — unreachable pairs contribute 0).

Parallelism
-----------
Routing is **embarrassingly parallel** at the origin-zone level: each zone's
Dijkstra/Yen computations are fully independent.  ``build_matrix`` uses
``concurrent.futures.ProcessPoolExecutor`` with a per-worker initialiser that
loads the read-only graph and zone marginals *once per worker process*, so the
large adjacency dict is serialised at most ``workers`` times total rather than
once per zone.

Public API
----------
build_matrix(network_fc, feedlinks_fc, zones_fc, max_routes=3, workers=None)
    -> od_geojson dict
"""

from __future__ import annotations

import logging
import math
import os
from concurrent.futures import ProcessPoolExecutor
from typing import TYPE_CHECKING

from od_support_matrices_creator.core.od_support_matrices_creator_core import (
    build_graph,
    extract_zone_centroids,
)
from route_explorer.core.route_explorer_core import (
    _build_link_coord_index,
    _build_link_index,
    _build_od_geojson,
    _estimate_zone_marginals,
    _extract_node_coords,
    _yen_k_shortest,
)

if TYPE_CHECKING:
    from route_explorer.core.route_explorer_core import PairKey, RouteEntry

logger = logging.getLogger(__name__)

__all__ = ["build_matrix"]

# ---------------------------------------------------------------------------
# Worker-process shared state
# ---------------------------------------------------------------------------
# Each worker process sets this dict once via _init_worker().  Tasks then
# communicate only the origin zone_id (a small string) rather than the full
# graph, keeping inter-process data transfer minimal.

_worker_state: dict = {}


def _init_worker(
    adj: dict,
    zone_node_ids: dict,
    zone_ids: list[str],
    zone_attractions: dict[str, float],
    max_routes: int,
) -> None:
    """Initialiser executed once per worker process."""
    _worker_state["adj"] = adj
    _worker_state["zone_node_ids"] = zone_node_ids
    _worker_state["zone_ids"] = zone_ids
    _worker_state["zone_attractions"] = zone_attractions
    _worker_state["max_routes"] = max_routes


def _route_one_origin(
    adj_zone_id: str,
) -> list[tuple[tuple, list, float]]:
    """Worker task: route *adj_zone_id* to every other zone.

    Reads shared state set by ``_init_worker`` and returns a list of
    ``(pair_key, routes, trips)`` tuples — one per routable destination zone.
    The main process merges these into the global ``od_trips`` /
    ``routes_per_pair`` dicts.

    Parameters
    ----------
    adj_zone_id:
        The origin zone ID to route from.

    Returns
    -------
    list of ``(pair_key, routes, trips)`` where

    - ``pair_key`` is ``(from_id, to_id, "zone", "zone")``
    - ``routes`` is a ``list[RouteEntry]`` from Yen's algorithm
    - ``trips`` is the proportional share (unit production distributed by
      destination attraction weight)
    """
    adj = _worker_state["adj"]
    zone_node_ids = _worker_state["zone_node_ids"]
    zone_ids = _worker_state["zone_ids"]
    zone_attractions = _worker_state["zone_attractions"]
    max_routes = _worker_state["max_routes"]

    if adj_zone_id not in zone_node_ids:
        return []

    vnode = zone_node_ids[adj_zone_id]
    target_zones = [z for z in zone_ids if z != adj_zone_id and z in zone_node_ids]

    prod_routes_by_zone: dict[str, list] = {}
    for target_zone_id in target_zones:
        tvnode = zone_node_ids[target_zone_id]
        routes = _yen_k_shortest(adj, vnode, tvnode, max_routes)
        if routes:
            prod_routes_by_zone[target_zone_id] = routes

    total_attr_weight = sum(zone_attractions.get(z, 0.0) for z in prod_routes_by_zone)

    results: list[tuple] = []
    for target_zone_id, routes in prod_routes_by_zone.items():
        raw = zone_attractions.get(target_zone_id, 0.0)
        proportion = (raw / total_attr_weight) if total_attr_weight > 0.0 else 0.0
        pair_key = (adj_zone_id, target_zone_id, "zone", "zone")
        results.append((pair_key, routes, proportion))  # trips = 1.0 × proportion

    return results


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_matrix(
    network_fc: dict,
    feedlinks_fc: dict,
    zones_fc: dict,
    max_routes: int = 3,
    workers: int | None = None,
) -> dict:
    """Build a complete zone × zone OD matrix with unit productions.

    For every zone present in *zones_fc*, a production of 1.0 is assigned and
    routes to all other zones are computed.  Trip weights are proportional to
    destination zone attractions derived from network ``flow`` values.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection.  Must carry ``fromNode``,
        ``toNode``, ``speed``, ``length``, ``capacity``, and ``flow`` per link.
    feedlinks_fc:
        Feedlinks GeoJSON (output of ``feedlink_creator`` /
        ``network_zone_joiner``).
    zones_fc:
        Zones GeoJSON.  Must contain one feature per zone with a ``zoneId``
        property and Polygon / MultiPolygon geometry.
    max_routes:
        Maximum number of k-shortest alternative routes per OD pair.
        Defaults to 3.
    workers:
        Number of parallel worker processes.  ``None`` (default) uses
        ``os.cpu_count()``.  Pass ``1`` to run sequentially (useful for
        debugging or when spawning overhead is not worth it for small networks).

    Returns
    -------
    dict
        GeoJSON FeatureCollection — one Feature per routable (zone, zone)
        pair.  Properties: ``fromId``, ``toId``, ``fromType`` (``"zone"``),
        ``toType`` (``"zone"``), ``trips``, ``routes``.
    """
    # ------------------------------------------------------------------
    # 1. Resolve worker count
    # ------------------------------------------------------------------
    n_workers: int = workers if workers is not None else (os.cpu_count() or 1)
    n_workers = max(1, n_workers)

    # ------------------------------------------------------------------
    # 2. Build graph + zone marginals  (done once, on the main process)
    # ------------------------------------------------------------------
    adj, zone_node_ids, zone_centroids_graph = build_graph(network_fc, feedlinks_fc)
    zone_centroids: dict[str, tuple[float, float]] = dict(zone_centroids_graph)
    zone_centroids.update(extract_zone_centroids(zones_fc))

    zone_features: list[dict] = zones_fc.get("features") or []
    zone_ids: list[str] = [
        str(feat["properties"]["zoneId"])
        for feat in zone_features
        if (feat.get("properties") or {}).get("zoneId")
    ]

    # Only route zones that have feedlink virtual nodes.
    routable_zone_ids = [z for z in zone_ids if z in zone_node_ids]

    logger.info(
        "build_matrix: %d zones total, %d routable, %d workers, max_routes=%d",
        len(zone_ids),
        len(routable_zone_ids),
        n_workers,
        max_routes,
    )

    if not routable_zone_ids:
        return {"type": "FeatureCollection", "features": [], "properties": {}}

    zone_productions, zone_attractions = _estimate_zone_marginals(
        network_fc, feedlinks_fc, zone_ids
    )
    node_coords = _extract_node_coords(network_fc)
    link_index = _build_link_index(network_fc)
    link_coord_index = _build_link_coord_index(network_fc)

    # ------------------------------------------------------------------
    # 3. Route all origin zones in parallel
    # ------------------------------------------------------------------
    od_trips: dict[tuple, float] = {}
    routes_per_pair: dict[tuple, list] = {}

    if n_workers == 1 or len(routable_zone_ids) <= 1:
        # Sequential path — avoids process-spawn overhead for small inputs.
        _init_worker(adj, zone_node_ids, zone_ids, zone_attractions, max_routes)
        for zone_id in routable_zone_ids:
            for pair_key, routes, trips in _route_one_origin(zone_id):
                routes_per_pair[pair_key] = routes
                od_trips[pair_key] = trips
    else:
        with ProcessPoolExecutor(
            max_workers=n_workers,
            initializer=_init_worker,
            initargs=(adj, zone_node_ids, zone_ids, zone_attractions, max_routes),
        ) as executor:
            for zone_results in executor.map(_route_one_origin, routable_zone_ids):
                for pair_key, routes, trips in zone_results:
                    routes_per_pair[pair_key] = routes
                    od_trips[pair_key] = trips

    # ------------------------------------------------------------------
    # 4. Serialise
    # ------------------------------------------------------------------
    od_geojson = _build_od_geojson(
        od_trips, routes_per_pair, node_coords, zone_centroids, link_index,
        link_coord_index=link_coord_index,
    )

    logger.info("build_matrix: %d OD pairs in output", len(routes_per_pair))
    return od_geojson
