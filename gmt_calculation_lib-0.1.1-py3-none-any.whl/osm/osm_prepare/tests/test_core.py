"""Tests for osm_prepare_core.

All external calls (Overpass, Eurostat, GISCO, matrix_builder) are mocked.
Only the orchestration logic is verified.
"""

from __future__ import annotations

import copy
import json
import uuid
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest


# ---------------------------------------------------------------------------
# Minimal stub FeatureCollections returned by mocked sub-modules
# ---------------------------------------------------------------------------

_BUILDINGS_FC = {
    "type": "FeatureCollection",
    "features": [{"type": "Feature", "geometry": None, "properties": {"buildingId": "1"}}],
}
_RAW_ZONES_FC = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [[[6.1, 52.0], [6.2, 52.0], [6.2, 52.1], [6.1, 52.1], [6.1, 52.0]]],
            },
            "properties": {"zoneId": "z_0", "centroidLon": 6.15, "centroidLat": 52.05},
        }
    ],
}
_ZONES_FC = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [[[6.1, 52.0], [6.2, 52.0], [6.2, 52.1], [6.1, 52.1], [6.1, 52.0]]],
            },
            "properties": {
                "zoneId": "z_0",
                "centroidLon": 6.15,
                "centroidLat": 52.05,
                "production": 1000.0,
                "attraction": 50.0,
            },
        }
    ],
}
_RAW_NET_FC = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[6.1, 52.0], [6.2, 52.1]]},
            "properties": {
                "fromNode": "1",
                "toNode": "2",
                "rijrichting_heen": True,
                "rijrichting_terug": False,
                "cap_heen": 1500.0,
                "max_snelheid_heen": 50.0,
                "length": 1200.0,
            },
        }
    ],
}
_SIMPLIFIED_FC = {"type": "FeatureCollection", "features": _RAW_NET_FC["features"]}
_CLEANED_FC = {"type": "FeatureCollection", "features": _RAW_NET_FC["features"]}
_DIRECTED_FEAT = [
    {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[6.1, 52.0], [6.2, 52.1]]},
        "properties": {
            "fromNode": "1",
            "toNode": "2",
            "speed": 50.0,
            "capacity": 1500.0,
            "flow": 0.0,
            "length": 1200.0,
            "linkId": "100",
            "mode": "CAR",
        },
    }
]
_NETWORK_FC = {
    "type": "FeatureCollection",
    "features": _DIRECTED_FEAT,
    "properties": {"bbox": [6.1, 52.0, 6.2, 52.1], "area_id": "test-area", "modes": ["CAR"]},
}
_FEEDLINKS_FC = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[6.15, 52.05], [6.1, 52.0]]},
            "properties": {
                "zoneId": "z_0",
                "fromNode": "ZONE_z_0",
                "toNode": "1",
                "length": 800.0,
                "capacity": 9999.0,
                "flow": 0.0,
            },
        }
    ],
}
_ROUTES_FC = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": None,
            "properties": {"fromZone": "z_0", "toZone": "z_0", "trips": 1.0},
        }
    ],
}


def _stub_parquet(fc: dict) -> bytes:
    """Return a minimal valid parquet-like bytes stand-in (just JSON for mocking)."""
    return json.dumps(fc).encode()


# ---------------------------------------------------------------------------
# Patch targets
# ---------------------------------------------------------------------------

_PATCH = {
    "build_buildings": "osm.osm_prepare.core.osm_prepare_core._run_track_a",  # noqa: E501
    "build_raw_network": "osm.osm_prepare.core.osm_prepare_core._run_track_b_partial",  # noqa: E501
    "build_buildings_direct": "osm.osm_building_fetcher.core.osm_building_fetcher_core.build_buildings",
    "create_zones": "osm.building_zone_creator.core.building_zone_creator_core.create_zones",
    "estimate_population": "osm.zone_population_estimator.core.zone_population_estimator_core.estimate_zone_population",
    "build_raw_network_direct": "osm.osm_network_fetcher.core.osm_network_fetcher_core.build_raw_network",
    "simplify_network": "network_simplifier.core.network_simplifier_core.simplify_network",
    "clean_network": "network_cleaner.core.network_cleaner_core.clean_network",
    "post_process": "bidirectional_splitter.core.bidirectional_splitter_core.post_process_features",
    "find_parallel": "parallel_link_finder.core.parallel_link_finder_core.find_parallel_links",
    "create_feedlinks": "osm.osm_feedlink_creator.core.osm_feedlink_creator_core.create_feedlinks",
    "create_external_zones": "osm.external_zone_creator.core.external_zone_creator_core.create_external_zones",
    "estimate_flow_from_routes": "osm.osm_flow_estimator.core.osm_flow_estimator_core.estimate_flow_from_routes",
    "build_matrix": "matrix_builder.core.matrix_builder_core.build_matrix",
    "to_geoparquet": "osm.osm_prepare.core.osm_prepare_core.to_geoparquet",
}


def _all_mocks(tmp_path: Path) -> dict:
    """Return a dict of mock objects for a full successful pipeline run."""
    m: dict = {}
    m["build_buildings"] = MagicMock(return_value=(_BUILDINGS_FC, {"buildings": 42, "streets": 10}))
    m["create_zones"] = MagicMock(return_value=(_RAW_ZONES_FC, {"zones": 1}))
    m["estimate_pop"] = MagicMock(
        return_value=(_ZONES_FC, {"totalPopulation": 5000, "nutsCode": "NL212"})
    )
    m["build_raw_net"] = MagicMock(return_value=_RAW_NET_FC)
    m["simplify"] = MagicMock(return_value=(_SIMPLIFIED_FC, {"final_links": 1, "removed_nodes": 0}))
    m["clean"] = MagicMock(return_value=(_CLEANED_FC, {"kept": 1, "removed": 0}))
    m["post_process"] = MagicMock(return_value=_DIRECTED_FEAT)
    m["find_parallel"] = MagicMock(
        return_value=(copy.deepcopy(_NETWORK_FC), {"features_enriched": 1, "features_skipped": 0})
    )
    m["create_feedlinks"] = MagicMock(
        return_value=(_FEEDLINKS_FC, {"total": 2, "zonesMatched": 1, "zonesFallback": 0})
    )
    m["create_external_zones"] = MagicMock(
        return_value=(
            _ZONES_FC,
            _FEEDLINKS_FC,
            {
                "externalZones": 2,
                "externalFeedlinks": 4,
                "totalCutLinks": 2,
                "totalExternalTrips": 500.0,
            },
        )
    )
    m["estimate_flow_from_routes"] = MagicMock(
        side_effect=lambda network_fc, routes_fc, **kw: (
            copy.deepcopy(network_fc),
            {"links_total": 1, "links_with_flow": 1, "total_trips_assigned": 1.0},
        )
    )
    m["build_matrix"] = MagicMock(return_value=_ROUTES_FC)
    m["to_geoparquet"] = MagicMock(return_value=b"parquet_bytes")
    return m


def _run_with_all_mocks(tmp_path: Path, **kwargs):
    """Run run_pipeline with all sub-module calls mocked out."""
    from osm.osm_prepare.core.osm_prepare_core import run_pipeline  # noqa: PLC0415

    m = _all_mocks(tmp_path)
    with (
        patch(_PATCH["build_buildings_direct"], m["build_buildings"]),
        patch(_PATCH["create_zones"], m["create_zones"]),
        patch(_PATCH["estimate_population"], m["estimate_pop"]),
        patch(_PATCH["build_raw_network_direct"], m["build_raw_net"]),
        patch(_PATCH["simplify_network"], m["simplify"]),
        patch(_PATCH["clean_network"], m["clean"]),
        patch(_PATCH["post_process"], m["post_process"]),
        patch(_PATCH["find_parallel"], m["find_parallel"]),
        patch(_PATCH["create_feedlinks"], m["create_feedlinks"]),
        patch(_PATCH["create_external_zones"], m["create_external_zones"]),
        patch(_PATCH["estimate_flow_from_routes"], m["estimate_flow_from_routes"]),
        patch(_PATCH["build_matrix"], m["build_matrix"]),
        patch(_PATCH["to_geoparquet"], m["to_geoparquet"]),
    ):
        result = run_pipeline(6.1, 52.0, 6.2, 52.1, tmp_path, **kwargs)
    return result, m


# ===========================================================================
# TestDiscoverOrCreateAreaId
# ===========================================================================


class TestDiscoverOrCreateAreaId:
    def test_returns_explicit_area_id_when_given(self, tmp_path: Path) -> None:
        from osm.osm_prepare.core.osm_prepare_core import _discover_or_create_area_id  # noqa: PLC0415

        result = _discover_or_create_area_id(tmp_path, area_id="my-fixed-id")
        assert result == "my-fixed-id"

    def test_discovers_uuid_from_existing_network_parquet(self, tmp_path: Path) -> None:
        from osm.osm_prepare.core.osm_prepare_core import _discover_or_create_area_id  # noqa: PLC0415

        expected = "abc123"
        (tmp_path / f"{expected}-NETWORK-CAR.parquet").touch()
        result = _discover_or_create_area_id(tmp_path)
        assert result == expected

    def test_discovers_uuid_from_existing_routes_parquet(self, tmp_path: Path) -> None:
        from osm.osm_prepare.core.osm_prepare_core import _discover_or_create_area_id  # noqa: PLC0415

        expected = "deadbeef"
        (tmp_path / f"{expected}-ROUTES-CAR.parquet").touch()
        result = _discover_or_create_area_id(tmp_path)
        assert result == expected

    def test_discovers_uuid_from_zone_parquet(self, tmp_path: Path) -> None:
        from osm.osm_prepare.core.osm_prepare_core import _discover_or_create_area_id  # noqa: PLC0415

        expected = "zonetest"
        (tmp_path / f"{expected}-ZONE-CAR.parquet").touch()
        result = _discover_or_create_area_id(tmp_path)
        assert result == expected

    def test_generates_uuid4_when_dir_is_empty(self, tmp_path: Path) -> None:
        from osm.osm_prepare.core.osm_prepare_core import _discover_or_create_area_id  # noqa: PLC0415

        result = _discover_or_create_area_id(tmp_path)
        # Should be parseable as a UUID
        parsed = uuid.UUID(result)
        assert str(parsed) == result

    def test_explicit_overrides_existing_file(self, tmp_path: Path) -> None:
        from osm.osm_prepare.core.osm_prepare_core import _discover_or_create_area_id  # noqa: PLC0415

        (tmp_path / "other-uuid-NETWORK-CAR.parquet").touch()
        result = _discover_or_create_area_id(tmp_path, area_id="forced-id")
        assert result == "forced-id"


# ===========================================================================
# TestRunPipeline — orchestration
# ===========================================================================


class TestRunPipeline:
    def test_returns_area_id_string(self, tmp_path: Path) -> None:
        result, _ = _run_with_all_mocks(tmp_path, area_id="test-area")
        assert result == "test-area"

    def test_returns_generated_uuid_when_no_area_id_given(self, tmp_path: Path) -> None:
        result, _ = _run_with_all_mocks(tmp_path)
        uuid.UUID(result)  # must be a valid UUID

    def test_writes_four_output_files(self, tmp_path: Path) -> None:
        _run_with_all_mocks(tmp_path, area_id="myarea")
        assert (tmp_path / "myarea-NETWORK-CAR.parquet").exists()
        assert (tmp_path / "myarea-FEEDLINK-CAR.parquet").exists()
        assert (tmp_path / "myarea-ZONE-CAR.parquet").exists()
        assert (tmp_path / "myarea-ROUTES-CAR.parquet").exists()

    def test_to_geoparquet_called_four_times(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        assert m["to_geoparquet"].call_count == 4

    def test_early_exit_when_all_outputs_exist_and_no_refresh(self, tmp_path: Path) -> None:
        area = "existing"
        for suffix in ["-NETWORK-CAR", "-FEEDLINK-CAR", "-ZONE-CAR", "-ROUTES-CAR"]:
            (tmp_path / f"{area}{suffix}.parquet").write_bytes(b"dummy")

        _, m = _run_with_all_mocks(tmp_path, area_id=area, refresh=False)
        # None of the pipeline steps should have been called.
        m["build_buildings"].assert_not_called()
        m["build_raw_net"].assert_not_called()
        m["build_matrix"].assert_not_called()

    def test_refresh_forces_rerun_when_outputs_exist(self, tmp_path: Path) -> None:
        area = "existing"
        for suffix in ["-NETWORK-CAR", "-FEEDLINK-CAR", "-ZONE-CAR", "-ROUTES-CAR"]:
            (tmp_path / f"{area}{suffix}.parquet").write_bytes(b"dummy")

        _, m = _run_with_all_mocks(tmp_path, area_id=area, refresh=True)
        m["build_buildings"].assert_called_once()
        assert m["build_matrix"].call_count == 2  # D1 (empty) + D2 (with flows)

    def test_partial_outputs_do_not_trigger_early_exit(self, tmp_path: Path) -> None:
        area = "partial"
        # Only network exists, others missing.
        (tmp_path / f"{area}-NETWORK-CAR.parquet").write_bytes(b"dummy")

        _, m = _run_with_all_mocks(tmp_path, area_id=area, refresh=False)
        m["build_buildings"].assert_called_once()

    # ------------------------------------------------------------------
    # Track A — zone steps
    # ------------------------------------------------------------------

    def test_building_fetcher_called_with_bbox(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, kwargs = m["build_buildings"].call_args
        assert args[0] == [6.1, 52.0, 6.2, 52.1]

    def test_building_fetcher_receives_overpass_url(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(
            tmp_path, area_id="a", overpass_url="https://custom-overpass.example.com/api"
        )
        _, kwargs = m["build_buildings"].call_args
        assert kwargs["overpass_url"] == "https://custom-overpass.example.com/api"

    def test_create_zones_called_with_buildings_and_bbox(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, kwargs = m["create_zones"].call_args
        assert args[0] is _BUILDINGS_FC
        assert args[1] == [6.1, 52.0, 6.2, 52.1]

    def test_create_zones_receives_area_id(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="myid")
        _, kwargs = m["create_zones"].call_args
        assert kwargs.get("area_id") == "myid"

    def test_create_zones_receives_target_footprint(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a", target_footprint_m2=8000.0)
        _, kwargs = m["create_zones"].call_args
        assert kwargs.get("target_footprint_m2") == 8000.0

    def test_create_zones_receives_none_target_footprint_by_default(self, tmp_path: Path) -> None:
        # When no target_footprint_m2 is given, None must be forwarded so that
        # building_zone_creator can auto-compute ~100 zones.
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        _, kwargs = m["create_zones"].call_args
        assert kwargs.get("target_footprint_m2") is None

    def test_zone_population_estimator_called_with_zones_and_bbox(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, _ = m["estimate_pop"].call_args
        assert args[0] is _RAW_ZONES_FC
        assert args[1] == [6.1, 52.0, 6.2, 52.1]

    # ------------------------------------------------------------------
    # Track B — network steps
    # ------------------------------------------------------------------

    def test_network_fetcher_called_with_car_mode(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, kwargs = m["build_raw_net"].call_args
        assert args[0] == [6.1, 52.0, 6.2, 52.1]
        assert kwargs.get("modes") == ["CAR"]

    def test_network_fetcher_receives_overpass_url(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(
            tmp_path, area_id="a", overpass_url="https://my-overpass.example.com"
        )
        _, kwargs = m["build_raw_net"].call_args
        assert kwargs["overpass_url"] == "https://my-overpass.example.com"

    def test_simplify_called_with_raw_network(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, _ = m["simplify"].call_args
        assert args[0] is _RAW_NET_FC

    def test_cleaner_called_with_simplified_network(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, _ = m["clean"].call_args
        assert args[0] is _SIMPLIFIED_FC

    def test_splitter_called_with_cleaned_features(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, _ = m["post_process"].call_args
        assert args[0] == (_CLEANED_FC.get("features") or [])

    def test_parallel_link_finder_receives_directed_fc(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, _ = m["find_parallel"].call_args
        # First argument is the directed FC — it must contain the directed features
        directed_fc_arg = args[0]
        assert directed_fc_arg["type"] == "FeatureCollection"
        assert directed_fc_arg["features"] is _DIRECTED_FEAT

    # ------------------------------------------------------------------
    # Post-parallel steps
    # ------------------------------------------------------------------

    def test_feedlink_creator_called_with_network_and_zones(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, _ = m["create_feedlinks"].call_args
        # First arg = enriched network (from parallel_link_finder output)
        assert args[0]["type"] == "FeatureCollection"
        assert args[0]["features"] == _NETWORK_FC["features"]
        # Second arg = enriched zones (from zone_population_estimator output)
        assert args[1] is _ZONES_FC

    def test_external_zone_creator_called_with_network_zones_feedlinks_bbox(
        self, tmp_path: Path
    ) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        args, kwargs = m["create_external_zones"].call_args
        assert args[0]["type"] == "FeatureCollection"  # network_fc
        assert args[1] is _ZONES_FC  # zones_fc (from zone_population_estimator)
        assert args[2] is _FEEDLINKS_FC  # feedlinks_fc (from create_feedlinks)
        assert args[3] == [6.1, 52.0, 6.2, 52.1]  # bbox

    def test_external_zone_creator_receives_external_share(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a", external_share=0.25)
        _, kwargs = m["create_external_zones"].call_args
        assert kwargs.get("external_share") == 0.25

    def test_matrix_builder_called_twice(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        assert m["build_matrix"].call_count == 2

    def test_matrix_builder_d1_called_before_estimate_flow(self, tmp_path: Path) -> None:
        """D1 routes_fc is the input for estimate_flow_from_routes."""
        _, m = _run_with_all_mocks(tmp_path, area_id="a")
        # estimate_flow_from_routes must have been called with the D1 routes output
        args, _ = m["estimate_flow_from_routes"].call_args
        # Second argument is routes_fc_1 (the _ROUTES_FC returned by D1)
        assert args[1] is _ROUTES_FC

    def test_estimate_flow_from_routes_receives_peak_hour_fraction(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a", peak_hour_fraction=0.15)
        _, kwargs = m["estimate_flow_from_routes"].call_args
        assert kwargs.get("peak_hour_fraction") == 0.15

    def test_matrix_builder_d2_receives_max_routes(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="a", max_routes=5)
        # Both calls should have max_routes
        for c in m["build_matrix"].call_args_list:
            assert c[1].get("max_routes") == 5

    # ------------------------------------------------------------------
    # Debug snapshots
    # ------------------------------------------------------------------

    def test_debug_snapshots_written_when_debug_true(self, tmp_path: Path) -> None:
        _run_with_all_mocks(tmp_path, area_id="dbg", debug=True)
        geojson_files = list(tmp_path.glob("STEP_*.geojson"))
        assert len(geojson_files) >= 2  # At minimum ZONES and NETWORK snapshots

    def test_no_snapshots_when_debug_false(self, tmp_path: Path) -> None:
        _run_with_all_mocks(tmp_path, area_id="nd", debug=False)
        assert list(tmp_path.glob("STEP_*.geojson")) == []

    def test_snapshot_files_contain_valid_geojson(self, tmp_path: Path) -> None:
        _run_with_all_mocks(tmp_path, area_id="dbg", debug=True)
        for snap in tmp_path.glob("STEP_*.geojson"):
            data = json.loads(snap.read_text(encoding="utf-8"))
            assert data["type"] == "FeatureCollection"

    # ------------------------------------------------------------------
    # Output directory creation
    # ------------------------------------------------------------------

    def test_creates_output_dir_if_missing(self, tmp_path: Path) -> None:
        new_dir = tmp_path / "deep" / "nested" / "dir"
        assert not new_dir.exists()
        _run_with_all_mocks(new_dir, area_id="x")
        assert new_dir.exists()


# ===========================================================================
# TestOutputMetadata — FC properties written to parquet
# ===========================================================================


class TestOutputMetadata:
    """Verify that FeatureCollection-level metadata is injected on all four outputs."""

    def _get_fc_args(self, m: dict) -> dict:
        """Return the FCs passed to to_geoparquet as a dict keyed by product."""
        calls = m["to_geoparquet"].call_args_list
        # Order: network, feedlinks, zones, routes
        return {
            "network": calls[0][0][0],
            "feedlinks": calls[1][0][0],
            "zones": calls[2][0][0],
            "routes": calls[3][0][0],
        }

    def test_network_fc_has_area_id(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="test-area")
        fc = self._get_fc_args(m)["network"]
        assert fc["properties"]["area_id"] == "test-area"

    def test_network_fc_has_fields(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        fc = self._get_fc_args(m)["network"]
        assert "fields" in fc["properties"]
        assert isinstance(fc["properties"]["fields"], list)
        assert len(fc["properties"]["fields"]) > 0

    def test_network_fc_has_modes_and_mode_label(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        props = self._get_fc_args(m)["network"]["properties"]
        assert props["modes"] == ["CAR"]
        assert props["modeLabel"] == "CAR"

    def test_network_fc_has_name_when_provided(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x", name="Deventer")
        props = self._get_fc_args(m)["network"]["properties"]
        assert props["name"] == "Deventer"

    def test_network_fc_has_name_none_when_omitted(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        props = self._get_fc_args(m)["network"]["properties"]
        assert "name" in props
        assert props["name"] is None

    def test_all_outputs_have_bbox(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        fc_args = self._get_fc_args(m)
        for key in ("network", "feedlinks", "zones", "routes"):
            assert fc_args[key]["properties"]["bbox"] == [6.1, 52.0, 6.2, 52.1], (
                f"bbox missing on {key}"
            )

    def test_all_outputs_have_region_none(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        fc_args = self._get_fc_args(m)
        for key in ("network", "feedlinks", "zones", "routes"):
            props = fc_args[key]["properties"]
            assert "region" in props, f"region key missing on {key}"
            assert props["region"] is None, f"region should be None on {key}"

    def test_all_outputs_have_name(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x", name="Zwolle")
        fc_args = self._get_fc_args(m)
        for key in ("network", "feedlinks", "zones", "routes"):
            assert fc_args[key]["properties"]["name"] == "Zwolle", f"name missing on {key}"

    def test_feedlinks_fc_has_area_id(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="test-area")
        props = self._get_fc_args(m)["feedlinks"]["properties"]
        assert props["area_id"] == "test-area"

    def test_feedlinks_fc_has_modes(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        props = self._get_fc_args(m)["feedlinks"]["properties"]
        assert props["modes"] == ["CAR"]

    def test_feedlinks_fc_has_fields(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        props = self._get_fc_args(m)["feedlinks"]["properties"]
        assert "fields" in props
        assert isinstance(props["fields"], list)

    def test_feedlinks_fc_has_name_when_provided(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x", name="Arnhem")
        props = self._get_fc_args(m)["feedlinks"]["properties"]
        assert props["name"] == "Arnhem"

    def test_zones_fc_has_area_id(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="test-area")
        props = self._get_fc_args(m)["zones"]["properties"]
        assert props["area_id"] == "test-area"

    def test_zones_fc_has_modes(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        props = self._get_fc_args(m)["zones"]["properties"]
        assert props["modes"] == ["CAR"]

    def test_zones_fc_has_fields(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        props = self._get_fc_args(m)["zones"]["properties"]
        assert "fields" in props
        assert "zoneId" in props["fields"]

    def test_zones_fc_has_name_when_provided(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x", name="Utrecht")
        props = self._get_fc_args(m)["zones"]["properties"]
        assert props["name"] == "Utrecht"

    def test_routes_fc_has_area_id(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="test-area")
        props = self._get_fc_args(m)["routes"]["properties"]
        assert props["area_id"] == "test-area"

    def test_routes_fc_has_modes(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x")
        props = self._get_fc_args(m)["routes"]["properties"]
        assert props["modes"] == ["CAR"]

    def test_routes_fc_has_name_when_provided(self, tmp_path: Path) -> None:
        _, m = _run_with_all_mocks(tmp_path, area_id="x", name="Rotterdam")
        props = self._get_fc_args(m)["routes"]["properties"]
        assert props["name"] == "Rotterdam"
