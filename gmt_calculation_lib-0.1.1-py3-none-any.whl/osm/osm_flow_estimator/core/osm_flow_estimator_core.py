"""osm_flow_estimator_core.py — synthetic 24-hour traffic flow estimation.

Three public functions
---------------------
estimate_flow_undirected(network_fc, zones_fc, **kwargs) -> tuple[dict, dict]
    Operates on a PRE-SPLIT (undirected) network FeatureCollection.
    Writes daily flow values into flow_heen / flow_terug dicts so that the
    downstream bidirectional_splitter sees non-zero flows and keeps all
    drivable links.  Also writes flow_dp_heen / flow_dp_terug.

estimate_flow(network_fc, zones_fc, **kwargs) -> tuple[dict, dict]
    Operates on a DIRECTED (post-split) network FeatureCollection.
    Writes flow, flow24hrs, flowsPerMotive, flowsPerDaypart, remainingCap
    onto each directed feature.  Kept for standalone use (runner, notebook).

estimate_flow_from_routes(network_fc, routes_fc, *, peak_hour_fraction) -> tuple[dict, dict]
    Operates on a DIRECTED network and a routes FeatureCollection produced by
    matrix_builder / route_explorer.
    Performs an all-or-nothing traffic assignment: for every route (identified
    by its ``linkPath``), the route's ``trips`` are summed onto each link in
    the path.  The resulting 24-hour flow is written to ``flow``, ``flow24hrs``,
    ``flowsPerMotive``, ``flowsPerDaypart``, and ``remainingCap``.

Default parameters
------------------
trip_rate_per_person : float = 3.5
local_radius_m       : float = 75.0
collector_radius_m   : float = 200.0
arterial_radius_m    : float = 500.0
highway_radius_m     : float = 1500.0
absorption_factor    : float = 0.6
peak_hour_fraction   : float = 0.10  (fraction of 24hr flow in the peak hour)
"""

from __future__ import annotations

import logging

from osm.osm_flow_estimator.domain.flow_assigner import (
    DEFAULT_ABSORPTION_FACTOR,
    assign_flows,
)
from osm.osm_flow_estimator.domain.temporal_splitter import split_flow
from osm.osm_flow_estimator.domain.trip_generator import DEFAULT_TRIP_RATE_PER_PERSON

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Defaults (re-exported so callers can reference them)
# ---------------------------------------------------------------------------

DEFAULT_LOCAL_RADIUS_M: float = 75.0
DEFAULT_COLLECTOR_RADIUS_M: float = 200.0
DEFAULT_ARTERIAL_RADIUS_M: float = 500.0
DEFAULT_HIGHWAY_RADIUS_M: float = 1500.0

RESIDENTIAL_FRACTION = 0.5  # fixed approximation used for temporal split


# ---------------------------------------------------------------------------
# Shared keyword arguments helper
# ---------------------------------------------------------------------------


def _flow_kwargs(
    trip_rate_per_person: float,
    local_radius_m: float,
    collector_radius_m: float,
    arterial_radius_m: float,
    highway_radius_m: float,
    absorption_factor: float,
) -> dict:
    return dict(
        trip_rate_per_person=trip_rate_per_person,
        local_radius_m=local_radius_m,
        collector_radius_m=collector_radius_m,
        arterial_radius_m=arterial_radius_m,
        highway_radius_m=highway_radius_m,
        absorption_factor=absorption_factor,
    )


# ---------------------------------------------------------------------------
# estimate_flow_undirected — pre-split (undirected) network
# ---------------------------------------------------------------------------


def estimate_flow_undirected(
    network_fc: dict,
    zones_fc: dict,
    *,
    trip_rate_per_person: float = DEFAULT_TRIP_RATE_PER_PERSON,
    local_radius_m: float = DEFAULT_LOCAL_RADIUS_M,
    collector_radius_m: float = DEFAULT_COLLECTOR_RADIUS_M,
    arterial_radius_m: float = DEFAULT_ARTERIAL_RADIUS_M,
    highway_radius_m: float = DEFAULT_HIGHWAY_RADIUS_M,
    absorption_factor: float = DEFAULT_ABSORPTION_FACTOR,
) -> tuple[dict, dict]:
    """Estimate and write synthetic flow onto an undirected (pre-split) network.

    Parameters
    ----------
    network_fc:
        Undirected network FeatureCollection (output of network_cleaner).
        Expected property keys per feature: ``linkId``, ``cap_heen``,
        ``max_snelheid_heen``, ``length``, ``highway``, ``rijrichting_heen``,
        ``rijrichting_terug``.
    zones_fc:
        Zone FeatureCollection with ``production`` and ``attraction`` fields.

    Returns
    -------
    (updated_network_fc, stats)
        Flow fields ``flow_heen``, ``flow_terug``, ``flow_dp_heen``,
        ``flow_dp_terug`` are written onto each feature so that the
        bidirectional_splitter can use them to decide which directions to keep.
    """
    network_features: list[dict] = network_fc.get("features") or []
    zone_features: list[dict] = zones_fc.get("features") or []

    logger.info(
        "estimate_flow_undirected: %d links, %d zones",
        len(network_features),
        len(zone_features),
    )

    flows, assign_stats = assign_flows(
        network_features,
        zone_features,
        **_flow_kwargs(
            trip_rate_per_person,
            local_radius_m,
            collector_radius_m,
            arterial_radius_m,
            highway_radius_m,
            absorption_factor,
        ),
    )

    updated_features: list[dict] = []
    for feat in network_features:
        props = feat.get("properties") or {}
        lid = str(props.get("linkId", ""))
        daily = flows.get(lid, 1.0)

        rr_heen = bool(props.get("rijrichting_heen", True))
        rr_terug = bool(props.get("rijrichting_terug", True))

        # Split daily flow across directions and day-parts
        if rr_heen and rr_terug:
            heen_daily = daily * 0.5
            terug_daily = daily * 0.5
        elif rr_heen:
            heen_daily = daily
            terug_daily = 0.0
        else:
            heen_daily = 0.0
            terug_daily = daily

        dp_heen = split_flow(heen_daily, RESIDENTIAL_FRACTION)
        dp_terug = split_flow(terug_daily, RESIDENTIAL_FRACTION)

        new_props = dict(props)
        # Write into flow_heen / flow_terug so the splitter's sum() > 0 check passes
        new_props["flow_heen"] = {"unknown": round(heen_daily, 2)} if rr_heen else {}
        new_props["flow_terug"] = {"unknown": round(terug_daily, 2)} if rr_terug else {}
        new_props["flow_dp_heen"] = {k: round(v, 2) for k, v in dp_heen.items()}
        new_props["flow_dp_terug"] = {k: round(v, 2) for k, v in dp_terug.items()}

        updated_features.append({**feat, "properties": new_props})

    updated_fc: dict = {**network_fc, "features": updated_features}
    stats = {**assign_stats, "zonesUsed": len(zone_features)}

    logger.info(
        "estimate_flow_undirected complete: %d links, %d assigned, %d minimum-floor",
        assign_stats["links_total"],
        assign_stats["links_assigned"],
        assign_stats["links_zero"],
    )
    return updated_fc, stats


# ---------------------------------------------------------------------------
# estimate_flow — directed (post-split) network  (standalone / runner use)
# ---------------------------------------------------------------------------


def estimate_flow(
    network_fc: dict,
    zones_fc: dict,
    *,
    trip_rate_per_person: float = DEFAULT_TRIP_RATE_PER_PERSON,
    local_radius_m: float = DEFAULT_LOCAL_RADIUS_M,
    collector_radius_m: float = DEFAULT_COLLECTOR_RADIUS_M,
    arterial_radius_m: float = DEFAULT_ARTERIAL_RADIUS_M,
    highway_radius_m: float = DEFAULT_HIGHWAY_RADIUS_M,
    absorption_factor: float = DEFAULT_ABSORPTION_FACTOR,
) -> tuple[dict, dict]:
    """Estimate synthetic 24-hour flow for every directed link.

    Parameters
    ----------
    network_fc:
        Directed network FeatureCollection (output of parallel_link_finder).
        Features must have a ``linkId`` property.
    zones_fc:
        Zone FeatureCollection with ``production`` and ``attraction`` fields.

    Returns
    -------
    (updated_network_fc, stats)
        Flow fields ``flow``, ``flow24hrs``, ``flowsPerMotive``,
        ``flowsPerDaypart``, ``remainingCap`` are written onto each feature.
    """
    network_features: list[dict] = network_fc.get("features") or []
    zone_features: list[dict] = zones_fc.get("features") or []

    logger.info(
        "estimate_flow: %d links, %d zones",
        len(network_features),
        len(zone_features),
    )

    flows, assign_stats = assign_flows(
        network_features,
        zone_features,
        **_flow_kwargs(
            trip_rate_per_person,
            local_radius_m,
            collector_radius_m,
            arterial_radius_m,
            highway_radius_m,
            absorption_factor,
        ),
    )

    updated_features: list[dict] = []
    for feat in network_features:
        props = feat.get("properties") or {}
        lid = str(props.get("linkId", ""))
        daily = flows.get(lid, 1.0)

        dp = split_flow(daily, RESIDENTIAL_FRACTION)
        peak = max(dp["mrh"], dp["erh"])

        cap = props.get("capacity")
        try:
            remaining = (float(cap) - peak) if cap is not None else None
        except TypeError, ValueError:
            remaining = None

        new_props = dict(props)
        new_props["flow"] = round(peak, 2)
        new_props["flow24hrs"] = round(daily, 2)
        new_props["flowsPerMotive"] = {
            "work": round(daily * 0.30, 2),
            "recreational": round(daily * 0.20, 2),
            "education": round(daily * 0.15, 2),
            "shopping": round(daily * 0.15, 2),
            "unknown": round(daily * 0.20, 2),
        }
        new_props["flowsPerDaypart"] = {k: round(v, 2) for k, v in dp.items()}
        new_props["remainingCap"] = round(remaining, 2) if remaining is not None else None

        updated_features.append({**feat, "properties": new_props})

    updated_fc: dict = {**network_fc, "features": updated_features}
    stats = {**assign_stats, "zonesUsed": len(zone_features)}

    logger.info(
        "estimate_flow complete: %d links, %d assigned, %d minimum-floor",
        assign_stats["links_total"],
        assign_stats["links_assigned"],
        assign_stats["links_zero"],
    )
    return updated_fc, stats


# ---------------------------------------------------------------------------
# Route-to-link flow assignment
# ---------------------------------------------------------------------------

DEFAULT_PEAK_HOUR_FRACTION: float = 0.10


def estimate_flow_from_routes(
    network_fc: dict,
    routes_fc: dict,
    *,
    peak_hour_fraction: float = DEFAULT_PEAK_HOUR_FRACTION,
) -> tuple[dict, dict]:
    """Assign OD route trips back to individual network links (all-or-nothing).

    For every feature in *routes_fc*, each sub-route in the ``routes`` property
    list carries a ``trips`` count and a ``linkPath`` (list of link IDs).
    This function sums all trips onto the corresponding links in *network_fc*
    and writes the standard flow fields.

    The flow fields written are:
    - ``flow``           — total 24-hr vehicles/day
    - ``flow24hrs``      — same as ``flow``
    - ``flowsPerMotive`` — ``{"unknown": flow}``
    - ``flowsPerDaypart``— ``{"mrh": mrh_share, "erh": erh_share, "rest": rest_share}``
                          using fixed splits (10 % morning peak, 10 % evening peak,
                          80 % off-peak)
    - ``remainingCap``   — ``max(0, capacity - peak_hour_flow)``

    Parameters
    ----------
    network_fc:
        Directed network FeatureCollection (post-split).  Links without
        ``spectrumId`` / ``linkId`` are skipped.
    routes_fc:
        Routes FeatureCollection as returned by ``matrix_builder``
        (``route_explorer``).  Each feature's ``routes`` property is a list
        of dicts with ``trips`` (float) and ``linkPath`` (list[str|int]).
    peak_hour_fraction:
        Fraction of daily flow assumed to occur in the peak hour.  Used to
        compute ``remainingCap``.  Default: 0.10.

    Returns
    -------
    updated_network_fc:
        Copy of *network_fc* with flow fields overwritten on every feature.
    stats:
        ``{"links_total": int, "links_with_flow": int, "total_trips_assigned": float}``
    """
    network_features = network_fc.get("features") or []

    # Build link-ID → feature index (both spectrumId and linkId as keys).
    link_index: dict[str, int] = {}
    for i, feat in enumerate(network_features):
        p = feat.get("properties") or {}
        for id_key in ("spectrumId", "linkId"):
            val = p.get(id_key)
            if val is not None:
                link_index[str(val)] = i

    # Accumulate trips per link.
    link_trips: dict[int, float] = {}
    links_on_route: set[int] = set()  # links that appear on ≥1 route, regardless of production
    total_trips_assigned = 0.0

    for feat in routes_fc.get("features") or []:
        p = feat.get("properties") or {}
        routes_list = p.get("routes")
        if not routes_list:
            continue
        # ``build_matrix`` uses unit production (1.0) per zone, so each
        # ``route.trips`` value is a fraction of 1 trip.  Multiply by the
        # origin zone's actual production to convert to real vehicles/day.
        origin_production = float(p.get("originProduction") or 0.0)
        for route in routes_list:
            route_fraction = float(route.get("trips") or 0.0)
            trips = route_fraction * origin_production
            link_path: list = route.get("linkPath") or []
            for link_id in link_path:
                idx = link_index.get(str(link_id))
                if idx is None:
                    continue
                links_on_route.add(idx)
                if trips > 0.0:
                    link_trips[idx] = link_trips.get(idx, 0.0) + trips
            if trips > 0.0:
                total_trips_assigned += trips  # count once per route, not per link

    # Write flow fields onto a copy of every feature.
    updated_features: list[dict] = []
    links_with_flow = 0

    for i, feat in enumerate(network_features):
        daily = link_trips.get(i, 0.0)
        # A link that appears on at least one route must carry at least 1 vtg/24h,
        # even when originProduction is very small or zero.
        if i in links_on_route and daily < 1.0:
            daily = 1.0
        p = dict(feat.get("properties") or {})
        capacity = float(p.get("capacity") or 0.0)
        peak_flow = daily * peak_hour_fraction
        remaining = max(0.0, capacity - peak_flow) if capacity > 0.0 else None

        p["flow"] = round(daily, 2)
        p["flow24hrs"] = round(daily, 2)
        p["flowTemporalUnit"] = "24"
        p["flowsPerMotive"] = {"unknown": round(daily, 2)}
        building_ratio: dict | None = p.get("buildingMotifRatio")
        if building_ratio and daily > 0.0:
            p["flowsPerMotive"] = {k: round(daily * v, 2) for k, v in building_ratio.items()}
        else:
            p["flowsPerMotive"] = {"unknown": round(daily, 2)}
        # flowsPerDaypart stores hourly intensities (pae/hr), consistent with the
        # Databricks pipeline where flow24hrs = 2×mrh + 2×erh + 10.4×rest.
        # The ratio OS:AS:RD = 1:1:(10.4/20) — off-peak hourly flow is 52% of peak.
        p["flowsPerDaypart"] = {
            "mrh": round(daily * peak_hour_fraction, 2),
            "erh": round(daily * peak_hour_fraction, 2),
            "rest": round(daily * peak_hour_fraction * (10.4 / 20.0), 2),
        }
        p["remainingCap"] = round(remaining, 2) if remaining is not None else None

        if daily > 0.0:
            links_with_flow += 1

        updated_features.append({**feat, "properties": p})

    updated_fc: dict = {**network_fc, "features": updated_features}
    stats: dict = {
        "links_total": len(network_features),
        "links_with_flow": links_with_flow,
        "total_trips_assigned": round(total_trips_assigned, 2),
    }
    logger.info(
        "estimate_flow_from_routes: %d links total, %d with flow, %.0f trips assigned",
        stats["links_total"],
        stats["links_with_flow"],
        stats["total_trips_assigned"],
    )
    return updated_fc, stats
