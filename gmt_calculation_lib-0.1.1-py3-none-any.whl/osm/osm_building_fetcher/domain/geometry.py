"""Building geometry helpers.

Converts raw Overpass elements to GeoJSON Features with building properties.

Public API
----------
element_centroid(element) -> tuple[float, float] | None
    Return (lon, lat) centroid for a building element.
element_to_feature(element, building_type, street_name, street_id) -> dict
    Convert an Overpass building element to a GeoJSON Feature.
"""

from __future__ import annotations

# m² per parking space (including access lanes) used when the OSM ``capacity``
# tag is absent.  A typical surface parking space + aisle is about 25 m².
_M2_PER_PARKING_SPACE: float = 25.0


def element_centroid(element: dict) -> tuple[float, float] | None:
    """Return (lon, lat) centroid for a building element.

    For ``node`` elements the coordinates are taken directly.
    For ``way`` elements the arithmetic mean of the geometry vertices is used.

    Parameters
    ----------
    element:
        Overpass element dict (``type``, ``id``, ``geometry`` / ``lon`` /
        ``lat`` keys).

    Returns
    -------
    tuple[float, float] | None
        ``(lon, lat)`` or ``None`` if coordinates are unavailable.
    """
    if element.get("type") == "node":
        lon = element.get("lon")
        lat = element.get("lat")
        if lon is None or lat is None:
            return None
        return float(lon), float(lat)

    # way
    geom = element.get("geometry") or []
    if not geom:
        return None
    lons = [float(p["lon"]) for p in geom]
    lats = [float(p["lat"]) for p in geom]
    return sum(lons) / len(lons), sum(lats) / len(lats)


def _extract_parking_capacity(tags: dict[str, str]) -> int:
    """Extract the parking capacity from OSM tags.

    Uses the ``capacity`` tag when present and parseable as a positive integer.
    Returns ``0`` otherwise — the caller (``building_zone_creator``) will
    substitute a footprint-based estimate for features whose capacity is 0.

    Parameters
    ----------
    tags:
        Dict of OSM tag key/value pairs for the element.
    """
    raw = tags.get("capacity", "").strip()
    if not raw:
        return 0
    try:
        val = int(raw)
        return max(0, val)
    except ValueError, TypeError:
        return 0


def element_to_feature(
    element: dict,
    building_type: str,
    street_name: str | None,
    street_id: str | None,
) -> dict:
    """Convert an Overpass building element to a GeoJSON Feature.

    Node elements become ``Point`` features; way elements become
    ``Polygon`` features (first ring closed automatically if needed).

    All OSM tags are stored as properties with a ``tag_`` prefix to avoid
    collisions with the structured fields.

    For ``buildingType="parking"`` the ``parkingCapacity`` property is set
    from the OSM ``capacity`` tag (``0`` when the tag is absent — downstream
    ``building_zone_creator`` will substitute a footprint-based estimate).
    For all other building types ``parkingCapacity`` is always ``0``.

    Parameters
    ----------
    element:
        Overpass element dict.
    building_type:
        Classified type: ``'school'``, ``'house'``, ``'hospital'``,
        ``'recreational'``, ``'shopping'``, ``'parking'``, or ``'other'``.
    street_name:
        Matched or nearest street name (``None`` if not found).
    street_id:
        OSM way ID of the matched / nearest street (``None`` if not found).

    Returns
    -------
    dict
        GeoJSON Feature.
    """
    tags: dict[str, str] = element.get("tags") or {}

    # ── geometry ────────────────────────────────────────────────────────────
    if element.get("type") == "node":
        geometry: dict = {
            "type": "Point",
            "coordinates": [float(element["lon"]), float(element["lat"])],
        }
    else:
        coords = [[float(p["lon"]), float(p["lat"])] for p in (element.get("geometry") or [])]
        # Close the ring if necessary
        if coords and coords[0] != coords[-1]:
            coords.append(coords[0])
        geometry = {
            "type": "Polygon",
            "coordinates": [coords],
        }

    # ── properties ──────────────────────────────────────────────────────────
    parking_capacity = _extract_parking_capacity(tags) if building_type == "parking" else 0

    props: dict = {
        "buildingId": f"osm_{element['id']}",
        "buildingType": building_type,
        "parkingCapacity": parking_capacity,
        "streetName": street_name,
        "streetId": street_id,
    }
    # Preserve all original OSM tags under a tag_ prefix
    for k, v in tags.items():
        props[f"tag_{k}"] = v

    return {
        "type": "Feature",
        "geometry": geometry,
        "properties": props,
    }
