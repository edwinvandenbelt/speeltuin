"""Building classification into simplified categories.

Maps OSM tags to one of eight building types:
  school | house | hospital | recreational | shopping | work | parking | other

Public API
----------
classify_building(tags) -> str
    Return the building type for a dict of OSM tags.
is_parking_element(tags) -> bool
    Return True if an OSM element represents a parking facility or P+R,
    even when it has no ``building=`` tag.
is_work_element(tags) -> bool
    Return True if an OSM element represents an office or industrial
    facility even when it has no ``building=`` tag.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# building= tag sets
# ---------------------------------------------------------------------------

_SCHOOL_BUILDING: frozenset[str] = frozenset(
    {
        "school",
        "university",
        "college",
        "kindergarten",
    }
)

_HOUSE_BUILDING: frozenset[str] = frozenset(
    {
        "house",
        "residential",
        "apartments",
        "detached",
        "terrace",
        "semi_detached",
        "bungalow",
        "dormitory",
        "block_of_flats",
        "static_caravan",
        "cabin",
    }
)

_HOSPITAL_BUILDING: frozenset[str] = frozenset(
    {
        "hospital",
        "clinic",
    }
)

_RECREATIONAL_BUILDING: frozenset[str] = frozenset(
    {
        "sports_hall",
        "stadium",
        "sports_centre",
        "grandstand",
        "pavilion",
        "riding_hall",
        "swimming_pool",
        "gym",
    }
)

_SHOPPING_BUILDING: frozenset[str] = frozenset(
    {
        "retail",
        "supermarket",
        "shop",
        "kiosk",
        "commercial",
        "mall",
    }
)

_WORK_BUILDING: frozenset[str] = frozenset(
    {
        "office",
        "industrial",
        "warehouse",
        "factory",
        "manufacture",
        "storage_tank",
        "barn",
        "farm_auxiliary",
        "greenhouse",
        "digester",
    }
)

# ---------------------------------------------------------------------------
# amenity= tag sets
# ---------------------------------------------------------------------------

_SCHOOL_AMENITY: frozenset[str] = frozenset(
    {
        "school",
        "university",
        "college",
        "kindergarten",
        "language_school",
        "driving_school",
        "music_school",
    }
)

_HOSPITAL_AMENITY: frozenset[str] = frozenset(
    {
        "hospital",
        "clinic",
        "doctors",
        "dentist",
        "pharmacy",
        "nursing_home",
        "social_facility",
    }
)

_RECREATIONAL_AMENITY: frozenset[str] = frozenset(
    {
        "theatre",
        "cinema",
        "arts_centre",
        "community_centre",
        "social_centre",
        "nightclub",
        "bar",
        "pub",
        "restaurant",
        "cafe",
        "fast_food",
        "stadium",
        "sports_centre",
        "swimming_pool",
    }
)

_SHOPPING_AMENITY: frozenset[str] = frozenset(
    {
        "marketplace",
        "car_wash",
        "fuel",
    }
)

# ---------------------------------------------------------------------------
# leisure= tag set
# ---------------------------------------------------------------------------

_RECREATIONAL_LEISURE: frozenset[str] = frozenset(
    {
        "sports_centre",
        "stadium",
        "swimming_pool",
        "fitness_centre",
        "dance",
        "horse_riding",
        "ice_rink",
        "pitch",
        "track",
        "recreation_ground",
        "theatre",
        "bowling_alley",
    }
)

# ---------------------------------------------------------------------------
# shop= — any non-empty shop tag → shopping
# ---------------------------------------------------------------------------


def classify_building(tags: dict[str, str]) -> str:
    """Classify a building based on its OSM tags.

    Checks in priority order:
    1. ``building=`` tag
    2. ``amenity=`` tag  (``parking`` checked first, before general amenities)
    3. ``park_ride=`` tag (any non-empty value → parking)
    4. ``office=`` tag (any non-empty value → work)
    5. ``shop=`` tag (any value → shopping)
    6. ``leisure=`` tag

    Parameters
    ----------
    tags:
        Dict of OSM tag key/value pairs for the element.

    Returns
    -------
    str
        One of ``'school'``, ``'house'``, ``'hospital'``,
        ``'recreational'``, ``'shopping'``, ``'work'``,
        ``'parking'``, or ``'other'``.
    """
    building = tags.get("building", "").strip().lower()
    amenity = tags.get("amenity", "").strip().lower()
    shop = tags.get("shop", "").strip().lower()
    leisure = tags.get("leisure", "").strip().lower()
    park_ride = tags.get("park_ride", "").strip().lower()
    office = tags.get("office", "").strip().lower()

    # --- building= priority ---
    if building == "parking" or building == "garage" or building == "garages":
        return "parking"
    if building in _SCHOOL_BUILDING:
        return "school"
    if building in _HOSPITAL_BUILDING:
        return "hospital"
    if building in _RECREATIONAL_BUILDING:
        return "recreational"
    if building in _SHOPPING_BUILDING:
        return "shopping"
    if building in _WORK_BUILDING:
        return "work"
    if building in _HOUSE_BUILDING:
        return "house"

    # --- amenity=parking (before generic amenity checks) ---
    if amenity == "parking":
        return "parking"

    # --- park_ride= (any non-empty value → P+R = parking) ---
    if park_ride:
        return "parking"

    # --- amenity= fallback ---
    if amenity in _SCHOOL_AMENITY:
        return "school"
    if amenity in _HOSPITAL_AMENITY:
        return "hospital"
    if amenity in _RECREATIONAL_AMENITY:
        return "recreational"
    if amenity in _SHOPPING_AMENITY:
        return "shopping"

    # --- office= tag (any non-empty value → work) ---
    if office:
        return "work"

    # --- shop= fallback (any value) ---
    if shop:
        return "shopping"

    # --- leisure= fallback ---
    if leisure in _RECREATIONAL_LEISURE:
        return "recreational"

    return "other"


def is_parking_element(tags: dict[str, str]) -> bool:
    """Return True if an OSM element is a parking facility or P+R.

    Used to include surface parking lots and P+R nodes that carry no
    ``building`` tag in the buildings pipeline.

    Parameters
    ----------
    tags:
        Dict of OSM tag key/value pairs for the element.
    """
    amenity = tags.get("amenity", "").strip().lower()
    park_ride = tags.get("park_ride", "").strip().lower()
    building = tags.get("building", "").strip().lower()
    return amenity == "parking" or bool(park_ride) or building in {"parking", "garage", "garages"}


def is_work_element(tags: dict[str, str]) -> bool:
    """Return True if an OSM element is an office or industrial facility.

    Used to include work-related elements that carry no ``building`` tag
    (e.g. ``office=*`` nodes) in the buildings pipeline.

    Parameters
    ----------
    tags:
        Dict of OSM tag key/value pairs for the element.
    """
    office = tags.get("office", "").strip().lower()
    building = tags.get("building", "").strip().lower()
    return bool(office) or building in _WORK_BUILDING
