"""OSM Building Fetcher core — fetches, classifies and links buildings.

Downloads buildings and streets from the Overpass API for a bounding box,
classifies each building (school / house / hospital / recreational /
shopping / work / parking / other) and links it to a street by name-match
or nearest centroid.  Parking elements (surface lots, P+R) that carry no
``building`` tag are included via :func:`is_parking_element`.  Work/office
elements that carry only an ``office=`` tag are included via
:func:`is_work_element`.
Output is a GeoJSON FeatureCollection ready for serialisation as GeoParquet.

Public API
----------
build_buildings(bbox, *, overpass_url, timeout) -> tuple[dict, dict]
    Fetch, classify, and link buildings.
    Returns (feature_collection, stats).
    stats: {"total": int, "buildings": int, "streets": int, "by_type": dict}
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from shared.overpass import DEFAULT_OVERPASS_URL, fetch_overpass  # noqa: E402

from osm.osm_building_fetcher.domain.classifier import (
    classify_building,
    is_parking_element,
    is_work_element,
)
from osm.osm_building_fetcher.domain.geometry import element_to_feature
from osm.osm_building_fetcher.domain.overpass import (
    DEFAULT_TIMEOUT,
    build_buildings_and_streets_query,
)
from osm.osm_building_fetcher.domain.street_linker import link_buildings_to_streets

_DEFAULT_OVERPASS_URL = DEFAULT_OVERPASS_URL


def build_buildings(
    bbox: list[float],
    *,
    overpass_url: str = _DEFAULT_OVERPASS_URL,
    timeout: int = DEFAULT_TIMEOUT,
) -> tuple[dict, dict]:
    """Fetch buildings and streets from Overpass, classify and link.

    Parameters
    ----------
    bbox:
        Bounding box ``[minLon, minLat, maxLon, maxLat]``.
    overpass_url:
        Overpass API endpoint URL.
    timeout:
        Overpass query timeout in seconds.

    Returns
    -------
    fc:
        GeoJSON FeatureCollection where each Feature represents one OSM
        building (way or node).  Properties include ``buildingId``,
        ``buildingType``, ``streetName``, ``streetId``, and all original
        OSM tags prefixed with ``tag_``.
    stats:
        ``{"total": int, "buildings": int, "streets": int, "by_type": dict}``
    """
    query = build_buildings_and_streets_query(bbox, timeout=timeout)
    logger.info(
        "Fetching buildings + streets via Overpass  bbox=%s  url=%s",
        bbox,
        overpass_url,
    )
    data = fetch_overpass(query, url=overpass_url, timeout=timeout)
    elements: list[dict] = data.get("elements") or []

    # Split raw elements into buildings and streets.
    # Include elements with a ``building`` tag AND parking/P+R elements that
    # may only carry ``amenity=parking`` or ``park_ride=*`` without a building
    # tag, as well as work/office elements that carry only an ``office=`` tag.
    buildings = [
        e
        for e in elements
        if "building" in (e.get("tags") or {})
        or is_parking_element(e.get("tags") or {})
        or is_work_element(e.get("tags") or {})
    ]
    streets = [e for e in elements if e.get("type") == "way" and "highway" in (e.get("tags") or {})]

    logger.info(
        "Overpass returned %d elements (%d buildings, %d streets)",
        len(elements),
        len(buildings),
        len(streets),
    )

    # Link each building to a street
    links = link_buildings_to_streets(buildings, streets)

    # Build GeoJSON features
    features: list[dict] = []
    type_counts: dict[str, int] = {}
    for building, (street_name, street_id) in zip(buildings, links):
        btype = classify_building(building.get("tags") or {})
        type_counts[btype] = type_counts.get(btype, 0) + 1
        feature = element_to_feature(building, btype, street_name, street_id)
        features.append(feature)

    fc: dict = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "bbox": bbox,
            "overpassUrl": overpass_url,
        },
    }
    stats: dict = {
        "total": len(features),
        "buildings": len(buildings),
        "streets": len(streets),
        "by_type": type_counts,
    }
    logger.info("Built %d building features — %s", len(features), type_counts)
    return fc, stats
