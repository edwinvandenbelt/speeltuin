"""Tests for osm_building_fetcher domain modules and core.

Covers:
- classify_building — all 7 types (including parking) + edge cases
- is_parking_element — amenity=parking, park_ride, building=parking
- element_centroid — node and way elements
- element_to_feature — geometry, properties mapping, OSM tag prefix, parkingCapacity
- build_buildings_and_streets_query — Overpass QL output (parking filters)
- link_buildings_to_streets — name match, nearest fallback, no streets
- build_buildings — integration with mocked Overpass response (parking elements)
"""

from __future__ import annotations

from unittest.mock import patch

import pytest

from osm_building_fetcher.domain.classifier import (
    classify_building,
    is_parking_element,
    is_work_element,
)
from osm_building_fetcher.domain.geometry import element_centroid, element_to_feature
from osm_building_fetcher.domain.overpass import build_buildings_and_streets_query
from osm_building_fetcher.domain.street_linker import link_buildings_to_streets


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _way(eid: int, tags: dict, geom: list[dict] | None = None) -> dict:
    return {
        "type": "way",
        "id": eid,
        "tags": tags,
        "geometry": geom
        or [
            {"lon": 6.10, "lat": 52.25},
            {"lon": 6.11, "lat": 52.25},
            {"lon": 6.11, "lat": 52.26},
            {"lon": 6.10, "lat": 52.26},
            {"lon": 6.10, "lat": 52.25},
        ],
    }


def _node(eid: int, tags: dict, lon: float = 6.15, lat: float = 52.26) -> dict:
    return {"type": "node", "id": eid, "tags": tags, "lon": lon, "lat": lat}


def _street(eid: int, name: str, lon: float = 6.12, lat: float = 52.25) -> dict:
    return {
        "type": "way",
        "id": eid,
        "tags": {"highway": "residential", "name": name},
        "geometry": [
            {"lon": lon, "lat": lat},
            {"lon": lon + 0.001, "lat": lat},
        ],
    }


# ---------------------------------------------------------------------------
# classify_building
# ---------------------------------------------------------------------------


class TestClassifyBuilding:
    def test_school_via_building_tag(self) -> None:
        assert classify_building({"building": "school"}) == "school"

    def test_school_via_university(self) -> None:
        assert classify_building({"building": "university"}) == "school"

    def test_school_via_amenity(self) -> None:
        assert classify_building({"building": "yes", "amenity": "kindergarten"}) == "school"

    def test_house_via_building_tag(self) -> None:
        assert classify_building({"building": "house"}) == "house"

    def test_house_apartments(self) -> None:
        assert classify_building({"building": "apartments"}) == "house"

    def test_hospital_via_building_tag(self) -> None:
        assert classify_building({"building": "hospital"}) == "hospital"

    def test_hospital_via_amenity(self) -> None:
        assert classify_building({"building": "yes", "amenity": "clinic"}) == "hospital"

    def test_recreational_via_building_tag(self) -> None:
        assert classify_building({"building": "sports_hall"}) == "recreational"

    def test_recreational_via_leisure(self) -> None:
        assert classify_building({"building": "yes", "leisure": "sports_centre"}) == "recreational"

    def test_recreational_via_amenity_theatre(self) -> None:
        assert classify_building({"building": "yes", "amenity": "theatre"}) == "recreational"

    def test_shopping_via_building_tag(self) -> None:
        assert classify_building({"building": "retail"}) == "shopping"

    def test_shopping_via_shop_tag(self) -> None:
        assert classify_building({"building": "yes", "shop": "bakery"}) == "shopping"

    def test_shopping_via_supermarket(self) -> None:
        assert classify_building({"building": "supermarket"}) == "shopping"

    def test_other_for_unknown_building_tag(self) -> None:
        assert classify_building({"building": "yes"}) == "other"

    def test_other_for_empty_tags(self) -> None:
        assert classify_building({}) == "other"

    def test_building_tag_priority_over_amenity(self) -> None:
        # building=house takes priority over amenity=school
        assert classify_building({"building": "house", "amenity": "school"}) == "house"

    def test_case_insensitive_tags(self) -> None:
        # The classifier lowercases the tag value, so 'HOUSE' → 'house' → matches
        assert classify_building({"building": "HOUSE"}) == "house"

    # --- parking ---
    def test_parking_via_building_parking(self) -> None:
        assert classify_building({"building": "parking"}) == "parking"

    def test_parking_via_building_garage(self) -> None:
        assert classify_building({"building": "garage"}) == "parking"

    def test_parking_via_building_garages(self) -> None:
        assert classify_building({"building": "garages"}) == "parking"

    def test_parking_via_amenity_parking(self) -> None:
        assert classify_building({"amenity": "parking"}) == "parking"

    def test_parking_via_park_ride(self) -> None:
        assert classify_building({"park_ride": "yes"}) == "parking"

    def test_parking_building_tag_beats_amenity(self) -> None:
        # building=parking is already parking, extra amenity tag irrelevant
        assert classify_building({"building": "parking", "amenity": "school"}) == "parking"

    # --- work ---
    def test_work_via_building_office(self) -> None:
        assert classify_building({"building": "office"}) == "work"

    def test_work_via_building_industrial(self) -> None:
        assert classify_building({"building": "industrial"}) == "work"

    def test_work_via_building_warehouse(self) -> None:
        assert classify_building({"building": "warehouse"}) == "work"

    def test_work_via_building_factory(self) -> None:
        assert classify_building({"building": "factory"}) == "work"

    def test_work_via_office_tag(self) -> None:
        assert classify_building({"office": "yes"}) == "work"

    def test_work_via_office_company(self) -> None:
        assert classify_building({"office": "company"}) == "work"

    def test_work_office_tag_beats_amenity_school(self) -> None:
        # office= is checked after amenity=, but a bare office tag with no
        # special amenity should still classify as work
        assert classify_building({"office": "government"}) == "work"


# ---------------------------------------------------------------------------
# is_parking_element
# ---------------------------------------------------------------------------


class TestIsParkingElement:
    def test_amenity_parking(self) -> None:
        assert is_parking_element({"amenity": "parking"}) is True

    def test_park_ride_yes(self) -> None:
        assert is_parking_element({"park_ride": "yes"}) is True

    def test_park_ride_bus(self) -> None:
        assert is_parking_element({"park_ride": "bus"}) is True

    def test_building_parking(self) -> None:
        assert is_parking_element({"building": "parking"}) is True

    def test_building_garage(self) -> None:
        assert is_parking_element({"building": "garage"}) is True

    def test_building_house_is_not_parking(self) -> None:
        assert is_parking_element({"building": "house"}) is False

    def test_empty_tags_is_not_parking(self) -> None:
        assert is_parking_element({}) is False

    def test_amenity_school_is_not_parking(self) -> None:
        assert is_parking_element({"amenity": "school"}) is False


# ---------------------------------------------------------------------------
# is_work_element
# ---------------------------------------------------------------------------


class TestIsWorkElement:
    def test_office_tag_yes(self) -> None:
        assert is_work_element({"office": "yes"}) is True

    def test_office_tag_company(self) -> None:
        assert is_work_element({"office": "company"}) is True

    def test_building_office(self) -> None:
        assert is_work_element({"building": "office"}) is True

    def test_building_industrial(self) -> None:
        assert is_work_element({"building": "industrial"}) is True

    def test_building_warehouse(self) -> None:
        assert is_work_element({"building": "warehouse"}) is True

    def test_building_house_is_not_work(self) -> None:
        assert is_work_element({"building": "house"}) is False

    def test_empty_tags_is_not_work(self) -> None:
        assert is_work_element({}) is False

    def test_amenity_school_is_not_work(self) -> None:
        assert is_work_element({"amenity": "school"}) is False


# ---------------------------------------------------------------------------
# element_centroid
# ---------------------------------------------------------------------------


class TestElementCentroid:
    def test_node_centroid(self) -> None:
        node = _node(1, {}, lon=6.15, lat=52.26)
        result = element_centroid(node)
        assert result is not None
        assert result == pytest.approx((6.15, 52.26))

    def test_way_centroid(self) -> None:
        way = _way(
            2,
            {},
            geom=[
                {"lon": 0.0, "lat": 0.0},
                {"lon": 2.0, "lat": 0.0},
                {"lon": 2.0, "lat": 2.0},
                {"lon": 0.0, "lat": 2.0},
            ],
        )
        result = element_centroid(way)
        assert result is not None
        assert result == pytest.approx((1.0, 1.0))

    def test_node_missing_coords(self) -> None:
        node = {"type": "node", "id": 3, "tags": {}}
        assert element_centroid(node) is None

    def test_way_no_geometry(self) -> None:
        way = {"type": "way", "id": 4, "tags": {}, "geometry": []}
        assert element_centroid(way) is None


# ---------------------------------------------------------------------------
# element_to_feature
# ---------------------------------------------------------------------------


class TestElementToFeature:
    def test_node_becomes_point(self) -> None:
        node = _node(10, {"building": "house", "addr:street": "Hoofdstraat"})
        feat = element_to_feature(node, "house", "Hoofdstraat", "osm_99")
        assert feat["geometry"]["type"] == "Point"
        assert feat["geometry"]["coordinates"] == pytest.approx([6.15, 52.26])

    def test_way_becomes_polygon(self) -> None:
        way = _way(20, {"building": "school"})
        feat = element_to_feature(way, "school", "Schoolstraat", "osm_88")
        assert feat["geometry"]["type"] == "Polygon"
        # Ring should be closed
        ring = feat["geometry"]["coordinates"][0]
        assert ring[0] == ring[-1]

    def test_properties_populated(self) -> None:
        node = _node(11, {"building": "retail", "name": "AH"})
        feat = element_to_feature(node, "shopping", "Winkelstraat", "osm_77")
        props = feat["properties"]
        assert props["buildingId"] == "osm_11"
        assert props["buildingType"] == "shopping"
        assert props["streetName"] == "Winkelstraat"
        assert props["streetId"] == "osm_77"

    def test_osm_tags_prefixed(self) -> None:
        node = _node(12, {"building": "house", "addr:housenumber": "5a"})
        feat = element_to_feature(node, "house", None, None)
        props = feat["properties"]
        assert "tag_building" in props
        assert props["tag_building"] == "house"
        assert props["tag_addr:housenumber"] == "5a"

    def test_none_street_preserved(self) -> None:
        node = _node(13, {"building": "yes"})
        feat = element_to_feature(node, "other", None, None)
        assert feat["properties"]["streetName"] is None
        assert feat["properties"]["streetId"] is None

    def test_polygon_ring_auto_closed(self) -> None:
        # Geometry without closing vertex should be closed automatically
        way = _way(
            30,
            {"building": "yes"},
            geom=[
                {"lon": 1.0, "lat": 1.0},
                {"lon": 2.0, "lat": 1.0},
                {"lon": 2.0, "lat": 2.0},
            ],
        )
        feat = element_to_feature(way, "other", None, None)
        ring = feat["geometry"]["coordinates"][0]
        assert ring[0] == ring[-1]

    def test_feature_type(self) -> None:
        node = _node(14, {"building": "hospital"})
        feat = element_to_feature(node, "hospital", None, None)
        assert feat["type"] == "Feature"


# ---------------------------------------------------------------------------
# build_buildings_and_streets_query
# ---------------------------------------------------------------------------


class TestBuildBuildingsAndStreetsQuery:
    def test_contains_building_way_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'way["building"]' in q

    def test_contains_building_node_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'node["building"]' in q

    def test_contains_highway_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'way["highway"]' in q

    def test_bbox_order_is_lat_lon(self) -> None:
        # Overpass expects south,west,north,east
        q = build_buildings_and_streets_query([6.143, 52.248, 6.184, 52.272])
        assert "52.248,6.143,52.272,6.184" in q

    def test_json_output_format(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "[out:json]" in q

    def test_custom_timeout(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1], timeout=120)
        assert "[timeout:120]" in q

    def test_out_geom(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "out geom" in q

    def test_contains_office_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'way["office"]' in q

    def test_contains_office_node_filter(self) -> None:
        q = build_buildings_and_streets_query([6.0, 52.0, 6.1, 52.1])
        assert 'node["office"]' in q


# ---------------------------------------------------------------------------
# link_buildings_to_streets
# ---------------------------------------------------------------------------


class TestLinkBuildingsToStreets:
    def test_no_streets_returns_none(self) -> None:
        buildings = [_way(1, {"building": "house"})]
        result = link_buildings_to_streets(buildings, [])
        assert result == [(None, None)]

    def test_name_match(self) -> None:
        building = _way(1, {"building": "house", "addr:street": "Hoofdstraat"})
        street = _street(100, "Hoofdstraat")
        result = link_buildings_to_streets([building], [street])
        assert result[0][0] == "Hoofdstraat"
        assert result[0][1] == "osm_100"

    def test_name_match_case_insensitive(self) -> None:
        building = _way(1, {"building": "house", "addr:street": "hoofdstraat"})
        street = _street(100, "Hoofdstraat")
        result = link_buildings_to_streets([building], [street])
        assert result[0][1] == "osm_100"

    def test_nearest_fallback_when_no_addr_street(self) -> None:
        building = _node(1, {"building": "house"}, lon=6.120, lat=52.250)
        near_street = _street(200, "Dichtbijstraat", lon=6.121, lat=52.250)
        far_street = _street(201, "Verrestraat", lon=6.200, lat=52.300)
        result = link_buildings_to_streets([building], [near_street, far_street])
        assert result[0][1] == "osm_200"

    def test_nearest_fallback_when_addr_street_not_found(self) -> None:
        building = _way(1, {"building": "house", "addr:street": "Onbekendstraat"})
        street = _street(300, "Hoofdstraat", lon=6.105, lat=52.250)
        result = link_buildings_to_streets([building], [street])
        # Falls back to nearest
        assert result[0][1] == "osm_300"

    def test_empty_buildings_returns_empty(self) -> None:
        result = link_buildings_to_streets([], [_street(1, "A")])
        assert result == []

    def test_multiple_buildings(self) -> None:
        b1 = _node(1, {"building": "house", "addr:street": "Astraat"}, lon=6.10, lat=52.25)
        b2 = _node(2, {"building": "school", "addr:street": "Bstraat"}, lon=6.20, lat=52.30)
        s1 = _street(10, "Astraat", lon=6.10, lat=52.25)
        s2 = _street(11, "Bstraat", lon=6.20, lat=52.30)
        result = link_buildings_to_streets([b1, b2], [s1, s2])
        assert result[0][1] == "osm_10"
        assert result[1][1] == "osm_11"

    def test_street_without_name_returns_none_name(self) -> None:
        building = _node(1, {"building": "house"}, lon=6.10, lat=52.25)
        nameless = {
            "type": "way",
            "id": 500,
            "tags": {"highway": "residential"},
            "geometry": [
                {"lon": 6.10, "lat": 52.25},
                {"lon": 6.101, "lat": 52.25},
            ],
        }
        result = link_buildings_to_streets([building], [nameless])
        assert result[0][1] == "osm_500"
        assert result[0][0] is None


# ---------------------------------------------------------------------------
# build_buildings (integration — Overpass mocked)
# ---------------------------------------------------------------------------


class TestBuildBuildings:
    """Integration tests for build_buildings() with a mocked Overpass call."""

    _MOCK_ELEMENTS = [
        {
            "type": "way",
            "id": 1001,
            "tags": {"building": "house", "addr:street": "Teststraat"},
            "geometry": [
                {"lon": 6.15, "lat": 52.25},
                {"lon": 6.16, "lat": 52.25},
                {"lon": 6.16, "lat": 52.26},
                {"lon": 6.15, "lat": 52.26},
                {"lon": 6.15, "lat": 52.25},
            ],
        },
        {
            "type": "way",
            "id": 1002,
            "tags": {"building": "school"},
            "geometry": [
                {"lon": 6.17, "lat": 52.27},
                {"lon": 6.18, "lat": 52.27},
                {"lon": 6.18, "lat": 52.28},
                {"lon": 6.17, "lat": 52.28},
                {"lon": 6.17, "lat": 52.27},
            ],
        },
        {
            "type": "node",
            "id": 2001,
            "tags": {"building": "yes", "shop": "bakery"},
            "lon": 6.155,
            "lat": 52.255,
        },
        {
            "type": "way",
            "id": 3001,
            "tags": {"highway": "residential", "name": "Teststraat"},
            "geometry": [
                {"lon": 6.14, "lat": 52.25},
                {"lon": 6.17, "lat": 52.25},
            ],
        },
    ]

    def _call(self, elements: list[dict] | None = None) -> tuple[dict, dict]:
        from osm_building_fetcher.core.osm_building_fetcher_core import build_buildings  # noqa: PLC0415

        mock_data = {"elements": self._MOCK_ELEMENTS if elements is None else elements}
        with patch("osm_building_fetcher.core.osm_building_fetcher_core.fetch_overpass") as mock_fp:
            mock_fp.return_value = mock_data
            return build_buildings([6.14, 52.24, 6.19, 52.29])

    def test_returns_feature_collection(self) -> None:
        fc, _ = self._call()
        assert fc["type"] == "FeatureCollection"

    def test_stats_total_matches_feature_count(self) -> None:
        fc, stats = self._call()
        assert stats["total"] == len(fc["features"])

    def test_correct_building_count(self) -> None:
        _, stats = self._call()
        # 2 way-buildings + 1 node-building = 3
        assert stats["buildings"] == 3

    def test_correct_street_count(self) -> None:
        _, stats = self._call()
        assert stats["streets"] == 1

    def test_building_types_in_stats(self) -> None:
        _, stats = self._call()
        assert "house" in stats["by_type"]
        assert "school" in stats["by_type"]
        assert "shopping" in stats["by_type"]

    def test_street_name_linked_by_addr_street(self) -> None:
        fc, _ = self._call()
        house = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_1001")
        assert house["properties"]["streetName"] == "Teststraat"
        assert house["properties"]["streetId"] == "osm_3001"

    def test_building_id_format(self) -> None:
        fc, _ = self._call()
        ids = {f["properties"]["buildingId"] for f in fc["features"]}
        assert "osm_1001" in ids
        assert "osm_1002" in ids
        assert "osm_2001" in ids

    def test_osm_tags_present_in_feature(self) -> None:
        fc, _ = self._call()
        house = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_1001")
        assert house["properties"]["tag_building"] == "house"
        assert house["properties"]["tag_addr:street"] == "Teststraat"

    def test_node_building_has_point_geometry(self) -> None:
        fc, _ = self._call()
        node_feat = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_2001")
        assert node_feat["geometry"]["type"] == "Point"

    def test_way_building_has_polygon_geometry(self) -> None:
        fc, _ = self._call()
        way_feat = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_1001")
        assert way_feat["geometry"]["type"] == "Polygon"

    def test_empty_overpass_response(self) -> None:
        fc, stats = self._call(elements=[])
        assert fc["features"] == []
        assert stats["total"] == 0

    def test_by_type_counts_correct(self) -> None:
        _, stats = self._call()
        assert stats["by_type"].get("house", 0) == 1
        assert stats["by_type"].get("school", 0) == 1
        assert stats["by_type"].get("shopping", 0) == 1

    def test_parking_element_without_building_tag_included(self) -> None:
        """A surface parking lot (amenity=parking, no building tag) must appear."""
        surface_lot = {
            "type": "way",
            "id": 5001,
            "tags": {"amenity": "parking", "capacity": "40"},
            "geometry": [
                {"lon": 6.151, "lat": 52.251},
                {"lon": 6.153, "lat": 52.251},
                {"lon": 6.153, "lat": 52.253},
                {"lon": 6.151, "lat": 52.253},
                {"lon": 6.151, "lat": 52.251},
            ],
        }
        elements = list(self._MOCK_ELEMENTS) + [surface_lot]
        fc, stats = self._call(elements)
        ids = {f["properties"]["buildingId"] for f in fc["features"]}
        assert "osm_5001" in ids
        assert stats["by_type"].get("parking", 0) >= 1

    def test_parking_element_has_parking_capacity(self) -> None:
        """parkingCapacity is set from the OSM capacity tag."""
        parking_node = {
            "type": "node",
            "id": 6001,
            "tags": {"amenity": "parking", "capacity": "80"},
            "lon": 6.155,
            "lat": 52.256,
        }
        elements = list(self._MOCK_ELEMENTS) + [parking_node]
        fc, stats = self._call(elements)
        feat = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_6001")
        assert feat["properties"]["parkingCapacity"] == 80

    def test_non_parking_building_has_zero_parking_capacity(self) -> None:
        fc, _ = self._call()
        house = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_1001")
        assert house["properties"]["parkingCapacity"] == 0

    def test_work_element_without_building_tag_included(self) -> None:
        """An office node (office=yes, no building tag) must appear in output."""
        office_node = {
            "type": "node",
            "id": 7001,
            "tags": {"office": "company"},
            "lon": 6.160,
            "lat": 52.260,
        }
        elements = list(self._MOCK_ELEMENTS) + [office_node]
        fc, stats = self._call(elements)
        ids = {f["properties"]["buildingId"] for f in fc["features"]}
        assert "osm_7001" in ids
        assert stats["by_type"].get("work", 0) >= 1

    def test_work_building_classified_correctly(self) -> None:
        """A way with building=industrial is classified as 'work'."""
        industrial = {
            "type": "way",
            "id": 7002,
            "tags": {"building": "industrial"},
            "geometry": [
                {"lon": 6.161, "lat": 52.261},
                {"lon": 6.163, "lat": 52.261},
                {"lon": 6.163, "lat": 52.263},
                {"lon": 6.161, "lat": 52.263},
                {"lon": 6.161, "lat": 52.261},
            ],
        }
        elements = list(self._MOCK_ELEMENTS) + [industrial]
        fc, stats = self._call(elements)
        feat = next(f for f in fc["features"] if f["properties"]["buildingId"] == "osm_7002")
        assert feat["properties"]["buildingType"] == "work"
        assert stats["by_type"].get("work", 0) >= 1
