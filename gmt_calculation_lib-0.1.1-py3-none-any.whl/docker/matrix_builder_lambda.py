"""MatrixBuilder Lambda handler — thin I/O wrapper around matrix_builder_core.

Reads network, feedlinks, and zones GeoJSON, builds a complete zone × zone OD
route matrix with unit productions, and writes the OD GeoJSON.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "networkUri":   "s3://bucket/key or local path",  // required
        "feedlinksUri": "s3://bucket/key or local path",  // required
        "zonesUri":     "s3://bucket/key or local path",  // required
        "outputUri":    "s3://bucket/key or local path",  // required
        "maxRoutes":    3,    // optional (default: 3)
        "workers":      null  // optional (null = os.cpu_count())
    }
}

Response (200)
--------------
{
    "statusCode": 200,
    "status":     "successful",
    "outputUri":  "...",
    "odPairs":    int
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from matrix_builder.core.matrix_builder_core import build_matrix  # noqa: PLC0415
        from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        network_uri: str = inputs.get("networkUri", "")
        feedlinks_uri: str = inputs.get("feedlinksUri", "")
        zones_uri: str = inputs.get("zonesUri", "")
        output_uri: str = inputs.get("outputUri", "")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not feedlinks_uri:
            raise ValueError("inputs.feedlinksUri is required.")
        if not zones_uri:
            raise ValueError("inputs.zonesUri is required.")
        if not output_uri:
            raise ValueError("inputs.outputUri is required.")

        max_routes: int = int(inputs.get("maxRoutes", 3))
        workers = inputs.get("workers")
        if workers is not None:
            workers = int(workers)

        logger.info("Reading network  : %s", network_uri)
        network_fc = from_geoparquet(_read_uri(network_uri))

        logger.info("Reading feedlinks: %s", feedlinks_uri)
        feedlinks_fc = from_geoparquet(_read_uri(feedlinks_uri))

        logger.info("Reading zones    : %s", zones_uri)
        zones_fc = from_geoparquet(_read_uri(zones_uri))

        od_fc = build_matrix(
            network_fc,
            feedlinks_fc,
            zones_fc,
            max_routes=max_routes,
            workers=workers,
        )

        logger.info("Writing output   : %s", output_uri)
        _write_uri(output_uri, to_geoparquet(od_fc))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "outputUri": output_uri,
            "odPairs": len(od_fc.get("features", [])),
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
