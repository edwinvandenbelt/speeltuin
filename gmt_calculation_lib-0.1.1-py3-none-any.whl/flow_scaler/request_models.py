"""Pydantic input schema for the flow-scaler Lambda handler."""

from __future__ import annotations

import datetime
import logging
from enum import StrEnum

from pydantic import BaseModel, ConfigDict, Field, computed_field, field_validator

from flow_scaler.core.flow_scaler_core import normalise_temperature, normalise_weather, parse_date

logger = logging.getLogger(__name__)


class Mode(StrEnum):
    """Transport mode. Case-insensitive; maps to the OpenAPI ``mode`` enum."""

    BIKE = "BIKE"
    PEDESTRIAN = "PEDESTRIAN"
    CAR = "CAR"
    BUS = "BUS"
    TRAIN = "TRAIN"
    TRAM = "TRAM"
    METRO = "METRO"


class Temperature(StrEnum):
    HIGH = "High"
    MEDIUM = "Medium"
    LOW = "Low"


class Weather(StrEnum):
    SUNNY = "sunny"
    CLOUDY = "cloudy"
    DRY = "dry"
    RAINY = "rainy"


class Purpose(StrEnum):
    WORK = "work"
    EDUCATION = "education"
    SHOPPING = "shopping"
    RECREATIONAL = "recreational"
    UNKNOWN = "unknown"


class HandlerInput(BaseModel):
    """Validated event payload for the flow-scaler Lambda handler.

    Required
    --------
    input_network_file
        S3 URL of the input GeoJSON network: ``s3://bucket/key``.
    output_network_file
        S3 URL where the resulting GeoJSON FeatureCollection will be written.
    output_network_format
        Format of the output file.  Currently only ``"ogc-geojson"`` is supported.
    mode
        Transport mode.  One of: ``BIKE``, ``PEDESTRIAN``, ``CAR``, ``BUS``,
        ``TRAIN``, ``TRAM``, ``METRO``.  Case-insensitive.
    regio
        Region identifier used for holiday-period lookup, e.g. ``"midden"``,
        ``"noord"``, ``"zuid"``.

    Optional
    --------
    purpose_index_file
        S3 URL of the purpose-index lookup table.  Each row has the form
        ``{"key": "motiv|MODE|day|hour|Temp|Weather", "index": float}``.
        When absent, all purpose-index factors default to ``1.0`` (raw flow).
    holiday_index_file
        S3 URL (or local path) for the holiday-indices CSV.  When absent,
        the ``INDICES_BUCKET`` / ``INDICES_KEY`` environment variables are used.
    daylight_file
        S3 URL of the monthly sunrise/sunset table used to distinguish
        *Light* vs *Dark* weather variants.
    date
        ISO-8601 datetime string.  When absent, no time-of-day index is applied.
    temperature
        Temperature bracket.  One of: ``high``, ``medium`` (default), ``low``.
    weather
        Weather condition.  One of: ``sunny``, ``cloudy`` (default), ``dry``, ``rainy``.
    purpose
        Trip-purpose filter.  One of: ``work``, ``education``, ``shopping``,
        ``recreational``, ``unknown``, ``all``.  ``all`` (or absent) sums all motives.
    bbox
        Bounding box in WGS-84: ``[minX, minY, maxX, maxY]``.
    limit
        Maximum number of features to return.  Range: 1–10 000.  Default: 100.
    offset
        Zero-based page start index.  Default: 0.
    base_url
        Base URL used to construct OGC pagination links.
    """

    model_config = ConfigDict(extra="ignore")

    input_network_file: str
    output_folder: str
    mode: Mode
    regio: str = Field(..., min_length=1, description="Region identifier for holiday lookup.")

    purpose_index_file: str | None = None
    holiday_index_file: str | None = None
    daylight_file: str | None = None
    date: str | None = None
    temperature: Temperature = Temperature.MEDIUM
    weather: Weather = Weather.CLOUDY
    purpose: Purpose | None = None
    bbox: list[float] | None = None
    limit: int = Field(default=100, ge=1, le=10000)
    offset: int = Field(default=0, ge=0)
    base_url: str | None = None
    run_cleaner: bool = Field(
        default=True,
        description=(
            "When True (default), strip all feature properties except ``flow`` and "
            "``linkId`` after scaling.  Set to False to retain all computed properties."
        ),
    )

    @field_validator("mode", mode="before")
    @classmethod
    def _mode_ci(cls, v: object) -> str:
        if v is None:
            raise ValueError("mode is required")
        return str(v).upper()

    @field_validator("temperature", mode="before")
    @classmethod
    def _temperature_ci(cls, v: object) -> str:
        if v is None:
            return Temperature.MEDIUM
        _MAP = {"high": "High", "medium": "Medium", "low": "Low"}
        key = str(v).lower()
        if key not in _MAP:
            raise ValueError(f"Invalid temperature {v!r}. Must be one of: high, medium, low")
        return _MAP[key]

    @field_validator("weather", mode="before")
    @classmethod
    def _weather_ci(cls, v: object) -> str:
        if v is None:
            return Weather.CLOUDY
        return str(v).lower()

    @field_validator("purpose", mode="before")
    @classmethod
    def _purpose_ci(cls, v: object) -> str | None:
        if not v or str(v).lower() == "all":
            return None
        return str(v).lower()

    @field_validator("bbox")
    @classmethod
    def _bbox_length(cls, v: list[float] | None) -> list[float] | None:
        if v is not None and len(v) not in (4, 6):
            raise ValueError("bbox must have exactly 4 or 6 numbers")
        return v

    @computed_field  # type: ignore[prop-decorator]
    @property
    def parsed_date(self) -> datetime.datetime | None:
        """Parse ``date`` into a timezone-aware datetime (Europe/Amsterdam); None when absent."""
        return parse_date(self.date)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def normalised_temperature(self) -> str:
        """Normalise temperature to the canonical string used in index keys."""
        return normalise_temperature(self.temperature)
