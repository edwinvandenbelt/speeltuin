"""
Core logic for link_based_staq_assigner.

Pure functions — no I/O, no boto3.  All parsing and assembly of GeoJSON / CSV
inputs and outputs lives here; the Lambda handler and local runner are thin
wrappers that handle I/O and call these functions.
"""

from __future__ import annotations

import csv
import io
from typing import Dict, List, Optional, Tuple

from .staq.config import Config, FundamentalDiagramType
from .staq.domain import LinkResult, Matrix
from .staq.model import run_staq
from .staq.network_builder import build_network
from shared.centroids import derive_centroids as _derive_centroids


# ---------------------------------------------------------------------------
# Output field definitions (authoritative)
# ---------------------------------------------------------------------------

STAQ_PROPERTIES: tuple[str, ...] = (
    "linkId",
    "fromNode",
    "toNode",
    "flow",
    "demand",
    "cost",
    "acceptanceFactor",
    "relativeDualityGap",
    "iterations",
)


# ---------------------------------------------------------------------------
# GeoJSON / CSV parsers  (pure, no I/O)
# ---------------------------------------------------------------------------

def parse_network_geojson(geojson: dict) -> Tuple[List[dict], Dict[str, dict]]:
    """
    Extract STAQ link elements and geometry lookup from a network GeoJSON.

    Returns
    -------
    (link_elements, geometry_by_link_id)
        link_elements         – list of dicts for build_network()
        geometry_by_link_id   – link id -> GeoJSON geometry object
    """
    elements: List[dict] = []
    geometries: Dict[str, dict] = {}

    for feat in geojson.get("features", []):
        props = feat.get("properties") or {}
        # Support both regular links (linkId, speed) and feedlinks (feedlinkId, no speed).
        # Feedlinks are centroid connectors and use a very high free-flow speed so they
        # contribute near-zero travel time and do not distort route costs.
        feature_type = props.get("type", "link")
        if feature_type == "feedlink":
            link_id = str(props["feedlinkId"])
            speed = 999.0  # virtual connector — effectively zero travel time
        else:
            link_id = str(props["linkId"])
            speed = float(props["speed"])

        elem: dict = {
            "dataType": "link",
            "properties": {
                "id":                       link_id,
                "fromNodeId":               str(props["fromNode"]),
                "toNodeId":                 str(props["toNode"]),
                "lengthInMeters":           float(props["length"]),
                "speedInKilometersPerHour": speed,
                "capacity":                 float(props["capacity"]),
            },
        }
        if "speedAtCapacityInKilometersPerHour" in props:
            elem["properties"]["speedAtCapacityInKilometersPerHour"] = float(
                props["speedAtCapacityInKilometersPerHour"]
            )
        if "preload" in props:
            elem["properties"]["preload"] = float(props["preload"])
        if "reverseLinkIds" in props:
            elem["properties"]["reverseLinkIds"] = list(props["reverseLinkIds"])

        elements.append(elem)

        if feat.get("geometry"):
            geometries[link_id] = feat["geometry"]

    return elements, geometries


def parse_feedlinks_as_centroids(
    feedlinks_geojson: dict,
) -> Tuple[List[dict], Dict[str, int], Dict[str, int]]:
    """
    Derive STAQ centroid elements from a feedlinks FeatureCollection.

    Internally calls ``feedlink_creator.derive_centroids`` to extract one
    centroid per zone from the feedlinks, then converts the result to the
    centroid elements + two index lookups required by the STAQ model.

    Returns
    -------
    (centroid_elements, zone_by_node_id, zone_index_by_zone_id)
        centroid_elements     – list of dicts for build_network()
        zone_by_node_id       – nodeId  -> zoneIndex (1-based)
        zone_index_by_zone_id – zoneId  -> zoneIndex (1-based)
    """
    centroids_fc = _derive_centroids(feedlinks_geojson)
    elements: List[dict] = []
    zone_by_node: Dict[str, int] = {}
    zone_index_by_zone_id: Dict[str, int] = {}

    for feat in centroids_fc.get("features", []):
        props = feat.get("properties") or {}
        node_id = str(props["nodeId"])
        zone_idx = int(props["zoneIndex"])
        zone_id = str(props.get("zoneId") or "")

        if node_id in zone_by_node:
            raise ValueError(f"Duplicate centroid nodeId {node_id!r} derived from feedlinks.")

        elements.append({
            "dataType": "centroid",
            "properties": {"nodeId": node_id, "zoneIndex": zone_idx},
        })
        zone_by_node[node_id] = zone_idx
        if zone_id:
            zone_index_by_zone_id[zone_id] = zone_idx

    return elements, zone_by_node, zone_index_by_zone_id


def parse_feedlinks_as_links(feedlinks_geojson: dict) -> List[dict]:
    """
    Convert a feedlinks FeatureCollection into STAQ link elements for ``build_network()``.

    Feedlinks connect virtual zone-centroid nodes to real network nodes and serve
    as the centroid connector links in the STAQ model.  They are given a very high
    free-flow speed (999 km/h) so they contribute near-zero travel time and do not
    distort generalised route costs.

    Returns
    -------
    link_elements
        List of ``{"dataType": "link", "properties": {...}}`` dicts, one per feedlink
        feature.  ``reverseLinkIds`` is forwarded when present so that step 4 of
        ``build_network`` can assign opposite links by ID rather than geometry.
    """
    elements: List[dict] = []
    for feat in feedlinks_geojson.get("features", []):
        props = feat.get("properties") or {}
        elem: dict = {
            "dataType": "link",
            "properties": {
                "id":                       str(props["feedlinkId"]),
                "fromNodeId":               str(props["fromNode"]),
                "toNodeId":                 str(props["toNode"]),
                "lengthInMeters":           float(props["length"]),
                "speedInKilometersPerHour": 999.0,
                "capacity":                 float(props["capacity"]),
                # Mark as virtual so build_network uses zero-cost connector constants.
                # Feedlinks are zone centroid connectors — they must not contribute to
                # generalised route costs (mirrors the zero-length virtual connectors in
                # the original Java STAQ model).
                "isVirtual":                True,
            },
        }
        if "reverseLinkIds" in props:
            elem["properties"]["reverseLinkIds"] = list(props["reverseLinkIds"])
        elements.append(elem)
    return elements


def parse_od_matrix_geojson(od_geojson: dict, zone_index_by_zone_id: Dict[str, int]) -> "Matrix":
    """
    Parse an OD matrix GeoJSON FeatureCollection into a STAQ demand Matrix.

    Each feature must have properties ``fromZoneId``, ``toZoneId``, and ``trips``.
    Features whose zone IDs are not in *zone_index_by_zone_id*, or whose trip
    count is zero / null, are silently skipped.

    Parameters
    ----------
    od_geojson:
        Parsed GeoJSON FeatureCollection (e.g. from od_matrix_completer output).
    zone_index_by_zone_id:
        ``{zoneId: zoneIndex}`` mapping as returned by
        :func:`parse_feedlinks_as_centroids`.

    Returns
    -------
    Matrix
        Populated STAQ demand matrix (1-indexed zones, 0-based internal storage).
    """
    n_zones = len(zone_index_by_zone_id)
    if n_zones == 0:
        raise ValueError("No centroids supplied; cannot build demand matrix.")

    matrix = Matrix(n_zones, n_zones)

    for feat in od_geojson.get("features", []):
        props = feat.get("properties") or {}
        from_zone = str(props.get("fromZoneId") or "").strip()
        to_zone = str(props.get("toZoneId") or "").strip()
        trips_raw = props.get("trips")

        if not from_zone or not to_zone or trips_raw is None:
            continue
        if from_zone not in zone_index_by_zone_id or to_zone not in zone_index_by_zone_id:
            continue

        trips = float(trips_raw)
        if trips > 0.0:
            origin_0 = zone_index_by_zone_id[from_zone] - 1
            dest_0 = zone_index_by_zone_id[to_zone] - 1
            matrix.set(origin_0, dest_0, trips)

    return matrix


def parse_matrix_csv(csv_text: str, zone_by_node: Dict[str, int]) -> Matrix:
    """
    Parse demand matrix CSV text (not a file path) into a Matrix.

    CSV format:
        Column 0  – origin node ID
        Columns 1+ – ``destinationNodeId:trips``

    Rows/columns whose node ID is not in zone_by_node are silently skipped.
    Rows starting with ``#`` are treated as comments.
    """
    n_zones = len(zone_by_node)
    if n_zones == 0:
        raise ValueError("No centroids supplied; cannot build demand matrix.")

    matrix = Matrix(n_zones, n_zones)

    reader = csv.reader(io.StringIO(csv_text))
    for row in reader:
        if not row:
            continue
        origin_raw = row[0].strip()
        if not origin_raw or origin_raw.startswith("#"):
            continue
        if origin_raw not in zone_by_node:
            continue  # header row or unknown node — skip

        origin_zone_0 = zone_by_node[origin_raw] - 1

        for cell in row[1:]:
            cell = cell.strip()
            if not cell:
                continue
            if ":" not in cell:
                raise ValueError(
                    f"Matrix CSV: expected 'nodeId:trips' in cell, got {cell!r} "
                    f"(origin row {origin_raw!r})."
                )
            dest_raw, trips_raw = cell.split(":", 1)
            dest_raw = dest_raw.strip()
            trips_raw = trips_raw.strip()

            if dest_raw not in zone_by_node:
                continue  # destination not in centroid list — skip

            dest_zone_0 = zone_by_node[dest_raw] - 1
            trips = float(trips_raw)
            if trips > 0.0:
                matrix.set(origin_zone_0, dest_zone_0, trips)

    return matrix


# ---------------------------------------------------------------------------
# Output GeoJSON builder
# ---------------------------------------------------------------------------

def build_output_geojson(
    network_geojson: dict,
    link_results: List[LinkResult],
    rdg: float,
    iterations: int,
) -> dict:
    """
    Merge assignment results back onto original link features.

    Links that carry zero demand still appear in the output with
    flow=0, demand=0, acceptanceFactor=1.  Properties ``relativeDualityGap``
    and ``iterations`` are written on every feature.
    """
    result_by_id = {lr.link_id: lr for lr in link_results}

    features = []
    for feat in network_geojson.get("features", []):
        props = dict(feat.get("properties") or {})
        # Resolve id from linkId (regular links) or feedlinkId (feedlinks).
        link_id = str(props.get("linkId") or props.get("feedlinkId", ""))

        lr = result_by_id.get(link_id)
        if lr is not None:
            props["flow"]             = lr.flow
            props["demand"]           = lr.demand
            props["cost"]             = lr.cost
            props["acceptanceFactor"] = lr.acceptance_factor
        else:
            props["flow"]             = 0.0
            props["demand"]           = 0.0
            props["acceptanceFactor"] = 1.0

        props["relativeDualityGap"] = rdg
        props["iterations"]         = iterations

        features.append({
            "type": "Feature",
            "geometry": feat.get("geometry"),
            "properties": props,
        })

    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"link_properties": list(STAQ_PROPERTIES)},
    }


# ---------------------------------------------------------------------------
# Top-level orchestrator
# ---------------------------------------------------------------------------

def run_assignment(
    network_geojson: dict,
    feedlinks_geojson: dict,
    od_matrix_geojson: dict,
    value_of_distance_per_km: float,
    value_of_time_per_hour: float,
    duration_hours: float,
    fundamental_diagram_type: str = "Newell",
    epsilon: float = 0.001,
    max_iterations: int = 100,
    fixed_point_epsilon: float = 0.0001,
    fixed_point_max_iterations: int = 10,
) -> Tuple[dict, dict]:
    """
    Parse inputs, build the network, run STAQ, and return enriched GeoJSON.

    Parameters
    ----------
    network_geojson       : parsed GeoJSON FeatureCollection of road links
    feedlinks_geojson     : parsed GeoJSON FeatureCollection of feedlinks
                            (centroids are derived from this automatically)
    od_matrix_geojson     : parsed GeoJSON FeatureCollection of OD pairs
                            (fromZoneId, toZoneId, trips per feature)
    value_of_distance_per_km : VoD (euros per km)
    value_of_time_per_hour   : VoT (euros per hour)
    duration_hours           : modelling period length in hours
    fundamental_diagram_type : "Newell" (default) or "QuadraticLinear"
    epsilon                  : RDG convergence threshold
    max_iterations           : outer loop limit
    fixed_point_epsilon      : fixed-point convergence threshold
    fixed_point_max_iterations : fixed-point iteration limit

    Returns
    -------
    (output_geojson, stats)
        output_geojson – enriched FeatureCollection
        stats          – dict with keys: nLinks, nCentroids, rdg, iterations
    """
    # Parse
    link_elements, _geometries = parse_network_geojson(network_geojson)
    feedlink_elements = parse_feedlinks_as_links(feedlinks_geojson)
    centroid_elements, _zone_by_node, zone_index_by_zone_id = parse_feedlinks_as_centroids(
        feedlinks_geojson
    )

    if not link_elements:
        raise ValueError("No links found in networkFile.")
    if not centroid_elements:
        raise ValueError("No centroids found in feedlinkFile.")

    # Build network — feedlinks are included as real links so their zone virtual
    # nodes are discovered in step 1; step 5 then just registers those nodes as
    # centroids without creating any additional virtual nodes or connector links.
    all_elements = link_elements + feedlink_elements + centroid_elements
    network = build_network(all_elements)

    # Demand matrix
    demand_matrix = parse_od_matrix_geojson(od_matrix_geojson, zone_index_by_zone_id)

    # Config
    try:
        fd_type = FundamentalDiagramType(fundamental_diagram_type)
    except ValueError:
        allowed = [e.value for e in FundamentalDiagramType]
        raise ValueError(
            f"Unknown fundamentalDiagramType {fundamental_diagram_type!r}. Allowed: {allowed}"
        )

    cfg = Config(
        value_of_distance_per_km=value_of_distance_per_km,
        value_of_time_per_hour=value_of_time_per_hour,
        fundamental_diagram_type=fd_type,
        duration_hours=duration_hours,
        epsilon=epsilon,
        max_iterations=max_iterations,
        fixed_point_epsilon=fixed_point_epsilon,
        fixed_point_max_iterations=fixed_point_max_iterations,
    )

    # Run
    link_results, rdg, iterations = run_staq(cfg, network, demand_matrix)

    # Build output
    output_geojson = build_output_geojson(network_geojson, link_results, rdg, iterations)

    stats = {
        "nLinks":      len(link_elements),
        "nCentroids":  len(network.centroids),
        "rdg":         rdg,
        "iterations":  iterations,
    }
    return output_geojson, stats
