"""Pure-Python selected-link analysis core — no I/O, no boto3.

For a given ``anchorLinkId``, finds all routes in a ROUTES GeoJSON that pass
through that link, aggregates the trips onto every link that those routes share,
and returns a SELECTEDLINK GeoJSON FeatureCollection that mirrors the NETWORK
format (one Feature per link) with ``flow`` and ``flow24h`` added.

Public API
----------
compute_selected_link(routes_fc, network_fc, anchor_link_id)
    Returns a GeoJSON FeatureCollection of link features with selected-link flows.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# Properties copied from the NETWORK link features into the output.
SELECTED_LINK_NETWORK_PROPERTIES: tuple[str, ...] = (
    "linkId",
    "fromNode",
    "toNode",
    "speed",
    "capacity",
    "length",
    "modes",
)

# Properties written on every output feature.
SELECTED_LINK_PROPERTIES: tuple[str, ...] = (
    *SELECTED_LINK_NETWORK_PROPERTIES,
    "flow",
    "flow24h",
)


def compute_selected_link(
    routes_fc: dict,
    network_fc: dict,
    anchor_link_id: str,
) -> dict:
    """Compute selected-link flows for *anchor_link_id*.

    For every OD-pair feature in *routes_fc* the function iterates over all
    ``routes`` sub-objects.  A route is included when ``anchor_link_id``
    appears in its ``linkPath``.  The route's ``trips`` value is accumulated
    onto each link in that route's ``linkPath``.

    The resulting per-link trip totals are joined to the *network_fc* geometry
    and properties, producing a FeatureCollection that contains only the links
    with a non-zero selected-link flow.

    Parameters
    ----------
    routes_fc:
        GeoJSON FeatureCollection produced by ``route_explorer`` or
        ``matrix_builder``.  Each feature must have ``properties.tripFraction``
        and ``properties.routes`` (list of route objects with ``trips`` and
        ``linkPath``).
    network_fc:
        GeoJSON FeatureCollection of directed network link features.  Each
        feature must have ``properties.linkId``.
    anchor_link_id:
        The ``linkId`` of the selected link.  Only routes that include this
        link contribute to the output flows.

    Returns
    -------
    dict
        GeoJSON FeatureCollection.  ``$.properties`` inherits ``modes``,
        ``area_id``, and ``selectedLinkId``.  Each feature carries the properties
        listed in ``SELECTED_LINK_PROPERTIES``.
    """
    anchor_link_id = str(anchor_link_id)

    # ------------------------------------------------------------------
    # Step 1 — accumulate trips per linkId from qualifying routes
    # ------------------------------------------------------------------
    link_flow: dict[str, float] = {}

    od_features = routes_fc.get("features") or []
    for od_feat in od_features:
        props = od_feat.get("properties") or {}
        routes = props.get("routes") or []
        for route in routes:
            link_path: list[str] = [str(lid) for lid in (route.get("linkPath") or [])]
            if anchor_link_id not in link_path:
                continue
            trips = float(route.get("trips") or 0.0)
            if trips == 0.0:
                continue
            for lid in link_path:
                link_flow[lid] = link_flow.get(lid, 0.0) + trips

    if not link_flow:
        logger.warning(
            "No routes found that pass through anchor link %r — output will be empty.",
            anchor_link_id,
        )

    # ------------------------------------------------------------------
    # Step 2 — build a lookup: linkId → network feature
    # ------------------------------------------------------------------
    network_index: dict[str, dict] = {}
    for feat in network_fc.get("features") or []:
        lid = str((feat.get("properties") or {}).get("linkId") or "")
        if lid:
            network_index[lid] = feat

    # ------------------------------------------------------------------
    # Step 3 — join flows to network geometry
    # ------------------------------------------------------------------
    out_features: list[dict] = []
    missing: list[str] = []

    for lid, flow in sorted(link_flow.items(), key=lambda x: -x[1]):
        net_feat = network_index.get(lid)
        if net_feat is None:
            missing.append(lid)
            continue

        net_props = net_feat.get("properties") or {}
        out_props: dict = {
            k: net_props.get(k)
            for k in SELECTED_LINK_NETWORK_PROPERTIES
        }
        out_props["flow"] = round(flow, 6)
        out_props["flow24h"] = round(flow, 6)  # 24-hour total equals the summed trips

        out_features.append({
            "type": "Feature",
            "geometry": net_feat.get("geometry"),
            "properties": out_props,
        })

    if missing:
        logger.warning(
            "%d links with selected-link flow have no matching network feature: %s%s",
            len(missing),
            ", ".join(missing[:10]),
            " …" if len(missing) > 10 else "",
        )

    net_props_top = network_fc.get("properties") or {}
    out_fc: dict = {
        "type": "FeatureCollection",
        "features": out_features,
        "properties": {
            "area_id":       net_props_top.get("area_id"),
            "modes":         net_props_top.get("modes") or [],
            "selectedLinkId": anchor_link_id,
            "link_properties": list(SELECTED_LINK_PROPERTIES),
        },
    }

    logger.info(
        "Selected-link analysis complete: anchor=%r, qualifying routes from %d OD pairs, "
        "%d links with flow, %d output features.",
        anchor_link_id,
        sum(
            1 for f in od_features
            if any(
                anchor_link_id in [str(l) for l in (r.get("linkPath") or [])]
                for r in (f.get("properties") or {}).get("routes") or []
            )
        ),
        len(link_flow),
        len(out_features),
    )

    return out_fc
