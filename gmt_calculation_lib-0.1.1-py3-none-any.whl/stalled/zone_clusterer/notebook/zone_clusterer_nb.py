# Databricks notebook source
# ---------------------------------------------------------------------------
# zone_clusterer_nb.py — Databricks notebook interface for zone_clusterer.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads zones + feedlinks + network GeoJSON from S3 (or local paths).
#   3. Calls pure core clustering logic — no Spark I/O.
#   4. Overwrites zones and feedlinks back to the same S3 keys.
#   5. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("zone_clusterer_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "zones_uri", "",
    "Full URI of the zones GeoJSON (s3://bucket/key or local path) — will be overwritten.",
)
dbutils.widgets.text(  # noqa: F821
    "feedlinks_uri", "",
    "Full URI of the feedlinks GeoJSON (s3://bucket/key or local path) — will be overwritten.",
)
dbutils.widgets.text(  # noqa: F821
    "network_uri", "",
    "Full URI of the network GeoJSON (read-only, for 80 km/h road check).",
)
dbutils.widgets.text(  # noqa: F821
    "max_distance_m", "1000",
    "Maximum centroid-to-centroid distance (m) to merge zones into a cluster.",
)
dbutils.widgets.text(  # noqa: F821
    "max_cluster_size", "6",
    "Maximum number of constituent zones per cluster.",
)
dbutils.widgets.text(  # noqa: F821
    "speed_threshold", "80",
    "Road speed (km/h) above which crossing triggers a warning.",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from zone_clusterer.core.zone_clusterer_core import cluster_zones  # noqa: E402, F821

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

ZONES_URI     = dbutils.widgets.get("zones_uri").strip()      # noqa: F821
FEEDLINKS_URI = dbutils.widgets.get("feedlinks_uri").strip()  # noqa: F821
NETWORK_URI   = dbutils.widgets.get("network_uri").strip()    # noqa: F821

if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty.")
if not FEEDLINKS_URI:
    raise ValueError("Widget 'feedlinks_uri' is empty.")
if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")

MAX_DISTANCE_M   = float(dbutils.widgets.get("max_distance_m")   or "1000")   # noqa: F821
MAX_CLUSTER_SIZE = int(dbutils.widgets.get("max_cluster_size")   or "6")       # noqa: F821
SPEED_THRESHOLD  = float(dbutils.widgets.get("speed_threshold")  or "80")     # noqa: F821

logger.info(
    "zones_uri=%s  feedlinks_uri=%s  network_uri=%s  "
    "max_distance_m=%.0f  max_cluster_size=%d  speed_threshold=%.0f",
    ZONES_URI, FEEDLINKS_URI, NETWORK_URI,
    MAX_DISTANCE_M, MAX_CLUSTER_SIZE, SPEED_THRESHOLD,
)

# COMMAND ----------
# ── S3 / local helpers ─────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415
import os  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run ZoneClusterer
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)

print(f"Starting  {_t_start.isoformat()}")
print(f"Zones URI     : {ZONES_URI}")
print(f"Feedlinks URI : {FEEDLINKS_URI}")
print(f"Network URI   : {NETWORK_URI}")
print(f"max_distance_m: {MAX_DISTANCE_M}")
print()

_zones_fc    = json.loads(_read_uri(ZONES_URI))
_feedlinks_fc = json.loads(_read_uri(FEEDLINKS_URI))
_network_fc  = json.loads(_read_uri(NETWORK_URI))

_out_zones_fc, _out_feedlinks_fc, _stats = cluster_zones(
    _zones_fc,
    _feedlinks_fc,
    _network_fc,
    max_distance_m=MAX_DISTANCE_M,
    max_cluster_size=MAX_CLUSTER_SIZE,
    speed_threshold=SPEED_THRESHOLD,
)

_write_uri(ZONES_URI,    json.dumps(_out_zones_fc,    ensure_ascii=False).encode("utf-8"))
_write_uri(FEEDLINKS_URI, json.dumps(_out_feedlinks_fc, ensure_ascii=False).encode("utf-8"))

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"ZoneClusterer complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Input zones      : {_stats['input_zones']}")
print(f"  Input feedlinks  : {_stats['input_feedlinks']}")
print(f"  Clusters         : {_stats['clusters']}")
print(f"  Merged agg zones : {_stats['merged_agg_zones']}")
print(f"  Passthru agg zones: {_stats['passthru_agg_zones']}")
print(f"  Output zones     : {_stats['output_zones']}")
print(f"  Output feedlinks : {_stats['output_feedlinks']}")
print(_SEP)
