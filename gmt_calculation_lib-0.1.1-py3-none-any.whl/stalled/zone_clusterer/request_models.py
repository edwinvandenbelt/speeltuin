"""Request model helpers for zone_clusterer."""

from __future__ import annotations


def parse_inputs(inputs: dict) -> tuple:
    """Extract and validate inputs dict.  Returns (zones_uri, feedlinks_uri, network_uri,
    max_distance_m, max_cluster_size, speed_threshold).
    """
    zones_uri    = inputs.get("zonesUri")
    feedlinks_uri = inputs.get("feedlinksUri")
    network_uri  = inputs.get("networkUri")
    max_distance_m = inputs.get("maxDistanceM")

    if not zones_uri:
        raise ValueError("inputs.zonesUri is required.")
    if not feedlinks_uri:
        raise ValueError("inputs.feedlinksUri is required.")
    if not network_uri:
        raise ValueError("inputs.networkUri is required.")
    if max_distance_m is None:
        raise ValueError("inputs.maxDistanceM is required.")

    max_distance_m   = float(max_distance_m)
    max_cluster_size = int(inputs.get("maxClusterSize") or 6)
    speed_threshold  = float(inputs.get("speedThresholdKmh") or 80.0)

    return zones_uri, feedlinks_uri, network_uri, max_distance_m, max_cluster_size, speed_threshold
