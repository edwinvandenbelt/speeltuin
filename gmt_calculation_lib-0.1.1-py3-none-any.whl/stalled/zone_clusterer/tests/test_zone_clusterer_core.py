"""Unit tests for zone_clusterer.zone_clusterer_core.

All tests are pure — no boto3, no Databricks, no network calls.
"""

from __future__ import annotations

import math
import pytest

from zone_clusterer.core.zone_clusterer_core import (
    _cluster_aggregate_zones,
    _feedlink_crosses_high_speed,
    _merge_cluster,
    _parse_high_speed_segments,
    _reroute_feedlinks,
    _segments_intersect,
    cluster_zones,
)


# ---------------------------------------------------------------------------
# Helpers / factories
# ---------------------------------------------------------------------------

def _agg_zone(
    gid: int,
    lon: float,
    lat: float,
    production: float = 500.0,
    attraction: float = 500.0,
    sector: int = 0,
    zone_id: str | None = None,
) -> dict:
    return {
        "gid":              gid,
        "zoneId":           zone_id or f"cross_{gid}",
        "zoneName":         f"Boundary {gid}",
        "zoneType":         "aggregate",
        "ringIndex":        0,
        "ringLabel":        "bbox-boundary",
        "sectorIndex":      sector,
        "constituentZoneIds": [],
        "centroidLon":      lon,
        "centroidLat":      lat,
        "production":       production,
        "attraction":       attraction,
        "nodeId":           f"N{gid}",
        "mode":             "CAR",
        "nCrossingLinks":   2,
    }


def _inner_zone(gid: int) -> dict:
    return {
        "gid":          gid,
        "zoneId":       f"zone_{gid}",
        "zoneName":     f"Inner {gid}",
        "zoneType":     "inner",
        "centroidLon":  5.1,
        "centroidLat":  52.1,
        "production":   100.0,
        "attraction":   100.0,
    }


def _zone_feat(props: dict) -> dict:
    return {
        "type":       "Feature",
        "geometry":   {"type": "Polygon", "coordinates": [[[0, 0], [1, 0], [1, 1], [0, 0]]]},
        "properties": props,
    }


def _feedlink_feat(
    fid: int,
    zone_id: str,
    from_node: str,
    to_node: str,
    from_coords: list,
    to_coords: list,
    capacity: float = 5000.0,
    ring_index: int = 0,
    flow: float = 0.0,
) -> dict:
    return {
        "type":     "Feature",
        "geometry": {"type": "LineString", "coordinates": [from_coords, to_coords]},
        "properties": {
            "feedlinkId":     fid,
            "reverseLinkIds": [],
            "zoneId":         zone_id,
            "fromNode":       from_node,
            "toNode":         to_node,
            "length":         1000.0,
            "capacity":       capacity,
            "flow":           flow,
            "mode":           "CAR",
            "ringIndex":      ring_index,
            "ringLabel":      "bbox-boundary",
            "sectorIndex":    0,
            "type":           "feedlink",
        },
    }


def _network_link_feat(
    from_coords: list,
    to_coords: list,
    speed: float = 50.0,
) -> dict:
    return {
        "type":     "Feature",
        "geometry": {"type": "LineString", "coordinates": [from_coords, to_coords]},
        "properties": {
            "fromNode": "netA",
            "toNode":   "netB",
            "speed":    speed,
            "capacity": 3600.0,
            "flow24hrs": 10000.0,
        },
    }


# ---------------------------------------------------------------------------
# _segments_intersect
# ---------------------------------------------------------------------------

class TestSegmentsIntersect:
    def test_crossing_segments(self):
        # + shape — segments cross in the middle
        assert _segments_intersect((0, 0), (2, 2), (0, 2), (2, 0))

    def test_parallel_horizontal(self):
        assert not _segments_intersect((0, 0), (1, 0), (0, 1), (1, 1))

    def test_t_junction_does_not_count(self):
        # T-junction: one segment's endpoint lies on the other (open interval check)
        assert not _segments_intersect((0, 0), (1, 0), (0.5, 0), (0.5, 1))

    def test_no_crossing(self):
        # Same direction, no overlap
        assert not _segments_intersect((0, 0), (1, 0), (2, 0), (3, 0))

    def test_collinear_overlapping(self):
        # Collinear segments — rxs ≈ 0, treated as non-crossing
        assert not _segments_intersect((0, 0), (2, 0), (1, 0), (3, 0))


# ---------------------------------------------------------------------------
# _parse_high_speed_segments
# ---------------------------------------------------------------------------

class TestParseHighSpeedSegments:
    def test_selects_over_threshold(self):
        fc = {
            "features": [
                _network_link_feat([0.0, 0.0], [1.0, 0.0], speed=50.0),
                _network_link_feat([0.0, 1.0], [1.0, 1.0], speed=90.0),
                _network_link_feat([0.0, 2.0], [1.0, 2.0], speed=80.0),  # equal — not selected
            ]
        }
        segs = _parse_high_speed_segments(fc, speed_threshold=80.0)
        assert len(segs) == 1
        assert segs[0] == ((0.0, 1.0), (1.0, 1.0))

    def test_empty_network(self):
        assert _parse_high_speed_segments({"features": []}) == []

    def test_multivertex_link_produces_multiple_segs(self):
        feat = {
            "type":     "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0], [2, 0]]},
            "properties": {"speed": 100.0},
        }
        segs = _parse_high_speed_segments({"features": [feat]}, speed_threshold=80.0)
        assert len(segs) == 2


# ---------------------------------------------------------------------------
# _feedlink_crosses_high_speed
# ---------------------------------------------------------------------------

class TestFeedlinkCrossesHighSpeed:
    def test_crossing(self):
        # Feedlink: (0,1) -> (2,1); high-speed road: (1,0) -> (1,2) — they cross
        segs = [((1.0, 0.0), (1.0, 2.0))]
        assert _feedlink_crosses_high_speed(0.0, 1.0, 2.0, 1.0, segs)

    def test_not_crossing(self):
        segs = [((3.0, 0.0), (3.0, 2.0))]
        assert not _feedlink_crosses_high_speed(0.0, 1.0, 2.0, 1.0, segs)

    def test_empty_segs(self):
        assert not _feedlink_crosses_high_speed(0.0, 0.0, 1.0, 1.0, [])


# ---------------------------------------------------------------------------
# _cluster_aggregate_zones
# ---------------------------------------------------------------------------

class TestClusterAggregateZones:
    def test_empty(self):
        assert _cluster_aggregate_zones([], 1000.0) == []

    def test_single_zone_becomes_singleton_cluster(self):
        z = _agg_zone(1, 5.0, 52.0)
        clusters = _cluster_aggregate_zones([z], max_distance_m=1000.0)
        assert len(clusters) == 1
        assert clusters[0] == [z]

    def test_two_close_zones_merge(self):
        # Two zones ~100 m apart (same lat, ~0.001° lon apart ≈ 70 m)
        z1 = _agg_zone(1, 5.000, 52.0)
        z2 = _agg_zone(2, 5.001, 52.0)
        clusters = _cluster_aggregate_zones([z1, z2], max_distance_m=500.0)
        assert len(clusters) == 1
        assert len(clusters[0]) == 2

    def test_two_far_zones_stay_separate(self):
        z1 = _agg_zone(1, 5.0, 52.0)
        z2 = _agg_zone(2, 6.0, 53.0)  # ~140 km away
        clusters = _cluster_aggregate_zones([z1, z2], max_distance_m=500.0)
        assert len(clusters) == 2

    def test_max_cluster_size_respected(self):
        # 4 zones all very close; max_cluster_size=2 → 2 clusters of 2
        zones = [_agg_zone(i, 5.0 + i * 0.0001, 52.0) for i in range(4)]
        clusters = _cluster_aggregate_zones(zones, max_distance_m=5000.0, max_cluster_size=2)
        assert all(len(c) <= 2 for c in clusters)
        assert sum(len(c) for c in clusters) == 4

    def test_three_zones_two_close_one_far(self):
        z1 = _agg_zone(1, 5.000, 52.0)
        z2 = _agg_zone(2, 5.001, 52.0)   # ~70 m from z1
        z3 = _agg_zone(3, 6.000, 52.0)   # ~70 km from z1/z2
        clusters = _cluster_aggregate_zones([z1, z2, z3], max_distance_m=500.0)
        assert len(clusters) == 2
        sizes = sorted(len(c) for c in clusters)
        assert sizes == [1, 2]


# ---------------------------------------------------------------------------
# _merge_cluster
# ---------------------------------------------------------------------------

class TestMergeCluster:
    def test_basic_merge(self):
        z1 = _agg_zone(1, 5.0, 52.0, production=1000.0, attraction=500.0)
        z2 = _agg_zone(2, 5.1, 52.1, production=500.0,  attraction=1000.0)
        merged = _merge_cluster([z1, z2], new_gid=999)
        assert merged["gid"] == 999
        assert merged["zoneId"] == "cluster_999"
        assert merged["zoneType"] == "aggregate"
        assert merged["production"] == pytest.approx(1500.0)
        assert merged["attraction"] == pytest.approx(1500.0)
        assert merged["constituentZoneIds"] == [1, 2]
        assert merged["nCrossingLinks"] == 4

    def test_weighted_centroid(self):
        # z1 at lon=5.0, production+attraction=100; z2 at lon=7.0, p+a=300
        # expected centroid = (5.0*100 + 7.0*300) / 400 = 6.5
        z1 = _agg_zone(1, 5.0, 52.0, production=50.0,  attraction=50.0)
        z2 = _agg_zone(2, 7.0, 52.0, production=150.0, attraction=150.0)
        merged = _merge_cluster([z1, z2], new_gid=100)
        assert merged["centroidLon"] == pytest.approx(6.5)

    def test_zero_weight_uses_simple_mean(self):
        z1 = _agg_zone(1, 5.0, 52.0, production=0.0, attraction=0.0)
        z2 = _agg_zone(2, 7.0, 52.0, production=0.0, attraction=0.0)
        merged = _merge_cluster([z1, z2], new_gid=100)
        assert merged["centroidLon"] == pytest.approx(6.0)


# ---------------------------------------------------------------------------
# _reroute_feedlinks
# ---------------------------------------------------------------------------

class TestRerouteFeedlinks:
    def _make_cluster_props(self) -> dict:
        return {
            "gid":         999,
            "zoneId":      "cluster_999",
            "centroidLon": 5.05,
            "centroidLat": 52.05,
            "ringIndex":   0,
            "ringLabel":   "bbox-boundary",
            "sectorIndex": 0,
            "mode":        "CAR",
            "production":  1200.0,
            "attraction":   800.0,
        }

    def _make_constituent_feedlinks(self) -> list[dict]:
        """Two constituent zones: gid=1 (→ N1), gid=2 (→ N2)."""
        return [
            # zone gid=1 production: fromNode="1" → toNode="N1"
            _feedlink_feat(1, "cross_1", "1", "N1", [5.0, 52.0], [5.1, 52.0], capacity=3000.0, flow=300.0),
            # zone gid=1 attraction: fromNode="N1" → toNode="1"
            _feedlink_feat(2, "cross_1", "N1", "1", [5.1, 52.0], [5.0, 52.0], capacity=2500.0, flow=200.0),
            # zone gid=2 production: fromNode="2" → toNode="N2"
            _feedlink_feat(3, "cross_2", "2", "N2", [5.0, 52.1], [5.1, 52.1], capacity=4000.0, flow=400.0),
            # zone gid=2 attraction: fromNode="N2" → toNode="2"
            _feedlink_feat(4, "cross_2", "N2", "2", [5.1, 52.1], [5.0, 52.1], capacity=3500.0, flow=350.0),
        ]

    def test_correct_number_of_feedlinks(self):
        cluster_props           = self._make_cluster_props()
        constituent_feedlinks   = self._make_constituent_feedlinks()
        constituent_gid_strings = {"1", "2"}
        records, next_fid = _reroute_feedlinks(
            cluster_props, constituent_feedlinks, constituent_gid_strings,
            high_speed_segs=[], fid_start=10,
        )
        # 2 network nodes (N1, N2) × 2 directions = 4 feedlinks
        assert len(records) == 4

    def test_feedlinks_use_cluster_zone_id(self):
        cluster_props         = self._make_cluster_props()
        constituent_feedlinks = self._make_constituent_feedlinks()
        records, _            = _reroute_feedlinks(
            cluster_props, constituent_feedlinks, {"1", "2"}, [], fid_start=10,
        )
        assert all(r["properties"]["zoneId"] == "cluster_999" for r in records)

    def test_production_feedlink_from_node_is_cluster_virtual_node(self):
        cluster_props         = self._make_cluster_props()
        constituent_feedlinks = self._make_constituent_feedlinks()
        records, _ = _reroute_feedlinks(
            cluster_props, constituent_feedlinks, {"1", "2"}, [], fid_start=10,
        )
        # cluster virtual node id = str(gid) = "999"
        prod_records = [
            r for r in records
            if r["properties"]["fromNode"] == "999"
        ]
        assert len(prod_records) == 2  # one per network node

    def test_attraction_feedlink_to_node_is_cluster_virtual_node(self):
        cluster_props         = self._make_cluster_props()
        constituent_feedlinks = self._make_constituent_feedlinks()
        records, _ = _reroute_feedlinks(
            cluster_props, constituent_feedlinks, {"1", "2"}, [], fid_start=10,
        )
        attr_records = [
            r for r in records
            if r["properties"]["toNode"] == "999"
        ]
        assert len(attr_records) == 2

    def test_reverse_link_ids_wired(self):
        cluster_props         = self._make_cluster_props()
        constituent_feedlinks = self._make_constituent_feedlinks()
        records, _ = _reroute_feedlinks(
            cluster_props, constituent_feedlinks, {"1", "2"}, [], fid_start=10,
        )
        for r in records:
            assert len(r["properties"]["reverseLinkIds"]) == 1

    def test_deduplication_same_node_from_two_constituents(self):
        # Both constituent zones point to the same network node N1
        cluster_props = self._make_cluster_props()
        feedlinks = [
            _feedlink_feat(1, "cross_1", "1", "N1", [5.0, 52.0], [5.1, 52.0]),
            _feedlink_feat(2, "cross_1", "N1", "1", [5.1, 52.0], [5.0, 52.0]),
            _feedlink_feat(3, "cross_2", "2", "N1", [5.0, 52.1], [5.1, 52.0]),  # same N1
            _feedlink_feat(4, "cross_2", "N1", "2", [5.1, 52.0], [5.0, 52.1]),  # same N1
        ]
        records, _ = _reroute_feedlinks(
            cluster_props, feedlinks, {"1", "2"}, [], fid_start=10,
        )
        # Should deduplicate: only 1 node (N1) → 2 feedlinks (prod + attr)
        assert len(records) == 2

    def test_capacity_uses_max(self):
        """When two constituents share the same network node, max capacity is used."""
        cluster_props = self._make_cluster_props()
        feedlinks = [
            _feedlink_feat(1, "cross_1", "1", "N1", [5.0, 52.0], [5.1, 52.0], capacity=3000.0),
            _feedlink_feat(2, "cross_2", "2", "N1", [5.0, 52.1], [5.1, 52.0], capacity=5000.0),
        ]
        records, _ = _reroute_feedlinks(
            cluster_props, feedlinks, {"1", "2"}, [], fid_start=10,
        )
        prod_records = [r for r in records if r["properties"]["fromNode"] == "999"]
        assert len(prod_records) == 1
        assert prod_records[0]["properties"]["capacity"] == pytest.approx(5000.0)

    def test_production_feedlink_flow_equals_original_zone_flow(self):
        """Production feedlinks carry the original constituent zone's capacity (= production)."""
        cluster_props         = self._make_cluster_props()  # production=1200, attraction=800
        constituent_feedlinks = self._make_constituent_feedlinks()
        records, _ = _reroute_feedlinks(
            cluster_props, constituent_feedlinks, {"1", "2"}, [], fid_start=10,
        )
        prod_records = [r for r in records if r["properties"]["fromNode"] == "999"]
        assert prod_records, "expected production feedlinks"
        caps = {r["properties"]["toNode"]: r["properties"]["capacity"] for r in prod_records}
        assert caps["N1"] == pytest.approx(3000.0)
        assert caps["N2"] == pytest.approx(4000.0)

    def test_attraction_feedlink_flow_equals_original_zone_flow(self):
        """Attraction feedlinks carry the original constituent zone's capacity (= attraction)."""
        cluster_props         = self._make_cluster_props()  # production=1200, attraction=800
        constituent_feedlinks = self._make_constituent_feedlinks()
        records, _ = _reroute_feedlinks(
            cluster_props, constituent_feedlinks, {"1", "2"}, [], fid_start=10,
        )
        attr_records = [r for r in records if r["properties"]["toNode"] == "999"]
        assert attr_records, "expected attraction feedlinks"
        caps = {r["properties"]["fromNode"]: r["properties"]["capacity"] for r in attr_records}
        assert caps["N1"] == pytest.approx(2500.0)
        assert caps["N2"] == pytest.approx(3500.0)


# ---------------------------------------------------------------------------
# cluster_zones  (integration / end-to-end)
# ---------------------------------------------------------------------------

class TestClusterZones:
    """End-to-end tests on the public cluster_zones() function."""

    def _make_two_close_agg_zones(self) -> tuple[dict, dict, dict]:
        """Two aggregate zones ~70 m apart with prod+attr feedlinks each."""
        z1_props = _agg_zone(101, 5.000, 52.0, zone_id="cross_101")
        z2_props = _agg_zone(102, 5.001, 52.0, zone_id="cross_102")

        zones_fc = {
            "type": "FeatureCollection",
            "features": [
                _zone_feat(_inner_zone(1)),
                _zone_feat(z1_props),
                _zone_feat(z2_props),
            ],
            "properties": {"link_properties": ["gid", "zoneId"]},
        }

        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": [
                # inner zone feedlink (should pass through)
                _feedlink_feat(0, "zone_1", "1", "netX", [5.0, 52.0], [5.05, 52.0], ring_index=-1),
                # z1 production + attraction
                _feedlink_feat(1, "cross_101", "101", "N101", [5.000, 52.0], [5.05, 52.0]),
                _feedlink_feat(2, "cross_101", "N101", "101", [5.05, 52.0], [5.000, 52.0]),
                # z2 production + attraction
                _feedlink_feat(3, "cross_102", "102", "N102", [5.001, 52.0], [5.05, 52.0]),
                _feedlink_feat(4, "cross_102", "N102", "102", [5.05, 52.0], [5.001, 52.0]),
            ],
            "properties": {"link_properties": ["feedlinkId"]},
        }

        network_fc = {
            "type": "FeatureCollection",
            "features": [_network_link_feat([5.0, 52.0], [5.1, 52.0], speed=50.0)],
        }

        return zones_fc, feedlinks_fc, network_fc

    def test_inner_zones_and_feedlinks_pass_through(self):
        zones_fc, feedlinks_fc, network_fc = self._make_two_close_agg_zones()
        out_z, out_fl, stats = cluster_zones(
            zones_fc, feedlinks_fc, network_fc, max_distance_m=500.0
        )
        # Inner zone preserved
        inner = [f for f in out_z["features"] if f["properties"]["zoneType"] == "inner"]
        assert len(inner) == 1
        assert inner[0]["properties"]["zoneId"] == "zone_1"
        # Inner feedlink preserved
        inner_fl = [
            f for f in out_fl["features"]
            if f["properties"].get("ringIndex") == -1
        ]
        assert len(inner_fl) == 1

    def test_two_close_zones_produce_one_cluster_zone(self):
        zones_fc, feedlinks_fc, network_fc = self._make_two_close_agg_zones()
        out_z, out_fl, stats = cluster_zones(
            zones_fc, feedlinks_fc, network_fc, max_distance_m=500.0
        )
        agg = [f for f in out_z["features"] if f["properties"]["zoneType"] == "aggregate"]
        assert len(agg) == 1
        props = agg[0]["properties"]
        assert props["zoneId"].startswith("cluster_")
        assert set(props["constituentZoneIds"]) == {101, 102}

    def test_cluster_zone_has_correct_feedlink_count(self):
        zones_fc, feedlinks_fc, network_fc = self._make_two_close_agg_zones()
        out_z, out_fl, stats = cluster_zones(
            zones_fc, feedlinks_fc, network_fc, max_distance_m=500.0
        )
        cluster_id = next(
            f["properties"]["zoneId"]
            for f in out_z["features"]
            if f["properties"]["zoneType"] == "aggregate"
        )
        cluster_fls = [
            f for f in out_fl["features"]
            if f["properties"]["zoneId"] == cluster_id
        ]
        # N101 and N102 → 2 nodes × 2 directions = 4 feedlinks
        assert len(cluster_fls) == 4

    def test_stats_are_correct(self):
        zones_fc, feedlinks_fc, network_fc = self._make_two_close_agg_zones()
        _, _, stats = cluster_zones(
            zones_fc, feedlinks_fc, network_fc, max_distance_m=500.0
        )
        assert stats["input_zones"]      == 3
        assert stats["input_feedlinks"]  == 5
        assert stats["clusters"]         == 1
        assert stats["merged_agg_zones"] == 2
        assert stats["passthru_agg_zones"] == 0

    def test_two_far_zones_both_pass_through(self):
        z1_props = _agg_zone(101, 5.0, 52.0, zone_id="cross_101")
        z2_props = _agg_zone(102, 6.5, 53.5, zone_id="cross_102")  # ~200 km away
        zones_fc = {
            "type": "FeatureCollection",
            "features": [_zone_feat(z1_props), _zone_feat(z2_props)],
            "properties": {},
        }
        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": [
                _feedlink_feat(1, "cross_101", "101", "N1", [5.0, 52.0], [5.05, 52.0]),
                _feedlink_feat(2, "cross_102", "102", "N2", [6.5, 53.5], [6.55, 53.5]),
            ],
            "properties": {},
        }
        network_fc = {"type": "FeatureCollection", "features": []}
        out_z, out_fl, stats = cluster_zones(
            zones_fc, feedlinks_fc, network_fc, max_distance_m=500.0
        )
        assert stats["clusters"] == 2
        assert stats["passthru_agg_zones"] == 2
        assert len(out_z["features"]) == 2   # both kept unchanged
        assert len(out_fl["features"]) == 2  # original feedlinks kept

    def test_empty_zones_fc(self):
        zones_fc    = {"type": "FeatureCollection", "features": [], "properties": {}}
        feedlinks_fc = {"type": "FeatureCollection", "features": [], "properties": {}}
        network_fc  = {"type": "FeatureCollection", "features": []}
        out_z, out_fl, stats = cluster_zones(
            zones_fc, feedlinks_fc, network_fc, max_distance_m=1000.0
        )
        assert out_z["features"]  == []
        assert out_fl["features"] == []
        assert stats["clusters"]  == 0
