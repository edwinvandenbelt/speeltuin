"""Local debug runner for zone_clusterer.

Reads zones + feedlinks + network GeoJSON, runs zone clustering, and
overwrites the zones and feedlinks files in place.

Usage
-----
    python -m zone_clusterer.zone_clusterer_runner \\
        --zones    path/to/{area_id}-ZONE-CAR.geojson \\
        --feedlinks path/to/{area_id}-FEEDLINK-CAR.geojson \\
        --network  path/to/{area_id}-NETWORK-CAR.geojson \\
        --max-distance-m 1000

    # S3 URIs are also accepted:
    python -m zone_clusterer.zone_clusterer_runner \\
        --zones    s3://gmp-networks/zones/abc-ZONE-CAR.geojson \\
        --feedlinks s3://gmp-networks/zones/abc-FEEDLINK-CAR.geojson \\
        --network  s3://gmp-networks/network/abc-NETWORK-CAR.geojson \\
        --max-distance-m 1000

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for zone_clusterer. "
            "Clusters nearby aggregate zones and overwrites the zone + feedlink files."
        )
    )
    parser.add_argument(
        "--zones",
        required=True,
        metavar="URI",
        help="URI of the zones GeoJSON (read + overwrite; s3:// or local path).",
    )
    parser.add_argument(
        "--feedlinks",
        required=True,
        metavar="URI",
        help="URI of the feedlinks GeoJSON (read + overwrite; s3:// or local path).",
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="URI of the network GeoJSON (read-only; used for 80 km/h road detection).",
    )
    parser.add_argument(
        "--max-distance-m",
        type=float,
        required=True,
        metavar="FLOAT",
        help="Maximum centroid-to-centroid distance in metres to merge zones into a cluster.",
    )
    parser.add_argument(
        "--max-cluster-size",
        type=int,
        default=6,
        metavar="INT",
        help="Maximum number of constituent zones per cluster (default: 6).",
    )
    parser.add_argument(
        "--speed-threshold",
        type=float,
        default=80.0,
        metavar="FLOAT",
        help="Road speed (km/h) above which crossing triggers a warning (default: 80).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from zone_clusterer.core.zone_clusterer_core import cluster_zones  # noqa: PLC0415

    # Read inputs
    print(f"Reading zones    : {args.zones}")
    zones_fc = json.loads(_read_uri(args.zones))

    print(f"Reading feedlinks: {args.feedlinks}")
    feedlinks_fc = json.loads(_read_uri(args.feedlinks))

    print(f"Reading network  : {args.network}")
    network_fc = json.loads(_read_uri(args.network))

    print(
        f"Clustering: max_distance_m={args.max_distance_m}  "
        f"max_cluster_size={args.max_cluster_size}  "
        f"speed_threshold={args.speed_threshold}"
    )

    # Run clustering
    out_zones_fc, out_feedlinks_fc, stats = cluster_zones(
        zones_fc,
        feedlinks_fc,
        network_fc,
        max_distance_m=args.max_distance_m,
        max_cluster_size=args.max_cluster_size,
        speed_threshold=args.speed_threshold,
    )

    print(f"Stats            : {stats}")

    # Overwrite in place
    print(f"Writing zones    : {args.zones}")
    _write_uri(args.zones, json.dumps(out_zones_fc, ensure_ascii=False).encode("utf-8"))

    print(f"Writing feedlinks: {args.feedlinks}")
    _write_uri(args.feedlinks, json.dumps(out_feedlinks_fc, ensure_ascii=False).encode("utf-8"))

    print("Done.")


if __name__ == "__main__":
    main()
