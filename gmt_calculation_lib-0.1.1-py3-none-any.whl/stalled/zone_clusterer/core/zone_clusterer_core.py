"""Pure-Python zone-clusterer core — no I/O, no boto3, no external deps.

Clusters nearby aggregate (boundary-crossing) zones and re-routes their
feedlinks so that the cluster zone's centroid connects to every network node
that was originally used by its constituent zones.

Public API
----------
cluster_zones(zones_fc, feedlinks_fc, network_fc, max_distance_m, ...) -> tuple[dict, dict, dict]
    Returns (updated_zones_fc, updated_feedlinks_fc).
    Inner zones and inner-zone feedlinks pass through unchanged.
    Aggregate zones within ``max_distance_m`` of each other are merged into
    cluster zones (max ``max_cluster_size`` per cluster).  Each cluster zone
    gets one production + one attraction feedlink per original constituent
    network node.  If the straight-line feedlink crosses a road with
    speed > ``speed_threshold``, a warning is logged but the feedlink is still
    added.
"""

from __future__ import annotations

import logging
import math

from shared.geo_utils import (
    _circle_polygon,
    _flat_earth_dist_m,
    _straight_line,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Maximum number of constituent zones in a single cluster.
_DEFAULT_MAX_CLUSTER_SIZE: int = 6

#: Speed threshold above which a road is considered a barrier (km/h).
_DEFAULT_SPEED_THRESHOLD: float = 80.0


# ---------------------------------------------------------------------------
# Internal geometry helpers
# ---------------------------------------------------------------------------

def _segments_intersect(
    a0: tuple[float, float],
    a1: tuple[float, float],
    b0: tuple[float, float],
    b1: tuple[float, float],
) -> bool:
    """Return True when line-segment a0→a1 properly intersects b0→b1.

    Collinear / endpoint-touching cases return False (not considered blocking).
    Uses 2-D cross-product method.
    """
    def _cross(v: tuple, w: tuple) -> float:
        return v[0] * w[1] - v[1] * w[0]

    def _sub(p: tuple, q: tuple) -> tuple:
        return (p[0] - q[0], p[1] - q[1])

    r   = _sub(a1, a0)
    s   = _sub(b1, b0)
    rxs = _cross(r, s)

    if abs(rxs) < 1e-14:
        return False  # parallel / collinear

    qp = _sub(b0, a0)
    t  = _cross(qp, s) / rxs
    u  = _cross(qp, r) / rxs

    return 0.0 < t < 1.0 and 0.0 < u < 1.0


def _parse_high_speed_segments(
    network_fc: dict,
    speed_threshold: float = _DEFAULT_SPEED_THRESHOLD,
) -> list[tuple[tuple[float, float], tuple[float, float]]]:
    """Return every consecutive-vertex segment from links with speed > threshold."""
    segs: list[tuple[tuple[float, float], tuple[float, float]]] = []
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        speed = float(props.get("speed") or 0)
        if speed > speed_threshold:
            coords = (feat.get("geometry") or {}).get("coordinates") or []
            for i in range(len(coords) - 1):
                segs.append(
                    ((coords[i][0], coords[i][1]), (coords[i + 1][0], coords[i + 1][1]))
                )
    return segs


def _feedlink_crosses_high_speed(
    lon0: float,
    lat0: float,
    lon1: float,
    lat1: float,
    high_speed_segs: list,
) -> bool:
    """Return True if the straight-line lon0/lat0 → lon1/lat1 crosses any high-speed segment."""
    p0 = (lon0, lat0)
    p1 = (lon1, lat1)
    for seg in high_speed_segs:
        if _segments_intersect(p0, p1, seg[0], seg[1]):
            return True
    return False


# ---------------------------------------------------------------------------
# Clustering
# ---------------------------------------------------------------------------

def _cluster_aggregate_zones(
    agg_zones: list[dict],
    max_distance_m: float,
    max_cluster_size: int = _DEFAULT_MAX_CLUSTER_SIZE,
) -> list[list[dict]]:
    """Group aggregate zone property-dicts into spatially compact clusters.

    Algorithm: greedy nearest-neighbour.
    Zones are sorted by ``sectorIndex`` (compass octant) first so that
    spatially adjacent zones are considered together.  For each unvisited
    zone a new cluster is started; its nearest unvisited neighbour within
    ``max_distance_m`` is repeatedly added until the cluster reaches
    ``max_cluster_size`` or no close neighbour remains.
    """
    if not agg_zones:
        return []

    sorted_zones = sorted(agg_zones, key=lambda z: int(z.get("sectorIndex") or 0))
    n            = len(sorted_zones)
    in_cluster   = [False] * n

    clusters: list[list[dict]] = []

    for seed in range(n):
        if in_cluster[seed]:
            continue
        cluster = [sorted_zones[seed]]
        in_cluster[seed] = True

        while len(cluster) < max_cluster_size:
            best_dist = float("inf")
            best_j    = -1

            for j in range(n):
                if in_cluster[j]:
                    continue
                z    = sorted_zones[j]
                zlon = float(z.get("centroidLon") or 0)
                zlat = float(z.get("centroidLat") or 0)
                # Distance to nearest zone already in the cluster
                for cz in cluster:
                    d = _flat_earth_dist_m(
                        float(cz.get("centroidLon") or 0),
                        float(cz.get("centroidLat") or 0),
                        zlon,
                        zlat,
                    )
                    if d < best_dist:
                        best_dist = d
                        best_j    = j

            if best_j == -1 or best_dist > max_distance_m:
                break

            cluster.append(sorted_zones[best_j])
            in_cluster[best_j] = True

        clusters.append(cluster)

    return clusters


# ---------------------------------------------------------------------------
# Zone merging
# ---------------------------------------------------------------------------

def _merge_cluster(cluster: list[dict], new_gid: int) -> dict:
    """Merge a list of aggregate zone property-dicts into one cluster zone dict."""
    total_weight = sum(
        float(z.get("production") or 0) + float(z.get("attraction") or 0)
        for z in cluster
    )

    if total_weight < 1e-9:
        cx = sum(float(z.get("centroidLon") or 0) for z in cluster) / len(cluster)
        cy = sum(float(z.get("centroidLat") or 0) for z in cluster) / len(cluster)
    else:
        cx = sum(
            float(z.get("centroidLon") or 0)
            * (float(z.get("production") or 0) + float(z.get("attraction") or 0))
            for z in cluster
        ) / total_weight
        cy = sum(
            float(z.get("centroidLat") or 0)
            * (float(z.get("production") or 0) + float(z.get("attraction") or 0))
            for z in cluster
        ) / total_weight

    total_prod  = sum(float(z.get("production") or 0)    for z in cluster)
    total_attr  = sum(float(z.get("attraction") or 0)    for z in cluster)
    total_links = sum(int(z.get("nCrossingLinks") or 0)  for z in cluster)
    constituent_ids = [z["gid"] for z in cluster if z.get("gid") is not None]

    # Inherit sector / ring / mode from the first (seed) zone
    sector_idx = int(cluster[0].get("sectorIndex") or 0)
    ring_label = str(cluster[0].get("ringLabel") or "bbox-boundary")
    mode       = str(cluster[0].get("mode") or "")

    return {
        "gid":                 new_gid,
        "zoneId":              f"cluster_{new_gid}",
        "zoneName":            f"Cluster {new_gid} ({len(cluster)} zones)",
        "zoneType":            "aggregate",
        "ringIndex":           0,
        "ringLabel":           ring_label,
        "sectorIndex":         sector_idx,
        "constituentZoneIds":  constituent_ids,
        "centroidLon":         cx,
        "centroidLat":         cy,
        "production":          total_prod,
        "attraction":          total_attr,
        "nodeId":              None,
        "mode":                mode,
        "nCrossingLinks":      total_links,
    }


# ---------------------------------------------------------------------------
# Feedlink re-routing
# ---------------------------------------------------------------------------

def _reroute_feedlinks(
    cluster_props: dict,
    constituent_feedlinks: list[dict],
    constituent_gid_strings: set[str],
    high_speed_segs: list,
    fid_start: int,
) -> tuple[list[dict], int]:
    """Build new feedlinks from the cluster centroid to each constituent network node.

    For each original feedlink whose zone-side node (virtual zone gid string)
    belongs to a constituent zone, we:
    1.  Identify the network-side node and its position from the feedlink geometry.
    2.  Create a production feedlink  (cluster_centroid → network_node).
    3.  Create an attraction feedlink (network_node → cluster_centroid).
    4.  Wire ``reverseLinkIds`` between each production/attraction pair.
    5.  Warn (but still add) if the new straight-line crosses a high-speed road.

    Network nodes that appear more than once (same node served by multiple
    constituent zones) are deduplicated: only one prod+attr pair per node.
    """
    cluster_lon    = float(cluster_props["centroidLon"])
    cluster_lat    = float(cluster_props["centroidLat"])
    cluster_zone_id = cluster_props["zoneId"]
    cluster_node_id = str(cluster_props["gid"])  # virtual zone node for the cluster
    ring_idx       = int(cluster_props.get("ringIndex") or 0)
    ring_lbl       = str(cluster_props.get("ringLabel") or "")
    sec_idx        = int(cluster_props.get("sectorIndex") or 0)
    mode           = str(cluster_props.get("mode") or "")
    production     = float(cluster_props.get("production") or 0.0)  # noqa: F841
    attraction     = float(cluster_props.get("attraction") or 0.0)  # noqa: F841

    # ── gather per-network-node capacity & geometry ───────────────────────────
    # prod_info[net_node] = (net_lon, net_lat, max_capacity, mode)
    prod_info: dict[str, tuple] = {}
    attr_info: dict[str, tuple] = {}

    for feat in constituent_feedlinks:
        props     = feat.get("properties") or {}
        from_node = str(props.get("fromNode") or "")
        to_node   = str(props.get("toNode")   or "")
        capacity  = float(props.get("capacity") or 0.0)
        fl_mode   = str(props.get("mode") or mode)
        coords    = (feat.get("geometry") or {}).get("coordinates") or []

        if from_node in constituent_gid_strings:
            # Production feedlink: zone_centroid -> network_node
            # network node position = last coordinate
            net_node = to_node
            if coords and net_node:
                net_lon, net_lat = float(coords[-1][0]), float(coords[-1][1])
                prev_cap = prod_info.get(net_node, (net_lon, net_lat, 0.0, fl_mode))[2]
                if capacity > prev_cap:
                    prod_info[net_node] = (net_lon, net_lat, capacity, fl_mode)
                else:
                    prod_info.setdefault(net_node, (net_lon, net_lat, capacity, fl_mode))

        elif to_node in constituent_gid_strings:
            # Attraction feedlink: network_node -> zone_centroid
            # network node position = first coordinate
            net_node = from_node
            if coords and net_node:
                net_lon, net_lat = float(coords[0][0]), float(coords[0][1])
                prev_cap = attr_info.get(net_node, (net_lon, net_lat, 0.0, fl_mode))[2]
                if capacity > prev_cap:
                    attr_info[net_node] = (net_lon, net_lat, capacity, fl_mode)
                else:
                    attr_info.setdefault(net_node, (net_lon, net_lat, capacity, fl_mode))

        else:
            logger.warning(
                "Cannot classify feedlink (from=%s, to=%s) for cluster %s — skipping.",
                from_node, to_node, cluster_zone_id,
            )

    # ── collect all distinct network nodes ───────────────────────────────────
    all_net_nodes = set(prod_info) | set(attr_info)

    records: list[dict] = []
    fid = fid_start

    for net_node in sorted(all_net_nodes):  # sorted for determinism
        prod_fid = fid
        attr_fid = fid + 1

        has_prod = net_node in prod_info
        has_attr = net_node in attr_info

        # Fall back to whichever side has the position info
        if has_prod:
            net_lon, net_lat, prod_cap, fl_mode = prod_info[net_node]
        else:
            net_lon, net_lat, _, fl_mode = attr_info[net_node]
            prod_cap = 0.0

        if has_attr:
            _net_lon2, _net_lat2, attr_cap, _ = attr_info[net_node]
        else:
            attr_cap = 0.0

        dist_m = _flat_earth_dist_m(cluster_lon, cluster_lat, net_lon, net_lat)

        # 80 km/h soft constraint check
        if _feedlink_crosses_high_speed(cluster_lon, cluster_lat, net_lon, net_lat, high_speed_segs):
            logger.warning(
                "New cluster feedlink (zoneId=%s → netNode=%s) crosses a road "
                "with speed > %.0f km/h — adding anyway.",
                cluster_zone_id, net_node, _DEFAULT_SPEED_THRESHOLD,
            )

        if has_prod and prod_cap > 0.0:
            records.append({
                "type": "Feature",
                "geometry": _straight_line(cluster_lon, cluster_lat, net_lon, net_lat),
                "properties": {
                    "feedlinkId":     prod_fid,
                    "reverseLinkIds": [attr_fid] if has_attr else [],
                    "zoneId":         cluster_zone_id,
                    "fromNode":       cluster_node_id,
                    "toNode":         net_node,
                    "length":         round(dist_m, 1),
                    "capacity":       prod_cap,
                    "mode":           fl_mode,
                    "ringIndex":      ring_idx,
                    "ringLabel":      ring_lbl,
                    "sectorIndex":    sec_idx,
                    "type":           "feedlink",
                },
            })

        if has_attr and attr_cap > 0.0:
            records.append({
                "type": "Feature",
                "geometry": _straight_line(net_lon, net_lat, cluster_lon, cluster_lat),
                "properties": {
                    "feedlinkId":     attr_fid,
                    "reverseLinkIds": [prod_fid] if has_prod else [],
                    "zoneId":         cluster_zone_id,
                    "fromNode":       net_node,
                    "toNode":         cluster_node_id,
                    "length":         round(dist_m, 1),
                    "capacity":       attr_cap,
                    "mode":           fl_mode,
                    "ringIndex":      ring_idx,
                    "ringLabel":      ring_lbl,
                    "sectorIndex":    sec_idx,
                    "type":           "feedlink",
                },
            })

        fid += 2

    return records, fid


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def cluster_zones(
    zones_fc: dict,
    feedlinks_fc: dict,
    network_fc: dict,
    max_distance_m: float,
    max_cluster_size: int = _DEFAULT_MAX_CLUSTER_SIZE,
    speed_threshold: float = _DEFAULT_SPEED_THRESHOLD,
) -> tuple[dict, dict, dict]:
    """Cluster nearby aggregate zones and re-route their feedlinks.

    Parameters
    ----------
    zones_fc:
        Zone FeatureCollection from ``zone_intersector``.
    feedlinks_fc:
        Feedlink FeatureCollection from ``zone_intersector``.
    network_fc:
        Network FeatureCollection (used for 80 km/h road segment detection).
    max_distance_m:
        Maximum centroid-to-centroid distance in metres for two zones to be
        eligible for merging into the same cluster.
    max_cluster_size:
        Hard upper limit on the number of constituent zones in one cluster.
    speed_threshold:
        Road speed (km/h) above which crossing is warned about.

    Returns
    -------
    (updated_zones_fc, updated_feedlinks_fc, stats)
        Inner zones and their feedlinks pass through unchanged.
        Aggregate zones are clustered; constituent zones and their feedlinks
        are replaced by cluster zones and re-routed feedlinks.
        Both output FeatureCollections carry the same top-level ``properties``
        as the inputs.
        ``stats`` is a dict with counters: input_zones, input_feedlinks,
        clusters, merged_agg_zones, passthru_agg_zones, output_zones,
        output_feedlinks.
    """
    all_zone_features     = zones_fc.get("features")     or []
    all_feedlink_features = feedlinks_fc.get("features") or []

    # ── split zones by type ──────────────────────────────────────────────────
    inner_zone_features = [
        f for f in all_zone_features
        if (f.get("properties") or {}).get("zoneType") != "aggregate"
    ]
    agg_zone_features = [
        f for f in all_zone_features
        if (f.get("properties") or {}).get("zoneType") == "aggregate"
    ]
    agg_zone_props = [(f.get("properties") or {}) for f in agg_zone_features]

    # ── split feedlinks by zone type ─────────────────────────────────────────
    agg_zone_ids: set[str] = {
        str((f.get("properties") or {}).get("zoneId") or "")
        for f in agg_zone_features
    }
    inner_feedlinks = [
        fl for fl in all_feedlink_features
        if str((fl.get("properties") or {}).get("zoneId") or "") not in agg_zone_ids
    ]
    # Index aggregate feedlinks by zoneId
    agg_feedlinks_by_zone: dict[str, list] = {}
    for fl in all_feedlink_features:
        props   = fl.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        if zone_id in agg_zone_ids:
            agg_feedlinks_by_zone.setdefault(zone_id, []).append(fl)

    # ── prepare high-speed segment list ─────────────────────────────────────
    high_speed_segs = _parse_high_speed_segments(network_fc, speed_threshold)
    logger.info(
        "High-speed segments (> %.0f km/h): %d", speed_threshold, len(high_speed_segs)
    )

    # ── determine starting IDs for new zones and feedlinks ──────────────────
    max_gid = max(
        (int((f.get("properties") or {}).get("gid") or 0) for f in all_zone_features),
        default=0,
    )
    max_fid = max(
        (int((f.get("properties") or {}).get("feedlinkId") or 0) for f in all_feedlink_features),
        default=0,
    )
    next_gid = max_gid + 1
    next_fid = max_fid + 1

    # ── cluster ──────────────────────────────────────────────────────────────
    clusters = _cluster_aggregate_zones(agg_zone_props, max_distance_m, max_cluster_size)
    logger.info(
        "Aggregate zones: %d → %d clusters (max_distance_m=%.0f)",
        len(agg_zone_props), len(clusters), max_distance_m,
    )

    # ── build new zone features and feedlinks ────────────────────────────────
    new_zone_features:     list[dict] = []
    new_feedlink_features: list[dict] = []
    n_merged   = 0
    n_passthru = 0

    for cluster in clusters:
        if len(cluster) == 1:
            # Single zone — pass through zone feature and its feedlinks as-is
            zone_id   = cluster[0].get("zoneId") or ""
            orig_feat = next(
                (
                    f for f in agg_zone_features
                    if (f.get("properties") or {}).get("zoneId") == zone_id
                ),
                None,
            )
            if orig_feat:
                new_zone_features.append(orig_feat)
            new_feedlink_features.extend(agg_feedlinks_by_zone.get(zone_id, []))
            n_passthru += 1
            continue

        # ── multi-zone cluster ──────────────────────────────────────────────
        n_merged += len(cluster)

        # Merge zone properties
        cluster_props = _merge_cluster(cluster, next_gid)
        next_gid     += 1

        # Build cluster zone Feature
        clon = float(cluster_props["centroidLon"])
        clat = float(cluster_props["centroidLat"])
        cluster_feat: dict = {
            "type":     "Feature",
            "geometry": {
                "type":        "Polygon",
                "coordinates": [_circle_polygon(clon, clat, 250.0)],
            },
            "properties": dict(cluster_props),
        }
        new_zone_features.append(cluster_feat)

        # Gather all constituent feedlinks
        constituent_gid_strings = {str(z.get("gid") or "") for z in cluster}
        constituent_feedlinks: list[dict] = []
        for z in cluster:
            constituent_feedlinks.extend(agg_feedlinks_by_zone.get(z.get("zoneId") or "", []))

        # Build re-routed feedlinks
        new_fls, next_fid = _reroute_feedlinks(
            cluster_props,
            constituent_feedlinks,
            constituent_gid_strings,
            high_speed_segs,
            next_fid,
        )
        new_feedlink_features.extend(new_fls)

    logger.info(
        "Clustering result: %d aggregate zones merged into clusters, "
        "%d passed through unchanged.  "
        "New zone features: %d (inner: %d + aggregate: %d).  "
        "New feedlink features: %d (inner: %d + aggregate: %d).",
        n_merged, n_passthru,
        len(inner_zone_features) + len(new_zone_features),
        len(inner_zone_features), len(new_zone_features),
        len(inner_feedlinks) + len(new_feedlink_features),
        len(inner_feedlinks), len(new_feedlink_features),
    )

    # ── assemble output FeatureCollections ───────────────────────────────────
    out_zones_fc: dict = {
        **zones_fc,
        "features": inner_zone_features + new_zone_features,
    }
    out_feedlinks_fc: dict = {
        **feedlinks_fc,
        "features": inner_feedlinks + new_feedlink_features,
    }

    stats = {
        "input_zones":        len(all_zone_features),
        "input_feedlinks":    len(all_feedlink_features),
        "clusters":           len(clusters),
        "merged_agg_zones":   n_merged,
        "passthru_agg_zones": n_passthru,
        "output_zones":       len(out_zones_fc["features"]),
        "output_feedlinks":   len(out_feedlinks_fc["features"]),
    }
    logger.info("Stats: %s", stats)

    return out_zones_fc, out_feedlinks_fc, stats


__all__ = [
    "_DEFAULT_MAX_CLUSTER_SIZE",
    "_DEFAULT_SPEED_THRESHOLD",
    "_cluster_aggregate_zones",
    "_merge_cluster",
    "_reroute_feedlinks",
    "_segments_intersect",
    "_parse_high_speed_segments",
    "_feedlink_crosses_high_speed",
    "cluster_zones",
]
