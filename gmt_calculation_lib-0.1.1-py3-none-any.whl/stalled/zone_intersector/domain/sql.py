"""SQL helpers for the zone-intersector — no I/O, no boto3."""

from __future__ import annotations

import json

from stalled.zone_intersector.domain.zone import _CBS_COLS


def build_inner_zones_sql(catalog: str, schema: str) -> str:
    """Build the Databricks SQL that fetches inner zones intersecting a bbox polygon.

    The returned SQL has one ``?`` positional placeholder for the bbox GeoJSON
    polygon string.
    """
    _cbs_select = ",\n            ".join(_CBS_COLS)
    return f"""
        SELECT
            gid,
            zone_id,
            zone_naam                                                               AS zoneName,
            ST_AsGeoJSON(ST_Transform(ST_GeomFromEWKB(zone_geometrie), 4326))      AS zone_geom_json,
            ST_X(ST_Centroid(ST_Transform(ST_GeomFromEWKB(zone_geometrie), 4326))) AS centroidLon,
            ST_Y(ST_Centroid(ST_Transform(ST_GeomFromEWKB(zone_geometrie), 4326))) AS centroidLat,
            {_cbs_select}
        FROM `{catalog}`.`{schema}`.d030_zones_met_centroids
        WHERE ST_Intersects(
            ST_GeomFromEWKB(zone_geometrie),
            ST_Transform(ST_GeomFromGeoJSON(?), 28992)
        )
        ORDER BY gid
    """


def bbox_to_polygon_json(bbox: list) -> str:
    """Return a GeoJSON Polygon string for [minLon, minLat, maxLon, maxLat]."""
    x1, y1, x2, y2 = bbox[0], bbox[1], bbox[2], bbox[3]
    ring = [[x1, y1], [x2, y1], [x2, y2], [x1, y2], [x1, y1]]
    return json.dumps({"type": "Polygon", "coordinates": [ring]})
