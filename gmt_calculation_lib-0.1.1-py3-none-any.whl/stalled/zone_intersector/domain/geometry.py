"""Geometry helpers for the zone-intersector — no I/O, no boto3.

All implementations live in ``shared.geo_utils``; this module re-exports
the subset used by zone_intersector so that intra-module imports are unchanged.
"""

from __future__ import annotations

from shared.geo_utils import (  # noqa: F401
    _COMPASS_8,
    _D_LAT,
    _d_lon,
    _is_inside_bbox,
    _nudge_point,
    _bearing_deg,
    _compass_8_label,
    _circle_polygon,
)
