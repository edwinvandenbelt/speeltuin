"""Zone row parsing for the zone-intersector — no I/O, no boto3."""

from __future__ import annotations

import json
import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# CBS demographic columns
# ---------------------------------------------------------------------------

_CBS_COLS: tuple[str, ...] = (
    "inwoners",
    "inwoners_mannen",
    "inwoners_vrouwen",
    "inwoners_leeftijd_00_17_jaar",
    "inwoners_leeftijd_18_29_jaar",
    "inwoners_leeftijd_30_44_jaar",
    "inwoners_leeftijd_45_64_jaar",
    "inwoners_leeftijd_65_plus_jaar",
    "inwoners_leeftijd_00_14_jaar",
    "inwoners_leeftijd_15_24_jaar",
    "inwoners_leeftijd_25_44_jaar",
    "inwoners_migratieachtergrond_europees",
    "inwoners_migratieachtergrond_niet_europees",
    "inwoners_zonder_migratieachtergrond",
    "inwoners_migratieachtergrond_westers",
    "inwoners_migratieachtergrond_niet_westers",
    "inwoners_leerlingen_middelbaaronderwijs",
    "inwoners_leerlingen_middelbaarberoepsonderwijs",
    "inwoners_leerlingen_hogeronderwijs",
    "inwoners_met_rijbewijs",
    "inwoners_zonder_rijbewijs",
    "inwoners_arbeidssituatie_student",
    "inwoners_arbeidssituatie_werkend",
    "inwoners_arbeidssituatie_anders",
    "huishoudens",
    "huishoudens_1_persoons",
    "huishoudens_2_persoons",
    "huishoudens_3_persoons",
    "huishoudens_4_persoons",
    "huishoudens_5_persoons",
    "huishoudens_6_plus_persoons",
    "huishoudens_meerpersoons_zonder_kinderen",
    "huishoudens_meerpersoons_met_kinderen",
    "huishoudens_0_autos",
    "huishoudens_1_autos",
    "huishoudens_2_autos",
    "huishoudens_3_plus_autos",
    "autos",
    "arbeidsplaatsen",
    "arbeidsplaatsen_woonfunctie",
    "arbeidsplaatsen_standplaats",
    "arbeidsplaatsen_ligplaats",
    "arbeidsplaatsen_celfunctie",
    "arbeidsplaatsen_onderwijsfunctie",
    "arbeidsplaatsen_industriefunctie",
    "arbeidsplaatsen_kantoorfunctie",
    "arbeidsplaatsen_overige_winkelfunctie",
    "arbeidsplaatsen_overige_voedselwinkelfunctie",
    "arbeidsplaatsen_supermarkt_voedselwinkelfunctie",
    "arbeidsplaatsen_gezondheidszorgfunctie",
    "arbeidsplaatsen_sportfunctie",
    "arbeidsplaatsen_bijeenkomstfunctie",
    "arbeidsplaatsen_logiesfunctie",
    "arbeidsplaatsen_boerderijfunctie",
    "arbeidsplaatsen_terminalfunctie",
    "arbeidsplaatsen_distributiecentrumfunctie",
    "arbeidsplaatsen_overige_gebruiksfunctie",
    "arbeidsplaatsen_gecombineerde_functies",
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)

_LEERLING_COLS: tuple[str, ...] = (
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)


def _calc_production(r: dict) -> float:
    """Return production for an inner zone using the household-based formula.

    production = (7 × huishoudens  +  2.3 × inwoners) / 2
    """
    huishoudens = float(r.get("huishoudens") or 0.0)
    inwoners    = float(r.get("inwoners")    or 0.0)
    return (7.0 * huishoudens + 2.3 * inwoners) / 2.0


def _calc_attraction(r: dict) -> float:
    """Return attraction for an inner zone using the employment-based formula.

    attraction = 2 × (arbeidsplaatsen + Σ leerlingplaatsen_*)
    """
    arbeidsplaatsen = float(r.get("arbeidsplaatsen") or 0.0)
    leerling        = sum(float(r.get(c) or 0.0) for c in _LEERLING_COLS)
    return 2.0 * (arbeidsplaatsen + leerling)


def parse_inner_zones_rows(rows: list, col_names: list) -> list[dict]:
    """Convert raw Databricks result rows into GeoJSON Feature dicts."""
    features = []
    for row in rows:
        r = dict(zip(col_names, row))
        geom_json = r.get("zone_geom_json")
        if not geom_json:
            logger.debug("Skipping zone gid=%s — no geometry", r.get("gid"))
            continue
        try:
            geom = json.loads(geom_json)
        except (json.JSONDecodeError, TypeError) as exc:
            logger.warning("Skipping zone gid=%s — bad geometry JSON: %s", r.get("gid"), exc)
            continue

        props: dict = {
            "gid":                r["gid"],
            "zoneId":            r["zone_id"],
            "zoneName":          r["zoneName"],
            "zoneType":          "inner",
            "ringIndex":         -1,
            "ringLabel":         "",
            "sectorIndex":       -1,
            "constituentZoneIds": [],
            "centroidLon":       r["centroidLon"],
            "centroidLat":       r["centroidLat"],
            "production":         _calc_production(r),
            "attraction":         _calc_attraction(r),
            "nodeId":            None,
            "mode":               None,
            "nCrossingLinks":   0,
        }
        for col in _CBS_COLS:
            props[col] = r.get(col)

        features.append({"type": "Feature", "geometry": geom, "properties": props})
    return features
