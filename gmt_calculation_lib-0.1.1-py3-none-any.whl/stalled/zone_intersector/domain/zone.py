"""Zone row parsing for the zone-intersector — no I/O, no boto3."""

from __future__ import annotations

import json
import logging

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# CBS demographic columns
# ---------------------------------------------------------------------------

_CBS_COLS: tuple[str, ...] = (
    "inwoners",
    "huishoudens",
    "arbeidsplaatsen",
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)

_LEERLING_COLS: tuple[str, ...] = (
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)


def _calc_production(r: dict) -> float:
    """Return production for an inner zone using the household-based formula.

    production = (7 × huishoudens  +  2.3 × inwoners) / 2
    """
    huishoudens = float(r.get("huishoudens") or 0.0)
    inwoners = float(r.get("inwoners") or 0.0)
    return (7.0 * huishoudens + 2.3 * inwoners) / 2.0


def _calc_attraction(r: dict) -> float:
    """Return attraction for an inner zone using the employment-based formula.

    attraction = 2 × (arbeidsplaatsen + Σ leerlingplaatsen_*)
    """
    arbeidsplaatsen = float(r.get("arbeidsplaatsen") or 0.0)
    leerling = sum(float(r.get(c) or 0.0) for c in _LEERLING_COLS)
    return 2.0 * (arbeidsplaatsen + leerling)


def parse_inner_zones_rows(rows: list, col_names: list) -> list[dict]:
    """Convert raw Databricks result rows into GeoJSON Feature dicts."""
    features = []
    for row in rows:
        r = dict(zip(col_names, row))
        geom_json = r.get("zone_geom_json")
        if not geom_json:
            logger.debug("Skipping zone gid=%s — no geometry", r.get("gid"))
            continue
        try:
            geom = json.loads(geom_json)
        except (json.JSONDecodeError, TypeError) as exc:
            logger.warning("Skipping zone gid=%s — bad geometry JSON: %s", r.get("gid"), exc)
            continue

        props: dict = {
            "gid": r["gid"],
            "zoneId": r["zone_id"],
            "zoneName": r["zoneName"],
            "zoneType": "inner",
            "ringIndex": -1,
            "ringLabel": "",
            "sectorIndex": -1,
            "constituentZoneIds": [],
            "centroidLon": r["centroidLon"],
            "centroidLat": r["centroidLat"],
            "production": _calc_production(r),
            "attraction": _calc_attraction(r),
            "nodeId": None,
            "mode": None,
            "nCrossingLinks": 0,
        }
        for col in _CBS_COLS:
            props[col] = r.get(col)

        features.append({"type": "Feature", "geometry": geom, "properties": props})
    return features
