# Databricks notebook source
# ---------------------------------------------------------------------------
# zone_intersector_nb.py — Databricks notebook interface for zone intersector.
#
# This notebook:
#   1. Reads widget parameters (network_geojson_path, output_folder, mode, …).
#   2. Loads the network GeoJSON produced by network_intersector_nb.py from S3 or path.
#   3. Queries inner zones via spark.sql() using SQL built by
#      zone_intersector.zone_intersector_core.build_inner_zones_sql().
#      NOTE: spark.sql() does not support ? placeholders — the polygon GeoJSON
#      is embedded directly in the SQL string (single-quote–escaped).
#   4. Calls pure core functions (parse_inner_zones_rows, derive_zones) — no I/O.
#   5. Queries voedingslinks via spark.sql() for the appropriate mode table.
#   6. Calls feedlink_creator_core.derive_feedlinks() to build feedlinks — no I/O.
#   7. Writes two GeoJSON outputs (and an optional GeoParquet for zones) to S3 or path:
#        {area_id}-ZONE-{mode}.geojson
#        {area_id}-FEEDLINK-{mode}.geojson
#
# Requirements (Databricks cluster):
#   pip install boto3 geopandas pyarrow   (or attach via cluster library)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
import tempfile
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("zone_intersector_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install geopandas pyarrow

# COMMAND ----------
# geopandas is optional — GeoParquet output is skipped when unavailable.
try:
    import geopandas as gpd
    _HAS_GEOPANDAS = True
except ImportError:
    _HAS_GEOPANDAS = False
    logger.warning(
        "geopandas / pyarrow not installed — GeoParquet output will be skipped."
    )

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "output_folder", "",
    "Output folder: s3://bucket/prefix  or  /dbfs/path (required)",
)
dbutils.widgets.text(  # noqa: F821
    "bbox", "4.9140989669,52.0270039292,4.9837934859,52.0587847105",
    "Bounding box — lon_min,lat_min,lon_max,lat_max in WGS-84",
)
dbutils.widgets.text(  # noqa: F821
    "mode", "CAR",
    "Transport mode (CAR, BIKE, PEDESTRIAN, BUS, TRAM, METRO, TRAIN)",
)
dbutils.widgets.text(  # noqa: F821
    "network_geojson_path", "",
    "Path or S3 URI to the network GeoJSON produced by network_intersector_nb.py",
)
dbutils.widgets.text(  # noqa: F821
    "centroid_offset_m", "1000",
    "Distance (m) to nudge each external crossing centroid further from bbox boundary",
)
dbutils.widgets.text(  # noqa: F821
    "DATABRICKS_CATALOG", "spectrum",
    "Unity Catalog name",
)
dbutils.widgets.text(  # noqa: F821
    "DATABRICKS_SCHEMA", "2023_01",
    "Schema / dataset version (e.g. 2024_01)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from stalled.zone_intersector.core.zone_intersector_core import (  # noqa: E402
    bbox_to_polygon_json,
    build_inner_zones_sql,
    derive_zones,
    parse_inner_zones_rows,
)
from stalled.feedlink_creator.core.feedlink_creator_core import (  # noqa: E402
    VOEDINGSLINKS_TABLE,
    build_voedingslinks_sql,
    derive_feedlinks,
    parse_network_geojson,
    parse_zone_geojson,
)

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

bbox_raw     = dbutils.widgets.get("bbox").strip()                  # noqa: F821
MODE         = dbutils.widgets.get("mode").strip().upper()          # noqa: F821
NET_PATH     = dbutils.widgets.get("network_geojson_path").strip()  # noqa: F821
CATALOG      = dbutils.widgets.get("DATABRICKS_CATALOG").strip() or "spectrum"  # noqa: F821
SCHEMA       = dbutils.widgets.get("DATABRICKS_SCHEMA").strip() or "2023_01"    # noqa: F821
OUT_PATH     = dbutils.widgets.get("output_folder").strip()         # noqa: F821

if not OUT_PATH:
    raise ValueError("output_folder widget must not be empty.")

_offset_raw  = dbutils.widgets.get("centroid_offset_m").strip() or "1000"  # noqa: F821
try:
    OFFSET_M = float(_offset_raw)
except ValueError as _exc:
    raise ValueError(f"'centroid_offset_m' must be a number, got: {_offset_raw!r}") from _exc

if not NET_PATH:
    raise ValueError(
        "'network_geojson_path' is required — provide a path or S3 URI to "
        "the network GeoJSON produced by network_intersector_nb.py."
    )

try:
    BBOX = [float(x.strip()) for x in bbox_raw.split(",")]
except ValueError as _exc:
    raise ValueError(
        f"'bbox' must be four comma-separated numbers (lon_min,lat_min,lon_max,lat_max), "
        f"got: {bbox_raw!r}"
    ) from _exc
if len(BBOX) != 4:
    raise ValueError(
        f"'bbox' must have exactly 4 values, got {len(BBOX)}."
    )

logger.info(
    "mode=%s  bbox=%s  catalog=%s.%s  offset_m=%s",
    MODE, BBOX, CATALOG, SCHEMA, OFFSET_M,
)
print(f"BBox          : {BBOX}")
print(f"Mode          : {MODE}")
print(f"Network path  : {NET_PATH}")
print(f"Centroid offs : {OFFSET_M} m")

# COMMAND ----------
# ── I/O helpers ───────────────────────────────────────────────────────────────

def _s3_split(uri: str) -> tuple:
    without = uri[5:]
    bucket, _, prefix = without.partition("/")
    return bucket, prefix


def _read_bytes(path: str) -> bytes:
    if path.startswith("s3://"):
        import boto3  # noqa: PLC0415
        bucket, key = _s3_split(path)
        data = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return data
    with open(path, "rb") as fh:
        data = fh.read()
    logger.info("Read %s  (%d bytes)", path, len(data))
    return data


def _put_s3(bucket: str, key: str, data: bytes, content_type: str) -> None:
    import boto3  # noqa: PLC0415
    boto3.client("s3").put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _output_dir() -> str:
    return OUT_PATH.rstrip("/")


def _ensure_dir(path: str) -> None:
    if not path.startswith("s3://"):
        os.makedirs(path, exist_ok=True)


def _write_file(out_dir: str, filename: str, data: bytes, content_type: str) -> str:
    if out_dir.startswith("s3://"):
        bucket, prefix = _s3_split(out_dir)
        key = f"{prefix}/{filename}".lstrip("/")
        _put_s3(bucket, key, data, content_type)
        return f"s3://{bucket}/{key}"
    fp = os.path.join(out_dir, filename)
    with open(fp, "wb") as fh:
        fh.write(data)
    logger.info("Wrote %s  (%d bytes)", fp, len(data))
    return fp


def _write_geoparquet(fc: dict, out_dir: str, area_id: str, mode: str):
    if not _HAS_GEOPANDAS:
        logger.warning("geopandas not installed — skipping GeoParquet output.")
        return None
    filename = f"{area_id}-ZONE-{mode}.parquet"
    records  = []
    for feat in fc["features"]:
        props = dict(feat["properties"])
        try:
            from shapely.geometry import shape as _shape  # noqa: PLC0415
            props["geometry"] = _shape(feat["geometry"])
        except Exception as exc:
            logger.warning("Skipping feature with bad geometry: %s", exc)
            continue
        records.append(props)
    if not records:
        return None
    gdf = gpd.GeoDataFrame(records, crs="EPSG:4326")
    if out_dir.startswith("s3://"):
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tmp:
            tmp_path = tmp.name
        try:
            gdf.to_parquet(tmp_path)
            bucket, prefix = _s3_split(out_dir)
            key = f"{prefix}/{filename}".lstrip("/")
            with open(tmp_path, "rb") as fh:
                _put_s3(bucket, key, fh.read(), "application/octet-stream")
            return f"s3://{bucket}/{key}"
        finally:
            os.unlink(tmp_path)
    fp = os.path.join(out_dir, filename)
    gdf.to_parquet(fp)
    logger.info("Wrote %s  (%d zones)", fp, len(gdf))
    return fp

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Zone Intersector + Feedlink Creator
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
logger.info("Starting zone intersector at %s", _t_start.isoformat())

# 1. Load network GeoJSON
logger.info("Loading network from %s", NET_PATH)
_net_bytes  = _read_bytes(NET_PATH)
_network_fc = json.loads(_net_bytes)
logger.info("Network loaded: %d features", len(_network_fc.get("features", [])))

# Read AREA_ID from network properties
AREA_ID = (_network_fc.get("properties") or {}).get("area_id") or ""
if not AREA_ID:
    from uuid import uuid4  # noqa: PLC0415
    AREA_ID = str(uuid4())
    logger.warning("Network has no 'area_id' property — using generated ID: %s", AREA_ID)
print(f"Area ID       : {AREA_ID}")

# 2. Build inner-zones SQL and embed polygon (spark.sql has no ? params)
_polygon_json = bbox_to_polygon_json(BBOX)
_poly_esc     = _polygon_json.replace("'", "''")
_sql_template = build_inner_zones_sql(CATALOG, SCHEMA)
_sql          = _sql_template.replace("?", f"'{_poly_esc}'")
logger.debug("Inner zones SQL (first 300 chars): %s…", _sql[:300])

# 3. Execute inner-zones query via Spark
_df        = spark.sql(_sql)  # noqa: F821 — Databricks-injected
_col_names = _df.columns
_rows      = _df.collect()
logger.info("Inner zones query returned %d rows", len(_rows))

# 4. Parse rows into GeoJSON Feature dicts
_inner_features = parse_inner_zones_rows(_rows, _col_names)
logger.info("Parsed %d inner zone features", len(_inner_features))

# 5. Derive the full zone FeatureCollection (pure — no I/O)
_zone_fc = derive_zones(_network_fc, _inner_features, MODE, OFFSET_M)
_zone_fc.setdefault("properties", {})["area_id"] = AREA_ID
_n_inner = sum(
    1 for f in _zone_fc["features"]
    if f["properties"].get("zoneType") == "inner"
)
_n_crossing = sum(
    1 for f in _zone_fc["features"]
    if f["properties"].get("zoneType") == "aggregate"
)
logger.info(
    "Zone derivation complete: %d inner, %d crossing, %d total",
    _n_inner, _n_crossing, len(_zone_fc["features"]),
)

# 6. Query voedingslinks via Spark (mode-dependent table)
_vl_table = VOEDINGSLINKS_TABLE.get(MODE)
_vl_rows: list = []

_zones_parsed = parse_zone_geojson(_zone_fc)
_inner_gids = [
    int(z["gid"])
    for z in _zones_parsed
    if z.get("zoneType") == "inner" and z.get("gid") is not None
]

if _vl_table and _inner_gids:
    _vl_sql = build_voedingslinks_sql(CATALOG, SCHEMA, _vl_table, _inner_gids)
    logger.info(
        "Querying %s.%s.%s for %d inner zone gids …",
        CATALOG, SCHEMA, _vl_table, len(_inner_gids),
    )
    _vl_df   = spark.sql(_vl_sql)  # noqa: F821
    _vl_rows = [row.asDict() for row in _vl_df.collect()]
    logger.info("Voedingslinks query returned %d rows", len(_vl_rows))
elif not _vl_table:
    logger.info("Mode %s has no voedingslinks table — only aggregate feedlinks.", MODE)

# 7. Derive feedlinks (pure — no I/O)
_network_parsed = parse_network_geojson(_network_fc)
_feedlinks_fc   = derive_feedlinks(_network_parsed, _zones_parsed, _vl_rows, MODE)
_feedlinks_fc.setdefault("properties", {})["area_id"] = AREA_ID
_n_feedlinks = len(_feedlinks_fc["features"])
logger.info("Feedlinks derived: %d total", _n_feedlinks)

# 8. Prepare output directory
_out_dir = _output_dir()
_ensure_dir(_out_dir)
logger.info("Output directory: %s", _out_dir)

# 9. Write zone GeoJSON
_geojson_payload = json.dumps(_zone_fc, ensure_ascii=False, indent=2).encode("utf-8")
_geojson_path    = _write_file(
    _out_dir, f"{AREA_ID}-ZONE-{MODE}.geojson", _geojson_payload, "application/geo+json",
)

# 10. Write zone GeoParquet (optional)
_parquet_path = _write_geoparquet(_zone_fc, _out_dir, AREA_ID, MODE)

# 11. Write feedlink GeoJSON
_feedlinks_payload = json.dumps(_feedlinks_fc, ensure_ascii=False, indent=2).encode("utf-8")
_feedlinks_path    = _write_file(
    _out_dir, f"{AREA_ID}-FEEDLINK-{MODE}.geojson", _feedlinks_payload, "application/geo+json",
)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("Zone intersector + feedlink creator complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"Zone Intersector + Feedlink Creator complete — {_total_elapsed:.1f}s total")
print(_SEP)
print(f"  Area ID       : {AREA_ID}")
print(f"  BBox          : {BBOX}")
print(f"  Network path  : {NET_PATH}")
print(f"  Centroid offs : {OFFSET_M} m")
print(f"  Inner zones   : {_n_inner}")
print(f"  Crossing zones: {_n_crossing}")
print(f"  Total zones   : {len(_zone_fc['features'])}")
print(f"  Feedlinks     : {_n_feedlinks}")
print()
print(f"  Zone GeoJSON  : {_geojson_path}")
print(f"  Zone Parquet  : {_parquet_path or '(skipped — geopandas unavailable)'}")
print(f"  Feedlinks     : {_feedlinks_path}")
print(_SEP)
