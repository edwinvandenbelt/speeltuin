"""Pure-Python zone-intersector logic — no I/O, no boto3, no Databricks connections.

Public API
----------
bbox_to_polygon_json(bbox)
build_inner_zones_sql(catalog, schema)
parse_inner_zones_rows(rows, col_names)
derive_zones(network_fc, inner_features, bbox, mode, offset_m=1000.0)
"""

from __future__ import annotations

import logging

from stalled.zone_intersector.domain.zone import (  # noqa: F401
    _CBS_COLS,
    _LEERLING_COLS,
    _calc_production,
    _calc_attraction,
    parse_inner_zones_rows,
)
from stalled.zone_intersector.domain.geometry import (  # noqa: F401
    _COMPASS_8,
    _D_LAT,
    _d_lon,
    _is_inside_bbox,
    _nudge_point,
    _bearing_deg,
    _compass_8_label,
    _circle_polygon,
)
from stalled.zone_intersector.domain.sql import (  # noqa: F401
    build_inner_zones_sql,
    bbox_to_polygon_json,
)

logger = logging.getLogger(__name__)

# Output schema — property keys present on every feature in the output FeatureCollection.
ZONE_PROPERTIES: tuple[str, ...] = (
    "gid",
    "zoneId",
    "zoneName",
    "zoneType",
    "ringIndex",
    "ringLabel",
    "sectorIndex",
    "constituentZoneIds",
    "centroidLon",
    "centroidLat",
    "production",
    "attraction",
    "nodeId",
    "mode",
    "nCrossingLinks",
    *_CBS_COLS,
)


def derive_zones(
    network_fc: dict,
    inner_features: list,
    mode: str,
    offset_m: float = 1000.0,
) -> dict:
    """Derive a zone FeatureCollection from pre-loaded inner zones + crossing nodes.

    The bounding box is read from ``network_fc["properties"]["bbox"]``.
    """
    bbox = (network_fc.get("properties") or {}).get("bbox")
    if not bbox or len(bbox) != 4:
        raise ValueError("network_fc must contain a 'bbox' list of 4 floats in its properties")

    features = network_fc.get("features") or []
    logger.info("Network features: %d", len(features))

    cx_lon = (bbox[0] + bbox[2]) / 2.0
    cx_lat = (bbox[1] + bbox[3]) / 2.0

    crossing: dict[str, dict] = {}

    for feat in features:
        geom  = feat.get("geometry") or {}
        props = feat.get("properties") or {}

        if geom.get("type") != "LineString":
            continue

        coords = geom.get("coordinates") or []
        if len(coords) < 2:
            continue

        from_lon, from_lat = coords[0][0],  coords[0][1]
        to_lon,   to_lat   = coords[-1][0], coords[-1][1]

        from_inside = _is_inside_bbox(from_lon, from_lat, bbox)
        to_inside   = _is_inside_bbox(to_lon,   to_lat,   bbox)

        if from_inside == to_inside:
            continue

        flow      = float(props.get("flow24hrs") or 0.0)
        feat_mode = props.get("mode") or mode

        if not from_inside:
            ext_lon, ext_lat = from_lon, from_lat
            node_id          = props.get("fromNode")
            production_add   = flow
            attraction_add   = 0.0
        else:
            ext_lon, ext_lat = to_lon, to_lat
            node_id          = props.get("toNode")
            production_add   = 0.0
            attraction_add   = flow

        key = str(node_id) if node_id is not None else f"{ext_lon:.7f},{ext_lat:.7f}"

        if key not in crossing:
            crossing[key] = {
                "lon":        ext_lon,
                "lat":        ext_lat,
                "production": 0.0,
                "attraction": 0.0,
                "node_id":    node_id,
                "mode":       feat_mode,
                "n_links":    0,
            }
        crossing[key]["production"] += production_add
        crossing[key]["attraction"] += attraction_add
        crossing[key]["n_links"]    += 1

    logger.info("Crossing nodes found: %d", len(crossing))

    def _sort_key(item: tuple) -> tuple:
        _, node = item
        bearing = _bearing_deg(cx_lon, cx_lat, node["lon"], node["lat"])
        return (int((bearing + 22.5) / 45.0) % 8, bearing)

    sorted_nodes = sorted(crossing.items(), key=_sort_key)

    max_inner_gid = max(
        (f["properties"]["gid"] for f in inner_features if f["properties"]["gid"] is not None),
        default=0,
    )

    crossing_features = []
    for i, (_key, node) in enumerate(sorted_nodes, start=1):
        bearing    = _bearing_deg(cx_lon, cx_lat, node["lon"], node["lat"])
        compass    = _compass_8_label(bearing)
        sector_idx = int((bearing + 22.5) / 45.0) % 8

        nudged_lon, nudged_lat = _nudge_point(
            node["lon"], node["lat"], cx_lon, cx_lat, offset_m
        )

        zone_id   = f"cross_{node['node_id']}"
        zone_name = f"Boundary node {compass} ({node['node_id']})"

        crossing_features.append({
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [_circle_polygon(nudged_lon, nudged_lat, 250.0)],
            },
            "properties": {
                "gid":                max_inner_gid + i,
                "zoneId":            zone_id,
                "zoneName":          zone_name,
                "zoneType":          "aggregate",
                "ringIndex":         0,
                "ringLabel":         "bbox-boundary",
                "sectorIndex":       sector_idx,
                "constituentZoneIds": [],
                "centroidLon":       nudged_lon,
                "centroidLat":       nudged_lat,
                "production":         node["production"],
                "attraction":         node["attraction"],
                "nodeId":            node["node_id"],
                "mode":               node["mode"],
                "nCrossingLinks":   node["n_links"],
            },
        })

    all_features = inner_features + crossing_features
    logger.info(
        "Zones built: %d inner + %d crossing = %d total",
        len(inner_features), len(crossing_features), len(all_features),
    )
    return {
        "type": "FeatureCollection",
        "features": all_features,
        "properties": {"zone_properties": list(ZONE_PROPERTIES)},
    }
