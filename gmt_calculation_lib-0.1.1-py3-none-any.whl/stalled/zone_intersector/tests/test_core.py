"""Unit tests for zone_intersector.zone_intersector_core.

All tests are pure — no boto3, no Databricks, no network calls.
"""

from __future__ import annotations

import json
import math

import pytest

from stalled.zone_intersector.core.zone_intersector_core import (
    _CBS_COLS,
    _COMPASS_8,
    _D_LAT,
    _bearing_deg,
    _circle_polygon,
    _compass_8_label,
    _d_lon,
    _is_inside_bbox,
    _nudge_point,
    bbox_to_polygon_json,
    build_inner_zones_sql,
    derive_zones,
    parse_inner_zones_rows,
)

# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------

_BBOX = [6.0, 52.0, 6.2, 52.1]  # [minLon, minLat, maxLon, maxLat]
_CX_LON = 6.1
_CX_LAT = 52.05


def _make_network(features: list) -> dict:
    return {"type": "FeatureCollection", "features": features, "properties": {"bbox": _BBOX}}


def _link(
    from_coords: list,
    to_coords: list,
    from_node: int | None = 1,
    to_node: int | None = 2,
    flow: float = 1000.0,
    mode: str = "CAR",
) -> dict:
    """Return a minimal LineString Feature representing a network link."""
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [from_coords, to_coords]},
        "properties": {
            "fromNode": from_node,
            "toNode":   to_node,
            "flow24hrs": flow,
            "mode":     mode,
        },
    }


def _inner_zone(gid: int) -> dict:
    """Return a minimal inner zone Feature."""
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [[[6.05, 52.02], [6.15, 52.02],
                                                          [6.15, 52.08], [6.05, 52.08],
                                                          [6.05, 52.02]]]},
        "properties": {
            "gid":               gid,
            "zoneId":           f"zone_{gid}",
            "zoneName":         f"Zone {gid}",
            "zoneType":         "inner",
            "ringIndex":        -1,
            "ringLabel":        "",
            "sectorIndex":      -1,
            "constituentZoneIds": [],
            "centroidLon":      6.1,
            "centroidLat":      52.05,
            "production":        0.0,
            "attraction":        0.0,
            "nodeId":           None,
            "mode":              None,
            "nCrossingLinks":  0,
        },
    }


# ---------------------------------------------------------------------------
# _d_lon
# ---------------------------------------------------------------------------

class TestDLon:
    def test_at_equator_equals_d_lat(self):
        assert math.isclose(_d_lon(0.0), _D_LAT, rel_tol=1e-9)

    def test_at_60_degrees(self):
        # cos(60°) = 0.5  →  d_lon ≈ D_LAT / 2
        assert math.isclose(_d_lon(60.0), _D_LAT * 0.5, rel_tol=1e-6)

    def test_at_90_degrees_approaches_zero(self):
        assert _d_lon(90.0) < 1e-6

    def test_positive_value(self):
        assert _d_lon(52.0) > 0


# ---------------------------------------------------------------------------
# _is_inside_bbox
# ---------------------------------------------------------------------------

class TestIsInsideBbox:
    def test_centre_is_inside(self):
        assert _is_inside_bbox(6.1, 52.05, _BBOX) is True

    def test_outside_west(self):
        assert _is_inside_bbox(5.9, 52.05, _BBOX) is False

    def test_outside_east(self):
        assert _is_inside_bbox(6.3, 52.05, _BBOX) is False

    def test_outside_south(self):
        assert _is_inside_bbox(6.1, 51.9, _BBOX) is False

    def test_outside_north(self):
        assert _is_inside_bbox(6.1, 52.2, _BBOX) is False

    def test_on_west_boundary_is_inside(self):
        assert _is_inside_bbox(6.0, 52.05, _BBOX) is True

    def test_on_east_boundary_is_inside(self):
        assert _is_inside_bbox(6.2, 52.05, _BBOX) is True

    def test_on_south_boundary_is_inside(self):
        assert _is_inside_bbox(6.1, 52.0, _BBOX) is True

    def test_on_north_boundary_is_inside(self):
        assert _is_inside_bbox(6.1, 52.1, _BBOX) is True


# ---------------------------------------------------------------------------
# _nudge_point
# ---------------------------------------------------------------------------

class TestNudgePoint:
    def test_nudge_moves_away_from_centre(self):
        # Point due east of centre; nudge should increase lon
        lon, lat = _nudge_point(6.2, 52.05, _CX_LON, _CX_LAT, 500.0)
        assert lon > 6.2
        assert math.isclose(lat, 52.05, abs_tol=1e-6)

    def test_nudge_distance_is_approx_correct(self):
        # Point 1 km east of centre before nudge; nudge by 500 m
        far_lon = _CX_LON + 1000.0 / _d_lon(52.05)
        lon_after, _ = _nudge_point(far_lon, _CX_LAT, _CX_LON, _CX_LAT, 500.0)
        # New distance from centre ≈ 1500 m
        new_dist_deg = (lon_after - _CX_LON) * _d_lon(52.05)
        assert math.isclose(new_dist_deg, 1500.0, rel_tol=0.01)

    def test_coincident_point_returns_unchanged(self):
        lon, lat = _nudge_point(_CX_LON, _CX_LAT, _CX_LON, _CX_LAT, 500.0)
        assert lon == _CX_LON
        assert lat == _CX_LAT

    def test_nudge_north(self):
        # Point due north of centre; nudge should increase lat
        north_lat = _CX_LAT + 0.01
        _, lat_after = _nudge_point(_CX_LON, north_lat, _CX_LON, _CX_LAT, 500.0)
        assert lat_after > north_lat


# ---------------------------------------------------------------------------
# _bearing_deg
# ---------------------------------------------------------------------------

class TestBearingDeg:
    def test_bearing_east(self):
        # Moving east → bearing ≈ 90°
        b = _bearing_deg(6.0, 52.0, 6.1, 52.0)
        assert math.isclose(b, 90.0, abs_tol=1.0)

    def test_bearing_west(self):
        # Moving west → bearing ≈ 270°
        b = _bearing_deg(6.1, 52.0, 6.0, 52.0)
        assert math.isclose(b, 270.0, abs_tol=1.0)

    def test_bearing_north(self):
        # Moving north → bearing = 0°
        b = _bearing_deg(6.0, 52.0, 6.0, 52.1)
        assert math.isclose(b, 0.0, abs_tol=1.0)

    def test_bearing_south(self):
        # Moving south → bearing = 180°
        b = _bearing_deg(6.0, 52.1, 6.0, 52.0)
        assert math.isclose(b, 180.0, abs_tol=1.0)

    def test_bearing_northeast(self):
        b = _bearing_deg(6.0, 52.0, 6.1, 52.1)
        assert 10.0 < b < 80.0

    def test_bearing_always_in_range(self):
        for dlon, dlat in [(-1, 0), (0, 1), (1, 1), (-1, -1)]:
            b = _bearing_deg(6.0, 52.0, 6.0 + dlon * 0.1, 52.0 + dlat * 0.1)
            assert 0.0 <= b < 360.0


# ---------------------------------------------------------------------------
# _compass_8_label
# ---------------------------------------------------------------------------

class TestCompass8Label:
    def test_north(self):
        assert _compass_8_label(0.0) == "N"

    def test_northeast(self):
        assert _compass_8_label(45.0) == "NO"

    def test_east(self):
        assert _compass_8_label(90.0) == "O"

    def test_southeast(self):
        assert _compass_8_label(135.0) == "ZO"

    def test_south(self):
        assert _compass_8_label(180.0) == "Z"

    def test_southwest(self):
        assert _compass_8_label(225.0) == "ZW"

    def test_west(self):
        assert _compass_8_label(270.0) == "W"

    def test_northwest(self):
        assert _compass_8_label(315.0) == "NW"

    def test_360_wraps_to_north(self):
        assert _compass_8_label(360.0) == "N"

    def test_all_labels_in_constant(self):
        for deg in range(0, 360, 45):
            assert _compass_8_label(float(deg)) in _COMPASS_8


# ---------------------------------------------------------------------------
# _circle_polygon
# ---------------------------------------------------------------------------

class TestCirclePolygon:
    def test_closed_ring(self):
        ring = _circle_polygon(6.1, 52.05, 250.0)
        assert ring[0] == ring[-1], "Ring must be closed (first == last)"

    def test_vertex_count(self):
        ring = _circle_polygon(6.1, 52.05, 250.0, n=8)
        assert len(ring) == 9  # n + 1

    def test_default_n_is_16(self):
        ring = _circle_polygon(6.1, 52.05, 250.0)
        assert len(ring) == 17

    def test_approx_radius(self):
        lon, lat, radius_m = 6.1, 52.05, 1000.0
        ring = _circle_polygon(lon, lat, radius_m)
        dlon = _d_lon(lat)
        for coord in ring[:-1]:  # skip closing duplicate
            dx = (coord[0] - lon) * dlon
            dy = (coord[1] - lat) * _D_LAT
            dist = math.hypot(dx, dy)
            assert math.isclose(dist, radius_m, rel_tol=0.01)


# ---------------------------------------------------------------------------
# bbox_to_polygon_json
# ---------------------------------------------------------------------------

class TestBboxToPolygonJson:
    def test_returns_valid_json(self):
        result = bbox_to_polygon_json(_BBOX)
        obj = json.loads(result)
        assert obj["type"] == "Polygon"

    def test_ring_is_closed(self):
        obj = json.loads(bbox_to_polygon_json(_BBOX))
        ring = obj["coordinates"][0]
        assert ring[0] == ring[-1]

    def test_contains_all_corners(self):
        obj = json.loads(bbox_to_polygon_json(_BBOX))
        ring = obj["coordinates"][0]
        lons = {c[0] for c in ring}
        lats = {c[1] for c in ring}
        assert 6.0 in lons and 6.2 in lons
        assert 52.0 in lats and 52.1 in lats


# ---------------------------------------------------------------------------
# build_inner_zones_sql
# ---------------------------------------------------------------------------

class TestBuildInnerZonesSql:
    def test_contains_catalog_and_schema(self):
        sql = build_inner_zones_sql("my_catalog", "my_schema")
        assert "my_catalog" in sql
        assert "my_schema" in sql

    def test_contains_placeholder(self):
        sql = build_inner_zones_sql("spectrum", "2023_01")
        assert "?" in sql

    def test_references_correct_table(self):
        sql = build_inner_zones_sql("spectrum", "2023_01")
        assert "d030_zones_met_centroids" in sql

    def test_selects_required_columns(self):
        sql = build_inner_zones_sql("spectrum", "2023_01")
        for col in ("gid", "zone_id", "zone_naam", "zone_geom_json", "centroidLon", "centroidLat"):
            assert col in sql

    def test_returns_string(self):
        assert isinstance(build_inner_zones_sql("a", "b"), str)


# ---------------------------------------------------------------------------
# parse_inner_zones_rows
# ---------------------------------------------------------------------------

class TestParseInnerZonesRows:
    # Fixed structural columns; CBS columns appended dynamically from _CBS_COLS.
    _FIXED_COLS = ["gid", "zone_id", "zoneName", "zone_geom_json", "centroidLon", "centroidLat"]
    _COL_NAMES  = _FIXED_COLS + list(_CBS_COLS)

    _GEOM = json.dumps({"type": "Polygon", "coordinates": [[[6.0, 52.0], [6.1, 52.0],
                                                             [6.1, 52.1], [6.0, 52.0]]]})

    def _row(self, gid=1, zone_id="z1", zone_naam="Zone 1", geom=None,
             c_lon=6.05, c_lat=52.05, **cbs_overrides):
        """Build a result-set tuple with all CBS columns defaulting to 0.0."""
        fixed = (gid, zone_id, zone_naam, geom or self._GEOM, c_lon, c_lat)
        cbs   = tuple(float(cbs_overrides.get(c, 0.0) or 0.0) for c in _CBS_COLS)
        return fixed + cbs

    def test_basic_row(self):
        features = parse_inner_zones_rows([self._row()], self._COL_NAMES)
        assert len(features) == 1

    def test_feature_type(self):
        features = parse_inner_zones_rows([self._row()], self._COL_NAMES)
        assert features[0]["type"] == "Feature"

    def test_zone_type_is_inner(self):
        features = parse_inner_zones_rows([self._row()], self._COL_NAMES)
        assert features[0]["properties"]["zoneType"] == "inner"

    def test_gid_preserved(self):
        features = parse_inner_zones_rows([self._row(gid=42)], self._COL_NAMES)
        assert features[0]["properties"]["gid"] == 42

    def test_zero_production_and_attraction(self):
        # When all CBS columns are 0.0, production and attraction must both be 0.
        features = parse_inner_zones_rows([self._row()], self._COL_NAMES)
        props = features[0]["properties"]
        assert props["production"] == 0.0
        assert props["attraction"] == 0.0

    def test_production_formula(self):
        # production = (7 × huishoudens + 2.3 × inwoners) / 2
        features = parse_inner_zones_rows(
            [self._row(huishoudens=100.0, inwoners=200.0)], self._COL_NAMES
        )
        expected = (7.0 * 100.0 + 2.3 * 200.0) / 2.0
        assert features[0]["properties"]["production"] == pytest.approx(expected)

    def test_attraction_formula(self):
        # attraction = 2 × (arbeidsplaatsen + Σ leerlingplaatsen_*)
        features = parse_inner_zones_rows(
            [self._row(
                arbeidsplaatsen=500.0,
                leerlingplaatsen_basisonderwijs=50.0,
                leerlingplaatsen_middelbaaronderwijs=30.0,
                leerlingplaatsen_middelbaarberoepsonderwijs=20.0,
                leerlingplaatsen_hogeronderwijs=10.0,
            )],
            self._COL_NAMES,
        )
        expected = 2.0 * (500.0 + 50.0 + 30.0 + 20.0 + 10.0)
        assert features[0]["properties"]["attraction"] == pytest.approx(expected)

    def test_none_columns_treated_as_zero(self):
        # Databricks may return NULL for zones with no demographic data.
        # Build a row with all CBS columns set to None.
        fixed = (1, "z1", "Zone 1", self._GEOM, 6.05, 52.05)
        row = fixed + tuple(None for _ in _CBS_COLS)
        features = parse_inner_zones_rows([row], self._COL_NAMES)
        props = features[0]["properties"]
        assert props["production"] == 0.0
        assert props["attraction"] == 0.0

    def test_cbs_cols_present_as_properties(self):
        # All _CBS_COLS must appear as properties on the feature.
        features = parse_inner_zones_rows([self._row(inwoners=100.0)], self._COL_NAMES)
        props = features[0]["properties"]
        for col in _CBS_COLS:
            assert col in props

    def test_ring_index_minus_one(self):
        features = parse_inner_zones_rows([self._row()], self._COL_NAMES)
        assert features[0]["properties"]["ringIndex"] == -1

    def test_node_id_is_none(self):
        features = parse_inner_zones_rows([self._row()], self._COL_NAMES)
        assert features[0]["properties"]["nodeId"] is None

    def test_centroid_preserved(self):
        features = parse_inner_zones_rows([self._row(c_lon=6.05, c_lat=52.05)], self._COL_NAMES)
        props = features[0]["properties"]
        assert props["centroidLon"] == 6.05
        assert props["centroidLat"] == 52.05

    def test_skips_row_with_no_geometry(self):
        row = self._row()
        row = (*row[:3], None, *row[4:])
        features = parse_inner_zones_rows([row], self._COL_NAMES)
        assert features == []

    def test_skips_row_with_bad_geometry_json(self):
        row = self._row(geom="not-json{{{")
        features = parse_inner_zones_rows([row], self._COL_NAMES)
        assert features == []

    def test_multiple_rows(self):
        rows = [self._row(gid=i) for i in range(5)]
        features = parse_inner_zones_rows(rows, self._COL_NAMES)
        assert len(features) == 5
        gids = [f["properties"]["gid"] for f in features]
        assert gids == list(range(5))

    def test_empty_rows(self):
        features = parse_inner_zones_rows([], self._COL_NAMES)
        assert features == []


# ---------------------------------------------------------------------------
# derive_zones
# ---------------------------------------------------------------------------

# Shared geometry: bbox  [6.0, 52.0, 6.2, 52.1]
# Centre:  cx_lon=6.1, cx_lat=52.05
# Inside:  lon ∈ [6.0, 6.2]  lat ∈ [52.0, 52.1]
# Outside: lon < 6.0 or lon > 6.2 or lat < 52.0 or lat > 52.1

_INSIDE_PT  = [6.1,  52.05]   # centre — clearly inside
_WEST_PT    = [5.9,  52.05]   # outside west
_EAST_PT    = [6.3,  52.05]   # outside east
_NORTH_PT   = [6.1,  52.15]   # outside north
_SOUTH_PT   = [6.1,  51.95]   # outside south


class TestDeriveZones:
    def test_returns_feature_collection(self):
        result = derive_zones(_make_network([]), [], "CAR")
        assert result["type"] == "FeatureCollection"
        assert isinstance(result["features"], list)

    def test_empty_network_no_crossings(self):
        result = derive_zones(_make_network([]), [], "CAR")
        assert result["features"] == []

    def test_inner_features_included_unchanged(self):
        zone = _inner_zone(gid=10)
        result = derive_zones(_make_network([]), [zone], "CAR")
        assert len(result["features"]) == 1
        assert result["features"][0]["properties"]["gid"] == 10

    def test_non_linestring_features_ignored(self):
        point_feat = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": _WEST_PT},
            "properties": {},
        }
        result = derive_zones(_make_network([point_feat]), [], "CAR")
        assert result["features"] == []

    def test_short_linestring_ignored(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [_WEST_PT]},  # only 1 coord
            "properties": {},
        }
        result = derive_zones(_make_network([feat]), [], "CAR")
        assert result["features"] == []

    def test_link_both_inside_no_crossing(self):
        net = _make_network([_link(_INSIDE_PT, [6.15, 52.05])])
        result = derive_zones(net, [], "CAR")
        assert result["features"] == []

    def test_link_both_outside_no_crossing(self):
        net = _make_network([_link(_WEST_PT, _EAST_PT)])
        result = derive_zones(net, [], "CAR")
        assert result["features"] == []

    def test_entering_link_produces_crossing_zone(self):
        # fromNode outside (west), toNode inside → entering → production
        net = _make_network([_link(_WEST_PT, _INSIDE_PT, from_node=100, flow=1000.0)])
        result = derive_zones(net, [], "CAR")
        assert len(result["features"]) == 1
        props = result["features"][0]["properties"]
        assert props["zoneType"] == "aggregate"
        assert props["production"] == 1000.0
        assert props["attraction"] == 0.0
        assert props["nodeId"] == 100

    def test_leaving_link_produces_crossing_zone(self):
        # fromNode inside, toNode outside (east) → leaving → attraction
        net = _make_network([_link(_INSIDE_PT, _EAST_PT, to_node=201, flow=500.0)])
        result = derive_zones(net, [], "CAR")
        assert len(result["features"]) == 1
        props = result["features"][0]["properties"]
        assert props["zoneType"] == "aggregate"
        assert props["production"] == 0.0
        assert props["attraction"] == 500.0
        assert props["nodeId"] == 201

    def test_two_links_same_external_node_grouped(self):
        # Two links sharing the same external node (same position) → 1 crossing zone
        net = _make_network([
            _link(_WEST_PT, _INSIDE_PT, from_node=100, flow=1000.0),
            _link(_WEST_PT, [6.12, 52.05], from_node=100, flow=500.0),
        ])
        result = derive_zones(net, [], "CAR")
        assert len(result["features"]) == 1
        props = result["features"][0]["properties"]
        assert props["production"] == 1500.0
        assert props["nCrossingLinks"] == 2

    def test_two_links_same_node_id_different_coords_grouped(self):
        # Two entering links with the same from_node id but slightly different
        # from_coords (> 1e-7 degrees apart) → must still produce 1 crossing zone
        # because grouping is by node_id, not by position.
        coords_a = [5.999990, 52.050000]  # just outside west edge
        coords_b = [5.999991, 52.050010]  # same node, slightly different coords
        net = _make_network([
            _link(coords_a, _INSIDE_PT, from_node=100, flow=600.0),
            _link(coords_b, [6.12, 52.05], from_node=100, flow=400.0),
        ])
        result = derive_zones(net, [], "CAR")
        assert len(result["features"]) == 1
        props = result["features"][0]["properties"]
        assert props["nodeId"] == 100
        assert props["production"] == 1000.0
        assert props["nCrossingLinks"] == 2

    def test_two_links_no_node_id_positional_fallback(self):
        # Two entering links with node_id=None but identical coords → positional
        # fallback still groups them into 1 zone (regression guard).
        net = _make_network([
            _link(_WEST_PT, _INSIDE_PT, from_node=None, flow=300.0),
            _link(_WEST_PT, [6.12, 52.05], from_node=None, flow=200.0),
        ])
        result = derive_zones(net, [], "CAR")
        assert len(result["features"]) == 1
        props = result["features"][0]["properties"]
        assert props["production"] == 500.0
        assert props["nCrossingLinks"] == 2

    def test_crossing_zone_geometry_is_polygon(self):
        net = _make_network([_link(_WEST_PT, _INSIDE_PT)])
        result = derive_zones(net, [], "CAR")
        geom = result["features"][0]["geometry"]
        assert geom["type"] == "Polygon"

    def test_crossing_zone_ring_is_closed(self):
        net = _make_network([_link(_WEST_PT, _INSIDE_PT)])
        result = derive_zones(net, [], "CAR")
        ring = result["features"][0]["geometry"]["coordinates"][0]
        assert ring[0] == ring[-1]

    def test_crossing_zone_has_all_required_properties(self):
        net = _make_network([_link(_WEST_PT, _INSIDE_PT, from_node=100)])
        result = derive_zones(net, [], "CAR")
        props = result["features"][0]["properties"]
        required = {
            "gid", "zoneId", "zoneName", "zoneType", "ringIndex", "ringLabel",
            "sectorIndex", "constituentZoneIds", "centroidLon", "centroidLat",
            "production", "attraction", "nodeId", "mode", "nCrossingLinks",
        }
        assert required.issubset(props.keys())

    def test_crossing_zone_ring_label(self):
        net = _make_network([_link(_WEST_PT, _INSIDE_PT)])
        result = derive_zones(net, [], "CAR")
        assert result["features"][0]["properties"]["ringLabel"] == "bbox-boundary"

    def test_crossing_zone_ring_index_zero(self):
        net = _make_network([_link(_WEST_PT, _INSIDE_PT)])
        result = derive_zones(net, [], "CAR")
        assert result["features"][0]["properties"]["ringIndex"] == 0

    def test_gids_follow_max_inner_gid(self):
        inner = [_inner_zone(gid=10), _inner_zone(gid=20)]
        net = _make_network([
            _link(_WEST_PT, _INSIDE_PT, from_node=100),  # W  → sector 6
            _link(_INSIDE_PT, _EAST_PT, to_node=201),    # E  → sector 2
        ])
        result = derive_zones(net, inner, "CAR")
        crossing_props = [
            f["properties"] for f in result["features"]
            if f["properties"]["zoneType"] == "aggregate"
        ]
        gids = {p["gid"] for p in crossing_props}
        # Two crossing zones → gid 21 and 22
        assert gids == {21, 22}

    def test_crossing_zones_sorted_by_compass(self):
        # East node (sector 2) sorts before West node (sector 6)
        net = _make_network([
            _link(_WEST_PT,   _INSIDE_PT, from_node=100),  # external node W → sector 6
            _link(_INSIDE_PT, _EAST_PT,   to_node=201),    # external node E → sector 2
        ])
        result = derive_zones(net, [], "CAR")
        crossing = [f for f in result["features"] if f["properties"]["zoneType"] == "aggregate"]
        sectors = [f["properties"]["sectorIndex"] for f in crossing]
        assert sectors == sorted(sectors), "Crossing zones must be sorted by sector"

    def test_mode_fallback_used_when_link_has_no_mode(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [_WEST_PT, _INSIDE_PT]},
            "properties": {"fromNode": 100, "toNode": 101, "flow24hrs": 100.0},
            # No "mode" property
        }
        result = derive_zones(_make_network([feat]), [], "BIKE")
        props = result["features"][0]["properties"]
        assert props["mode"] == "BIKE"

    def test_zero_flow_link_still_creates_crossing_zone(self):
        net = _make_network([_link(_WEST_PT, _INSIDE_PT, flow=0.0)])
        result = derive_zones(net, [], "CAR")
        assert len(result["features"]) == 1

    def test_north_link_compass_label(self):
        net = _make_network([_link(_NORTH_PT, _INSIDE_PT, from_node=99)])
        result = derive_zones(net, [], "CAR")
        zone_name = result["features"][0]["properties"]["zoneName"]
        assert "N" in zone_name

    def test_west_link_compass_label(self):
        net = _make_network([_link(_WEST_PT, _INSIDE_PT, from_node=100)])
        result = derive_zones(net, [], "CAR")
        zone_name = result["features"][0]["properties"]["zoneName"]
        assert "W" in zone_name

    def test_zone_id_contains_node_id(self):
        net = _make_network([_link(_WEST_PT, _INSIDE_PT, from_node=999)])
        result = derive_zones(net, [], "CAR")
        zone_id = result["features"][0]["properties"]["zoneId"]
        assert "999" in zone_id

    def test_inner_plus_crossing_total(self):
        inner = [_inner_zone(gid=1), _inner_zone(gid=2)]
        net = _make_network([
            _link(_WEST_PT, _INSIDE_PT, from_node=100),
            _link(_INSIDE_PT, _NORTH_PT, to_node=200),
        ])
        result = derive_zones(net, inner, "CAR")
        # 2 inner + 2 crossing = 4
        assert len(result["features"]) == 4

    def test_missing_bbox_raises(self):
        with pytest.raises(ValueError, match="bbox"):
            derive_zones({"type": "FeatureCollection"}, [], "CAR")

    def test_offset_m_affects_centroid_position(self):
        net = _make_network([_link(_WEST_PT, _INSIDE_PT)])
        r1 = derive_zones(net, [], "CAR", offset_m=0.0)
        r2 = derive_zones(net, [], "CAR", offset_m=1000.0)
        lon1 = r1["features"][0]["properties"]["centroidLon"]
        lon2 = r2["features"][0]["properties"]["centroidLon"]
        # Larger offset → centroid nudged further west (smaller lon for W node)
        assert lon2 < lon1
