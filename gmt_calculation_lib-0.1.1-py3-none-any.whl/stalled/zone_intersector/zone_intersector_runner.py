"""Local debug runner for zone_intersector.

Calls zone_intersector_core and feedlink_creator_core directly — no Lambda handler involved.
Produces two output files per run:
  {area_id}-ZONE-{mode}.geojson     — inner + aggregate (crossing) zones
  {area_id}-FEEDLINK-{mode}.geojson — feedlinks connecting zone centroids to the network

Usage
-----
    python -m zone_intersector.zone_intersector_runner \\
        --network s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.geojson \\
        --output-folder s3://gmp-networks/zones/ \\
        --mode CAR \\
        --catalog spectrum --schema 2024_01

Prerequisites
-------------
* Databricks credentials in a .env file or os.environ
  (DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID, DATABRICKS_TOKEN).
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for zone_intersector. "
            "Produces ZONE and FEEDLINK GeoJSON outputs."
        )
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="Full URI of the input network GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help=(
            "Output folder URI (s3://bucket/prefix/ or local dir). "
            "Writes {area_id}-ZONE-{mode}.geojson and {area_id}-FEEDLINK-{mode}.geojson."
        ),
    )
    parser.add_argument("--mode", required=True, help="Transport mode label, e.g. CAR")
    parser.add_argument(
        "--centroid-offset-m",
        type=float,
        default=1000.0,
        help="Nudge distance for crossing-node centroids in metres (default: 1000)",
    )
    parser.add_argument("--catalog", default="spectrum", help="Databricks Unity Catalog name")
    parser.add_argument("--schema",  default="2024_01",  help="Databricks schema / dataset version")
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    mode = args.mode.upper()

    from stalled.zone_intersector.core.zone_intersector_core import (  # noqa: PLC0415
        build_inner_zones_sql,
        bbox_to_polygon_json,
        parse_inner_zones_rows,
        derive_zones,
    )
    from stalled.feedlink_creator.core.feedlink_creator_core import (  # noqa: PLC0415
        VOEDINGSLINKS_TABLE,
        build_voedingslinks_sql,
        parse_network_geojson,
        parse_zone_geojson,
        derive_feedlinks,
    )
    import shared.databricks_sql as databricks_sql  # noqa: PLC0415
    from shared.output_path import build_output_path  # noqa: PLC0415

    # 1. Read network
    print(f"Reading network : {args.network}")
    network_fc = json.loads(_read_uri(args.network))

    # 2. Extract bbox from network properties
    bbox = (network_fc.get("properties") or {}).get("bbox")
    if not bbox:
        raise SystemExit("ERROR: network GeoJSON is missing 'bbox' in its top-level properties.")
    print(f"Bbox from network: {bbox}")

    # 3. Resolve area_id
    area_id = (network_fc.get("properties") or {}).get("area_id")
    if not area_id:
        from uuid import uuid4  # noqa: PLC0415
        area_id = str(uuid4())
        print(f"area_id auto-generated: {area_id}")

    # 4. Query Databricks for inner zones
    print(f"Querying Databricks (inner zones): catalog={args.catalog!r}  schema={args.schema!r}")
    sql = build_inner_zones_sql(args.catalog, args.schema)
    with databricks_sql.connect_from_env() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, (bbox_to_polygon_json(bbox),))
            col_names = [d[0] for d in cur.description]
            rows      = cur.fetchall()
    print(f"Inner zone rows  : {len(rows)}")

    # 5. Parse + derive zones
    inner_features = parse_inner_zones_rows(rows, col_names)
    zones_fc       = derive_zones(network_fc, inner_features, mode, args.centroid_offset_m)
    zones_fc.setdefault("properties", {})["area_id"] = area_id
    print(f"Zones produced   : {len(zones_fc['features'])}")

    # 6. Query Databricks for voedingslinks (feedlink geometry / capacity)
    table_name = VOEDINGSLINKS_TABLE.get(mode)
    vl_rows: list = []
    if table_name:
        zones_list  = parse_zone_geojson(zones_fc)
        inner_gids  = [
            int(z["gid"])
            for z in zones_list
            if z.get("zoneType") == "inner" and z.get("gid") is not None
        ]
        print(
            f"Querying Databricks (voedingslinks): table={table_name!r}  "
            f"inner_gids={len(inner_gids)}"
        )
        vl_sql = build_voedingslinks_sql(args.catalog, args.schema, table_name, inner_gids)
        with databricks_sql.connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute(vl_sql)
                vl_col_names = [d[0] for d in cur.description]
                vl_rows = [dict(zip(vl_col_names, row)) for row in cur.fetchall()]
        print(f"Voedingslinks rows: {len(vl_rows)}")
    else:
        print(f"No voedingslinks table for mode {mode!r} — only aggregate feedlinks will be built.")

    # 6b. Back-populate nodeId on inner zone features from voedingslinks rows.
    #     Each inner zone has exactly one canonical network node (naar_knoop_id).
    #     We use the first row per gid as the authoritative node reference.
    if vl_rows:
        gid_to_node: dict[int, str] = {}
        for r in vl_rows:
            gid_val = r.get("van_centroid_gid")
            nid_val = r.get("naar_knoop_id")
            if gid_val is not None and nid_val is not None:
                gid_to_node.setdefault(int(gid_val), str(nid_val))
        for feat in zones_fc["features"]:
            props = feat.get("properties") or {}
            if props.get("zoneType") == "inner":
                gid_val = props.get("gid")
                if gid_val is not None:
                    node_id = gid_to_node.get(int(gid_val))
                    props["nodeId"] = node_id
                    if node_id is None:
                        print(
                            f"  WARNING: zone {props.get('zoneId')} (gid={gid_val})"
                            " has no voedingslinks row — nodeId remains null"
                        )
        print(f"nodeId populated : {len(gid_to_node)} inner zone(s)")

    # 6c. Filter zones: keep only zones where nodeId is in the network, or nodeId is null
    #     (aggregate / clustered zones have no nodeId and are always kept).
    #     Normalise both sides to str to avoid int/str type mismatches.
    network_parsed    = parse_network_geojson(network_fc)
    all_node_ids_str  = {str(n) for n in network_parsed["all_node_ids"]}
    before_filter  = len(zones_fc["features"])
    kept, dropped  = [], []
    for feat in zones_fc["features"]:
        props   = feat.get("properties") or {}
        node_id = props.get("nodeId")
        if node_id is None or str(node_id) in all_node_ids_str:
            kept.append(feat)
        else:
            dropped.append(props.get("zoneId"))
    zones_fc["features"] = kept
    if dropped:
        print(
            f"Zones filtered   : {len(kept)} kept, {len(dropped)} dropped"
            f" (nodeId not in network): {', '.join(str(z) for z in dropped)}"
        )
    else:
        print(f"Zones filtered   : {before_filter} kept, 0 dropped")

    # 7. Derive feedlinks
    zones_parsed   = parse_zone_geojson(zones_fc)
    feedlinks_fc   = derive_feedlinks(
        network_parsed, zones_parsed, vl_rows, mode,
    )
    feedlinks_fc.setdefault("properties", {})["area_id"] = area_id
    print(f"Feedlinks produced: {len(feedlinks_fc['features'])}")

    # 8. Write outputs
    zones_uri     = build_output_path(args.output_folder, area_id, "ZONE", mode)
    feedlinks_uri = build_output_path(args.output_folder, area_id, "FEEDLINK", mode)

    print(f"Writing zones    : {zones_uri}")
    _write_uri(zones_uri, json.dumps(zones_fc, ensure_ascii=False).encode("utf-8"))

    print(f"Writing feedlinks: {feedlinks_uri}")
    _write_uri(feedlinks_uri, json.dumps(feedlinks_fc, ensure_ascii=False).encode("utf-8"))

    print("Done.")


if __name__ == "__main__":
    main()
