"""Request model for the zone-intersector Lambda."""

from __future__ import annotations

from pydantic import BaseModel


class HandlerInput(BaseModel):
    input_network_file: str
    output_folder: str
    mode: str
    centroid_offset_m: float = 1000.0
    catalog: str | None = None
    db_schema: str | None = None
