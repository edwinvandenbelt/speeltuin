"""Local debug runner for zone_splitter.

Reads a network GeoJSON and a zones GeoJSON, splits zones into one mini-zone
per network node, overwrites the zones file in place, and writes (or overwrites)
a feedlinks file with the 1-to-1 node feedlinks.

Usage
-----
    python -m zone_splitter.zone_splitter_runner \\
        --network  path/to/{area_id}-NETWORK-CAR.geojson \\
        --zones    path/to/{area_id}-ZONE-CAR.geojson \\
        --feedlinks path/to/{area_id}-FEEDLINK-CAR.geojson

    # S3 URIs are also accepted:
    python -m zone_splitter.zone_splitter_runner \\
        --network  s3://gmp-networks/network/abc-NETWORK-CAR.geojson \\
        --zones    s3://gmp-networks/zones/abc-ZONE-CAR.geojson \\
        --feedlinks s3://gmp-networks/feedlinks/abc-FEEDLINK-CAR.geojson

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for zone_splitter. "
            "Splits zones into one mini-zone per network node and overwrites the zones file."
        )
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="URI of the network GeoJSON (read-only; s3:// or local path).",
    )
    parser.add_argument(
        "--zones",
        required=True,
        metavar="URI",
        help="URI of the zones GeoJSON (read + overwrite in place; s3:// or local path).",
    )
    parser.add_argument(
        "--feedlinks",
        required=True,
        metavar="URI",
        help="URI of the feedlinks GeoJSON (write/overwrite; s3:// or local path).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from zone_splitter.core.zone_splitter_core import split_zones  # noqa: PLC0415

    print(f"Reading network  : {args.network}")
    network_fc = json.loads(_read_uri(args.network))

    print(f"Reading zones    : {args.zones}")
    zones_fc = json.loads(_read_uri(args.zones))

    new_zones_fc, new_feedlinks_fc, stats = split_zones(network_fc, zones_fc)

    print(f"Stats            : {stats}")
    print(f"Writing zones    : {args.zones}")
    _write_uri(args.zones, json.dumps(new_zones_fc, ensure_ascii=False).encode("utf-8"))
    print(f"Writing feedlinks: {args.feedlinks}")
    _write_uri(args.feedlinks, json.dumps(new_feedlinks_fc, ensure_ascii=False).encode("utf-8"))
    print("Done.")


if __name__ == "__main__":
    main()
