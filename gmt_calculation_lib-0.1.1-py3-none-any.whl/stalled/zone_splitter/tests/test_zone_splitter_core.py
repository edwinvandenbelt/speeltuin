"""Tests for zone_splitter_core."""

from __future__ import annotations

import math

import pytest

from zone_splitter.core.zone_splitter_core import (
    _assign_nodes_to_zones,
    _extract_node_coords,
    _node_link_lengths,
    _node_max_capacities,
    _point_in_polygon,
    _scale_properties,
    _square_polygon,
    split_zones,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _link(link_id: str, from_node: str, to_node: str,
          from_coord: list, to_coord: list, length_m: float = 100.0) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [from_coord, to_coord]},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "length": length_m,
        },
    }


def _zone(zone_id: str, ring: list, **extra_props) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring + [ring[0]]]},
        "properties": {"zoneId": zone_id, **extra_props},
    }


def _fc(features: list) -> dict:
    return {"type": "FeatureCollection", "features": features}


# A unit square zone [0,0] → [1,1]
UNIT_SQUARE = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]


# ---------------------------------------------------------------------------
# Unit: _square_polygon
# ---------------------------------------------------------------------------

class TestSquarePolygon:
    def test_returns_polygon(self):
        poly = _square_polygon(5.0, 52.0)
        assert poly["type"] == "Polygon"

    def test_ring_is_closed(self):
        ring = _square_polygon(5.0, 52.0)["coordinates"][0]
        assert ring[0] == ring[-1]

    def test_five_points(self):
        ring = _square_polygon(5.0, 52.0)["coordinates"][0]
        assert len(ring) == 5

    def test_width_approx_10m(self):
        ring = _square_polygon(5.0, 52.0)["coordinates"][0]
        lons = [p[0] for p in ring]
        dlon = max(lons) - min(lons)
        # dlon in degrees * cos(lat) * 111320 ≈ 10 m
        width_m = dlon * math.cos(math.radians(52.0)) * 111_320.0
        assert abs(width_m - 10.0) < 0.5

    def test_height_approx_10m(self):
        ring = _square_polygon(5.0, 52.0)["coordinates"][0]
        lats = [p[1] for p in ring]
        dlat = max(lats) - min(lats)
        height_m = dlat * 111_320.0
        assert abs(height_m - 10.0) < 0.5


# ---------------------------------------------------------------------------
# Unit: _point_in_polygon
# ---------------------------------------------------------------------------

class TestPointInPolygon:
    def test_centre_inside(self):
        assert _point_in_polygon(0.5, 0.5, [UNIT_SQUARE + [UNIT_SQUARE[0]]])

    def test_outside(self):
        assert not _point_in_polygon(2.0, 2.0, [UNIT_SQUARE + [UNIT_SQUARE[0]]])

    def test_on_corner_not_inside(self):
        # Ray-casting corner behaviour is implementation-defined; just check it doesn't crash
        _point_in_polygon(0.0, 0.0, [UNIT_SQUARE + [UNIT_SQUARE[0]]])


# ---------------------------------------------------------------------------
# Unit: _extract_node_coords
# ---------------------------------------------------------------------------

class TestExtractNodeCoords:
    def test_basic(self):
        feats = [_link("L1", "A", "B", [4.0, 52.0], [4.1, 52.1])]
        coords = _extract_node_coords(feats)
        assert coords["A"] == (4.0, 52.0)
        assert coords["B"] == (4.1, 52.1)

    def test_shared_node_not_overwritten(self):
        feats = [
            _link("L1", "A", "B", [4.0, 52.0], [4.1, 52.1]),
            _link("L2", "C", "A", [4.2, 52.2], [4.0, 52.0]),
        ]
        coords = _extract_node_coords(feats)
        # A first seen as fromNode of L1 → should stay [4.0, 52.0]
        assert coords["A"] == (4.0, 52.0)

    def test_skips_non_linestring(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [4.0, 52.0]},
            "properties": {"fromNode": "A", "toNode": "B", "length": 100},
        }
        coords = _extract_node_coords([feat])
        assert coords == {}


# ---------------------------------------------------------------------------
# Unit: _node_link_lengths
# ---------------------------------------------------------------------------

class TestNodeLinkLengths:
    def test_both_endpoints_accumulate(self):
        feats = [_link("L1", "A", "B", [0, 0], [1, 0], length_m=200.0)]
        lengths = _node_link_lengths(feats)
        assert lengths["A"] == 200.0
        assert lengths["B"] == 200.0

    def test_multiple_links(self):
        feats = [
            _link("L1", "A", "B", [0, 0], [1, 0], length_m=100.0),
            _link("L2", "B", "C", [1, 0], [2, 0], length_m=300.0),
        ]
        lengths = _node_link_lengths(feats)
        assert lengths["A"] == 100.0
        assert lengths["B"] == 400.0  # L1 + L2
        assert lengths["C"] == 300.0


# ---------------------------------------------------------------------------
# Unit: _scale_properties
# ---------------------------------------------------------------------------

class TestScaleProperties:
    def test_numeric_scaled(self):
        props = {"production": 100.0, "attraction": 200.0}
        result = _scale_properties(props, 0.4)
        assert result["production"] == pytest.approx(40.0)
        assert result["attraction"] == pytest.approx(80.0)

    def test_string_unchanged(self):
        props = {"name": "Zone A", "zoneId": "z1"}
        result = _scale_properties(props, 0.5)
        assert result["name"] == "Zone A"
        assert result["zoneId"] == "z1"

    def test_zone_id_not_scaled(self):
        props = {"zoneId": "original_id"}
        result = _scale_properties(props, 0.5)
        assert result["zoneId"] == "original_id"

    def test_none_unchanged(self):
        props = {"val": None}
        result = _scale_properties(props, 0.5)
        assert result["val"] is None

    def test_bool_unchanged(self):
        props = {"active": True}
        result = _scale_properties(props, 0.5)
        assert result["active"] is True


# ---------------------------------------------------------------------------
# Integration: split_zones
# ---------------------------------------------------------------------------

class TestSplitZones:
    def _simple_network(self):
        """Two links inside the unit square, sharing node B at centre."""
        return _fc([
            _link("L1", "A", "B", [0.1, 0.1], [0.5, 0.5], length_m=100.0),
            _link("L2", "B", "C", [0.5, 0.5], [0.9, 0.9], length_m=300.0),
        ])

    def _simple_zones(self):
        return _fc([_zone("Z1", UNIT_SQUARE, production=1000.0, name="Zone One")])

    def test_output_count(self):
        new_zones, _, stats = split_zones(self._simple_network(), self._simple_zones())
        # 3 nodes (A, B, C), all inside unit square
        assert len(new_zones["features"]) == 3
        assert stats["outputZones"] == 3
        assert stats["inputZones"] == 1

    def test_zone_id_equals_node_id(self):
        new_zones, _, _ = split_zones(self._simple_network(), self._simple_zones())
        zone_ids = {f["properties"]["zoneId"] for f in new_zones["features"]}
        assert zone_ids == {"A", "B", "C"}

    def test_geometry_is_square_polygon(self):
        new_zones, _, _ = split_zones(self._simple_network(), self._simple_zones())
        for feat in new_zones["features"]:
            assert feat["geometry"]["type"] == "Polygon"
            ring = feat["geometry"]["coordinates"][0]
            assert len(ring) == 5
            assert ring[0] == ring[-1]

    def test_production_sums_to_original(self):
        new_zones, _, _ = split_zones(self._simple_network(), self._simple_zones())
        total = sum(f["properties"]["production"] for f in new_zones["features"])
        assert total == pytest.approx(1000.0)

    def test_non_numeric_inherited(self):
        new_zones, _, _ = split_zones(self._simple_network(), self._simple_zones())
        for feat in new_zones["features"]:
            assert feat["properties"]["name"] == "Zone One"

    def test_node_outside_zone_excluded(self):
        network = _fc([
            _link("L1", "A", "B", [0.1, 0.1], [0.5, 0.5], length_m=100.0),
            _link("L2", "B", "C", [0.5, 0.5], [5.0, 5.0], length_m=100.0),  # C far outside
        ])
        zones = _fc([_zone("Z1", UNIT_SQUARE)])
        new_zones, _, stats = split_zones(network, zones)
        zone_ids = {f["properties"]["zoneId"] for f in new_zones["features"]}
        assert "C" not in zone_ids
        assert stats["unassignedNodes"] >= 1

    def test_proportional_weight_by_link_length(self):
        """Node B has 400 m (L1=100 + L2=300), A has 100 m, C has 300 m."""
        new_zones, _, _ = split_zones(self._simple_network(), self._simple_zones())
        # total weight = 100 + 400 + 300 = 800
        by_node = {f["properties"]["zoneId"]: f["properties"] for f in new_zones["features"]}
        assert by_node["A"]["production"] == pytest.approx(1000.0 * 100 / 800)
        assert by_node["B"]["production"] == pytest.approx(1000.0 * 400 / 800)
        assert by_node["C"]["production"] == pytest.approx(1000.0 * 300 / 800)

    def test_empty_network(self):
        new_zones, feedlinks, stats = split_zones(_fc([]), self._simple_zones())
        assert new_zones["features"] == []
        assert feedlinks["features"] == []
        assert stats["outputZones"] == 0

    def test_empty_zones(self):
        new_zones, feedlinks, stats = split_zones(self._simple_network(), _fc([]))
        assert new_zones["features"] == []
        assert feedlinks["features"] == []
        assert stats["inputZones"] == 0


# ---------------------------------------------------------------------------
# Unit: _node_max_capacities
# ---------------------------------------------------------------------------

class TestNodeMaxCapacities:
    def _link_with_cap(self, from_node, to_node, cap):
        return {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
            "properties": {"fromNode": from_node, "toNode": to_node,
                           "length": 100.0, "capacity": cap},
        }

    def test_max_cap_per_node(self):
        feats = [
            self._link_with_cap("A", "B", 500.0),
            self._link_with_cap("B", "C", 300.0),
        ]
        caps = _node_max_capacities(feats)
        assert caps["A"] == pytest.approx(500.0)
        assert caps["B"] == pytest.approx(500.0)  # max of 500 and 300
        assert caps["C"] == pytest.approx(300.0)


# ---------------------------------------------------------------------------
# Integration: feedlinks from split_zones
# ---------------------------------------------------------------------------

class TestSplitZonesFeedlinks:
    def _simple_network(self):
        return _fc([
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.1, 0.1], [0.5, 0.5]]},
                "properties": {"fromNode": "A", "toNode": "B",
                               "length": 100.0, "capacity": 400.0},
            },
        ])

    def _simple_zones(self):
        return _fc([_zone("Z1", UNIT_SQUARE)])

    def test_feedlinks_count(self):
        _, feedlinks, _ = split_zones(self._simple_network(), self._simple_zones())
        # 2 nodes (A, B), each gets 1 production + 1 attraction feedlink = 4 total
        assert len(feedlinks["features"]) == 4

    def test_feedlinks_have_required_properties(self):
        _, feedlinks, _ = split_zones(self._simple_network(), self._simple_zones())
        for feat in feedlinks["features"]:
            props = feat["properties"]
            assert "zoneId" in props
            assert "fromNode" in props
            assert "toNode" in props
            assert props["length"] == pytest.approx(0.0)
            assert props["capacity"] > 0.0

    def test_production_and_attraction_per_node(self):
        _, feedlinks, _ = split_zones(self._simple_network(), self._simple_zones())
        by_zone: dict[str, list[dict]] = {}
        for feat in feedlinks["features"]:
            z = feat["properties"]["zoneId"]
            by_zone.setdefault(z, []).append(feat["properties"])

        for zone_id, fl_list in by_zone.items():
            # production: fromNode starts with "Z_"
            prods = [f for f in fl_list if f["fromNode"].startswith("Z_")]
            # attraction: toNode starts with "Z_"
            attrs = [f for f in fl_list if f["toNode"].startswith("Z_")]
            assert len(prods) == 1, f"Expected 1 production feedlink for {zone_id}"
            assert len(attrs) == 1, f"Expected 1 attraction feedlink for {zone_id}"
            # virtual node must match zone ID
            assert prods[0]["fromNode"] == f"Z_{zone_id}"
            assert prods[0]["toNode"] == zone_id
            assert attrs[0]["fromNode"] == zone_id
            assert attrs[0]["toNode"] == f"Z_{zone_id}"

    def test_feedlink_capacity_reflects_network(self):
        _, feedlinks, _ = split_zones(self._simple_network(), self._simple_zones())
        # Both A and B are connected to the 400-cap link
        for feat in feedlinks["features"]:
            assert feat["properties"]["capacity"] == pytest.approx(400.0)

    def test_feedlink_geometry_is_linestring(self):
        _, feedlinks, _ = split_zones(self._simple_network(), self._simple_zones())
        for feat in feedlinks["features"]:
            assert feat["geometry"]["type"] == "LineString"
