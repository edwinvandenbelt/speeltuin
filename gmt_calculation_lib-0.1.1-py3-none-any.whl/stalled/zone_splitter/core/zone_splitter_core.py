"""Pure-Python zone_splitter core — no I/O, no boto3, no external deps.

Splits an existing zone GeoJSON into one mini-zone per network node.  Each
node is assigned to the zone whose polygon contains it (point-in-polygon).
The node's weight within a zone equals the sum of the lengths of all network
links connected to that node (both incoming and outgoing).  Numeric zone
properties are distributed proportionally by weight; non-numeric properties
are inherited unchanged.  The geometry of each mini-zone is a 10 m × 10 m
axis-aligned square centred on the node.

For every mini-zone, a matching pair of feedlinks is generated so that the
OD matrix builder can route directly from/to the node without an intermediate
zone centroid:

    production feedlink:  Z_{nodeId}  →  nodeId   (length = 0, capacity = node max capacity)
    attraction feedlink:  nodeId      →  Z_{nodeId}

Public API
----------
split_zones(network_fc, zones_fc) -> tuple[dict, dict, dict]
    Returns (new_zones_fc, new_feedlinks_fc, stats).
    stats: {"inputZones": int, "outputZones": int, "unassignedNodes": int}
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)

# Half-side of the square mini-zone geometry in metres.
_HALF_SIDE_M = 5.0

# Approximate metres per degree latitude (constant).
_M_PER_DEG_LAT = 111_320.0


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------

def _square_polygon(lon: float, lat: float, half_m: float = _HALF_SIDE_M) -> dict:
    """Return a GeoJSON Polygon that is a square of side 2*half_m centred on (lon, lat)."""
    dlat = half_m / _M_PER_DEG_LAT
    dlon = half_m / (_M_PER_DEG_LAT * math.cos(math.radians(lat)))
    ring = [
        [lon - dlon, lat - dlat],
        [lon + dlon, lat - dlat],
        [lon + dlon, lat + dlat],
        [lon - dlon, lat + dlat],
        [lon - dlon, lat - dlat],  # closed
    ]
    return {"type": "Polygon", "coordinates": [ring]}


def _point_in_polygon(lon: float, lat: float, polygon_coords: list) -> bool:
    """Ray-casting point-in-polygon test for a GeoJSON ring (list of [lon, lat])."""
    inside = False
    ring = polygon_coords[0]  # outer ring only
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if ((yi > lat) != (yj > lat)) and (lon < (xj - xi) * (lat - yi) / (yj - yi + 1e-15) + xi):
            inside = not inside
        j = i
    return inside


def _point_in_feature(lon: float, lat: float, feature: dict) -> bool:
    """Test whether (lon, lat) lies inside a GeoJSON Polygon or MultiPolygon feature."""
    geom = feature.get("geometry") or {}
    gtype = geom.get("type", "")
    coords = geom.get("coordinates", [])
    if gtype == "Polygon":
        return _point_in_polygon(lon, lat, coords)
    if gtype == "MultiPolygon":
        return any(_point_in_polygon(lon, lat, poly) for poly in coords)
    return False


# ---------------------------------------------------------------------------
# Network helpers
# ---------------------------------------------------------------------------

def _extract_node_coords(network_features: list[dict]) -> dict[str, tuple[float, float]]:
    """Extract {nodeId: (lon, lat)} from network LineString geometries.

    fromNode  → first coordinate of the LineString
    toNode    → last  coordinate of the LineString
    """
    coords: dict[str, tuple[float, float]] = {}
    for feat in network_features:
        props = feat.get("properties") or {}
        geom = feat.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        line = geom.get("coordinates") or []
        if len(line) < 2:
            continue
        from_node = str(props.get("fromNode", ""))
        to_node = str(props.get("toNode", ""))
        if from_node and from_node not in coords:
            coords[from_node] = (float(line[0][0]), float(line[0][1]))
        if to_node and to_node not in coords:
            coords[to_node] = (float(line[-1][0]), float(line[-1][1]))
    return coords


def _node_link_lengths(network_features: list[dict]) -> dict[str, float]:
    """Return {nodeId: total length (m) of all connected links}."""
    lengths: dict[str, float] = {}
    for feat in network_features:
        props = feat.get("properties") or {}
        length = float(props.get("length") or 0.0)
        for key in ("fromNode", "toNode"):
            node = str(props.get(key, ""))
            if node:
                lengths[node] = lengths.get(node, 0.0) + length
    return lengths


def _node_max_capacities(network_features: list[dict]) -> dict[str, float]:
    """Return {nodeId: maximum capacity (veh/h) of any connected link}."""
    caps: dict[str, float] = {}
    for feat in network_features:
        props = feat.get("properties") or {}
        cap = float(props.get("capacity") or 0.0)
        for key in ("fromNode", "toNode"):
            node = str(props.get(key, ""))
            if node and cap > caps.get(node, 0.0):
                caps[node] = cap
    return caps


# ---------------------------------------------------------------------------
# Zone assignment
# ---------------------------------------------------------------------------

def _assign_nodes_to_zones(
    node_coords: dict[str, tuple[float, float]],
    zone_features: list[dict],
) -> dict[str, int]:
    """Return {nodeId: zone_feature_index} by point-in-polygon lookup."""
    assignment: dict[str, int] = {}
    for node_id, (lon, lat) in node_coords.items():
        for idx, feat in enumerate(zone_features):
            if _point_in_feature(lon, lat, feat):
                assignment[node_id] = idx
                break
    return assignment


# ---------------------------------------------------------------------------
# Property scaling
# ---------------------------------------------------------------------------

def _scale_properties(props: dict, fraction: float) -> dict:
    """Return a copy of *props* with numeric values multiplied by *fraction*.

    Non-numeric values (str, None, bool) are copied unchanged.
    ``zoneId`` is always treated as non-numeric (string identity).
    """
    out: dict = {}
    for key, val in props.items():
        if key == "zoneId":
            out[key] = val
        elif isinstance(val, (int, float)) and not isinstance(val, bool):
            out[key] = val * fraction
        else:
            out[key] = val
    return out


# ---------------------------------------------------------------------------
# Feedlink builder
# ---------------------------------------------------------------------------

_ZONE_PREFIX = "Z_"
_DEFAULT_FEEDLINK_CAPACITY = 9999.0


def _build_split_feedlinks(
    node_coords: dict[str, tuple[float, float]],
    assignment: dict[str, int],
    node_capacities: dict[str, float],
) -> dict:
    """Build a feedlinks FeatureCollection for all assigned mini-zone nodes.

    Each node in *assignment* gets two feedlink features:

    * production: ``Z_{nodeId}`` → ``nodeId``  (zone centroid departing to network)
    * attraction: ``nodeId`` → ``Z_{nodeId}``  (network arriving at zone centroid)

    Both feedlinks have ``length = 0.0`` and ``capacity`` equal to the maximum
    capacity of all links connected to *nodeId*.  The geometry is a degenerate
    LineString of length 0 positioned at the node coordinate.
    """
    features: list[dict] = []
    for node_id in assignment:
        lon, lat = node_coords[node_id]
        capacity = node_capacities.get(node_id, _DEFAULT_FEEDLINK_CAPACITY)
        vnode = f"{_ZONE_PREFIX}{node_id}"
        coord = [lon, lat]
        base_props = {
            "zoneId":   node_id,
            "length":   0.0,
            "capacity": capacity,
        }
        # Production feedlink: virtual zone node → real network node
        features.append({
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [coord, coord]},
            "properties": {**base_props, "fromNode": vnode, "toNode": node_id},
        })
        # Attraction feedlink: real network node → virtual zone node
        features.append({
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [coord, coord]},
            "properties": {**base_props, "fromNode": node_id, "toNode": vnode},
        })
    return {"type": "FeatureCollection", "features": features}


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def split_zones(
    network_fc: dict,
    zones_fc: dict,
) -> tuple[dict, dict, dict]:
    """Split zone GeoJSON into one mini-zone per network node.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection.  Each feature must be a LineString
        with ``fromNode``, ``toNode``, and ``length`` properties.
    zones_fc:
        Zone GeoJSON FeatureCollection.  Features must be Polygon or
        MultiPolygon geometries.

    Returns
    -------
    new_zones_fc:
        New GeoJSON FeatureCollection — one feature per network node that
        falls inside a zone.  Each feature has a 10 m × 10 m square geometry
        and scaled numeric properties from the parent zone.  ``zoneId`` is
        set to the node ID.
    new_feedlinks_fc:
        New GeoJSON FeatureCollection — two feedlink features per assigned
        node (one production, one attraction).  The production feedlink goes
        from the virtual zone centroid node (``Z_{nodeId}``) to the real
        network node; the attraction feedlink goes the other way.  Both have
        ``length = 0.0`` and ``capacity`` equal to the maximum capacity of any
        link connected to the node.
    stats:
        ``inputZones``, ``outputZones``, ``unassignedNodes``.
    """
    network_features: list[dict] = network_fc.get("features") or []
    zone_features: list[dict] = zones_fc.get("features") or []

    logger.info(
        "split_zones: %d network links, %d zones",
        len(network_features), len(zone_features),
    )

    node_coords = _extract_node_coords(network_features)
    node_weights = _node_link_lengths(network_features)
    node_capacities = _node_max_capacities(network_features)
    assignment = _assign_nodes_to_zones(node_coords, zone_features)

    logger.info(
        "Nodes: %d total, %d assigned to zones, %d unassigned",
        len(node_coords),
        len(assignment),
        len(node_coords) - len(assignment),
    )

    # Compute total weight per zone
    zone_total_weight: dict[int, float] = {}
    for node_id, zone_idx in assignment.items():
        w = node_weights.get(node_id, 0.0)
        zone_total_weight[zone_idx] = zone_total_weight.get(zone_idx, 0.0) + w

    # Build output zone features
    output_features: list[dict] = []
    for node_id, zone_idx in assignment.items():
        lon, lat = node_coords[node_id]
        parent_props = dict((zone_features[zone_idx].get("properties") or {}))
        total_w = zone_total_weight.get(zone_idx, 0.0)
        node_w = node_weights.get(node_id, 0.0)
        fraction = (node_w / total_w) if total_w > 0.0 else 0.0

        props = _scale_properties(parent_props, fraction)
        props["zoneId"] = node_id  # override: mini-zone ID = node ID

        output_features.append({
            "type": "Feature",
            "geometry": _square_polygon(lon, lat),
            "properties": props,
        })

    new_zones_fc: dict = {
        "type": "FeatureCollection",
        "features": output_features,
        "properties": zones_fc.get("properties"),
    }
    new_feedlinks_fc = _build_split_feedlinks(node_coords, assignment, node_capacities)
    stats: dict = {
        "inputZones": len(zone_features),
        "outputZones": len(output_features),
        "unassignedNodes": len(node_coords) - len(assignment),
    }
    logger.info("split_zones complete: %s", stats)
    return new_zones_fc, new_feedlinks_fc, stats
