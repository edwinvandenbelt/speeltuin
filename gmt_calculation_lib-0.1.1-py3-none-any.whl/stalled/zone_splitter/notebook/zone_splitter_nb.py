# Databricks notebook source
# ---------------------------------------------------------------------------
# zone_splitter_nb.py — Databricks notebook interface for zone_splitter.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads network + zones GeoJSON from S3 (or local path).
#   3. Calls split_zones — no Spark I/O.
#   4. Writes the new zones GeoJSON back to S3 (overwrites input).
#   5. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("zone_splitter_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text("network_uri", "", "Full URI of the network GeoJSON (s3:// or local path)")  # noqa: F821
dbutils.widgets.text("zones_uri",   "", "Full URI of the zones GeoJSON (read + overwrite in place)")  # noqa: F821
dbutils.widgets.text("LOG_LEVEL",   "INFO", "Log level (DEBUG / INFO / WARNING / ERROR)")  # noqa: F821

# COMMAND ----------
_ll = getattr(logging, dbutils.widgets.get("LOG_LEVEL").strip().upper(), logging.INFO)  # noqa: F821
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
import sys  # noqa: E402
sys.path.insert(0, "/Workspace/Repos/gmt-calculation-lib/src")
from zone_splitter.core.zone_splitter_core import split_zones  # noqa: E402

# COMMAND ----------
NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
ZONES_URI   = dbutils.widgets.get("zones_uri").strip()    # noqa: F821

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")
if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty.")

logger.info("network_uri=%s  zones_uri=%s", NETWORK_URI, ZONES_URI)

# COMMAND ----------
import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    import os  # noqa: PLC0415
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run ZoneSplitter
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell**.

# COMMAND ----------
_t_start = datetime.now(timezone.utc)

print(f"Starting  {_t_start.isoformat()}")
print(f"Network   : {NETWORK_URI}")
print(f"Zones     : {ZONES_URI}")
print()

_network_fc = json.loads(_read_uri(NETWORK_URI))
_zones_fc   = json.loads(_read_uri(ZONES_URI))

_new_zones_fc, _stats = split_zones(_network_fc, _zones_fc)

_payload = json.dumps(_new_zones_fc, ensure_ascii=False).encode("utf-8")
_write_uri(ZONES_URI, _payload)

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
_SEP = "─" * 60
print(_SEP)
print(f"ZoneSplitter complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Network URI  : {NETWORK_URI}")
print(f"  Zones URI    : {ZONES_URI}")
print(f"  Input zones  : {_stats['inputZones']}")
print(f"  Output zones : {_stats['outputZones']}  (mini-zones, one per node)")
print(f"  Unassigned   : {_stats['unassignedNodes']}  nodes outside all zones")
print(_SEP)
