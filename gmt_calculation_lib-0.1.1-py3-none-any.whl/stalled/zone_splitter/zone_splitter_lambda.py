"""ZoneSplitter Lambda handler — thin I/O wrapper around zone_splitter_core.

Reads a network GeoJSON and a zones GeoJSON from S3 (or local paths),
splits zones into one mini-zone per network node, and overwrites the zones
file in place.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "networkUri": "s3://bucket/key or local path",  // required
        "zonesUri":   "s3://bucket/key or local path"   // required
    }
}

Response (200 / direct invocation)
------------------------------------
{
    "statusCode":      200,
    "status":          "successful",
    "zonesUri":        "...",
    "inputZones":      int,
    "outputZones":     int,
    "unassignedNodes": int
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    # ------------------------------------------------------------------
    # Direct invocation
    # ------------------------------------------------------------------
    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from zone_splitter.core.zone_splitter_core import split_zones  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        network_uri: str = inputs.get("networkUri", "")
        zones_uri: str = inputs.get("zonesUri", "")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not zones_uri:
            raise ValueError("inputs.zonesUri is required.")

        logger.info("Reading network: %s", network_uri)
        network_fc = json.loads(_read_uri(network_uri))

        logger.info("Reading zones  : %s", zones_uri)
        zones_fc = json.loads(_read_uri(zones_uri))

        new_zones_fc, stats = split_zones(network_fc, zones_fc)

        logger.info("Writing zones  : %s", zones_uri)
        _write_uri(zones_uri, json.dumps(new_zones_fc, ensure_ascii=False).encode("utf-8"))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "zonesUri": zones_uri,
            **stats,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id,
            exc,
            traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
