"""scale — GMT flow-scaling pipeline orchestrator."""
