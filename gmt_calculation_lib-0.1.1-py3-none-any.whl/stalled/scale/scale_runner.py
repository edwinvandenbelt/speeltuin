"""
scale_runner.py — CLI entry point for the GMT flow-scaling pipeline.

Usage
-----
    python -m scale.scale_runner <FOLDER> [--mode MODE] [--date ISO8601]
        [--temperature high|medium|low] [--weather sunny|cloudy|dry|rainy]
        [--purpose work|education|shopping|recreational|unknown|all]
        [--output-folder DIR] [--refresh]
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

_RUNNER_FILE = Path(__file__).resolve()
_REPO_ROOT   = _RUNNER_FILE.parent.parent.parent  # src/scale/ -> repo root
_SRC_DIR     = str(_REPO_ROOT / "src")
if _SRC_DIR not in sys.path:
    sys.path.insert(0, _SRC_DIR)

from scale.core.scale_core import INDICES_DIR, REPO_ROOT, _read_env_file, run_scale  # noqa: E402


def _resolve_folder(raw: str) -> Path:
    p = Path(raw)
    if p.is_absolute():
        return p
    return REPO_ROOT / raw


def main() -> None:
    parser = argparse.ArgumentParser(
        description="GMT flow-scaling pipeline — applies time-of-day indices and strips to linkId + flow."
    )
    parser.add_argument("folder", help="Prepared area folder (output of prepare).")
    parser.add_argument(
        "--mode", default=None,
        help="Transport mode (e.g. CAR, BIKE).  Auto-detected when omitted.",
    )
    parser.add_argument(
        "--date", default=None,
        help="ISO-8601 datetime for the scaling scenario, e.g. 2025-06-21T09:00:00Z.",
    )
    parser.add_argument(
        "--temperature", default="medium", choices=["high", "medium", "low"],
        help="Temperature level (default: medium).",
    )
    parser.add_argument(
        "--weather", default="cloudy", choices=["sunny", "cloudy", "dry", "rainy"],
        help="Weather condition (default: cloudy).",
    )
    parser.add_argument(
        "--purpose", default="all",
        choices=["work", "education", "shopping", "recreational", "unknown", "all"],
        help="Trip purpose filter (default: all).",
    )
    parser.add_argument(
        "--output-folder", default=None, metavar="DIR",
        help="Output directory (defaults to FOLDER).",
    )
    parser.add_argument(
        "--purpose-index", default=None, metavar="PATH",
        help=f"Path to purpose_index.json.  Default: {INDICES_DIR / 'purpose_index.json'}",
    )
    parser.add_argument(
        "--daylight-index", default=None, metavar="PATH",
        help=f"Path to daylight.json.  Default: {INDICES_DIR / 'daylight.json'}",
    )
    parser.add_argument(
        "--holiday-index", default=None, metavar="PATH",
        help=f"Path to holiday_indices.csv.  Default: {INDICES_DIR / 'holiday_indices.csv'}",
    )
    parser.add_argument(
        "--refresh", action="store_true",
        help="Rebuild the output even if it already exists.",
    )
    parser.add_argument(
        "--env-file", default=None,
        help="Path to .env file for credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(_SRC_DIR).parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    folder = _resolve_folder(args.folder)
    if not folder.is_dir():
        parser.error(f"FOLDER does not exist or is not a directory: {folder}")

    output_folder = (
        _resolve_folder(args.output_folder) if args.output_folder else folder
    )

    run_scale(
        folder=folder,
        mode=args.mode,
        date=args.date,
        temperature=args.temperature,
        weather=args.weather,
        purpose=args.purpose,
        output_folder=output_folder,
        purpose_index_uri=args.purpose_index or str(INDICES_DIR / "purpose_index.json"),
        daylight_index_uri=args.daylight_index or str(INDICES_DIR / "daylight.json"),
        holiday_index_uri=args.holiday_index  or str(INDICES_DIR / "holiday_indices.csv"),
        refresh=args.refresh,
    )


if __name__ == "__main__":
    main()
