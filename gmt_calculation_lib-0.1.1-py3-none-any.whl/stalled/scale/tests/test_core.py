"""Unit tests for scale.core.scale_core — pure helper functions only."""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from scale.core.scale_core import (
    _detect_mode,
    _discover_area_id,
    _read_env_file,
)


# ---------------------------------------------------------------------------
# _discover_area_id
# ---------------------------------------------------------------------------


class TestDiscoverAreaId:
    def test_discovers_from_clean_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "my-uuid-5678-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _discover_area_id(folder) == "my-uuid-5678"

    def test_raises_when_no_network_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _discover_area_id(Path(tmp))

    def test_prefers_clean_over_raw(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "abc-123-NETWORK-RAW-CAR.geojson").write_text("{}", encoding="utf-8")
            (folder / "abc-123-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _discover_area_id(folder) == "abc-123"

    def test_falls_back_to_raw_when_no_clean(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "abc-123-NETWORK-RAW-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _discover_area_id(folder) == "abc-123"


# ---------------------------------------------------------------------------
# _detect_mode
# ---------------------------------------------------------------------------


class TestDetectMode:
    def test_detects_car(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            aid    = "some-id"
            (folder / f"{aid}-NETWORK-CAR.geojson").write_text("{}", encoding="utf-8")
            assert _detect_mode(folder, aid) == "CAR"

    def test_ignores_compound_suffixes(self):
        """NETWORK-RAW-CAR should not be matched."""
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            aid    = "some-id"
            (folder / f"{aid}-NETWORK-RAW-CAR.geojson").write_text("{}", encoding="utf-8")
            (folder / f"{aid}-NETWORK-BIKE.geojson").write_text("{}", encoding="utf-8")
            assert _detect_mode(folder, aid) == "BIKE"

    def test_raises_when_nothing_found(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _detect_mode(Path(tmp), "no-such-id")


# ---------------------------------------------------------------------------
# _read_env_file
# ---------------------------------------------------------------------------


class TestReadEnvFile:
    def _write(self, tmp: str, content: str) -> Path:
        path = Path(tmp) / ".env"
        path.write_text(content, encoding="utf-8")
        return path

    def test_parses_simple_key_value(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self._write(tmp, "FOO=bar\nBAZ=qux\n")
            result = _read_env_file(path)
            assert result == {"FOO": "bar", "BAZ": "qux"}

    def test_strips_quoted_values(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self._write(tmp, 'KEY="hello world"\n')
            assert _read_env_file(path)["KEY"] == "hello world"

    def test_ignores_comments_and_blanks(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = self._write(tmp, "# comment\n\nFOO=1\n")
            assert _read_env_file(path) == {"FOO": "1"}

    def test_returns_empty_when_file_missing(self):
        result = _read_env_file(Path("/nonexistent/.env"))
        assert result == {}
