# Databricks notebook source
# ---------------------------------------------------------------------------
# scale_nb.py — Databricks notebook interface for the GMT flow-scaling pipeline.
#
# This notebook:
#   1. Reads widget parameters (folder, mode, date, temperature, weather, purpose, …).
#   2. Installs gmt-calculation-lib from Nexus (if not already present).
#   3. Calls scale.core.scale_core.run_scale directly.
#
# Requirements (Databricks cluster):
#   pip install gmt-calculation-lib
# ---------------------------------------------------------------------------

# COMMAND ----------
# MAGIC %pip install --quiet gmt-calculation-lib

# COMMAND ----------
import logging
from pathlib import Path

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("scale_nb")

# COMMAND ----------
dbutils.widgets.text("folder",           "/tmp/gmt_area",  "Source folder")           # noqa: F821
dbutils.widgets.text("mode",             "",               "Mode (empty = auto-detect)") # noqa: F821
dbutils.widgets.text("date",             "",               "Date ISO-8601 (empty = default)") # noqa: F821
dbutils.widgets.dropdown("temperature",  "medium", ["high", "medium", "low"], "Temperature") # noqa: F821
dbutils.widgets.dropdown("weather",      "cloudy", ["sunny", "cloudy", "dry", "rainy"], "Weather") # noqa: F821
dbutils.widgets.dropdown("purpose",      "all",
    ["work", "education", "shopping", "recreational", "unknown", "all"], "Purpose")  # noqa: F821
dbutils.widgets.text("output_folder",    "",               "Output folder (empty = source folder)") # noqa: F821
dbutils.widgets.text("purpose_index",    "",               "purpose_index.json path (empty = default)") # noqa: F821
dbutils.widgets.text("daylight_index",   "",               "daylight.json path (empty = default)") # noqa: F821
dbutils.widgets.text("holiday_index",    "",               "holiday_indices.csv path (empty = default)") # noqa: F821
dbutils.widgets.dropdown("refresh",      "false", ["true", "false"], "Refresh")  # noqa: F821

# COMMAND ----------
from scale.core.scale_core import INDICES_DIR, run_scale  # noqa: E402

folder      = Path(dbutils.widgets.get("folder").strip())              # noqa: F821
_mode       = dbutils.widgets.get("mode").strip().upper() or None      # noqa: F821
_date       = dbutils.widgets.get("date").strip() or None              # noqa: F821
temperature = dbutils.widgets.get("temperature")                       # noqa: F821
weather     = dbutils.widgets.get("weather")                           # noqa: F821
purpose     = dbutils.widgets.get("purpose")                           # noqa: F821
_out        = dbutils.widgets.get("output_folder").strip()             # noqa: F821
_pi         = dbutils.widgets.get("purpose_index").strip()             # noqa: F821
_di         = dbutils.widgets.get("daylight_index").strip()            # noqa: F821
_hi         = dbutils.widgets.get("holiday_index").strip()             # noqa: F821
refresh     = dbutils.widgets.get("refresh") == "true"                 # noqa: F821

output_folder      = Path(_out) if _out else folder
purpose_index_uri  = _pi or str(INDICES_DIR / "purpose_index.json")
daylight_index_uri = _di or str(INDICES_DIR / "daylight.json")
holiday_index_uri  = _hi or str(INDICES_DIR / "holiday_indices.csv")

logger.info("Scale pipeline: folder=%s mode=%s date=%s", folder, _mode, _date)

# COMMAND ----------
run_scale(
    folder=folder,
    mode=_mode,
    date=_date,
    temperature=temperature,
    weather=weather,
    purpose=purpose,
    output_folder=output_folder,
    purpose_index_uri=purpose_index_uri,
    daylight_index_uri=daylight_index_uri,
    holiday_index_uri=holiday_index_uri,
    refresh=refresh,
)
