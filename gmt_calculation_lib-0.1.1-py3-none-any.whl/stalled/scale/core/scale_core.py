"""
scale_core.py — GMT flow-scaling pipeline orchestration logic.

Import and call ``run_scale`` from a local runner, notebook, or Lambda handler.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Repo-root paths
# ---------------------------------------------------------------------------

_CORE_FILE  = Path(__file__).resolve()
REPO_ROOT   = _CORE_FILE.parent.parent.parent   # src/scale/ -> src/ -> repo root
INDICES_DIR = REPO_ROOT / "artifacts" / "indices"


# ---------------------------------------------------------------------------
# .env loader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    """Parse a simple ``KEY=VALUE`` .env file into a dict."""
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# Path helpers
# ---------------------------------------------------------------------------


def _discover_area_id(folder: Path) -> str:
    """Discover the area UUID from ``{uuid}-NETWORK-{MODE}.geojson`` in *folder*.

    Only "clean" network files are considered — derived variants such as
    ``{uuid}-NETWORK-RAW-CAR.geojson`` are excluded by the hyphen-in-mode check.
    Falls back to any ``*-NETWORK-*.geojson`` when no clean file exists.
    """
    matches = [
        p for p in sorted(folder.glob("*-NETWORK-*.geojson"))
        if "-" not in p.stem.split("-NETWORK-", 1)[1]
    ]
    if not matches:
        matches = sorted(folder.glob("*-NETWORK-*.geojson"))
    if not matches:
        raise FileNotFoundError(
            f"No *-NETWORK-*.geojson file found in {folder}\n"
            "Check that FOLDER is correct and preparation.py has been run at least once."
        )
    return matches[0].stem.split("-NETWORK-", 1)[0]


def _detect_mode(folder: Path, area_id: str) -> str:
    """Infer transport mode from ``{area_id}-NETWORK-{MODE}.geojson`` in *folder*."""
    prefix  = f"{area_id}-NETWORK-"
    matches = [
        p for p in folder.glob(f"{prefix}*.geojson")
        if "-" not in p.stem[len(prefix):]
    ]
    if not matches:
        raise FileNotFoundError(
            f"No file matching {prefix}*.geojson found in {folder}.\n"
            "Check that FOLDER is correct or supply --mode explicitly."
        )
    return matches[0].stem[len(prefix):]


# ---------------------------------------------------------------------------
# I/O helpers
# ---------------------------------------------------------------------------


def _read_file(path: Path) -> bytes:
    with open(path, "rb") as fh:
        return fh.read()


def _write_file(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"  Written {len(data):,} bytes  →  {path}")


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------


def run_scale(
    folder: Path,
    mode: str | None,
    *,
    date: str | None,
    temperature: str,
    weather: str,
    purpose: str,
    output_folder: Path,
    purpose_index_uri: str,
    daylight_index_uri: str,
    holiday_index_uri: str,
    refresh: bool,
) -> None:
    """Run the GMT flow-scaling pipeline (flow_scaler → janitor).

    Parameters
    ----------
    folder:
        Directory containing the prepared source files produced by ``prepare``.
    mode:
        Transport mode (e.g. ``"CAR"``).  Auto-detected when ``None``.
    date:
        ISO-8601 datetime string for the scaling scenario.  ``None`` uses the
        mode-default indices.
    temperature:
        ``"high"`` / ``"medium"`` / ``"low"``.
    weather:
        ``"sunny"`` / ``"cloudy"`` / ``"dry"`` / ``"rainy"``.
    purpose:
        Trip purpose filter: ``"work"``, ``"education"``, ``"shopping"``,
        ``"recreational"``, ``"unknown"``, or ``"all"``.
    output_folder:
        Destination directory for the scaled GeoJSON.
    purpose_index_uri:
        Path to ``purpose_index.json``.
    daylight_index_uri:
        Path to ``daylight.json``.
    holiday_index_uri:
        Path to ``holiday_indices.csv``.
    refresh:
        Re-run even if the output file already exists.
    """
    from flow_scaler.core.flow_scaler_core import (  # noqa: PLC0415
        Params,
        applyIndices,
        determineIndiceKeys,
        filterNetwork,
        load_purpose_index,
        normalise_temperature,
        normalise_weather,
        parse_date,
        read_indexes,
    )
    from janitor.core.janitor_core import clean_geojson  # noqa: PLC0415

    area_id = _discover_area_id(folder)
    mode    = (mode or _detect_mode(folder, area_id)).upper()

    network_file = folder / f"{area_id}-NETWORK-{mode}.geojson"
    if not network_file.exists():
        raise FileNotFoundError(f"Network file not found: {network_file}")

    output_folder.mkdir(parents=True, exist_ok=True)
    out_file = output_folder / f"{area_id}-SCALED-FLOW-{mode}.geojson"

    print()
    print("============================================================")
    print(" GMT Scale pipeline")
    print(f" folder      : {folder}")
    print(f" area-id     : {area_id}")
    print(f" mode        : {mode}")
    print(f" date        : {date or '(none — uses mode default)'}")
    print(f" temperature : {temperature}")
    print(f" weather     : {weather}")
    print(f" purpose     : {purpose}")
    print(f" output      : {out_file}")
    print("============================================================")

    if out_file.exists() and not refresh:
        print(f"\n[skip] Output already exists ({out_file.name}).  Pass --refresh to rebuild.")
        return

    # Step 1 — flow_scaler
    print("\n[1/2] flow_scaler")
    print(f"  Reading network      : {network_file}")

    network_raw = json.loads(_read_file(network_file))
    network = (
        network_raw
        if isinstance(network_raw, dict) and network_raw.get("type") == "FeatureCollection"
        else {"type": "FeatureCollection", "features": network_raw}
    )

    print(f"  Reading purpose index: {purpose_index_uri}")
    purpose_index_raw = json.loads(Path(purpose_index_uri).read_bytes())

    print(f"  Reading daylight     : {daylight_index_uri}")
    daylight_raw = json.loads(Path(daylight_index_uri).read_bytes())

    dt           = parse_date(date)
    temp_norm    = normalise_temperature(temperature)
    weather_norm = normalise_weather(weather, dt, daylight_raw)
    purpose_val  = None if purpose.lower() == "all" else purpose.lower()

    purpose_index = load_purpose_index(purpose_index_raw)
    params = Params(
        mode=mode,
        dt=dt,
        temperature=temp_norm,
        weather=weather_norm,
        regio=(network.get("properties") or {}).get("region") or "",
        purpose=purpose_val,
        holiday_index=holiday_index_uri,
    )

    filtered        = filterNetwork(network, None, 0, len(network.get("features", [])) + 1)
    filtered.params = params
    keys            = determineIndiceKeys(params, filtered.metadata)
    indexes         = read_indexes(keys, purpose_index)

    scaled_fc = applyIndices(filtered, indexes, run_cleaner=False)
    print(f"  Scaled features      : {len(scaled_fc.get('features', []))}")

    # Step 2 — janitor
    print("\n[2/2] janitor")

    schema     = {"linkId": None, "flow": None}
    cleaned_fc, stats = clean_geojson(scaled_fc, schema)

    cleaned_fc["properties"] = {
        "areaId":          area_id,
        "mode":            mode,
        "date":            date,
        "temperature":     temp_norm,
        "weather":         weather_norm,
        "purpose":         purpose,
        "link_properties": ["linkId", "flow"],
    }

    print(f"  Total features       : {stats['total']}")
    print(f"  Cleaned features     : {stats['cleaned']}")
    print(f"  Fields kept          : {stats['schema_fields']}  (linkId, flow)")

    print("\nWriting output")
    _write_file(out_file, json.dumps(cleaned_fc, ensure_ascii=False).encode("utf-8"))

    print()
    print("============================================================")
    print(" Scale pipeline complete.")
    print(f" Output : {out_file}")
    print("============================================================")
