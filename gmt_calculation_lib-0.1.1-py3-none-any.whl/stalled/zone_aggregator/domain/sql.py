"""SQL construction and constants for the zone-aggregator — no I/O, no boto3."""

from __future__ import annotations

import json

# Distance rings: (d_min_m, d_max_m, n_sectors, label)
_RINGS: list[tuple[float, float, int, str]] = [
    (0,        10_000,  32, "0-10km"),
    (10_000,   25_000,  16, "10-25km"),
    (25_000,   50_000,  12, "25-50km"),
    (50_000,  100_000,   8, "50-100km"),
    (100_000, float("inf"), 8, "100+km"),
]

# 16-point Dutch compass rose, clockwise from North.
_COMPASS_16: list[str] = [
    "N", "NNO", "NO", "ONO", "O", "OZO", "ZO", "ZZO",
    "Z", "ZZW", "ZW", "WZW", "W", "WNW", "NW", "NNW",
]

# Columns aggregated by population-weighted average (weight = inwoners).
_WEIGHTED_AVG_COLS: tuple[str, ...] = (
    "percentage_huishoudens_in_40_procent_laagste_inkomens",
    "percentage_huishoudens_in_20_procent_hoogste_inkomens",
    "stedelijkheidsgraad",
)

# All numeric (DOUBLE) columns that are summed during aggregation.
_ADDITIVE_COLS: tuple[str, ...] = (
    "inwoners",
    "inwoners_mannen",
    "inwoners_vrouwen",
    "inwoners_leeftijd_00_17_jaar",
    "inwoners_leeftijd_18_29_jaar",
    "inwoners_leeftijd_30_44_jaar",
    "inwoners_leeftijd_45_64_jaar",
    "inwoners_leeftijd_65_plus_jaar",
    "inwoners_leeftijd_00_14_jaar",
    "inwoners_leeftijd_15_24_jaar",
    "inwoners_leeftijd_25_44_jaar",
    "inwoners_migratieachtergrond_europees",
    "inwoners_migratieachtergrond_niet_europees",
    "inwoners_zonder_migratieachtergrond",
    "inwoners_migratieachtergrond_westers",
    "inwoners_migratieachtergrond_niet_westers",
    "inwoners_leerlingen_middelbaaronderwijs",
    "inwoners_leerlingen_middelbaarberoepsonderwijs",
    "inwoners_leerlingen_hogeronderwijs",
    "inwoners_met_rijbewijs",
    "inwoners_zonder_rijbewijs",
    "inwoners_arbeidssituatie_student",
    "inwoners_arbeidssituatie_werkend",
    "inwoners_arbeidssituatie_anders",
    "huishoudens",
    "huishoudens_1_persoons",
    "huishoudens_2_persoons",
    "huishoudens_3_persoons",
    "huishoudens_4_persoons",
    "huishoudens_5_persoons",
    "huishoudens_6_plus_persoons",
    "huishoudens_meerpersoons_zonder_kinderen",
    "huishoudens_meerpersoons_met_kinderen",
    "huishoudens_0_autos",
    "huishoudens_1_autos",
    "huishoudens_2_autos",
    "huishoudens_3_plus_autos",
    "autos",
    "arbeidsplaatsen",
    "arbeidsplaatsen_woonfunctie",
    "arbeidsplaatsen_standplaats",
    "arbeidsplaatsen_ligplaats",
    "arbeidsplaatsen_celfunctie",
    "arbeidsplaatsen_onderwijsfunctie",
    "arbeidsplaatsen_industriefunctie",
    "arbeidsplaatsen_kantoorfunctie",
    "arbeidsplaatsen_overige_winkelfunctie",
    "arbeidsplaatsen_overige_voedselwinkelfunctie",
    "arbeidsplaatsen_supermarkt_voedselwinkelfunctie",
    "arbeidsplaatsen_gezondheidszorgfunctie",
    "arbeidsplaatsen_sportfunctie",
    "arbeidsplaatsen_bijeenkomstfunctie",
    "arbeidsplaatsen_logiesfunctie",
    "arbeidsplaatsen_boerderijfunctie",
    "arbeidsplaatsen_terminalfunctie",
    "arbeidsplaatsen_distributiecentrumfunctie",
    "arbeidsplaatsen_overige_gebruiksfunctie",
    "arbeidsplaatsen_gecombineerde_functies",
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)

# Output schema — property keys present on every feature in the output FeatureCollection.
ZONE_PROPERTIES: tuple[str, ...] = (
    "gid",
    "zoneId",
    "zoneName",
    "municipalityCode",
    "municipalityName",
    "ringIndex",
    "ringLabel",
    "sectorIndex",
    "zoneType",
    "constituentZoneIds",
    "directionLabel",
    "centroidLon",
    "centroidLat",
    *_ADDITIVE_COLS,
    *_WEIGHTED_AVG_COLS,
)

# SQL builder internals
_ADDITIVE_INNER  = ",\n        ".join(_ADDITIVE_COLS)
_ADDITIVE_OUTER  = ",\n        ".join(f"SUM({c}) AS {c}" for c in _ADDITIVE_COLS)

_WAVG_INNER = ",\n        ".join(_WEIGHTED_AVG_COLS)
_WAVG_OUTER = ",\n        ".join(
    f"SUM({c} * COALESCE(inwoners, 0.0)) / NULLIF(SUM(COALESCE(inwoners, 0.0)), 0.0) AS {c}"
    for c in _WEIGHTED_AVG_COLS
)

_SEC_EXPR = (
    "CASE ring_index\n"
    "            WHEN 0 THEN -1\n"
    "            WHEN 1 THEN CAST(FLOOR(bearing_deg / 22.5) AS INT) % 16\n"
    "            WHEN 2 THEN CAST(FLOOR(bearing_deg / 30.0) AS INT) % 12\n"
    "            WHEN 3 THEN CAST(FLOOR(bearing_deg / 45.0) AS INT) % 8\n"
    "            ELSE        CAST(FLOOR(bearing_deg / 45.0) AS INT) % 8\n"
    "        END"
)
_KEY_EXPR = (
    "CASE ring_index\n"
    "            WHEN 0 THEN CONCAT('r0_', COALESCE(municipality_name, 'unknown'))\n"
    "            WHEN 1 THEN CONCAT('r1_s', CAST(CAST(FLOOR(bearing_deg/22.5) AS INT)%16 AS STRING))\n"
    "            WHEN 2 THEN CONCAT('r2_s', CAST(CAST(FLOOR(bearing_deg/30.0) AS INT)%12 AS STRING))\n"
    "            WHEN 3 THEN CONCAT('r3_s', CAST(CAST(FLOOR(bearing_deg/45.0) AS INT)%8  AS STRING))\n"
    "            ELSE        CONCAT('r4_s', CAST(CAST(FLOOR(bearing_deg/45.0) AS INT)%8  AS STRING))\n"
    "        END"
)

_ZONE_SQL_TEMPLATE = """\
WITH
bbox_poly AS (
    SELECT ST_GeomFromGeoJSON(?) AS poly
),
bbox_centre AS (
    SELECT
        ST_X(ST_Centroid(poly)) AS cx,
        ST_Y(ST_Centroid(poly)) AS cy
    FROM bbox_poly
),
zones_geom AS (
    SELECT
        z.gid,
        z.zone_id,
        z.zone_naam                                                          AS zone_name,
        z.gemeente_code                                                      AS municipality_code,
        z.gemeente_naam                                                      AS municipality_name,
        {additive_inner},
        {wavg_inner},
        ST_GeomFromEWKB(z.zone_geometrie)                                   AS geom_rd,
        ST_X(ST_Transform(ST_GeomFromEWKB(z.centroid_geometrie), 4326))     AS clon,
        ST_Y(ST_Transform(ST_GeomFromEWKB(z.centroid_geometrie), 4326))     AS clat,
        CASE
            WHEN ST_Intersects(
                     ST_GeomFromEWKB(z.zone_geometrie),
                     ST_Transform(bp.poly, 28992)
                 )
            THEN 1 ELSE 0
        END AS is_inner
    FROM {{catalog}}.`{{schema}}`.d030_zones_met_centroids z
    CROSS JOIN bbox_poly bp
    WHERE z.zone_geometrie IS NOT NULL
),
zones_dist AS (
    SELECT
        zg.*,
        (zg.clat - bc.cy) * 111320.0                                        AS dlat_m,
        (zg.clon - bc.cx) * 111320.0 * COS(RADIANS((zg.clat + bc.cy) / 2.0)) AS dlon_m
    FROM zones_geom zg
    CROSS JOIN bbox_centre bc
),
zones_bearing AS (
    SELECT
        zd.*,
        SQRT(zd.dlat_m * zd.dlat_m + zd.dlon_m * zd.dlon_m)               AS dist_m,
        ((DEGREES(ATAN2(zd.dlon_m, zd.dlat_m)) % 360.0) + 360.0) % 360.0  AS bearing_deg
    FROM zones_dist zd
),
zones_ringed AS (
    SELECT
        zb.*,
        CASE
            WHEN zb.dist_m <  10000 THEN 0
            WHEN zb.dist_m <  25000 THEN 1
            WHEN zb.dist_m <  50000 THEN 2
            WHEN zb.dist_m < 100000 THEN 3
            ELSE 4
        END AS ring_index
    FROM zones_bearing zb
),
zones_keyed AS (
    SELECT
        zr.*,
        {sec_expr}   AS sector_index,
        {key_expr}   AS agg_key
    FROM zones_ringed zr
)

-- ── Inner zones: one row per individual zone ─────────────────────────────────
SELECT
    gid,
    zone_id                                     AS zoneId,
    zone_name                                   AS zoneName,
    municipality_code                           AS municipalityCode,
    municipality_name                           AS municipalityName,
    {additive_inner},
    {wavg_inner},
    ST_AsGeoJSON(ST_Transform(geom_rd, 4326))  AS geom_json,
    clon                                        AS centroidLon,
    clat                                        AS centroidLat,
    is_inner,
    CAST(-1 AS INT)                             AS ringIndex,
    CAST(-1 AS INT)                             AS sectorIndex,
    CAST(NULL AS STRING)                        AS agg_key,
    CAST(NULL AS ARRAY<BIGINT>)                 AS constituentZoneIds
FROM zones_keyed
WHERE is_inner = 1

UNION ALL

-- ── Outer zones: one row per ring-sector (or ring-0 gemeente) bucket ─────────
SELECT
    MIN(gid)                                                                        AS gid,
    MIN(agg_key)                                                                    AS zoneId,
    CAST(NULL AS STRING)                                                            AS zoneName,
    CASE WHEN ring_index = 0 THEN MIN(municipality_code) ELSE NULL END             AS municipalityCode,
    CASE WHEN ring_index = 0 THEN MIN(municipality_name) ELSE NULL END             AS municipalityName,
    {additive_outer},
    {wavg_outer},
    ST_AsGeoJSON(ST_Union_Agg(ST_Transform(geom_rd, 4326)))                        AS geom_json,
    SUM(clon * COALESCE(inwoners, 0.0)) / NULLIF(SUM(COALESCE(inwoners, 0.0)), 0.0) AS centroidLon,
    SUM(clat * COALESCE(inwoners, 0.0)) / NULLIF(SUM(COALESCE(inwoners, 0.0)), 0.0) AS centroidLat,
    0                                                                               AS is_inner,
    ring_index                                                                      AS ringIndex,
    sector_index                                                                    AS sectorIndex,
    MIN(agg_key)                                                                    AS agg_key,
    COLLECT_LIST(CAST(gid AS BIGINT))                                               AS constituentZoneIds
FROM zones_keyed
WHERE is_inner = 0
GROUP BY ring_index, sector_index, agg_key
"""


def build_zones_sql(catalog: str, schema: str) -> str:
    """Return the SQL string with one ``?`` placeholder for the bbox polygon GeoJSON."""
    sql = _ZONE_SQL_TEMPLATE.format(
        additive_inner=_ADDITIVE_INNER,
        additive_outer=_ADDITIVE_OUTER,
        wavg_inner=_WAVG_INNER,
        wavg_outer=_WAVG_OUTER,
        sec_expr=_SEC_EXPR,
        key_expr=_KEY_EXPR,
    )
    return sql.format(catalog=catalog, schema=schema)


def bbox_to_polygon_json(bbox: list[float]) -> str:
    """Convert ``[lon_min, lat_min, lon_max, lat_max]`` to a GeoJSON Polygon string."""
    lon_min, lat_min, lon_max, lat_max = bbox
    coords = [
        [lon_min, lat_min],
        [lon_max, lat_min],
        [lon_max, lat_max],
        [lon_min, lat_max],
        [lon_min, lat_min],
    ]
    return json.dumps({"type": "Polygon", "coordinates": [coords]})
