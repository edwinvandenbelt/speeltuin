"""Zone row parsing and feature assembly for the zone-aggregator — no I/O, no boto3."""

from __future__ import annotations

import json
import math

from zone_aggregator.domain.sql import _RINGS, _COMPASS_16


def _sector_index(bearing_deg: float, n_sectors: int) -> int:
    """Map a bearing (0–360°, clockwise from North) to a zero-based sector index."""
    sector_size = 360.0 / n_sectors
    return int(bearing_deg % 360.0 / sector_size) % n_sectors


def _compass_label(sector_idx: int, n_sectors: int) -> str:
    """Return the Dutch compass-rose label nearest to the midpoint bearing of *sector_idx*."""
    bearing_mid = sector_idx * 360.0 / n_sectors
    idx16 = round(bearing_mid / (360.0 / 16)) % 16
    return _COMPASS_16[idx16]


def parse_zone_rows(
    rows: list,
    col_names: list[str],
) -> tuple[list[dict], list[dict]]:
    """Convert raw DB rows to ``(inner_rows, agg_rows)``."""
    inner_rows: list[dict] = []
    agg_rows:   list[dict] = []

    for row in rows:
        d = dict(zip(col_names, row))
        d["is_inner"] = bool(d.get("is_inner"))
        if d["is_inner"]:
            inner_rows.append(d)
        else:
            _enrich_agg_row(d)
            agg_rows.append(d)

    return inner_rows, agg_rows


def _enrich_agg_row(row: dict) -> None:
    """Add ``direction_label``, ``zone_name``, and ``ring_label`` to an agg row in-place."""
    ring_idx = int(row.get("ringIndex") or 0)
    sec_idx  = int(row.get("sectorIndex") or 0)

    ring_info = _RINGS[ring_idx] if ring_idx < len(_RINGS) else _RINGS[-1]
    ring_lbl  = ring_info[3]
    n_sec     = ring_info[2]

    row["ringLabel"] = ring_lbl

    if ring_idx == 0:
        gemeente = str(row.get("municipalityName") or "").strip() or "Unknown"
        row["directionLabel"] = gemeente
        row["zoneName"]       = gemeente
    else:
        dir_lbl = _compass_label(sec_idx, n_sec)
        row["directionLabel"] = dir_lbl
        row["zoneName"]       = f"Aggregate {ring_lbl} {dir_lbl}"

    raw_gids = row.get("constituentZoneIds")
    if isinstance(raw_gids, list):
        row["constituentZoneIds"] = sorted(int(g) for g in raw_gids if g is not None)
    else:
        row["constituentZoneIds"] = []

    for key, val in row.items():
        if isinstance(val, float) and not math.isnan(val) and not math.isinf(val):
            row[key] = round(val, 3)


def _zone_row_to_feature(zone: dict, zone_type: str) -> dict:
    """Convert a zone dict to a GeoJSON Feature."""
    raw_geom = zone.get("geom_json")
    geom: dict | None = None
    if raw_geom:
        try:
            geom = json.loads(raw_geom)
        except (json.JSONDecodeError, ValueError):
            geom = None

    _SKIP = {"geom_json", "is_inner", "agg_key"}
    props: dict = {k: v for k, v in zone.items() if k not in _SKIP}
    props["zoneType"]    = zone_type
    props.setdefault("ringIndex",   -1)
    props.setdefault("ringLabel",   "")
    props.setdefault("sectorIndex", -1)

    return {"type": "Feature", "geometry": geom, "properties": props}


def derive_zone_feature_collection(
    inner_rows: list[dict],
    agg_rows:   list[dict],
) -> dict:
    """Combine inner zones and aggregate rows into a GeoJSON FeatureCollection."""
    from zone_aggregator.domain.sql import ZONE_PROPERTIES

    features: list[dict] = [
        _zone_row_to_feature(z, "inner")     for z in inner_rows
    ] + [
        _zone_row_to_feature(a, "aggregate") for a in agg_rows
    ]
    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"zone_properties": list(ZONE_PROPERTIES)},
    }
