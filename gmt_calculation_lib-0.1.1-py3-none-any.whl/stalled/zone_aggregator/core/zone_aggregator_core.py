"""
Pure-Python core for the zone-aggregator Lambda.

No I/O, no boto3, no Databricks connections.

Public API
----------
build_zones_sql(catalog, schema) -> str
bbox_to_polygon_json(bbox) -> str
parse_zone_rows(rows, col_names) -> tuple[list[dict], list[dict]]
derive_zone_feature_collection(inner_rows, agg_rows) -> dict
"""

from __future__ import annotations

from zone_aggregator.domain.sql import (  # noqa: F401
    _RINGS,
    _COMPASS_16,
    _WEIGHTED_AVG_COLS,
    _ADDITIVE_COLS,
    ZONE_PROPERTIES,
    _ADDITIVE_INNER,
    _ADDITIVE_OUTER,
    _WAVG_INNER,
    _WAVG_OUTER,
    _SEC_EXPR,
    _KEY_EXPR,
    _ZONE_SQL_TEMPLATE,
    build_zones_sql,
    bbox_to_polygon_json,
)
from zone_aggregator.domain.zone import (  # noqa: F401
    _sector_index,
    _compass_label,
    parse_zone_rows,
    _enrich_agg_row,
    _zone_row_to_feature,
    derive_zone_feature_collection,
)
