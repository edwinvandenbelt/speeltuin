"""Request model for the zone-aggregator Lambda."""

from __future__ import annotations

from pydantic import BaseModel


class HandlerInput(BaseModel):
    output_folder: str
    area_id: str
    bbox: list[float]
    catalog: str | None = None
    db_schema: str | None = None
