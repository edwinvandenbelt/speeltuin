"""Tests for zone_aggregator.zone_aggregator_core — pure logic, no I/O."""

from __future__ import annotations

import json

import pytest

from zone_aggregator.core.zone_aggregator_core import (
    _ADDITIVE_COLS,
    _COMPASS_16,
    _RINGS,
    _WEIGHTED_AVG_COLS,
    _compass_label,
    _sector_index,
    bbox_to_polygon_json,
    build_zones_sql,
    derive_zone_feature_collection,
    parse_zone_rows,
)


# ---------------------------------------------------------------------------
# bbox_to_polygon_json
# ---------------------------------------------------------------------------

class TestBboxToPolygonJson:
    def test_returns_valid_json(self):
        result = bbox_to_polygon_json([4.0, 52.0, 5.0, 53.0])
        parsed = json.loads(result)
        assert parsed["type"] == "Polygon"

    def test_ring_closed(self):
        parsed = json.loads(bbox_to_polygon_json([4.0, 52.0, 5.0, 53.0]))
        ring = parsed["coordinates"][0]
        assert ring[0] == ring[-1]

    def test_ring_has_five_points(self):
        parsed = json.loads(bbox_to_polygon_json([4.0, 52.0, 5.0, 53.0]))
        assert len(parsed["coordinates"][0]) == 5

    def test_corners_match_bbox(self):
        bbox = [4.1, 52.1, 4.9, 52.9]
        parsed = json.loads(bbox_to_polygon_json(bbox))
        ring = parsed["coordinates"][0]
        lons = {p[0] for p in ring}
        lats = {p[1] for p in ring}
        assert lons == {4.1, 4.9}
        assert lats == {52.1, 52.9}

    def test_degenerate_zero_area(self):
        result = bbox_to_polygon_json([5.0, 52.0, 5.0, 52.0])
        parsed = json.loads(result)
        assert parsed["type"] == "Polygon"


# ---------------------------------------------------------------------------
# build_zones_sql
# ---------------------------------------------------------------------------

class TestBuildZonesSql:
    def test_contains_table_reference(self):
        sql = build_zones_sql("spectrum", "2023_01")
        assert "spectrum" in sql
        assert "2023_01" in sql
        assert "d030_zones_met_centroids" in sql

    def test_has_one_placeholder(self):
        sql = build_zones_sql("spectrum", "2023_01")
        assert sql.count("?") == 1

    def test_selects_geom_json(self):
        sql = build_zones_sql("spectrum", "2023_01")
        assert "geom_json" in sql.lower() or "ST_AsGeoJSON" in sql

    def test_selects_centroid_lon_lat(self):
        sql = build_zones_sql("spectrum", "2023_01")
        assert "centroidLon" in sql
        assert "centroidLat" in sql

    def test_selects_is_inner(self):
        sql = build_zones_sql("spectrum", "2023_01")
        assert "is_inner" in sql

    def test_schema_with_backticks(self):
        sql = build_zones_sql("mycat", "2024_01")
        assert "`2024_01`" in sql

    def test_additive_cols_present(self):
        sql = build_zones_sql("spectrum", "2023_01")
        for col in ("inwoners", "autos", "huishoudens"):
            assert col in sql

    def test_weighted_avg_cols_present(self):
        sql = build_zones_sql("spectrum", "2023_01")
        for col in _WEIGHTED_AVG_COLS:
            assert col in sql

    def test_union_all_present(self):
        sql = build_zones_sql("spectrum", "2023_01")
        assert "UNION ALL" in sql

    def test_st_union_agg_present(self):
        sql = build_zones_sql("spectrum", "2023_01")
        assert "ST_Union_Agg" in sql

    def test_collect_list_present(self):
        sql = build_zones_sql("spectrum", "2023_01")
        assert "COLLECT_LIST" in sql


# ---------------------------------------------------------------------------
# parse_zone_rows
# ---------------------------------------------------------------------------

class TestParseZoneRows:
    def _make_row(self, gid=1, is_inner=1, ring_index=-1, sector_index=-1,
                  agg_key=None, municipality_name="Deventer"):
        # 78 values matching _col_names() exactly.
        # Positions 0-4: identity columns; 5: inwoners; 6-69: 64 Nones (other numerics);
        # 70: geom_json; 71-72: centroid lon/lat; 73: is_inner;
        # 74: ring_index; 75: sector_index; 76: agg_key; 77: constituent_zone_ids
        return (
            gid, "z1", "Zone 1", "GM0001", municipality_name,  # 0-4
            1000,                                                # 5  inwoners
            *(None,) * 64,                                       # 6-69 other numerics
            '{"type":"Polygon","coordinates":[[[0,0],[1,0],[1,1],[0,0]]]}',  # 70
            5.0, 52.0,                                           # 71-72
            is_inner, ring_index, sector_index, agg_key, None,  # 73-77
        )

    def _col_names(self):
        return [
            "gid", "zoneId", "zoneName", "municipalityCode", "municipalityName",
            "inwoners",
            "inwoners_mannen", "inwoners_vrouwen",
            "inwoners_leeftijd_00_17_jaar", "inwoners_leeftijd_18_29_jaar",
            "inwoners_leeftijd_30_44_jaar", "inwoners_leeftijd_45_64_jaar",
            "inwoners_leeftijd_65_plus_jaar", "inwoners_leeftijd_00_14_jaar",
            "inwoners_leeftijd_15_24_jaar", "inwoners_leeftijd_25_44_jaar",
            "inwoners_migratieachtergrond_europees",
            "inwoners_migratieachtergrond_niet_europees",
            "inwoners_zonder_migratieachtergrond",
            "inwoners_migratieachtergrond_westers",
            "inwoners_migratieachtergrond_niet_westers",
            "inwoners_leerlingen_middelbaaronderwijs",
            "inwoners_leerlingen_middelbaarberoepsonderwijs",
            "inwoners_leerlingen_hogeronderwijs",
            "inwoners_met_rijbewijs", "inwoners_zonder_rijbewijs",
            "inwoners_arbeidssituatie_student",
            "inwoners_arbeidssituatie_werkend",
            "inwoners_arbeidssituatie_anders",
            "huishoudens", "huishoudens_1_persoons", "huishoudens_2_persoons",
            "huishoudens_3_persoons", "huishoudens_4_persoons",
            "huishoudens_5_persoons", "huishoudens_6_plus_persoons",
            "huishoudens_meerpersoons_zonder_kinderen",
            "huishoudens_meerpersoons_met_kinderen",
            "huishoudens_0_autos", "huishoudens_1_autos", "huishoudens_2_autos",
            "huishoudens_3_plus_autos", "autos",
            "arbeidsplaatsen", "arbeidsplaatsen_woonfunctie",
            "arbeidsplaatsen_standplaats", "arbeidsplaatsen_ligplaats",
            "arbeidsplaatsen_celfunctie", "arbeidsplaatsen_onderwijsfunctie",
            "arbeidsplaatsen_industriefunctie", "arbeidsplaatsen_kantoorfunctie",
            "arbeidsplaatsen_overige_winkelfunctie",
            "arbeidsplaatsen_overige_voedselwinkelfunctie",
            "arbeidsplaatsen_supermarkt_voedselwinkelfunctie",
            "arbeidsplaatsen_gezondheidszorgfunctie",
            "arbeidsplaatsen_sportfunctie", "arbeidsplaatsen_bijeenkomstfunctie",
            "arbeidsplaatsen_logiesfunctie", "arbeidsplaatsen_boerderijfunctie",
            "arbeidsplaatsen_terminalfunctie",
            "arbeidsplaatsen_distributiecentrumfunctie",
            "arbeidsplaatsen_overige_gebruiksfunctie",
            "arbeidsplaatsen_gecombineerde_functies",
            "leerlingplaatsen_basisonderwijs",
            "leerlingplaatsen_middelbaaronderwijs",
            "leerlingplaatsen_middelbaarberoepsonderwijs",
            "leerlingplaatsen_hogeronderwijs",
            "percentage_huishoudens_in_40_procent_laagste_inkomens",
            "percentage_huishoudens_in_20_procent_hoogste_inkomens",
            "stedelijkheidsgraad",
            "geom_json", "centroidLon", "centroidLat",
            "is_inner", "ringIndex", "sectorIndex", "agg_key", "constituentZoneIds",
        ]

    def test_returns_tuple_of_two_lists(self):
        rows = [self._make_row()]
        result = parse_zone_rows(rows, self._col_names())
        assert isinstance(result, tuple)
        assert len(result) == 2

    def test_inner_row_goes_to_first_list(self):
        rows = [self._make_row(is_inner=1)]
        inner, agg = parse_zone_rows(rows, self._col_names())
        assert len(inner) == 1
        assert len(agg) == 0

    def test_outer_row_goes_to_second_list(self):
        rows = [self._make_row(is_inner=0, ring_index=1, sector_index=2, agg_key="r1_s2")]
        inner, agg = parse_zone_rows(rows, self._col_names())
        assert len(inner) == 0
        assert len(agg) == 1

    def test_gid_preserved_inner(self):
        rows = [self._make_row(gid=42)]
        inner, _ = parse_zone_rows(rows, self._col_names())
        assert inner[0]["gid"] == 42

    def test_is_inner_truthy_normalised(self):
        rows = [self._make_row(is_inner=1)]
        inner, _ = parse_zone_rows(rows, self._col_names())
        assert inner[0]["is_inner"] is True

    def test_is_inner_zero_normalised(self):
        rows = [self._make_row(is_inner=0, ring_index=1, sector_index=0, agg_key="r1_s0")]
        _, agg = parse_zone_rows(rows, self._col_names())
        assert agg[0]["is_inner"] is False

    def test_empty_rows(self):
        inner, agg = parse_zone_rows([], self._col_names())
        assert inner == []
        assert agg == []

    def test_multiple_inner_rows(self):
        rows = [self._make_row(gid=i) for i in range(5)]
        inner, agg = parse_zone_rows(rows, self._col_names())
        assert len(inner) == 5
        assert len(agg) == 0

    def test_agg_row_gets_zone_naam(self):
        rows = [self._make_row(
            is_inner=0, ring_index=1, sector_index=2, agg_key="r1_s2",
        )]
        _, agg = parse_zone_rows(rows, self._col_names())
        assert "zoneName" in agg[0]
        assert agg[0]["zoneName"] != ""

    def test_agg_row_gets_ring_label(self):
        rows = [self._make_row(
            is_inner=0, ring_index=2, sector_index=3, agg_key="r2_s3",
        )]
        _, agg = parse_zone_rows(rows, self._col_names())
        assert agg[0].get("ringLabel") == "25-50km"

    def test_ring0_agg_direction_label_is_gemeente(self):
        rows = [self._make_row(
            is_inner=0, ring_index=0, sector_index=-1,
            agg_key="r0_Apeldoorn", municipality_name="Apeldoorn",
        )]
        _, agg = parse_zone_rows(rows, self._col_names())
        assert agg[0]["directionLabel"] == "Apeldoorn"


# ---------------------------------------------------------------------------
# _sector_index
# ---------------------------------------------------------------------------

class TestSectorIndex:
    def test_north_is_zero(self):
        assert _sector_index(0.0, 8) == 0

    def test_north_360_is_zero(self):
        assert _sector_index(360.0, 8) == 0

    def test_east_sector_8(self):
        # 90° = East → sector 2 of 8 (each sector 45°)
        assert _sector_index(90.0, 8) == 2

    def test_south_sector_8(self):
        assert _sector_index(180.0, 8) == 4

    def test_west_sector_8(self):
        assert _sector_index(270.0, 8) == 6

    def test_sector_boundary_wraps(self):
        # Just before 360 should still be sector 7 (last sector)
        assert _sector_index(359.0, 8) == 7

    def test_16_sectors_ne(self):
        # 45° with 16 sectors: sector_size=22.5, (45+11.25)%360/22.5 = 2
        assert _sector_index(45.0, 16) == 2


# ---------------------------------------------------------------------------
# _compass_label
# ---------------------------------------------------------------------------

class TestCompassLabel:
    def test_north_label(self):
        assert _compass_label(0, 8) == "N"

    def test_east_label_8_sectors(self):
        # sector 2 of 8: midpoint bearing = 90° → "O" (East)
        assert _compass_label(2, 8) == "O"

    def test_south_label_8_sectors(self):
        assert _compass_label(4, 8) == "Z"

    def test_16_sectors_nnw_wrap(self):
        # sector 15 of 16: midpoint = 337.5° → "NNW"
        assert _compass_label(15, 16) == "NNW"

    def test_result_in_compass_16(self):
        for n_sec in (8, 12, 16, 32):
            for sec_idx in range(n_sec):
                assert _compass_label(sec_idx, n_sec) in _COMPASS_16


# ---------------------------------------------------------------------------
# derive_zone_feature_collection
# ---------------------------------------------------------------------------

class TestDeriveZoneFeatureCollection:
    def _inner(self, gid=1):
        return {
            "gid": gid, "zoneId": f"z{gid}", "zoneName": "Inner Zone",
            "municipalityName": "Deventer", "municipalityCode": "GM0001",
            "inwoners": 500, "is_inner": True,
            "geom_json": json.dumps({
                "type": "Polygon",
                "coordinates": [[[5, 52], [6, 52], [6, 53], [5, 52]]],
            }),
            "centroidLon": 5.5, "centroidLat": 52.5,
        }

    def _agg(self, gid=100):
        row: dict = {
            "gid": gid, "zone_id": "agg_r1_s2", "zone_name": "Aggregate 10-25km NO",
            "zoneType": "aggregate", "ringIndex": 1, "ringLabel": "10-25km",
            "sectorIndex": 2, "directionLabel": "NO", "municipality_name": None,
            "inwoners": 1000,
            "geom_json": json.dumps({
                "type": "Polygon",
                "coordinates": [[[7, 52], [8, 52], [8, 53], [7, 52]]],
            }),
            "centroidLon": 7.5, "centroidLat": 52.5,
            "constituentZoneIds": [1, 2, 3],
        }
        for col in _ADDITIVE_COLS:
            row.setdefault(col, 0)
        for col in _WEIGHTED_AVG_COLS:
            row.setdefault(col, None)
        return row

    def test_returns_feature_collection(self):
        fc = derive_zone_feature_collection([self._inner()], [self._agg()])
        assert fc["type"] == "FeatureCollection"

    def test_features_list(self):
        fc = derive_zone_feature_collection([self._inner()], [self._agg()])
        assert isinstance(fc["features"], list)

    def test_inner_plus_agg_count(self):
        fc = derive_zone_feature_collection([self._inner(1), self._inner(2)], [self._agg(100)])
        assert len(fc["features"]) == 3

    def test_inner_zone_type_in_properties(self):
        fc = derive_zone_feature_collection([self._inner()], [])
        feat = fc["features"][0]
        assert feat["properties"]["zoneType"] == "inner"

    def test_agg_zone_type_in_properties(self):
        fc = derive_zone_feature_collection([], [self._agg()])
        feat = fc["features"][0]
        assert feat["properties"]["zoneType"] == "aggregate"

    def test_inner_geometry_parsed(self):
        fc = derive_zone_feature_collection([self._inner()], [])
        geom = fc["features"][0]["geometry"]
        assert geom is not None
        assert geom["type"] == "Polygon"

    def test_agg_geometry_in_feature(self):
        fc = derive_zone_feature_collection([], [self._agg()])
        geom = fc["features"][0]["geometry"]
        assert geom is not None
        assert geom["type"] == "Polygon"

    def test_empty_inputs(self):
        fc = derive_zone_feature_collection([], [])
        assert fc["features"] == []

    def test_geom_json_not_in_properties(self):
        fc = derive_zone_feature_collection([self._inner()], [])
        props = fc["features"][0]["properties"]
        assert "geom_json" not in props

    def test_ring_index_present_in_inner_properties(self):
        fc = derive_zone_feature_collection([self._inner()], [])
        props = fc["features"][0]["properties"]
        assert "ringIndex" in props
        assert props["ringIndex"] == -1

    def test_ring_index_present_in_agg_properties(self):
        fc = derive_zone_feature_collection([], [self._agg()])
        props = fc["features"][0]["properties"]
        assert props["ringIndex"] == 1


# ---------------------------------------------------------------------------
# _enrich_agg_row — rounding
# ---------------------------------------------------------------------------

class TestEnrichAggRowRounding:
    """Verify that _enrich_agg_row rounds float values to 3 decimal places."""

    def _make_agg_row(self, **overrides):
        """Return a minimal agg-row dict ready for _enrich_agg_row."""
        row = {
            "ringIndex": 1,
            "sectorIndex": 2,
            "municipalityName": None,
            "constituentZoneIds": [],
        }
        row.update(overrides)
        return row

    # Import lazily so we don't expose it in the module-level import block.
    @staticmethod
    def _enrich(row):
        from zone_aggregator.core.zone_aggregator_core import _enrich_agg_row
        _enrich_agg_row(row)
        return row

    def test_float_rounded_to_3_places(self):
        row = self._make_agg_row(inwoners=1234.56789)
        self._enrich(row)
        assert row["inwoners"] == round(1234.56789, 3)

    def test_float_already_3_places_unchanged(self):
        row = self._make_agg_row(some_val=1.234)
        self._enrich(row)
        assert row["some_val"] == 1.234

    def test_integer_not_changed(self):
        row = self._make_agg_row(inwoners=1000)
        self._enrich(row)
        assert row["inwoners"] == 1000
        assert isinstance(row["inwoners"], int)

    def test_none_not_changed(self):
        row = self._make_agg_row(some_col=None)
        self._enrich(row)
        assert row["some_col"] is None

    def test_string_not_changed(self):
        row = self._make_agg_row(zone_name=None)
        self._enrich(row)
        # zoneName is a string after enrichment — must not be rounded
        assert isinstance(row["zoneName"], str)

    def test_nan_not_changed(self):
        import math
        row = self._make_agg_row(some_col=float("nan"))
        self._enrich(row)
        assert math.isnan(row["some_col"])

    def test_inf_not_changed(self):
        import math
        row = self._make_agg_row(some_col=float("inf"))
        self._enrich(row)
        assert math.isinf(row["some_col"])

    def test_multiple_floats_all_rounded(self):
        row = self._make_agg_row(a=1.111111, b=2.999999, c=0.000001)
        self._enrich(row)
        assert row["a"] == 1.111
        assert row["b"] == 3.0
        assert row["c"] == 0.0

    def test_weighted_avg_col_rounded(self):
        """A weighted-average column (percentage) should also be rounded."""
        row = self._make_agg_row(
            percentage_huishoudens_in_40_procent_laagste_inkomens=12.3456789,
        )
        self._enrich(row)
        assert row["percentage_huishoudens_in_40_procent_laagste_inkomens"] == 12.346

    def test_centroid_lon_rounded(self):
        row = self._make_agg_row(centroidLon=5.123456789, centroidLat=52.987654321)
        self._enrich(row)
        assert row["centroidLon"] == 5.123
        assert row["centroidLat"] == 52.988
