"""Local debug runner for zone_aggregator.

Calls zone_aggregator_core directly — no Lambda handler involved.

Usage
-----
    python -m zone_aggregator.zone_aggregator_runner \\
        --output s3://gmp-networks/zones/deventer-centrum-ZONE-CAR.geojson \\
        --bbox 6.0 52.0 6.2 52.1 \\
        --catalog spectrum --schema 2024_01

Prerequisites
-------------
* Databricks credentials in a .env file or os.environ
  (DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID, DATABRICKS_TOKEN).
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Local runner for zone_aggregator (calls core directly)."
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder URI (s3://bucket/prefix/ or local dir). File named {area_id}-ZONE.geojson.",
    )
    parser.add_argument(
        "--area-id",
        required=True,
        metavar="ID",
        help="Area identifier used in the output filename.",
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        required=True,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box as four floats",
    )
    parser.add_argument("--catalog", default="spectrum", help="Databricks Unity Catalog name")
    parser.add_argument("--schema",  default="2024_01",  help="Databricks schema / dataset version")
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from zone_aggregator.core.zone_aggregator_core import (  # noqa: PLC0415
        build_zones_sql,
        bbox_to_polygon_json,
        parse_zone_rows,
        derive_zone_feature_collection,
    )
    import shared.databricks_sql as databricks_sql  # noqa: PLC0415

    # 1. Query Databricks for all zones
    print(f"Querying Databricks: catalog={args.catalog!r}  schema={args.schema!r}")
    sql = build_zones_sql(args.catalog, args.schema)
    with databricks_sql.connect_from_env() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, (bbox_to_polygon_json(args.bbox),))
            col_names = [d[0] for d in cur.description]
            rows      = cur.fetchall()
    print(f"Zone rows returned : {len(rows)}")

    # 2. Parse + build FeatureCollection
    inner_rows, agg_rows = parse_zone_rows(rows, col_names)
    zones_fc = derive_zone_feature_collection(inner_rows, agg_rows)
    print(
        f"Zones produced : {len(zones_fc['features'])} "
        f"({len(inner_rows)} inner, {len(agg_rows)} aggregate)"
    )

    # 3. Write output
    from shared.output_path import build_output_path  # noqa: PLC0415
    zones_fc.setdefault("properties", {})["area_id"] = args.area_id
    out_uri = build_output_path(args.output_folder, args.area_id, "ZONE")
    print(f"Writing : {out_uri}")
    _write_uri(out_uri, json.dumps(zones_fc, ensure_ascii=False).encode("utf-8"))
    print("Done.")


if __name__ == "__main__":
    main()
