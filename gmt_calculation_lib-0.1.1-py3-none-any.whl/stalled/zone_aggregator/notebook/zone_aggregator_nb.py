# Databricks notebook source
# ---------------------------------------------------------------------------
# zone_aggregator_nb.py — Databricks notebook interface for zone aggregation.
#
# This notebook:
#   1. Reads widget parameters (uuid, bbox, catalog, schema, …).
#   2. Queries d030_zones_met_centroids via spark.sql() using SQL built by
#      zone_aggregator.zone_aggregator_core.build_zones_sql().
#      NOTE: spark.sql() does not support ? placeholders — the polygon GeoJSON
#      is embedded directly in the SQL string (single-quote–escaped).
#   3. Calls pure core functions (parse_zone_rows, derive_zone_feature_collection)
#      — no classify/aggregate step needed; SQL handles all aggregation.
#   4. Writes GeoJSON and GeoParquet outputs to S3 or a local path.
#
# Requirements (Databricks cluster):
#   pip install boto3 geopandas pyarrow   (or attach via cluster library)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
import tempfile
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("zone_aggregator_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install geopandas pyarrow

# COMMAND ----------
# geopandas is optional — GeoParquet output is skipped when unavailable.
try:
    import geopandas as gpd
    _HAS_GEOPANDAS = True
except ImportError:
    _HAS_GEOPANDAS = False
    logger.warning(
        "geopandas / pyarrow not installed — GeoParquet output will be skipped."
    )

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "area_id", "",
    "Area ID — used in output file names ({area_id}-ZONE.*); required",
)
dbutils.widgets.text(  # noqa: F821
    "output_folder", "",
    "Output folder: s3://bucket/prefix  or  /dbfs/path (required)",
)
dbutils.widgets.text(  # noqa: F821
    "bbox", "4.9140989669,52.0270039292,4.9837934859,52.0587847105",
    "Bounding box — lon_min,lat_min,lon_max,lat_max in WGS-84",
)
dbutils.widgets.text(  # noqa: F821
    "DATABRICKS_CATALOG", "spectrum",
    "Unity Catalog name",
)
dbutils.widgets.text(  # noqa: F821
    "DATABRICKS_SCHEMA", "2023_01",
    "Schema / dataset version (e.g. 2024_01)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from zone_aggregator.core.zone_aggregator_core import (  # noqa: E402
    bbox_to_polygon_json,
    build_zones_sql,
    derive_zone_feature_collection,
    parse_zone_rows,
)

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

AREA_ID  = dbutils.widgets.get("area_id").strip()                   # noqa: F821
bbox_raw = dbutils.widgets.get("bbox").strip()                      # noqa: F821
CATALOG  = dbutils.widgets.get("DATABRICKS_CATALOG").strip() or "spectrum"  # noqa: F821
SCHEMA   = dbutils.widgets.get("DATABRICKS_SCHEMA").strip() or "2023_01"    # noqa: F821
OUT_PATH = dbutils.widgets.get("output_folder").strip()             # noqa: F821

if not AREA_ID:
    raise ValueError("area_id widget must not be empty.")
if not OUT_PATH:
    raise ValueError("output_folder widget must not be empty.")

try:
    BBOX = [float(x.strip()) for x in bbox_raw.split(",")]
except ValueError as _exc:
    raise ValueError(
        f"'bbox' must be four comma-separated numbers (lon_min,lat_min,lon_max,lat_max), "
        f"got: {bbox_raw!r}"
    ) from _exc
if len(BBOX) != 4:
    raise ValueError(f"'bbox' must have exactly 4 values, got {len(BBOX)}.")

logger.info(
    "area_id=%s  bbox=%s  catalog=%s.%s",
    AREA_ID, BBOX, CATALOG, SCHEMA,
)
print(f"Area ID : {AREA_ID}")
print(f"BBox    : {BBOX}")
print(f"Catalog : {CATALOG}.{SCHEMA}")

# COMMAND ----------
# ── I/O helpers ───────────────────────────────────────────────────────────────

def _s3_split(uri: str) -> tuple:
    without = uri[5:]
    bucket, _, prefix = without.partition("/")
    return bucket, prefix


def _put_s3(bucket: str, key: str, data: bytes, content_type: str) -> None:
    import boto3  # noqa: PLC0415
    boto3.client("s3").put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _ensure_dir(path: str) -> None:
    if not path.startswith("s3://"):
        os.makedirs(path, exist_ok=True)


def _write_file(path: str, filename: str, data: bytes, content_type: str) -> str:
    if path.startswith("s3://"):
        bucket, prefix = _s3_split(path)
        key = f"{prefix}/{filename}".lstrip("/")
        _put_s3(bucket, key, data, content_type)
        return f"s3://{bucket}/{key}"
    fp = os.path.join(path, filename)
    with open(fp, "wb") as fh:
        fh.write(data)
    logger.info("Wrote %s  (%d bytes)", fp, len(data))
    return fp


def _output_dir() -> str:
    return OUT_PATH.rstrip("/")


def _write_geoparquet(fc: dict, out_dir: str, area_id: str):
    if not _HAS_GEOPANDAS:
        logger.warning("geopandas not installed — skipping GeoParquet output.")
        return None
    filename = f"{area_id}-ZONE.parquet"
    records  = []
    for feat in fc["features"]:
        props = dict(feat["properties"])
        try:
            from shapely.geometry import shape as _shape  # noqa: PLC0415
            props["geometry"] = _shape(feat["geometry"]) if feat.get("geometry") else None
        except Exception as exc:
            logger.warning("Skipping feature with bad geometry: %s", exc)
            props["geometry"] = None
        records.append(props)
    if not records:
        return None
    gdf = gpd.GeoDataFrame(records, crs="EPSG:4326")
    if out_dir.startswith("s3://"):
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tmp:
            tmp_path = tmp.name
        try:
            gdf.to_parquet(tmp_path)
            bucket, prefix = _s3_split(out_dir)
            key = f"{prefix}/{filename}".lstrip("/")
            with open(tmp_path, "rb") as fh:
                _put_s3(bucket, key, fh.read(), "application/octet-stream")
            return f"s3://{bucket}/{key}"
        finally:
            os.unlink(tmp_path)
    fp = os.path.join(out_dir, filename)
    gdf.to_parquet(fp)
    logger.info("Wrote %s  (%d zones)", fp, len(gdf))
    return fp

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Zone Aggregation
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
logger.info("Starting zone aggregation at %s", _t_start.isoformat())

# 1. Build SQL and embed polygon (spark.sql has no ? params).
_polygon_json = bbox_to_polygon_json(BBOX)
_poly_esc     = _polygon_json.replace("'", "''")
_sql_template = build_zones_sql(CATALOG, SCHEMA)
_sql          = _sql_template.replace("?", f"'{_poly_esc}'")
logger.debug("Zones SQL (first 300 chars): %s…", _sql[:300])

# 2. Execute via Spark
_df        = spark.sql(_sql)  # noqa: F821 — Databricks-injected
_col_names = _df.columns
_rows      = _df.collect()
logger.info("Zones query returned %d rows", len(_rows))

# 3. Parse rows — SQL already aggregated outer zones; returns (inner_rows, agg_rows)
_inner_rows, _agg_rows = parse_zone_rows(_rows, _col_names)
logger.info("Zones: %d inner, %d aggregate", len(_inner_rows), len(_agg_rows))

# 4. Assemble GeoJSON FeatureCollection (pure — no I/O)
_zone_fc  = derive_zone_feature_collection(_inner_rows, _agg_rows)
_n_inner  = len(_inner_rows)
_n_agg    = len(_agg_rows)
logger.info(
    "Zone FC assembled: %d inner, %d aggregate, %d total",
    _n_inner, _n_agg, len(_zone_fc["features"]),
)

# 8. Prepare output directory
_out_dir = _output_dir()
_ensure_dir(_out_dir)
logger.info("Output directory: %s", _out_dir)

# 9. Write GeoJSON
_geojson_payload = json.dumps(_zone_fc, ensure_ascii=False, indent=2).encode("utf-8")
_geojson_path    = _write_file(
    _out_dir, f"{AREA_ID}-ZONE.geojson", _geojson_payload, "application/geo+json",
)

# 10. Write GeoParquet (optional)
_parquet_path = _write_geoparquet(_zone_fc, _out_dir, AREA_ID)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("Zone aggregation complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"Zone Aggregation complete — {_total_elapsed:.1f}s total")
print(_SEP)
print(f"  Area ID     : {AREA_ID}")
print(f"  BBox        : {BBOX}")
print(f"  Catalog     : {CATALOG}.{SCHEMA}")
print(f"  Inner zones : {_n_inner}")
print(f"  Agg zones   : {_n_agg}")
print(f"  Total zones : {len(_zone_fc['features'])}")
print()
print(f"  GeoJSON     : {_geojson_path}")
print(f"  GeoParquet  : {_parquet_path or '(skipped — geopandas unavailable)'}")
print(_SEP)
