"""Pure-Python Melvin Downloader core — no I/O, no HTTP, no boto3, no external deps.

Filters and converts raw Melvin GeoJSON (roadworks) data to the GMT analytics format,
consistent with the network-intersector FeatureCollection structure.

Public API
----------
bbox_overlaps(area_bbox, query_bbox) -> bool
    Returns True when two axis-aligned bounding boxes overlap.

find_area_ids(areas, bbox) -> list[int]
    Returns Melvin area IDs whose geometry overlaps the given bounding box.

merge_multilinestring(coordinates) -> list
    Merges a MultiLineString coordinate list into a single LineString coordinate list.

to_analytics_geojson(raw_geojson, bbox) -> tuple[dict, dict]
    Converts a raw Melvin export FeatureCollection to the GMT analytics format.
    Returns (result_fc, stats).

    Output feature properties (MELVIN_LINK_PROPERTIES):
      linkId / melvinId  — Melvin recordId
      mode               — always "CAR"
      length             — metres
      heading            — compass bearing 0-360
      capacity           — 0 if restrictionType=COMPLETE, else None
      flow               — 0 if restrictionType=COMPLETE, else None
      speed              — Melvin speed value if restrictionType=SPEED, else None
      direction          — A_B | B_A | BOTH (original) or A_B / B_A (after split)
      restrictionType    — COMPLETE | SPEED
      reverseLinkIds     — cross-references the opposite feature when direction=BOTH
"""

from __future__ import annotations

import logging
import math
from typing import Any

logger = logging.getLogger(__name__)

# Ordered list of property keys present on every Feature in the output FeatureCollection.
MELVIN_LINK_PROPERTIES: tuple[str, ...] = (
    "linkId",           # = recordId from Melvin
    "melvinId",         # = recordId from Melvin
    "mode",             # always "CAR" (roadworks affect road traffic)
    "length",           # link length in metres (flat-earth approximation)
    "heading",          # compass bearing 0–360° (0=N, 90=E) of travel direction
    "capacity",         # 0 when restrictionType is COMPLETE, else None
    "flow",             # 0 when restrictionType is COMPLETE, else None
    "speed",            # speed value from Melvin when restrictionType is SPEED, else None
    "direction",        # A_B | B_A — direction the restriction applies to
    "restrictionType",  # COMPLETE | SPEED
    "reverseLinkIds",   # ID of the opposite-direction feature when split from BOTH
)

# Properties to strip from every feature before writing to output.
_STRIP_PROPERTIES: frozenset[str] = frozenset([
    # Noisy audit / contact fields
    "createdBy", "lastChangedBy", "remarks", "contacts", "source",
    # Type field (used only for the RESTRICTION filter, not meaningful in output)
    "type",
    # Fields explicitly excluded from the output
    "railwayTypes", "boatTypes", "vehicleTypes", "emergency",
    "roadManagementType", "recordId", "transportMode", "periods",
    "publicTransport",
])

# Offset applied to each direction when splitting a BOTH-direction feature.
# Identical to the value used by the network-intersector.
_OFFSET_M = 2.0

# Near-node transition distances (metres) — same as network-intersector.
_NEAR_NODE_M     = 3.0
_NEAR_NODE_M_MED = 1.0
_NEAR_NODE_M_SHT = 0.5


# ---------------------------------------------------------------------------
# Geometry helpers (flat-earth, stdlib only)
# ---------------------------------------------------------------------------

def _heading(coords: list[list[float]]) -> float:
    """Compass bearing 0–360° (0=N, 90=E) from first to last coord of a LineString.

    Uses the same flat-earth approximation as the network-intersector.
    """
    lon0, lat0 = coords[0][0], coords[0][1]
    lon1, lat1 = coords[-1][0], coords[-1][1]
    lat_mid_r = math.radians((lat0 + lat1) / 2)
    dx = (lon1 - lon0) * math.cos(lat_mid_r)
    dy = lat1 - lat0
    return round(math.degrees(math.atan2(dx, dy)) % 360, 1)


def _linestring_length_m(coords: list[list[float]]) -> float:
    """Return the total length in metres of a LineString (flat-earth approximation)."""
    if len(coords) < 2:
        return 0.0
    total = 0.0
    for i in range(len(coords) - 1):
        lon0, lat0 = coords[i][0], coords[i][1]
        lon1, lat1 = coords[i + 1][0], coords[i + 1][1]
        lat_mid_r = math.radians((lat0 + lat1) / 2)
        dx = (lon1 - lon0) * math.cos(lat_mid_r) * 111_320.0
        dy = (lat1 - lat0) * 111_320.0
        total += math.hypot(dx, dy)
    return round(total, 1)


def _offset_linestring(coords: list, offset_m: float) -> list:
    """Offset a LineString by *offset_m* metres to the right of the travel direction.

    Copied verbatim from stalled.network_intersector/domain/geometry.py to keep this
    module free of cross-module imports.  Uses a flat-earth WGS-84 approximation
    accurate enough for a 2-metre offset anywhere in the Netherlands.
    """
    if len(coords) < 2:
        return [c[:2] for c in coords]

    lat0  = sum(c[1] for c in coords) / len(coords)
    d_lat = 111_320.0
    d_lon = 111_320.0 * math.cos(math.radians(lat0))

    mx = [c[0] * d_lon for c in coords]
    my = [c[1] * d_lat for c in coords]
    n  = len(mx)

    total_len = sum(math.hypot(mx[i + 1] - mx[i], my[i + 1] - my[i]) for i in range(n - 1))
    if total_len >= 10.0:
        near_m = _NEAR_NODE_M
    elif total_len >= 3.0:
        near_m = _NEAR_NODE_M_MED
    else:
        near_m = _NEAR_NODE_M_SHT

    out: list = []
    out.append(list(coords[0][:2]))

    first_len = math.hypot(mx[1] - mx[0], my[1] - my[0])
    if first_len > near_m:
        udx = (mx[1] - mx[0]) / first_len
        udy = (my[1] - my[0]) / first_len
        nx, ny = udy, -udx
        out.append([
            (mx[0] + udx * near_m + nx * offset_m) / d_lon,
            (my[0] + udy * near_m + ny * offset_m) / d_lat,
        ])

    for i in range(1, n - 1):
        normals = []
        for (ax, ay, bx, by) in [(mx[i - 1], my[i - 1], mx[i],     my[i]),
                                  (mx[i],     my[i],     mx[i + 1], my[i + 1])]:
            dx, dy = bx - ax, by - ay
            ln = math.hypot(dx, dy)
            if ln:
                normals.append((dy / ln, -dx / ln))
        if normals:
            anx = sum(v[0] for v in normals) / len(normals)
            any_ = sum(v[1] for v in normals) / len(normals)
            nl = math.hypot(anx, any_)
            if nl:
                anx, any_ = anx / nl, any_ / nl
        else:
            anx, any_ = 0.0, 0.0
        out.append([
            (mx[i] + anx * offset_m) / d_lon,
            (my[i] + any_ * offset_m) / d_lat,
        ])

    last_len = math.hypot(mx[n - 1] - mx[n - 2], my[n - 1] - my[n - 2])
    if last_len > near_m:
        udx = (mx[n - 1] - mx[n - 2]) / last_len
        udy = (my[n - 1] - my[n - 2]) / last_len
        nx, ny = udy, -udx
        out.append([
            (mx[n - 1] - udx * near_m + nx * offset_m) / d_lon,
            (my[n - 1] - udy * near_m + ny * offset_m) / d_lat,
        ])

    out.append(list(coords[-1][:2]))
    return out


# ---------------------------------------------------------------------------
# Spatial helpers
# ---------------------------------------------------------------------------

def bbox_overlaps(area_bbox: tuple[float, float, float, float],
                  query_bbox: tuple[float, float, float, float]) -> bool:
    """Return True when two axis-aligned bounding boxes overlap."""
    a_minx, a_miny, a_maxx, a_maxy = area_bbox
    b_minx, b_miny, b_maxx, b_maxy = query_bbox
    return a_minx <= b_maxx and a_maxx >= b_minx and a_miny <= b_maxy and a_maxy >= b_miny


def _area_extent(geometry: dict[str, Any]) -> tuple[float, float, float, float] | None:
    """Compute the bounding box of a GeoJSON geometry (Polygon, MultiPolygon, LineString)."""
    coords: list[Any] = []
    geo_type = geometry.get("type", "")
    raw_coords = geometry.get("coordinates")
    if not raw_coords:
        return None

    if geo_type == "Polygon":
        for ring in raw_coords:
            coords.extend(ring)
    elif geo_type == "MultiPolygon":
        for polygon in raw_coords:
            for ring in polygon:
                coords.extend(ring)
    elif geo_type == "LineString":
        coords = raw_coords
    elif geo_type == "MultiLineString":
        for segment in raw_coords:
            coords.extend(segment)
    else:
        return None

    if not coords:
        return None

    lons = [c[0] for c in coords]
    lats = [c[1] for c in coords]
    return (min(lons), min(lats), max(lons), max(lats))


def find_area_ids(areas: list[dict[str, Any]], bbox: list[float]) -> list[int]:
    """Return Melvin area IDs whose geometry bounding box overlaps *bbox* (sorted)."""
    query = (float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3]))
    matching: list[int] = []
    for area in areas:
        geometry = area.get("geometry")
        if geometry is None:
            continue
        extent = _area_extent(geometry)
        if extent is None:
            continue
        if bbox_overlaps(extent, query):
            matching.append(int(area["id"]))
            print("Matching area ", area["id"], area["name"], area["roadOperatorType"]) if "name" in area and "roadOperatorType" in area else ""
    logger.debug("find_area_ids: %d/%d areas overlap bbox %s", len(matching), len(areas), bbox)
    return sorted(matching)


def merge_multilinestring(coordinates: list[list[list[float]]]) -> list[list[float]]:
    """Merge a MultiLineString coordinate list into a single LineString coordinate list.

    Consecutive segments that share an endpoint are joined without duplicating it.
    """
    if not coordinates:
        return []
    merged: list[list[float]] = list(coordinates[0])
    for segment in coordinates[1:]:
        if not segment:
            continue
        start_idx = 1 if segment[0] == merged[-1] else 0
        merged.extend(segment[start_idx:])
    return merged


def _feature_bbox_overlaps(feature: dict[str, Any],
                            bbox: tuple[float, float, float, float]) -> bool:
    """Return True when a feature's geometry bounding box overlaps *bbox*."""
    geometry = feature.get("geometry")
    if not geometry:
        return False
    extent = _area_extent(geometry)
    if extent is None:
        return False
    return bbox_overlaps(extent, bbox)


# ---------------------------------------------------------------------------
# Main conversion
# ---------------------------------------------------------------------------

def _neg_id(record_id: Any) -> Any:
    """Return the negative / return-direction ID, mirroring network-intersector convention."""
    if isinstance(record_id, (int, float)):
        return -record_id
    return f"-{record_id}"


def _make_props(
    record_id: Any,
    coords: list[list[float]],
    direction: str,
    restriction_type: str,
    raw_speed: Any,
    reverse_link_ids: list,
    extra: dict[str, Any],
) -> dict[str, Any]:
    """Build the output properties dict for a single (possibly split) feature."""
    if restriction_type.upper() == "COMPLETE":
        capacity: int | None = 0
        flow: int | None = 0
        speed: Any = None
    elif restriction_type.upper() == "SPEED":
        capacity = None
        flow = None
        speed = raw_speed
    else:
        capacity = None
        flow = None
        speed = None

    return {
        "linkId":          record_id,
        "melvinId":        record_id,
        "mode":            "CAR",
        "length":          _linestring_length_m(coords),
        "heading":         _heading(coords) if len(coords) >= 2 else None,
        "capacity":        capacity,
        "flow":            flow,
        "speed":           speed,
        "direction":       direction,
        "restrictionType": restriction_type or None,
        "reverseLinkIds":  reverse_link_ids,
        **extra,
    }


def to_analytics_geojson(
    raw_geojson: dict[str, Any],
    bbox: list[float],
) -> tuple[dict[str, Any], dict[str, Any]]:
    """Convert a raw Melvin export FeatureCollection to the GMT analytics format.

    Steps
    -----
    1. Filters out ``Point`` geometry features.
    2. Filters features outside *bbox*.
    3. Keeps only features whose ``type`` property contains ``"RESTRICTION"``.
    4. Merges ``MultiLineString`` → ``LineString``.
    5. Splits ``direction=BOTH`` features into two directed features (A_B and B_A),
       each offset by 2 m to the right — identical to the network-intersector
       bidirectional-link split.  ``reverseLinkIds`` cross-reference the pair.
       ``direction=B_A`` features have their coordinates reversed.
    6. Builds network-intersector-compatible properties per ``MELVIN_LINK_PROPERTIES``.
    7. Strips excluded properties.

    Returns
    -------
    result_fc:
        GeoJSON FeatureCollection with a top-level ``properties`` dict
        (``modes``, ``link_properties``, ``bbox``).
    stats:
        ``{total, skipped_point, skipped_bbox, skipped_type, skipped_type_counts, output}``
    """
    query_bbox = (float(bbox[0]), float(bbox[1]), float(bbox[2]), float(bbox[3]))
    features_in: list[dict] = raw_geojson.get("features", [])
    total = len(features_in)
    skipped_point = 0
    skipped_bbox = 0
    skipped_type = 0
    skipped_type_counts: dict[str, int] = {}
    output_features: list[dict] = []

    for feature in features_in:
        geometry = feature.get("geometry") or {}
        geo_type = geometry.get("type", "")

        # 1. Skip Point features.
        if geo_type == "Point":
            skipped_point += 1
            continue

        # 2. Skip features outside bbox.
        if not _feature_bbox_overlaps(feature, query_bbox):
            skipped_bbox += 1
            continue

        # 3. Keep only RESTRICTION features.
        raw_props: dict[str, Any] = feature.get("properties") or {}
        raw_type: str = str(raw_props.get("type", ""))
        if "RESTRICTION" not in raw_type.upper():
            skipped_type += 1
            label = raw_type if raw_type else "(no type)"
            skipped_type_counts[label] = skipped_type_counts.get(label, 0) + 1
            continue

        # 4. Merge MultiLineString -> LineString.
        if geo_type == "MultiLineString":
            merged = merge_multilinestring(geometry.get("coordinates", []))
            coords: list[list[float]] = merged
        else:
            coords = list(geometry.get("coordinates", []))

        feature_id = feature.get("id")
        record_id = raw_props.get("recordId") or feature_id
        neg_id = _neg_id(record_id)

        restriction_type: str = str(raw_props.get("restrictionType", ""))
        raw_speed = raw_props.get("speed")
        direction: str = str(raw_props.get("direction", ""))

        # Extra props: everything not stripped and not handled explicitly above.
        extra: dict[str, Any] = {
            k: v for k, v in raw_props.items()
            if k not in _STRIP_PROPERTIES
            and k not in {"restrictionType", "direction", "speed"}
        }

        # 5. Direction-based geometry and splitting.
        if direction.upper() == "BOTH":
            # Split into two directed features, each offset 2 m to the right —
            # mirrors the network-intersector bidirectional-link split.
            fwd_coords = _offset_linestring(coords, _OFFSET_M)
            bwd_coords = _offset_linestring(list(reversed(coords)), _OFFSET_M)

            output_features.append({
                "type":       "Feature",
                "id":         record_id,
                "geometry":   {"type": "LineString", "coordinates": fwd_coords},
                "properties": _make_props(
                    record_id, fwd_coords, "A_B",
                    restriction_type, raw_speed, [neg_id], extra,
                ),
            })
            output_features.append({
                "type":       "Feature",
                "id":         neg_id,
                "geometry":   {"type": "LineString", "coordinates": bwd_coords},
                "properties": _make_props(
                    neg_id, bwd_coords, "B_A",
                    restriction_type, raw_speed, [record_id], extra,
                ),
            })

        elif direction.upper() == "B_A":
            # Reverse coordinates so the geometry runs in the travel direction.
            rev_coords = list(reversed(coords))
            output_features.append({
                "type":       "Feature",
                "id":         feature_id,
                "geometry":   {"type": "LineString", "coordinates": rev_coords},
                "properties": _make_props(
                    record_id, rev_coords, "B_A",
                    restriction_type, raw_speed, [], extra,
                ),
            })

        else:
            # A_B or unspecified — use coords as-is.
            output_features.append({
                "type":       "Feature",
                "id":         feature_id,
                "geometry":   {"type": "LineString", "coordinates": coords},
                "properties": _make_props(
                    record_id, coords, direction or "A_B",
                    restriction_type, raw_speed, [], extra,
                ),
            })

    result_fc: dict[str, Any] = {
        "type":     "FeatureCollection",
        "features": output_features,
        "properties": {
            "modes":           ["CAR"],
            "link_properties": list(MELVIN_LINK_PROPERTIES),
            "bbox":            list(bbox),
        },
    }
    stats: dict[str, Any] = {
        "total":               total,
        "skipped_point":       skipped_point,
        "skipped_bbox":        skipped_bbox,
        "skipped_type":        skipped_type,
        "skipped_type_counts": skipped_type_counts,
        "output":              len(output_features),
    }
    logger.info(
        "to_analytics_geojson: total=%d  skipped_point=%d  skipped_bbox=%d"
        "  skipped_type=%d  output=%d  type_breakdown=%s",
        total, skipped_point, skipped_bbox, skipped_type,
        len(output_features), skipped_type_counts,
    )
    return result_fc, stats
