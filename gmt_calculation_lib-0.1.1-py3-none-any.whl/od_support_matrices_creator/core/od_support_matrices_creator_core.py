"""Pure-Python od_support_matrices_creator core — no I/O, no boto3, no external deps.

Computes a full OD travel-time / distance / resistance matrix between all zones
in a network, routing through feedlinks and network links using Dijkstra.

Public API
----------
build_graph(network_fc, feedlinks_fc)
    -> tuple[adj, zone_node_ids, zone_centroids]
    Builds the directed weighted adjacency used by dijkstra_od.

compute_matrix(zone_ids, zone_node_ids, zone_centroids, adj)
    -> list[MatrixRecord]
    Runs Dijkstra from every zone origin and returns one record per OD pair.

enrich_od_geojson(od_fc, network_fc, feedlinks_fc) -> dict
    Adds a ``remainingCap`` property (bottleneck min remaining capacity along
    the time-optimal path) to every feature in an existing OD GeoJSON.
    Returns a new GeoJSON FeatureCollection with the enriched features.

enriched_od_to_csv(enriched_fc) -> str
    Serialises an enriched OD GeoJSON FeatureCollection to CSV text.
    Columns: fromZoneId, toZoneId, trips, travelTime, distance, remainingCap.

records_to_csv(records) -> str
    Serialises records to CSV text.

records_to_geojson(records, zone_centroids) -> dict
    Serialises records to a GeoJSON FeatureCollection (one feature per OD pair).
"""

from __future__ import annotations

import csv
import io
import logging
import math
from typing import TypedDict

from shared.graph_utils import dijkstra_od

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Prefix for virtual zone centroid nodes in the graph so they never collide
# with real network node IDs (which are plain integer strings).
_ZONE_PREFIX = "Z_"

# Fallback feedlink speed when no connected network link can be found.
_FALLBACK_SPEED_KMH: float = 50.0

# ---------------------------------------------------------------------------
# Output field names (authoritative — keep in sync with openapi.yaml)
# ---------------------------------------------------------------------------

MATRIX_PROPERTIES: tuple[str, ...] = (
    "fromZoneId",
    "toZoneId",
    "travelTime",      # seconds  (float | None)
    "distance",        # metres   (float | None)
    "remainingCap",    # cars/h   (float | None) — bottleneck min remaining capacity
)

# ---------------------------------------------------------------------------
# Internal types
# ---------------------------------------------------------------------------

Adjacency = dict[str, list[tuple[str, float, float, float, float]]]
# {node_id: [(neighbour_id, time_s, dist_m, remaining_cap), ...]}


class MatrixRecord(TypedDict):
    fromZoneId: str
    toZoneId: str
    travelTime: float | None
    distance: float | None
    remainingCap: float | None


# ---------------------------------------------------------------------------
# Graph construction
# ---------------------------------------------------------------------------

def build_graph(
    network_fc: dict,
    feedlinks_fc: dict,
) -> tuple[Adjacency, dict[str, str], dict[str, tuple[float, float]]]:
    """Build a directed weighted graph from a network and feedlinks GeoJSON.

    Parameters
    ----------
    network_fc:
        GeoJSON FeatureCollection produced by ``network_intersector`` /
        ``flow_scaler``.  Must be the plain network (no feedlinks).  Each
        feature must have properties: ``fromNode``, ``toNode``, ``speed``
        (km/h), ``length`` (m), ``capacity`` (cars/h), ``flowsPerDaypart``
        (dict of cars/h per period).
    feedlinks_fc:
        GeoJSON FeatureCollection produced by ``feedlink_creator``.
        Each feature must have properties:
        ``zoneId``, ``fromNode``, ``toNode``, ``length`` (m), ``capacity``
        (cars/h).  Direction (production vs attraction) is inferred
        automatically: the end that is present in the real network graph is
        the network attachment node; the other end is the zone centroid.

    Returns
    -------
    adj:
        Adjacency dict ``{node: [(neighbour, time_s, dist_m, remaining_cap)]}``.
    zone_node_ids:
        ``{zoneId: virtual_node_id}`` mapping each zone to its centroid node.
    zone_centroids:
        ``{zoneId: (lon, lat)}`` — populated from the feedlink zoneId values;
        callers must enrich this from the zone file.
    """
    adj: Adjacency = {}

    # ------------------------------------------------------------------
    # Pass 1 — build per-node max-speed lookup from network links
    # (used to infer feedlink travel time at the network attachment node)
    # ------------------------------------------------------------------
    node_max_speed: dict[str, float] = {}

    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        from_n = str(props.get("fromNode", ""))
        to_n   = str(props.get("toNode", ""))
        speed  = float(props.get("speed") or 0.0)
        for nid in (from_n, to_n):
            if not nid:
                continue
            if speed > node_max_speed.get(nid, 0.0):
                node_max_speed[nid] = speed

    # ------------------------------------------------------------------
    # Pass 2 — add network link edges
    # ------------------------------------------------------------------
    for feat in network_fc.get("features", []):
        props  = feat.get("properties") or {}
        from_n = str(props.get("fromNode", ""))
        to_n   = str(props.get("toNode", ""))
        if not from_n or not to_n:
            continue

        speed_kmh = float(props.get("speed") or 0.0)
        length_m  = float(props.get("length") or 0.0)
        capacity  = float(props.get("capacity") or 0.0)

        # Travel time in seconds (avoid division by zero)
        time_s = (length_m / (speed_kmh / 3.6)) if speed_kmh > 0.0 else float("inf")

        # Remaining capacity = capacity − peak-period flow
        daypart_flows = props.get("flowsPerDaypart")
        if daypart_flows and isinstance(daypart_flows, dict):
            peak_flow = max((float(v) for v in daypart_flows.values() if v is not None),
                            default=0.0)
        else:
            peak_flow = 0.0
        remaining_cap = max(capacity - peak_flow, 0.0)

        adj.setdefault(from_n, []).append((to_n, time_s, length_m, remaining_cap, capacity))

    # ------------------------------------------------------------------
    # Pass 3 — add feedlink edges (zone centroid <-> network node)
    # ------------------------------------------------------------------
    zone_node_ids: dict[str, str] = {}
    zone_centroids: dict[str, tuple[float, float]] = {}

    for feat in feedlinks_fc.get("features", []):
        props     = feat.get("properties") or {}
        zone_id   = str(props.get("zoneId")   or "")
        from_node = str(props.get("fromNode") or "")
        to_node   = str(props.get("toNode")   or "")
        dist_m    = float(props.get("length")   or 0.0)
        capacity  = float(props.get("capacity") or 0.0)

        if not zone_id or not from_node or not to_node:
            continue

        # Infer direction from which end is a real network node.
        # node_max_speed is populated in Pass 1 from actual network links.
        to_is_net   = to_node   in node_max_speed
        from_is_net = from_node in node_max_speed

        if to_is_net and not from_is_net:
            # Production feedlink: fromNode = zone centroid, toNode = network node
            network_node  = to_node
            is_production = True
            is_attraction = False
        elif from_is_net and not to_is_net:
            # Attraction feedlink: fromNode = network node, toNode = zone centroid
            network_node  = from_node
            is_production = False
            is_attraction = True
        else:
            # Ambiguous (both or neither in network) — treat as both
            network_node  = to_node
            is_production = True
            is_attraction = True

        # Virtual centroid node for this zone
        vnode = f"{_ZONE_PREFIX}{zone_id}"
        zone_node_ids[zone_id] = vnode

        # Speed at the network endpoint
        speed_at_node = node_max_speed.get(network_node, _FALLBACK_SPEED_KMH)
        if speed_at_node <= 0.0:
            speed_at_node = _FALLBACK_SPEED_KMH
        feedlink_time_s = dist_m / (speed_at_node / 3.6) if dist_m > 0.0 else 0.0

        if is_production:
            # zone centroid -> network node  (outgoing trip)
            adj.setdefault(vnode, []).append((network_node, feedlink_time_s, dist_m, capacity, capacity))
        if is_attraction:
            # network node -> zone centroid  (incoming trip)
            adj.setdefault(network_node, []).append((vnode, feedlink_time_s, dist_m, capacity, capacity))

    logger.info(
        "build_graph: %d network nodes, %d zone nodes, %d adj entries",
        len(node_max_speed),
        len(zone_node_ids),
        sum(len(v) for v in adj.values()),
    )
    return adj, zone_node_ids, zone_centroids


# ---------------------------------------------------------------------------
# Matrix computation
# ---------------------------------------------------------------------------

def compute_matrix(
    zone_ids: list[str],
    zone_node_ids: dict[str, str],
    zone_centroids: dict[str, tuple[float, float]],
    adj: Adjacency,
) -> list[MatrixRecord]:
    """Run Dijkstra from every zone origin and build the full OD matrix.

    Parameters
    ----------
    zone_ids:
        Ordered list of all zone IDs (defines row/column order).
    zone_node_ids:
        ``{zoneId: virtual_node_id}`` as returned by ``build_graph``.
    zone_centroids:
        ``{zoneId: (lon, lat)}`` — used only for GeoJSON output (not needed here).
    adj:
        Adjacency dict as returned by ``build_graph``.

    Returns
    -------
    List of :class:`MatrixRecord` — one per OD pair (N² total including diagonal).
    Unreachable pairs have ``travelTime``, ``distance``, and ``resistanceFactor``
    set to ``None``.  Diagonal (same origin and destination) always has zeros.
    """
    _INF = float("inf")
    records: list[MatrixRecord] = []

    for origin_id in zone_ids:
        origin_vnode = zone_node_ids.get(origin_id)
        if origin_vnode is None:
            # Zone has no feedlink — emit null rows for all destinations
            for dest_id in zone_ids:
                if dest_id == origin_id:
                    records.append(_zero_record(origin_id, dest_id))
                else:
                    records.append(_null_record(origin_id, dest_id))
            continue

        time_dict, dist_dict, res_dict = dijkstra_od(adj, origin_vnode)

        for dest_id in zone_ids:
            if dest_id == origin_id:
                records.append(_zero_record(origin_id, dest_id))
                continue

            dest_vnode = zone_node_ids.get(dest_id)
            if dest_vnode is None or dest_vnode not in time_dict:
                records.append(_null_record(origin_id, dest_id))
                continue

            t   = time_dict[dest_vnode]
            d   = dist_dict[dest_vnode]
            res = res_dict[dest_vnode]

            records.append(MatrixRecord(
                fromZoneId=origin_id,
                toZoneId=dest_id,
                travelTime=None if t >= _INF else round(t, 3),
                distance=None if d >= _INF else round(d, 3),
                remainingCap=None if res >= _INF else round(res, 3),
            ))

    logger.info("compute_matrix: %d zone pairs computed", len(records))
    return records


def _zero_record(origin_id: str, dest_id: str) -> MatrixRecord:
    return MatrixRecord(
        fromZoneId=origin_id,
        toZoneId=dest_id,
        travelTime=0.0,
        distance=0.0,
        remainingCap=0.0,
    )


def _null_record(origin_id: str, dest_id: str) -> MatrixRecord:
    return MatrixRecord(
        fromZoneId=origin_id,
        toZoneId=dest_id,
        travelTime=None,
        distance=None,
        remainingCap=None,
    )


# ---------------------------------------------------------------------------
# Output serialisation
# ---------------------------------------------------------------------------

def records_to_csv(records: list[MatrixRecord]) -> str:
    """Serialise matrix records to a CSV string.

    Columns: fromZoneId, toZoneId, travelTime, distance, remainingCap.
    Unreachable pairs have empty cells.
    """
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(list(MATRIX_PROPERTIES))
    for rec in records:
        writer.writerow([
            rec["fromZoneId"],
            rec["toZoneId"],
            "" if rec["travelTime"] is None else rec["travelTime"],
            "" if rec["distance"] is None else rec["distance"],
            "" if rec["remainingCap"] is None else rec["remainingCap"],
        ])
    return buf.getvalue()


# Columns written by enriched_od_to_csv — superset of MATRIX_PROPERTIES plus trips.
ENRICHED_CSV_COLUMNS: tuple[str, ...] = (
    "fromZoneId",
    "toZoneId",
    "trips",
    "travelTime",   # seconds  (float | empty)
    "distance",     # metres   (float | empty)
    "remainingCap", # cars/h   (float | empty)
)


def enriched_od_to_csv(enriched_fc: dict) -> str:
    """Serialise an enriched OD GeoJSON FeatureCollection to CSV.

    Columns: fromZoneId, toZoneId, trips, travelTime, distance, remainingCap.
    Features that have no value for a numeric column produce an empty cell.
    """
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(list(ENRICHED_CSV_COLUMNS))
    for feat in enriched_fc.get("features", []):
        props = feat.get("properties") or {}
        def _cell(key: str) -> object:  # noqa: E306
            v = props.get(key)
            return "" if v is None else v
        writer.writerow([
            _cell("fromZoneId"),
            _cell("toZoneId"),
            _cell("trips"),
            _cell("travelTime"),
            _cell("distance"),
            _cell("remainingCap"),
        ])
    return buf.getvalue()


def records_to_geojson(
    records: list[MatrixRecord],
    zone_centroids: dict[str, tuple[float, float]],
) -> dict:
    """Serialise matrix records to a GeoJSON FeatureCollection.

    Each feature has:
    - ``geometry``: ``LineString([origin_centroid, dest_centroid])``.
      If either centroid is unknown the geometry is ``null``.
    - ``properties``: all five MATRIX_PROPERTIES fields.
    """
    features = []
    for rec in records:
        o_id = rec["fromZoneId"]
        d_id = rec["toZoneId"]

        o_pt = zone_centroids.get(o_id)
        d_pt = zone_centroids.get(d_id)

        if o_pt is not None and d_pt is not None:
            # LineString collapses to a point on the diagonal — still valid GeoJSON
            geometry: dict | None = {
                "type": "LineString",
                "coordinates": [list(o_pt), list(d_pt)],
            }
        else:
            geometry = None

        features.append({
            "type": "Feature",
            "geometry": geometry,
            "properties": {
                "fromZoneId":    o_id,
                "toZoneId":      d_id,
                "travelTime":    rec["travelTime"],
                "distance":      rec["distance"],
                "remainingCap":  rec["remainingCap"],
            },
        })

    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "link_properties": list(MATRIX_PROPERTIES),
        },
    }


# ---------------------------------------------------------------------------
# Zone centroid extraction helper
# ---------------------------------------------------------------------------

def extract_zone_centroids(zones_fc: dict) -> dict[str, tuple[float, float]]:
    """Extract ``{zoneId: (centroidLon, centroidLat)}`` from a zones GeoJSON.

    Falls back to computing the centroid from the feature geometry when
    ``centroidLon`` / ``centroidLat`` properties are absent.
    """
    centroids: dict[str, tuple[float, float]] = {}
    for feat in zones_fc.get("features", []):
        props   = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        if not zone_id:
            continue
        lon = props.get("centroidLon")
        lat = props.get("centroidLat")
        if lon is not None and lat is not None:
            centroids[zone_id] = (float(lon), float(lat))
        else:
            # Fall back to geometry centroid (simple average of coordinates)
            geom = feat.get("geometry") or {}
            coords = _flatten_coords(geom)
            if coords:
                avg_lon = sum(c[0] for c in coords) / len(coords)
                avg_lat = sum(c[1] for c in coords) / len(coords)
                centroids[zone_id] = (avg_lon, avg_lat)
    return centroids


def _flatten_coords(geometry: dict) -> list[tuple[float, float]]:
    """Return a flat list of (lon, lat) pairs from any GeoJSON geometry."""
    gtype = geometry.get("type", "")
    raw   = geometry.get("coordinates")
    if raw is None:
        return []
    if gtype == "Point":
        return [(raw[0], raw[1])]
    if gtype in ("LineString", "MultiPoint"):
        return [(c[0], c[1]) for c in raw]
    if gtype in ("Polygon", "MultiLineString"):
        return [(c[0], c[1]) for ring in raw for c in ring]
    if gtype == "MultiPolygon":
        return [(c[0], c[1]) for poly in raw for ring in poly for c in ring]
    return []


# ---------------------------------------------------------------------------
# Convenience: extract ordered zone_ids from a zones FeatureCollection
# ---------------------------------------------------------------------------

def extract_zone_ids(zones_fc: dict) -> list[str]:
    """Return ordered list of zoneId strings from a zones GeoJSON."""
    ids: list[str] = []
    seen: set[str] = set()
    for feat in zones_fc.get("features", []):
        props   = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        if zone_id and zone_id not in seen:
            ids.append(zone_id)
            seen.add(zone_id)
    return ids


# ---------------------------------------------------------------------------
# OD enrichment
# ---------------------------------------------------------------------------

def enrich_od_geojson(
    od_fc: dict,
    network_fc: dict,
    feedlinks_fc: dict,
) -> dict:
    """Enrich an existing OD GeoJSON with a ``remainingCap`` property.

    Builds the Dijkstra graph from *network_fc* and *feedlinks_fc*, runs
    Dijkstra from every zone origin, and annotates each OD feature in *od_fc*
    with the bottleneck minimum remaining road capacity along the time-optimal
    path between its origin and destination zones.

    Features whose ``(fromZoneId, toZoneId)`` pair cannot be routed (no
    feedlink or unreachable) receive ``remainingCap: null``.

    Parameters
    ----------
    od_fc:
        Completed OD GeoJSON FeatureCollection (output of ``od_matrix_completer``).
        Each feature must have ``fromZoneId`` and ``toZoneId`` properties.
    network_fc:
        Network GeoJSON (output of ``network_intersector`` / ``flow_scaler``).
    feedlinks_fc:
        Feedlinks GeoJSON (output of ``feedlink_creator``).

    Returns
    -------
    Enriched GeoJSON FeatureCollection — a shallow copy of *od_fc* with
    ``remainingCap`` added to each feature's properties.  The top-level
    ``properties`` dict is updated to include ``remainingCap`` in
    ``link_properties`` (if that key exists).
    """
    adj, zone_node_ids, _ = build_graph(network_fc, feedlinks_fc)

    # Collect all unique origin zone IDs from OD features
    origin_ids: set[str] = set()
    for feat in od_fc.get("features", []):
        props = feat.get("properties") or {}
        f_id = str(props.get("fromZoneId") or "").strip()
        if f_id:
            origin_ids.add(f_id)

    # Run Dijkstra from each origin zone and build lookup res_cap[(from, to)]
    _INF = float("inf")
    res_cap: dict[tuple[str, str], float | None] = {}

    for origin_id in origin_ids:
        origin_vnode = zone_node_ids.get(origin_id)
        if origin_vnode is None:
            continue
        _, _, res_dict = dijkstra_od(adj, origin_vnode)

        for dest_id, dest_vnode in zone_node_ids.items():
            if dest_id == origin_id:
                res_cap[(origin_id, dest_id)] = 0.0
                continue
            res = res_dict.get(dest_vnode)
            if res is None or res >= _INF:
                res_cap[(origin_id, dest_id)] = None
            else:
                res_cap[(origin_id, dest_id)] = round(res, 3)

    logger.info(
        "enrich_od_geojson: %d origins processed, %d res_cap entries",
        len(origin_ids),
        len(res_cap),
    )

    # Enrich features
    enriched_features: list[dict] = []
    for feat in od_fc.get("features", []):
        props = (feat.get("properties") or {}).copy()
        f_id = str(props.get("fromZoneId") or "").strip()
        t_id = str(props.get("toZoneId") or "").strip()
        if f_id == t_id:
            props["remainingCap"] = 0.0
        else:
            props["remainingCap"] = res_cap.get((f_id, t_id))
        enriched_features.append({
            "type": "Feature",
            "geometry": feat.get("geometry"),
            "properties": props,
        })

    # Update top-level properties
    fc_props = (od_fc.get("properties") or {}).copy()
    lp = fc_props.get("link_properties")
    if isinstance(lp, list) and "remainingCap" not in lp:
        fc_props["link_properties"] = lp + ["remainingCap"]

    return {
        "type": "FeatureCollection",
        "features": enriched_features,
        "properties": fc_props,
    }
