"""Pure-Python od_support_matrices_creator core — no I/O, no boto3, no external deps.

Computes a full OD travel-time / distance / resistance matrix between all zones
in a network, routing through feedlinks and network links using Dijkstra.

Public API
----------
build_graph(network_fc, feedlinks_fc)
    -> tuple[adj, zone_node_ids, zone_centroids]
    Builds the directed weighted adjacency used by dijkstra_od.

compute_zone_headings(network_fc, feedlinks_fc)
    -> dict[str, float]
    Returns the compass heading (0–360°) of the outgoing network link at each
    zone's attachment node.  Used for U-turn / anti-parallel pair filtering.

compute_zone_reverse_pairs(network_fc, feedlinks_fc)
    -> set[frozenset[str]]
    Returns the set of (zone_id_A, zone_id_B) pairs whose attachment links are
    each other's physical reverse-direction counterparts (via reverseLinkIds).
    Routing between such a pair is equivalent to a U-turn.

compute_matrix(zone_ids, zone_node_ids, zone_centroids, adj)
    -> list[MatrixRecord]
    Runs Dijkstra from every zone origin and returns one record per OD pair.

enrich_od_geojson(od_fc, network_fc, feedlinks_fc) -> dict
    Adds a ``remainingCap`` property (bottleneck min remaining capacity along
    the time-optimal path) to every feature in an existing OD GeoJSON.
    Returns a new GeoJSON FeatureCollection with the enriched features.

enriched_od_to_csv(enriched_fc) -> str
    Serialises an enriched OD GeoJSON FeatureCollection to CSV text.
    Columns: fromZoneId, toZoneId, trips, travelTime, distance, remainingCap.

records_to_csv(records) -> str
    Serialises records to CSV text.

records_to_geojson(records, zone_centroids) -> dict
    Serialises records to a GeoJSON FeatureCollection (one feature per OD pair).
"""

from __future__ import annotations

import csv
import io
import logging
import math
from typing import TypedDict

from shared.graph_utils import dijkstra_od

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Prefix for virtual zone centroid nodes in the graph so they never collide
# with real network node IDs (which are plain integer strings).
_ZONE_PREFIX = "Z_"

# Maximum v/c ratio used in the BPR cost function.  Capping at 2.0 prevents
# all-or-nothing over-concentration from making bottleneck links (bridges,
# tunnels) unreachable in the D2 BPR re-routing step.
_BPR_VC_CAP: float = 2.0


# Fallback feedlink speed when no connected network link can be found.
_FALLBACK_SPEED_KMH: float = 50.0

# ---------------------------------------------------------------------------
# Output field names (authoritative — keep in sync with openapi.yaml)
# ---------------------------------------------------------------------------

MATRIX_PROPERTIES: tuple[str, ...] = (
    "fromZoneId",
    "toZoneId",
    "travelTime",  # seconds  (float | None)
    "distance",  # metres   (float | None)
    "remainingCap",  # cars/h   (float | None) — bottleneck min remaining capacity
)

# ---------------------------------------------------------------------------
# Internal types
# ---------------------------------------------------------------------------

Adjacency = dict[str, list[tuple[str, float, float, float, float]]]
# {node_id: [(neighbour_id, time_s, dist_m, remaining_cap), ...]}


class MatrixRecord(TypedDict):
    fromZoneId: str
    toZoneId: str
    travelTime: float | None
    distance: float | None
    remainingCap: float | None


# ---------------------------------------------------------------------------
# Graph construction
# ---------------------------------------------------------------------------


def build_graph(
    network_fc: dict,
    feedlinks_fc: dict,
    *,
    signal_base_delay_s: float = 0.0,
) -> tuple[Adjacency, dict[str, str], dict[str, tuple[float, float]]]:
    """Build a directed weighted graph from a network and feedlinks GeoJSON.

    Edge weights are BPR-adjusted travel times:

        t_bpr = t0 × (1 + 0.15 × (flow / capacity)⁴)

    where ``t0`` is the free-flow travel time derived from ``speed`` and
    ``length``, and ``flow`` is the current hourly volume on the link.
    Links with ``capacity = 0`` or ``speed = 0`` are treated as closed
    (``time_s = inf``), making them unroutable for Dijkstra.

    When *signal_base_delay_s* > 0 and a link has ``trafficSignal=True`` in
    its properties, an intersection delay is added on top of the BPR time:

        signal_delay = signal_base_delay_s / (1 − min(v/c, 0.95))

    This is a Webster-style cycle-delay term: it grows as the intersection
    approaches saturation.  A default of ``0.0`` disables the term entirely
    so that callers that do not set it are unaffected.

    Parameters
    ----------
    network_fc:
        GeoJSON FeatureCollection produced by ``network_intersector`` /
        ``flow_scaler``.  Must be the plain network (no feedlinks).  Each
        feature must have properties: ``fromNode``, ``toNode``, ``speed``
        (km/h), ``length`` (m), ``capacity`` (cars/h), ``flow`` (cars/h,
        current hourly volume), ``flowsPerDaypart``
        (dict of cars/h per period).
    feedlinks_fc:
        GeoJSON FeatureCollection produced by ``feedlink_creator``.
        Each feature must have properties:
        ``zoneId``, ``fromNode``, ``toNode``, ``length`` (m), ``capacity``
        (cars/h).  Direction (production vs attraction) is inferred
        automatically: the end that is present in the real network graph is
        the network attachment node; the other end is the zone centroid.
    signal_base_delay_s:
        Base intersection delay in seconds used in the Webster formula.
        ``0.0`` (default) disables signal delays entirely.

    Returns
    -------
    adj:
        Adjacency dict ``{node: [(neighbour, time_s, dist_m, remaining_cap)]}``.
    zone_node_ids:
        ``{zoneId: virtual_node_id}`` mapping each zone to its centroid node.
    zone_centroids:
        ``{zoneId: (lon, lat)}`` — populated from the feedlink zoneId values;
        callers must enrich this from the zone file.
    """
    adj: Adjacency = {}

    # ------------------------------------------------------------------
    # Pass 1 — build per-node max-speed lookup from network links
    # (used to infer feedlink travel time at the network attachment node)
    # ------------------------------------------------------------------
    node_max_speed: dict[str, float] = {}

    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        from_n = str(props.get("fromNode", ""))
        to_n = str(props.get("toNode", ""))
        speed = float(props.get("speed") or 0.0)
        for nid in (from_n, to_n):
            if not nid:
                continue
            if speed > node_max_speed.get(nid, 0.0):
                node_max_speed[nid] = speed

    # ------------------------------------------------------------------
    # Pass 2 — add network link edges
    # ------------------------------------------------------------------
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        from_n = str(props.get("fromNode", ""))
        to_n = str(props.get("toNode", ""))
        if not from_n or not to_n:
            continue

        speed_kmh = float(props.get("speed") or 0.0)
        length_m = float(props.get("length") or 0.0)
        capacity = float(props.get("capacity") or 0.0)
        flow = float(props.get("flow") or 0.0)

        # Determine effective hourly flow for both BPR congestion and remaining
        # capacity.  Primary: max(flowsPerDaypart).  Fallback: flow24hrs / 12
        # when daypart flows are absent but a 24-hour total is available.
        daypart_flows = props.get("flowsPerDaypart")
        if daypart_flows and isinstance(daypart_flows, dict):
            peak_flow = max(
                (float(v) for v in daypart_flows.values() if v is not None), default=0.0
            )
        else:
            peak_flow = 0.0

        flow_for_cap = peak_flow
        if flow_for_cap == 0.0:
            flow24 = float(props.get("flow24hrs") or 0.0)
            if flow24 > 0.0:
                flow_for_cap = flow24 / 12.0

        remaining_cap = max(capacity - flow_for_cap, 0.0)

        # BPR travel time: t_bpr = t0 × (1 + 0.15 × (v/c)⁴)
        #
        # A link is only truly closed (time = ∞) when its free-flow speed is
        # zero or missing — i.e. it is physically impassable.
        #
        # Saturated links (remaining_cap == 0, flow > capacity) are NOT closed.
        # All-or-nothing assignment in D1 concentrates all traffic on the
        # shortest paths, easily pushing flow >> capacity on bottleneck links
        # such as bridges or tunnels.  Treating those links as closed in D2
        # causes Dijkstra to route around them even when they are the only
        # realistic crossing — producing routes that bear no resemblance to
        # reality.  Instead we cap v/c at 2.0, giving a maximum BPR penalty
        # of t0 × (1 + 0.15 × 2⁴) = t0 × 3.4.  The link becomes expensive
        # but always remains reachable.
        #
        # capacity == 0 means the link is explicitly closed (e.g. by an
        # adjust afsluiting).  Treat it as impassable regardless of speed.
        # The previous assumption that speed_kmh would also be 0 for OSM
        # links with capacity=0 does not hold for Spectrum network data.
        if speed_kmh <= 0.0 or capacity <= 0.0:
            time_s = float("inf")
        else:
            t0 = length_m / (speed_kmh / 3.6)
            v_over_c = min(flow_for_cap / capacity, _BPR_VC_CAP)
            time_s = t0 * (1.0 + 0.15 * v_over_c**4)
            # Webster-style intersection delay for signalised links.
            if signal_base_delay_s > 0.0 and props.get("trafficSignal"):
                # Cap v/c at 0.95 to avoid division-by-zero at saturation.
                _vc_sig = min(flow_for_cap / capacity, 0.95)
                time_s += signal_base_delay_s / (1.0 - _vc_sig)

        adj.setdefault(from_n, []).append((to_n, time_s, length_m, remaining_cap, capacity))

    # ------------------------------------------------------------------
    # Pass 3 — add feedlink edges (zone centroid <-> network node)
    # ------------------------------------------------------------------
    zone_node_ids: dict[str, str] = {}
    zone_centroids: dict[str, tuple[float, float]] = {}

    for feat in feedlinks_fc.get("features", []):
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        from_node = str(props.get("fromNode") or "")
        to_node = str(props.get("toNode") or "")
        dist_m = float(props.get("length") or 0.0)
        capacity = float(props.get("capacity") or 0.0)

        if not zone_id or not from_node or not to_node:
            continue

        # Infer direction from which end is a real network node.
        # node_max_speed is populated in Pass 1 from actual network links.
        to_is_net = to_node in node_max_speed
        from_is_net = from_node in node_max_speed

        if to_is_net and not from_is_net:
            # Production feedlink: fromNode = zone centroid, toNode = network node
            network_node = to_node
            is_production = True
            is_attraction = False
        elif from_is_net and not to_is_net:
            # Attraction feedlink: fromNode = network node, toNode = zone centroid
            network_node = from_node
            is_production = False
            is_attraction = True
        else:
            # Ambiguous (both or neither in network) — treat as both
            network_node = to_node
            is_production = True
            is_attraction = True

        # Virtual centroid node for this zone
        vnode = f"{_ZONE_PREFIX}{zone_id}"
        zone_node_ids[zone_id] = vnode

        # Speed at the network endpoint
        speed_at_node = node_max_speed.get(network_node, _FALLBACK_SPEED_KMH)
        if speed_at_node <= 0.0:
            speed_at_node = _FALLBACK_SPEED_KMH
        feedlink_time_s = dist_m / (speed_at_node / 3.6) if dist_m > 0.0 else 0.0

        if is_production:
            # zone centroid -> network node  (outgoing trip)
            adj.setdefault(vnode, []).append(
                (network_node, feedlink_time_s, dist_m, capacity, capacity)
            )
        if is_attraction:
            # network node -> zone centroid  (incoming trip)
            adj.setdefault(network_node, []).append(
                (vnode, feedlink_time_s, dist_m, capacity, capacity)
            )

    logger.info(
        "build_graph: %d network nodes, %d zone nodes, %d adj entries",
        len(node_max_speed),
        len(zone_node_ids),
        sum(len(v) for v in adj.values()),
    )
    return adj, zone_node_ids, zone_centroids


# ---------------------------------------------------------------------------
# Zone heading lookup
# ---------------------------------------------------------------------------


def compute_zone_headings(
    network_fc: dict,
    feedlinks_fc: dict,
) -> dict[str, float]:
    """Return the compass heading for each zone's boundary road crossing.

    For each zone the heading is taken from the *first* outgoing network link
    at the zone's attachment node (i.e. the network node the feedlink connects
    to).  The heading value (0–360°, 0 = North, 90 = East) comes from the
    ``heading`` property that ``bidirectional_splitter`` sets on every directed
    link.

    This is used by matrix_builder and route_explorer to filter out implausible
    U-turn routes: a pair of BOUNDARY zones that are close together and whose
    road headings are nearly anti-parallel (e.g. entering eastbound, exiting
    westbound) is unlikely to carry real through-traffic.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection — same object passed to
        :func:`build_graph`.
    feedlinks_fc:
        Feedlinks GeoJSON FeatureCollection — same object passed to
        :func:`build_graph`.

    Returns
    -------
    dict[str, float]
        ``{zoneId: heading_deg}`` for every zone whose attachment node has at
        least one outgoing link with a ``heading`` property.  Zones without a
        resolvable heading are absent from the dict.
    """
    # Pass 1 — collect the heading of the first outgoing link per network node.
    node_out_heading: dict[str, float] = {}
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        from_n = str(props.get("fromNode", ""))
        heading = props.get("heading")
        if from_n and heading is not None and from_n not in node_out_heading:
            node_out_heading[from_n] = float(heading)

    # Pass 2 — for each feedlink, identify the network attachment node and look
    # up its outgoing heading.  We detect the network side by checking which end
    # of the feedlink appears as a fromNode in the real network.
    zone_headings: dict[str, float] = {}
    for feat in feedlinks_fc.get("features", []):
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        if not zone_id or zone_id in zone_headings:
            continue
        from_n = str(props.get("fromNode") or "")
        to_n = str(props.get("toNode") or "")
        # Prefer the end that appears in node_out_heading (a real network node).
        if from_n in node_out_heading:
            network_node = from_n
        elif to_n in node_out_heading:
            network_node = to_n
        else:
            continue
        zone_headings[zone_id] = node_out_heading[network_node]

    return zone_headings


def compute_zone_reverse_pairs(
    network_fc: dict,
    feedlinks_fc: dict,
) -> set[frozenset]:
    """Return zone ID pairs that are physically anti-parallel boundary crossings.

    Two zones form a *reverse pair* when the outgoing network links at their
    respective attachment nodes are each other's opposite-direction counterparts
    as recorded in the ``reverseLinkIds`` property (set by
    ``bidirectional_splitter`` and supplemented by ``parallel_link_finder``).
    Routing from zone A to zone B in such a pair is equivalent to a U-turn: the
    vehicle enters the bounding box on one direction of a road and immediately
    exits on the physically parallel reverse road — implausible for real
    through-traffic.

    The returned set contains ``frozenset({zone_id_a, zone_id_b})`` elements so
    membership testing is order-independent:
    ``frozenset({a, b}) in result`` works regardless of routing direction.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection.  Links must have ``fromNode``,
        ``toNode``, ``linkId`` (int), and optionally ``reverseLinkIds``
        (list[int]).
    feedlinks_fc:
        Feedlinks GeoJSON FeatureCollection.  Used to map zone IDs to their
        network attachment nodes.

    Returns
    -------
    set of frozenset
        Each element is a two-element ``frozenset`` of zone ID strings.
    """
    # Pass 1 — for each network node: collect (linkId, reverseLinkIds) tuples
    # of all outgoing links, and build a linkId → edge lookup.
    node_link_info: dict[str, list[tuple[int, list[int]]]] = {}
    link_id_to_node: dict[int, str] = {}  # linkId -> fromNode (to detect which zones share it)
    seen_nodes: set[str] = set()

    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        from_n = str(props.get("fromNode", ""))
        to_n = str(props.get("toNode", ""))
        link_id = props.get("linkId")
        if not from_n or not to_n:
            continue
        seen_nodes.add(from_n)
        if link_id is None:
            continue
        try:
            link_id_key = int(link_id)
        except TypeError, ValueError:
            link_id_key = str(link_id)
        link_id_to_node[link_id_key] = from_n
        rev_ids_raw = props.get("reverseLinkIds") or []
        rev_ids: list = []
        for x in rev_ids_raw:
            try:
                rev_ids.append(int(x))
            except TypeError, ValueError:
                rev_ids.append(str(x))
        node_link_info.setdefault(from_n, []).append((link_id_key, rev_ids))

    # Pass 2 — for each zone, find the attachment network node and derive:
    #   zone_link_ids : the linkIds of outgoing links at that node
    #   zone_rev_ids  : all reverseLinkIds referenced by those links
    zone_link_ids: dict[str, frozenset[int]] = {}
    zone_rev_ids: dict[str, frozenset[int]] = {}

    for feat in feedlinks_fc.get("features", []):
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        if not zone_id or zone_id in zone_link_ids:
            continue
        from_n = str(props.get("fromNode") or "")
        to_n = str(props.get("toNode") or "")
        # The network attachment node is whichever end is a real network node.
        if from_n in seen_nodes:
            network_node = from_n
        elif to_n in seen_nodes:
            network_node = to_n
        else:
            continue
        infos = node_link_info.get(network_node, [])
        zone_link_ids[zone_id] = frozenset(lid for lid, _ in infos)
        zone_rev_ids[zone_id] = frozenset(rid for _, rids in infos for rid in rids)

    # Pass 3 — build an inverse index: linkId -> list of zones that have it.
    # Then, for each zone's reverse IDs, find all zones that own those link IDs.
    link_to_zones: dict[int, list[str]] = {}
    for zid, lids in zone_link_ids.items():
        for lid in lids:
            link_to_zones.setdefault(lid, []).append(zid)

    reverse_pairs: set[frozenset] = set()
    for zone_a, rev_ids in zone_rev_ids.items():
        for rev_id in rev_ids:
            for zone_b in link_to_zones.get(rev_id, []):
                if zone_b != zone_a:
                    reverse_pairs.add(frozenset({zone_a, zone_b}))

    return reverse_pairs


# ---------------------------------------------------------------------------
# Matrix computation
# ---------------------------------------------------------------------------


def compute_matrix(
    zone_ids: list[str],
    zone_node_ids: dict[str, str],
    zone_centroids: dict[str, tuple[float, float]],
    adj: Adjacency,
) -> list[MatrixRecord]:
    """Run Dijkstra from every zone origin and build the full OD matrix.

    Parameters
    ----------
    zone_ids:
        Ordered list of all zone IDs (defines row/column order).
    zone_node_ids:
        ``{zoneId: virtual_node_id}`` as returned by ``build_graph``.
    zone_centroids:
        ``{zoneId: (lon, lat)}`` — used only for GeoJSON output (not needed here).
    adj:
        Adjacency dict as returned by ``build_graph``.

    Returns
    -------
    List of :class:`MatrixRecord` — one per OD pair (N² total including diagonal).
    Unreachable pairs have ``travelTime``, ``distance``, and ``resistanceFactor``
    set to ``None``.  Diagonal (same origin and destination) always has zeros.
    """
    _INF = float("inf")
    records: list[MatrixRecord] = []

    for origin_id in zone_ids:
        origin_vnode = zone_node_ids.get(origin_id)
        if origin_vnode is None:
            # Zone has no feedlink — emit null rows for all destinations
            for dest_id in zone_ids:
                if dest_id == origin_id:
                    records.append(_zero_record(origin_id, dest_id))
                else:
                    records.append(_null_record(origin_id, dest_id))
            continue

        time_dict, dist_dict, res_dict = dijkstra_od(adj, origin_vnode)

        for dest_id in zone_ids:
            if dest_id == origin_id:
                records.append(_zero_record(origin_id, dest_id))
                continue

            dest_vnode = zone_node_ids.get(dest_id)
            if dest_vnode is None or dest_vnode not in time_dict:
                records.append(_null_record(origin_id, dest_id))
                continue

            t = time_dict[dest_vnode]
            d = dist_dict[dest_vnode]
            res = res_dict[dest_vnode]

            records.append(
                MatrixRecord(
                    fromZoneId=origin_id,
                    toZoneId=dest_id,
                    travelTime=None if t >= _INF else round(t, 3),
                    distance=None if d >= _INF else round(d, 3),
                    remainingCap=None if res >= _INF else round(res, 3),
                )
            )

    logger.info("compute_matrix: %d zone pairs computed", len(records))
    return records


def _zero_record(origin_id: str, dest_id: str) -> MatrixRecord:
    return MatrixRecord(
        fromZoneId=origin_id,
        toZoneId=dest_id,
        travelTime=0.0,
        distance=0.0,
        remainingCap=0.0,
    )


def _null_record(origin_id: str, dest_id: str) -> MatrixRecord:
    return MatrixRecord(
        fromZoneId=origin_id,
        toZoneId=dest_id,
        travelTime=None,
        distance=None,
        remainingCap=None,
    )


# ---------------------------------------------------------------------------
# Output serialisation
# ---------------------------------------------------------------------------


def records_to_csv(records: list[MatrixRecord]) -> str:
    """Serialise matrix records to a CSV string.

    Columns: fromZoneId, toZoneId, travelTime, distance, remainingCap.
    Unreachable pairs have empty cells.
    """
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(list(MATRIX_PROPERTIES))
    for rec in records:
        writer.writerow(
            [
                rec["fromZoneId"],
                rec["toZoneId"],
                "" if rec["travelTime"] is None else rec["travelTime"],
                "" if rec["distance"] is None else rec["distance"],
                "" if rec["remainingCap"] is None else rec["remainingCap"],
            ]
        )
    return buf.getvalue()


# Columns written by enriched_od_to_csv — superset of MATRIX_PROPERTIES plus trips.
ENRICHED_CSV_COLUMNS: tuple[str, ...] = (
    "fromZoneId",
    "toZoneId",
    "trips",
    "travelTime",  # seconds  (float | empty)
    "distance",  # metres   (float | empty)
    "remainingCap",  # cars/h   (float | empty)
)


def enriched_od_to_csv(enriched_fc: dict) -> str:
    """Serialise an enriched OD GeoJSON FeatureCollection to CSV.

    Columns: fromZoneId, toZoneId, trips, travelTime, distance, remainingCap.
    Features that have no value for a numeric column produce an empty cell.
    """
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(list(ENRICHED_CSV_COLUMNS))
    for feat in enriched_fc.get("features", []):
        props = feat.get("properties") or {}

        def _cell(key: str) -> object:  # noqa: E306
            v = props.get(key)
            return "" if v is None else v

        writer.writerow(
            [
                _cell("fromZoneId"),
                _cell("toZoneId"),
                _cell("trips"),
                _cell("travelTime"),
                _cell("distance"),
                _cell("remainingCap"),
            ]
        )
    return buf.getvalue()


def records_to_geojson(
    records: list[MatrixRecord],
    zone_centroids: dict[str, tuple[float, float]],
) -> dict:
    """Serialise matrix records to a GeoJSON FeatureCollection.

    Each feature has:
    - ``geometry``: ``LineString([origin_centroid, dest_centroid])``.
      If either centroid is unknown the geometry is ``null``.
    - ``properties``: all five MATRIX_PROPERTIES fields.
    """
    features = []
    for rec in records:
        o_id = rec["fromZoneId"]
        d_id = rec["toZoneId"]

        o_pt = zone_centroids.get(o_id)
        d_pt = zone_centroids.get(d_id)

        if o_pt is not None and d_pt is not None:
            # LineString collapses to a point on the diagonal — still valid GeoJSON
            geometry: dict | None = {
                "type": "LineString",
                "coordinates": [list(o_pt), list(d_pt)],
            }
        else:
            geometry = None

        features.append(
            {
                "type": "Feature",
                "geometry": geometry,
                "properties": {
                    "fromZoneId": o_id,
                    "toZoneId": d_id,
                    "travelTime": rec["travelTime"],
                    "distance": rec["distance"],
                    "remainingCap": rec["remainingCap"],
                },
            }
        )

    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "fields": list(MATRIX_PROPERTIES),
        },
    }


# ---------------------------------------------------------------------------
# Zone centroid extraction helper
# ---------------------------------------------------------------------------


def extract_zone_centroids(zones_fc: dict) -> dict[str, tuple[float, float]]:
    """Extract ``{zoneId: (centroidLon, centroidLat)}`` from a zones GeoJSON.

    Falls back to computing the centroid from the feature geometry when
    ``centroidLon`` / ``centroidLat`` properties are absent.
    """
    centroids: dict[str, tuple[float, float]] = {}
    for feat in zones_fc.get("features", []):
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        if not zone_id:
            continue
        lon = props.get("centroidLon")
        lat = props.get("centroidLat")
        if lon is not None and lat is not None:
            centroids[zone_id] = (float(lon), float(lat))
        else:
            # Fall back to geometry centroid (simple average of coordinates)
            geom = feat.get("geometry") or {}
            coords = _flatten_coords(geom)
            if coords:
                avg_lon = sum(c[0] for c in coords) / len(coords)
                avg_lat = sum(c[1] for c in coords) / len(coords)
                centroids[zone_id] = (avg_lon, avg_lat)
    return centroids


def _flatten_coords(geometry: dict) -> list[tuple[float, float]]:
    """Return a flat list of (lon, lat) pairs from any GeoJSON geometry."""
    gtype = geometry.get("type", "")
    raw = geometry.get("coordinates")
    if raw is None:
        return []
    if gtype == "Point":
        return [(raw[0], raw[1])]
    if gtype in ("LineString", "MultiPoint"):
        return [(c[0], c[1]) for c in raw]
    if gtype in ("Polygon", "MultiLineString"):
        return [(c[0], c[1]) for ring in raw for c in ring]
    if gtype == "MultiPolygon":
        return [(c[0], c[1]) for poly in raw for ring in poly for c in ring]
    return []


# ---------------------------------------------------------------------------
# Convenience: extract ordered zone_ids from a zones FeatureCollection
# ---------------------------------------------------------------------------


def extract_zone_ids(zones_fc: dict) -> list[str]:
    """Return ordered list of zoneId strings from a zones GeoJSON."""
    ids: list[str] = []
    seen: set[str] = set()
    for feat in zones_fc.get("features", []):
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        if zone_id and zone_id not in seen:
            ids.append(zone_id)
            seen.add(zone_id)
    return ids


# ---------------------------------------------------------------------------
# OD enrichment
# ---------------------------------------------------------------------------


def enrich_od_geojson(
    od_fc: dict,
    network_fc: dict,
    feedlinks_fc: dict,
) -> dict:
    """Enrich an existing OD GeoJSON with a ``remainingCap`` property.

    Builds the Dijkstra graph from *network_fc* and *feedlinks_fc*, runs
    Dijkstra from every zone origin, and annotates each OD feature in *od_fc*
    with the bottleneck minimum remaining road capacity along the time-optimal
    path between its origin and destination zones.

    Features whose ``(fromZoneId, toZoneId)`` pair cannot be routed (no
    feedlink or unreachable) receive ``remainingCap: null``.

    Parameters
    ----------
    od_fc:
        Completed OD GeoJSON FeatureCollection (output of ``od_matrix_completer``).
        Each feature must have ``fromZoneId`` and ``toZoneId`` properties.
    network_fc:
        Network GeoJSON (output of ``network_intersector`` / ``flow_scaler``).
    feedlinks_fc:
        Feedlinks GeoJSON (output of ``feedlink_creator``).

    Returns
    -------
    Enriched GeoJSON FeatureCollection — a shallow copy of *od_fc* with
    ``remainingCap`` added to each feature's properties.  The top-level
    ``properties`` dict is updated to include ``remainingCap`` in
    ``fields`` (if that key exists).
    """
    adj, zone_node_ids, _ = build_graph(network_fc, feedlinks_fc)

    # Collect all unique origin zone IDs from OD features
    origin_ids: set[str] = set()
    for feat in od_fc.get("features", []):
        props = feat.get("properties") or {}
        f_id = str(props.get("fromZoneId") or "").strip()
        if f_id:
            origin_ids.add(f_id)

    # Run Dijkstra from each origin zone and build lookup res_cap[(from, to)]
    _INF = float("inf")
    res_cap: dict[tuple[str, str], float | None] = {}

    for origin_id in origin_ids:
        origin_vnode = zone_node_ids.get(origin_id)
        if origin_vnode is None:
            continue
        _, _, res_dict = dijkstra_od(adj, origin_vnode)

        for dest_id, dest_vnode in zone_node_ids.items():
            if dest_id == origin_id:
                res_cap[(origin_id, dest_id)] = 0.0
                continue
            res = res_dict.get(dest_vnode)
            if res is None or res >= _INF:
                res_cap[(origin_id, dest_id)] = None
            else:
                res_cap[(origin_id, dest_id)] = round(res, 3)

    logger.info(
        "enrich_od_geojson: %d origins processed, %d res_cap entries",
        len(origin_ids),
        len(res_cap),
    )

    # Enrich features
    enriched_features: list[dict] = []
    for feat in od_fc.get("features", []):
        props = (feat.get("properties") or {}).copy()
        f_id = str(props.get("fromZoneId") or "").strip()
        t_id = str(props.get("toZoneId") or "").strip()
        if f_id == t_id:
            props["remainingCap"] = 0.0
        else:
            props["remainingCap"] = res_cap.get((f_id, t_id))
        enriched_features.append(
            {
                "type": "Feature",
                "geometry": feat.get("geometry"),
                "properties": props,
            }
        )

    # Update top-level properties
    fc_props = (od_fc.get("properties") or {}).copy()
    lp = fc_props.get("fields")
    if isinstance(lp, list) and "remainingCap" not in lp:
        fc_props["fields"] = lp + ["remainingCap"]

    return {
        "type": "FeatureCollection",
        "features": enriched_features,
        "properties": fc_props,
    }
