"""Shared displacement / geometry helpers for GMT network modules.

Provides the canonical implementations of:
  - heading           — compass bearing from first to last coord
  - offset_linestring — lateral right-hand offset with node-taper and densification
  - assign_reverse_link_ids — second-pass pairing of opposite directed links

These are used by both *network_intersector* and *network_link_inserter*
(and any future module that creates or modifies directed network geometry).

All functions use a flat-earth WGS-84 approximation that is accurate to
well under 1 cm for the distances involved in the Netherlands.
"""

from __future__ import annotations

import math

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_OFFSET_M_CAR         = 2.0    # metres — CAR half-road offset per direction from centreline
_MEDIAN_HALF_M        = 0.25   # metres — half median strip (50 cm total); only bidirectional roads
_OFFSET_M_BIKE_EXTRA  = 1.5    # metres — bike lane beyond the car edge (fietspad outside autorijbaan)
_OFFSET_M_FOOT_EXTRA  = 1.0    # metres — footway beyond the bike lane (voetpad outside fietspad)
_NEAR_NODE_M          = 3.0    # transition distance (m) for links >= 10 m
_NEAR_NODE_M_MED      = 1.0    # transition distance (m) for links  3 m – 10 m
_NEAR_NODE_M_SHT      = 0.5    # transition distance (m) for links  < 3 m
_DENSIFY_M            = 5.0    # max sub-segment length (m) used before offsetting
_OPPOSITE_SEARCH_M    = 25.0   # max midpoint-to-midpoint distance to consider as opposite
_OPPOSITE_HEADING_TOL = 30.0   # ± degrees around 180° that counts as "opposite heading"


# ---------------------------------------------------------------------------
# heading
# ---------------------------------------------------------------------------

def heading(coords: list) -> float:
    """Compass bearing 0–360° (0 = N, 90 = E) from first to last coord of a LineString.

    Uses a flat-earth approximation valid for the Netherlands.
    """
    lon0, lat0 = coords[0][0], coords[0][1]
    lon1, lat1 = coords[-1][0], coords[-1][1]
    lat_mid_r  = math.radians((lat0 + lat1) / 2)
    dx = (lon1 - lon0) * math.cos(lat_mid_r)   # east component
    dy =  lat1 - lat0                           # north component
    return round(math.degrees(math.atan2(dx, dy)) % 360, 1)


# ---------------------------------------------------------------------------
# _densify (internal helper, but exposed for testing and JS parity)
# ---------------------------------------------------------------------------

def _densify(coords: list, max_seg_m: float) -> list:
    """Insert intermediate points so no segment exceeds *max_seg_m* metres.

    Uses the same flat-earth approximation as offset_linestring.
    """
    if len(coords) < 2:
        return [c[:2] for c in coords]
    lat0  = sum(c[1] for c in coords) / len(coords)
    d_lat = 111_320.0
    d_lon = 111_320.0 * math.cos(math.radians(lat0))
    out   = [coords[0][:2]]
    for i in range(len(coords) - 1):
        lng0, lat0_ = coords[i][0], coords[i][1]
        lng1, lat1_ = coords[i + 1][0], coords[i + 1][1]
        seg_len = math.hypot((lng1 - lng0) * d_lon, (lat1_ - lat0_) * d_lat)
        n_sub   = max(1, math.ceil(seg_len / max_seg_m))
        for j in range(1, n_sub + 1):
            t = j / n_sub
            out.append([lng0 + t * (lng1 - lng0), lat0_ + t * (lat1_ - lat0_)])
    return out


# ---------------------------------------------------------------------------
# offset_linestring
# ---------------------------------------------------------------------------

def offset_linestring(coords: list, offset_m: float) -> list:
    """Offset a LineString by *offset_m* metres to the right of the travel direction.

    The geometry is first densified to *_DENSIFY_M*-metre sub-segments so that
    the lateral offset is smooth even on long straight links.  End-caps taper
    back to the original (unshifted) start and end nodes so that links visually
    converge at intersections.

    Uses a flat-earth WGS-84 approximation; accurate enough for a 2-metre offset
    anywhere in the Netherlands.
    """
    if len(coords) < 2:
        return [c[:2] for c in coords]

    coords = _densify(coords, _DENSIFY_M)

    lat0  = sum(c[1] for c in coords) / len(coords)
    d_lat = 111_320.0
    d_lon = 111_320.0 * math.cos(math.radians(lat0))

    mx = [c[0] * d_lon for c in coords]
    my = [c[1] * d_lat for c in coords]
    n  = len(mx)

    total_len = sum(math.hypot(mx[i + 1] - mx[i], my[i + 1] - my[i]) for i in range(n - 1))
    if total_len >= 10.0:
        near_m = _NEAR_NODE_M
    elif total_len >= 3.0:
        near_m = _NEAR_NODE_M_MED
    else:
        near_m = _NEAR_NODE_M_SHT

    out = []

    out.append(list(coords[0][:2]))

    first_len = math.hypot(mx[1] - mx[0], my[1] - my[0])
    if first_len > near_m:
        udx = (mx[1] - mx[0]) / first_len
        udy = (my[1] - my[0]) / first_len
        nx, ny = udy, -udx
        out.append([
            (mx[0] + udx * near_m + nx * offset_m) / d_lon,
            (my[0] + udy * near_m + ny * offset_m) / d_lat,
        ])

    for i in range(1, n - 1):
        normals = []
        for (ax, ay, bx, by) in [(mx[i-1], my[i-1], mx[i],   my[i]),
                                  (mx[i],   my[i],   mx[i+1], my[i+1])]:
            dx, dy = bx - ax, by - ay
            ln = math.hypot(dx, dy)
            if ln:
                normals.append((dy / ln, -dx / ln))

        if normals:
            anx = sum(v[0] for v in normals) / len(normals)
            any_ = sum(v[1] for v in normals) / len(normals)
            nl = math.hypot(anx, any_)
            if nl:
                anx, any_ = anx / nl, any_ / nl
        else:
            anx, any_ = 0.0, 0.0

        out.append([
            (mx[i] + anx * offset_m) / d_lon,
            (my[i] + any_ * offset_m) / d_lat,
        ])

    last_len = math.hypot(mx[n-1] - mx[n-2], my[n-1] - my[n-2])
    if last_len > near_m:
        udx = (mx[n-1] - mx[n-2]) / last_len
        udy = (my[n-1] - my[n-2]) / last_len
        nx, ny = udy, -udx
        out.append([
            (mx[n-1] - udx * near_m + nx * offset_m) / d_lon,
            (my[n-1] - udy * near_m + ny * offset_m) / d_lat,
        ])

    out.append(list(coords[-1][:2]))

    return out


# ---------------------------------------------------------------------------
# assign_reverse_link_ids
# ---------------------------------------------------------------------------

def assign_reverse_link_ids(features: list) -> None:
    """Second pass: for features whose reverseLinkIds is still [], find the nearest
    parallel feature going in the opposite direction.

    Matching is symmetric — both features get each other's spectrum_id in reverseLinkIds.
    """
    n = len(features)

    mids     = []
    headings = []
    for f in features:
        coords  = f["geometry"]["coordinates"]
        lat_avg = sum(c[1] for c in coords) / len(coords)
        d_lon   = 111_320.0 * math.cos(math.radians(lat_avg))
        d_lat   = 111_320.0
        mid     = coords[len(coords) // 2]
        mids.append((mid[0] * d_lon, mid[1] * d_lat))
        headings.append(heading(coords))

    candidates = [i for i in range(n)
                  if features[i]["properties"].get("reverseLinkIds") == []]

    matched: set = set()
    for ii, i in enumerate(candidates):
        if i in matched:
            continue
        mx, my = mids[i]
        opp_h  = (headings[i] + 180) % 360
        best_dist = _OPPOSITE_SEARCH_M + 1.0
        best_j    = None

        for j in candidates[ii + 1:]:
            if j in matched:
                continue
            hdiff = abs(((headings[j] - opp_h + 180) % 360) - 180)
            if hdiff > _OPPOSITE_HEADING_TOL:
                continue
            dist = math.hypot(mids[j][0] - mx, mids[j][1] - my)
            if dist < best_dist:
                best_dist = dist
                best_j    = j

        if best_j is not None:
            sid_i = features[i]["properties"]["spectrumId"]
            sid_j = features[best_j]["properties"]["spectrumId"]
            features[i]["properties"]["reverseLinkIds"]      = [sid_j]
            features[best_j]["properties"]["reverseLinkIds"] = [sid_i]
            matched.add(i)
            matched.add(best_j)
