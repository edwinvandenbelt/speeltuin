"""
Grid-based 2D spatial index — a drop-in replacement for ``scipy.spatial.cKDTree``
for the k-nearest-neighbours use case in ``parallel_link_finder_core.py``.

Only the subset of the ``cKDTree`` API actually used in this project is
implemented:

* ``KDTree2D(data)`` — constructor, ``data`` is an ``(N, 2)`` float array.
* ``KDTree2D.query(x, k=1)`` — returns ``(distances, indices)`` each of shape
  ``(M, k)`` for ``M`` query points.

Algorithm
---------
The points are placed into a uniform 2-D grid of square cells.  The cell size
is chosen so that the expected number of points per cell is ~1 (i.e.
``cell_size ≈ max(range) / sqrt(N)``).

For each query point an adaptive ring search is performed:

1. Start with ring radius ``r = 0`` (the cell that contains the query point).
2. Collect all data-point candidates from every cell in the square ring of
   half-width ``r`` around the query cell.
3. If we have ≥ k candidates **and** the Euclidean distance to the k-th
   closest candidate is ≤ r * cell_size (guaranteeing that no closer point
   can exist in the unsearched rings beyond ``r``), terminate.
4. Otherwise increment ``r`` and repeat.

This is O(k log k) per query on average for uniformly distributed data, which
is sufficient for the parallel-link-finder use case.
"""

from __future__ import annotations

import math
from collections import defaultdict
from typing import TYPE_CHECKING

try:
    import numpy as np
except ImportError as _np_err:
    raise ImportError(
        "numpy is required for KDTree2D. "
        "Install it with: pip install gmt-calculation-lib[prepare]"
    ) from _np_err

if TYPE_CHECKING:
    pass


class KDTree2D:
    """Grid-based 2-D nearest-neighbour index.

    Parameters
    ----------
    data:
        Array of shape ``(N, 2)`` containing the 2-D point coordinates to
        index.  A copy is **not** made; do not modify the array after
        construction.
    """

    def __init__(self, data: np.ndarray) -> None:
        data = np.asarray(data, dtype=float)
        if data.ndim != 2 or data.shape[1] != 2:
            raise ValueError(f"data must have shape (N, 2), got {data.shape}")

        self._data = data
        n = len(data)

        if n == 0:
            self._cell_size = 1.0
            self._cells: dict[tuple[int, int], list[int]] = {}
            self._n = 0
            return

        self._n = n

        # Choose cell size so expected occupancy ≈ 1 point / cell.
        x_range = float(np.max(data[:, 0]) - np.min(data[:, 0]))
        y_range = float(np.max(data[:, 1]) - np.min(data[:, 1]))
        span = max(x_range, y_range)
        if span == 0.0:
            # All points coincide — use a nominal cell size.
            self._cell_size = 1.0
        else:
            self._cell_size = span / math.sqrt(n)

        # Build the grid: map (cell_i, cell_j) → list of point indices.
        cells: dict[tuple[int, int], list[int]] = defaultdict(list)
        cell_size = self._cell_size
        for idx in range(n):
            ci = int(math.floor(data[idx, 0] / cell_size))
            cj = int(math.floor(data[idx, 1] / cell_size))
            cells[(ci, cj)].append(idx)
        self._cells = dict(cells)

    # ------------------------------------------------------------------
    def query(
        self,
        x: np.ndarray,
        k: int = 1,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Find the *k* nearest neighbours for each row of *x*.

        Parameters
        ----------
        x:
            Query points, shape ``(M, 2)`` or ``(2,)`` for a single point.
        k:
            Number of neighbours to return.

        Returns
        -------
        distances : np.ndarray, shape ``(M, k)``
            Euclidean distances to the k nearest neighbours, sorted ascending.
        indices : np.ndarray, shape ``(M, k)``
            Row indices into the original ``data`` array.

        Notes
        -----
        If the dataset contains fewer than *k* points the behaviour mirrors
        ``cKDTree``: the result arrays are filled up to ``min(k, N)`` entries.
        If the dataset is empty, zero-length arrays are returned.
        """
        x = np.asarray(x, dtype=float)
        scalar = x.ndim == 1
        if scalar:
            x = x[None, :]
        if x.ndim != 2 or x.shape[1] != 2:
            raise ValueError(f"x must have shape (M, 2) or (2,), got {x.shape}")

        m = len(x)
        effective_k = min(k, self._n)

        if effective_k == 0:
            empty = np.empty((m, 0), dtype=float)
            return empty, np.empty((m, 0), dtype=int)

        dist_out = np.empty((m, effective_k), dtype=float)
        idx_out = np.empty((m, effective_k), dtype=int)

        cell_size = self._cell_size
        cells = self._cells
        data = self._data

        for qi in range(m):
            qx = x[qi, 0]
            qy = x[qi, 1]

            qci = int(math.floor(qx / cell_size))
            qcj = int(math.floor(qy / cell_size))

            candidates: list[int] = []
            r = 0
            while True:
                # Collect cells in ring r (the border of the square from
                # (qci-r, qcj-r) to (qci+r, qcj+r)).
                if r == 0:
                    bucket = cells.get((qci, qcj))
                    if bucket:
                        candidates.extend(bucket)
                else:
                    # Top and bottom rows of the ring.
                    for ci in range(qci - r, qci + r + 1):
                        for cj in (qcj - r, qcj + r):
                            bucket = cells.get((ci, cj))
                            if bucket:
                                candidates.extend(bucket)
                    # Left and right columns (excluding corners already added).
                    for cj in range(qcj - r + 1, qcj + r):
                        for ci in (qci - r, qci + r):
                            bucket = cells.get((ci, cj))
                            if bucket:
                                candidates.extend(bucket)

                if len(candidates) >= effective_k:
                    # Compute squared distances for all candidates so far.
                    cand_arr = data[candidates]
                    dx = cand_arr[:, 0] - qx
                    dy = cand_arr[:, 1] - qy
                    sq_dists = dx * dx + dy * dy

                    # Find the k-th smallest squared distance.
                    if len(sq_dists) <= effective_k:
                        kth_sq = float(np.max(sq_dists))
                    else:
                        kth_sq = float(np.partition(sq_dists, effective_k - 1)[effective_k - 1])

                    # Safe-to-stop condition: any unsearched point (ring r+1 or
                    # beyond) is at distance ≥ r * cell_size from the query.
                    if kth_sq <= (r * cell_size) ** 2:
                        break

                r += 1
                # Guard: if we've expanded past all possible cells, stop.
                if r > 2 * math.ceil(math.sqrt(self._n)) + 1:
                    break

            # Final ranking of collected candidates.
            if not candidates:
                dist_out[qi, :] = np.inf
                idx_out[qi, :] = 0
                continue

            cand_arr = data[candidates]
            dx = cand_arr[:, 0] - qx
            dy = cand_arr[:, 1] - qy
            sq_dists = dx * dx + dy * dy

            # Partial sort to get the effective_k nearest.
            if len(sq_dists) <= effective_k:
                order = np.argsort(sq_dists)
                best_sq = sq_dists[order]
                best_idx = np.array(candidates)[order]
                # Pad if fewer candidates than effective_k (shouldn't happen
                # except in degenerate cases, but be safe).
                pad = effective_k - len(order)
                if pad > 0:
                    best_sq = np.concatenate([best_sq, np.full(pad, np.inf)])
                    best_idx = np.concatenate([best_idx, np.zeros(pad, dtype=int)])
            else:
                part = np.argpartition(sq_dists, effective_k)[:effective_k]
                order = part[np.argsort(sq_dists[part])]
                best_sq = sq_dists[order]
                best_idx = np.array(candidates)[order]

            dist_out[qi, :] = np.sqrt(best_sq)
            idx_out[qi, :] = best_idx

        return dist_out, idx_out
