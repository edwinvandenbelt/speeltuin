"""
Minimal Databricks SQL REST client (stdlib-only).

Public surface
--------------
connect_from_env() -> _Connection
conn.cursor()      -> _Cursor
cur.execute(sql, params=())   # ? positional placeholders
cur.fetchall()     -> list[tuple]
cur.description    -> list[(name,)]

Result disposition
------------------
Uses disposition=EXTERNAL_LINKS so that large result sets (> 25 MB) are
returned as presigned download URLs rather than inline JSON.  Each chunk URL
is downloaded without authentication; pagination follows
``next_chunk_internal_link`` until all chunks are consumed.
"""
from __future__ import annotations

import json
import logging
import os
import time
import urllib.error
import urllib.request

logger = logging.getLogger(__name__)

_DBSQL_WAIT        = '50s'
_DBSQL_POLL_S      = 1.5
_DOWNLOAD_TIMEOUT  = 300   # seconds — presigned URLs for large chunks


def _to_named_params(sql: str, params: tuple) -> tuple[str, list]:
    named: list[dict] = []
    result = sql
    for i, val in enumerate(params, 1):
        result = result.replace('?', f':p{i}', 1)
        named.append({'name': f'p{i}', 'value': str(val), 'type': 'STRING'})
    return result, named


def _coerce(value, col_meta: dict):
    if value is None:
        return None
    type_name = (col_meta.get('type_name') or '').upper()
    if type_name in {'INT', 'INTEGER', 'BIGINT', 'LONG', 'SHORT', 'BYTE', 'SMALLINT', 'TINYINT'}:
        try:
            return int(value)
        except (TypeError, ValueError):
            return value
    if type_name in {'DOUBLE', 'FLOAT', 'DECIMAL', 'NUMERIC', 'REAL'}:
        try:
            return float(value)
        except (TypeError, ValueError):
            return value
    if type_name == 'BOOLEAN':
        if isinstance(value, bool):
            return value
        return str(value).lower() in ('true', '1')
    return value


class _ResultSet:
    __slots__ = ('description', '_rows')

    def __init__(self, description: list, rows: list) -> None:
        self.description = description
        self._rows = rows

    def fetchall(self) -> list:
        return self._rows

    def __enter__(self):
        return self

    def __exit__(self, *_):
        pass


class _Cursor:
    def __init__(self, host: str, warehouse_id: str, token: str) -> None:
        self._host         = host.rstrip('/')
        self._warehouse_id = warehouse_id
        self._token        = token
        self._result: _ResultSet | None = None

    @property
    def description(self):
        return self._result.description if self._result else []

    def execute(self, sql: str, params: tuple = ()) -> None:
        named_sql, api_params = _to_named_params(sql, params)
        body: dict = {
            'warehouse_id':    self._warehouse_id,
            'statement':       named_sql,
            'wait_timeout':    _DBSQL_WAIT,
            'on_wait_timeout': 'CONTINUE',
            'format':          'JSON_ARRAY',
            'disposition':     'EXTERNAL_LINKS',
        }
        if api_params:
            body['parameters'] = api_params

        resp    = self._api('POST', '/api/2.0/sql/statements', body)
        stmt_id: str = resp['statement_id']
        logger.debug('Statement submitted: id=%s', stmt_id)

        while resp.get('status', {}).get('state') in ('PENDING', 'RUNNING'):
            time.sleep(_DBSQL_POLL_S)
            resp = self._api('GET', f'/api/2.0/sql/statements/{stmt_id}')

        state = resp.get('status', {}).get('state')
        if state != 'SUCCEEDED':
            err = (resp.get('status') or {}).get('error') or {}
            msg = err.get('message', 'no error message')
            raise RuntimeError(
                f'Databricks query {stmt_id} ended with state={state}: {msg}'
            )

        columns: list = (
            resp.get('manifest', {})
                .get('schema', {})
                .get('columns', [])
        )
        description = [(col['name'],) for col in columns]

        rows: list = []
        # EXTERNAL_LINKS: result contains a list of presigned-URL chunk descriptors.
        # Each descriptor has an 'external_link' to download and optionally a
        # 'next_chunk_internal_link' pointing to the next descriptor page.
        ext_links: list = (resp.get('result') or {}).get('external_links') or []
        while ext_links:
            next_link: str | None = None
            for link_info in ext_links:
                chunk_rows = self._download_chunk(link_info['external_link'])
                for raw_row in chunk_rows:
                    rows.append(tuple(
                        _coerce(raw_row[i], columns[i])
                        for i in range(len(columns))
                    ))
                next_link = link_info.get('next_chunk_internal_link') or next_link
            if not next_link:
                break
            ext_links = (self._api('GET', next_link).get('external_links') or [])

        logger.debug('Statement %s: %d rows, %d columns', stmt_id, len(rows), len(columns))
        self._result = _ResultSet(description, rows)

    def fetchall(self) -> list:
        return self._result.fetchall() if self._result else []

    def __enter__(self):
        return self

    def __exit__(self, *_):
        pass

    def _download_chunk(self, url: str) -> list:
        """Download a presigned external-link URL; return the JSON array of row-arrays."""
        req = urllib.request.Request(url, method='GET')
        try:
            with urllib.request.urlopen(req, timeout=_DOWNLOAD_TIMEOUT) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            body_bytes = exc.read()
            raise RuntimeError(
                f'External-link download HTTP {exc.code}: '
                f"{body_bytes.decode('utf-8', errors='replace')}"
            ) from exc

    def _api(self, method: str, path: str, body: dict | None = None) -> dict:
        url  = f'https://{self._host}{path}'
        data = json.dumps(body).encode() if body is not None else None
        req  = urllib.request.Request(
            url,
            data=data,
            headers={
                'Authorization': f'Bearer {self._token}',
                'Content-Type':  'application/json',
                'Accept':        'application/json',
            },
            method=method,
        )
        try:
            with urllib.request.urlopen(req, timeout=55) as resp:
                return json.loads(resp.read())
        except urllib.error.HTTPError as exc:
            body_bytes = exc.read()
            raise RuntimeError(
                f'Databricks API {method} {path} HTTP {exc.code}: '
                f"{body_bytes.decode('utf-8', errors='replace')}"
            ) from exc


class _Connection:
    def __init__(self, host: str, warehouse_id: str, token: str) -> None:
        self._host         = host
        self._warehouse_id = warehouse_id
        self._token        = token

    def cursor(self) -> _Cursor:
        return _Cursor(self._host, self._warehouse_id, self._token)

    def close(self) -> None:
        pass

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()


def connect_from_env() -> _Connection:
    """Create a _Connection from DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID, DATABRICKS_TOKEN."""
    missing = [
        k for k in ('DATABRICKS_HOST', 'DATABRICKS_WAREHOUSE_ID', 'DATABRICKS_TOKEN')
        if not os.environ.get(k)
    ]
    if missing:
        raise RuntimeError(
            f"Required environment variable(s) not set: {', '.join(missing)}."
        )
    host         = os.environ['DATABRICKS_HOST']
    warehouse_id = os.environ['DATABRICKS_WAREHOUSE_ID']
    token        = os.environ['DATABRICKS_TOKEN']
    logger.debug('Databricks REST client: host=%s  warehouse=%s', host, warehouse_id)
    return _Connection(host, warehouse_id, token)
