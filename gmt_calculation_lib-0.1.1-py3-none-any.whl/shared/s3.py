"""S3 helpers shared by Lambda handlers and local runners.

All functions lazy-import boto3 so that the package can be imported in
unit-test environments that lack boto3.
"""
from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

try:
    import boto3 as _boto3  # noqa: F401
    _HAS_BOTO3 = True
except ImportError:
    _HAS_BOTO3 = False


def s3_split(s3_uri: str) -> tuple[str, str]:
    """Split ``s3://bucket/key`` into ``(bucket, key)``."""
    assert s3_uri.startswith("s3://"), f"Not an S3 URI: {s3_uri}"
    parts = s3_uri[5:].split("/", 1)
    return parts[0], parts[1] if len(parts) > 1 else ""


def get_bytes_s3(bucket: str, key: str) -> bytes:
    """Download *key* from *bucket* and return the raw bytes."""
    import boto3  # noqa: PLC0415

    s3 = boto3.client("s3")
    obj = s3.get_object(Bucket=bucket, Key=key)
    return obj["Body"].read()


def put_bytes_s3(
    bucket: str,
    key: str,
    data: bytes,
    content_type: str = "application/geo+json",
) -> None:
    """Upload *data* to *bucket*/*key*."""
    if not _HAS_BOTO3:
        logger.warning("boto3 not available; skipping S3 write for s3://%s/%s", bucket, key)
        return
    import boto3  # noqa: PLC0415

    s3 = boto3.client("s3")
    s3.put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def delete_object_s3(bucket: str, key: str) -> None:
    """Delete *key* from *bucket* (no-op if the object does not exist)."""
    import boto3  # noqa: PLC0415

    s3 = boto3.client("s3")
    s3.delete_object(Bucket=bucket, Key=key)
    logger.info("Deleted s3://%s/%s", bucket, key)


def list_keys_s3(bucket: str, prefix: str) -> list[str]:
    """Return all object keys whose key starts with *prefix* in *bucket*."""
    import boto3  # noqa: PLC0415

    s3 = boto3.client("s3")
    keys: list[str] = []
    kwargs: dict = {"Bucket": bucket, "Prefix": prefix}
    while True:
        resp = s3.list_objects_v2(**kwargs)
        for obj in resp.get("Contents", []):
            keys.append(obj["Key"])
        if not resp.get("IsTruncated"):
            break
        kwargs["ContinuationToken"] = resp["NextContinuationToken"]
    return keys


def s3_presign(bucket: str, key: str, expiry: int = 3600) -> str:
    """Return a presigned GET URL for *bucket*/*key*.

    Respects the ``S3_PRESIGN_ENDPOINT`` environment variable so that
    LocalStack can return a ``host.docker.internal`` URL instead of an AWS one.
    """
    import boto3  # noqa: PLC0415

    presign_endpoint = os.environ.get("S3_PRESIGN_ENDPOINT")
    kwargs = {"endpoint_url": presign_endpoint} if presign_endpoint else {}
    s3 = boto3.client("s3", **kwargs)
    return s3.generate_presigned_url(
        "get_object",
        Params={"Bucket": bucket, "Key": key},
        ExpiresIn=expiry,
    )
