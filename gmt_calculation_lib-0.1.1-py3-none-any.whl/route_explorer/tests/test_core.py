"""Unit tests for route_explorer_core."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from route_explorer.core.route_explorer_core import (
    OD_BUILDER_PROPERTIES,
    _apply_external_tt_correction,
    _boundary_link_speed,
    _build_link_coord_index,
    _build_link_speed_index,
    _dijkstra_path,
    _distribute_trips_over_routes,
    _extract_node_coords,
    _extract_node_flows,
    _find_home_zones,
    _parse_adjustments,
    _parse_node_adjustments,
    _path_to_linestring,
    _yen_k_shortest,
    build_od_matrix,
)

# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------


def _net_feature(from_node, to_node, speed, length, capacity, flow=0.0, coords=None, link_id=None):
    """Build a minimal network GeoJSON feature."""
    if coords is None:
        coords = [[0.0, 0.0], [1.0, 0.0]]
    props: dict = {
        "fromNode": from_node,
        "toNode": to_node,
        "speed": speed,
        "length": length,
        "capacity": capacity,
        "flow": flow,
        "flowsPerDaypart": {},
    }
    if link_id is not None:
        props["linkId"] = link_id
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": props,
    }


def _feedlink_feature(zone_id, network_node, direction, length, capacity=1000.0):
    """Build a feedlink feature.

    direction: "production" -> fromNode=fake_zone, toNode=network_node
               "attraction" -> fromNode=network_node, toNode=fake_zone
    """
    fake_zone = f"fake_{zone_id}"
    if direction == "attraction":
        from_node, to_node = network_node, fake_zone
    else:
        from_node, to_node = fake_zone, network_node
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [0.1, 0.0]]},
        "properties": {
            "zoneId": zone_id,
            "fromNode": from_node,
            "toNode": to_node,
            "length": length,
            "capacity": capacity,
        },
    }


def _zone_feature_polygon(zone_id, ring):
    """Build a zone GeoJSON feature with polygon geometry."""
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {
            "zoneId": zone_id,
            "zoneClass": "STUDY",
        },
    }


def _make_fc(features):
    return {"type": "FeatureCollection", "features": features}


# ---------------------------------------------------------------------------
# Toy network for integration tests
#
# Topology (directed):
#   "1" → "2" → "3"   (forward path)
#   "3" → "2"          (return path, so zone B → node 2 is reachable)
#
# Zones (polygon geometry):
#   Zone A: x=[0,2), y=[0,1]  — covers nodes "1" ([0.5,0.5]) and "2" ([1.5,0.5])
#   Zone B: x=[2,4], y=[0,1]  — covers node "3" ([2.5,0.5])
#
# Anchor node: "2" (inside zone A)
# ---------------------------------------------------------------------------

_ZONE_A_RING = [[0.0, 0.0], [2.0, 0.0], [2.0, 1.0], [0.0, 1.0], [0.0, 0.0]]
_ZONE_B_RING = [[2.0, 0.0], [4.0, 0.0], [4.0, 1.0], [2.0, 1.0], [2.0, 0.0]]


def _toy_network():
    return _make_fc([
        _net_feature("1", "2", 36.0, 100.0, 500.0, flow=40.0,
                     coords=[[0.5, 0.5], [1.5, 0.5]], link_id="L12"),
        _net_feature("2", "3", 36.0, 100.0, 500.0, flow=50.0,
                     coords=[[1.5, 0.5], [2.5, 0.5]], link_id="L23"),
        _net_feature("3", "2", 36.0, 100.0, 500.0, flow=30.0,
                     coords=[[2.5, 0.5], [1.5, 0.5]], link_id="L32"),
    ])


def _toy_feedlinks():
    return _make_fc([
        _feedlink_feature("A", "2", "production", 10.0),
        _feedlink_feature("A", "2", "attraction", 10.0),
        _feedlink_feature("B", "3", "production", 10.0),
        _feedlink_feature("B", "3", "attraction", 10.0),
    ])


def _toy_zones():
    return _make_fc([
        _zone_feature_polygon("A", _ZONE_A_RING),
        _zone_feature_polygon("B", _ZONE_B_RING),
    ])


def _adj_node2(production=100.0, attraction=80.0):
    """Return node_adjustments that assign production+attraction to node '2'."""
    adjustments = []
    if production:
        adjustments.append({"nodeId": "2", "production": str(production)})
    if attraction:
        adjustments.append({"nodeId": "2", "attraction": str(attraction)})
    return adjustments


# ---------------------------------------------------------------------------
# Tests: _dijkstra_path
# ---------------------------------------------------------------------------


class TestDijkstraPath:
    def _simple_adj(self):
        # A -> B (5s, 100m, 400 remaining, 400 total cap)
        # A -> C (10s, 200m, 300 remaining, 300 total cap)
        # B -> C (3s, 50m, 250 remaining, 250 total cap)
        return {
            "A": [("B", 5.0, 100.0, 400.0, 400.0), ("C", 10.0, 200.0, 300.0, 300.0)],
            "B": [("C", 3.0, 50.0, 250.0, 250.0)],
        }

    def test_finds_shortest_path(self):
        adj = self._simple_adj()
        result = _dijkstra_path(adj, "A", "C")
        assert result is not None
        time_s, dist_m, res, cap_total, path = result
        # A->B->C: 8s, 150m
        assert time_s == pytest.approx(8.0)
        assert dist_m == pytest.approx(150.0)
        assert path == ["A", "B", "C"]

    def test_direct_path_not_taken_when_slower(self):
        adj = self._simple_adj()
        result = _dijkstra_path(adj, "A", "C")
        assert result is not None
        assert result[0] == pytest.approx(8.0)  # A->B->C is faster

    def test_returns_none_when_unreachable(self):
        adj = {"A": [("B", 1.0, 1.0, 1.0, 1.0)]}
        result = _dijkstra_path(adj, "A", "C")
        assert result is None

    def test_forbidden_edge_forces_alternative(self):
        adj = self._simple_adj()
        result = _dijkstra_path(adj, "A", "C", forbidden_edges={("A", "B")})
        assert result is not None
        time_s, dist_m, res, cap_total, path = result
        assert path == ["A", "C"]
        assert time_s == pytest.approx(10.0)

    def test_forbidden_node(self):
        adj = self._simple_adj()
        result = _dijkstra_path(adj, "A", "C", forbidden_nodes={"B"})
        assert result is not None
        assert result[4] == ["A", "C"]

    def test_resistance_is_bottleneck(self):
        adj = {
            "S": [("M", 1.0, 10.0, 100.0, 100.0)],
            "M": [("T", 1.0, 10.0, 50.0, 50.0)],  # bottleneck
        }
        result = _dijkstra_path(adj, "S", "T")
        assert result is not None
        assert result[2] == pytest.approx(50.0)


# ---------------------------------------------------------------------------
# Tests: _yen_k_shortest
# ---------------------------------------------------------------------------


class TestYenKShortest:
    def _two_path_adj(self):
        # S -> A -> T  (10s, route 1)
        # S -> B -> T  (11s, route 2 — within 1.2× ratio, so kept)
        return {
            "S": [("A", 5.0, 50.0, 100.0, 100.0), ("B", 5.5, 55.0, 100.0, 100.0)],
            "A": [("T", 5.0, 50.0, 100.0, 100.0)],
            "B": [("T", 5.5, 55.0, 100.0, 100.0)],
        }

    def test_returns_two_paths(self):
        adj = self._two_path_adj()
        paths = _yen_k_shortest(adj, "S", "T", k=2)
        assert len(paths) == 2
        # First path is shortest
        assert paths[0][0] <= paths[1][0]
        assert paths[0][4] == ["S", "A", "T"]
        assert paths[1][4] == ["S", "B", "T"]

    def test_returns_one_path_when_no_alternative(self):
        adj = {"S": [("T", 5.0, 50.0, 100.0, 100.0)]}
        paths = _yen_k_shortest(adj, "S", "T", k=3)
        assert len(paths) == 1
        assert paths[0][4] == ["S", "T"]

    def test_returns_empty_when_unreachable(self):
        adj: dict = {}
        paths = _yen_k_shortest(adj, "S", "T", k=2)
        assert paths == []

    def test_paths_are_loopless(self):
        # Network with a cycle: S->A->B->A (but A->T exists)
        adj = {
            "S": [("A", 1.0, 10.0, 100.0, 100.0)],
            "A": [("B", 1.0, 10.0, 100.0, 100.0), ("T", 5.0, 50.0, 100.0, 100.0)],
            "B": [("A", 1.0, 10.0, 100.0, 100.0), ("T", 1.0, 10.0, 100.0, 100.0)],
        }
        paths = _yen_k_shortest(adj, "S", "T", k=3)
        for _, _, _, _, path in paths:
            assert len(path) == len(set(path)), f"Loop in path: {path}"

    def test_alternative_route_exceeding_ratio_is_dropped(self):
        # Shortest path S->A->T costs 10 s.
        # Alternative S->B->T costs 13 s (1.3× > 1.2×) — must be discarded.
        adj = {
            "S": [("A", 5.0, 50.0, 100.0, 100.0), ("B", 6.0, 60.0, 100.0, 100.0)],
            "A": [("T", 5.0, 50.0, 100.0, 100.0)],
            "B": [("T", 7.0, 70.0, 100.0, 100.0)],
        }
        paths = _yen_k_shortest(adj, "S", "T", k=2)
        assert len(paths) == 1, "Alternative route exceeding 1.2× ratio should be dropped"
        assert paths[0][4] == ["S", "A", "T"]

    def test_alternative_route_within_ratio_is_kept(self):
        # Shortest path S->A->T costs 10 s.
        # Alternative S->B->T costs 11 s (1.1× ≤ 1.2×) — must be kept.
        adj = {
            "S": [("A", 5.0, 50.0, 100.0, 100.0), ("B", 5.5, 55.0, 100.0, 100.0)],
            "A": [("T", 5.0, 50.0, 100.0, 100.0)],
            "B": [("T", 5.5, 55.0, 100.0, 100.0)],
        }
        paths = _yen_k_shortest(adj, "S", "T", k=2)
        assert len(paths) == 2, "Alternative route within 1.2× ratio should be kept"
        assert paths[0][4] == ["S", "A", "T"]
        assert paths[1][4] == ["S", "B", "T"]


# ---------------------------------------------------------------------------
# Tests: _extract_node_flows
# ---------------------------------------------------------------------------


class TestExtractNodeFlows:
    def test_basic(self):
        network_fc = _make_fc([
            _net_feature("1", "2", 50.0, 100.0, 500.0, flow=30.0),
            _net_feature("2", "3", 50.0, 100.0, 500.0, flow=20.0),
            _net_feature("1", "3", 50.0, 100.0, 500.0, flow=10.0),
        ])
        outflow, inflow = _extract_node_flows(network_fc)
        assert outflow["1"] == pytest.approx(40.0)  # 30 + 10
        assert outflow["2"] == pytest.approx(20.0)
        assert inflow["2"] == pytest.approx(30.0)
        assert inflow["3"] == pytest.approx(30.0)  # 20 + 10

    def test_missing_flow_defaults_to_zero(self):
        network_fc = _make_fc([
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
                "properties": {"fromNode": "A", "toNode": "B", "speed": 50.0,
                               "length": 100.0, "capacity": 500.0},
            }
        ])
        outflow, inflow = _extract_node_flows(network_fc)
        assert outflow.get("A", 0.0) == 0.0


# ---------------------------------------------------------------------------
# Tests: _find_home_zones
# ---------------------------------------------------------------------------

_SQUARE_RING = [[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0], [0.0, 0.0]]


class TestFindHomeZones:
    def _zone_feat(self, zone_id, ring=None):
        return _zone_feature_polygon(zone_id, ring or _SQUARE_RING)

    def test_node_inside_zone_returns_zone_id(self):
        zone = self._zone_feat("Z1")
        result = _find_home_zones([1.0, 1.0], [zone])
        assert result == {"Z1"}

    def test_node_outside_all_zones_returns_empty(self):
        zone = self._zone_feat("Z1")
        result = _find_home_zones([5.0, 5.0], [zone])
        assert result == set()

    def test_node_in_multiple_zones(self):
        z1 = self._zone_feat("Z1", [[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0], [0.0, 0.0]])
        z2 = self._zone_feat("Z2", [[1.0, 0.0], [3.0, 0.0], [3.0, 2.0], [1.0, 2.0], [1.0, 0.0]])
        result = _find_home_zones([1.5, 1.0], [z1, z2])
        assert result == {"Z1", "Z2"}

    def test_none_coords_returns_empty(self):
        zone = self._zone_feat("Z1")
        result = _find_home_zones(None, [zone])
        assert result == set()

    def test_empty_zone_list_returns_empty(self):
        result = _find_home_zones([1.0, 1.0], [])
        assert result == set()

    def test_multipolygon_zone(self):
        feat = {
            "type": "Feature",
            "geometry": {
                "type": "MultiPolygon",
                "coordinates": [
                    [[[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.0, 0.0]]],
                    [[[3.0, 0.0], [4.0, 0.0], [4.0, 1.0], [3.0, 1.0], [3.0, 0.0]]],
                ],
            },
            "properties": {"zoneId": "MULTI"},
        }
        assert _find_home_zones([0.5, 0.5], [feat]) == {"MULTI"}
        assert _find_home_zones([3.5, 0.5], [feat]) == {"MULTI"}
        assert _find_home_zones([2.0, 0.5], [feat]) == set()

    def test_non_polygon_geometry_skipped(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [1.0, 1.0]},
            "properties": {"zoneId": "PT"},
        }
        result = _find_home_zones([1.0, 1.0], [feat])
        assert result == set()


# ---------------------------------------------------------------------------
# Tests: _parse_node_adjustments
# ---------------------------------------------------------------------------


class TestParseNodeAdjustments:
    def test_absolute_values(self):
        adj = [{"nodeId": "N1", "production": "100", "attraction": "50"}]
        prod, attr = _parse_node_adjustments(adj)
        assert prod == {"N1": pytest.approx(100.0)}
        assert attr == {"N1": pytest.approx(50.0)}

    def test_delta_values(self):
        adj = [
            {"nodeId": "N1", "production": "100"},
            {"nodeId": "N1", "production": "+50"},
        ]
        prod, attr = _parse_node_adjustments(adj)
        assert prod == {"N1": pytest.approx(150.0)}

    def test_negative_delta(self):
        adj = [
            {"nodeId": "N1", "production": "200"},
            {"nodeId": "N1", "production": "-50"},
        ]
        prod, attr = _parse_node_adjustments(adj)
        assert prod == {"N1": pytest.approx(150.0)}

    def test_zero_excluded_negative_kept(self):
        """Zero values are excluded; negative values are kept (they reduce existing flows)."""
        adj = [
            {"nodeId": "N1", "production": "0"},
            {"nodeId": "N2", "production": "-10"},
        ]
        prod, attr = _parse_node_adjustments(adj)
        assert "N1" not in prod
        assert prod["N2"] == pytest.approx(-10.0)

    def test_missing_node_id_skipped(self):
        adj = [{"production": "100"}]
        prod, attr = _parse_node_adjustments(adj)
        assert prod == {}

    def test_empty_list(self):
        prod, attr = _parse_node_adjustments([])
        assert prod == {}
        assert attr == {}

    def test_multiple_nodes(self):
        adj = [
            {"nodeId": "A", "production": "10"},
            {"nodeId": "B", "attraction": "20"},
        ]
        prod, attr = _parse_node_adjustments(adj)
        assert prod == {"A": pytest.approx(10.0)}
        assert attr == {"B": pytest.approx(20.0)}

    def test_only_production_or_only_attraction(self):
        adj_prod = [{"nodeId": "N1", "production": "100"}]
        prod, attr = _parse_node_adjustments(adj_prod)
        assert "N1" in prod
        assert "N1" not in attr

        adj_attr = [{"nodeId": "N1", "attraction": "80"}]
        prod, attr = _parse_node_adjustments(adj_attr)
        assert "N1" not in prod
        assert "N1" in attr


# ---------------------------------------------------------------------------
# Tests: _parse_adjustments  (nodeId / zoneId)
# ---------------------------------------------------------------------------


class TestParseAdjustments:
    def test_node_id_only(self):
        adj = [{"nodeId": "N1", "production": "100", "attraction": "50"}]
        node_prod, node_attr, zone_prod, zone_attr = _parse_adjustments(adj)
        assert node_prod == {"N1": pytest.approx(100.0)}
        assert node_attr == {"N1": pytest.approx(50.0)}
        assert zone_prod == {}
        assert zone_attr == {}

    def test_zone_id_only(self):
        adj = [{"zoneId": "Z1", "production": "200", "attraction": "80"}]
        node_prod, node_attr, zone_prod, zone_attr = _parse_adjustments(adj)
        assert node_prod == {}
        assert node_attr == {}
        assert zone_prod == {"Z1": pytest.approx(200.0)}
        assert zone_attr == {"Z1": pytest.approx(80.0)}

    def test_mixed_node_and_zone_entries(self):
        adj = [
            {"nodeId": "N1", "production": "100"},
            {"zoneId": "Z1", "attraction": "50"},
        ]
        node_prod, node_attr, zone_prod, zone_attr = _parse_adjustments(adj)
        assert node_prod == {"N1": pytest.approx(100.0)}
        assert zone_attr == {"Z1": pytest.approx(50.0)}

    def test_both_node_and_zone_raises(self):
        adj = [{"nodeId": "N1", "zoneId": "Z1", "production": "100"}]
        with pytest.raises(ValueError, match="both"):
            _parse_adjustments(adj)

    def test_entry_without_id_skipped(self):
        adj = [{"production": "100"}]
        node_prod, node_attr, zone_prod, zone_attr = _parse_adjustments(adj)
        assert node_prod == {}
        assert zone_prod == {}

    def test_zone_delta_values(self):
        adj = [
            {"zoneId": "Z1", "production": "100"},
            {"zoneId": "Z1", "production": "+50"},
        ]
        _, _, zone_prod, _ = _parse_adjustments(adj)
        assert zone_prod == {"Z1": pytest.approx(150.0)}

    def test_zero_excluded(self):
        adj = [{"zoneId": "Z1", "production": "0"}]
        _, _, zone_prod, _ = _parse_adjustments(adj)
        assert "Z1" not in zone_prod


# ---------------------------------------------------------------------------
# Tests: _path_to_linestring
# ---------------------------------------------------------------------------


class TestPathToLinestring:
    def test_network_nodes_legacy(self):
        # Without link_coord_index: falls back to one point per node
        node_coords = {"1": [0.0, 0.0], "2": [1.0, 0.0], "3": [2.0, 0.0]}
        result = _path_to_linestring(["1", "2", "3"], node_coords, {})
        assert result == [[0.0, 0.0], [1.0, 0.0], [2.0, 0.0]]

    def test_zone_centroid_nodes(self):
        node_coords: dict = {}
        zone_centroids = {"A": (0.0, 0.0), "B": (2.0, 0.0)}
        result = _path_to_linestring(["Z_A", "Z_B"], node_coords, zone_centroids)
        assert result == [[0.0, 0.0], [2.0, 0.0]]

    def test_deduplication(self):
        node_coords = {"1": [1.0, 0.0], "2": [1.0, 0.0]}  # same coords
        result = _path_to_linestring(["1", "2"], node_coords, {})
        assert len(result) == 1  # de-duped

    def test_missing_node_skipped_legacy(self):
        node_coords = {"1": [0.0, 0.0], "3": [2.0, 0.0]}
        result = _path_to_linestring(["1", "2", "3"], node_coords, {})
        assert result == [[0.0, 0.0], [2.0, 0.0]]

    def test_link_coord_index_uses_full_geometry(self):
        # Link 1→2 has an intermediate shape point at (0.5, 0.1)
        node_coords = {"1": [0.0, 0.0], "2": [1.0, 0.0], "3": [2.0, 0.0]}
        link_idx = {
            ("1", "2"): [[0.0, 0.0], [0.5, 0.1], [1.0, 0.0]],
            ("2", "3"): [[1.0, 0.0], [2.0, 0.0]],
        }
        result = _path_to_linestring(["1", "2", "3"], node_coords, {}, link_idx)
        # Should include the intermediate shape point
        assert [0.5, 0.1] in result
        # First and last points must be correct
        assert result[0] == [0.0, 0.0]
        assert result[-1] == [2.0, 0.0]

    def test_link_coord_index_no_duplicate_junction_point(self):
        # Junction node coord must appear exactly once between two links
        node_coords = {"A": [0.0, 0.0], "B": [1.0, 0.0], "C": [2.0, 0.0]}
        link_idx = {
            ("A", "B"): [[0.0, 0.0], [1.0, 0.0]],
            ("B", "C"): [[1.0, 0.0], [2.0, 0.0]],
        }
        result = _path_to_linestring(["A", "B", "C"], node_coords, {}, link_idx)
        # [1.0, 0.0] should appear exactly once
        assert result.count([1.0, 0.0]) == 1

    def test_link_coord_index_fallback_for_missing_link(self):
        # Feedlink (Z_x → A) not in index → fallback to node_coords[A]
        node_coords = {"A": [0.5, 0.0], "B": [1.5, 0.0]}
        link_idx = {("A", "B"): [[0.5, 0.0], [1.0, 0.0], [1.5, 0.0]]}
        zone_centroids = {"x": (0.0, 0.0)}
        result = _path_to_linestring(
            ["Z_x", "A", "B"], node_coords, zone_centroids, link_idx
        )
        # Z_x centroid, then A endpoint, then full A→B geometry (skipping first A point)
        assert result[0] == [0.0, 0.0]   # zone centroid
        assert result[1] == [0.5, 0.0]   # fallback: node A (feedlink not in index)
        assert [1.0, 0.0] in result       # intermediate point of A→B


class TestBuildLinkCoordIndex:
    def test_basic(self):
        network_fc = _make_fc([
            _net_feature("1", "2", 50.0, 100.0, 500.0,
                         coords=[[0.0, 0.0], [0.5, 0.1], [1.0, 0.0]]),
        ])
        idx = _build_link_coord_index(network_fc)
        assert ("1", "2") in idx
        assert idx[("1", "2")] == [[0.0, 0.0], [0.5, 0.1], [1.0, 0.0]]

    def test_two_point_link_included(self):
        network_fc = _make_fc([_net_feature("A", "B", 50.0, 100.0, 500.0)])
        idx = _build_link_coord_index(network_fc)
        assert ("A", "B") in idx
        assert len(idx[("A", "B")]) == 2


# ---------------------------------------------------------------------------
# Tests: build_od_matrix (integration)
# ---------------------------------------------------------------------------
# Tests: _distribute_trips_over_routes
# ---------------------------------------------------------------------------


class TestDistributeTripsOverRoutes:
    def _route(self, time, dist, remaining_cap, cap_total):
        return (time, dist, remaining_cap, cap_total, [])

    # ------------------------------------------------------------------
    # Basic behaviour
    # ------------------------------------------------------------------

    def test_single_route_gets_all_trips(self):
        routes = [self._route(10.0, 100.0, 500.0, 500.0)]
        result = _distribute_trips_over_routes(300.0, routes)
        assert result == pytest.approx([300.0])

    def test_trips_sum_to_total(self):
        routes = [
            self._route(10.0, 100.0, 500.0, 500.0),
            self._route(15.0, 150.0, 400.0, 400.0),
        ]
        result = _distribute_trips_over_routes(100.0, routes)
        assert sum(result) == pytest.approx(100.0)

    def test_zero_trips_returns_zeros(self):
        routes = [self._route(10.0, 100.0, 500.0, 500.0), self._route(20.0, 200.0, 300.0, 300.0)]
        result = _distribute_trips_over_routes(0.0, routes)
        assert result == pytest.approx([0.0, 0.0])

    def test_empty_routes_returns_empty(self):
        result = _distribute_trips_over_routes(100.0, [])
        assert result == []

    # ------------------------------------------------------------------
    # Weight function: shorter travel time → more weight
    # ------------------------------------------------------------------

    def test_faster_route_gets_more_trips(self):
        # Both at zero utilization; shorter tt → higher f(tt) → more trips
        routes = [
            self._route(5.0, 100.0, 500.0, 500.0),   # faster
            self._route(20.0, 200.0, 500.0, 500.0),  # slower
        ]
        result = _distribute_trips_over_routes(100.0, routes)
        assert sum(result) == pytest.approx(100.0)
        assert result[0] > result[1]

    # ------------------------------------------------------------------
    # Motive: different alpha/beta must change the split
    # ------------------------------------------------------------------

    def test_motive_work_vs_shopping_different_split(self):
        routes = [
            self._route(5.0, 100.0, 500.0, 500.0),
            self._route(20.0, 200.0, 500.0, 500.0),
        ]
        result_work = _distribute_trips_over_routes(100.0, routes, motive="work")
        result_shop = _distribute_trips_over_routes(100.0, routes, motive="shopping")
        # Both must sum to 100
        assert sum(result_work) == pytest.approx(100.0)
        assert sum(result_shop) == pytest.approx(100.0)
        # The splits must differ because alpha/beta differ
        assert result_work[0] != pytest.approx(result_shop[0], rel=1e-3)

    # ------------------------------------------------------------------
    # Congestion penalty: high utilization penalises a route
    # ------------------------------------------------------------------

    def test_congested_route_gets_fewer_trips(self):
        # Route A: 60 % utilization (no penalty), Route B: 90 % utilization (heavy penalty)
        # Both have same raw travel time; after penalty B's effective tt is much larger.
        cap = 1000.0
        routes = [
            self._route(10.0, 100.0, 400.0, cap),   # utilization = 0.60 → no penalty
            self._route(10.0, 100.0, 100.0, cap),   # utilization = 0.90 → heavy penalty
        ]
        result = _distribute_trips_over_routes(100.0, routes)
        assert sum(result) == pytest.approx(100.0)
        assert result[0] > result[1]

    def test_no_congestion_below_threshold(self):
        # Both routes at utilization = 0.5 → penalty = 1.0 for both
        # → same weight → equal split
        cap = 1000.0
        routes = [
            self._route(10.0, 100.0, 500.0, cap),
            self._route(10.0, 100.0, 500.0, cap),
        ]
        result = _distribute_trips_over_routes(100.0, routes)
        assert result == pytest.approx([50.0, 50.0])


# ---------------------------------------------------------------------------
# Tests: build_od_matrix
# ---------------------------------------------------------------------------


class TestBuildOdMatrix:
    def test_returns_geojson_feature_collection(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(), max_routes=2,
        )
        assert isinstance(od_geojson, dict)
        assert od_geojson["type"] == "FeatureCollection"

    def test_geojson_features_have_required_properties(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(), max_routes=2,
        )
        for feat in od_geojson["features"]:
            props = feat["properties"]
            assert "fromZoneId" in props
            assert "toZoneId" in props
            assert "fromType" in props
            assert "toType" in props
            assert "tripFraction" in props
            assert "routes" in props

    def test_home_zone_excluded_from_output(self):
        """Node '2' is inside zone A — no features with zone A as endpoint."""
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(), max_routes=1,
        )
        for feat in od_geojson["features"]:
            props = feat["properties"]
            assert not (props["fromZoneId"] == "A" and props["fromType"] == "zone")
            assert not (props["toZoneId"] == "A" and props["toType"] == "zone")

    def test_production_features_node_to_zone(self):
        """Production pairs: from_type='node', to_type='zone'."""
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(production=100.0, attraction=0.0),
            max_routes=1,
        )
        prod_feats = [
            f for f in od_geojson["features"]
            if f["properties"]["fromType"] == "node"
        ]
        assert len(prod_feats) >= 1
        for feat in prod_feats:
            props = feat["properties"]
            assert props["fromZoneId"] == "2"
            assert props["toType"] == "zone"

    def test_attraction_features_zone_to_node(self):
        """Attraction pairs: from_type='zone', to_type='node'."""
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(production=0.0, attraction=80.0),
            max_routes=1,
        )
        attr_feats = [
            f for f in od_geojson["features"]
            if f["properties"]["toType"] == "node"
        ]
        assert len(attr_feats) >= 1
        for feat in attr_feats:
            props = feat["properties"]
            assert props["toZoneId"] == "2"
            assert props["fromType"] == "zone"

    def test_trips_are_non_negative(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(), max_routes=1,
        )
        for feat in od_geojson["features"]:
            assert feat["properties"]["tripFraction"] >= 0.0

    def test_trips_sum_to_production(self):
        """Total trips across all production pairs must equal the node's production value."""
        production = 300.0
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=[{"nodeId": "2", "production": str(production)}],
            max_routes=1,
        )
        prod_trips = sum(
            f["properties"]["tripFraction"] for f in od_geojson["features"]
            if f["properties"]["fromType"] == "node"
        )
        assert prod_trips == pytest.approx(production, rel=1e-6)

    def test_trips_sum_to_attraction(self):
        """Total trips across all attraction pairs must equal the node's attraction value."""
        attraction = 150.0
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=[{"nodeId": "2", "attraction": str(attraction)}],
            max_routes=1,
        )
        attr_trips = sum(
            f["properties"]["tripFraction"] for f in od_geojson["features"]
            if f["properties"]["toType"] == "node"
        )
        assert attr_trips == pytest.approx(attraction, rel=1e-6)

    def test_trips_scaled_by_production(self):
        """Doubling production doubles trips on production pairs."""
        od_low = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=[{"nodeId": "2", "production": "100"}], max_routes=1,
        )
        od_high = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=[{"nodeId": "2", "production": "200"}], max_routes=1,
        )
        trips_low = sum(f["properties"]["tripFraction"] for f in od_low["features"])
        trips_high = sum(f["properties"]["tripFraction"] for f in od_high["features"])
        assert trips_high == pytest.approx(trips_low * 2.0, rel=1e-6)

    def test_routes_have_expected_fields(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(), max_routes=2,
        )
        for feat in od_geojson["features"]:
            for route in feat["properties"]["routes"]:
                assert "travelTime" in route
                assert "distance" in route
                assert "remainingCap" in route
                assert "trips" in route
                assert "nodePath" in route
                assert "linkPath" in route
                assert route["travelTime"] >= 0.0
                assert route["trips"] >= 0.0

    def test_route_trips_sum_to_pair_trips(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(), max_routes=3,
        )
        for feat in od_geojson["features"]:
            props = feat["properties"]
            pair_trips = props["tripFraction"]
            route_trips_sum = round(sum(r["trips"] for r in props["routes"]), 4)
            assert route_trips_sum == pair_trips

    def test_routes_link_path_is_list(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(), max_routes=1,
        )
        for feat in od_geojson["features"]:
            for route in feat["properties"]["routes"]:
                assert isinstance(route["linkPath"], list)

    def test_routes_link_path_matches_node_path(self):
        # node "2" -> zone "B" (attached to node "3") goes through link L23
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=[{"nodeId": "2", "production": "1"}], max_routes=1,
        )
        # Find the production feature (from node "2" to zone "B")
        prod_feats = [
            f for f in od_geojson["features"]
            if f["properties"]["fromZoneId"] == "2"
        ]
        assert len(prod_feats) >= 1
        for feat in prod_feats:
            route = feat["properties"]["routes"][0]
            node_path = route["nodePath"]
            link_path = route["linkPath"]
            # linkPath must be a subset of the transitions, matching real links
            # Every consecutive pair in node_path that has a linkId should appear
            assert len(link_path) <= len(node_path) - 1
            # "L23" must be present (2->3 is a real link on the path to zone B)
            assert "L23" in link_path

    def test_routes_link_path_excludes_feedlink_edges(self):
        # Feedlink edges (virtual zone nodes) have no linkId — they must be absent
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=[{"nodeId": "2", "production": "1"}], max_routes=1,
        )
        for feat in od_geojson["features"]:
            for route in feat["properties"]["routes"]:
                # Feedlink virtual nodes look like "fake_<zoneId>"; their edges
                # are not in the network link index → not in linkPath
                node_path = route["nodePath"]
                link_path = route["linkPath"]
                # linkPath length must be ≤ number of real-network edges in path
                assert len(link_path) <= len(node_path) - 1

    def test_geometry_is_multilinestring(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(), max_routes=1,
        )
        for feat in od_geojson["features"]:
            geom = feat["geometry"]
            if geom is not None:
                assert geom["type"] == "MultiLineString"

    def test_link_properties_in_fc_metadata(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=_adj_node2(), max_routes=1,
        )
        lp = od_geojson.get("properties", {}).get("link_properties", [])
        for field in OD_BUILDER_PROPERTIES:
            assert field in lp

    def test_empty_adjustments_produces_empty_output(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=[], max_routes=1,
        )
        assert od_geojson["features"] == []

    def test_node_not_in_graph_produces_no_production_features(self):
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=[{"nodeId": "NONEXISTENT", "production": "100"}],
            max_routes=1,
        )
        prod_feats = [
            f for f in od_geojson["features"]
            if f["properties"]["fromType"] == "node"
        ]
        assert len(prod_feats) == 0

    def test_multiple_nodes(self):
        """Nodes '1' and '2' are both in zone A; both can produce to zone B."""
        adjustments = [
            {"nodeId": "1", "production": "50"},
            {"nodeId": "2", "production": "100"},
        ]
        od_geojson = build_od_matrix(
            _toy_network(), _toy_feedlinks(), _toy_zones(),
            node_adjustments=adjustments, max_routes=1,
        )
        from_ids = {f["properties"]["fromZoneId"] for f in od_geojson["features"]
                    if f["properties"]["fromType"] == "node"}
        assert "2" in from_ids

    def test_unreachable_pairs_omitted(self):
        """Zone B → node 2 is not routable without a 3→2 edge."""
        network_fc = _make_fc([
            _net_feature("2", "3", 36.0, 100.0, 500.0, flow=50.0,
                         coords=[[1.5, 0.5], [2.5, 0.5]]),
        ])
        feedlinks_fc = _make_fc([
            _feedlink_feature("A", "2", "production", 10.0),
            _feedlink_feature("A", "2", "attraction", 10.0),
            _feedlink_feature("B", "3", "production", 10.0),
            _feedlink_feature("B", "3", "attraction", 10.0),
        ])
        od_geojson = build_od_matrix(
            network_fc, feedlinks_fc, _toy_zones(),
            node_adjustments=[{"nodeId": "2", "attraction": "80"}],
            max_routes=1,
        )
        attr_feats = [
            f for f in od_geojson["features"]
            if f["properties"]["fromType"] == "zone" and f["properties"]["toZoneId"] == "2"
        ]
        assert len(attr_feats) == 0


# ---------------------------------------------------------------------------
# Tests: _build_link_speed_index, _boundary_link_speed, _apply_external_tt_correction
# ---------------------------------------------------------------------------


class TestBuildLinkSpeedIndex:
    def test_extracts_speed(self):
        network_fc = _make_fc([
            _net_feature("1", "2", 50.0, 100.0, 500.0),
            _net_feature("2", "3", 90.0, 200.0, 400.0),
        ])
        idx = _build_link_speed_index(network_fc)
        assert idx[("1", "2")] == pytest.approx(50.0)
        assert idx[("2", "3")] == pytest.approx(90.0)

    def test_missing_speed_skipped(self):
        feat = _net_feature("1", "2", 50.0, 100.0, 500.0)
        del feat["properties"]["speed"]
        network_fc = _make_fc([feat])
        idx = _build_link_speed_index(network_fc)
        assert ("1", "2") not in idx


class TestBoundaryLinkSpeed:
    def _speed_idx(self):
        return {("A", "B"): 50.0, ("B", "C"): 90.0, ("C", "D"): 120.0}

    def test_zone_to_node_uses_second_edge(self):
        # path: [Z_zone, A, B, C]  → entry edge A→B
        speed = _boundary_link_speed(["Z_x", "A", "B", "C"], "zone", "node", self._speed_idx())
        assert speed == pytest.approx(50.0)

    def test_node_to_zone_uses_second_to_last_edge(self):
        # path: [A, B, C, Z_zone]  → exit edge B→C
        speed = _boundary_link_speed(["A", "B", "C", "Z_x"], "node", "zone", self._speed_idx())
        assert speed == pytest.approx(90.0)

    def test_zone_to_zone_uses_entry_edge(self):
        # path: [Z_x, A, B, Z_y]  → entry edge A→B
        speed = _boundary_link_speed(["Z_x", "A", "B", "Z_y"], "zone", "zone", self._speed_idx())
        assert speed == pytest.approx(50.0)

    def test_path_too_short_returns_none(self):
        # path only 2 nodes: no real network edge exists
        speed = _boundary_link_speed(["Z_x", "A"], "zone", "node", self._speed_idx())
        assert speed is None

    def test_link_not_in_index_returns_none(self):
        speed = _boundary_link_speed(["Z_x", "X", "Y", "Z"], "zone", "node", self._speed_idx())
        assert speed is None


class TestApplyExternalTtCorrection:
    """Unit tests for _apply_external_tt_correction."""

    def _feat(self, from_type, to_type, routes):
        """Build a minimal GeoJSON feature dict."""
        return {
            "properties": {
                "fromType": from_type,
                "toType": to_type,
                "routes": routes,
            }
        }

    def _route(self, tt, trips, path=None):
        return {"travelTime": tt, "trips": trips, "nodePath": path or []}

    # ------------------------------------------------------------------
    # Basic: internal trips unchanged, external trips corrected
    # ------------------------------------------------------------------

    def test_internal_trip_not_changed(self):
        features = [
            self._feat("node", "node", [self._route(600.0, 10.0)]),
        ]
        _apply_external_tt_correction(features, 1800.0, {}, None)
        # Internal trip travel time must not be touched
        assert features[0]["properties"]["routes"][0]["travelTime"] == pytest.approx(600.0)

    def test_external_trip_gets_flat_correction(self):
        # Internal avg tt = 600 s; target = 1800 s → correction = 1200 s
        features = [
            self._feat("node", "node", [self._route(600.0, 10.0)]),
            self._feat("node", "zone", [self._route(500.0, 5.0, ["A", "B", "C", "Z_z"])]),
        ]
        _apply_external_tt_correction(features, 1800.0, {}, None)
        # external route: 500 + 1200 = 1700
        assert features[1]["properties"]["routes"][0]["travelTime"] == pytest.approx(1700.0)

    def test_no_correction_when_avg_exceeds_target(self):
        # Internal avg tt = 2400 s > target 1800 s → correction = 0 (only increase)
        features = [
            self._feat("node", "node", [self._route(2400.0, 10.0)]),
            self._feat("zone", "node", [self._route(500.0, 5.0, ["Z_z", "A", "B", "C"])]),
        ]
        original_tt = features[1]["properties"]["routes"][0]["travelTime"]
        _apply_external_tt_correction(features, 1800.0, {}, None)
        assert features[1]["properties"]["routes"][0]["travelTime"] == pytest.approx(original_tt)

    def test_no_internal_trips_no_correction(self):
        # No internal trips → avg_tt = 0 → correction = target - 0... actually applies
        # But here we just check that avg_tt=0 → correction=target when there are no internal
        features = [
            self._feat("node", "zone", [self._route(100.0, 5.0, ["A", "B", "C", "Z_z"])]),
        ]
        _apply_external_tt_correction(features, 1800.0, {}, None)
        # correction_base = max(0, 1800 - 0) = 1800
        assert features[0]["properties"]["routes"][0]["travelTime"] == pytest.approx(1900.0)

    # ------------------------------------------------------------------
    # Speed-based scaling
    # ------------------------------------------------------------------

    def test_speed_scaling_faster_road_gets_more_correction(self):
        # Internal avg = 600 s, target = 1800 s → base = 1200 s, ref = 70 km/h
        # Route A (node→zone): path=["A","B","C","Z_z"] → last real edge B→C = 140 km/h
        #   corr = 1200 * 140/70 = 2400 → tt = 500 + 2400 = 2900
        # Route B (node→zone): path=["X","Y","Z_z2"] → last real edge X→Y = 50 km/h
        #   corr = 1200 * 50/70 ≈ 857 → tt = 500 + 857 ≈ 1357
        speed_idx = {("B", "C"): 140.0, ("X", "Y"): 50.0}
        features = [
            self._feat("node", "node", [self._route(600.0, 10.0)]),
            self._feat("node", "zone", [self._route(500.0, 5.0, ["A", "B", "C", "Z_z"])]),
            self._feat("node", "zone", [self._route(500.0, 5.0, ["X", "Y", "Z_z2"])]),
        ]
        _apply_external_tt_correction(features, 1800.0, speed_idx, 70.0)
        tt_fast = features[1]["properties"]["routes"][0]["travelTime"]
        tt_slow = features[2]["properties"]["routes"][0]["travelTime"]
        assert tt_fast > tt_slow
        assert tt_fast == pytest.approx(500.0 + 1200.0 * 140.0 / 70.0, rel=1e-4)
        assert tt_slow == pytest.approx(500.0 + 1200.0 * 50.0 / 70.0, rel=1e-4)

    def test_speed_scaling_fallback_when_link_not_found(self):
        # Boundary link not in speed_idx → fallback to flat correction_base
        speed_idx: dict = {}
        features = [
            self._feat("node", "node", [self._route(600.0, 10.0)]),
            self._feat("zone", "node", [self._route(200.0, 3.0, ["Z_z", "A", "B", "C"])]),
        ]
        _apply_external_tt_correction(features, 1800.0, speed_idx, 70.0)
        # base = 1200; link not found → flat 1200
        assert features[1]["properties"]["routes"][0]["travelTime"] == pytest.approx(1400.0)

    def test_weighted_average_respects_trips(self):
        # Two internal routes: 300 s × 10 trips, 900 s × 10 trips → avg = 600 s
        # target = 1800 → base = 1200
        features = [
            self._feat("node", "node", [self._route(300.0, 10.0), self._route(900.0, 10.0)]),
            self._feat("node", "zone", [self._route(0.0, 1.0, ["A", "B", "C", "Z_z"])]),
        ]
        _apply_external_tt_correction(features, 1800.0, {}, None)
        assert features[1]["properties"]["routes"][0]["travelTime"] == pytest.approx(1200.0)
