"""SQL builder for feedlink_fetcher — identical mapping to feedlink_creator."""

from __future__ import annotations

# None → no Spectrum voedingslinks table for this mode
VOEDINGSLINKS_TABLE: dict[str, str | None] = {
    "CAR":        "d110_voedingslinks",
    "BIKE":       "d120_voedingslinks",
    "PEDESTRIAN": None,
    "BUS":        "d140_voedingslinks",
    "TRAM":       "d140_voedingslinks",
    "METRO":      "d140_voedingslinks",
    "TRAIN":      "d140_voedingslinks",
}


def build_voedingslinks_sql(
    catalog: str,
    schema: str,
    table: str,
    gids: list,
) -> str:
    """Return a SELECT statement for the given zone gids."""
    where = (
        "WHERE FALSE"
        if not gids
        else "WHERE van_centroid_gid IN (" + ", ".join(str(int(g)) for g in gids) + ")"
    )
    return (
        f"SELECT van_centroid_gid,\n"
        f"       naar_knoop_id,\n"
        f"       wkt_geom_4326\n"
        f"FROM `{catalog}`.`{schema}`.{table}\n"
        f"{where}"
    )
