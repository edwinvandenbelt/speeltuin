"""Unit tests for bidirectional_splitter core — pure Python, no I/O."""

from __future__ import annotations

import pytest

from bidirectional_splitter.core.bidirectional_splitter_core import (
    _estimate_capacity,
    post_process_features,
)
from shared.displacer import (
    _NEAR_NODE_M,
    _NEAR_NODE_M_MED,
    _NEAR_NODE_M_SHT,
    _OFFSET_M,
    _OFFSET_M_BIKE,
    _OPPOSITE_HEADING_TOL,
    _OPPOSITE_SEARCH_M,
    assign_reverse_link_ids,
    heading,
    offset_linestring,
)


# ---------------------------------------------------------------------------
# _estimate_capacity
# ---------------------------------------------------------------------------


class TestEstimateCapacity:
    def test_returns_none_when_speed_is_none(self):
        assert _estimate_capacity(None, 2) is None

    def test_uses_one_lane_when_lanes_none(self):
        result = _estimate_capacity(80, None)
        assert result == 1800.0

    def test_speed_30_gives_1500_per_lane(self):
        assert _estimate_capacity(30, 1) == 1500.0

    def test_speed_50_gives_1700_per_lane(self):
        assert _estimate_capacity(50, 1) == 1700.0

    def test_speed_80_gives_1800_per_lane(self):
        assert _estimate_capacity(80, 1) == 1800.0

    def test_speed_130_gives_2200_per_lane(self):
        assert _estimate_capacity(130, 1) == 2200.0

    def test_two_lanes_doubles_result(self):
        single = _estimate_capacity(80, 1)
        double = _estimate_capacity(80, 2)
        assert double == pytest.approx(single * 2)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_raw_feature(
    seg_id: int,
    coords: list,
    *,
    heen: bool = True,
    terug: bool = True,
    flow_heen: float = 100.0,
    flow_terug: float = 80.0,
    mode: str = "CAR",
) -> dict:
    """Construct a raw feature as returned by rows_to_feature_collection."""
    return {
        "type":     "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId":            seg_id,
            "mode":              mode,
            "fromNode":         1,
            "toNode":           2,
            "rijrichting_heen":  heen,
            "cap_heen":          2000,
            "rijstroken_heen":   2,
            "max_snelheid_heen": 80,
            "rijrichting_terug": terug,
            "cap_terug":         2000,
            "rijstroken_terug":  2,
            "max_snelheid_terug": 80,
            "length":            100.0,
            "flow_heen":  {"work": flow_heen, "recreational": 0, "education": 0,
                           "shopping": 0, "unknown": 0},
            "flow_terug": {"work": flow_terug, "recreational": 0, "education": 0,
                           "shopping": 0, "unknown": 0},
            "flow_dp_heen":  {"mrh": 60.0, "erh": 50.0, "rest": 30.0},
            "flow_dp_terug": {"mrh": 45.0, "erh": 40.0, "rest": 25.0},
        },
    }


_COORDS_NS = [[4.0, 52.0], [4.0, 52.1]]
_COORDS_EW = [[4.0, 52.0], [4.1, 52.0]]


# ---------------------------------------------------------------------------
# post_process_features
# ---------------------------------------------------------------------------


class TestPostProcessFeatures:
    def test_bidir_produces_two_features(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        assert len(result) == 2

    def test_heen_only_produces_one_feature(self):
        features = [_make_raw_feature(1, _COORDS_NS, terug=False)]
        result = post_process_features(features)
        assert len(result) == 1

    def test_terug_only_produces_one_feature(self):
        features = [_make_raw_feature(1, _COORDS_NS, heen=False)]
        result = post_process_features(features)
        assert len(result) == 1

    def test_neither_direction_omitted(self):
        features = [_make_raw_feature(1, _COORDS_NS, flow_heen=0.0, flow_terug=0.0)]
        result = post_process_features(features)
        assert len(result) == 0

    def test_bidir_opposite_ids_set(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        ids = {r["properties"]["spectrumId"] for r in result}
        assert 1 in ids
        assert -1 in ids
        for r in result:
            assert r["properties"]["reverseLinkIds"] is not None

    def test_heading_present(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            h = r["properties"]["heading"]
            assert 0.0 <= h < 360.0

    def test_flow24hrs_computed(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            assert r["properties"]["flow24hrs"] > 0
            assert r["properties"]["flow"] > 0
            assert isinstance(r["properties"]["flowsPerMotive"], dict)

    def test_flow_temporal_unit_is_24(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            assert r["properties"]["flowTemporalUnit"] == 24

    def test_flows_per_daypart_present(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            dp = r["properties"]["flowsPerDaypart"]
            assert isinstance(dp, dict)
            assert set(dp.keys()) == {"mrh", "erh", "rest"}

    def test_terug_only_geometry_reversed(self):
        features = [_make_raw_feature(1, _COORDS_NS, heen=False)]
        result = post_process_features(features)
        coords = result[0]["geometry"]["coordinates"]
        assert coords[0] == pytest.approx(_COORDS_NS[-1], abs=1e-9)

    def test_empty_input(self):
        assert post_process_features([]) == []

    def test_multiple_features_processed(self):
        features = [
            _make_raw_feature(1, _COORDS_NS),
            _make_raw_feature(2, _COORDS_EW),
        ]
        result = post_process_features(features)
        assert len(result) == 4  # 2 bidir × 2 directions


# ---------------------------------------------------------------------------
# Offset distance per mode
# ---------------------------------------------------------------------------

# A 300 m north-going link gives enough length for interior vertices to be
# fully offset (clear of the near-node taper zone).
_LAT_PER_M  = 1.0 / 111_320.0
_COORDS_300M_N = [[4.0, 52.0], [4.0, 52.0 + 300 * _LAT_PER_M]]

import math as _math
_D_LON = 111_320.0 * _math.cos(_math.radians(52.0))


def _mid_lon_offset(features: list, direction: str) -> float:
    """Return the longitude offset of the midpoint of the *direction* feature
    relative to the original centreline (lon 4.0)."""
    feat = next(f for f in features if f["properties"].get("heading", 0) < 180)
    if direction == "terug":
        feat = next(f for f in features if f["properties"].get("heading", 0) >= 180)
    coords = feat["geometry"]["coordinates"]
    mid = coords[len(coords) // 2]
    return (mid[0] - 4.0) * _D_LON   # convert lon-degrees → metres


class TestBikeOffset:
    def test_bike_bidir_uses_bike_offset(self):
        """BIKE bidirectional links are offset by _OFFSET_M_BIKE, not _OFFSET_M."""
        features = [_make_raw_feature(1, _COORDS_300M_N, mode="BIKE")]
        result = post_process_features(features)
        assert len(result) == 2
        off = _mid_lon_offset(result, "heen")
        assert off == pytest.approx(_OFFSET_M_BIKE, abs=0.05)

    def test_car_bidir_still_uses_car_offset(self):
        """CAR bidirectional links keep the original _OFFSET_M offset."""
        features = [_make_raw_feature(1, _COORDS_300M_N, mode="CAR")]
        result = post_process_features(features)
        assert len(result) == 2
        off = _mid_lon_offset(result, "heen")
        assert off == pytest.approx(_OFFSET_M, abs=0.05)

    def test_bike_offset_smaller_than_car_offset(self):
        """Sanity: BIKE separation is narrower than CAR separation."""
        assert _OFFSET_M_BIKE < _OFFSET_M

    def test_bike_heen_only_not_offset(self):
        """One-directional BIKE links are not offset (same as CAR)."""
        features = [_make_raw_feature(1, _COORDS_300M_N, terug=False, mode="BIKE")]
        result = post_process_features(features)
        assert len(result) == 1
        coords = result[0]["geometry"]["coordinates"]
        mid = coords[len(coords) // 2]
        assert mid[0] == pytest.approx(4.0, abs=1e-9)
