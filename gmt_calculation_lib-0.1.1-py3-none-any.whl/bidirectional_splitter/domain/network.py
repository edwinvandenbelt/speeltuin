"""Bidirectional→unidirectional link splitting — no I/O, no boto3.

Converts raw bidirectional network links (as returned by the Databricks network query)
into directed, unidirectional GeoJSON features.  Each bidirectional link yields two
directed features with laterally offset geometries.  Links with flow in only one
direction yield a single directed feature.  Links with no flow in either direction
are dropped.

Logic
-----
- heen AND terug with flow → 2 directed features (geometries offset left/right)
- heen only with flow      → 1 directed feature  (geometry unchanged)
- terug only with flow     → 1 directed feature  (coordinates reversed)
- neither direction        → 0 features (dropped)
"""

from __future__ import annotations

import logging

from shared.displacer import (
    _MEDIAN_HALF_M,
    _OFFSET_M_BIKE_EXTRA,
    _OFFSET_M_BIKE_ONEWAY_SNAPPED,
    _OFFSET_M_BIKE_STANDALONE,
    _OFFSET_M_CAR,
    _OFFSET_M_FOOT_EXTRA,
    assign_reverse_link_ids,
    heading,
    offset_linestring,
)

logger = logging.getLogger(__name__)


def _estimate_capacity(speed: float | None, lanes: int | None) -> float | None:
    """Estimate per-direction capacity (pae/hr) when the raw value is null or zero.

    Returns ``None`` when *speed* is also unavailable so callers can distinguish
    "estimated" from "truly unknown".
    """
    if speed is None:
        return None
    n = lanes or 1
    if speed <= 30:
        per_lane = 1500
    elif speed <= 50:
        per_lane = 1700
    elif speed <= 60:
        per_lane = 1750
    elif speed <= 80:
        per_lane = 1800
    elif speed <= 100:
        per_lane = 2100
    else:
        per_lane = 2200
    return float(per_lane * n)


# Ordered list of property keys on every directed Feature produced by post_process_features.
# Used by the runner to overwrite fc["properties"]["fields"] after splitting.
DIRECTED_LINK_PROPERTIES: tuple[str, ...] = (
    "spectrumId",
    "linkId",
    "fromNode",
    "toNode",
    "capacity",
    "lanes",
    "speed",
    "flow",
    "flowsPerMotive",
    "flow24hrs",
    "flowTemporalUnit",
    "flowsPerDaypart",
    "length",
    "mode",
    "remainingCap",
    "heading",
    "reverseLinkIds",
    "carLinkIds",
    "carOneway",
    "highway",
    "ref",
    "name",
)


def post_process_features(features: list) -> list:
    """Split bidirectional links into two directed links and rename fields.

    Parameters
    ----------
    features:
        Raw Feature list as returned by ``rows_to_feature_collection``.
        Each feature has flat ``rijrichting_heen`` / ``rijrichting_terug`` flags
        and nested ``flow_heen`` / ``flow_terug`` dicts.

    Returns
    -------
    list
        Directed Feature list.  ``reverseLinkIds`` is populated for all features
        by a spatial KD-tree pass at the end (``assign_reverse_link_ids``).
    """
    result = []
    logger.debug("Post-processing %d raw features", len(features))

    for feat in features:
        geom = feat["geometry"]
        gtype = geom["type"]
        coords = geom["coordinates"]
        p = feat["properties"]

        rr_heen = bool(p.get("rijrichting_heen"))
        rr_terug = bool(p.get("rijrichting_terug"))
        flow_heen_dict = p.get("flow_heen") or {}
        flow_terug_dict = p.get("flow_terug") or {}

        # Direction logic:
        # - Empty flow dict {} (missing or no flow data yet)  → fall back to rijrichting flags.
        #   NOTE: OSM CAR features carry flow_heen={} from the fetcher; BIKE features
        #   carry {"unknown": 1} per passable direction.  Databricks features carry
        #   a full motive-keyed dict (possibly all zeros for unassigned links).
        # - Non-empty dict, sum > 0 (active flow)  → keep that direction.
        # - Non-empty dict, sum = 0 (zero flow)    → drop that direction.
        has_flow_data = bool(flow_heen_dict) or bool(flow_terug_dict)
        if has_flow_data:
            heen = rr_heen and sum(flow_heen_dict.values()) > 0
            terug = rr_terug and sum(flow_terug_dict.values()) > 0
        else:
            heen = rr_heen
            terug = rr_terug

        seg_id = p.get("linkId")
        mode = p.get("mode")
        from_node = p.get("fromNode")
        to_node = p.get("toNode")

        def _heen_props(sid):
            flow = p.get("flow_heen") or {}
            total = sum(flow.values())
            dp = p.get("flow_dp_heen") or {"mrh": 0, "erh": 0, "rest": 0}
            peak = max(dp.values()) if dp else 0.0
            raw_cap = p.get("cap_heen")
            capacity = (
                raw_cap
                if raw_cap is not None and raw_cap > 0
                else _estimate_capacity(p.get("max_snelheid_heen"), p.get("rijstroken_heen"))
            )
            flow_for_cap = peak if peak > 0.0 else (total / 12.0 if total > 0.0 else 0.0)
            remaining = (capacity - flow_for_cap) if (capacity is not None) else None
            return {
                "spectrumId": sid,
                "linkId": sid,
                "fromNode": from_node,
                "toNode": to_node,
                "capacity": capacity,
                "lanes": p.get("rijstroken_heen"),
                "speed": p.get("max_snelheid_heen"),
                "flow": total,
                "flowsPerMotive": flow,
                "flow24hrs": total,
                "flowTemporalUnit": 24,
                "flowsPerDaypart": dp,
                "length": p.get("length"),
                "mode": mode,
                "remainingCap": remaining,
                "carLinkIds": p.get("carLinkIds") or [],
                "carOneway": bool(p.get("carOneway")),
                "highway": p.get("highway", ""),
                "ref": p.get("ref", ""),
                "name": p.get("name", ""),
            }

        def _terug_props(sid):
            flow = p.get("flow_terug") or {}
            total = sum(flow.values())
            dp = p.get("flow_dp_terug") or {"mrh": 0, "erh": 0, "rest": 0}
            peak = max(dp.values()) if dp else 0.0
            raw_cap = p.get("cap_terug")
            capacity = (
                raw_cap
                if raw_cap is not None and raw_cap > 0
                else _estimate_capacity(p.get("max_snelheid_terug"), p.get("rijstroken_terug"))
            )
            flow_for_cap = peak if peak > 0.0 else (total / 12.0 if total > 0.0 else 0.0)
            remaining = (capacity - flow_for_cap) if (capacity is not None) else None
            return {
                "spectrumId": sid,
                "linkId": sid,
                "fromNode": to_node,  # flipped
                "toNode": from_node,  # flipped
                "capacity": capacity,
                "lanes": p.get("rijstroken_terug"),
                "speed": p.get("max_snelheid_terug"),
                "flow": total,
                "flowsPerMotive": flow,
                "flow24hrs": total,
                "flowTemporalUnit": 24,
                "flowsPerDaypart": dp,
                "length": p.get("length"),
                "mode": mode,
                "remainingCap": remaining,
                "carLinkIds": p.get("carLinkIds") or [],
                "carOneway": bool(p.get("carOneway")),
                "highway": p.get("highway", ""),
                "ref": p.get("ref", ""),
                "name": p.get("name", ""),
            }

        neg_id = -seg_id if isinstance(seg_id, (int, float)) else f"-{seg_id}"

        if heen and terug:
            # Bidirectionele weg — laterale offset per mode (vanuit middenlijn):
            #
            #   BIKE snapped, twee-richtingsautoweg (7.5 m totaal):
            #     voetpad (4.75m) — fietspad (3.75m) — auto (2.25m) — [middenberm 0.50m]
            #                     — auto (2.25m) — fietspad (3.75m) — voetpad (4.75m)
            #
            #   BIKE snapped, één-richtingsautoweg (5.0 m totaal):
            #     fietspad (2.5m) — auto (0m) — fietspad (2.5m)
            #
            #   BIKE solitair (niet op autoweg, 1.0 m totaal):
            #     fietspad (0.5m) — [middenpunt] — fietspad (0.5m)
            _base = _OFFSET_M_CAR + _MEDIAN_HALF_M  # 2.25 m
            if mode == "PEDESTRIAN":
                off = _base + _OFFSET_M_BIKE_EXTRA + _OFFSET_M_FOOT_EXTRA  # 4.75 m
            elif mode == "BIKE":
                snapped = bool(p.get("carLinkIds"))
                if snapped:
                    off = (
                        _OFFSET_M_BIKE_ONEWAY_SNAPPED  # 2.5 m — één-richtingsweg
                        if p.get("carOneway")
                        else _base + _OFFSET_M_BIKE_EXTRA  # 3.75 m — twee-richtingsweg
                    )
                else:
                    off = _OFFSET_M_BIKE_STANDALONE  # 0.5 m — solitair fietspad
            else:
                off = _base  # 2.25 m  (CAR / overig)
            heen_coords = offset_linestring(coords, off)
            terug_coords = offset_linestring(list(reversed(coords)), off)
            result.append(
                {
                    "type": "Feature",
                    "id": seg_id,
                    "geometry": {"type": gtype, "coordinates": heen_coords},
                    "properties": {
                        **_heen_props(seg_id),
                        "heading": heading(heen_coords),
                        "reverseLinkIds": [neg_id],
                    },
                }
            )
            result.append(
                {
                    "type": "Feature",
                    "id": neg_id,
                    "geometry": {"type": gtype, "coordinates": terug_coords},
                    "properties": {
                        **_terug_props(neg_id),
                        "heading": heading(terug_coords),
                        "reverseLinkIds": [seg_id],
                    },
                }
            )

        elif heen:
            result.append(
                {
                    "type": "Feature",
                    "id": seg_id,
                    "geometry": geom,
                    "properties": {
                        **_heen_props(seg_id),
                        "heading": heading(coords),
                        "reverseLinkIds": [],
                    },
                }
            )

        elif terug:
            terug_coords = list(reversed(coords))
            result.append(
                {
                    "type": "Feature",
                    "id": neg_id,
                    "geometry": {"type": gtype, "coordinates": terug_coords},
                    "properties": {
                        **_terug_props(neg_id),
                        "heading": heading(terug_coords),
                        "reverseLinkIds": [],
                    },
                }
            )
        # else: neither direction — omit

    assign_reverse_link_ids(result)
    logger.debug(
        "Post-processing complete: %d input → %d output features",
        len(features),
        len(result),
    )
    return result
