"""Bidirectional→unidirectional link splitting — no I/O, no boto3.

Converts raw bidirectional network links (as returned by the Databricks network query)
into directed, unidirectional GeoJSON features.  Each bidirectional link yields two
directed features with laterally offset geometries.  Links with flow in only one
direction yield a single directed feature.  Links with no flow in either direction
are dropped.

Logic
-----
- heen AND terug with flow → 2 directed features (geometries offset left/right)
- heen only with flow      → 1 directed feature  (geometry unchanged)
- terug only with flow     → 1 directed feature  (coordinates reversed)
- neither direction        → 0 features (dropped)
"""

from __future__ import annotations

import logging

from shared.displacer import (
    _OFFSET_M,
    assign_reverse_link_ids,
    heading,
    offset_linestring,
)

logger = logging.getLogger(__name__)


def _estimate_capacity(speed: float | None, lanes: int | None) -> float | None:
    """Estimate per-direction capacity (pae/hr) when the raw Databricks value is null.

    Returns ``None`` when *speed* is also unavailable so callers can distinguish
    "estimated" from "truly unknown".
    """
    if speed is None:
        return None
    n = lanes or 1
    if speed <= 30:
        per_lane = 1500
    elif speed <= 50:
        per_lane = 1700
    elif speed <= 60:
        per_lane = 1750
    elif speed <= 80:
        per_lane = 1800
    elif speed <= 100:
        per_lane = 2100
    else:
        per_lane = 2200
    return float(per_lane * n)


# Ordered list of property keys on every directed Feature produced by post_process_features.
# Used by the runner to overwrite fc["properties"]["fields"] after splitting.
DIRECTED_LINK_PROPERTIES: tuple[str, ...] = (
    "spectrumId",
    "linkId",
    "fromNode",
    "toNode",
    "capacity",
    "lanes",
    "speed",
    "flow",
    "flowsPerMotive",
    "flow24hrs",
    "flowTemporalUnit",
    "flowsPerDaypart",
    "length",
    "mode",
    "remainingCap",
    "heading",
    "reverseLinkIds",
)


def post_process_features(features: list) -> list:
    """Split bidirectional links into two directed links and rename fields.

    Parameters
    ----------
    features:
        Raw Feature list as returned by ``rows_to_feature_collection``.
        Each feature has flat ``rijrichting_heen`` / ``rijrichting_terug`` flags
        and nested ``flow_heen`` / ``flow_terug`` dicts.

    Returns
    -------
    list
        Directed Feature list.  ``reverseLinkIds`` is populated for all features
        by a spatial KD-tree pass at the end (``assign_reverse_link_ids``).
    """
    result = []
    logger.debug("Post-processing %d raw features", len(features))

    for feat in features:
        geom   = feat["geometry"]
        gtype  = geom["type"]
        coords = geom["coordinates"]
        p      = feat["properties"]

        heen  = bool(p.get("rijrichting_heen"))  and sum((p.get("flow_heen")  or {}).values()) > 0
        terug = bool(p.get("rijrichting_terug")) and sum((p.get("flow_terug") or {}).values()) > 0

        seg_id    = p.get("linkId")
        mode      = p.get("mode")
        from_node = p.get("fromNode")
        to_node   = p.get("toNode")

        def _heen_props(sid):
            flow = p.get("flow_heen") or {}
            total = sum(flow.values())
            dp = p.get("flow_dp_heen") or {"mrh": 0, "erh": 0, "rest": 0}
            peak = max(dp.values()) if dp else 0.0
            raw_cap = p.get("cap_heen")
            capacity = raw_cap if raw_cap is not None else _estimate_capacity(
                p.get("max_snelheid_heen"), p.get("rijstroken_heen")
            )
            remaining = (capacity - peak) if (capacity is not None) else None
            return {
                "spectrumId":       sid,
                "linkId":           sid,
                "fromNode":         from_node,
                "toNode":           to_node,
                "capacity":         capacity,
                "lanes":            p.get("rijstroken_heen"),
                "speed":            p.get("max_snelheid_heen"),
                "flow":             total,
                "flowsPerMotive":   flow,
                "flow24hrs":        total,
                "flowTemporalUnit": 24,
                "flowsPerDaypart":  dp,
                "length":           p.get("length"),
                "mode":             mode,
                "remainingCap":     remaining,
            }

        def _terug_props(sid):
            flow = p.get("flow_terug") or {}
            total = sum(flow.values())
            dp = p.get("flow_dp_terug") or {"mrh": 0, "erh": 0, "rest": 0}
            peak = max(dp.values()) if dp else 0.0
            raw_cap = p.get("cap_terug")
            capacity = raw_cap if raw_cap is not None else _estimate_capacity(
                p.get("max_snelheid_terug"), p.get("rijstroken_terug")
            )
            remaining = (capacity - peak) if (capacity is not None) else None
            return {
                "spectrumId":       sid,
                "linkId":           sid,
                "fromNode":         to_node,    # flipped
                "toNode":           from_node,  # flipped
                "capacity":         capacity,
                "lanes":            p.get("rijstroken_terug"),
                "speed":            p.get("max_snelheid_terug"),
                "flow":             total,
                "flowsPerMotive":   flow,
                "flow24hrs":        total,
                "flowTemporalUnit": 24,
                "flowsPerDaypart":  dp,
                "length":           p.get("length"),
                "mode":             mode,
                "remainingCap":     remaining,
            }

        neg_id = (-seg_id if isinstance(seg_id, (int, float)) else f"-{seg_id}")

        if heen and terug:
            heen_coords  = offset_linestring(coords, _OFFSET_M)
            terug_coords = offset_linestring(list(reversed(coords)), _OFFSET_M)
            result.append({
                "type":       "Feature",
                "id":         seg_id,
                "geometry":   {"type": gtype, "coordinates": heen_coords},
                "properties": {**_heen_props(seg_id),
                               "heading":        heading(heen_coords),
                               "reverseLinkIds": [neg_id]},
            })
            result.append({
                "type":       "Feature",
                "id":         neg_id,
                "geometry":   {"type": gtype, "coordinates": terug_coords},
                "properties": {**_terug_props(neg_id),
                               "heading":        heading(terug_coords),
                               "reverseLinkIds": [seg_id]},
            })

        elif heen:
            result.append({
                "type":       "Feature",
                "id":         seg_id,
                "geometry":   geom,
                "properties": {**_heen_props(seg_id),
                               "heading":        heading(coords),
                               "reverseLinkIds": []},
            })

        elif terug:
            terug_coords = list(reversed(coords))
            result.append({
                "type":       "Feature",
                "id":         neg_id,
                "geometry":   {"type": gtype, "coordinates": terug_coords},
                "properties": {**_terug_props(neg_id),
                               "heading":        heading(terug_coords),
                               "reverseLinkIds": []},
            })
        # else: neither direction — omit

    assign_reverse_link_ids(result)
    logger.debug(
        "Post-processing complete: %d input → %d output features",
        len(features), len(result),
    )
    return result
