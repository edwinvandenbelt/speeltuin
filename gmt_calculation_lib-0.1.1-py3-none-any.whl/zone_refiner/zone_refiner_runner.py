"""Local debug runner for zone_refiner.

Calls zone_refiner_core.refine_zones() directly — no Lambda handler involved.

Usage
-----
    # Read from local files, write to a new file:
    python -m zone_refiner.zone_refiner_runner \\
        --zones  /tmp/myarea-ZONE-BIKE.parquet \\
        --network /tmp/myarea-NETWORK-BIKE.parquet \\
        --output  /tmp/myarea-ZONE-BIKE-refined.parquet

    # Overwrite the zones file in-place (omit --output):
    python -m zone_refiner.zone_refiner_runner \\
        --zones  /tmp/myarea-ZONE-BIKE.parquet \\
        --network /tmp/myarea-NETWORK-BIKE.parquet

    # Read from / write to S3:
    python -m zone_refiner.zone_refiner_runner \\
        --zones   s3://gmp-networks/myarea-ZONE-BIKE.parquet \\
        --network s3://gmp-networks/myarea-NETWORK-BIKE.parquet \\
        --output  s3://gmp-networks/myarea-ZONE-BIKE-refined.parquet

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for
  s3:// URIs).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for zone_refiner (calls core directly).",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--zones",
        required=True,
        metavar="URI",
        help="Full URI of the zone GeoParquet to refine (s3:// or local path).",
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="Full URI of the network GeoParquet used as split-line candidates.",
    )
    parser.add_argument(
        "--output",
        default=None,
        metavar="URI",
        help=(
            "Output URI for the refined zones GeoParquet. "
            "Defaults to overwriting the --zones input."
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # ── Load .env ─────────────────────────────────────────────────────────────
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from zone_refiner.core.zone_refiner_core import refine_zones  # noqa: PLC0415
    from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

    # ── Read inputs ───────────────────────────────────────────────────────────
    print(f"Reading zones   : {args.zones}")
    zones_fc = from_geoparquet(_read_uri(args.zones))

    print(f"Reading network : {args.network}")
    network_fc = from_geoparquet(_read_uri(args.network))

    # ── Refine ────────────────────────────────────────────────────────────────
    refined_fc, stats = refine_zones(zones_fc, network_fc)

    # ── Write output ──────────────────────────────────────────────────────────
    out_uri = args.output or args.zones
    print(f"Writing output  : {out_uri}")
    _write_uri(out_uri, to_geoparquet(refined_fc))

    print()
    print(
        f"  inputZones={stats['inputZones']}  outputZones={stats['outputZones']}  "
        f"splitZones={stats['splitZones']}  unsplitZones={stats['unsplitZones']}"
    )


if __name__ == "__main__":
    main()
