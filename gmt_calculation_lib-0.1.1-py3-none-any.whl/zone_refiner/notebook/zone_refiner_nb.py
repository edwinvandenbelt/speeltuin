# Databricks notebook source
# ---------------------------------------------------------------------------
# zone_refiner_nb.py — Databricks notebook interface for zone refinement.
#
# This notebook:
#   1. Reads widget parameters (zones_uri, network_uri, output_uri).
#   2. Reads the zone and network GeoJSON files (s3:// or local path).
#   3. Calls pure core function (refine_zones) — no Spark I/O.
#   4. Writes the refined zone GeoJSON to output_uri
#      (defaults to overwriting zones_uri when output_uri is empty).
#   5. Prints a summary of split / unsplit zones.
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("zone_refiner_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "zones_uri", "",
    "Full URI of the zone GeoJSON to refine (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "network_uri", "",
    "Full URI of the network GeoJSON used as split-line candidates (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri", "",
    "Output URI for refined zones (leave empty to overwrite zones_uri)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from zone_refiner.core.zone_refiner_core import refine_zones

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

ZONES_URI = dbutils.widgets.get("zones_uri").strip()  # noqa: F821
NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip() or ZONES_URI  # noqa: F821

if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty — provide a full URI to the zone GeoJSON.")
if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty — provide a full URI to the network GeoJSON.")

logger.info("zones_uri=%s", ZONES_URI)
logger.info("network_uri=%s", NETWORK_URI)
logger.info("output_uri=%s", OUTPUT_URI)

# COMMAND ----------
# ── S3 helpers ────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Zone Refiner
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
_created = _t_start.isoformat()

print(f"Starting     {_created}")
print(f"Zones URI  : {ZONES_URI}")
print(f"Network URI: {NETWORK_URI}")
print(f"Output URI : {OUTPUT_URI}")
print()

_raw_zones = _read_uri(ZONES_URI)
_zones_fc = json.loads(_raw_zones)
logger.info("Loaded %d zone features", len(_zones_fc.get("features") or []))

_raw_network = _read_uri(NETWORK_URI)
_network_fc = json.loads(_raw_network)
logger.info("Loaded %d network features", len(_network_fc.get("features") or []))

_refined_fc, _stats = refine_zones(_zones_fc, _network_fc)

_payload = json.dumps(_refined_fc, ensure_ascii=False).encode("utf-8")
_write_uri(OUTPUT_URI, _payload)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("Zone refinement complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"Zone refiner complete — {_total_elapsed:.1f}s total")
print(_SEP)
print()
print(f"  inputZones   : {_stats['inputZones']}")
print(f"  outputZones  : {_stats['outputZones']}")
print(f"  splitZones   : {_stats['splitZones']}")
print(f"  unsplitZones : {_stats['unsplitZones']}")
print()
print(f"  Output       : {OUTPUT_URI}  ({len(_payload):,} bytes)")
print(_SEP)
