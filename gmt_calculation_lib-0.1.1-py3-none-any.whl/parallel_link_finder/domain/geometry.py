"""Geometry helpers for parallel_link_finder: centroids, vertices, sub-links, and KD-tree mapping."""

from __future__ import annotations

import numpy as np

from shared.kd_tree import KDTree2D


def get_link_centroids(
    links: np.ndarray,
    lengths: list[float],
    xys: list[list[list[float]]],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Compute the midpoint centroid and direction for each link."""
    clinks, clinkxys, clinkdxys = [], [], []

    for i in range(len(links)):
        hlength = 0.0
        for j in range(len(xys[i]) - 1):
            if not (xys[i][j][0] == xys[i][j + 1][0] and xys[i][j][1] == xys[i][j + 1][1]):
                mx = (xys[i][j][0] + xys[i][j + 1][0]) / 2
                my = (xys[i][j][1] + xys[i][j + 1][1]) / 2
                dx = xys[i][j + 1][0] - xys[i][j][0]
                dy = xys[i][j + 1][1] - xys[i][j][1]
                hlength += np.sqrt(dx ** 2 + dy ** 2)
                if hlength > lengths[i] / 2:
                    clinks.append(i)
                    clinkxys.append([mx, my])
                    clinkdxys.append([dx, dy])
                    break

    clinks = np.array(clinks)
    clinkxys = np.array(clinkxys)
    clinkdxys = np.array(clinkdxys)

    clengths = np.sqrt(clinkdxys[:, 0] ** 2 + clinkdxys[:, 1] ** 2)
    clinkdxys[:, 0] /= clengths
    clinkdxys[:, 1] /= clengths

    return clinks, clinkxys, clinkdxys


def get_vertices(
    links: np.ndarray,
    xys: list[list[list[float]]],
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Split link geometries into individual straight-line segments (vertices)."""
    vertlinks, vertxys1, vertxys2 = [], [], []

    for i in range(len(links)):
        for j in range(len(xys[i]) - 1):
            if not (xys[i][j][0] == xys[i][j + 1][0] and xys[i][j][1] == xys[i][j + 1][1]):
                vertlinks.append(i)
                vertxys1.append(xys[i][j])
                vertxys2.append(xys[i][j + 1])

    vertlinks = np.array(vertlinks)
    vertxys1 = np.array(vertxys1)
    vertxys2 = np.array(vertxys2)

    vertlengths = np.sqrt(
        (vertxys1[:, 0] - vertxys2[:, 0]) ** 2 + (vertxys1[:, 1] - vertxys2[:, 1]) ** 2
    )

    vertdxys = np.zeros((len(vertlinks), 2))
    vertdxys[:, 0] = (vertxys2[:, 0] - vertxys1[:, 0]) / vertlengths
    vertdxys[:, 1] = (vertxys2[:, 1] - vertxys1[:, 1]) / vertlengths

    return vertlinks, vertlengths, vertxys1, vertdxys


def get_sublinks(
    vertlinks: np.ndarray,
    vertlengths: np.ndarray,
    vertxys1: np.ndarray,
    vertdxys: np.ndarray,
    maxlength_sublink: float,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Subdivide line segments into regularly spaced sub-links."""
    sublinks, sublengths = [], []
    subxys, subdxys = [], []

    for i in range(len(vertlinks)):
        nsub = int(vertlengths[i] / maxlength_sublink) + 1
        for j in range(nsub):
            f = (j + 0.5) / nsub
            sublinks.append(vertlinks[i])
            sublengths.append(vertlengths[i] / nsub)
            subxys.append(vertxys1[i, :] + f * vertlengths[i] * vertdxys[i, :])
            subdxys.append(vertdxys[i])

    return (
        np.array(sublinks),
        np.array(sublengths),
        np.array(subxys),
        np.array(subdxys),
    )


def map1to2(
    links1: np.ndarray,
    sublinks1: np.ndarray,
    sublinks2: np.ndarray,
    subxys1: np.ndarray,
    subxys2: np.ndarray,
    subdxys1: np.ndarray,
    subdxys2: np.ndarray,
    mapped: np.ndarray,
    maxlength_sublink: float,
    maxdist: float,
    maxalpha: float,
    nnb: int,
    map_direction: str,
    map_on_self: bool,
    use_parallel_distance: bool,
) -> tuple[np.ndarray, np.ndarray]:
    """Map sub-links from network 1 onto network 2 using a k-d tree."""
    ckd_tree = KDTree2D(subxys2)
    dist, idx = ckd_tree.query(subxys1, k=nnb)

    mininprod = np.cos(maxalpha * np.pi / 180)
    index1 = np.array([], dtype=int)
    index2 = np.array([], dtype=int)

    for i in range(nnb):
        if map_direction == "both":
            inprod = np.abs(
                subdxys1[:, 0] * subdxys2[idx[:, i], 0]
                + subdxys1[:, 1] * subdxys2[idx[:, i], 1]
            )
        elif map_direction == "opposite":
            inprod = -(
                subdxys1[:, 0] * subdxys2[idx[:, i], 0]
                + subdxys1[:, 1] * subdxys2[idx[:, i], 1]
            )
        else:
            inprod = (
                subdxys1[:, 0] * subdxys2[idx[:, i], 0]
                + subdxys1[:, 1] * subdxys2[idx[:, i], 1]
            )

        dxys12 = np.zeros((len(idx), 2))
        dxys12[:, 0] = subxys2[idx[:, i], 0] - subxys1[:, 0]
        dxys12[:, 1] = subxys2[idx[:, i], 1] - subxys1[:, 1]
        dist_parallel = np.abs(
            subdxys1[:, 0] * dxys12[:, 0] + subdxys1[:, 1] * dxys12[:, 1]
        )

        if use_parallel_distance:
            if map_on_self:
                hindex = np.where(
                    (mapped == 0)
                    & (dist_parallel <= maxlength_sublink / 2)
                    & (dist[:, i] <= maxdist)
                    & (inprod >= mininprod)
                    & (links1[sublinks1] != links1[sublinks2[idx[:, i]]])
                )[0]
            else:
                hindex = np.where(
                    (mapped == 0)
                    & (dist_parallel <= maxlength_sublink / 2)
                    & (dist[:, i] <= maxdist)
                    & (inprod >= mininprod)
                )[0]
        else:
            if map_on_self:
                hindex = np.where(
                    (mapped == 0)
                    & (dist[:, i] <= maxdist)
                    & (inprod >= mininprod)
                    & (links1[sublinks1] != links1[sublinks2[idx[:, i]]])
                )[0]
            else:
                hindex = np.where(
                    (mapped == 0) & (dist[:, i] <= maxdist) & (inprod >= mininprod)
                )[0]

        index1 = np.concatenate((index1, hindex))
        index2 = np.concatenate((index2, idx[hindex, i]))
        mapped[hindex] = 1

    return index1, index2
