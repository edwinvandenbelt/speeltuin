"""Core orchestrator for parallel_link_finder. Delegates to domain modules."""

from __future__ import annotations

from collections import defaultdict

try:
    import numpy as np
except ImportError as _np_err:
    raise ImportError(
        "numpy is required for parallel_link_finder. "
        "Install it with: pip install gmt-calculation-lib[prepare]"
    ) from _np_err

from parallel_link_finder.domain.geometry import (
    get_link_centroids,
    get_vertices,
    get_sublinks,
    map1to2,
)
from parallel_link_finder.domain.network import get_links_spectrum

#: Fields added to every link feature by this module.
PARALLEL_LINK_PROPERTIES: tuple[str, ...] = (
    "parallelLinkIds",
    "reverseLinkIds",
)


def find_parallel_links(
    geojson_network: dict,
    maxlength_sublink: float = 5,
    maxdist: float = 20,
    maxalpha: float = 15,
) -> tuple[dict, dict]:
    """Enrich a directed GeoJSON network with parallelLinkIds and reverseLinkIds."""
    links_raw, lengths, xys = get_links_spectrum(geojson_network)
    links = np.array(links_raw)

    clinks, clinkxys, clinkdxys = get_link_centroids(links, lengths, xys)
    vertlinks, vertlengths, vertxys1, vertdxys = get_vertices(links, xys)
    sublinks, sublengths, subxys, subdxys = get_sublinks(
        vertlinks, vertlengths, vertxys1, vertdxys, maxlength_sublink
    )

    nnb = 10
    use_parallel_distance = True
    map_on_self = True

    mapped = np.zeros(len(clinks), dtype=int)
    index1_parallel, index2_parallel = map1to2(
        links, clinks, sublinks,
        clinkxys, subxys, clinkdxys, subdxys, mapped,
        maxlength_sublink, maxdist, maxalpha,
        nnb, "same", map_on_self, use_parallel_distance,
    )

    mapped = np.zeros(len(clinks), dtype=int)
    index1_reverse, index2_reverse = map1to2(
        links, clinks, sublinks,
        clinkxys, subxys, clinkdxys, subdxys, mapped,
        maxlength_sublink, maxdist, maxalpha,
        nnb, "opposite", map_on_self, use_parallel_distance,
    )

    parallel_map: dict = defaultdict(list)
    reverse_map: dict = defaultdict(list)

    for i in range(len(index1_parallel)):
        link = links[clinks[index1_parallel[i]]]
        link_parallel = links[sublinks[index2_parallel[i]]]
        parallel_map[link].append(int(link_parallel))

    for i in range(len(index1_reverse)):
        link = links[clinks[index1_reverse[i]]]
        link_reverse = links[sublinks[index2_reverse[i]]]
        reverse_map[link].append(int(link_reverse))

    enriched = 0
    skipped = 0
    for feature in geojson_network["features"]:
        link_id = feature["properties"].get("linkId")
        if link_id is None:
            skipped += 1
            continue
        feature["properties"]["parallelLinkIds"] = parallel_map.get(link_id, [])
        existing_reverse: list = feature["properties"].get("reverseLinkIds") or []
        kdtree_reverse = reverse_map.get(link_id, [])
        seen: set = set(existing_reverse)
        merged = list(existing_reverse)
        for rid in kdtree_reverse:
            if rid not in seen:
                seen.add(rid)
                merged.append(rid)
        feature["properties"]["reverseLinkIds"] = merged
        enriched += 1

    # Ensure the output FC's $.properties.link_properties includes the new fields.
    out_props = dict(geojson_network.get("properties") or {})
    existing = list(out_props.get("link_properties") or [])
    for field in PARALLEL_LINK_PROPERTIES:
        if field not in existing:
            existing.append(field)
    out_props["link_properties"] = existing
    geojson_network["properties"] = out_props

    stats = {"features_enriched": enriched, "features_skipped": skipped}
    return geojson_network, stats


__all__ = [
    "PARALLEL_LINK_PROPERTIES",
    "find_parallel_links",
    "get_link_centroids",
    "get_vertices",
    "get_sublinks",
    "map1to2",
    "get_links_spectrum",
]
