"""Pure-Python network_fuser core — no I/O, no boto3, no external deps.

Designed to run on the **pre-split** (undirected) network — i.e. before
``bidirectional_splitter`` has created directed link pairs.  At that stage
each link carries a ``"mode"`` property (``"CAR"`` or ``"BIKE"``) directly
from the network fetcher, and ``fromNode`` / ``toNode`` properties identify
shared junction points.

Purpose
-------
For each BIKE link that likely shares the car roadway — determined by
``wegtype`` not being in ``_EXCLUDED_WEGTYPES`` and the car road having a
speed limit below ``_SPEED_LIMIT_MAX_KMH`` — the fuser finds the matching
CAR link based on geometric overlap and **replaces the entire BIKE geometry**
with the CAR geometry.  This makes the BIKE and CAR geometries topologically
identical before the ``bidirectional_splitter`` applies per-direction lateral
displacements.

Matching algorithm (buffer + overlap)
--------------------------------------
1. Each link (BIKE and CAR) is subdivided into sub-links of approximately
   ``sublink_length_m`` metres.  The midpoint and unit-direction of each
   sub-link are computed in RD New (EPSG:28992) coordinates.
2. A KD-tree is built from all eligible CAR sub-link midpoints.
3. All BIKE sub-link midpoints are queried against the tree in a single batch
   to retrieve the ``_NNB`` nearest CAR sub-links per BIKE sub-link.
4. For each BIKE sub-link the closest CAR sub-link that passes both tests is
   recorded as a match:

   a. **Proximity** — midpoint distance ≤ ``max_lateral_dist_m``.
   b. **Direction** — ``|dot(bike_dir, car_dir)| ≥ cos(max_heading_diff_deg)``.
      The absolute dot-product accepts both parallel and anti-parallel links.

   Each BIKE sub-link is matched to at most one CAR link (the nearest
   valid candidate).

5. For each eligible BIKE link the number of its sub-links that matched each
   CAR link is accumulated.  The CAR link with the highest count is selected
   as the best match.
6. If ``best_match_count / total_bike_sublinks ≥ min_overlap_fraction`` the
   geometries are fused: the BIKE feature's WGS-84 coordinates are replaced
   with the CAR feature's coordinates (reversed when the two links run in
   opposite directions).

Node propagation
----------------
Replacing a BIKE geometry moves its junction nodes.  Any other BIKE link
that shares the same ``fromNode`` or ``toNode`` has its corresponding
endpoint coordinate updated automatically, keeping the network
topologically consistent.

Public API
----------
fuse_networks(fc, *, max_lateral_dist_m, max_heading_diff_deg,
              min_overlap_fraction, sublink_length_m, excluded_wegtypes)
    -> tuple[dict, list[dict], list[dict], dict]
    Returns (fc_corrected, node_map=[], link_pairs, stats).
"""

from __future__ import annotations

import logging
import math
from collections import defaultdict

import numpy as np

try:
    from scipy.spatial import cKDTree as _KDTree
except ImportError:
    from shared.kd_tree import KDTree2D as _KDTree  # type: ignore[assignment]

from shared.rd_projection import wgs84_to_rd

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# BIKE link ``wegtype`` values that represent standalone / pedestrian
# infrastructure.  Links with these values are never matched to a CAR link.
_EXCLUDED_WEGTYPES: frozenset[str] = frozenset({
    "solitair_onverplicht_fietspad",
    "pedelecfietspad",
    "solitair_fietspad",
    "solitair_bromfietspad",
    "fietsstraat",
    "veerpont",
    "voetgangersgebied_fietsen_toegestaan",
    "voetgangersgebied",
    "voetgangersdoorsteekje",
})

# CAR links with a legal speed at or above this value (km/h) are never matched.
_SPEED_LIMIT_MAX_KMH: int = 60

# Default matching parameters.
_DEFAULT_BUFFER_M:             float = 10.0  # lateral buffer for sub-link matching
_DEFAULT_MAX_HEADING_DIFF_DEG: float = 30.0  # direction-alignment threshold (degrees)
_DEFAULT_MIN_OVERLAP_FRACTION: float = 0.60  # min fraction of bike sub-links matched
_DEFAULT_SUBLINK_LENGTH_M:     float = 5.0   # target sub-link length (metres)

# Number of nearest CAR sub-links to inspect per BIKE sub-link.
_NNB: int = 10


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_link_id(props: dict) -> str:
    """Return the canonical link identifier from a feature's properties."""
    return str(props.get("linkId") or props.get("spectrumId") or "")


def _car_speed_ok(props: dict) -> bool:
    """True when the CAR link's legal speed is below ``_SPEED_LIMIT_MAX_KMH``."""
    s_h = float(props.get("max_snelheid_heen")  or 0)
    s_t = float(props.get("max_snelheid_terug") or 0)
    return max(s_h, s_t) < _SPEED_LIMIT_MAX_KMH


def _to_rd_coords(wgs84_coords: list) -> list[tuple[float, float]]:
    """Project a WGS-84 coordinate list to RD New (EPSG:28992) tuples."""
    return [wgs84_to_rd(float(c[0]), float(c[1])) for c in wgs84_coords]


def _sublinks_for_link(
    rd_coords: list[tuple[float, float]],
    sublink_len: float,
) -> tuple[np.ndarray, np.ndarray]:
    """Compute sub-link midpoints and unit directions for a polyline in RD New.

    Each straight segment of the polyline is divided into
    ``int(seg_len / sublink_len) + 1`` equal pieces.  Returns
    ``(midpoints, directions)`` where both arrays have shape ``(N, 2)``
    (N = total sub-links across all segments).  If the polyline is degenerate
    (zero total length), empty ``(0, 2)`` arrays are returned.
    """
    midpoints: list[list[float]] = []
    directions: list[list[float]] = []

    for i in range(len(rd_coords) - 1):
        ax, ay = rd_coords[i]
        bx, by = rd_coords[i + 1]
        dx, dy = bx - ax, by - ay
        seg_len = math.hypot(dx, dy)
        if seg_len < 1e-9:
            continue
        ux, uy = dx / seg_len, dy / seg_len
        nsub = int(seg_len / sublink_len) + 1
        for j in range(nsub):
            f = (j + 0.5) / nsub
            midpoints.append([ax + f * dx, ay + f * dy])
            directions.append([ux, uy])

    if not midpoints:
        return np.empty((0, 2), dtype=float), np.empty((0, 2), dtype=float)
    return np.array(midpoints, dtype=float), np.array(directions, dtype=float)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def fuse_networks(
    fc: dict,
    *,
    max_lateral_dist_m:   float = _DEFAULT_BUFFER_M,
    max_heading_diff_deg: float = _DEFAULT_MAX_HEADING_DIFF_DEG,
    min_overlap_fraction: float = _DEFAULT_MIN_OVERLAP_FRACTION,
    sublink_length_m:     float = _DEFAULT_SUBLINK_LENGTH_M,
    excluded_wegtypes:    frozenset[str] | None = None,
) -> tuple[dict, list[dict], list[dict], dict]:
    """Replace BIKE link geometries with the matching CAR link geometry.

    Parameters
    ----------
    fc:
        Merged multi-mode FeatureCollection.  Each feature must carry a
        ``"mode"`` property (``"CAR"`` or ``"BIKE"``).
    max_lateral_dist_m:
        Maximum lateral distance (RD New metres) between a BIKE sub-link
        midpoint and a CAR sub-link midpoint for them to count as a match.
        Default: 10.0.
    max_heading_diff_deg:
        Maximum heading difference (degrees) between a BIKE sub-link direction
        and a CAR sub-link direction.  The absolute dot-product is used, so
        both parallel and anti-parallel orientations are accepted within this
        angle.  Default: 30.0.
    min_overlap_fraction:
        Minimum fraction of BIKE sub-links that must find a matching CAR
        sub-link for the BIKE link to be fused onto the best-matching CAR link.
        Default: 0.60.
    sublink_length_m:
        Target length (metres) of each sub-link used for the overlap check.
        Smaller values give finer resolution but increase computation.
        Default: 5.0.
    excluded_wegtypes:
        BIKE ``wegtype`` values to skip.  ``None`` uses ``_EXCLUDED_WEGTYPES``.
        Pass ``frozenset()`` to disable the filter entirely.

    Returns
    -------
    fc:
        The input FeatureCollection with BIKE link geometries replaced in-place
        where matches were found.  The ``bidirectional_splitter`` that follows
        will apply per-direction lateral displacements.
    node_map:
        Always ``[]`` — kept for API compatibility.
    link_pairs:
        ``[{"carLinkId": …, "bikeLinkId": …, "isReverse": …,
            "chainLength": 1}, …]``
    stats:
        ``{"car_links", "bike_links", "bike_eligible", "link_pairs",
           "skipped_wegtype", "skipped_speed", "reverse_matches",
           "fused_bike"}``
    """
    _excluded = _EXCLUDED_WEGTYPES if excluded_wegtypes is None else excluded_wegtypes
    features  = fc.get("features") or []

    # ── A: split by mode ────────────────────────────────────────────────────
    car_features:  list[dict] = []
    bike_features: list[dict] = []
    for feat in features:
        mode = (feat.get("properties") or {}).get("mode", "")
        if mode == "CAR":
            car_features.append(feat)
        elif mode == "BIKE":
            bike_features.append(feat)

    if not car_features or not bike_features:
        logger.info(
            "fuse_networks: single-mode input (car=%d, bike=%d) — no-op.",
            len(car_features), len(bike_features),
        )
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   0,
            "link_pairs":      0,
            "skipped_wegtype": 0,
            "skipped_speed":   0,
            "reverse_matches": 0,
            "fused_bike":      0,
        }

    # ── B: pre-process eligible BIKE links ──────────────────────────────────
    # bike_entries[i] = (link_id, ax_rd, ay_rd, bx_rd, by_rd, rd_coords, wgs84_coords)
    bike_entries: list[tuple] = []
    n_skipped_wt = 0

    for feat in bike_features:
        props  = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        if props.get("wegtype") in _excluded:
            n_skipped_wt += 1
            continue
        link_id = _get_link_id(props)
        rd = _to_rd_coords(coords)
        ax, ay = rd[0]
        bx, by = rd[-1]
        bike_entries.append((link_id, ax, ay, bx, by, rd, coords))

    if not bike_entries:
        logger.info("fuse_networks: no eligible BIKE links after wegtype filter — no-op.")
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   0,
            "link_pairs":      0,
            "skipped_wegtype": n_skipped_wt,
            "skipped_speed":   0,
            "reverse_matches": 0,
            "fused_bike":      0,
        }

    # ── C: pre-process eligible CAR links ───────────────────────────────────
    # car_entries[i] = (link_id, ax_rd, ay_rd, bx_rd, by_rd, rd_coords, wgs84_coords)
    car_entries:    list[tuple] = []
    n_skipped_speed = 0

    for feat in car_features:
        props  = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        if not _car_speed_ok(props):
            n_skipped_speed += 1
            continue
        link_id = _get_link_id(props)
        rd = _to_rd_coords(coords)
        ax, ay = rd[0]
        bx, by = rd[-1]
        car_entries.append((link_id, ax, ay, bx, by, rd, coords))

    if not car_entries:
        logger.info("fuse_networks: no eligible CAR links after speed filter — no-op.")
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   len(bike_entries),
            "link_pairs":      0,
            "skipped_wegtype": n_skipped_wt,
            "skipped_speed":   n_skipped_speed,
            "reverse_matches": 0,
            "fused_bike":      0,
        }

    # ── D: build CAR sub-links ───────────────────────────────────────────────
    # Build flat arrays of all CAR sub-link midpoints and directions, with an
    # index array that maps each sub-link back to its car_entry index.
    car_sub_mids_list: list[np.ndarray] = []
    car_sub_dirs_list: list[np.ndarray] = []
    car_sub_ci_list:   list[int]        = []

    for ci, c_entry in enumerate(car_entries):
        mids, dirs = _sublinks_for_link(c_entry[5], sublink_length_m)
        if len(mids) == 0:
            continue
        car_sub_mids_list.append(mids)
        car_sub_dirs_list.append(dirs)
        car_sub_ci_list.extend([ci] * len(mids))

    if not car_sub_mids_list:
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   len(bike_entries),
            "link_pairs":      0,
            "skipped_wegtype": n_skipped_wt,
            "skipped_speed":   n_skipped_speed,
            "reverse_matches": 0,
            "fused_bike":      0,
        }

    all_car_mids   = np.vstack(car_sub_mids_list)         # (M_car, 2)
    all_car_dirs   = np.vstack(car_sub_dirs_list)         # (M_car, 2)
    car_sub_ci_arr = np.array(car_sub_ci_list, dtype=int) # (M_car,)

    # ── E: build BIKE sub-links ──────────────────────────────────────────────
    bike_sub_mids_list: list[np.ndarray] = []
    bike_sub_dirs_list: list[np.ndarray] = []
    bike_sub_bi_list:   list[int]        = []
    bike_total_subs:    list[int]        = []   # total sub-links per bike_entry

    for bi, b_entry in enumerate(bike_entries):
        mids, dirs = _sublinks_for_link(b_entry[5], sublink_length_m)
        n = len(mids)
        bike_total_subs.append(n)
        if n == 0:
            continue
        bike_sub_mids_list.append(mids)
        bike_sub_dirs_list.append(dirs)
        bike_sub_bi_list.extend([bi] * n)

    if not bike_sub_mids_list:
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   len(bike_entries),
            "link_pairs":      0,
            "skipped_wegtype": n_skipped_wt,
            "skipped_speed":   n_skipped_speed,
            "reverse_matches": 0,
            "fused_bike":      0,
        }

    all_bike_mids   = np.vstack(bike_sub_mids_list)          # (N_bike, 2)
    all_bike_dirs   = np.vstack(bike_sub_dirs_list)          # (N_bike, 2)
    bike_sub_bi_arr = np.array(bike_sub_bi_list, dtype=int)  # (N_bike,)

    # ── F: KD-tree query ─────────────────────────────────────────────────────
    # For each BIKE sub-link find the nearest CAR sub-links and record the
    # closest valid match (proximity + direction).  Each BIKE sub-link
    # contributes at most 1 to the match count of any (bike_entry, car_entry)
    # pair (we stop at the first valid candidate, similar to map1to2).
    tree = _KDTree(all_car_mids)
    nnb  = min(_NNB, len(all_car_mids))
    dists, idxs = tree.query(all_bike_mids, k=nnb)

    # Normalise to 2-D (scipy returns 1-D when k=1).
    if dists.ndim == 1:
        dists = dists[:, np.newaxis]
        idxs  = idxs[:, np.newaxis]

    cos_max = math.cos(math.radians(max_heading_diff_deg))

    # by_bike[bi][ci] = number of bike sub-links from bike entry bi that
    # found their best match in car entry ci.
    by_bike: dict[int, dict[int, int]] = defaultdict(lambda: defaultdict(int))

    # Track which bike sub-links have already been matched (first valid hit wins).
    already_matched = np.zeros(len(all_bike_mids), dtype=bool)

    for k in range(nnb):
        dist_col = dists[:, k]
        idx_col  = idxs[:, k]

        # Direction check: |dot(bike_dir, car_dir)| ≥ cos_max
        car_dirs_k = all_car_dirs[idx_col]       # (N_bike, 2)
        dots = np.abs(
            all_bike_dirs[:, 0] * car_dirs_k[:, 0]
            + all_bike_dirs[:, 1] * car_dirs_k[:, 1]
        )

        mask = (
            (~already_matched)
            & (dist_col <= max_lateral_dist_m)
            & (dots >= cos_max)
        )

        if not np.any(mask):
            continue

        valid_sub_si = np.where(mask)[0]
        valid_ci     = car_sub_ci_arr[idx_col[mask]]

        for sub_si, ci_v in zip(valid_sub_si.tolist(), valid_ci.tolist()):
            by_bike[int(bike_sub_bi_arr[sub_si])][ci_v] += 1

        already_matched[mask] = True

        if np.all(already_matched):
            break  # every bike sub-link has been matched

    # ── G: select best CAR link per BIKE link ────────────────────────────────
    # best_car[bi] = car_entry index  (only entries that meet overlap threshold)
    best_car: dict[int, int] = {}

    for bi, car_counts in by_bike.items():
        best_ci  = max(car_counts, key=car_counts.__getitem__)
        best_cnt = car_counts[best_ci]
        total    = bike_total_subs[bi]
        if total > 0 and best_cnt / total >= min_overlap_fraction:
            best_car[bi] = best_ci

    # ── H: build node-to-BIKE mapping for node propagation ──────────────────
    node_to_bike: dict[str, list[tuple[dict, int]]] = defaultdict(list)
    for feat in bike_features:
        props     = feat.get("properties") or {}
        from_node = str(props.get("fromNode") or "")
        to_node   = str(props.get("toNode")   or "")
        coords    = (feat.get("geometry") or {}).get("coordinates") or []
        if from_node and coords:
            node_to_bike[from_node].append((feat, 0))
        if to_node and coords:
            node_to_bike[to_node].append((feat, -1))

    # ── I: apply geometry replacements ──────────────────────────────────────
    link_pairs:        list[dict]      = []
    bike_replacements: dict[str, list] = {}   # link_id → new wgs84 coords
    bike_is_reverse:   dict[str, bool] = {}

    for bi, ci in best_car.items():
        b_entry = bike_entries[bi]
        c_entry = car_entries[ci]

        b_lid          = b_entry[0]
        bax, bay       = b_entry[1], b_entry[2]
        bbx, bby       = b_entry[3], b_entry[4]
        c_lid          = c_entry[0]
        cax, cay       = c_entry[1], c_entry[2]
        cbx, cby       = c_entry[3], c_entry[4]
        c_wgs84_coords = c_entry[6]

        # Determine direction by overall link heading (endpoint → endpoint).
        is_reverse = (
            (bbx - bax) * (cbx - cax) + (bby - bay) * (cby - cay)
        ) < 0

        new_coords = (
            list(reversed(c_wgs84_coords)) if is_reverse else list(c_wgs84_coords)
        )
        bike_replacements[b_lid] = [list(c) for c in new_coords]
        bike_is_reverse[b_lid]   = is_reverse
        link_pairs.append({
            "carLinkId":   c_lid,
            "bikeLinkId":  b_lid,
            "isReverse":   is_reverse,
            "chainLength": 1,
        })

    # ── J: apply replacements and propagate moved junction nodes ─────────────
    n_fused = 0
    updated_nodes: dict[str, list[float]] = {}

    for feat in bike_features:
        props  = feat.get("properties") or {}
        b_lid  = _get_link_id(props)
        new_coords = bike_replacements.get(b_lid)
        if new_coords is None:
            continue

        from_node = str(props.get("fromNode") or "")
        to_node   = str(props.get("toNode")   or "")

        feat["geometry"]["coordinates"] = new_coords
        n_fused += 1

        if from_node:
            new_start = new_coords[0]
            if from_node not in updated_nodes:
                updated_nodes[from_node] = new_start
                for other_feat, ci_n in node_to_bike.get(from_node, []):
                    other_coords = (other_feat.get("geometry") or {}).get("coordinates") or []
                    if other_coords:
                        other_coords[ci_n] = list(new_start)

        if to_node:
            new_end = new_coords[-1]
            if to_node not in updated_nodes:
                updated_nodes[to_node] = new_end
                for other_feat, ci_n in node_to_bike.get(to_node, []):
                    other_coords = (other_feat.get("geometry") or {}).get("coordinates") or []
                    if other_coords:
                        other_coords[ci_n] = list(new_end)

    stats = {
        "car_links":       len(car_features),
        "bike_links":      len(bike_features),
        "bike_eligible":   len(bike_entries),
        "link_pairs":      len(link_pairs),
        "skipped_wegtype": n_skipped_wt,
        "skipped_speed":   n_skipped_speed,
        "reverse_matches": sum(1 for lp in link_pairs if lp["isReverse"]),
        "fused_bike":      n_fused,
    }
    logger.info(
        "fuse_networks: car=%d  bike_eligible=%d  "
        "link_pairs=%d  fused=%d  skipped(wt=%d speed=%d)",
        len(car_features), len(bike_entries),
        len(link_pairs), n_fused, n_skipped_wt, n_skipped_speed,
    )
    return fc, [], link_pairs, stats
