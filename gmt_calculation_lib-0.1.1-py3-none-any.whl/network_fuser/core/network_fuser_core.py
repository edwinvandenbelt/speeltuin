"""Pure-Python network_fuser core — no I/O, no boto3, no external deps.

For each directed CAR link, finds all BIKE links that run alongside it in the
same direction and within a configurable lateral distance.  This is a
**link-trace** match — no node-ID matching is performed.

Standalone / pedestrian BIKE infrastructure (``excluded_wegtypes``) is
excluded from all matching.

One-way road handling
---------------------
A CAR link is considered **one-way** when its ``reverseLinkIds`` property is
absent or empty.  On a one-way road, cyclists are legally allowed to travel in
both directions, so BIKE links running in the **opposite** direction are also
eligible for matching.  Their ``isReverse`` flag is set to ``True`` in the
returned ``link_pairs``.

Algorithm
---------
A. Split features by mode (CAR, BIKE, other).  Single-mode → no-op.
B. Pre-process eligible BIKE links: compute heading and RD New coordinates
   (start, end, midpoint).  Links with an excluded ``wegtype`` are skipped.
C. Build ``KDTree2D`` on BIKE link midpoints (RD New).
D. For each CAR link:
   1. Detect whether the link is one-way (``reverseLinkIds`` empty/absent).
   2. Compute CAR heading and RD New coordinates.
   3. Query the ``_K_CANDIDATES`` nearest BIKE midpoints from the KDTree.
      Stop iterating once a result exceeds the search radius
      (``max_lateral_dist_m`` + ``_SEARCH_RADIUS_EXTRA``).
   4. For each candidate:
      a. Check heading difference:
         - Two-way road: skip if heading diff > ``max_heading_diff_deg``.
         - One-way road: also accept the opposite direction
           (``180° − diff ≤ max_heading_diff_deg``); record ``isReverse=True``.
      b. Compute the **average** perpendicular distance from three sampled
         points on the BIKE link (start, mid, end) to the **infinite** CAR
         line.
      c. Skip if average distance > ``max_lateral_dist_m``.
      d. Record as a link pair.
E. **Geometry correction**: for each matched BIKE link, find the *snap region*
   — the contiguous range of **intermediate** BIKE vertices (indices 1..n-2;
   endpoints are always preserved) whose projection onto the CAR axis falls
   within ``[0, L_car]``.  Replace those vertices with the full CAR geometry
   offset laterally by ``_SNAP_OFFSET_M`` (0.5 m) always to the **right of
   the BIKE's own travel direction**.  ``avgLateralDistM`` is recorded in
   ``link_pairs`` for reference but is not used as a shift.  BIKE vertices
   outside the snap region are kept unchanged.  A BIKE link with fewer than
   three coordinates (no intermediate vertices) is never snapped.

Public API
----------
fuse_networks(fc, *, max_lateral_dist_m, max_heading_diff_deg,
              excluded_wegtypes)
    -> tuple[dict, list[dict], list[dict], dict]
    Returns (fc_corrected, node_map=[], link_pairs, stats).
    ``fc_corrected`` is the same object as the input ``fc`` but with
    BIKE link geometries updated in-place where matches were found.
"""

from __future__ import annotations

import logging
import math
from collections import defaultdict

import numpy as np

from shared.kd_tree import KDTree2D
from shared.rd_projection import wgs84_to_rd

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# BIKE link ``wegtype`` values that represent standalone / pedestrian
# infrastructure.  Links with these values are never matched to a CAR link.
_EXCLUDED_WEGTYPES: frozenset[str] = frozenset({
    "solitair_onverplicht_fietspad",
    "pedelecfietspad",
    "solitair_fietspad",
    "solitair_bromfietspad",
    "fietsstraat",
    "veerpont",
    "voetgangersgebied_fietsen_toegestaan",
    "voetgangersgebied",
    "voetgangersdoorsteekje",
})

# Extra search radius (metres) added to max_lateral_dist_m when pre-filtering
# via the KDTree.  Accommodates the longitudinal offset between the midpoints
# of two links that only partially overlap.
_SEARCH_RADIUS_EXTRA: float = 250.0

# Maximum BIKE-link candidates to inspect per CAR link.  Raise this constant
# if very dense networks log "all candidates within radius" warnings.
_K_CANDIDATES: int = 100

# WGS84 scale constants (Netherlands, lat ≈ 52°) used for geometry correction.
_LAT_SCALE: float = 111320.0           # metres per degree latitude
_LON_SCALE: float = 111320.0 * math.cos(math.radians(52.0))  # m/deg longitude

# Fixed lateral offset applied to snapped BIKE intermediate vertices.
# The BIKE geometry follows the CAR road shape but is placed this many metres
# to the side (towards the BIKE's measured side of the road).
_SNAP_OFFSET_M: float = 0.5


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_link_id(props: dict) -> str:
    """Return the canonical link identifier from a feature's properties."""
    return str(props.get("linkId") or props.get("spectrumId") or "")


def _link_heading(coords: list) -> float:
    """Compass bearing 0–360° (0 = N, 90 = E) from first to last coord.

    Uses a flat-earth approximation accurate to well under 0.1° anywhere in
    the Netherlands.
    """
    lon0, lat0 = float(coords[0][0]),  float(coords[0][1])
    lon1, lat1 = float(coords[-1][0]), float(coords[-1][1])
    lat_mid_r  = math.radians((lat0 + lat1) / 2)
    dx = (lon1 - lon0) * math.cos(lat_mid_r)
    dy = lat1 - lat0
    return math.degrees(math.atan2(dx, dy)) % 360


def _heading_diff(h1: float, h2: float) -> float:
    """Minimum angular difference between two compass headings (result: 0–180°)."""
    diff = abs(h1 - h2) % 360
    return min(diff, 360.0 - diff)


def _pt_to_line_dist_rd(
    px: float,
    py: float,
    ax: float,
    ay: float,
    bx: float,
    by: float,
) -> float:
    """Perpendicular distance from point P to the *infinite* line through A-B (RD metres).

    When A == B the distance degenerates to |PA|.
    """
    dx = bx - ax
    dy = by - ay
    length = math.hypot(dx, dy)
    if length == 0.0:
        return math.hypot(px - ax, py - ay)
    return abs(dx * (py - ay) - dy * (px - ax)) / length


def _lateral_side(
    bike_mid_x: float,
    bike_mid_y: float,
    car_ax: float,
    car_ay: float,
    car_bx: float,
    car_by: float,
) -> float:
    """Return +1.0 if the BIKE midpoint is to the *left* of the directed CAR
    line A→B, or −1.0 if to the right.

    All coordinates must be in the same physical coordinate system (e.g.
    RD New metres, or WGS84 degrees scaled to metres).
    """
    cross = (car_bx - car_ax) * (bike_mid_y - car_ay) - (car_by - car_ay) * (bike_mid_x - car_ax)
    return 1.0 if cross >= 0.0 else -1.0


def _compute_snap_region(
    bike_wgs: list,
    car_wgs: list,
    lon_sc: float,
    lat_sc: float,
) -> tuple[int, int] | None:
    """Return the range of BIKE intermediate vertices (indices 1..n-2) that
    project within the CAR link's longitudinal extent.

    Projection is computed along the axis from ``car_wgs[0]`` to
    ``car_wgs[-1]`` in WGS84-scaled physical metres (using ``lon_sc`` and
    ``lat_sc``).

    Returns ``(snap_start_idx, snap_end_idx)`` — both inclusive — or ``None``
    when no intermediate BIKE vertex falls within the extent.  The first and
    last BIKE vertices (network node positions) are never included.
    """
    if len(bike_wgs) < 3:
        return None  # no intermediate vertices to snap

    car_a_lon = float(car_wgs[0][0])
    car_a_lat = float(car_wgs[0][1])
    car_dx    = (float(car_wgs[-1][0]) - car_a_lon) * lon_sc
    car_dy    = (float(car_wgs[-1][1]) - car_a_lat) * lat_sc
    car_L     = math.hypot(car_dx, car_dy)
    if car_L == 0.0:
        return None

    vx = car_dx / car_L
    vy = car_dy / car_L

    first_in: int | None = None
    last_in:  int | None = None

    for i in range(1, len(bike_wgs) - 1):
        rel_x = (float(bike_wgs[i][0]) - car_a_lon) * lon_sc
        rel_y = (float(bike_wgs[i][1]) - car_a_lat) * lat_sc
        proj  = rel_x * vx + rel_y * vy
        if 0.0 <= proj <= car_L:
            if first_in is None:
                first_in = i
            last_in = i

    if first_in is None or last_in is None:
        return None
    return (first_in, last_in)


def _build_snapped_segment(
    car_wgs: list,
    is_reverse: bool,
    d_m: float,
    lon_sc: float,
    lat_sc: float,
) -> list[list[float]]:
    """Build a laterally offset copy of the CAR geometry.

    Each CAR vertex is displaced perpendicular to the local tangent direction
    by ``d_m`` metres, always to the **right of the BIKE's travel direction**.
    When ``is_reverse`` is ``True`` the coordinate sequence is reversed so that
    the sequence is already oriented in the BIKE's travel direction; the offset
    is then to the right of that reversed sequence.

    "Right of travel" is computed as ``effective_side = -1.0`` applied to the
    left-perpendicular unit vector ``(−dy, +dx)``, which yields ``(+dy, −dx)``.
    ``lon_sc`` and ``lat_sc`` are WGS84 scale factors (metres per degree).
    """
    coords_seq = list(reversed(car_wgs)) if is_reverse else list(car_wgs)
    # Always offset to the RIGHT of the BIKE's travel direction.
    # The sequence is already oriented in the BIKE's direction (reversed if
    # needed), so right-of-travel = negate the left-perpendicular vector.
    effective_side = -1.0
    n              = len(coords_seq)
    result: list[list[float]] = []

    for i in range(n):
        lon = float(coords_seq[i][0])
        lat = float(coords_seq[i][1])
        # Local tangent: previous→next; at endpoints use the only neighbour.
        prev_i   = max(0, i - 1)
        next_i   = min(n - 1, i + 1)
        phys_dx  = (float(coords_seq[next_i][0]) - float(coords_seq[prev_i][0])) * lon_sc
        phys_dy  = (float(coords_seq[next_i][1]) - float(coords_seq[prev_i][1])) * lat_sc
        phys_len = math.hypot(phys_dx, phys_dy)
        if phys_len == 0.0:
            result.append([lon, lat])
            continue
        # Left-perpendicular unit vector in physical space: (−dy, +dx) / len.
        offset_lon = effective_side * d_m * (-phys_dy) / (phys_len * lon_sc)
        offset_lat = effective_side * d_m * phys_dx    / (phys_len * lat_sc)
        result.append([lon + offset_lon, lat + offset_lat])

    return result


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def fuse_networks(
    fc: dict,
    *,
    max_lateral_dist_m: float = 15.0,
    max_heading_diff_deg: float = 30.0,
    excluded_wegtypes: frozenset[str] | None = None,
) -> tuple[dict, list[dict], list[dict], dict]:
    """Find BIKE links that run alongside CAR links (same or opposite direction
    on one-way roads, close laterally) and correct their geometry.

    Parameters
    ----------
    fc:
        Merged multi-mode FeatureCollection.  Each feature must carry a
        ``"mode"`` property (``"CAR"`` or ``"BIKE"``).
    max_lateral_dist_m:
        Maximum *average* perpendicular distance (RD New metres) between the
        sampled BIKE points and the infinite CAR line.  Default: ``15.0``.
    max_heading_diff_deg:
        Maximum heading difference (degrees, 0–180) between a CAR link and a
        BIKE link for them to be considered running in the same direction.
        Also used as the tolerance for the opposite direction on one-way roads.
        Default: ``30.0``.
    excluded_wegtypes:
        Set of BIKE ``wegtype`` values that represent standalone / pedestrian
        infrastructure and must never be matched.  ``None`` (default) uses
        ``_EXCLUDED_WEGTYPES``.  Pass ``frozenset()`` to disable the filter.

    Returns
    -------
    fc:
        The input FeatureCollection with BIKE link geometries corrected
        in-place where matches were found.  Intermediate vertices in the snap
        region are replaced by the matched CAR link's vertices offset laterally
        by ``_SNAP_OFFSET_M`` (0.5 m) always to the right of the BIKE's own
        travel direction.  The first and last coordinate of every BIKE link are
        always preserved.
    node_map:
        Always ``[]`` — kept for API compatibility with the pipeline.
    link_pairs:
        ``[{"carLinkId": …, "bikeLinkId": …,
            "avgLateralDistM": …, "headingDiffDeg": …, "isReverse": …}, …]``
        One entry per (CAR link, BIKE link) pair.
    stats:
        ``{"car_links", "bike_links", "bike_eligible", "link_pairs",
           "skipped_wegtype", "one_way_car", "reverse_matches",
           "snapped_bike"}``
    """
    _excluded  = _EXCLUDED_WEGTYPES if excluded_wegtypes is None else excluded_wegtypes
    features   = fc.get("features") or []

    # ── Step A: split by mode ───────────────────────────────────────────────
    car_features:  list[dict] = []
    bike_features: list[dict] = []

    for feat in features:
        mode = (feat.get("properties") or {}).get("mode", "")
        if mode == "CAR":
            car_features.append(feat)
        elif mode == "BIKE":
            bike_features.append(feat)

    if not car_features or not bike_features:
        logger.info(
            "fuse_networks: single-mode input (car=%d, bike=%d) — no-op.",
            len(car_features), len(bike_features),
        )
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   0,
            "link_pairs":      0,
            "skipped_wegtype": 0,
            "one_way_car":     0,
            "reverse_matches": 0,
            "snapped_bike":    0,
        }

    # ── Step B: pre-process eligible BIKE links ─────────────────────────────
    # Each entry: (link_id, heading_deg, ax_rd, ay_rd, bx_rd, by_rd, mx_rd, my_rd)
    bike_entries: list[tuple[str, float, float, float, float, float, float, float]] = []
    n_skipped_wt = 0

    for feat in bike_features:
        props  = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue

        if props.get("wegtype") in _excluded:
            n_skipped_wt += 1
            continue

        link_id     = _get_link_id(props)
        heading     = _link_heading(coords)
        ax, ay      = wgs84_to_rd(float(coords[0][0]),  float(coords[0][1]))
        bx, by      = wgs84_to_rd(float(coords[-1][0]), float(coords[-1][1]))
        bike_entries.append((link_id, heading, ax, ay, bx, by, (ax + bx) / 2, (ay + by) / 2))

    if not bike_entries:
        logger.info("fuse_networks: no eligible BIKE links after wegtype filter — no-op.")
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   0,
            "link_pairs":      0,
            "skipped_wegtype": n_skipped_wt,
            "one_way_car":     0,
            "reverse_matches": 0,
            "snapped_bike":    0,
        }

    # ── Step C: build KDTree on BIKE midpoints (RD New) ─────────────────────
    bike_mid_xy = np.array([[e[6], e[7]] for e in bike_entries], dtype=float)
    bike_tree   = KDTree2D(bike_mid_xy)

    k_cand   = min(_K_CANDIDATES, len(bike_entries))
    search_r = max_lateral_dist_m + _SEARCH_RADIUS_EXTRA

    # ── Step D: for each CAR link find matching BIKE links ───────────────────
    link_pairs:  list[dict] = []
    n_one_way    = 0

    # bike_matches[bike_lid] → list of (car_wgs_coords, avg_lat, is_reverse)
    bike_matches: dict[str, list[tuple]] = defaultdict(list)

    for feat in car_features:
        props  = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue

        car_id         = _get_link_id(props)
        car_heading    = _link_heading(coords)
        car_ax, car_ay = wgs84_to_rd(float(coords[0][0]),  float(coords[0][1]))
        car_bx, car_by = wgs84_to_rd(float(coords[-1][0]), float(coords[-1][1]))
        car_mx         = (car_ax + car_bx) / 2
        car_my         = (car_ay + car_by) / 2

        # One-way detection: reverseLinkIds absent or empty → one-way road.
        reverse_ids = props.get("reverseLinkIds")
        is_one_way  = not bool(reverse_ids)
        if is_one_way:
            n_one_way += 1

        dists, idxs = bike_tree.query(np.array([[car_mx, car_my]]), k=k_cand)

        # Warn if the search radius might have been too tight.
        if k_cand == len(bike_entries) and float(dists[0, -1]) <= search_r:
            logger.debug(
                "CAR link %s: all %d candidates are within search radius — "
                "consider increasing _K_CANDIDATES.",
                car_id, k_cand,
            )

        for j in range(k_cand):
            dist_to_mid = float(dists[0, j])
            if dist_to_mid > search_r:
                break

            bi = int(idxs[0, j])
            b_lid, b_heading, bax, bay, bbx, bby, bmx, bmy = bike_entries[bi]

            # ① Direction check.
            h_diff = _heading_diff(car_heading, b_heading)
            if is_one_way:
                # One-way road: accept same direction AND opposite direction.
                same_dir     = h_diff        <= max_heading_diff_deg
                reverse_dir  = (180.0 - h_diff) <= max_heading_diff_deg
                if not (same_dir or reverse_dir):
                    continue
                is_reverse = not same_dir   # True when opposite direction matched
            else:
                if h_diff > max_heading_diff_deg:
                    continue
                is_reverse = False

            # ② Average perpendicular distance (3 sample points on BIKE link).
            d_s = _pt_to_line_dist_rd(bax, bay, car_ax, car_ay, car_bx, car_by)
            d_m = _pt_to_line_dist_rd(bmx, bmy, car_ax, car_ay, car_bx, car_by)
            d_e = _pt_to_line_dist_rd(bbx, bby, car_ax, car_ay, car_bx, car_by)
            avg_lat = (d_s + d_m + d_e) / 3.0

            if avg_lat > max_lateral_dist_m:
                continue

            link_pairs.append({
                "carLinkId":       car_id,
                "bikeLinkId":      b_lid,
                "avgLateralDistM": round(avg_lat, 2),
                "headingDiffDeg":  round(h_diff, 1),
                "isReverse":       is_reverse,
            })

            # Collect per-BIKE match info for Step E geometry correction.
            bike_matches[b_lid].append((
                coords,      # CAR WGS84 coordinates
                avg_lat,     # lateral distance (m)
                is_reverse,  # direction flag
            ))

    # ── Step E: geometry correction for matched BIKE links ──────────────────
    # For each matched BIKE link, find which *intermediate* vertices (indices
    # 1..n-2) project within the matched CAR link's longitudinal extent (the
    # "snap region") and replace them with the CAR vertices offset laterally
    # by avg_lat.  BIKE vertices outside the snap region and both endpoints
    # are always preserved.  BIKE links with fewer than 3 coords are skipped.
    n_snapped = 0

    for feat in bike_features:
        props  = feat.get("properties") or {}
        b_lid  = _get_link_id(props)

        matches = bike_matches.get(b_lid)
        if not matches:
            continue

        bike_wgs = (feat.get("geometry") or {}).get("coordinates") or []
        if len(bike_wgs) < 3:
            continue  # no intermediate vertices to snap

        # WGS84 scale factors at the BIKE midpoint latitude.
        lat_mid = sum(float(c[1]) for c in bike_wgs) / len(bike_wgs)
        lat_sc  = _LAT_SCALE
        lon_sc  = _LAT_SCALE * math.cos(math.radians(lat_mid))

        # Compute snap region and snapped segment for each CAR match.
        snap_ops: list[tuple[int, int, list]] = []
        for car_wgs, _avg_lat, is_reverse in matches:
            region = _compute_snap_region(bike_wgs, car_wgs, lon_sc, lat_sc)
            if region is None:
                continue
            snap_start, snap_end = region
            # Place BIKE intermediate vertices on the CAR line with a fixed
            # _SNAP_OFFSET_M lateral shift always to the right of the BIKE's
            # travel direction.
            snapped = _build_snapped_segment(
                car_wgs, is_reverse, _SNAP_OFFSET_M, lon_sc, lat_sc,
            )
            snap_ops.append((snap_start, snap_end, snapped))

        if not snap_ops:
            continue

        # Process snap regions in longitudinal order; skip overlapping regions.
        snap_ops.sort(key=lambda x: x[0])
        new_coords: list = []
        cursor = 0
        for snap_start, snap_end, snapped in snap_ops:
            if snap_start < cursor:
                continue  # overlapping region — skip
            new_coords.extend(list(c) for c in bike_wgs[cursor:snap_start])
            new_coords.extend(snapped)
            cursor = snap_end + 1
        new_coords.extend(list(c) for c in bike_wgs[cursor:])

        feat["geometry"]["coordinates"] = new_coords
        n_snapped += 1

    stats = {
        "car_links":       len(car_features),
        "bike_links":      len(bike_features),
        "bike_eligible":   len(bike_entries),
        "link_pairs":      len(link_pairs),
        "skipped_wegtype": n_skipped_wt,
        "one_way_car":     n_one_way,
        "reverse_matches": sum(1 for lp in link_pairs if lp["isReverse"]),
        "snapped_bike":    n_snapped,
    }
    logger.info(
        "fuse_networks: car=%d (one_way=%d)  bike_eligible=%d  "
        "link_pairs=%d (reversed=%d)  snapped_bike=%d  skipped_wegtype=%d",
        len(car_features), n_one_way, len(bike_entries),
        len(link_pairs), stats["reverse_matches"], n_snapped, n_skipped_wt,
    )
    return fc, [], link_pairs, stats
