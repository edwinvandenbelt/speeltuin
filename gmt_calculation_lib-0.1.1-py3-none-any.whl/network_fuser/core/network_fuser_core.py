"""Pure-Python network_fuser core — no I/O, no boto3, no external deps.

Designed to run on the **pre-split** (undirected) network — i.e. before
``bidirectional_splitter`` has created directed link pairs.  At that stage
each link carries a ``"mode"`` property (``"CAR"`` or ``"BIKE"``) directly
from the network fetcher, and ``fromNode`` / ``toNode`` properties identify
shared junction points.

Purpose
-------
For each BIKE link that likely shares the car roadway — determined by
``wegtype`` not being in ``_EXCLUDED_WEGTYPES`` and the car road having a
speed limit below ``_SPEED_LIMIT_MAX_KMH`` — the fuser finds the matching
CAR link (or a chain of consecutive CAR links) and **replaces the entire
BIKE geometry** with the CAR geometry.  This makes the BIKE and CAR
geometries topologically identical before the ``bidirectional_splitter``
applies per-direction lateral displacements.

Matching conditions
-------------------
All three must hold:

a) **Endpoint proximity** — both endpoints of the BIKE link lie within
   ``max_node_dist_m`` of the corresponding CAR link endpoints (forward) or
   within ``max_node_dist_m`` of the reversed CAR endpoints (``isReverse``).
b) **Wegtype** — the BIKE link's ``wegtype`` is not in ``_EXCLUDED_WEGTYPES``
   (vrijliggende / separate bike paths are excluded).
c) **Speed limit** — both ``max_snelheid_heen`` and ``max_snelheid_terug``
   on the CAR link are below ``_SPEED_LIMIT_MAX_KMH`` (60 km/h).

Multi-link chains
-----------------
When no single CAR link satisfies (a), the fuser builds a local node graph
from all candidate CAR links nearby and performs a BFS to find a chain of
consecutive CAR links whose first-node is close to the BIKE start and whose
last-node is close to the BIKE end.  The combined length of the chain must
not exceed the original BIKE link length by more than
``_MAX_LENGTH_INCREASE_FACTOR``.

Node propagation
----------------
Replacing a BIKE geometry moves its junction nodes.  Any other BIKE link
that shares the same ``fromNode`` or ``toNode`` has its corresponding
endpoint coordinate updated automatically, keeping the network
topologically consistent.

Public API
----------
fuse_networks(fc, *, max_lateral_dist_m, max_heading_diff_deg,
              excluded_wegtypes, max_node_dist_m)
    -> tuple[dict, list[dict], list[dict], dict]
    Returns (fc_corrected, node_map=[], link_pairs, stats).
"""

from __future__ import annotations

import logging
import math
from collections import defaultdict, deque

import numpy as np

from shared.kd_tree import KDTree2D
from shared.rd_projection import wgs84_to_rd

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# BIKE link ``wegtype`` values that represent standalone / pedestrian
# infrastructure.  Links with these values are never matched to a CAR link.
_EXCLUDED_WEGTYPES: frozenset[str] = frozenset({
    "solitair_onverplicht_fietspad",
    "pedelecfietspad",
    "solitair_fietspad",
    "solitair_bromfietspad",
    "fietsstraat",
    "veerpont",
    "voetgangersgebied_fietsen_toegestaan",
    "voetgangersgebied",
    "voetgangersdoorsteekje",
})

# CAR links with a legal speed at or above this value (km/h) are never matched.
_SPEED_LIMIT_MAX_KMH: int = 60

# Both BIKE link endpoints must lie within this distance (RD New metres) of
# the corresponding CAR endpoints for the links to be considered a match.
_DEFAULT_MAX_NODE_DIST_M: float = 30.0

# Combined CAR geometry length may not exceed original BIKE length × this.
_MAX_LENGTH_INCREASE_FACTOR: float = 1.20

# Extra search radius (metres) beyond max_lateral_dist_m when pre-filtering
# via the KDTree.  Needs to be large enough to catch links whose midpoints
# may be far apart even when their endpoints are close (e.g. long links).
_SEARCH_RADIUS_EXTRA: float = 500.0

# Maximum CAR-link candidates to inspect per BIKE link from the KDTree.
_K_CANDIDATES: int = 100

# Maximum number of CAR links in a chain.
_MAX_CHAIN_HOPS: int = 8


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_link_id(props: dict) -> str:
    """Return the canonical link identifier from a feature's properties."""
    return str(props.get("linkId") or props.get("spectrumId") or "")


def _rd_dist(ax: float, ay: float, bx: float, by: float) -> float:
    """Euclidean distance between two RD New points (metres)."""
    return math.hypot(bx - ax, by - ay)


def _rd_length(coords: list) -> float:
    """Total polyline length in RD New metres."""
    total = 0.0
    for i in range(1, len(coords)):
        ax, ay = wgs84_to_rd(float(coords[i - 1][0]), float(coords[i - 1][1]))
        bx, by = wgs84_to_rd(float(coords[i][0]),     float(coords[i][1]))
        total += math.hypot(bx - ax, by - ay)
    return total


def _node_key(x: float, y: float) -> tuple[int, int]:
    """Round RD coordinates to ~1 m precision as a hashable node key."""
    return (round(x), round(y))


def _car_speed_ok(props: dict) -> bool:
    """True when the CAR link's legal speed is below ``_SPEED_LIMIT_MAX_KMH``."""
    s_h = float(props.get("max_snelheid_heen")  or 0)
    s_t = float(props.get("max_snelheid_terug") or 0)
    return max(s_h, s_t) < _SPEED_LIMIT_MAX_KMH


def _stitch_chain(chain: list[tuple[list, bool]]) -> list[list[float]]:
    """Stitch ``(wgs84_coords, is_reversed)`` pairs into one coordinate list.

    Duplicate junction points between consecutive links are removed: the last
    coordinate of each link is assumed to equal the first coordinate of the
    next link in the chain.
    """
    result: list[list[float]] = []
    for coords, is_reversed in chain:
        seq = list(reversed(coords)) if is_reversed else list(coords)
        if result:
            result.extend(list(c) for c in seq[1:])
        else:
            result.extend(list(c) for c in seq)
    return result


def _find_chain(
    start_keys: set[tuple[int, int]],
    end_keys:   set[tuple[int, int]],
    adjacency:  dict[tuple[int, int], list[tuple[int, tuple[int, int], bool]]],
    max_hops:   int,
) -> list[tuple[int, bool]] | None:
    """BFS from any start-key to any end-key through the adjacency graph.

    Returns a list of ``(car_entry_index, go_forward)`` pairs (the path), or
    ``None`` if no path is found within ``max_hops``.  An empty list means a
    start key is also an end key (degenerate; no links needed).

    ``adjacency[node_key]`` is a list of
    ``(car_entry_index, neighbour_key, go_forward)`` triples where
    ``go_forward=True`` means we traverse the CAR link in its stored
    coordinate direction.
    """
    if not start_keys or not end_keys:
        return None
    if start_keys & end_keys:
        return []  # degenerate: already at destination

    # visited[key] = (prev_key, car_idx, go_forward)  or  None for roots
    visited: dict[tuple[int, int], tuple | None] = {}
    queue:   deque[tuple[tuple[int, int], int]] = deque()
    for sk in start_keys:
        visited[sk] = None
        queue.append((sk, 0))

    found: tuple[int, int] | None = None
    while queue:
        key, depth = queue.popleft()
        if key in end_keys:
            found = key
            break
        if depth >= max_hops:
            continue
        for car_idx, neighbour, go_forward in adjacency.get(key, []):
            if neighbour not in visited:
                visited[neighbour] = (key, car_idx, go_forward)
                queue.append((neighbour, depth + 1))

    if found is None:
        return None

    # Reconstruct path backwards then reverse.
    path: list[tuple[int, bool]] = []
    key = found
    while visited[key] is not None:
        prev_key, car_idx, go_forward = visited[key]
        path.append((car_idx, go_forward))
        key = prev_key
    path.reverse()
    return path


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def fuse_networks(
    fc: dict,
    *,
    max_lateral_dist_m:   float = 15.0,
    max_heading_diff_deg: float = 30.0,
    excluded_wegtypes:    frozenset[str] | None = None,
    max_node_dist_m:      float = _DEFAULT_MAX_NODE_DIST_M,
) -> tuple[dict, list[dict], list[dict], dict]:
    """Replace BIKE link geometries with the matching CAR link geometry.

    Parameters
    ----------
    fc:
        Merged multi-mode FeatureCollection.  Each feature must carry a
        ``"mode"`` property (``"CAR"`` or ``"BIKE"``).
    max_lateral_dist_m:
        Kept for backward compatibility.  Used only as the KDTree pre-filter
        radius together with ``_SEARCH_RADIUS_EXTRA``.  The primary matching
        criterion is endpoint proximity (``max_node_dist_m``).
    max_heading_diff_deg:
        Kept for backward compatibility; no longer used in matching.
    excluded_wegtypes:
        BIKE ``wegtype`` values to skip.  ``None`` uses ``_EXCLUDED_WEGTYPES``.
        Pass ``frozenset()`` to disable the filter entirely.
    max_node_dist_m:
        Maximum RD New distance (metres) between BIKE and CAR endpoints for
        the two links to be considered a match.
        Default: ``_DEFAULT_MAX_NODE_DIST_M`` (30 m).

    Returns
    -------
    fc:
        The input FeatureCollection with BIKE link geometries replaced in-place
        where matches were found.  The ``bidirectional_splitter`` that follows
        will apply per-direction lateral displacements.
    node_map:
        Always ``[]`` — kept for API compatibility.
    link_pairs:
        ``[{"carLinkId": …, "bikeLinkId": …, "isReverse": …,
            "chainLength": …}, …]``
    stats:
        ``{"car_links", "bike_links", "bike_eligible", "link_pairs",
           "skipped_wegtype", "skipped_speed", "reverse_matches",
           "fused_bike"}``
    """
    _excluded = _EXCLUDED_WEGTYPES if excluded_wegtypes is None else excluded_wegtypes
    features  = fc.get("features") or []

    # ── A: split by mode ────────────────────────────────────────────────────
    car_features:  list[dict] = []
    bike_features: list[dict] = []
    for feat in features:
        mode = (feat.get("properties") or {}).get("mode", "")
        if mode == "CAR":
            car_features.append(feat)
        elif mode == "BIKE":
            bike_features.append(feat)

    if not car_features or not bike_features:
        logger.info(
            "fuse_networks: single-mode input (car=%d, bike=%d) — no-op.",
            len(car_features), len(bike_features),
        )
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   0,
            "link_pairs":      0,
            "skipped_wegtype": 0,
            "skipped_speed":   0,
            "reverse_matches": 0,
            "fused_bike":      0,
        }

    # ── B: pre-process eligible BIKE links ──────────────────────────────────
    # Each entry: (link_id, ax_rd, ay_rd, bx_rd, by_rd, mx_rd, my_rd, length_m)
    bike_entries: list[tuple] = []
    n_skipped_wt = 0

    for feat in bike_features:
        props  = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        if props.get("wegtype") in _excluded:
            n_skipped_wt += 1
            continue
        link_id = _get_link_id(props)
        ax, ay  = wgs84_to_rd(float(coords[0][0]),  float(coords[0][1]))
        bx, by  = wgs84_to_rd(float(coords[-1][0]), float(coords[-1][1]))
        length  = _rd_length(coords)
        bike_entries.append((link_id, ax, ay, bx, by, (ax + bx) / 2, (ay + by) / 2, length))

    if not bike_entries:
        logger.info("fuse_networks: no eligible BIKE links after wegtype filter — no-op.")
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   0,
            "link_pairs":      0,
            "skipped_wegtype": n_skipped_wt,
            "skipped_speed":   0,
            "reverse_matches": 0,
            "fused_bike":      0,
        }

    # ── C: pre-process eligible CAR links ───────────────────────────────────
    # Each entry: (link_id, ax_rd, ay_rd, bx_rd, by_rd, mx_rd, my_rd, length_m, coords)
    car_entries: list[tuple] = []
    n_skipped_speed = 0

    for feat in car_features:
        props  = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        if not _car_speed_ok(props):
            n_skipped_speed += 1
            continue
        link_id = _get_link_id(props)
        ax, ay  = wgs84_to_rd(float(coords[0][0]),  float(coords[0][1]))
        bx, by  = wgs84_to_rd(float(coords[-1][0]), float(coords[-1][1]))
        length  = _rd_length(coords)
        car_entries.append((link_id, ax, ay, bx, by, (ax + bx) / 2, (ay + by) / 2, length, coords))

    if not car_entries:
        logger.info("fuse_networks: no eligible CAR links after speed filter — no-op.")
        return fc, [], [], {
            "car_links":       len(car_features),
            "bike_links":      len(bike_features),
            "bike_eligible":   len(bike_entries),
            "link_pairs":      0,
            "skipped_wegtype": n_skipped_wt,
            "skipped_speed":   n_skipped_speed,
            "reverse_matches": 0,
            "fused_bike":      0,
        }

    # ── D: build KDTree on CAR midpoints (RD New) ───────────────────────────
    car_mid_xy = np.array([[e[5], e[6]] for e in car_entries], dtype=float)
    car_tree   = KDTree2D(car_mid_xy)
    k_cand     = min(_K_CANDIDATES, len(car_entries))
    search_r   = max_lateral_dist_m + _SEARCH_RADIUS_EXTRA

    # ── E: build node-to-BIKE mapping for node propagation ──────────────────
    # node_to_bike[node_id] = [(feature, coord_index)]
    # coord_index is 0 (fromNode end) or -1 (toNode end).
    node_to_bike: dict[str, list[tuple[dict, int]]] = defaultdict(list)
    for feat in bike_features:
        props     = feat.get("properties") or {}
        from_node = str(props.get("fromNode") or "")
        to_node   = str(props.get("toNode")   or "")
        coords    = (feat.get("geometry") or {}).get("coordinates") or []
        if from_node and coords:
            node_to_bike[from_node].append((feat, 0))
        if to_node and coords:
            node_to_bike[to_node].append((feat, -1))

    # ── F: for each BIKE link, find matching CAR geometry ───────────────────
    link_pairs:        list[dict]              = []
    bike_replacements: dict[str, list]         = {}   # link_id → new wgs84 coords
    bike_is_reverse:   dict[str, bool]         = {}

    for b_entry in bike_entries:
        b_lid, bax, bay, bbx, bby, bmx, bmy, b_len = b_entry

        # Query KDTree for nearby CAR midpoints.
        dists, idxs = car_tree.query(np.array([[bmx, bmy]]), k=k_cand)
        candidates: list[int] = [
            int(idxs[0, j]) for j in range(k_cand)
            if float(dists[0, j]) <= search_r
        ]
        if not candidates:
            continue

        # ── F1: try single-link endpoint-proximity match ─────────────────
        best_single: tuple[int, bool] | None = None
        for ci in candidates:
            c_lid, cax, cay, cbx, cby, *_ = car_entries[ci]
            # Forward: bike_start ≈ car_start  AND  bike_end ≈ car_end
            if (_rd_dist(bax, bay, cax, cay) < max_node_dist_m and
                    _rd_dist(bbx, bby, cbx, cby) < max_node_dist_m):
                best_single = (ci, False)
                break
            # Reverse: bike_start ≈ car_end  AND  bike_end ≈ car_start
            if (_rd_dist(bax, bay, cbx, cby) < max_node_dist_m and
                    _rd_dist(bbx, bby, cax, cay) < max_node_dist_m):
                best_single = (ci, True)
                break

        if best_single is not None:
            ci, is_reverse = best_single
            c_lid, cax, cay, cbx, cby, _, _, c_len, c_coords = car_entries[ci]
            if c_len <= b_len * _MAX_LENGTH_INCREASE_FACTOR:
                new_coords = (list(reversed(c_coords)) if is_reverse else list(c_coords))
                bike_replacements[b_lid] = [list(c) for c in new_coords]
                bike_is_reverse[b_lid]   = is_reverse
                link_pairs.append({
                    "carLinkId":   c_lid,
                    "bikeLinkId":  b_lid,
                    "isReverse":   is_reverse,
                    "chainLength": 1,
                })
                continue

        # ── F2: try chain match via BFS ──────────────────────────────────
        # Build a local undirected node graph from the candidate CAR links.
        # Nodes are identified by rounded RD coordinates (~1 m precision).
        adjacency: dict[tuple[int, int], list[tuple[int, tuple[int, int], bool]]] = (
            defaultdict(list)
        )
        node_rd: dict[tuple[int, int], tuple[float, float]] = {}
        for ci in candidates:
            c_lid, cax, cay, cbx, cby, *_ = car_entries[ci]
            fn = _node_key(cax, cay)
            tn = _node_key(cbx, cby)
            adjacency[fn].append((ci, tn, True))    # forward: fn → tn
            adjacency[tn].append((ci, fn, False))   # backward: tn → fn
            node_rd[fn] = (cax, cay)
            node_rd[tn] = (cbx, cby)

        # Find CAR nodes close to the BIKE start / end.
        start_keys: set[tuple[int, int]] = {
            nk for nk, (nx, ny) in node_rd.items()
            if _rd_dist(bax, bay, nx, ny) < max_node_dist_m
        }
        end_keys: set[tuple[int, int]] = {
            nk for nk, (nx, ny) in node_rd.items()
            if _rd_dist(bbx, bby, nx, ny) < max_node_dist_m
        }

        path = _find_chain(start_keys, end_keys, adjacency, _MAX_CHAIN_HOPS)
        if not path:
            continue

        # Stitch chain geometry and check length constraint.
        chain_parts: list[tuple[list, bool]] = [
            (car_entries[ci][8], not go_forward) for ci, go_forward in path
        ]
        chain_len = sum(car_entries[ci][7] for ci, _ in path)

        if chain_len > b_len * _MAX_LENGTH_INCREASE_FACTOR:
            continue

        new_coords = _stitch_chain(chain_parts)
        car_ids    = [car_entries[ci][0] for ci, _ in path]
        bike_replacements[b_lid] = new_coords
        bike_is_reverse[b_lid]   = False   # chain is already oriented bike_start → bike_end
        link_pairs.append({
            "carLinkId":   ",".join(car_ids),
            "bikeLinkId":  b_lid,
            "isReverse":   False,
            "chainLength": len(path),
        })

    # ── G: apply geometry replacements and propagate node moves ─────────────
    n_fused = 0
    updated_nodes: dict[str, list[float]] = {}   # node_id → new coordinate

    for feat in bike_features:
        props  = feat.get("properties") or {}
        b_lid  = _get_link_id(props)
        new_coords = bike_replacements.get(b_lid)
        if new_coords is None:
            continue

        from_node = str(props.get("fromNode") or "")
        to_node   = str(props.get("toNode")   or "")

        # Replace the full geometry.
        feat["geometry"]["coordinates"] = new_coords
        n_fused += 1

        # Propagate the moved start node to all BIKE features sharing it.
        if from_node:
            new_start = new_coords[0]
            if from_node in updated_nodes:
                prev = updated_nodes[from_node]
                if abs(prev[0] - new_start[0]) > 1e-8 or abs(prev[1] - new_start[1]) > 1e-8:
                    logger.warning(
                        "fuse_networks: node %s moved to two different positions "
                        "(%s vs %s) — keeping first assignment.",
                        from_node, prev, new_start,
                    )
            else:
                updated_nodes[from_node] = new_start
                for other_feat, ci in node_to_bike.get(from_node, []):
                    other_coords = (other_feat.get("geometry") or {}).get("coordinates") or []
                    if other_coords:
                        other_coords[ci] = list(new_start)

        # Propagate the moved end node.
        if to_node:
            new_end = new_coords[-1]
            if to_node in updated_nodes:
                prev = updated_nodes[to_node]
                if abs(prev[0] - new_end[0]) > 1e-8 or abs(prev[1] - new_end[1]) > 1e-8:
                    logger.warning(
                        "fuse_networks: node %s moved to two different positions "
                        "(%s vs %s) — keeping first assignment.",
                        to_node, prev, new_end,
                    )
            else:
                updated_nodes[to_node] = new_end
                for other_feat, ci in node_to_bike.get(to_node, []):
                    other_coords = (other_feat.get("geometry") or {}).get("coordinates") or []
                    if other_coords:
                        other_coords[ci] = list(new_end)

    stats = {
        "car_links":       len(car_features),
        "bike_links":      len(bike_features),
        "bike_eligible":   len(bike_entries),
        "link_pairs":      len(link_pairs),
        "skipped_wegtype": n_skipped_wt,
        "skipped_speed":   n_skipped_speed,
        "reverse_matches": sum(1 for lp in link_pairs if lp["isReverse"]),
        "fused_bike":      n_fused,
    }
    logger.info(
        "fuse_networks: car=%d  bike_eligible=%d  "
        "link_pairs=%d  fused=%d  skipped(wt=%d speed=%d)",
        len(car_features), len(bike_entries),
        len(link_pairs), n_fused, n_skipped_wt, n_skipped_speed,
    )
    return fc, [], link_pairs, stats
