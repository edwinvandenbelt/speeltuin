"""Tests for network_fuser_core.fuse_networks and helpers."""

from __future__ import annotations

import pytest

from network_fuser.core.network_fuser_core import (
    _EXCLUDED_WEGTYPES,
    _MAX_LENGTH_INCREASE_FACTOR,
    _SPEED_LIMIT_MAX_KMH,
    _car_speed_ok,
    _find_chain,
    _rd_dist,
    _rd_length,
    _stitch_chain,
    fuse_networks,
)
from shared.rd_projection import wgs84_to_rd

# ---------------------------------------------------------------------------
# Test-data helpers
# ---------------------------------------------------------------------------

# Base coordinates in the Netherlands (required for wgs84_to_rd accuracy).
# CAR link runs due east: from (5.0, 52.0) to (5.001, 52.0) — ≈ 68.7 m.
_CAR_LON_S, _CAR_LAT = 5.0, 52.0
_CAR_LON_E            = 5.001

# BIKE endpoints ≈ 5.6 m north of the CAR link, same longitude range.
# The lateral offset is well within the 30 m node-distance threshold.
_OFFSET_LAT  = 0.00005          # ≈ 5.6 m north
_BIKE_LON_S  = _CAR_LON_S
_BIKE_LAT    = _CAR_LAT + _OFFSET_LAT
_BIKE_LON_E  = _CAR_LON_E


def _car(
    lon_s=_CAR_LON_S, lat_s=_CAR_LAT, lon_e=_CAR_LON_E, lat_e=_CAR_LAT,
    link_id="C1",
    speed: float = 30.0,
    from_node: str = "100",
    to_node:   str = "101",
) -> dict:
    """Build a straight CAR feature with the correct pre-split property names."""
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [[lon_s, lat_s], [lon_e, lat_e]],
        },
        "properties": {
            "mode": "CAR",
            "fromNode": from_node,
            "toNode":   to_node,
            "linkId":   link_id,
            "max_snelheid_heen":  speed,
            "max_snelheid_terug": speed,
        },
    }


def _car_curved(link_id="C1", speed: float = 30.0) -> dict:
    """CAR feature with 3 coordinates (slight northward bulge at the midpoint)."""
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [_CAR_LON_S, _CAR_LAT],
                [(_CAR_LON_S + _CAR_LON_E) / 2, _CAR_LAT + 0.000005],  # ~0.6 m bulge
                [_CAR_LON_E, _CAR_LAT],
            ],
        },
        "properties": {
            "mode": "CAR",
            "fromNode": "100",
            "toNode":   "101",
            "linkId":   link_id,
            "max_snelheid_heen":  speed,
            "max_snelheid_terug": speed,
        },
    }


def _car_zigzag(link_id="C_ZZ") -> dict:
    """CAR with the same endpoints as ``_car()`` but a large northward detour.

    The polyline length is ~1100 m — much more than 120 % of the ~68.7 m BIKE
    length — so the length-constraint check must reject any match with ``_bike()``.
    """
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [_CAR_LON_S, _CAR_LAT],
                [(_CAR_LON_S + _CAR_LON_E) / 2, _CAR_LAT + 0.005],   # ≈ 556 m north
                [_CAR_LON_E, _CAR_LAT],
            ],
        },
        "properties": {
            "mode": "CAR",
            "fromNode": "100",
            "toNode":   "101",
            "linkId":   link_id,
            "max_snelheid_heen":  30.0,
            "max_snelheid_terug": 30.0,
        },
    }


def _bike(
    lon_s=_BIKE_LON_S, lat_s=_BIKE_LAT, lon_e=_BIKE_LON_E, lat_e=_BIKE_LAT,
    link_id="B1",
    wegtype: str | None = None,
    from_node: str = "200",
    to_node:   str = "201",
) -> dict:
    """Build a 2-coordinate BIKE feature."""
    props: dict = {
        "mode": "BIKE",
        "fromNode": from_node,
        "toNode":   to_node,
        "linkId":   link_id,
    }
    if wegtype is not None:
        props["wegtype"] = wegtype
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [[lon_s, lat_s], [lon_e, lat_e]],
        },
        "properties": props,
    }


def _fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features), "properties": {}}


# ---------------------------------------------------------------------------
# Helper unit tests
# ---------------------------------------------------------------------------

class TestRdDist:
    def test_zero_distance(self):
        assert _rd_dist(0.0, 0.0, 0.0, 0.0) == 0.0

    def test_horizontal(self):
        assert abs(_rd_dist(0.0, 0.0, 3.0, 0.0) - 3.0) < 1e-9

    def test_345_triangle(self):
        assert abs(_rd_dist(0.0, 0.0, 3.0, 4.0) - 5.0) < 1e-9


class TestRdLength:
    def test_two_point_line(self):
        """Single segment length matches _rd_dist for the same coords."""
        coords = [[5.0, 52.0], [5.001, 52.0]]
        ax, ay = wgs84_to_rd(5.0, 52.0)
        bx, by = wgs84_to_rd(5.001, 52.0)
        expected = _rd_dist(ax, ay, bx, by)
        assert abs(_rd_length(coords) - expected) < 1e-3

    def test_multi_segment_longer_than_straight_line(self):
        """A 3-point polyline with a detour is longer than a 2-point straight."""
        straight = [[5.0, 52.0], [5.001, 52.0]]
        detour   = [[5.0, 52.0], [5.0005, 52.001], [5.001, 52.0]]
        assert _rd_length(detour) > _rd_length(straight)


class TestCarSpeedOk:
    def test_below_threshold_ok(self):
        assert _car_speed_ok({"max_snelheid_heen": 50, "max_snelheid_terug": 50}) is True

    def test_at_threshold_not_ok(self):
        assert _car_speed_ok({"max_snelheid_heen": 60, "max_snelheid_terug": 60}) is False

    def test_above_threshold_not_ok(self):
        assert _car_speed_ok({"max_snelheid_heen": 80, "max_snelheid_terug": 80}) is False

    def test_missing_speed_treated_as_zero(self):
        assert _car_speed_ok({}) is True

    def test_one_direction_above_threshold(self):
        # heen = 30 OK, terug = 80 → overall NOT ok
        assert _car_speed_ok({"max_snelheid_heen": 30, "max_snelheid_terug": 80}) is False


class TestStitchChain:
    def test_single_link_forward(self):
        coords = [[0.0, 0.0], [1.0, 0.0], [2.0, 0.0]]
        result = _stitch_chain([(coords, False)])
        assert result == [[0.0, 0.0], [1.0, 0.0], [2.0, 0.0]]

    def test_single_link_reversed(self):
        coords = [[0.0, 0.0], [1.0, 0.0], [2.0, 0.0]]
        result = _stitch_chain([(coords, True)])
        assert result == [[2.0, 0.0], [1.0, 0.0], [0.0, 0.0]]

    def test_two_links_no_duplicate_junction(self):
        c1 = [[0.0, 0.0], [1.0, 0.0]]
        c2 = [[1.0, 0.0], [2.0, 0.0]]
        result = _stitch_chain([(c1, False), (c2, False)])
        assert result == [[0.0, 0.0], [1.0, 0.0], [2.0, 0.0]]


class TestFindChain:
    def _adj(self):
        """Simple linear graph: A → B → C."""
        return {
            (0, 0): [(0, (1, 0), True)],
            (1, 0): [(0, (0, 0), False), (1, (2, 0), True)],
            (2, 0): [(1, (1, 0), False)],
        }

    def test_direct_path(self):
        path = _find_chain({(0, 0)}, {(2, 0)}, self._adj(), max_hops=5)
        assert path == [(0, True), (1, True)]

    def test_no_path_exceeds_hops(self):
        path = _find_chain({(0, 0)}, {(2, 0)}, self._adj(), max_hops=1)
        assert path is None

    def test_start_equals_end_returns_empty(self):
        path = _find_chain({(1, 0)}, {(1, 0)}, self._adj(), max_hops=5)
        assert path == []

    def test_empty_start_returns_none(self):
        assert _find_chain(set(), {(2, 0)}, self._adj(), 5) is None

    def test_disconnected_returns_none(self):
        assert _find_chain({(0, 0)}, {(99, 99)}, self._adj(), 5) is None


# ---------------------------------------------------------------------------
# Single-mode / empty → no-op
# ---------------------------------------------------------------------------

class TestNoOp:
    def test_car_only(self):
        fc = _fc(_car())
        out_fc, node_map, link_pairs, stats = fuse_networks(fc)
        assert out_fc is fc
        assert node_map  == []
        assert link_pairs == []
        assert stats["link_pairs"]  == 0
        assert stats["fused_bike"]  == 0

    def test_bike_only(self):
        fc = _fc(_bike())
        _, _, link_pairs, _ = fuse_networks(fc)
        assert link_pairs == []

    def test_empty(self):
        fc = _fc()
        _, _, link_pairs, stats = fuse_networks(fc)
        assert link_pairs == []
        assert stats["car_links"] == stats["bike_links"] == 0

    def test_all_bike_excluded_wegtype(self):
        """When all BIKE links have an excluded wegtype the result is empty."""
        fc = _fc(_car(), _bike(wegtype="solitair_fietspad"))
        _, _, link_pairs, stats = fuse_networks(fc)
        assert link_pairs == []
        assert stats["bike_eligible"]   == 0
        assert stats["skipped_wegtype"] == 1


# ---------------------------------------------------------------------------
# Speed filter
# ---------------------------------------------------------------------------

class TestSpeedFilter:
    def test_car_below_60_matched(self):
        _, _, link_pairs, stats = fuse_networks(_fc(_car(speed=50.0), _bike()))
        assert len(link_pairs) == 1
        assert stats["skipped_speed"] == 0

    def test_car_at_60_excluded(self):
        _, _, link_pairs, stats = fuse_networks(_fc(_car(speed=60.0), _bike()))
        assert link_pairs == []
        assert stats["skipped_speed"] == 1

    def test_car_above_60_excluded(self):
        _, _, link_pairs, stats = fuse_networks(_fc(_car(speed=80.0), _bike()))
        assert link_pairs == []
        assert stats["skipped_speed"] == 1

    def test_car_no_speed_properties_matched(self):
        """A CAR feature without speed properties is treated as 0 km/h → matched."""
        car_no_speed = {
            "type": "Feature",
            "geometry": {"type": "LineString",
                         "coordinates": [[_CAR_LON_S, _CAR_LAT], [_CAR_LON_E, _CAR_LAT]]},
            "properties": {"mode": "CAR", "fromNode": "100", "toNode": "101", "linkId": "C1"},
        }
        _, _, link_pairs, _ = fuse_networks(_fc(car_no_speed, _bike()))
        assert len(link_pairs) == 1

    def test_one_direction_above_60_whole_link_excluded(self):
        """Even if only one direction is ≥ 60 km/h the whole link is excluded."""
        car_fast_one_dir = {
            "type": "Feature",
            "geometry": {"type": "LineString",
                         "coordinates": [[_CAR_LON_S, _CAR_LAT], [_CAR_LON_E, _CAR_LAT]]},
            "properties": {
                "mode": "CAR", "fromNode": "100", "toNode": "101", "linkId": "C1",
                "max_snelheid_heen": 30.0, "max_snelheid_terug": 70.0,
            },
        }
        _, _, link_pairs, _ = fuse_networks(_fc(car_fast_one_dir, _bike()))
        assert link_pairs == []


# ---------------------------------------------------------------------------
# Endpoint proximity matching
# ---------------------------------------------------------------------------

class TestEndpointProximity:
    def test_close_endpoints_forward_match(self):
        """BIKE 5.6 m north → endpoints within 30 m → forward match."""
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), _bike()))
        assert len(link_pairs) == 1
        assert link_pairs[0]["isReverse"] is False

    def test_endpoints_beyond_threshold_not_matched(self):
        """BIKE endpoints ~41 m east of CAR endpoints → no match."""
        # 0.0006° lon at 52°N ≈ 41 m
        bike_east = _bike(
            lon_s=_CAR_LON_S + 0.0006, lon_e=_CAR_LON_E + 0.0006,
        )
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), bike_east))
        assert link_pairs == []

    def test_reversed_endpoints_matched_as_reversed(self):
        """BIKE running westbound → start ≈ CAR end → isReverse=True."""
        bike_rev = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                         lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), bike_rev))
        assert len(link_pairs) == 1
        assert link_pairs[0]["isReverse"] is True

    def test_tight_max_node_dist_excludes_close_link(self):
        """BIKE 5.6 m from CAR; threshold 3 m → no match."""
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike()), max_node_dist_m=3.0,
        )
        assert link_pairs == []

    def test_generous_max_node_dist_includes_link(self):
        """Threshold 50 m easily captures the 5.6 m offset BIKE."""
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike()), max_node_dist_m=50.0,
        )
        assert len(link_pairs) == 1

    def test_link_pair_fields(self):
        """link_pairs entry has the expected keys."""
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), _bike()))
        lp = link_pairs[0]
        assert lp["carLinkId"]   == "C1"
        assert lp["bikeLinkId"]  == "B1"
        assert lp["isReverse"]   is False
        assert lp["chainLength"] == 1

    def test_stats_keys_present(self):
        _, _, _, stats = fuse_networks(_fc(_car(), _bike()))
        for key in ("car_links", "bike_links", "bike_eligible", "link_pairs",
                    "skipped_wegtype", "skipped_speed", "reverse_matches", "fused_bike"):
            assert key in stats, f"missing stats key: {key}"

    def test_reverse_matches_stat(self):
        bike_rev = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                         lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, _, stats = fuse_networks(_fc(_car(), bike_rev))
        assert stats["reverse_matches"] == 1

    def test_both_directions_matched_simultaneously(self):
        """One forward BIKE and one reversed BIKE alongside the same CAR → two pairs."""
        bike_fwd = _bike(link_id="B_FWD")
        bike_rev = _bike(link_id="B_REV",
                         lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                         lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, link_pairs, stats = fuse_networks(_fc(_car(), bike_fwd, bike_rev))
        assert len(link_pairs) == 2
        assert stats["reverse_matches"] == 1


# ---------------------------------------------------------------------------
# Excluded wegtype filter
# ---------------------------------------------------------------------------

class TestExcludedWegtype:
    @pytest.mark.parametrize("wegtype", sorted(_EXCLUDED_WEGTYPES))
    def test_excluded_wegtype_not_matched(self, wegtype: str):
        _, _, link_pairs, stats = fuse_networks(_fc(_car(), _bike(wegtype=wegtype)))
        assert link_pairs == []
        assert stats["skipped_wegtype"] == 1
        assert stats["bike_eligible"]   == 0

    def test_normal_wegtype_matched(self):
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), _bike(wegtype="rijbaan")))
        assert len(link_pairs) == 1

    def test_no_wegtype_property_matched(self):
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), _bike()))
        assert len(link_pairs) == 1

    def test_disable_filter_with_empty_frozenset(self):
        """excluded_wegtypes=frozenset() disables the filter entirely."""
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike(wegtype="solitair_fietspad")),
            excluded_wegtypes=frozenset(),
        )
        assert len(link_pairs) == 1


# ---------------------------------------------------------------------------
# Multiple BIKE links per CAR link
# ---------------------------------------------------------------------------

class TestMultipleBikePerCar:
    def test_two_bike_links_both_matched(self):
        """Two BIKE links alongside one CAR link — both are fused."""
        bike1 = _bike(link_id="B1", lat_s=_CAR_LAT + 0.00003, lat_e=_CAR_LAT + 0.00003)
        bike2 = _bike(link_id="B2", lat_s=_CAR_LAT + 0.00006, lat_e=_CAR_LAT + 0.00006,
                      from_node="300", to_node="301")
        _, _, link_pairs, stats = fuse_networks(_fc(_car(), bike1, bike2))
        bike_ids = {lp["bikeLinkId"] for lp in link_pairs}
        assert "B1" in bike_ids
        assert "B2" in bike_ids
        assert stats["link_pairs"] == 2
        assert stats["fused_bike"] == 2

    def test_one_bike_too_far_one_close(self):
        """Only the BIKE with close endpoints should be matched."""
        bike_close = _bike(link_id="CLOSE",
                           lat_s=_CAR_LAT + 0.00005, lat_e=_CAR_LAT + 0.00005)
        bike_far   = _bike(link_id="FAR",
                           lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002,
                           from_node="400", to_node="401")
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), bike_close, bike_far))
        assert len(link_pairs) == 1
        assert link_pairs[0]["bikeLinkId"] == "CLOSE"


# ---------------------------------------------------------------------------
# Geometry replacement
# ---------------------------------------------------------------------------

class TestGeometryReplacement:
    def _get_bike(self, fc: dict) -> dict:
        return next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")

    def test_bike_geometry_replaced_with_car_geometry(self):
        """After fusing, the BIKE coordinates match the CAR coordinates exactly."""
        fc = _fc(_car(), _bike())
        fuse_networks(fc)
        bike_coords = self._get_bike(fc)["geometry"]["coordinates"]
        car_coords  = _car()["geometry"]["coordinates"]
        assert len(bike_coords) == len(car_coords) == 2
        for i in range(2):
            assert abs(bike_coords[i][0] - car_coords[i][0]) < 1e-9
            assert abs(bike_coords[i][1] - car_coords[i][1]) < 1e-9

    def test_curved_car_geometry_fully_transferred(self):
        """A 3-coord curved CAR → the fused BIKE gets all 3 coordinates."""
        fc = _fc(_car_curved(), _bike())
        fuse_networks(fc)
        bike_coords = self._get_bike(fc)["geometry"]["coordinates"]
        car_coords  = _car_curved()["geometry"]["coordinates"]
        assert len(bike_coords) == 3
        for i in range(3):
            assert abs(bike_coords[i][0] - car_coords[i][0]) < 1e-9
            assert abs(bike_coords[i][1] - car_coords[i][1]) < 1e-9

    def test_reversed_bike_gets_reversed_car_geometry(self):
        """Westbound BIKE (isReverse=True) → geometry is the reversed CAR coords."""
        bike_rev = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                         lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT, link_id="BREV")
        fc = _fc(_car(), bike_rev)
        fuse_networks(fc)
        bike_coords = self._get_bike(fc)["geometry"]["coordinates"]
        car_coords  = list(reversed(_car()["geometry"]["coordinates"]))
        assert len(bike_coords) == 2
        for i in range(2):
            assert abs(bike_coords[i][0] - car_coords[i][0]) < 1e-9
            assert abs(bike_coords[i][1] - car_coords[i][1]) < 1e-9

    def test_unmatched_bike_geometry_unchanged(self):
        """A BIKE whose endpoints are far from all CAR links keeps its geometry."""
        # 200 m north: far beyond the 30 m node-distance threshold.
        bike_far = _bike(lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002, link_id="BFAR",
                         from_node="900", to_node="901")
        orig_coords = [list(c) for c in bike_far["geometry"]["coordinates"]]
        fc = _fc(_car(), bike_far)
        fuse_networks(fc)
        bike_feat   = next(f for f in fc["features"] if f["properties"]["linkId"] == "BFAR")
        assert bike_feat["geometry"]["coordinates"] == orig_coords

    def test_fused_bike_stat_correct(self):
        _, _, _, stats = fuse_networks(_fc(_car(), _bike()))
        assert stats["fused_bike"] == 1

    def test_unfused_bike_stat_is_zero(self):
        bike_far = _bike(lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002,
                         from_node="900", to_node="901")
        _, _, _, stats = fuse_networks(_fc(_car(), bike_far))
        assert stats["fused_bike"] == 0

    def test_fc_is_same_object(self):
        fc = _fc(_car(), _bike())
        out_fc, *_ = fuse_networks(fc)
        assert out_fc is fc


# ---------------------------------------------------------------------------
# Node propagation
# ---------------------------------------------------------------------------

class TestNodePropagation:
    def test_adjacent_bike_start_updated(self):
        """When BIKE-A is fused its toNode moves; BIKE-B sharing that node is updated."""
        # BIKE-A: N1 → N2, running alongside CAR C1.
        bike_a = _bike(
            lon_s=_BIKE_LON_S, lat_s=_BIKE_LAT,
            lon_e=_BIKE_LON_E, lat_e=_BIKE_LAT,
            link_id="BA", from_node="N1", to_node="N2",
        )
        # BIKE-B: N2 → N3, no matching CAR (continues east past the CAR extent).
        bike_b = _bike(
            lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
            lon_e=_BIKE_LON_E + 0.001, lat_e=_BIKE_LAT,
            link_id="BB", from_node="N2", to_node="N3",
        )
        fc = _fc(_car(), bike_a, bike_b)
        fuse_networks(fc)

        feat_a = next(f for f in fc["features"] if f["properties"]["linkId"] == "BA")
        feat_b = next(f for f in fc["features"] if f["properties"]["linkId"] == "BB")
        car_coords = _car()["geometry"]["coordinates"]

        # BIKE-A should have the full CAR geometry.
        assert abs(feat_a["geometry"]["coordinates"][0][1] - _CAR_LAT) < 1e-9
        assert abs(feat_a["geometry"]["coordinates"][-1][1] - _CAR_LAT) < 1e-9

        # BIKE-B's start (node N2) should have moved to the CAR end position.
        b_start = feat_b["geometry"]["coordinates"][0]
        assert abs(b_start[0] - car_coords[-1][0]) < 1e-9
        assert abs(b_start[1] - car_coords[-1][1]) < 1e-9

        # BIKE-B's end (node N3) should be unchanged.
        b_end = feat_b["geometry"]["coordinates"][-1]
        assert abs(b_end[0] - (_BIKE_LON_E + 0.001)) < 1e-9
        assert abs(b_end[1] - _BIKE_LAT) < 1e-9

    def test_adjacent_bike_end_updated(self):
        """When BIKE-A is fused its fromNode moves; BIKE-C whose toNode is the same is updated."""
        # BIKE-A: N1 → N2 (fused).
        bike_a = _bike(
            lon_s=_BIKE_LON_S, lat_s=_BIKE_LAT,
            lon_e=_BIKE_LON_E, lat_e=_BIKE_LAT,
            link_id="BA", from_node="N1", to_node="N2",
        )
        # BIKE-C: N0 → N1, approaching from the west (no matching CAR).
        bike_c = _bike(
            lon_s=_BIKE_LON_S - 0.001, lat_s=_BIKE_LAT,
            lon_e=_BIKE_LON_S,          lat_e=_BIKE_LAT,
            link_id="BC", from_node="N0", to_node="N1",
        )
        fc = _fc(_car(), bike_a, bike_c)
        fuse_networks(fc)

        feat_c = next(f for f in fc["features"] if f["properties"]["linkId"] == "BC")
        car_coords = _car()["geometry"]["coordinates"]

        # BIKE-C's end (node N1) must now point to the CAR start position.
        c_end = feat_c["geometry"]["coordinates"][-1]
        assert abs(c_end[0] - car_coords[0][0]) < 1e-9
        assert abs(c_end[1] - car_coords[0][1]) < 1e-9

        # BIKE-C's start (node N0) must be unchanged.
        c_start = feat_c["geometry"]["coordinates"][0]
        assert abs(c_start[0] - (_BIKE_LON_S - 0.001)) < 1e-9
        assert abs(c_start[1] - _BIKE_LAT) < 1e-9


# ---------------------------------------------------------------------------
# Chain matching — one BIKE, multiple consecutive CAR links
# ---------------------------------------------------------------------------

class TestChaining:
    def test_bike_fused_with_chain_of_two_car_links(self):
        """BIKE spanning two consecutive CAR halves → 1 chain link_pair."""
        car1 = _car(lon_e=5.0005, link_id="C1")
        car2 = _car(lon_s=5.0005, lon_e=5.001, link_id="C2",
                    from_node="102", to_node="103")
        _, _, link_pairs, stats = fuse_networks(
            _fc(car1, car2, _bike()),
            max_lateral_dist_m=15.0,
        )
        assert len(link_pairs) == 1
        lp = link_pairs[0]
        assert lp["chainLength"] == 2
        assert "C1" in lp["carLinkId"]
        assert "C2" in lp["carLinkId"]
        assert lp["isReverse"] is False
        assert stats["fused_bike"] == 1

    def test_chain_geometry_stitched_correctly(self):
        """The fused BIKE gets 3 coordinates: C1_start, C1_end=C2_start, C2_end."""
        car1 = _car(lon_e=5.0005, link_id="C1")
        car2 = _car(lon_s=5.0005, lon_e=5.001, link_id="C2",
                    from_node="102", to_node="103")
        fc = _fc(car1, car2, _bike())
        fuse_networks(fc)
        bike_feat   = next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")
        bike_coords = bike_feat["geometry"]["coordinates"]
        assert len(bike_coords) == 3
        # All coordinates should be on the CAR latitude (no lateral offset).
        for coord in bike_coords:
            assert abs(coord[1] - _CAR_LAT) < 1e-9
        # Longitudes should be in increasing order.
        assert bike_coords[0][0] < bike_coords[1][0] < bike_coords[2][0]
        assert abs(bike_coords[0][0] - 5.0)    < 1e-9
        assert abs(bike_coords[1][0] - 5.0005) < 1e-9
        assert abs(bike_coords[2][0] - 5.001)  < 1e-9

    def test_single_car_still_preferred_over_chain(self):
        """When a single CAR fully covers a BIKE, no chain search is needed."""
        # The default _car() goes from 5.0 to 5.001, exactly covering _bike().
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), _bike()))
        assert link_pairs[0]["chainLength"] == 1


# ---------------------------------------------------------------------------
# Length constraint
# ---------------------------------------------------------------------------

class TestLengthConstraint:
    def test_car_much_longer_than_bike_not_fused(self):
        """CAR with endpoints within 30 m but a ~1100 m polyline → not fused."""
        # _car_zigzag() has the same endpoints as _car() but goes ~556 m north.
        _, _, link_pairs, stats = fuse_networks(_fc(_car_zigzag(), _bike()))
        assert link_pairs == []
        assert stats["fused_bike"] == 0

    def test_car_similar_length_fused(self):
        """The default _car() and _bike() have similar lengths → fused."""
        _, _, link_pairs, stats = fuse_networks(_fc(_car(), _bike()))
        assert len(link_pairs) == 1
        assert stats["fused_bike"] == 1

    def test_constant_value(self):
        """_MAX_LENGTH_INCREASE_FACTOR is defined and sane (> 1.0)."""
        assert _MAX_LENGTH_INCREASE_FACTOR > 1.0
        assert _SPEED_LIMIT_MAX_KMH > 0
