"""Tests for network_fuser_core.fuse_networks and helpers."""

from __future__ import annotations

import math

import pytest

from network_fuser.core.network_fuser_core import (
    _EXCLUDED_WEGTYPES,
    _build_snapped_segment,
    _compute_snap_region,
    _heading_diff,
    _lateral_side,
    _link_heading,
    _pt_to_line_dist_rd,
    fuse_networks,
)

# ---------------------------------------------------------------------------
# Test-data helpers
# ---------------------------------------------------------------------------

# Base coordinates in the Netherlands (required for wgs84_to_rd accuracy).
# CAR link runs due east: from (5.0, 52.0) to (5.001, 52.0) — heading ≈ 90°.
_CAR_LON_S, _CAR_LAT = 5.0,   52.0
_CAR_LON_E            = 5.001

# BIKE link offset 0.00005° north (≈ 5.6 m) — same heading, within 15 m threshold.
_OFFSET_LAT  = 0.00005          # ≈ 5.6 m north
_BIKE_LON_S  = _CAR_LON_S
_BIKE_LAT    = _CAR_LAT + _OFFSET_LAT
_BIKE_LON_E  = _CAR_LON_E

# WGS84 scale constants used in helper tests.
_LAT_SCALE = 111320.0
_LON_SCALE = 111320.0 * math.cos(math.radians(52.0))


def _car(lon_s=_CAR_LON_S, lat_s=_CAR_LAT, lon_e=_CAR_LON_E, lat_e=_CAR_LAT,
         link_id="C1", speed=30.0, reverse_ids=None) -> dict:
    """Build a CAR feature.  ``reverse_ids=None`` → one-way (default).
    Pass a non-empty list to make it a two-way road."""
    props: dict = {
        "mode": "CAR", "fromNode": "100", "toNode": "101",
        "linkId": link_id, "speed": speed,
    }
    if reverse_ids is not None:
        props["reverseLinkIds"] = reverse_ids
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[lon_s, lat_s], [lon_e, lat_e]]},
        "properties": props,
    }


def _car_twoway(lon_s=_CAR_LON_S, lat_s=_CAR_LAT, lon_e=_CAR_LON_E, lat_e=_CAR_LAT,
                link_id="C1") -> dict:
    """Build a two-way CAR feature (non-empty reverseLinkIds)."""
    return _car(lon_s=lon_s, lat_s=lat_s, lon_e=lon_e, lat_e=lat_e,
                link_id=link_id, reverse_ids=["C1_REV"])


def _car_curved(link_id="C1") -> dict:
    """CAR feature with 3 coordinates (slight northward bulge at the midpoint).
    No reverseLinkIds → one-way."""
    props: dict = {
        "mode": "CAR", "fromNode": "100", "toNode": "101", "linkId": link_id,
    }
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [_CAR_LON_S,  _CAR_LAT],
                [(_CAR_LON_S + _CAR_LON_E) / 2, _CAR_LAT + 0.000005],  # ~0.6 m bulge
                [_CAR_LON_E,  _CAR_LAT],
            ],
        },
        "properties": props,
    }


def _bike(lon_s=_BIKE_LON_S, lat_s=_BIKE_LAT, lon_e=_BIKE_LON_E, lat_e=_BIKE_LAT,
          link_id="B1", wegtype: str | None = None) -> dict:
    """2-coordinate BIKE feature (no intermediate vertices)."""
    props: dict = {
        "mode": "BIKE", "fromNode": "200", "toNode": "201", "linkId": link_id,
    }
    if wegtype is not None:
        props["wegtype"] = wegtype
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[lon_s, lat_s], [lon_e, lat_e]]},
        "properties": props,
    }


def _bike_extended(link_id="B_EXT") -> dict:
    """4-vertex BIKE going east, extending beyond the CAR on both sides.

    Layout (east direction):
      B0 (west of CAR start) → B1 (within CAR) → B2 (within CAR) → B3 (east of CAR end)

    B1 and B2 project within the CAR's longitudinal extent [5.0, 5.001] so
    they form the snap region.  B0 and B3 are outside the CAR extent.
    All vertices lie at _BIKE_LAT (slightly north of the CAR).
    """
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [_CAR_LON_S - 0.0005, _BIKE_LAT],   # B0: west of CAR start
                [_CAR_LON_S + 0.0003, _BIKE_LAT],   # B1: within CAR extent
                [_CAR_LON_E - 0.0003, _BIKE_LAT],   # B2: within CAR extent
                [_CAR_LON_E + 0.0005, _BIKE_LAT],   # B3: east of CAR end
            ],
        },
        "properties": {
            "mode": "BIKE", "fromNode": "200", "toNode": "201", "linkId": link_id,
        },
    }


def _bike_extended_rev(link_id="B_EXT_REV") -> dict:
    """4-vertex BIKE going *west* (opposite to eastbound CAR), extending beyond
    the CAR on both sides.  B1 and B2 fall within the CAR's longitudinal extent
    so they form the snap region."""
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [_CAR_LON_E + 0.0005, _BIKE_LAT],   # B0: east of CAR end
                [_CAR_LON_E - 0.0003, _BIKE_LAT],   # B1: within CAR extent
                [_CAR_LON_S + 0.0003, _BIKE_LAT],   # B2: within CAR extent
                [_CAR_LON_S - 0.0005, _BIKE_LAT],   # B3: west of CAR start
            ],
        },
        "properties": {
            "mode": "BIKE", "fromNode": "210", "toNode": "211", "linkId": link_id,
        },
    }


def _fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features), "properties": {}}


# ---------------------------------------------------------------------------
# _heading_diff
# ---------------------------------------------------------------------------

class TestHeadingDiff:
    def test_same_heading(self):
        assert _heading_diff(90.0, 90.0) == 0.0

    def test_opposite_headings(self):
        assert _heading_diff(90.0, 270.0) == 180.0

    def test_small_difference(self):
        assert abs(_heading_diff(10.0, 40.0) - 30.0) < 1e-9

    def test_wrap_around_360(self):
        # 350° and 10° are 20° apart.
        assert abs(_heading_diff(350.0, 10.0) - 20.0) < 1e-9

    def test_perpendicular(self):
        assert abs(_heading_diff(0.0, 90.0) - 90.0) < 1e-9


# ---------------------------------------------------------------------------
# _pt_to_line_dist_rd
# ---------------------------------------------------------------------------

class TestPtToLineDist:
    def test_perpendicular_above_midpoint(self):
        # Horizontal line (0,0)→(10,0), point (5,5): distance = 5.
        assert abs(_pt_to_line_dist_rd(5.0, 5.0, 0.0, 0.0, 10.0, 0.0) - 5.0) < 1e-9

    def test_beyond_endpoint_infinite_line(self):
        # Horizontal line (0,0)→(10,0), point (20, 5): infinite line distance still 5.
        assert abs(_pt_to_line_dist_rd(20.0, 5.0, 0.0, 0.0, 10.0, 0.0) - 5.0) < 1e-9

    def test_vertical_line(self):
        # Vertical line (0,0)→(0,10), point (5,5): distance = 5.
        assert abs(_pt_to_line_dist_rd(5.0, 5.0, 0.0, 0.0, 0.0, 10.0) - 5.0) < 1e-9

    def test_point_on_line(self):
        assert _pt_to_line_dist_rd(5.0, 0.0, 0.0, 0.0, 10.0, 0.0) < 1e-9

    def test_degenerate_segment(self):
        # A == B: distance to point A (3-4-5 triangle).
        assert abs(_pt_to_line_dist_rd(3.0, 4.0, 0.0, 0.0, 0.0, 0.0) - 5.0) < 1e-9


# ---------------------------------------------------------------------------
# _link_heading
# ---------------------------------------------------------------------------

class TestLinkHeading:
    def test_due_east(self):
        h = _link_heading([[5.0, 52.0], [5.001, 52.0]])
        assert abs(h - 90.0) < 1.0

    def test_due_west(self):
        h = _link_heading([[5.001, 52.0], [5.0, 52.0]])
        assert abs(h - 270.0) < 1.0

    def test_due_north(self):
        h = _link_heading([[5.0, 52.0], [5.0, 52.001]])
        assert h < 5.0 or h > 355.0   # ≈ 0°

    def test_due_south(self):
        h = _link_heading([[5.0, 52.001], [5.0, 52.0]])
        assert abs(h - 180.0) < 5.0


# ---------------------------------------------------------------------------
# _lateral_side
# ---------------------------------------------------------------------------

class TestLateralSide:
    def test_bike_left_of_car(self):
        # CAR from (0,0)→(1,0) (East). Point at (0.5, 5) is to the north = left.
        assert _lateral_side(0.5, 5.0, 0.0, 0.0, 1.0, 0.0) == 1.0

    def test_bike_right_of_car(self):
        # Same CAR. Point at (0.5, -5) is to the south = right.
        assert _lateral_side(0.5, -5.0, 0.0, 0.0, 1.0, 0.0) == -1.0


# ---------------------------------------------------------------------------
# _compute_snap_region
# ---------------------------------------------------------------------------

class TestComputeSnapRegion:
    def test_2coord_bike_returns_none(self):
        """A 2-vertex BIKE has no intermediate vertices → always None."""
        bike = [[5.0, 52.0], [5.001, 52.0]]
        car  = [[5.0, 52.0], [5.001, 52.0]]
        assert _compute_snap_region(bike, car, _LON_SCALE, _LAT_SCALE) is None

    def test_single_intermediate_within_extent(self):
        """One BIKE intermediate vertex projects within the CAR extent."""
        bike = [[4.999, 52.0], [5.0005, 52.0], [5.002, 52.0]]
        car  = [[5.0,   52.0], [5.001,  52.0]]
        result = _compute_snap_region(bike, car, _LON_SCALE, _LAT_SCALE)
        assert result == (1, 1)

    def test_intermediate_outside_extent_returns_none(self):
        """BIKE intermediate beyond the CAR endpoint does not project in."""
        bike = [[5.0, 52.0], [5.005, 52.0], [5.01, 52.0]]   # all past CAR
        car  = [[5.0, 52.0], [5.001, 52.0]]
        assert _compute_snap_region(bike, car, _LON_SCALE, _LAT_SCALE) is None

    def test_two_intermediates_snap_range(self):
        """Two BIKE intermediates within extent → range (1, 2)."""
        bike = [[4.999, 52.0], [5.0003, 52.0], [5.0007, 52.0], [5.002, 52.0]]
        car  = [[5.0,   52.0], [5.001,  52.0]]
        result = _compute_snap_region(bike, car, _LON_SCALE, _LAT_SCALE)
        assert result == (1, 2)

    def test_degenerate_car_returns_none(self):
        """CAR with coincident endpoints has no valid axis → None."""
        bike = [[5.0, 52.0], [5.0005, 52.0], [5.001, 52.0]]
        car  = [[5.0, 52.0], [5.0,    52.0]]
        assert _compute_snap_region(bike, car, _LON_SCALE, _LAT_SCALE) is None

    def test_endpoints_never_in_snap_region(self):
        """Even if a BIKE endpoint would project within CAR extent, it is excluded."""
        # Only 2 vertices (endpoints) — no intermediates.
        bike = [[5.0003, 52.0], [5.0007, 52.0]]
        car  = [[5.0,    52.0], [5.001,  52.0]]
        assert _compute_snap_region(bike, car, _LON_SCALE, _LAT_SCALE) is None


# ---------------------------------------------------------------------------
# _build_snapped_segment
# ---------------------------------------------------------------------------

class TestBuildSnappedSegment:
    def test_straight_car_two_coords_offset_north(self):
        """Eastbound 2-coord CAR, BIKE to left (north) → both output lats > CAR lat."""
        car = [[5.0, 52.0], [5.001, 52.0]]
        result = _build_snapped_segment(
            car, is_reverse=False, side=1.0, d_m=10.0,
            lon_sc=_LON_SCALE, lat_sc=_LAT_SCALE,
        )
        assert len(result) == 2
        assert result[0][1] > 52.0   # first coord moved north
        assert result[1][1] > 52.0   # second coord moved north

    def test_reversed_car_offset_stays_north(self):
        """is_reverse=True reverses the CAR coords and negates side so the offset
        remains on the same physical side (north for BIKE north of CAR)."""
        car = [[5.0, 52.0], [5.001, 52.0]]
        result = _build_snapped_segment(
            car, is_reverse=True, side=1.0, d_m=10.0,
            lon_sc=_LON_SCALE, lat_sc=_LAT_SCALE,
        )
        assert len(result) == 2
        # reversed CAR goes West; effective_side=-1; right of West = North.
        assert result[0][1] > 52.0
        assert result[1][1] > 52.0

    def test_curved_car_three_coords(self):
        """3-coord CAR → 3 offset output points."""
        car = [[5.0, 52.0], [5.0005, 52.000005], [5.001, 52.0]]
        result = _build_snapped_segment(
            car, is_reverse=False, side=1.0, d_m=10.0,
            lon_sc=_LON_SCALE, lat_sc=_LAT_SCALE,
        )
        assert len(result) == 3
        for coord in result:
            assert coord[1] > 52.0   # all moved north

    def test_zero_distance_no_offset(self):
        """d_m=0 → output coords equal input CAR coords."""
        car = [[5.0, 52.0], [5.001, 52.0]]
        result = _build_snapped_segment(
            car, is_reverse=False, side=1.0, d_m=0.0,
            lon_sc=_LON_SCALE, lat_sc=_LAT_SCALE,
        )
        assert abs(result[0][0] - 5.0)   < 1e-9
        assert abs(result[0][1] - 52.0)  < 1e-9
        assert abs(result[1][0] - 5.001) < 1e-9
        assert abs(result[1][1] - 52.0)  < 1e-9


# ---------------------------------------------------------------------------
# Single-mode / empty → no-op
# ---------------------------------------------------------------------------

class TestNoOp:
    def test_car_only(self):
        fc = _fc(_car())
        out_fc, node_map, link_pairs, stats = fuse_networks(fc)
        assert out_fc is fc
        assert node_map  == []
        assert link_pairs == []
        assert stats["link_pairs"] == 0

    def test_bike_only(self):
        fc = _fc(_bike())
        _, _, link_pairs, _ = fuse_networks(fc)
        assert link_pairs == []

    def test_empty(self):
        fc = _fc()
        _, _, link_pairs, stats = fuse_networks(fc)
        assert link_pairs == []
        assert stats["car_links"] == stats["bike_links"] == 0

    def test_all_bike_excluded_wegtype(self):
        """When all BIKE links are excluded by wegtype, result is empty."""
        fc = _fc(_car(), _bike(wegtype="solitair_fietspad"))
        _, _, link_pairs, stats = fuse_networks(fc)
        assert link_pairs == []
        assert stats["bike_eligible"]   == 0
        assert stats["skipped_wegtype"] == 1


# ---------------------------------------------------------------------------
# Basic match — CAR and parallel BIKE, same direction, within threshold
# ---------------------------------------------------------------------------

class TestBasicMatch:
    def setup_method(self):
        self.fc = _fc(_car(), _bike())
        self.out_fc, self.node_map, self.link_pairs, self.stats = fuse_networks(
            self.fc,
            max_lateral_dist_m   = 15.0,
            max_heading_diff_deg = 30.0,
        )

    def test_fc_is_same_object(self):
        """fuse_networks always returns the same fc object (may be modified)."""
        assert self.out_fc is self.fc

    def test_node_map_always_empty(self):
        assert self.node_map == []

    def test_one_link_pair(self):
        assert len(self.link_pairs) == 1

    def test_link_pair_fields(self):
        lp = self.link_pairs[0]
        assert lp["carLinkId"]   == "C1"
        assert lp["bikeLinkId"]  == "B1"
        assert 0.0 <= lp["avgLateralDistM"] <= 15.0
        assert lp["headingDiffDeg"] < 1.0       # nearly identical headings
        assert lp["isReverse"] is False

    def test_lateral_distance_approx_correct(self):
        # BIKE link is ~5.6 m north of CAR link.
        lp = self.link_pairs[0]
        assert 3.0 <= lp["avgLateralDistM"] <= 10.0

    def test_stats(self):
        assert self.stats["car_links"]       == 1
        assert self.stats["bike_links"]      == 1
        assert self.stats["bike_eligible"]   == 1
        assert self.stats["link_pairs"]      == 1
        assert self.stats["skipped_wegtype"] == 0
        assert self.stats["reverse_matches"] == 0

    def test_2coord_bike_no_snap(self):
        """A 2-coordinate BIKE has no intermediate vertices → never snapped."""
        orig_coords = [list(c) for c in self.fc["features"][1]["geometry"]["coordinates"]]
        assert self.fc["features"][1]["geometry"]["coordinates"] == orig_coords
        assert self.stats["snapped_bike"] == 0


# ---------------------------------------------------------------------------
# Direction filter
# ---------------------------------------------------------------------------

class TestDirectionFilter:
    def test_opposite_direction_excluded_on_twoway(self):
        """Two-way CAR: BIKE going west (270°) alongside east (90°) → 180° diff → no pair."""
        bike_opposite = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                               lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car_twoway(), bike_opposite),
            max_heading_diff_deg=30.0,
        )
        assert link_pairs == []

    def test_perpendicular_excluded(self):
        """BIKE going north (≈0°) alongside a CAR going east (≈90°) — 90° diff → no pair."""
        lon_mid = (_CAR_LON_S + _CAR_LON_E) / 2
        bike_north = _bike(lon_s=lon_mid, lat_s=_CAR_LAT,
                           lon_e=lon_mid, lat_e=_CAR_LAT + 0.001)
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), bike_north),
            max_heading_diff_deg=30.0,
        )
        assert link_pairs == []

    def test_within_heading_tolerance_included(self):
        """BIKE heading 20° off from CAR (within 30° tolerance) → match."""
        bike_diag = _bike(lon_s=_BIKE_LON_S, lat_s=_BIKE_LAT,
                          lon_e=_BIKE_LON_E, lat_e=_BIKE_LAT + 0.00002)
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), bike_diag),
            max_heading_diff_deg=30.0,
            max_lateral_dist_m=15.0,
        )
        assert len(link_pairs) == 1


# ---------------------------------------------------------------------------
# One-way road handling
# ---------------------------------------------------------------------------

class TestOneWayMatching:
    def test_opposite_direction_matched_on_oneway(self):
        """One-way CAR: BIKE going in the opposite direction → should be matched."""
        car_oneway   = _car()   # reverseLinkIds absent → one-way
        bike_reverse = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                              lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, link_pairs, stats = fuse_networks(
            _fc(car_oneway, bike_reverse),
            max_lateral_dist_m   = 15.0,
            max_heading_diff_deg = 30.0,
        )
        assert len(link_pairs) == 1
        assert link_pairs[0]["isReverse"] is True
        assert stats["reverse_matches"] == 1
        assert stats["one_way_car"] == 1

    def test_opposite_direction_rejected_on_twoway(self):
        """Two-way CAR: BIKE going opposite direction → should NOT be matched."""
        car_twoway   = _car_twoway()
        bike_reverse = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                              lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, link_pairs, stats = fuse_networks(
            _fc(car_twoway, bike_reverse),
            max_lateral_dist_m   = 15.0,
            max_heading_diff_deg = 30.0,
        )
        assert link_pairs == []
        assert stats["one_way_car"] == 0

    def test_same_direction_still_matched_on_oneway(self):
        """One-way CAR + same-direction BIKE → matched (existing behaviour preserved)."""
        _, _, link_pairs, stats = fuse_networks(
            _fc(_car(), _bike()),
            max_lateral_dist_m   = 15.0,
            max_heading_diff_deg = 30.0,
        )
        assert len(link_pairs) == 1
        assert link_pairs[0]["isReverse"] is False
        assert stats["reverse_matches"] == 0

    def test_oneway_both_directions_matched(self):
        """One-way CAR alongside two BIKE links (one each direction) → both matched."""
        bike_fwd = _bike(link_id="B_FWD")   # same direction
        bike_rev = _bike(link_id="B_REV",
                         lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                         lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)   # opposite
        _, _, link_pairs, stats = fuse_networks(
            _fc(_car(), bike_fwd, bike_rev),
            max_lateral_dist_m   = 15.0,
            max_heading_diff_deg = 30.0,
        )
        assert len(link_pairs) == 2
        assert stats["reverse_matches"] == 1
        fwd_pairs = [lp for lp in link_pairs if not lp["isReverse"]]
        rev_pairs = [lp for lp in link_pairs if lp["isReverse"]]
        assert len(fwd_pairs) == 1 and fwd_pairs[0]["bikeLinkId"] == "B_FWD"
        assert len(rev_pairs) == 1 and rev_pairs[0]["bikeLinkId"] == "B_REV"

    def test_empty_reverseLinkIds_list_is_oneway(self):
        """An explicit empty list for reverseLinkIds is treated as one-way."""
        car_explicit_empty = _car(reverse_ids=[])
        bike_reverse = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                              lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, link_pairs, _ = fuse_networks(
            _fc(car_explicit_empty, bike_reverse),
            max_lateral_dist_m   = 15.0,
            max_heading_diff_deg = 30.0,
        )
        assert len(link_pairs) == 1

    def test_nonempty_reverseLinkIds_is_twoway(self):
        """A non-empty reverseLinkIds makes the road two-way → opposite rejected."""
        car_twoway   = _car(reverse_ids=["C1_REV"])
        bike_reverse = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                              lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, link_pairs, _ = fuse_networks(
            _fc(car_twoway, bike_reverse),
            max_lateral_dist_m   = 15.0,
            max_heading_diff_deg = 30.0,
        )
        assert link_pairs == []


# ---------------------------------------------------------------------------
# Lateral distance filter
# ---------------------------------------------------------------------------

class TestLateralFilter:
    def test_too_far_laterally(self):
        """BIKE link 111 m north (0.001°) — far beyond any threshold."""
        bike_far = _bike(lat_s=_CAR_LAT + 0.001, lat_e=_CAR_LAT + 0.001)
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), bike_far), max_lateral_dist_m=15.0,
        )
        assert link_pairs == []

    def test_tight_threshold_excludes_close_link(self):
        """BIKE link 5.6 m north — excluded when threshold is 3 m."""
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike()), max_lateral_dist_m=3.0,
        )
        assert link_pairs == []

    def test_generous_threshold_includes_link(self):
        """BIKE link 5.6 m north — included when threshold is 10 m."""
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike()), max_lateral_dist_m=10.0,
        )
        assert len(link_pairs) == 1


# ---------------------------------------------------------------------------
# Multiple BIKE links per CAR link
# ---------------------------------------------------------------------------

class TestMultipleBikePerCar:
    def test_two_bike_links_both_match(self):
        """Two BIKE links alongside one CAR link — both should be paired."""
        bike1 = _bike(link_id="B1", lat_s=_CAR_LAT + 0.00003, lat_e=_CAR_LAT + 0.00003)
        bike2 = _bike(link_id="B2", lat_s=_CAR_LAT + 0.00006, lat_e=_CAR_LAT + 0.00006)
        _, _, link_pairs, stats = fuse_networks(
            _fc(_car(), bike1, bike2),
            max_lateral_dist_m=15.0,
        )
        bike_ids = {lp["bikeLinkId"] for lp in link_pairs}
        assert "B1" in bike_ids
        assert "B2" in bike_ids
        assert stats["link_pairs"] == 2

    def test_one_bike_too_far_one_close(self):
        """Only the close BIKE link should be paired."""
        bike_close = _bike(link_id="CLOSE",
                           lat_s=_CAR_LAT + 0.00005, lat_e=_CAR_LAT + 0.00005)
        bike_far   = _bike(link_id="FAR",
                           lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002)
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), bike_close, bike_far), max_lateral_dist_m=15.0,
        )
        assert len(link_pairs) == 1
        assert link_pairs[0]["bikeLinkId"] == "CLOSE"


# ---------------------------------------------------------------------------
# One BIKE link spans multiple CAR links
# ---------------------------------------------------------------------------

class TestBikeSpansMultipleCar:
    def test_long_bike_matches_two_car_links(self):
        """A long BIKE link running alongside two consecutive CAR links."""
        car1 = _car(lon_e=5.0005, link_id="C1")                         # first half
        car2 = _car(lon_s=5.0005, lon_e=5.001, link_id="C2")            # second half
        bike_long = _bike(lon_s=_BIKE_LON_S, lat_s=_BIKE_LAT,
                          lon_e=_BIKE_LON_E, lat_e=_BIKE_LAT, link_id="BLONG")
        _, _, link_pairs, stats = fuse_networks(
            _fc(car1, car2, bike_long), max_lateral_dist_m=15.0,
        )
        car_ids = {lp["carLinkId"] for lp in link_pairs}
        assert "C1" in car_ids
        assert "C2" in car_ids
        assert stats["link_pairs"] == 2


# ---------------------------------------------------------------------------
# Excluded wegtype filter
# ---------------------------------------------------------------------------

class TestExcludedWegtype:
    @pytest.mark.parametrize("wegtype", sorted(_EXCLUDED_WEGTYPES))
    def test_excluded_wegtype_not_matched(self, wegtype: str):
        _, _, link_pairs, stats = fuse_networks(
            _fc(_car(), _bike(wegtype=wegtype)),
            max_lateral_dist_m=15.0,
        )
        assert link_pairs == []
        assert stats["skipped_wegtype"] == 1
        assert stats["bike_eligible"]   == 0

    def test_normal_wegtype_matched(self):
        _, _, link_pairs, stats = fuse_networks(
            _fc(_car(), _bike(wegtype="rijbaan")),
            max_lateral_dist_m=15.0,
        )
        assert len(link_pairs) == 1
        assert stats["skipped_wegtype"] == 0

    def test_no_wegtype_property_matched(self):
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike()),    # no wegtype at all
            max_lateral_dist_m=15.0,
        )
        assert len(link_pairs) == 1

    def test_disable_filter_with_empty_frozenset(self):
        """excluded_wegtypes=frozenset() disables the filter entirely."""
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike(wegtype="solitair_fietspad")),
            max_lateral_dist_m  = 15.0,
            excluded_wegtypes   = frozenset(),
        )
        assert len(link_pairs) == 1


# ---------------------------------------------------------------------------
# Geometry snapping
# ---------------------------------------------------------------------------

class TestGeometrySnap:
    def test_2coord_bike_not_snapped(self):
        """A 2-coordinate BIKE has no intermediate vertices → never snapped,
        even when the CAR is curved."""
        fc = _fc(_car_curved(), _bike())   # _bike() is 2-coord
        _, _, _, stats = fuse_networks(fc, max_lateral_dist_m=15.0)
        assert stats["snapped_bike"] == 0
        bike_feature = next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")
        assert len(bike_feature["geometry"]["coordinates"]) == 2

    def test_straight_car_no_snap(self):
        """2-coord CAR + 2-coord BIKE → no snap (no intermediate vertices on BIKE)."""
        fc = _fc(_car(), _bike())
        _, _, _, stats = fuse_networks(fc, max_lateral_dist_m=15.0)
        assert stats["snapped_bike"] == 0
        bike_coords = fc["features"][1]["geometry"]["coordinates"]
        assert len(bike_coords) == 2
        assert bike_coords[0]  == [_BIKE_LON_S, _BIKE_LAT]
        assert bike_coords[-1] == [_BIKE_LON_E, _BIKE_LAT]

    def test_extended_bike_snapped(self):
        """4-coord BIKE with two intermediates in CAR extent → snapped."""
        fc = _fc(_car(), _bike_extended())
        _, _, _, stats = fuse_networks(fc, max_lateral_dist_m=15.0)
        assert stats["snapped_bike"] == 1

    def test_curved_car_snaps_extended_bike_five_coords(self):
        """3-coord CAR + 4-coord BIKE (2 intermediates in CAR extent) → 5-coord BIKE.

        Snap region covers both BIKE intermediates and replaces them with all 3
        CAR vertices (offset), growing the BIKE by one coordinate.
        """
        fc = _fc(_car_curved(), _bike_extended())
        _, _, _, stats = fuse_networks(fc, max_lateral_dist_m=15.0)
        assert stats["snapped_bike"] == 1
        bike_feature = next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")
        bike_coords = bike_feature["geometry"]["coordinates"]
        # 4-coord BIKE: [B0] + [CA_off, CM_off, CB_off] + [B3] = 5 coords
        assert len(bike_coords) == 5

    def test_bike_endpoints_always_preserved(self):
        """The first and last BIKE coordinates (network nodes) are never moved."""
        fc = _fc(_car_curved(), _bike_extended())
        fuse_networks(fc, max_lateral_dist_m=15.0)
        bike_feature = next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")
        bike_coords = bike_feature["geometry"]["coordinates"]
        assert bike_coords[0]  == [_CAR_LON_S - 0.0005, _BIKE_LAT]   # B0 preserved
        assert bike_coords[-1] == [_CAR_LON_E + 0.0005, _BIKE_LAT]   # B3 preserved

    def test_snapped_intermediates_follow_car_geometry(self):
        """Snapped intermediates lie 0.5 m to the BIKE's side of the corresponding
        CAR vertices (the BIKE is north of the eastbound road → offset is northward)."""
        fc = _fc(_car_curved(), _bike_extended())
        fuse_networks(fc, max_lateral_dist_m=15.0)
        bike_feature = next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")
        bike_coords = bike_feature["geometry"]["coordinates"]
        assert len(bike_coords) == 5
        # For an eastbound road the perpendicular offset is purely in latitude.
        expected_lat_offset = 0.5 / _LAT_SCALE
        for i, car_c in enumerate(_car_curved()["geometry"]["coordinates"]):
            assert abs(bike_coords[i + 1][0] - car_c[0]) < 1e-6
            assert abs(bike_coords[i + 1][1] - (car_c[1] + expected_lat_offset)) < 1e-6

    def test_snapped_intermediate_at_car_midpoint(self):
        """The middle snapped coord is 0.5 m north of the CAR midpoint latitude."""
        fc = _fc(_car_curved(), _bike_extended())
        fuse_networks(fc, max_lateral_dist_m=15.0)
        bike_feature = next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")
        bike_coords = bike_feature["geometry"]["coordinates"]
        assert len(bike_coords) == 5
        # bike_coords[2] = the CAR midpoint offset 0.5 m northward.
        car_mid_lat  = _CAR_LAT + 0.000005
        expected_lat = car_mid_lat + 0.5 / _LAT_SCALE
        assert abs(bike_coords[2][1] - expected_lat) < 1e-6
        assert abs(bike_coords[2][0] - (_CAR_LON_S + _CAR_LON_E) / 2) < 1e-6

    def test_reversed_bike_snapped_correctly(self):
        """One-way CAR + westbound BIKE (is_reverse=True) → reversed CAR vertices
        offset 0.5 m towards the BIKE's side (north, same as the forward case)."""
        fc = _fc(_car_curved(), _bike_extended_rev())
        _, _, link_pairs, stats = fuse_networks(fc, max_lateral_dist_m=15.0)
        assert len(link_pairs) == 1
        assert link_pairs[0]["isReverse"] is True
        assert stats["snapped_bike"] == 1

        bike_feature = next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")
        bike_coords = bike_feature["geometry"]["coordinates"]

        # Endpoints preserved (B0 = east, B3 = west for the westbound BIKE).
        assert bike_coords[0]  == [_CAR_LON_E + 0.0005, _BIKE_LAT]
        assert bike_coords[-1] == [_CAR_LON_S - 0.0005, _BIKE_LAT]
        # 4-coord BIKE + 3-coord CAR → 5-coord result.
        assert len(bike_coords) == 5
        # Snapped intermediates = reversed CAR vertices + 0.5 m northward offset.
        car_coords_rev    = list(reversed(_car_curved()["geometry"]["coordinates"]))
        expected_lat_offset = 0.5 / _LAT_SCALE
        for i, car_c in enumerate(car_coords_rev):
            assert abs(bike_coords[i + 1][0] - car_c[0]) < 1e-6
            assert abs(bike_coords[i + 1][1] - (car_c[1] + expected_lat_offset)) < 1e-6

    def test_unmatched_bike_not_snapped(self):
        """A BIKE link that does not match any CAR link retains its original geometry."""
        bike_far = _bike(lat_s=_CAR_LAT + 0.005, lat_e=_CAR_LAT + 0.005, link_id="BFAR")
        fc = _fc(_car_curved(), bike_far)
        fuse_networks(fc, max_lateral_dist_m=15.0)
        bike_feature = next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")
        assert len(bike_feature["geometry"]["coordinates"]) == 2
