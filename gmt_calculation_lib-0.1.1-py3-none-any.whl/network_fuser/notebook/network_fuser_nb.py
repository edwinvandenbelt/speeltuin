# Databricks notebook source
# ---------------------------------------------------------------------------
# network_fuser_nb.py — Databricks notebook interface for network_fuser.
#
# This notebook:
#   1. Reads widget parameters (network URI + thresholds).
#   2. Reads the merged multi-mode network GeoJSON from S3 (or local path).
#   3. Calls fuse_networks() — pure Python, no Spark I/O.
#   4. Writes the corrected network back to the same URI.
#   5. Writes NODE-MAP and LINK-PAIRS sidecar files alongside it.
#   6. Prints a summary.
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("network_fuser_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uri", "",
    "Full URI of the merged multi-mode network GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "area_id", "",
    "Area UUID (derived from filename when blank)",
)
dbutils.widgets.text(  # noqa: F821
    "mode_label", "MIXED",
    "Mode label used in sidecar filenames, e.g. MIXED",
)
dbutils.widgets.text(  # noqa: F821
    "max_lateral_dist_m", "15.0",
    "Maximum average perpendicular distance (metres) between BIKE link and CAR line",
)
dbutils.widgets.text(  # noqa: F821
    "max_heading_diff_deg", "30.0",
    "Maximum heading difference (degrees) between CAR and BIKE link",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from network_fuser.core.network_fuser_core import fuse_networks  # noqa: E402

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

NETWORK_URI       = dbutils.widgets.get("network_uri").strip()       # noqa: F821
AREA_ID           = dbutils.widgets.get("area_id").strip()           # noqa: F821
MODE_LABEL        = dbutils.widgets.get("mode_label").strip().upper() or "MIXED"  # noqa: F821
MAX_LATERAL_DIST  = float(dbutils.widgets.get("max_lateral_dist_m").strip() or "15.0")    # noqa: F821
MAX_HEADING_DIFF  = float(dbutils.widgets.get("max_heading_diff_deg").strip() or "30.0")   # noqa: F821

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty — provide a full network URI.")

logger.info(
    "network_uri=%s  area_id=%s  mode_label=%s  max_lateral_dist_m=%.1f  max_heading_diff_deg=%.1f",
    NETWORK_URI, AREA_ID or "(auto)", MODE_LABEL,
    MAX_LATERAL_DIST, MAX_HEADING_DIFF,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run NetworkFuser
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
print(f"Starting  {_t_start.isoformat()}")
print(f"Network URI          : {NETWORK_URI}")
print(f"Mode label           : {MODE_LABEL}")
print(f"max_lateral_dist_m   : {MAX_LATERAL_DIST}")
print(f"max_heading_diff_deg : {MAX_HEADING_DIFF}")
print()

_raw = _read_uri(NETWORK_URI)
_fc  = json.loads(_raw)

# Derive area_id from properties or filename when not supplied via widget.
_area_id = AREA_ID or (_fc.get("properties") or {}).get("area_id")
if not _area_id:
    _basename = NETWORK_URI.rsplit("/", 1)[-1]
    _area_id  = _basename.split("-NETWORK")[0] or "unknown"

_corrected_fc, _node_map, _link_pairs, _stats = fuse_networks(
    _fc,
    max_lateral_dist_m   = MAX_LATERAL_DIST,
    max_heading_diff_deg = MAX_HEADING_DIFF,
)

# The fuser no longer modifies the network geometry; writing it back is a no-op
# but kept for pipeline consistency.
_net_payload = json.dumps(_corrected_fc, ensure_ascii=False).encode("utf-8")
_write_uri(NETWORK_URI, _net_payload)

# Derive sidecar URIs (same S3 prefix / folder as the network).
_base_uri = NETWORK_URI.rsplit("/", 1)[0]
_node_map_uri   = f"{_base_uri}/{_area_id}-NODE-MAP-{MODE_LABEL}.json"
_link_pairs_uri = f"{_base_uri}/{_area_id}-LINK-PAIRS-{MODE_LABEL}.json"

_write_uri(_node_map_uri,   json.dumps(_node_map,   ensure_ascii=False).encode("utf-8"))
_write_uri(_link_pairs_uri, json.dumps(_link_pairs, ensure_ascii=False).encode("utf-8"))

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"NetworkFuser complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Area ID          : {_area_id}")
print(f"  Mode label       : {MODE_LABEL}")
print(f"  CAR links        : {_stats['car_links']}")
print(f"  BIKE links       : {_stats['bike_links']}")
print(f"  Node map entries : {_stats['node_map']}")
print(f"  Link pairs       : {_stats['link_pairs']}")
print(f"  Snapped endpoints: {_stats['snapped']}")
print(f"  Node-map URI     : {_node_map_uri}")
print(f"  Link-pairs URI   : {_link_pairs_uri}")
print(_SEP)
