"""Pure-Python network_simplifier core — no I/O, no boto3, no external deps.

Removes "pass-through" nodes from a NETWORK-RAW GeoJSON FeatureCollection.

A pass-through node B is eligible for removal when:
  - Exactly 2 distinct links are incident to B.
  - The 2 neighbouring nodes A and C have different IDs.
  - At least one traversal direction through B is fully connected:
      - A→B→C (forward): link AB is passable A→B AND link BC is passable B→C.
      - C→B→A (backward): link BC is passable C→B AND link AB is passable B→A.

When B is removed, the two links are replaced by a single merged link:
  - from_node = A, to_node = C
  - rijrichting_heen  = True  iff A→C was passable through B
  - rijrichting_terug = True  iff C→A was passable through B
  - linkId / segment_id       = min of the two legs (whichever key is present)
  - max_snelheid_heen / _terug = min of the two legs' speed in that direction
  - cap_heen / _terug          = min of the two legs' capacity in that direction
  - rijstroken_heen / _terug   = min of the two legs' lane count in that direction
  - flow_heen / flow_terug     = nested flow dict from the leg whose 24-hr flow total
                                  (sum of motief values) is smallest in that direction
  - flow_dp_heen / _terug      = same selection rule (smallest total)
  - length                     = sum of both legs' lengths
  - geometry                   = coordinates of leg1 followed by leg2 (B removed)
  - All other attributes where both legs carry the same value are preserved as-is.

"24-hr flow" per direction = sum of all values in the corresponding flow_heen or
flow_terug nested dict.

Simplification runs iteratively until no more nodes can be removed.

Public API
----------
simplify_network(fc, *, collect_nodes=False) -> tuple[dict, dict]
    fc     : GeoJSON FeatureCollection (NETWORK-RAW, from network_fetcher)
    Returns: (simplified_fc, stats)
    stats keys: original_links, removed_nodes, merged_links, final_links.
    When collect_nodes is True, stats also contains "removed_nodes_fc".
"""

from __future__ import annotations

import logging
from collections import defaultdict

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Directional helpers
# ---------------------------------------------------------------------------


def _other_node(props: dict, node: int | str) -> int | str:
    """Return the endpoint of link *props* that is NOT *node*."""
    return props["toNode"] if props["fromNode"] == node else props["fromNode"]


def _can_enter(props: dict, node: int | str) -> bool:
    """True if the link allows arriving at *node* (from the other end)."""
    if props["toNode"] == node:
        return bool(props.get("rijrichting_heen"))
    return bool(props.get("rijrichting_terug"))


def _can_leave(props: dict, node: int | str) -> bool:
    """True if the link allows departing from *node* (toward the other end)."""
    if props["fromNode"] == node:
        return bool(props.get("rijrichting_heen"))
    return bool(props.get("rijrichting_terug"))


def _dir_value(props: dict, from_node: int | str, heen_key: str, terug_key: str) -> float | None:
    """Return the scalar heen or terug value for the direction traversed *from* from_node.

    Returns None when the property is absent or None (e.g. OSM links with unknown capacity).
    """
    val = props.get(heen_key) if props["fromNode"] == from_node else props.get(terug_key)
    return float(val) if val is not None else None


def _min_or_none(a: float | None, b: float | None) -> float | None:
    """Return min(a, b), or None if either operand is None (unknown)."""
    if a is None or b is None:
        return None
    return min(a, b)  # type: ignore[type-var]


def _dir_flow(props: dict, from_node: int | str, heen_key: str, terug_key: str) -> dict:
    """Return the flow dict for the direction traversed *from* from_node."""
    if props["fromNode"] == from_node:
        return props.get(heen_key) or {}
    return props.get(terug_key) or {}


def _flow_total(flow_dict: dict) -> float:
    """24-hr flow total = sum of all motief/daypart values."""
    return sum(flow_dict.values()) if flow_dict else 0.0


def _pick_flow(d1: dict, d2: dict) -> dict:
    """Return a copy of the flow dict with the smaller total."""
    return dict(d1) if _flow_total(d1) <= _flow_total(d2) else dict(d2)


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------


def _coords_from(feat: dict, from_node: int | str) -> list[list[float]]:
    """Return link coordinates ordered so the sequence starts at from_node."""
    coords: list[list[float]] = feat["geometry"]["coordinates"]
    if feat["properties"]["fromNode"] == from_node:
        return list(coords)
    return list(reversed(coords))


def _merge_geometries(feat1: dict, n1: int | str, feat2: dict, node_b: int | str) -> dict:
    """Return merged LineString geometry: n1 → … → B → … → n2 (B shared point removed)."""
    coords1 = _coords_from(feat1, n1)  # ends at B
    coords2 = _coords_from(feat2, node_b)  # starts at B
    return {"type": "LineString", "coordinates": coords1 + coords2[1:]}


# ---------------------------------------------------------------------------
# Handled property keys (not copied via the equal-value fallback)
# ---------------------------------------------------------------------------

_HANDLED_KEYS = frozenset(
    {
        "fromNode",
        "toNode",
        "rijrichting_heen",
        "rijrichting_terug",
        "max_snelheid_heen",
        "max_snelheid_terug",
        "cap_heen",
        "cap_terug",
        "rijstroken_heen",
        "rijstroken_terug",
        "flow_heen",
        "flow_terug",
        "flow_dp_heen",
        "flow_dp_terug",
        "length",
        "linkId",
        "segment_id",
    }
)


# ---------------------------------------------------------------------------
# Single-pass merge
# ---------------------------------------------------------------------------


def _merge_features(
    feat1: dict,
    feat2: dict,
    node_b: int | str,
    n1: int | str,
    n2: int | str,
    fwd: bool,
    bwd: bool,
) -> dict:
    """Merge feat1 (n1↔B) and feat2 (B↔n2) by removing node_b.

    fwd = n1→n2 is passable; bwd = n2→n1 is passable.
    The merged link is oriented from_node=n1, to_node=n2.
    """
    p1 = feat1["properties"]
    p2 = feat2["properties"]

    # --- directional scalars: min per leg ---
    spd_heen = (
        _min_or_none(
            _dir_value(p1, n1, "max_snelheid_heen", "max_snelheid_terug"),
            _dir_value(p2, node_b, "max_snelheid_heen", "max_snelheid_terug"),
        )
        if fwd
        else 0.0
    )

    spd_terug = (
        _min_or_none(
            _dir_value(p2, n2, "max_snelheid_heen", "max_snelheid_terug"),
            _dir_value(p1, node_b, "max_snelheid_heen", "max_snelheid_terug"),
        )
        if bwd
        else 0.0
    )

    cap_heen = (
        _min_or_none(
            _dir_value(p1, n1, "cap_heen", "cap_terug"),
            _dir_value(p2, node_b, "cap_heen", "cap_terug"),
        )
        if fwd
        else None
    )

    cap_terug = (
        _min_or_none(
            _dir_value(p2, n2, "cap_heen", "cap_terug"),
            _dir_value(p1, node_b, "cap_heen", "cap_terug"),
        )
        if bwd
        else None
    )

    _rij_heen = (
        _min_or_none(
            _dir_value(p1, n1, "rijstroken_heen", "rijstroken_terug"),
            _dir_value(p2, node_b, "rijstroken_heen", "rijstroken_terug"),
        )
        if fwd
        else None
    )
    rij_heen = int(_rij_heen) if _rij_heen is not None else None

    _rij_terug = (
        _min_or_none(
            _dir_value(p2, n2, "rijstroken_heen", "rijstroken_terug"),
            _dir_value(p1, node_b, "rijstroken_heen", "rijstroken_terug"),
        )
        if bwd
        else None
    )
    rij_terug = int(_rij_terug) if _rij_terug is not None else None

    # --- flows: n1→n2 direction (heen of merged link) ---
    flow_heen = _pick_flow(
        _dir_flow(p1, n1, "flow_heen", "flow_terug"),
        _dir_flow(p2, node_b, "flow_heen", "flow_terug"),
    )
    flow_dp_heen = _pick_flow(
        _dir_flow(p1, n1, "flow_dp_heen", "flow_dp_terug"),
        _dir_flow(p2, node_b, "flow_dp_heen", "flow_dp_terug"),
    )

    # --- flows: n2→n1 direction (terug of merged link) ---
    flow_terug = _pick_flow(
        _dir_flow(p2, n2, "flow_heen", "flow_terug"),
        _dir_flow(p1, node_b, "flow_heen", "flow_terug"),
    )
    flow_dp_terug = _pick_flow(
        _dir_flow(p2, n2, "flow_dp_heen", "flow_dp_terug"),
        _dir_flow(p1, node_b, "flow_dp_heen", "flow_dp_terug"),
    )

    # --- base properties ---
    props: dict = {
        "fromNode": n1,
        "toNode": n2,
        "rijrichting_heen": fwd,
        "rijrichting_terug": bwd,
        "max_snelheid_heen": spd_heen,
        "max_snelheid_terug": spd_terug,
        "cap_heen": cap_heen,
        "cap_terug": cap_terug,
        "rijstroken_heen": rij_heen,
        "rijstroken_terug": rij_terug,
        "flow_heen": flow_heen,
        "flow_terug": flow_terug,
        "flow_dp_heen": flow_dp_heen,
        "flow_dp_terug": flow_dp_terug,
        "length": (p1.get("length") or 0.0) + (p2.get("length") or 0.0),
    }

    # linkId / segment_id: take min of whichever key(s) are present
    for id_key in ("linkId", "segment_id"):
        v1, v2 = p1.get(id_key), p2.get(id_key)
        if v1 is not None and v2 is not None:
            props[id_key] = min(v1, v2)
        elif v1 is not None:
            props[id_key] = v1
        elif v2 is not None:
            props[id_key] = v2

    # Copy any additional attribute that has the same value in both legs
    for key in p1:
        if key in _HANDLED_KEYS or key in props:
            continue
        if key in p2 and p1[key] == p2[key]:
            props[key] = p1[key]

    return {
        "type": "Feature",
        "geometry": _merge_geometries(feat1, n1, feat2, node_b),
        "properties": props,
    }


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def simplify_network(fc: dict, *, collect_nodes: bool = False) -> tuple[dict, dict]:
    """Remove pass-through nodes from a NETWORK-RAW GeoJSON FeatureCollection.

    Parameters
    ----------
    fc:
        GeoJSON FeatureCollection produced by network_fetcher.
    collect_nodes:
        When True, populate ``stats["removed_nodes_fc"]`` with a GeoJSON
        FeatureCollection of Point features — one per removed node.

    Returns
    -------
    simplified_fc:
        New FeatureCollection with pass-through nodes removed.
    stats:
        Dictionary with keys: original_links, removed_nodes, merged_links,
        final_links.  When *collect_nodes* is True, also contains
        ``removed_nodes_fc`` (GeoJSON FeatureCollection of removed node Points).
    """
    features: list[dict] = list(fc.get("features") or [])
    original_links = len(features)
    total_removed_nodes = 0
    total_merged_links = 0
    node_point_features: list[dict] = []

    while True:
        active: list[dict] = [f for f in features if f is not None]

        active_idx: dict[int | str, list[int]] = defaultdict(list)
        for i, feat in enumerate(active):
            p = feat["properties"]
            active_idx[p["fromNode"]].append(i)
            active_idx[p["toNode"]].append(i)

        removed_this_round = 0
        merged_map: dict[int, dict] = {}
        consumed: set[int] = set()

        for node, link_idxs in active_idx.items():
            if len(link_idxs) != 2:
                continue
            i1, i2 = link_idxs
            if i1 in consumed or i2 in consumed:
                continue

            f1, f2 = active[i1], active[i2]
            p1, p2 = f1["properties"], f2["properties"]

            n1 = _other_node(p1, node)
            n2 = _other_node(p2, node)
            if n1 == n2:
                continue  # loop edge

            fwd = _can_enter(p1, node) and _can_leave(p2, node)  # n1→node→n2
            bwd = _can_enter(p2, node) and _can_leave(p1, node)  # n2→node→n1
            if not (fwd or bwd):
                continue

            merged = _merge_features(f1, f2, node, n1, n2, fwd, bwd)
            merged_map[i1] = merged
            consumed.add(i1)
            consumed.add(i2)
            removed_this_round += 1

            if collect_nodes:
                b_coord = _coords_from(f1, n1)[-1]
                node_point_features.append(
                    {
                        "type": "Feature",
                        "geometry": {"type": "Point", "coordinates": b_coord},
                        "properties": {
                            "nodeId": node,
                            "linkId1": p1.get("linkId") or p1.get("segment_id"),
                            "linkId2": p2.get("linkId") or p2.get("segment_id"),
                            "streetName": p1.get("streetName") or p2.get("streetName"),
                        },
                    }
                )

        if not removed_this_round:
            features = active
            break

        result: list[dict] = []
        for i, feat in enumerate(active):
            if i in consumed and i not in merged_map:
                continue
            elif i in merged_map:
                result.append(merged_map[i])
            else:
                result.append(feat)

        features = result
        total_removed_nodes += removed_this_round
        total_merged_links += removed_this_round

        logger.debug("Round complete: removed %d nodes", removed_this_round)

    stats: dict = {
        "original_links": original_links,
        "removed_nodes": total_removed_nodes,
        "merged_links": total_merged_links,
        "final_links": len(features),
    }
    if collect_nodes:
        stats["removed_nodes_fc"] = {
            "type": "FeatureCollection",
            "features": node_point_features,
        }
    simplified_fc: dict = {"type": "FeatureCollection", "features": features}
    if "properties" in fc:
        simplified_fc["properties"] = fc["properties"]
    return simplified_fc, stats
