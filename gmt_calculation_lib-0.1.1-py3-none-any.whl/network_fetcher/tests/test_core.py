"""Unit tests for network_fetcher core — pure Python, no I/O."""

from __future__ import annotations

import json

import pytest

from network_fetcher.core.network_fetcher_core import (
    _DAYPART_KEYS,
    _MOTIEF_KEYS,
    _PT_PARAMS,
    VALID_MODES,
    build_intersection_sql,
    get_pt_params,
    rows_to_feature_collection,
)


# ---------------------------------------------------------------------------
# build_intersection_sql
# ---------------------------------------------------------------------------


class TestBuildIntersectionSql:
    def test_car_contains_db_prefix(self):
        sql = build_intersection_sql("CAR", "spectrum", "2024_01")
        assert "spectrum.`2024_01`.d110_toedeelbaar_autonetwerk" in sql

    def test_bike_contains_fiets_table(self):
        sql = build_intersection_sql("BIKE", "spectrum", "2023_01")
        assert "d120_toedeelbaar_fietsnetwerk" in sql

    def test_pedestrian_uses_catalog_dot_pedestrians(self):
        sql = build_intersection_sql("PEDESTRIAN", "spectrum", "2025_12")
        assert "loopstromenmodel.`2025_12`.intensiteiten_voetgangers_202512" in sql
        assert "ST_StartPoint" in sql
        assert "ST_EndPoint" in sql

    @pytest.mark.parametrize("mode", ["BUS", "TRAM", "METRO", "TRAIN"])
    def test_pt_modes_contain_ov_table(self, mode):
        sql = build_intersection_sql(mode, "spectrum", "2023_01")
        assert "d140_toedeelbaar_ov_netwerk_links" in sql

    def test_car_has_single_placeholder(self):
        sql = build_intersection_sql("CAR", "spectrum", "2023_01")
        assert sql.count("?") == 1

    def test_bike_has_single_placeholder(self):
        sql = build_intersection_sql("BIKE", "spectrum", "2023_01")
        assert sql.count("?") == 1

    def test_pedestrian_has_single_placeholder(self):
        sql = build_intersection_sql("PEDESTRIAN", "spectrum", "2023_01")
        assert sql.count("?") == 1

    @pytest.mark.parametrize("mode", ["BUS", "TRAM", "METRO", "TRAIN"])
    def test_pt_has_four_placeholders(self, mode):
        sql = build_intersection_sql(mode, "spectrum", "2023_01")
        assert sql.count("?") == 4

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError, match="Unsupported mode"):
            build_intersection_sql("HELICOPTER", "spectrum", "2023_01")

    def test_all_valid_modes_accepted(self):
        for mode in VALID_MODES:
            sql = build_intersection_sql(mode, "spectrum", "2023_01")
            assert "?" in sql

    def test_catalog_schema_in_sql_car(self):
        sql = build_intersection_sql("CAR", "mycatalog", "2025_01")
        assert "mycatalog.`2025_01`" in sql

    def test_flow_pivot_columns_present(self):
        sql = build_intersection_sql("CAR", "spectrum", "2023_01")
        for key in _MOTIEF_KEYS:
            assert f"flow_heen_{key}" in sql
            assert f"flow_terug_{key}" in sql

    def test_daypart_pivot_columns_present(self):
        for mode in ("CAR", "BIKE"):
            sql = build_intersection_sql(mode, "spectrum", "2023_01")
            for dp in _DAYPART_KEYS:
                assert f"flow_dp_heen_{dp}" in sql, f"Missing flow_dp_heen_{dp} in {mode} SQL"
                assert f"flow_dp_terug_{dp}" in sql, f"Missing flow_dp_terug_{dp} in {mode} SQL"

    def test_daypart_pivot_columns_present_pedestrian(self):
        sql = build_intersection_sql("PEDESTRIAN", "spectrum", "2023_01")
        for dp in _DAYPART_KEYS:
            assert f"flow_dp_heen_{dp}" in sql
            assert f"flow_dp_terug_{dp}" in sql

    @pytest.mark.parametrize("mode", ["BUS", "TRAM", "METRO", "TRAIN"])
    def test_daypart_pivot_columns_present_pt(self, mode):
        sql = build_intersection_sql(mode, "spectrum", "2023_01")
        for dp in _DAYPART_KEYS:
            assert f"flow_dp_heen_{dp}" in sql
            assert f"flow_dp_terug_{dp}" in sql


# ---------------------------------------------------------------------------
# get_pt_params
# ---------------------------------------------------------------------------


class TestGetPtParams:
    @pytest.mark.parametrize("mode,link_mode,modaliteit", [
        ("BUS",   "other", "bus"),
        ("TRAM",  "other", "tram"),
        ("METRO", "other", "metro"),
        ("TRAIN", "train", "trein"),
    ])
    def test_known_modes(self, mode, link_mode, modaliteit):
        lm, mod = get_pt_params(mode)
        assert lm == link_mode
        assert mod == modaliteit

    def test_unknown_raises_key_error(self):
        with pytest.raises(KeyError):
            get_pt_params("FERRY")


# ---------------------------------------------------------------------------
# rows_to_feature_collection
# ---------------------------------------------------------------------------


class TestRowsToFeatureCollection:
    def _make_rows(self):
        """Return (rows, col_names) for a minimal two-row result."""
        geom_str = json.dumps({"type": "LineString", "coordinates": [[0, 0], [1, 1]]})
        col_names = (
            ["segment_id", "geom", "mode", "from_node", "to_node",
             "rijrichting_heen", "cap_heen", "rijstroken_heen", "max_snelheid_heen"]
            + [f"flow_heen_{k}" for k in _MOTIEF_KEYS]
            + ["rijrichting_terug", "cap_terug", "rijstroken_terug", "max_snelheid_terug"]
            + [f"flow_terug_{k}" for k in _MOTIEF_KEYS]
            + [f"flow_dp_heen_{k}" for k in _DAYPART_KEYS]
            + [f"flow_dp_terug_{k}" for k in _DAYPART_KEYS]
            + ["length"]
        )
        row = (
            1, geom_str, "CAR", 10, 20,
            True, 2000, 2, 80,
            100.0, 50.0, 0.0, 0.0, 0.0,
            80.0, 40.0, 0.0, 0.0, 0.0,
            True, 2000, 2, 80,
            # daypart heen: mrh, erh, rest
            60.0, 50.0, 30.0,
            # daypart terug: mrh, erh, rest
            45.0, 40.0, 25.0,
            150.0,
        )
        return [row, row], col_names

    def test_returns_feature_collection(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        assert fc["type"] == "FeatureCollection"
        assert len(fc["features"]) == 2

    def test_flow_pivot_folded(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert "flow_heen" in props
        assert "flow_terug" in props
        assert props["flow_heen"]["work"] == 100.0

    def test_daypart_pivot_folded(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert "flow_dp_heen" in props
        assert "flow_dp_terug" in props
        assert props["flow_dp_heen"]["mrh"] == 60.0
        assert props["flow_dp_terug"]["rest"] == 25.0

    def test_geom_is_parsed(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        geom = fc["features"][0]["geometry"]
        assert geom["type"] == "LineString"

    def test_geom_column_removed_from_props(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert "geom" not in props

    def test_empty_rows(self):
        fc = rows_to_feature_collection([], ["segment_id", "geom", "mode"], "CAR")
        assert fc["features"] == []

    def test_modes_in_properties(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "BIKE")
        assert fc["properties"]["modes"] == ["BIKE"]

    def test_link_properties_in_properties(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        assert "fields" in fc["properties"]
        assert isinstance(fc["properties"]["fields"], list)
