# Databricks notebook source
# ---------------------------------------------------------------------------
# network_fetcher_nb.py — Databricks notebook interface for network_fetcher.
#
# This notebook:
#   1. Reads widget parameters (modes, bbox, catalog, schema, output_folder).
#   2. Executes Databricks SQL queries per mode using build_intersection_sql.
#   3. Assembles raw GeoJSON FeatureCollections via rows_to_feature_collection.
#   4. Writes results back to S3.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("network_fetcher_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text("modes", "CAR,BIKE", "Transport modes (comma-separated)")  # noqa: F821
dbutils.widgets.text(
    "bbox", "6.143,52.248,6.184,52.272", "Bounding box: minLon,minLat,maxLon,maxLat"
)  # noqa: F821
dbutils.widgets.text("catalog", "spectrum", "Databricks Unity Catalog")  # noqa: F821
dbutils.widgets.text("schema", "2024_01", "Databricks schema / dataset version")  # noqa: F821
dbutils.widgets.text("output_folder", "s3://gmp-networks/network/", "Output folder URI")  # noqa: F821
dbutils.widgets.text("area_id", "", "Area identifier (optional)")  # noqa: F821
dbutils.widgets.text("w_mrh", "2.0", "ETM hour-weight ochtendspits (default 2.0)")  # noqa: F821
dbutils.widgets.text("w_erh", "2.0", "ETM hour-weight avondspits (default 2.0)")  # noqa: F821
dbutils.widgets.text("w_rest", "13.72", "ETM hour-weight restdag (default 13.72)")  # noqa: F821
dbutils.widgets.text("LOG_LEVEL", "INFO", "Log level (DEBUG / INFO / WARNING / ERROR)")  # noqa: F821

# COMMAND ----------
_ll = getattr(logging, dbutils.widgets.get("LOG_LEVEL").strip().upper(), logging.INFO)  # noqa: F821
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
MODES = [m.strip().upper() for m in dbutils.widgets.get("modes").split(",") if m.strip()]  # noqa: F821
BBOX = [float(x) for x in dbutils.widgets.get("bbox").split(",")]  # noqa: F821
CATALOG = dbutils.widgets.get("catalog").strip()  # noqa: F821
SCHEMA = dbutils.widgets.get("schema").strip()  # noqa: F821
OUT_FOLDER = dbutils.widgets.get("output_folder").strip().rstrip("/") + "/"  # noqa: F821
AREA_ID = dbutils.widgets.get("area_id").strip() or None  # noqa: F821
W_MRH = float(dbutils.widgets.get("w_mrh").strip())  # noqa: F821
W_ERH = float(dbutils.widgets.get("w_erh").strip())  # noqa: F821
W_REST = float(dbutils.widgets.get("w_rest").strip())  # noqa: F821

if not MODES:
    raise ValueError("Widget 'modes' is empty.")
if len(BBOX) != 4:
    raise ValueError(f"Widget 'bbox' must have 4 comma-separated values, got {len(BBOX)}.")

logger.info("modes=%s  bbox=%s  catalog=%s  schema=%s", MODES, BBOX, CATALOG, SCHEMA)

# COMMAND ----------
import json
import sys

sys.path.insert(0, "/Workspace/Shared/gmt-calculation-lib/src")

from network_fetcher.core.network_fetcher_core import (  # noqa: E402
    build_intersection_sql,
    get_pt_params,
    rows_to_feature_collection,
    VALID_MODES,
)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run NetworkFetcher
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess.

# COMMAND ----------
import boto3  # noqa: E402, PLC0415

_PT_MODES = {"BUS", "TRAM", "METRO", "TRAIN"}


def _geojson_polygon(bbox):
    x1, y1, x2, y2 = bbox
    ring = [[x1, y1], [x2, y1], [x2, y2], [x1, y2], [x1, y1]]
    return json.dumps({"type": "Polygon", "coordinates": [ring]})


def _put_s3(uri: str, data: bytes) -> None:
    assert uri.startswith("s3://"), f"Expected s3:// URI, got {uri!r}"
    rest = uri[5:]
    bucket, _, key = rest.partition("/")
    boto3.client("s3").put_object(
        Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json"
    )
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


_t_start = datetime.now(timezone.utc)
polygon_json = _geojson_polygon(BBOX)
_results: dict[str, int] = {}
_mode_fcs: dict[str, dict] = {}

for _mode in MODES:
    if _mode not in VALID_MODES:
        logger.warning("Unknown mode %r — skipping", _mode)
        continue

    logger.info("Fetching mode=%s ...", _mode)
    _sql = build_intersection_sql(
        _mode,
        CATALOG,
        SCHEMA,
        weights={"mrh": W_MRH, "erh": W_ERH, "rest": W_REST},
    )

    if _mode in _PT_MODES:
        _link_mode, _modaliteit = get_pt_params(_mode)
        _params = (_link_mode, polygon_json, _modaliteit, _mode)
    else:
        _params = (polygon_json,)  # type: ignore[assignment]

    _rows = spark.sql(_sql, _params).collect()  # noqa: F821
    _col_names = _rows[0].__fields__ if _rows else []

    _fc = rows_to_feature_collection(
        [tuple(r) for r in _rows],
        list(_col_names),
        _mode,
    )
    _fc["properties"].update({"bbox": BBOX, "area_id": AREA_ID})
    _mode_fcs[_mode] = _fc

    _area_prefix = AREA_ID or "area"
    _out_uri = f"{OUT_FOLDER}{_area_prefix}-NETWORK-RAW-{_mode}.geojson"
    _put_s3(_out_uri, json.dumps(_fc, ensure_ascii=False).encode("utf-8"))
    _results[_mode] = len(_fc["features"])
    logger.info("mode=%s  features=%d  written to %s", _mode, len(_fc["features"]), _out_uri)

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
_SEP = "─" * 60
print(_SEP)
print(f"NetworkFetcher complete — {_elapsed:.1f}s")
print(_SEP)
for _m, _n in _results.items():
    print(f"  {_m:<12} : {_n} raw features")
print(f"  Output   : {OUT_FOLDER}")
print(_SEP)

# COMMAND ----------
# MAGIC %md
# MAGIC ## Kaartvisualisatie
# MAGIC
# MAGIC Toont de geselecteerde wegvakken via een inline Leaflet-kaart (`displayHTML`).
# MAGIC Kleur = totale flow heen (grijs = geen flow, geel→rood = oplopende flow).


# COMMAND ----------
def _leaflet_map(feature_collections: dict[str, dict], polygon_json_str: str) -> str:
    """Genereer een zelfstandige HTML-pagina met een Leaflet-kaart.

    Parameters
    ----------
    feature_collections:
        Dict van mode → GeoJSON FeatureCollection.
    polygon_json_str:
        GeoJSON Polygon-string van het selectiegebied.
    """
    import json as _json

    # Bereken centrum van het selectiepolygon voor de initiële kaartweergave
    _coords = _json.loads(polygon_json_str)["coordinates"][0]
    _lons = [c[0] for c in _coords]
    _lats = [c[1] for c in _coords]
    _center_lat = (min(_lats) + max(_lats)) / 2
    _center_lon = (min(_lons) + max(_lons)) / 2

    # Kleur per mode
    _mode_colors = {
        "CAR": "#e31a1c",
        "BIKE": "#1f78b4",
        "PEDESTRIAN": "#33a02c",
        "BUS": "#ff7f00",
        "TRAM": "#6a3d9a",
        "METRO": "#b15928",
        "TRAIN": "#a6cee3",
    }

    # Bouw GeoJSON-lagen als JS-variabelen
    _layers_js = []
    for _mode, _fc in feature_collections.items():
        _color = _mode_colors.get(_mode, "#888888")
        # Voeg flow_total toe als property voor tooltip
        _flow_cols = [
            k
            for k in (_fc["features"][0]["properties"].keys() if _fc["features"] else [])
            if k.startswith("flow_heen_") and not k.startswith("flow_dp")
        ]
        for _feat in _fc["features"]:
            _p = _feat["properties"]
            _p["_flow_total"] = sum(_p.get(c) or 0 for c in _flow_cols)
            _p["_mode"] = _mode

        _var = f"fc_{_mode.lower()}"
        _layers_js.append(
            f"var {_var} = {_json.dumps(_fc, ensure_ascii=False)};\n"
            f"L.geoJSON({_var}, {{\n"
            f"  style: function(f) {{\n"
            f"    var flow = f.properties._flow_total || 0;\n"
            f"    var color = flow > 0 ? flowColor(flow) : '#cccccc';\n"
            f"    return {{color: color, weight: flow > 0 ? 1.5 : 0.8, opacity: 0.8}};\n"
            f"  }},\n"
            f"  onEachFeature: function(f, layer) {{\n"
            f"    var p = f.properties;\n"
            f"    layer.bindTooltip(\n"
            f"      '<b>' + (p._mode||'') + ' — link ' + (p.linkId||'') + '</b><br>'"
            f"      + 'flow heen: ' + Math.round(p._flow_total||0) + '<br>'"
            f"      + 'length: ' + Math.round(p.length||0) + ' m',\n"
            f"      {{sticky: true}}\n"
            f"    );\n"
            f"  }}\n"
            f"}}).addTo(map);"
        )

    _selection_js = (
        f"var selPoly = {_json.dumps({'type': 'Feature', 'geometry': _json.loads(polygon_json_str), 'properties': {}})};\n"
        "L.geoJSON(selPoly, {style: {color:'red', weight:2, fill:false, dashArray:'6 4'}}).addTo(map);"
    )

    _layers_block = "\n".join(_layers_js)

    return f"""<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <style>html,body,#map{{margin:0;padding:0;height:600px;}}</style>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
</head>
<body>
<div id="map"></div>
<script>
  var map = L.map('map').setView([{_center_lat}, {_center_lon}], 13);
  L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
    attribution: '© OpenStreetMap', maxZoom: 19
  }}).addTo(map);

  // Kleurschaal geel→oranje→rood op basis van flow (max=2000 pae)
  function flowColor(v) {{
    var t = Math.min(v / 2000, 1);
    var r = Math.round(255);
    var g = Math.round(255 * (1 - t));
    var b = 0;
    return 'rgb(' + r + ',' + g + ',' + b + ')';
  }}

  {_selection_js}
  {_layers_block}
</script>
</body>
</html>"""


# COMMAND ----------
displayHTML(_leaflet_map(_mode_fcs, polygon_json))  # noqa: F821
