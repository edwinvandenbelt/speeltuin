"""SQL construction for network_fetcher — no I/O, no boto3.

Builds parameterised Databricks SQL queries for all supported transport modes.
"""

from __future__ import annotations

# Motief keys — order must match the pivot columns in every SQL query
_MOTIEF_KEYS: tuple[str, ...] = ("work", "recreational", "education", "shopping", "unknown")

# Daypart keys — ochtendspits (morning rush), avondspits (evening rush), restdag (rest of day)
_DAYPART_KEYS: tuple[str, ...] = ("mrh", "erh", "rest")

# Dutch purpose → English CASE expression (shared by all modes)
_MOTIEF_CASE = """\
    CASE motief
        WHEN 'werk'                       THEN 'work'
        WHEN 'zakelijk'                   THEN 'work'
        WHEN 'sociaalrecreatief'          THEN 'recreational'
        WHEN 'basisonderwijs'             THEN 'education'
        WHEN 'hogeronderwijs'             THEN 'education'
        WHEN 'middelbaarberoepsonderwijs' THEN 'education'
        WHEN 'winkel'                     THEN 'shopping'
        ELSE 'unknown'
    END"""

# Multiplier: weekday peak-hour → whole-day equivalent
_FLOW_WEIGHT = "CASE WHEN tijd = 'restdag' THEN 10.4 ELSE 2 END"

_FLOW_HEEN_PIVOT = """\
       SUM(CASE WHEN motief = 'work'         THEN flow_etm_heen ELSE 0 END) AS flow_heen_work,
       SUM(CASE WHEN motief = 'recreational' THEN flow_etm_heen ELSE 0 END) AS flow_heen_recreational,
       SUM(CASE WHEN motief = 'education'    THEN flow_etm_heen ELSE 0 END) AS flow_heen_education,
       SUM(CASE WHEN motief = 'shopping'     THEN flow_etm_heen ELSE 0 END) AS flow_heen_shopping,
       SUM(CASE WHEN motief = 'unknown'      THEN flow_etm_heen ELSE 0 END) AS flow_heen_unknown"""

_FLOW_TERUG_PIVOT = """\
       SUM(CASE WHEN motief = 'work'         THEN flow_etm_terug ELSE 0 END) AS flow_terug_work,
       SUM(CASE WHEN motief = 'recreational' THEN flow_etm_terug ELSE 0 END) AS flow_terug_recreational,
       SUM(CASE WHEN motief = 'education'    THEN flow_etm_terug ELSE 0 END) AS flow_terug_education,
       SUM(CASE WHEN motief = 'shopping'     THEN flow_etm_terug ELSE 0 END) AS flow_terug_shopping,
       SUM(CASE WHEN motief = 'unknown'      THEN flow_etm_terug ELSE 0 END) AS flow_terug_unknown"""

# Per-daypart intensity columns added to the flows CTE (CAR/BIKE — uses pae_per_uur).
# These are raw pae/hr values per daypart, *not* multiplied by hours.
_FLOW_DP_HEEN_CTE = """\
           SUM(CASE WHEN tijd = 'ochtendspits' THEN intensiteit_heen_pae_per_uur  ELSE 0 END) AS flow_dp_heen_mrh,
           SUM(CASE WHEN tijd = 'avondspits'   THEN intensiteit_heen_pae_per_uur  ELSE 0 END) AS flow_dp_heen_erh,
           SUM(CASE WHEN tijd = 'restdag'      THEN intensiteit_heen_pae_per_uur  ELSE 0 END) AS flow_dp_heen_rest"""

_FLOW_DP_TERUG_CTE = """\
           SUM(CASE WHEN tijd = 'ochtendspits' THEN intensiteit_terug_pae_per_uur ELSE 0 END) AS flow_dp_terug_mrh,
           SUM(CASE WHEN tijd = 'avondspits'   THEN intensiteit_terug_pae_per_uur ELSE 0 END) AS flow_dp_terug_erh,
           SUM(CASE WHEN tijd = 'restdag'      THEN intensiteit_terug_pae_per_uur ELSE 0 END) AS flow_dp_terug_rest"""

# Same but for PT modes (ritten_per_uur instead of pae_per_uur).
_FLOW_DP_HEEN_PT_CTE = """\
           SUM(CASE WHEN tijd = 'ochtendspits' THEN intensiteit_heen_ritten_per_uur  ELSE 0 END) AS flow_dp_heen_mrh,
           SUM(CASE WHEN tijd = 'avondspits'   THEN intensiteit_heen_ritten_per_uur  ELSE 0 END) AS flow_dp_heen_erh,
           SUM(CASE WHEN tijd = 'restdag'      THEN intensiteit_heen_ritten_per_uur  ELSE 0 END) AS flow_dp_heen_rest"""

_FLOW_DP_TERUG_PT_CTE = """\
           SUM(CASE WHEN tijd = 'ochtendspits' THEN intensiteit_terug_ritten_per_uur ELSE 0 END) AS flow_dp_terug_mrh,
           SUM(CASE WHEN tijd = 'avondspits'   THEN intensiteit_terug_ritten_per_uur ELSE 0 END) AS flow_dp_terug_erh,
           SUM(CASE WHEN tijd = 'restdag'      THEN intensiteit_terug_ritten_per_uur ELSE 0 END) AS flow_dp_terug_rest"""

# Outer-SELECT aggregations for daypart columns.
# Daypart intensities are per-link (not per-motive), so every motive row for a given
# link carries the same value.  MAX is used to collapse across moties without inflating
# the totals (SUM would multiply by the number of distinct motives).
_FLOW_DP_OUTER_HEEN = """\
       MAX(flow_dp_heen_mrh)  AS flow_dp_heen_mrh,
       MAX(flow_dp_heen_erh)  AS flow_dp_heen_erh,
       MAX(flow_dp_heen_rest) AS flow_dp_heen_rest"""

_FLOW_DP_OUTER_TERUG = """\
       MAX(flow_dp_terug_mrh)  AS flow_dp_terug_mrh,
       MAX(flow_dp_terug_erh)  AS flow_dp_terug_erh,
       MAX(flow_dp_terug_rest) AS flow_dp_terug_rest"""

# link_mode and modaliteit per public-transport mode
_PT_PARAMS: dict[str, tuple[str, str]] = {
    "BUS":   ("other", "bus"),
    "TRAM":  ("other", "tram"),
    "METRO": ("other", "metro"),
    "TRAIN": ("train", "trein"),
}

VALID_MODES: frozenset[str] = frozenset({"CAR", "BIKE", "PEDESTRIAN", "BUS", "TRAM", "METRO", "TRAIN"})


def build_intersection_sql(mode: str, catalog: str, schema: str) -> str:
    """Return the parameterised Databricks SQL for *mode*.

    The returned SQL has ``?`` positional placeholders:
    - CAR / BIKE / PEDESTRIAN: one ``?`` for the GeoJSON polygon string
    - BUS / TRAM / METRO / TRAIN: four ``?`` for link_mode, polygon, modaliteit, mode label

    Raises
    ------
    ValueError
        When *mode* is not one of the supported values.
    """
    db = f"{catalog}.`{schema}`"

    if mode == "CAR":
        return f"""\
WITH link_selection AS (
    SELECT *
    FROM   {db}.d110_toedeelbaar_autonetwerk
    WHERE  ST_Intersects(
               ST_Transform(ST_GeomFromGeoJSON(?), 28992),
               geometry
           )
),
flows AS (
    SELECT link_id,
           {_MOTIEF_CASE} AS motief,
           SUM(intensiteit_heen_pae_per_uur  * {_FLOW_WEIGHT}) AS flow_etm_heen,
           SUM(intensiteit_terug_pae_per_uur * {_FLOW_WEIGHT}) AS flow_etm_terug,
{_FLOW_DP_HEEN_CTE},
{_FLOW_DP_TERUG_CTE}
    FROM   {db}.d171_toedelingsresultaten_auto_node_to_node_per_hoofdmotief
    JOIN   link_selection USING (link_id)
    GROUP  BY 1, 2
)
SELECT link_id                                          AS linkId,
       ST_AsGeoJSON(ST_Transform(geometry, 4326))       AS geom,
       'CAR'                                            AS mode,
       van_knoop_id                                     AS fromNode,
       naar_knoop_id                                    AS toNode,
       rijrichting_heen,
       capaciteit_heen_pae_per_uur                      AS cap_heen,
       aantal_rijstroken_heen                           AS rijstroken_heen,
       wettelijke_snelheid_heen_km_per_uur              AS max_snelheid_heen,
{_FLOW_HEEN_PIVOT},
       rijrichting_terug,
       capaciteit_heen_pae_per_uur                      AS cap_terug,
       aantal_rijstroken_terug                          AS rijstroken_terug,
       wettelijke_snelheid_terug_km_per_uur             AS max_snelheid_terug,
{_FLOW_TERUG_PIVOT},
{_FLOW_DP_OUTER_HEEN},
{_FLOW_DP_OUTER_TERUG},
       ST_Length(geometry)                              AS length,
       straatnaam                                       AS streetName
FROM   link_selection
LEFT JOIN flows USING (link_id)
GROUP  BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 15, 16, 17, 18, 30, 31
ORDER  BY 1"""

    if mode == "BIKE":
        return f"""\
WITH link_selection AS (
    SELECT *
    FROM   {db}.d120_toedeelbaar_fietsnetwerk
    WHERE  ST_Intersects(
               ST_Transform(ST_GeomFromGeoJSON(?), 28992),
               geometry
           )
),
flows AS (
    SELECT link_id,
           {_MOTIEF_CASE} AS motief,
           SUM(intensiteit_heen_pae_per_uur  * {_FLOW_WEIGHT}) AS flow_etm_heen,
           SUM(intensiteit_terug_pae_per_uur * {_FLOW_WEIGHT}) AS flow_etm_terug,
{_FLOW_DP_HEEN_CTE},
{_FLOW_DP_TERUG_CTE}
    FROM   {db}.d181_toedelingsresultaten_fiets_node_to_node_per_hoofdmotief
    JOIN   link_selection USING (link_id)
    GROUP  BY 1, 2
)
SELECT link_id                                                           AS linkId,
       ST_AsGeoJSON(ST_Transform(geometry, 4326))                        AS geom,
       'BIKE'                                                            AS mode,
       van_knoop_id                                                      AS fromNode,
       naar_knoop_id                                                     AS toNode,
       rijrichting_heen,
       0                                                                 AS cap_heen,
       1                                                                 AS rijstroken_heen,
       snelheid_heen_km_per_uur                                          AS max_snelheid_heen,
{_FLOW_HEEN_PIVOT},
       rijrichting_terug,
       0                                                                 AS cap_terug,
       CASE WHEN rijrichting_terug THEN 1 ELSE 0 END                    AS rijstroken_terug,
       CASE WHEN rijrichting_terug THEN snelheid_terug_km_per_uur
            ELSE 0 END                                                   AS max_snelheid_terug,
{_FLOW_TERUG_PIVOT},
{_FLOW_DP_OUTER_HEEN},
{_FLOW_DP_OUTER_TERUG},
       ST_Length(geometry)                                               AS length,
       wegtype,
       straatnaam                                                        AS streetName
FROM   link_selection
LEFT JOIN flows USING (link_id)
GROUP  BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 15, 16, 17, 18, 30, 31, 32
ORDER  BY 1"""

    if mode == "PEDESTRIAN":
        return f"""\
WITH link_selection AS (
    SELECT *
    FROM   loopstromenmodel.`{schema}`.intensiteiten_voetgangers_202512
    WHERE  ST_Intersects(
               geom_28992,
               ST_Transform(ST_GeomFromGeoJSON(?), 28992)
           )
)
SELECT sublink                                                                AS linkId,
       ST_AsGeoJSON(ST_Transform(geom_28992, 4326))                           AS geom,
       'PEDESTRIAN'                                                           AS mode,
       CAST(ROUND(ST_X(ST_StartPoint(geom_28992))) AS BIGINT) * 1000000
           + CAST(ROUND(ST_Y(ST_StartPoint(geom_28992))) AS BIGINT)          AS fromNode,
       CAST(ROUND(ST_X(ST_EndPoint(geom_28992))) AS BIGINT) * 1000000
           + CAST(ROUND(ST_Y(ST_EndPoint(geom_28992))) AS BIGINT)            AS toNode,
       TRUE                                                                   AS rijrichting_heen,
       0                                                                      AS cap_heen,
       1                                                                      AS rijstroken_heen,
       speed                                                                  AS max_snelheid_heen,
       fwork         * volume / 200.0                                         AS flow_heen_work,
       frecreational * volume / 200.0                                         AS flow_heen_recreational,
       fschool       * volume / 200.0                                         AS flow_heen_education,
       fshopping     * volume / 200.0                                         AS flow_heen_shopping,
       fresidential  * volume / 200.0                                         AS flow_heen_unknown,
       TRUE                                                                   AS rijrichting_terug,
       0                                                                      AS cap_terug,
       1                                                                      AS rijstroken_terug,
       speed                                                                  AS max_snelheid_terug,
       fwork         * volume / 200.0                                         AS flow_terug_work,
       frecreational * volume / 200.0                                         AS flow_terug_recreational,
       fschool       * volume / 200.0                                         AS flow_terug_education,
       fshopping     * volume / 200.0                                         AS flow_terug_shopping,
       fresidential  * volume / 200.0                                         AS flow_terug_unknown,
       0                                                                      AS flow_dp_heen_mrh,
       0                                                                      AS flow_dp_heen_erh,
       0                                                                      AS flow_dp_heen_rest,
       0                                                                      AS flow_dp_terug_mrh,
       0                                                                      AS flow_dp_terug_erh,
       0                                                                      AS flow_dp_terug_rest,
       ST_Length(geom_28992)                                                  AS length
FROM   link_selection
ORDER  BY sublink"""

    if mode in _PT_PARAMS:
        return f"""\
WITH link_selection AS (
    SELECT *
    FROM   {db}.d140_toedeelbaar_ov_netwerk_links
    WHERE  link_mode = ?
      AND  ST_Intersects(
               geometry,
               ST_Transform(ST_GeomFromGeoJSON(?), 28992)
           )
),
flows AS (
    SELECT link_id,
           {_MOTIEF_CASE} AS motief,
           SUM(intensiteit_heen_ritten_per_uur  * {_FLOW_WEIGHT}) AS flow_etm_heen,
           SUM(intensiteit_terug_ritten_per_uur * {_FLOW_WEIGHT}) AS flow_etm_terug,
{_FLOW_DP_HEEN_PT_CTE},
{_FLOW_DP_TERUG_PT_CTE}
    FROM   {db}.d380_toedelingsresultaten_ov_per_hoofdmotief_na_kalibratie
    JOIN   link_selection USING (link_id)
    WHERE  CAST(modaliteit AS STRING) = ?
    GROUP  BY 1, 2
)
SELECT link_id                                                   AS linkId,
       ST_AsGeoJSON(ST_Transform(geometry, 4326))               AS geom,
       ?                                                        AS mode,
       from_node_id                                             AS fromNode,
       to_node_id                                               AS toNode,
       TRUE                                                      AS rijrichting_heen,
       0                                                         AS cap_heen,
       1                                                         AS rijstroken_heen,
       0                                                         AS max_snelheid_heen,
{_FLOW_HEEN_PIVOT},
       FALSE                                                     AS rijrichting_terug,
       0                                                         AS cap_terug,
       0                                                         AS rijstroken_terug,
       0                                                         AS max_snelheid_terug,
{_FLOW_TERUG_PIVOT},
{_FLOW_DP_OUTER_HEEN},
{_FLOW_DP_OUTER_TERUG},
       ST_Length(geometry)                                       AS length
FROM   link_selection
LEFT JOIN flows USING (link_id)
GROUP  BY 1, 2, 3, 4, 5, 6, 7, 8, 9, 15, 16, 17, 18, 30
ORDER  BY 1"""

    raise ValueError(
        f"Unsupported mode: {mode!r}. "
        f"Valid modes: {', '.join(sorted(VALID_MODES))}."
    )


def get_pt_params(mode: str) -> tuple[str, str]:
    """Return the (link_mode, modaliteit) tuple for a PT mode."""
    return _PT_PARAMS[mode]
