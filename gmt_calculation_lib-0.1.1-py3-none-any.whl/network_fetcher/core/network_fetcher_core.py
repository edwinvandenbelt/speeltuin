"""Pure-Python network-fetcher core — no I/O, no boto3, no Databricks connections.

Builds Databricks SQL queries and assembles raw result rows into a GeoJSON FeatureCollection.

Public API
----------
build_intersection_sql(mode, catalog, schema) -> str
    Return the parameterised Databricks SQL string for the given transport mode.
get_pt_params(mode) -> tuple[str, str]
    Return (link_mode, modaliteit) for a public-transport mode.
rows_to_feature_collection(rows, col_names, mode) -> dict
    Convert raw Databricks result rows into a GeoJSON FeatureCollection.
"""

from __future__ import annotations

from network_fetcher.domain.network import (  # noqa: F401
    LINK_PROPERTIES,
    rows_to_feature_collection,
)
from network_fetcher.domain.sql import (  # noqa: F401
    _DAYPART_KEYS,
    _MOTIEF_KEYS,
    _PT_PARAMS,
    VALID_MODES,
    build_intersection_sql,
    get_pt_params,
)
