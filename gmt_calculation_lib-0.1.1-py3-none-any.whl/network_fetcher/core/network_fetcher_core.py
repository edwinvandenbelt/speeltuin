"""Pure-Python network-fetcher core — no I/O, no boto3, no Databricks connections.

Builds Databricks SQL queries and assembles raw result rows into a GeoJSON FeatureCollection.

Public API
----------
build_intersection_sql(mode, catalog, schema) -> str
    Return the parameterised Databricks SQL string for the given transport mode.
get_pt_params(mode) -> tuple[str, str]
    Return (link_mode, modaliteit) for a public-transport mode.
rows_to_feature_collection(rows, col_names, mode) -> dict
    Convert raw Databricks result rows into a GeoJSON FeatureCollection.
merge_network_feature_collections(fcs) -> dict
    Merge multiple single-mode FeatureCollections into one multimodal collection.
"""

from __future__ import annotations

from network_fetcher.domain.network import (  # noqa: F401
    LINK_PROPERTIES,
    rows_to_feature_collection,
)
from network_fetcher.domain.sql import (  # noqa: F401
    _DAYPART_KEYS,
    _MOTIEF_KEYS,
    _PT_PARAMS,
    VALID_MODES,
    build_intersection_sql,
    get_pt_params,
)


def merge_network_feature_collections(fcs: list[dict]) -> dict:
    """Merge multiple single-mode network FeatureCollections into one.

    Each input FeatureCollection must have been produced by
    ``rows_to_feature_collection`` for a single transport mode.  The resulting
    collection contains all features from every input; each feature retains its
    own ``"mode"`` property.  The FeatureCollection-level ``"modes"`` list is
    the union of all input ``"modes"`` lists (order preserved, no duplicates).
    The ``"fields"`` list is the union of all input ``"fields"`` lists.

    Parameters
    ----------
    fcs:
        One or more GeoJSON FeatureCollection dicts.  Must not be empty.

    Returns
    -------
    dict
        A single merged FeatureCollection.

    Raises
    ------
    ValueError
        When *fcs* is empty.
    """
    if not fcs:
        raise ValueError("merge_network_feature_collections requires at least one FeatureCollection.")
    if len(fcs) == 1:
        return fcs[0]

    all_features: list[dict] = []
    merged_modes: list[str] = []
    merged_fields: list[str] = []
    fields_seen: set[str] = set()
    base_props: dict = {}

    for fc in fcs:
        all_features.extend(fc.get("features") or [])
        props = fc.get("properties") or {}
        for m in (props.get("modes") or []):
            if m not in merged_modes:
                merged_modes.append(m)
        for f in (props.get("fields") or []):
            if f not in fields_seen:
                merged_fields.append(f)
                fields_seen.add(f)
        if not base_props:
            base_props = {k: v for k, v in props.items() if k not in ("modes", "fields")}

    return {
        "type": "FeatureCollection",
        "features": all_features,
        "properties": {
            **base_props,
            "modes": merged_modes,
            "fields": merged_fields,
        },
    }
