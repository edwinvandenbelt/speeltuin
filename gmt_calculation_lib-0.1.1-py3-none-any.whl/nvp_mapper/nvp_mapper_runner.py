"""Local debug runner for nvp_mapper.

Calls map_nvp_trips() directly — no Lambda handler involved.

Reads the NETWORK GeoJSON for spatial geometry (read-only — the file is never
modified).  The spatial polygon used to filter NVP segments is derived
automatically from the ``bbox`` stored in the NETWORK file's top-level
``properties`` object (``$.properties.bbox``), so no separate polygon argument
is required.

Output is a Parquet file with one row per matched Spectrum link:
    linkId (int64), nvpLinkIds (list<string>), nvpTripIds (list<string>)

Usage
-----
    python -m nvp_mapper.nvp_mapper_runner \\
        --network-file /tmp/deventer-NETWORK-CAR.geojson \\
        --nvp-table nvp_experimental.silver.vw_segments \\
        --mode CAR \\
        --nvp-year 2025 \\
        --output-parquet /tmp/deventer-NVP-ROUTES-CAR.parquet

    # S3 network file (read-only):
    python -m nvp_mapper.nvp_mapper_runner \\
        --network-file s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.geojson \\
        --nvp-table nvp_experimental.silver.vw_segments \\
        --mode CAR \\
        --nvp-year 2025 \\
        --output-parquet /tmp/deventer-NVP-ROUTES-CAR.parquet

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only for s3:// URIs).
* Databricks credentials in the environment or .env file:
  DATABRICKS_HOST, DATABRICKS_TOKEN (or DATABRICKS_HTTP_PATH / DATABRICKS_CATALOG).
* numpy and pyarrow installed (pip install gmt-calculation-lib[prepare]).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_parquet(match_rows: list, output_path: str) -> None:
    """Write match rows to a Parquet file using pyarrow.

    Schema: linkId (int64), nvpLinkId (string), nvpTripIds (list<string>).
    """
    try:
        import pyarrow as pa          # noqa: PLC0415
        import pyarrow.parquet as pq  # noqa: PLC0415
    except ImportError as exc:
        raise ImportError(
            "pyarrow is required to write Parquet output. "
            "Install it with: pip install pyarrow"
        ) from exc

    schema = pa.schema([
        pa.field("linkId",     pa.int64()),
        pa.field("nvpLinkId",  pa.string()),
        pa.field("nvpTripIds", pa.list_(pa.string())),
    ])
    table = pa.Table.from_pylist(match_rows, schema=schema)
    dest = output_path.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(dest)), exist_ok=True)
    pq.write_table(table, dest)
    print(f"Written {len(match_rows):,} rows -> {dest}")


# ---------------------------------------------------------------------------
# Polygon extractor
# ---------------------------------------------------------------------------


def _polygon_from_network(fc: dict) -> str:
    """Return a GeoJSON Polygon geometry string derived from the NETWORK file.

    Reads ``$.properties.bbox`` — a ``[minLon, minLat, maxLon, maxLat]`` array
    stored on the FeatureCollection by network_fetcher — and wraps it into a
    closed GeoJSON Polygon ring.

    Raises
    ------
    KeyError / ValueError
        When ``$.properties.bbox`` is absent or has the wrong shape.
    """
    props = fc.get("properties") or {}
    bbox = props.get("bbox")
    if bbox is None:
        raise KeyError(
            "NETWORK GeoJSON has no 'bbox' in $.properties. "
            "This field is written by network_fetcher; ensure the file was "
            "produced by the standard GMT pipeline."
        )
    try:
        min_lon, min_lat, max_lon, max_lat = (float(v) for v in bbox)
    except (TypeError, ValueError) as exc:
        raise ValueError(
            f"$.properties.bbox must be [minLon, minLat, maxLon, maxLat], got {bbox!r}"
        ) from exc

    geom = {
        "type": "Polygon",
        "coordinates": [[
            [min_lon, min_lat],
            [max_lon, min_lat],
            [max_lon, max_lat],
            [min_lon, max_lat],
            [min_lon, min_lat],
        ]],
    }
    return json.dumps(geom)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for nvp_mapper — enriches a NETWORK GeoJSON in-place "
            "with NVP trip IDs per link.  The spatial filter polygon is derived "
            "automatically from $.properties.bbox in the NETWORK file."
        )
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help=(
            "Full URI of the NETWORK GeoJSON to enrich "
            "(s3:// or local path).  Overwritten in-place."
        ),
    )
    parser.add_argument(
        "--nvp-table",
        required=True,
        metavar="TABLE",
        help=(
            "Fully qualified Databricks table name for NVP trip segments, "
            "e.g. nvp_experimental.silver.vw_segments."
        ),
    )
    parser.add_argument(
        "--mode",
        required=True,
        metavar="MODE",
        help="Transport mode: CAR or BIKE.",
    )
    parser.add_argument(
        "--nvp-year",
        required=True,
        type=int,
        metavar="YEAR",
        help="NVP location_year value to filter on (e.g. 2025).",
    )
    parser.add_argument(
        "--maxlength-sublink",
        type=float,
        default=5.0,
        help="Max sub-link length in metres (default: 5).",
    )
    parser.add_argument(
        "--maxdist",
        type=float,
        default=20.0,
        help="Max lateral distance in metres for a valid match (default: 20).",
    )
    parser.add_argument(
        "--maxalpha-forward1",
        type=float,
        default=15.0,
        help="Tight angular threshold for forward pass 1, degrees (default: 15).",
    )
    parser.add_argument(
        "--maxalpha-forward2",
        type=float,
        default=45.0,
        help="Wide angular threshold for forward pass 2, degrees (default: 45).",
    )
    parser.add_argument(
        "--maxalpha-backward",
        type=float,
        default=30.0,
        help="Angular threshold for backward validation pass, degrees (default: 30).",
    )
    parser.add_argument(
        "--fmatch12",
        type=float,
        default=0.5,
        help="Minimum overlap fraction to accept a match (default: 0.5 = 50%%).",
    )
    parser.add_argument(
        "--nnb",
        type=int,
        default=20,
        help="Number of nearest neighbours in the k-d tree query (default: 20).",
    )
    parser.add_argument(
        "--log-level",
        default="INFO",
        help="Python logging level (default: INFO).",
    )
    parser.add_argument(
        "--output-parquet",
        default=None,
        metavar="PATH",
        help=(
            "(Optional) Local path for the NVP-ROUTES Parquet output file, "
            "e.g. output/deventer/{areaId}-NVP-ROUTES-CAR.parquet.  "
            "When omitted, no Parquet file is written."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS + Databricks credentials.",
    )
    args = parser.parse_args()

    # ── Load .env ──────────────────────────────────────────────────────────
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    # ── Logging ─────────────────────────────────────────────────────────────
    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
        level=getattr(logging, args.log_level.upper(), logging.INFO),
    )

    # ── Late imports (after sys.path is ready) ───────────────────────────────
    from shared.databricks_sql import connect_from_env  # noqa: PLC0415

    from nvp_mapper.core.nvp_mapper_core import map_nvp_trips  # noqa: PLC0415
    from nvp_mapper.domain.sql import get_links_nvp, get_trips_nvp  # noqa: PLC0415

    # ── Read network ─────────────────────────────────────────────────────────
    print(f"\nReading   : {args.network_file}")
    fc = json.loads(_read_uri(args.network_file))
    print(f"  {len(fc.get('features', []))} features loaded")

    # ── Derive spatial filter polygon from the network's bbox ─────────────────
    polygon_json = _polygon_from_network(fc)
    fc_props = fc.get("properties") or {}
    print(f"  bbox     : {fc_props.get('bbox')}")

    # ── Connect to Databricks ────────────────────────────────────────────────
    print("Connecting to Databricks ...")
    conn = connect_from_env()
    cursor = conn.cursor()

    # ── Fetch NVP link geometry ───────────────────────────────────────────────
    print(
        f"Fetching NVP links: table={args.nvp_table}  mode={args.mode}  year={args.nvp_year}"
    )
    nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys = get_links_nvp(
        cursor, args.nvp_table, polygon_json, args.mode, args.nvp_year
    )
    print(f"  NVP links fetched: {len(nvp_links)}")

    # ── Fetch NVP trip IDs ────────────────────────────────────────────────────
    print("Fetching NVP trip IDs ...")
    linktrips1, trips_all = get_trips_nvp(
        cursor, args.nvp_table, polygon_json, args.mode, args.nvp_year
    )
    print(f"  NVP trip IDs: {len(trips_all)} total  {len(linktrips1)} segments with trips")

    # ── Map NVP trips onto NETWORK (read-only) ───────────────────────────────
    print("Matching NVP trips onto NETWORK ...")
    stats, match_rows = map_nvp_trips(
        fc,
        nvp_links=nvp_links,
        nvp_vertlengths=nvp_vertlengths,
        nvp_vertxys=nvp_vertxys,
        nvp_vertdxys=nvp_vertdxys,
        linktrips1=linktrips1,
        maxlength_sublink=args.maxlength_sublink,
        maxdist=args.maxdist,
        maxalpha_forward1=args.maxalpha_forward1,
        maxalpha_forward2=args.maxalpha_forward2,
        maxalpha_backward=args.maxalpha_backward,
        fmatch12=args.fmatch12,
        nnb=args.nnb,
    )

    # ── Write NVP-ROUTES Parquet ──────────────────────────────────────────────
    if args.output_parquet:
        print(f"Writing   : {args.output_parquet}")
        _write_parquet(match_rows, args.output_parquet)

    print(
        f"\n  spectrum_links : {stats['spectrum_links']}"
        f"\n  nvp_links      : {stats['nvp_links']}"
        f"\n  matched_links  : {stats['matched_links']}"
        f"\n  match_rows     : {stats['match_rows']}"
    )


if __name__ == "__main__":
    main()
