"""Databricks SQL queries for nvp_mapper — no I/O beyond the DB connection.

Fetches NVP (Nationale Verkeersprestatie) link geometry and trip IDs from
``nvp_experimental.silver.vw_segments`` (or any compatible table) for a given
spatial polygon, transport mode, and year.

All geometry is returned in RD New (EPSG:28992) metres so that downstream
matching can work directly in a Cartesian coordinate system.

Public API
----------
get_links_nvp(cursor, table, polygon_json, mode, year)
    Return NVP vertex geometry arrays (in RD New metres).
get_trips_nvp(cursor, table, polygon_json, mode, year)
    Return dict mapping (nodeId, next_nodeId, pairindex) → list of trip IDs.
"""

from __future__ import annotations

import json
import logging
from collections import defaultdict

try:
    import numpy as np
except ImportError as _np_err:
    raise ImportError(
        "numpy is required for nvp_mapper. Install it with: pip install numpy"
    ) from _np_err

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Transport-mode mapping  (repo convention → NVP table convention)
# ---------------------------------------------------------------------------

#: Maps repo transport-mode strings to the ``trip_mode`` values in the NVP table.
_NVP_MODE_MAP: dict[str, str] = {
    "CAR":  "Car",
    "BIKE": "Fiets",
}


def _nvp_mode(mode: str) -> str:
    """Translate a repo mode string (e.g. ``"CAR"``) to the NVP table value."""
    mapped = _NVP_MODE_MAP.get(mode.upper())
    if mapped is None:
        raise ValueError(
            f"Mode {mode!r} is not supported by nvp_mapper. "
            f"Supported modes: {', '.join(_NVP_MODE_MAP)}"
        )
    return mapped


def _bbox_from_polygon_json(polygon_json: str) -> tuple[float, float, float, float]:
    """Extract ``(minX, minY, maxX, maxY)`` from a GeoJSON Polygon string.

    Used to pass four scalar parameters to ``ST_MakeEnvelope`` instead of
    parsing the full GeoJSON string once per row with ``ST_GeomFromGeoJSON``.
    Non-rectangular polygons are reduced to their bounding envelope, which is
    the correct coarse spatial filter for nvp_mapper's use case.
    """
    coords = json.loads(polygon_json)["coordinates"][0]
    xs = [c[0] for c in coords]
    ys = [c[1] for c in coords]
    return min(xs), min(ys), max(xs), max(ys)


# ---------------------------------------------------------------------------
# NVP link geometry
# ---------------------------------------------------------------------------


def get_links_nvp(
    cursor: object,
    table_nvp: str,
    polygon_json: str,
    mode: str,
    year: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Fetch NVP link geometry for a bounding polygon.

    Each distinct ``(nodeId, next_nodeId, segment_id)`` combination is treated
    as a single straight-line vertex (NVP links are already vertex-level
    straight segments).  The geometry is projected to RD New (EPSG:28992)
    inside the SQL so that the returned coordinates are in metres.

    Parameters
    ----------
    cursor:
        An active ``shared.databricks_sql._Cursor`` instance.
    table_nvp:
        Fully qualified Databricks table name,
        e.g. ``"nvp_experimental.silver.vw_segments"``.
    polygon_json:
        GeoJSON Polygon geometry string used for spatial filtering,
        e.g. the AREA feature geometry from the ZONES file.
    mode:
        Repo transport mode (``"CAR"`` or ``"BIKE"``).
    year:
        ``location_year`` value to filter on (e.g. ``2025``).

    Returns
    -------
    links : ndarray, shape (N, 3)
        Rows of ``[nodeId, next_nodeId, pairindex]``.
    vertlengths : ndarray, shape (N,)
        Length of each NVP link in RD metres.
    vertxys : ndarray, shape (N, 2)
        Start-point ``[x, y]`` in RD New metres for each NVP link.
    vertdxys : ndarray, shape (N, 2)
        Unit direction vectors ``[dx, dy]`` for each NVP link.
    """
    nvp_mode = _nvp_mode(mode)
    bbox = _bbox_from_polygon_json(polygon_json)

    sql = f"""
    WITH base AS (
        SELECT
            nodeId,
            next_nodeId,
            segment_id                                             AS pairindex,
            ST_Transform(ANY_VALUE(line_geom_4326), 28992)        AS g28992
        FROM   {table_nvp}
        WHERE  trip_mode      = ?
          AND  location_year  = ?
          AND  ST_Intersects(line_geom_4326, ST_SetSRID(ST_MakeEnvelope(?, ?, ?, ?), 4326))
        GROUP BY nodeId, next_nodeId, segment_id
    )
    SELECT
        nodeId,
        next_nodeId,
        pairindex,
        ST_X(ST_StartPoint(g28992))  AS x1,
        ST_Y(ST_StartPoint(g28992))  AS y1,
        ST_X(ST_EndPoint(g28992))    AS x2,
        ST_Y(ST_EndPoint(g28992))    AS y2,
        ST_Length(g28992)            AS length_m
    FROM base
    """

    logger.info(
        "Querying NVP links: table=%s  mode=%s  year=%d", table_nvp, nvp_mode, year
    )
    cursor.execute(sql, (nvp_mode, str(year), *bbox))
    rows = cursor.fetchall()
    logger.info("NVP links query returned %d rows", len(rows))

    if not rows:
        empty2 = np.empty((0, 2), dtype=float)
        return np.empty((0, 3), dtype=object), np.array([]), empty2, empty2

    # Unpack rows: (nodeId, next_nodeId, pairindex, x1, y1, x2, y2, length_m)
    node_ids    = [r[0] for r in rows]
    next_ids    = [r[1] for r in rows]
    pair_idxs   = [r[2] for r in rows]
    x1s         = np.array([float(r[3]) for r in rows])
    y1s         = np.array([float(r[4]) for r in rows])
    x2s         = np.array([float(r[5]) for r in rows])
    y2s         = np.array([float(r[6]) for r in rows])
    lengths     = np.array([float(r[7]) for r in rows])

    links = np.array(
        [[n1, n2, pi] for n1, n2, pi in zip(node_ids, next_ids, pair_idxs)],
        dtype=object,
    )

    # Filter out degenerate segments
    valid = lengths > 0.01
    links   = links[valid]
    lengths = lengths[valid]
    x1s, y1s = x1s[valid], y1s[valid]
    x2s, y2s = x2s[valid], y2s[valid]

    vertxys  = np.stack([x1s, y1s], axis=1)
    vertdxys = np.zeros((len(links), 2))
    vertdxys[:, 0] = (x2s - x1s) / lengths
    vertdxys[:, 1] = (y2s - y1s) / lengths

    return links, lengths, vertxys, vertdxys


# ---------------------------------------------------------------------------
# NVP trip IDs
# ---------------------------------------------------------------------------


def get_trips_nvp(
    cursor: object,
    table_nvp: str,
    polygon_json: str,
    mode: str,
    year: int,
) -> tuple[dict, np.ndarray]:
    """Fetch NVP trip IDs per link segment for a bounding polygon.

    Uses ``EXPLODE`` to flatten the ``trip_ids`` array column into one row per
    trip per segment, then groups the result back into a dict keyed by
    ``(nodeId, next_nodeId, pairindex)``.

    Parameters
    ----------
    cursor, table_nvp, polygon_json, mode, year:
        Same as :func:`get_links_nvp`.

    Returns
    -------
    linktrips : dict[(nodeId, next_nodeId, pairindex), list]
        Mapping from NVP segment key to list of trip IDs.
    trips_all : ndarray, dtype object
        Flat array of all unique trip IDs seen (informational).
    """
    nvp_mode = _nvp_mode(mode)
    bbox = _bbox_from_polygon_json(polygon_json)

    sql = f"""
    WITH base AS (
        SELECT
            nodeId,
            next_nodeId,
            segment_id                                                    AS pairindex,
            array_distinct(flatten(collect_list(trip_ids)))               AS trip_ids_all
        FROM   {table_nvp}
        WHERE  trip_mode      = ?
          AND  location_year  = ?
          AND  ST_Intersects(line_geom_4326, ST_SetSRID(ST_MakeEnvelope(?, ?, ?, ?), 4326))
        GROUP BY nodeId, next_nodeId, segment_id
    )
    SELECT
        nodeId,
        next_nodeId,
        pairindex,
        EXPLODE(trip_ids_all) AS trip_id
    FROM base
    """

    logger.info(
        "Querying NVP trips: table=%s  mode=%s  year=%d", table_nvp, nvp_mode, year
    )
    cursor.execute(sql, (nvp_mode, str(year), *bbox))
    rows = cursor.fetchall()
    logger.info("NVP trips query returned %d rows", len(rows))

    linktrips: dict = defaultdict(list)
    all_trip_ids: list = []

    for row in rows:
        node_id, next_node_id, pairindex, trip_id = row[0], row[1], row[2], row[3]
        key = (node_id, next_node_id, pairindex)
        linktrips[key].append(trip_id)
        all_trip_ids.append(trip_id)

    trips_all = np.array(all_trip_ids, dtype=object) if all_trip_ids else np.array([], dtype=object)

    return dict(linktrips), trips_all
