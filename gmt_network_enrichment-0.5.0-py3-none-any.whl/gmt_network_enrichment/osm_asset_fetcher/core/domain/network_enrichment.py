"""Network enrichment helpers for OSM traffic assets.

This module provides a simple, ``linkId``-based way to add proximity counts to
network links.  It assumes every point asset has already been matched to its
nearest network link (see :mod:`geometry_matching`).  Linear assets
(``cyclePath``, ``footPath``) are counted against links they intersect within a
small buffer.
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)


# Counted asset types on the network.
_ASSET_COUNTERS: dict[str, str] = {
    "pedestrianCrossing": "numPedestrianCrossings",
    "refugeAreaCrossing": "numRefugeAreas",
    "refugeAreaFootway": "numRefugeAreas",
    "refugeAreaTraffic": "numRefugeAreas",
    "stoppingLane": "numStoppingLanes",
    "stopSign": "numGiveWays",
    "giveWay": "numGiveWays",
    "speedBump": "numSpeedBumps",
}

# Approximate meters per degree at mid-latitudes.
_METERS_PER_DEGREE: float = 111_000.0

# Buffer distance per modus used when computing nearby POI area.
_POI_BUFFER_M: dict[str, float] = {
    "bike": 250.0,
    "pedestrian": 100.0,
}

# Fallback area (m²) for point POIs when no polygon geometry is available.
_POI_POINT_AREA_M2: dict[str, float] = {
    "school": 5_000.0,
    "hospital": 20_000.0,
    "recreation": 2_500.0,
    "shop": 1_500.0,
}

# POI category keys used for output columns.
_POI_CATEGORIES: tuple[str, ...] = ("school", "hospital", "recreation", "shop")

# Mapping from output column prefix -> POI category key.
_AREA_PREFIX_TO_CATEGORY: dict[str, str] = {
    "areaSchoolsNearbyM2": "school",
    "areaHospitalsNearbyM2": "hospital",
    "areaRecreationNearbyM2": "recreation",
    "areaShopsNearbyM2": "shop",
}

# Classifiers: (predicate, category) used on OSM tags.
_POI_TAG_CLASSIFIERS: list[tuple[callable, str]] = [
    (
        lambda t: t.get("amenity") in ("school", "kindergarten", "college", "university"),
        "school",
    ),
    (
        lambda t: (
            t.get("amenity") in ("hospital", "clinic")
            or t.get("healthcare") in ("hospital", "clinic")
        ),
        "hospital",
    ),
    (
        lambda t: (
            t.get("leisure") in ("park", "playground", "pitch", "sports_centre", "garden")
            or t.get("tourism") in ("camp_site", "attraction")
        ),
        "recreation",
    ),
    (
        lambda t: t.get("shop") in ("supermarket", "convenience", "mall", "department_store"),
        "shop",
    ),
]


def _asset_counter_for(asset_type: str | None) -> str | None:
    """Return the network counter field for an asset type, if any."""
    if asset_type is None:
        return None
    return _ASSET_COUNTERS.get(asset_type)


def _normalise_link_id(lid) -> str | None:
    """Return a string key for a linkId, handling float/int equivalence."""
    if lid is None:
        return None
    try:
        return str(int(lid))
    except (TypeError, ValueError):
        return str(lid)


def _link_index(network_fc: dict) -> dict[str, dict]:
    """Return a ``linkId -> link properties`` index."""
    idx: dict[str, dict] = {}
    for link in network_fc.get("features") or []:
        props = link.get("properties") or {}
        key = _normalise_link_id(props.get("linkId"))
        if key is not None:
            idx[key] = props
    return idx


def _count_linear_intersections(
    network_fc: dict,
    line_features: list[dict],
    buffer_m: float = 20.0,
) -> dict[str, int]:
    """Count how many line assets intersect each network link (within buffer).

    For now this keeps the existing shapely-based spatial check so that
    ``numCyclePaths`` still works for paths that cross a link rather than being
    snapped to a single ``linkId``.
    """
    try:
        from shapely.geometry import LineString
    except ImportError:
        logger.warning("shapely not available; skipping cycle/foot path enrichment")
        return {}

    counts: dict[str, int] = {}
    buffer_deg = buffer_m / _METERS_PER_DEGREE

    network_links: list[tuple[dict, LineString]] = []
    for link in network_fc.get("features") or []:
        props = link.get("properties") or {}
        geom = link.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coords = [
            (float(c[0]), float(c[1])) for c in (geom.get("coordinates") or []) if len(c) >= 2
        ]
        if len(coords) < 2:
            continue
        try:
            network_links.append((props, LineString(coords)))
        except (TypeError, ValueError):
            continue

    for feat in line_features:
        geom = feat.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coords = [
            (float(c[0]), float(c[1])) for c in (geom.get("coordinates") or []) if len(c) >= 2
        ]
        if len(coords) < 2:
            continue
        try:
            asset_line = LineString(coords).buffer(buffer_deg)
        except (TypeError, ValueError):
            continue

        for link_props, link_line in network_links:
            if asset_line.intersects(link_line):
                lid = _normalise_link_id(link_props.get("linkId"))
                if lid is not None:
                    counts[lid] = counts.get(lid, 0) + 1

    return counts


def enrich_network_with_osm_assets(
    network_fc: dict,
    asset_features: list[dict],
) -> dict:
    """Add asset-count columns to network links based on matched ``linkId`` s.

    Adds the following integer fields to every link feature (default 0):

    * ``numPedestrianCrossings``  — from ``assetType == "pedestrianCrossing"``
    * ``numRefugeAreas``          — from ``refugeArea*`` types
    * ``numStoppingLanes``        — from ``stoppingLane``
    * ``numGiveWays``             — from ``stopSign`` and ``giveWay``
    * ``numSpeedBumps``           — from ``speedBump``
    * ``numCyclePaths``           — from ``cyclePath`` LineStrings within 20 m

    Parameters
    ----------
    network_fc:
        Network FeatureCollection whose links have ``properties.linkId``.
    asset_features:
        Asset features produced by ``osm_asset_fetcher``.

    Returns
    -------
    dict
        *network_fc* with counts added to each link's properties.
    """
    link_props_by_id = _link_index(network_fc)

    # Ensure all counter fields exist and start at 0.
    counter_fields = [*set(_ASSET_COUNTERS.values()), "numCyclePaths"]
    for props in link_props_by_id.values():
        for field in counter_fields:
            props[field] = 0

    # Count point assets by linkId.
    for feat in asset_features:
        props = feat.get("properties") or {}
        asset_type = props.get("assetType")
        counter_field = _asset_counter_for(asset_type)
        if counter_field is None:
            continue
        lid = _normalise_link_id(props.get("linkId"))
        if lid is None:
            continue
        link_props = link_props_by_id.get(lid)
        if link_props is None:
            continue
        link_props[counter_field] += 1

    # Count linear assets (cycle paths) spatially.
    cycle_paths = [
        f for f in asset_features if (f.get("properties") or {}).get("assetType") == "cyclePath"
    ]
    if cycle_paths:
        cycle_counts = _count_linear_intersections(network_fc, cycle_paths)
        for lid, count in cycle_counts.items():
            link_props = link_props_by_id.get(lid)
            if link_props is not None:
                link_props["numCyclePaths"] += count

    enriched = 0
    for props in link_props_by_id.values():
        if any(props.get(f, 0) > 0 for f in counter_fields):
            enriched += 1

    logger.info(
        "Enriched %d/%d network links with OSM asset counts",
        enriched,
        len(link_props_by_id),
    )
    return network_fc


# ---------------------------------------------------------------------------
# Speed-layer enrichment: cycle crossings + POI areas (OSM-derived only)
# ---------------------------------------------------------------------------


def _classify_poi_asset_type(tags: dict) -> str | None:
    """Return the POI category for OSM *tags*, or ``None``."""
    for predicate, category in _POI_TAG_CLASSIFIERS:
        if predicate(tags):
            return category
    return None


def extract_poi_features(elements: list[dict]) -> list[dict]:
    """Extract POI features (point or polygon) from raw Overpass elements.

    Produces GeoJSON features with ``assetType`` set to the POI category and,
    for polygons, preserves the original geometry.
    """
    features: list[dict] = []
    for elem in elements:
        tags = elem.get("tags") or {}
        asset_type = _classify_poi_asset_type(tags)
        if asset_type is None:
            continue

        etype = elem.get("type")
        geometry = elem.get("geometry") or []
        geom: dict | None = None

        if etype == "node":
            lat = elem.get("lat")
            lon = elem.get("lon")
            if lat is not None and lon is not None:
                geom = {"type": "Point", "coordinates": [float(lon), float(lat)]}
        elif etype == "way" and geometry:
            pts = [
                [float(p["lon"]), float(p["lat"])] for p in geometry if "lon" in p and "lat" in p
            ]
            if len(pts) >= 3:
                if pts[0] != pts[-1]:
                    pts.append(pts[0])
                geom = {"type": "Polygon", "coordinates": [pts]}
            elif len(pts) >= 1:
                geom = {"type": "Point", "coordinates": pts[0]}
        elif etype == "relation" and geometry:
            rings = _relation_geometry_to_rings(geometry)
            if rings:
                geom = {"type": "Polygon", "coordinates": rings}

        if geom is None:
            continue

        features.append(
            {
                "type": "Feature",
                "geometry": geom,
                "properties": {"assetType": asset_type, **tags},
            }
        )
    return features


def extract_built_up_features(elements: list[dict]) -> list[dict]:
    """Extract ``landuse=residential/commercial/retail`` polygons."""
    features: list[dict] = []
    for elem in elements:
        tags = elem.get("tags") or {}
        if tags.get("landuse") not in ("residential", "commercial", "retail"):
            continue
        etype = elem.get("type")
        geometry = elem.get("geometry") or []
        rings: list[list[list[float]]] | None = None
        if etype == "way" and geometry:
            pts = [
                [float(p["lon"]), float(p["lat"])] for p in geometry if "lon" in p and "lat" in p
            ]
            if len(pts) >= 3:
                if pts[0] != pts[-1]:
                    pts.append(pts[0])
                rings = [pts]
        elif etype == "relation" and geometry:
            rings = _relation_geometry_to_rings(geometry)

        if rings:
            features.append(
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": rings},
                    "properties": {"landuse": tags.get("landuse")},
                }
            )
    return features


def _relation_geometry_to_rings(geometry: list[dict]) -> list[list[list[float]]]:
    """Convert Overpass relation ``out geom`` geometry to Polygon rings.

    Nodes belonging to an outer ring are accumulated; empty role markers or
    members with a different role start a new ring.
    """
    rings: list[list[list[float]]] = []
    current: list[list[float]] = []
    for p in geometry:
        role = p.get("role")
        if role not in ("outer", "", None):
            if len(current) >= 3:
                if current[0] != current[-1]:
                    current.append(current[0])
                rings.append(current)
            current = []
            continue
        lon = p.get("lon")
        lat = p.get("lat")
        if lon is not None and lat is not None:
            current.append([float(lon), float(lat)])
    if len(current) >= 3:
        if current[0] != current[-1]:
            current.append(current[0])
        rings.append(current)
    return rings


def _derive_cycle_crossings(
    network_fc: dict,
    path_features: list[dict],
    buffer_m: float = 5.0,
) -> list[dict]:
    """Return ``cycleCrossing`` Point features where cycle/foot paths cross network links."""
    try:
        from shapely.geometry import LineString
    except ImportError:
        logger.warning("shapely not available; skipping cycle crossing derivation")
        return []

    buffer_deg = buffer_m / _METERS_PER_DEGREE

    network_lines: list[tuple[dict, LineString]] = []
    for link in network_fc.get("features") or []:
        geom = link.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coords = [
            (float(c[0]), float(c[1])) for c in (geom.get("coordinates") or []) if len(c) >= 2
        ]
        if len(coords) < 2:
            continue
        try:
            network_lines.append((link, LineString(coords)))
        except (TypeError, ValueError):
            continue

    crossings: list[dict] = []
    seen: set[tuple] = set()
    for feat in path_features:
        geom = feat.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coords = [
            (float(c[0]), float(c[1])) for c in (geom.get("coordinates") or []) if len(c) >= 2
        ]
        if len(coords) < 2:
            continue
        try:
            path_line_buffered = LineString(coords).buffer(buffer_deg)
        except (TypeError, ValueError):
            continue

        for link, link_line in network_lines:
            inter = path_line_buffered.intersection(link_line)
            if inter.is_empty:
                continue
            pts = _extract_points_from_intersection(inter)
            for lon, lat in pts:
                key = (round(lon, 6), round(lat, 6), link["properties"].get("linkId"))
                if key in seen:
                    continue
                seen.add(key)
                crossings.append(
                    {
                        "type": "Feature",
                        "geometry": {"type": "Point", "coordinates": [lon, lat]},
                        "properties": {
                            "assetType": "cycleCrossing",
                            "linkId": link["properties"].get("linkId"),
                            "nodeId": link["properties"].get("toNode"),
                        },
                    }
                )

    return crossings


def _extract_points_from_intersection(inter) -> list[tuple[float, float]]:
    """Return representative (lon, lat) points from a shapely intersection geometry."""

    pts: list[tuple[float, float]] = []
    geom_type = inter.geom_type
    if geom_type == "Point":
        pts.append((inter.x, inter.y))
    elif geom_type == "MultiPoint":
        pts.extend((p.x, p.y) for p in inter.geoms)
    elif geom_type == "LineString":
        pts.append((inter.coords[0][0], inter.coords[0][1]))
        pts.append((inter.coords[-1][0], inter.coords[-1][1]))
    elif geom_type == "MultiLineString":
        for line in inter.geoms:
            pts.append((line.coords[0][0], line.coords[0][1]))
            pts.append((line.coords[-1][0], line.coords[-1][1]))
    elif geom_type == "GeometryCollection":
        for part in inter.geoms:
            pts.extend(_extract_points_from_intersection(part))
    return pts


def _poi_geometry_to_shape(feature: dict, fallback_area_m2: float) -> object:
    """Convert a POI feature to a shapely geometry, buffering points to match *fallback_area_m2*."""
    from shapely.geometry import Point, shape

    geom = feature.get("geometry") or {}
    geom_type = geom.get("type")
    if geom_type == "Polygon":
        return shape(geom)
    if geom_type == "Point":
        lon, lat = geom["coordinates"]
        radius_m = math.sqrt(fallback_area_m2 / math.pi)
        radius_deg = radius_m / _METERS_PER_DEGREE
        return Point(lon, lat).buffer(radius_deg)
    return None


def _compute_poi_areas_by_link(
    network_fc: dict,
    poi_features: list[dict],
    built_up_features: list[dict],
    buffer_m: float,
) -> dict[str, float]:
    """Return ``linkId -> POI area (m²)`` within *buffer_m*, clipped to built-up."""
    try:
        from shapely.geometry import LineString, shape
        from shapely.ops import unary_union
    except ImportError:
        logger.warning("shapely not available; skipping POI area computation")
        return {}

    if not built_up_features or not poi_features:
        return {}

    built_up_union = unary_union(
        [shape(f["geometry"]) for f in built_up_features if f.get("geometry")]
    )
    if built_up_union.is_empty:
        return {}

    poi_shapes: list[object] = []
    for feat in poi_features:
        asset_type = (feat.get("properties") or {}).get("assetType", "")
        fallback = _POI_POINT_AREA_M2.get(asset_type, 1_000.0)
        geom = _poi_geometry_to_shape(feat, fallback)
        if geom is not None:
            poi_shapes.append(geom)
    if not poi_shapes:
        return {}

    poi_union = unary_union(poi_shapes).intersection(built_up_union)
    if poi_union.is_empty:
        return {}

    m2_per_deg2 = _METERS_PER_DEGREE**2
    buffer_deg = buffer_m / _METERS_PER_DEGREE
    result: dict[str, float] = {}

    for link in network_fc.get("features") or []:
        props = link.get("properties") or {}
        lid = _normalise_link_id(props.get("linkId"))
        if lid is None:
            continue
        geom = link.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coords = [
            (float(c[0]), float(c[1])) for c in (geom.get("coordinates") or []) if len(c) >= 2
        ]
        if len(coords) < 2:
            continue
        try:
            link_buffer = LineString(coords).buffer(buffer_deg)
        except (TypeError, ValueError):
            continue
        area_m2 = float(link_buffer.intersection(poi_union).area) * m2_per_deg2
        if area_m2 > 0:
            result[lid] = area_m2

    return result


def enrich_network_with_pois_and_crossings(
    network_fc: dict,
    asset_features: list[dict] | None = None,
    poi_features: list[dict] | None = None,
    built_up_features: list[dict] | None = None,
) -> dict:
    """Add speed-layer POI area columns and derived cycle crossings to ``network_fc``.

    Adds per modus:
      * ``areaSchoolsNearbyM2_<bike|pedestrian>``
      * ``areaShopsNearbyM2_<bike|pedestrian>``
      * ``areaHospitalsNearbyM2_<bike|pedestrian>``
      * ``areaRecreationNearbyM2_<bike|pedestrian>``

    Adds:
      * ``numCycleCrossings`` — count of cycle/foot path intersections with the network.

    Parameters
    ----------
    network_fc:
        Network FeatureCollection whose links have ``properties.linkId``.
    asset_features:
        Optional OSM asset features (used to derive ``cycleCrossing`` features from
        ``cyclePath`` / ``footPath`` LineStrings).
    poi_features:
        Optional POI features with ``assetType`` in the supported categories.
    built_up_features:
        Optional built-up polygons (`landuse=residential/commercial/retail`).

    Returns
    -------
    dict
        *network_fc* with new columns added to each link's properties.
    """
    link_props_by_id = _link_index(network_fc)

    area_cols = [
        f"{prefix}_{mode}" for mode in ("bike", "pedestrian") for prefix in _AREA_PREFIX_TO_CATEGORY
    ]
    all_cols = [*area_cols, "numCycleCrossings"]

    for props in link_props_by_id.values():
        for col in all_cols:
            props[col] = 0.0 if col.startswith("area") else 0

    if asset_features:
        path_features = [
            f
            for f in asset_features
            if (f.get("properties") or {}).get("assetType") in ("cyclePath", "footPath")
        ]
        crossings = _derive_cycle_crossings(network_fc, path_features)
        for feat in crossings:
            lid = _normalise_link_id(feat["properties"].get("linkId"))
            if lid is None:
                continue
            props = link_props_by_id.get(lid)
            if props is not None:
                props["numCycleCrossings"] += 1

    if poi_features and built_up_features:
        for mode, buffer_m in _POI_BUFFER_M.items():
            category_areas = {
                cat: _compute_poi_areas_by_link(
                    network_fc,
                    [
                        f
                        for f in poi_features
                        if (f.get("properties") or {}).get("assetType") == cat
                    ],
                    built_up_features,
                    buffer_m,
                )
                for cat in _POI_CATEGORIES
            }
            for props in link_props_by_id.values():
                lid = _normalise_link_id(props.get("linkId"))
                for prefix, cat in _AREA_PREFIX_TO_CATEGORY.items():
                    props[f"{prefix}_{mode}"] = (
                        category_areas[cat].get(lid, 0.0) if lid is not None else 0.0
                    )

    logger.info(
        "Enriched %d network links with POI areas and cycle crossings",
        len(link_props_by_id),
    )
    return network_fc
