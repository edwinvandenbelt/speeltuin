"""Domain modules for osm_asset_fetcher — specialized asset extraction logic."""

from __future__ import annotations

from gmt_network_enrichment.osm_asset_fetcher.core.domain.refuge_crossing import (
    crossing_refuge_features,
)
from gmt_network_enrichment.osm_asset_fetcher.core.domain.refuge_footway import (
    footway_refuge_features,
)
from gmt_network_enrichment.osm_asset_fetcher.core.domain.refuge_traffic import (
    traffic_refuge_features,
)
from gmt_network_enrichment.osm_asset_fetcher.core.domain.stopping_lanes import (
    stopping_lanes_to_features,
)

__all__ = [
    "crossing_refuge_features",
    "footway_refuge_features",
    "traffic_refuge_features",
    "stopping_lanes_to_features",
]
