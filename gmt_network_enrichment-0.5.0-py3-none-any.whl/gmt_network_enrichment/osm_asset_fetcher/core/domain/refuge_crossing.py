"""Extract refuge areas at pedestrian crossings.

Pedestrian crossings with refuge islands/medians are encoded in OSM as:

    node[highway=crossing][crossing:island=yes]

The crossing:island tag indicates the presence of a refuge area (vluchtheuvel)
that separates the crossing into sections (e.g., for elderly or disabled
pedestrians who cannot cross in one go).

Additional context:
- crossing=traffic_signals | unmarked | island (type of crossing)
- crossing:marking=zebra | dots | dashes | no (line marking type)
- lit=yes/no (pedestrian lighting present)
- traffic_signals=yes/no (traffic signals present)

Output
------
Each feature is a Point at the crossing node with assetType='refugeAreaCrossing'
and properties for crossing type, marking, lighting, etc.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def parse_bool_tag(value: str | None) -> bool | None:
    """Parse OSM yes/no-style tag to bool, or None when unknown/absent."""
    if value is None:
        return None
    lc = value.strip().lower()
    if lc in ("yes", "true", "1"):
        return True
    if lc in ("no", "false", "0"):
        return False
    return None


def crossing_refuge_features(elements: list[dict]) -> list[dict]:
    """Convert Overpass crossing nodes to refuge area features.

    Parameters
    ----------
    elements:
        List of Overpass node elements with highway=crossing + crossing:island=yes.

    Returns
    -------
    list[dict]
        GeoJSON Point features with assetType='refugeAreaCrossing'.
    """
    features: list[dict] = []

    for elem in elements:
        if elem.get("type") != "node":
            continue

        tags = elem.get("tags") or {}
        if tags.get("highway") != "crossing" or tags.get("crossing:island") != "yes":
            continue

        lat = elem.get("lat")
        lon = elem.get("lon")
        if lat is None or lon is None:
            continue

        # Extract typed properties.
        crossing_type = tags.get("crossing")  # traffic_signals | unmarked | island
        marking = tags.get("crossing:marking")  # zebra | dots | dashes | no
        lit = parse_bool_tag(tags.get("lit"))
        has_traffic_signals = parse_bool_tag(tags.get("traffic_signals"))

        props = {
            "osm_id": elem.get("id"),
            "assetType": "refugeAreaCrossing",
            "crossingType": crossing_type,
            "marking": marking,
            "lit": lit,
            "hasTrafficSignals": has_traffic_signals,
            "hasIsland": True,  # By definition (crossing:island=yes)
            **tags,  # Preserve all raw OSM tags
        }

        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [lon, lat]},
                "properties": props,
            }
        )

    logger.info("Extracted %d crossing refuge features.", len(features))
    return features
