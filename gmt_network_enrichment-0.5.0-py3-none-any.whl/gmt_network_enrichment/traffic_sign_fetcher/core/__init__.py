# src/traffic_sign_fetcher/core/__init__.py
