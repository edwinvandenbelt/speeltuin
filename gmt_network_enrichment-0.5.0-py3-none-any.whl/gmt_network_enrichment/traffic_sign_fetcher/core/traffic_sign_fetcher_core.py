"""Pure-Python traffic_sign_fetcher core — fetches traffic signs (verkeersborden).

Fetches traffic-sign point features for a bounding box from either the Dutch
NDW static-road-data dataset (when the bbox centroid lies in the Netherlands)
or the OpenStreetMap Overpass API (elsewhere), and returns them as a GeoJSON
point ``FeatureCollection``.  Every feature is tagged
``properties.assetType = "trafficSign"`` so the result can be merged into the
combined ``{area_id}-TRAFFIC-ASSETS.parquet`` produced by the prepare pipeline.

The NDW dataset is assumed to be *pre-provisioned* — this module never
downloads it.  Callers pass the already-parsed NDW ``FeatureCollection`` dict
via *ndw_data* (see :func:`fetch_sign_features`).

Public API
----------
is_netherlands(bbox) -> bool
    True when the bbox centroid lies inside the Netherlands.

filter_ndw_by_bbox(data, bbox) -> dict
    Filter a NDW GeoJSON FeatureCollection to Point features inside *bbox*.

overpass_query_for_bbox(bbox) -> str
    Build an Overpass QL query for ``node["traffic_sign"]`` inside *bbox*.

elements_to_sign_features(elements) -> list[dict]
    Convert raw Overpass node elements to GeoJSON sign Feature dicts.

fetch_signs_overpass(bbox, *, tiles, timeout) -> dict
    Fetch OSM traffic signs via the shared Overpass client (tiled).

fetch_sign_features(bbox, *, ndw_data, tiles, timeout) -> tuple[dict, dict]
    High-level entry: pick NDW vs Overpass, return (fc, stats).
"""

from __future__ import annotations

import logging

from gmt_shared.geo import is_netherlands

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached traffic-sign output.
TRAFFIC_SIGNS_QUERY_VER: int = 1

#: Default NxN tile grid for Overpass fetches.
OVERPASS_GRID: int = 3

#: Asset-type tag written on every produced feature.
ASSET_TYPE: str = "trafficSign"

# ``is_netherlands`` lives in :mod:`shared.geo` (imported above) and is
# re-exported here for backward compatibility with existing callers/tests.


# ---------------------------------------------------------------------------
# NDW filtering
# ---------------------------------------------------------------------------


def filter_ndw_by_bbox(data: dict, bbox: list[float]) -> dict:
    """Filter a NDW GeoJSON FeatureCollection to Point features inside *bbox*.

    Parameters
    ----------
    data:
        A parsed NDW GeoJSON ``FeatureCollection`` dict.
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.

    Returns
    -------
    A new ``FeatureCollection`` dict containing only the matching features,
    each tagged with ``properties.assetType``.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    filtered: list[dict] = []
    for feat in data.get("features") or []:
        geom = feat.get("geometry") or {}
        if geom.get("type") != "Point":
            continue
        coords = geom.get("coordinates") or []
        if len(coords) < 2:
            continue
        lon, lat = coords[0], coords[1]
        if min_lon <= lon <= max_lon and min_lat <= lat <= max_lat:
            props = {**(feat.get("properties") or {}), "assetType": ASSET_TYPE}
            filtered.append({**feat, "properties": props})
    return {
        "type": "FeatureCollection",
        "features": filtered,
        "properties": {"_qv": TRAFFIC_SIGNS_QUERY_VER, "source": "NDW"},
    }


# ---------------------------------------------------------------------------
# Overpass query + parsing
# ---------------------------------------------------------------------------


def overpass_query_for_bbox(bbox: list[float], timeout: int = 40) -> str:
    """Build an Overpass QL query for ``node["traffic_sign"]`` inside *bbox*.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    timeout:
        Overpass server-side timeout in seconds.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    # Overpass uses (south, west, north, east) coordinate order.
    coord_str = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    return f'[out:json][timeout:{timeout}];\nnode["traffic_sign"]({coord_str});\nout body;'


def elements_to_sign_features(elements: list[dict]) -> list[dict]:
    """Convert raw Overpass node elements to GeoJSON sign Feature dicts.

    The OSM ``traffic_sign`` tag is normalised: a country prefix such as
    ``NL:A01`` is reduced to ``A01`` so it aligns with the RVV coding used by
    the NDW dataset.  Every feature is tagged ``properties.assetType``.
    """
    features: list[dict] = []
    for elem in elements:
        if elem.get("type") != "node":
            continue
        lat = elem.get("lat")
        lon = elem.get("lon")
        if lat is None or lon is None:
            continue
        tags = elem.get("tags") or {}
        raw_sign = tags.get("traffic_sign", "")
        if ":" in raw_sign:
            raw_sign = raw_sign.split(":", 1)[1]
        props = {
            **tags,
            "osm_id": elem.get("id"),
            "rvvCode": raw_sign,
            "assetType": ASSET_TYPE,
        }
        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [lon, lat]},
                "properties": props,
            }
        )
    return features


def fetch_signs_overpass(
    bbox: list[float],
    *,
    tiles: int = OVERPASS_GRID,
    timeout: int = 40,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> dict:
    """Fetch OSM traffic signs via the shared Overpass client (tiled).

    Uses the repository's shared :mod:`shared.overpass` client, which provides
    on-disk caching, retries and rate-limit handling.  The bbox is split into a
    ``tiles x tiles`` grid to keep individual requests small.

    Returns a ``FeatureCollection`` dict with de-duplicated features.
    """
    from gmt_shared.overpass import fetch_overpass_tiled

    response = fetch_overpass_tiled(
        lambda b: overpass_query_for_bbox(b, timeout=timeout),
        bbox,
        tiles=(tiles, tiles),
        timeout=timeout,
        osm_path=osm_path,
        osm_workers=osm_workers,
    )
    features = elements_to_sign_features(response.get("elements") or [])
    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"_qv": TRAFFIC_SIGNS_QUERY_VER, "source": "OSM"},
    }


# ---------------------------------------------------------------------------
# High-level entry point
# ---------------------------------------------------------------------------


def fetch_sign_features(
    bbox: list[float],
    *,
    ndw_data: dict | None = None,
    tiles: int = OVERPASS_GRID,
    timeout: int = 40,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> tuple[dict, dict]:
    """Fetch traffic-sign features for *bbox*, selecting NDW or Overpass.

    When the bbox centroid lies in the Netherlands *and* a pre-provisioned NDW
    dataset is supplied via *ndw_data*, the signs are taken from NDW (filtered
    to the bbox).  Otherwise they are fetched live from OSM Overpass.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    ndw_data:
        A parsed NDW ``FeatureCollection`` dict, or ``None`` when unavailable.
    tiles:
        NxN Overpass tile grid (ignored for the NDW path).
    timeout:
        Overpass HTTP + server-side timeout in seconds.

    Returns
    -------
    fc:
        A GeoJSON ``FeatureCollection`` of traffic-sign point features, each
        tagged ``properties.assetType == "trafficSign"``.
    stats:
        ``{"total": int, "source": str}``.
    """
    if is_netherlands(bbox) and ndw_data is not None:
        logger.info("Using pre-provisioned NDW dataset for traffic signs.")
        fc = filter_ndw_by_bbox(ndw_data, bbox)
        source = "NDW"
    else:
        logger.info("Fetching traffic signs from OSM Overpass (tiles=%dx%d).", tiles, tiles)
        fc = fetch_signs_overpass(
            bbox, tiles=tiles, timeout=timeout, osm_path=osm_path, osm_workers=osm_workers
        )
        source = "OSM"

    total = len(fc.get("features") or [])
    logger.info("Fetched %d traffic-sign features (source=%s).", total, source)
    return fc, {"total": total, "source": source}
