# src/traffic_sign_fetcher/tests/__init__.py
