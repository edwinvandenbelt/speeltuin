"""Unit tests for traffic_sign_fetcher core (pure functions only)."""

from __future__ import annotations

from gmt_network_enrichment.traffic_sign_fetcher.core.traffic_sign_fetcher_core import (
    ASSET_TYPE,
    TRAFFIC_SIGNS_QUERY_VER,
    elements_to_sign_features,
    fetch_sign_features,
    filter_ndw_by_bbox,
    is_netherlands,
    overpass_query_for_bbox,
)

# ---------------------------------------------------------------------------
# is_netherlands
# ---------------------------------------------------------------------------


def test_is_netherlands_true_for_amsterdam() -> None:
    assert is_netherlands([4.8, 52.3, 4.95, 52.4]) is True


def test_is_netherlands_false_for_paris() -> None:
    assert is_netherlands([2.2, 48.8, 2.4, 48.9]) is False


# ---------------------------------------------------------------------------
# filter_ndw_by_bbox
# ---------------------------------------------------------------------------


def _ndw_fixture() -> dict:
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [5.0, 52.0]},
                "properties": {"rvvCode": "A01"},
            },
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [9.9, 52.0]},
                "properties": {"rvvCode": "B02"},
            },
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.1, 52.1]]},
                "properties": {"rvvCode": "C03"},
            },
        ],
    }


def test_filter_ndw_keeps_only_points_inside_bbox() -> None:
    fc = filter_ndw_by_bbox(_ndw_fixture(), [4.9, 51.9, 5.1, 52.1])
    assert len(fc["features"]) == 1
    assert fc["features"][0]["properties"]["rvvCode"] == "A01"


def test_filter_ndw_tags_asset_type_and_source() -> None:
    fc = filter_ndw_by_bbox(_ndw_fixture(), [4.9, 51.9, 5.1, 52.1])
    assert fc["features"][0]["properties"]["assetType"] == ASSET_TYPE
    assert fc["properties"]["source"] == "NDW"
    assert fc["properties"]["_qv"] == TRAFFIC_SIGNS_QUERY_VER


# ---------------------------------------------------------------------------
# overpass_query_for_bbox
# ---------------------------------------------------------------------------


def test_overpass_query_contains_tag_and_south_west_order() -> None:
    q = overpass_query_for_bbox([4.9, 52.0, 5.0, 52.1], timeout=40)
    assert 'node["traffic_sign"]' in q
    # Overpass order is south,west,north,east
    assert "52.0,4.9,52.1,5.0" in q
    assert "timeout:40" in q


# ---------------------------------------------------------------------------
# elements_to_sign_features
# ---------------------------------------------------------------------------


def test_elements_to_sign_features_normalises_country_prefix() -> None:
    elements = [
        {"type": "node", "id": 1, "lat": 52.0, "lon": 5.0, "tags": {"traffic_sign": "NL:A01"}},
    ]
    feats = elements_to_sign_features(elements)
    assert len(feats) == 1
    assert feats[0]["properties"]["rvvCode"] == "A01"
    assert feats[0]["properties"]["osm_id"] == 1
    assert feats[0]["properties"]["assetType"] == ASSET_TYPE
    assert feats[0]["geometry"]["coordinates"] == [5.0, 52.0]


def test_elements_to_sign_features_skips_ways_and_missing_coords() -> None:
    elements = [
        {"type": "way", "id": 2, "tags": {"traffic_sign": "A01"}},
        {"type": "node", "id": 3, "lat": None, "lon": 5.0, "tags": {}},
        {"type": "node", "id": 4, "lat": 52.0, "lon": 5.0, "tags": {"traffic_sign": "A01"}},
    ]
    feats = elements_to_sign_features(elements)
    assert len(feats) == 1
    assert feats[0]["properties"]["osm_id"] == 4


# ---------------------------------------------------------------------------
# fetch_sign_features (NDW path — no network needed)
# ---------------------------------------------------------------------------


def test_fetch_sign_features_uses_ndw_when_in_netherlands() -> None:
    fc, stats = fetch_sign_features([4.9, 51.9, 5.1, 52.1], ndw_data=_ndw_fixture())
    assert stats["source"] == "NDW"
    assert stats["total"] == 1
    assert fc["features"][0]["properties"]["assetType"] == ASSET_TYPE
