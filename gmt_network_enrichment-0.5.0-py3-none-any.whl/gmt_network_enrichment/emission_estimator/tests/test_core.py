"""Tests for emission_estimator.core.emission_estimator_core."""

from __future__ import annotations

from gmt_network_enrichment.emission_estimator.core import emission_estimator_core as core
from gmt_network_enrichment.emission_estimator.domain.factors import EMISSION_FACTORS


def _link(**props) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
        "properties": props,
    }


def _fc(*features) -> dict:
    return {"type": "FeatureCollection", "features": list(features)}


# ---------------------------------------------------------------------------
# Stage 1
# ---------------------------------------------------------------------------


def test_stage1_factor_times_vehicle_km() -> None:
    # 1000 vehicles/day over a 2000 m link -> 2000 vehicle-km.
    props = {"flow24hrs": 1000.0, "length": 2000.0}
    out = core.compute_link_emissions(props)
    assert out["vehicleKm"] == 2000.0
    # co2Kg = factor[g/veh-km] * veh_km / 1000
    expected_co2 = EMISSION_FACTORS["co2"] * 2000.0 / 1000.0
    assert abs(out["co2Kg"] - round(expected_co2, 6)) < 1e-9


def test_stage1_linear_in_flow_and_length() -> None:
    base = core.compute_link_emissions({"flow24hrs": 100.0, "length": 1000.0})
    double_flow = core.compute_link_emissions({"flow24hrs": 200.0, "length": 1000.0})
    double_len = core.compute_link_emissions({"flow24hrs": 100.0, "length": 2000.0})
    assert abs(double_flow["co2Kg"] - 2.0 * base["co2Kg"]) < 1e-9
    assert abs(double_len["co2Kg"] - 2.0 * base["co2Kg"]) < 1e-9


def test_stage1_missing_fields_are_zero() -> None:
    out = core.compute_link_emissions({})
    assert out["vehicleKm"] == 0.0
    for pollutant in ("co2Kg", "noxKg", "pm10Kg", "pm25Kg"):
        assert out[pollutant] == 0.0


def test_stage1_properties_exact_set() -> None:
    out = core.compute_link_emissions({"flow24hrs": 10.0, "length": 100.0})
    assert set(out) == set(core.EMISSION_PROPERTIES)


def test_estimate_emissions_preserves_geometry_and_props() -> None:
    fc = _fc(_link(flow24hrs=1000.0, length=1000.0, linkId="A"))
    out = core.estimate_emissions(fc)
    feat = out["features"][0]
    assert feat["geometry"] == {"type": "LineString", "coordinates": [[0, 0], [1, 1]]}
    assert feat["properties"]["linkId"] == "A"
    assert "co2Kg" in feat["properties"]


def test_estimate_emissions_copies_top_level_properties() -> None:
    fc = _fc(_link(flow24hrs=1.0, length=1.0))
    fc["properties"] = {"fields": ["a", "b"]}
    out = core.estimate_emissions(fc)
    assert out["properties"] == {"fields": ["a", "b"]}


# ---------------------------------------------------------------------------
# Stage 2
# ---------------------------------------------------------------------------


def test_stage2_has_daypart_properties() -> None:
    props = {
        "flow24hrs": 1000.0,
        "length": 1000.0,
        "speed": 50.0,
        "flowsPerDaypart": {"mrh": 100.0, "erh": 80.0, "rest": 20.0},
    }
    out = core.compute_link_emissions_detailed(props)
    assert set(out) == set(core.EMISSION_PROPERTIES_DETAILED)
    for daypart in ("Mrh", "Erh", "Rest"):
        assert f"co2Kg{daypart}" in out


def test_stage2_dayparts_sum_to_total() -> None:
    props = {
        "flow24hrs": 1000.0,
        "length": 1000.0,
        "speed": 50.0,
        "flowsPerDaypart": {"mrh": 100.0, "erh": 80.0, "rest": 20.0},
    }
    out = core.compute_link_emissions_detailed(props)
    parts_sum = out["co2KgMrh"] + out["co2KgErh"] + out["co2KgRest"]
    assert abs(parts_sum - out["co2Kg"]) < 1e-6


def test_stage2_speed_correction_at_reference_matches_mix() -> None:
    # At the reference speed the speed multiplier is 1.0, so the total equals
    # the mix-weighted factor times vehicle-km.
    from gmt_network_enrichment.emission_estimator.domain.factors import SPEED_REF, combined_factor

    props = {"flow24hrs": 1000.0, "length": 1000.0, "speed": SPEED_REF}
    out = core.compute_link_emissions_detailed(props)
    expected = combined_factor("co2") * 1000.0 / 1000.0
    assert abs(out["co2Kg"] - round(expected, 6)) < 1e-6


def test_estimate_emissions_detailed_preserves_geometry() -> None:
    fc = _fc(_link(flow24hrs=1000.0, length=1000.0, speed=50.0))
    out = core.estimate_emissions_detailed(fc)
    feat = out["features"][0]
    assert feat["geometry"]["type"] == "LineString"
    assert "co2KgMrh" in feat["properties"]
