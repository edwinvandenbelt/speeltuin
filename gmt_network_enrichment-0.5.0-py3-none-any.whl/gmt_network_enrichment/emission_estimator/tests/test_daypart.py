"""Tests for emission_estimator.domain.daypart."""

from __future__ import annotations

from gmt_network_enrichment.emission_estimator.domain import daypart


def test_dayparts_keys() -> None:
    assert daypart.DAYPARTS == ("mrh", "erh", "rest")
    assert sum(daypart.DAYPART_HOURS.values()) == 24.0


def test_fractions_sum_to_one() -> None:
    flows = {"mrh": 100.0, "erh": 80.0, "rest": 20.0}
    fractions = daypart.daypart_fractions(flows)
    assert abs(sum(fractions.values()) - 1.0) < 1e-9
    assert all(v >= 0.0 for v in fractions.values())


def test_fractions_weighted_by_hours() -> None:
    # Equal hourly intensity -> shares proportional to hours (2:2:20).
    flows = {"mrh": 10.0, "erh": 10.0, "rest": 10.0}
    fractions = daypart.daypart_fractions(flows)
    assert abs(fractions["mrh"] - 2.0 / 24.0) < 1e-9
    assert abs(fractions["erh"] - 2.0 / 24.0) < 1e-9
    assert abs(fractions["rest"] - 20.0 / 24.0) < 1e-9


def test_zero_flow_yields_zero_fractions() -> None:
    fractions = daypart.daypart_fractions({"mrh": 0.0, "erh": 0.0, "rest": 0.0})
    assert fractions == {"mrh": 0.0, "erh": 0.0, "rest": 0.0}


def test_non_mapping_input_yields_zero_fractions() -> None:
    assert daypart.daypart_fractions(None) == {"mrh": 0.0, "erh": 0.0, "rest": 0.0}
    assert daypart.daypart_fractions("nope") == {"mrh": 0.0, "erh": 0.0, "rest": 0.0}


def test_missing_and_invalid_keys_treated_as_zero() -> None:
    fractions = daypart.daypart_fractions({"mrh": "bad", "erh": 10.0})
    assert fractions["mrh"] == 0.0
    assert fractions["rest"] == 0.0
    assert abs(fractions["erh"] - 1.0) < 1e-9
