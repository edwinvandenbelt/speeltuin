"""Tests for emission_estimator."""
