"""Databricks notebook wrappers for emission_estimator."""
