"""emission_estimator - per-link road-traffic air-pollutant emission.

Two-stage model:

* stage 1 (fast, on-the-fly): emission factor times vehicle-km per link.
* stage 2 (detailed, slower): speed-dependent factors, day-part split via
  ``flowsPerDaypart``, vehicle/fuel mix and cold-start / gradient hooks.
"""
