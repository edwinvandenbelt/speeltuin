"""Pure-Python emission_estimator core - no I/O, no boto3, no external deps.

Two-stage road-traffic air-pollutant emission model working entirely in memory
on a GeoJSON ``FeatureCollection`` (``fc -> fc``).  Reading and writing files is
the job of the runner / notebook wrappers, never of this core.

Stage 1 - :func:`estimate_emissions` (fast, on-the-fly)
    Per link: ``emission_kg = factor[pollutant] * vehicle_km / 1000`` where
    ``vehicle_km = flow24hrs * length_m / 1000``.  Adds ``co2Kg``, ``noxKg``,
    ``pm10Kg``, ``pm25Kg`` and ``vehicleKm``.

Stage 2 - :func:`estimate_emissions_detailed` (elaborate, slower)
    Refines stage 1 with speed-dependent factors, a light/heavy vehicle mix,
    cold-start / gradient correction hooks and a day-part split driven by
    ``flowsPerDaypart``.  Adds the stage 1 totals plus per-day-part values
    (e.g. ``co2KgMrh``, ``co2KgErh``, ``co2KgRest``).

Input links are expected to carry the prepare flow schema: ``flow24hrs``
(vehicles/day), ``length`` (m), ``speed`` (km/h) and ``flowsPerDaypart``.

Public API
----------
EMISSION_PROPERTIES: tuple[str, ...]
    Stage 1 property names written onto each feature (authoritative).
EMISSION_PROPERTIES_DETAILED: tuple[str, ...]
    Stage 2 property names (stage 1 totals + per-day-part).
compute_link_emissions(props) -> dict
    Stage 1 emission properties for a single link's property dict.
estimate_emissions(fc) -> dict
    Stage 1: enrich a whole FeatureCollection on-the-fly.
estimate_emissions_detailed(fc) -> dict
    Stage 2: enrich a whole FeatureCollection with the elaborate model.
"""

from __future__ import annotations

import logging

from gmt_network_enrichment.emission_estimator.domain.daypart import DAYPARTS, daypart_fractions
from gmt_network_enrichment.emission_estimator.domain.factors import (
    COLD_START_FACTOR,
    EMISSION_FACTORS,
    GRADIENT_FACTOR,
    POLLUTANTS,
    combined_factor,
    speed_multiplier,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Property names (authoritative - camelCase external field names)
# ---------------------------------------------------------------------------

PROP_VEHICLE_KM: str = "vehicleKm"


def _pollutant_prop(pollutant: str) -> str:
    """Return the stage 1 property name for *pollutant* (e.g. "co2" -> "co2Kg")."""
    return f"{pollutant}Kg"


def _pollutant_daypart_prop(pollutant: str, daypart: str) -> str:
    """Return the stage 2 property name (e.g. "co2", "mrh" -> "co2KgMrh")."""
    return f"{pollutant}Kg{daypart.capitalize()}"


#: Stage 1 property names, in output order.
EMISSION_PROPERTIES: tuple[str, ...] = (
    *(_pollutant_prop(p) for p in POLLUTANTS),
    PROP_VEHICLE_KM,
)

#: Stage 2 property names: stage 1 totals plus per-day-part values.
EMISSION_PROPERTIES_DETAILED: tuple[str, ...] = (
    *EMISSION_PROPERTIES,
    *(_pollutant_daypart_prop(p, d) for p in POLLUTANTS for d in DAYPARTS),
)


# ---------------------------------------------------------------------------
# Input field names on the incoming network links
# ---------------------------------------------------------------------------

_FIELD_FLOW24HRS: str = "flow24hrs"
_FIELD_LENGTH: str = "length"
_FIELD_SPEED: str = "speed"
_FIELD_FLOWS_PER_DAYPART: str = "flowsPerDaypart"

#: Grams per kilogram (factors are g/vehicle-km; output is kg).
_G_PER_KG: float = 1000.0
#: Metres per kilometre.
_M_PER_KM: float = 1000.0


def _as_float(value: object) -> float:
    """Coerce *value* to a float, returning 0.0 for missing / invalid input."""
    if value is None:
        return 0.0
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0.0


def _vehicle_km(props: dict) -> float:
    """Return the daily vehicle-kilometres carried on a link."""
    flow24hrs = _as_float(props.get(_FIELD_FLOW24HRS))
    length_m = _as_float(props.get(_FIELD_LENGTH))
    return flow24hrs * (length_m / _M_PER_KM)


def compute_link_emissions(props: dict) -> dict:
    """Compute the stage 1 emission properties for a single link.

    Parameters
    ----------
    props:
        The ``properties`` dict of one network link feature.  Read-only.

    Returns
    -------
    A dict with the keys in :data:`EMISSION_PROPERTIES`.  Per pollutant the
    emission in kg/day (``factor * vehicle_km / 1000``) plus ``vehicleKm``.
    """
    veh_km = _vehicle_km(props)
    result: dict = {
        _pollutant_prop(p): round(EMISSION_FACTORS[p] * veh_km / _G_PER_KG, 6) for p in POLLUTANTS
    }
    result[PROP_VEHICLE_KM] = round(veh_km, 3)
    return result


def compute_link_emissions_detailed(props: dict) -> dict:
    """Compute the stage 2 (elaborate) emission properties for a single link.

    Applies the mix-weighted factor, a speed-dependent multiplier and the
    cold-start / gradient correction hooks, then splits each pollutant total
    over the ``flowsPerDaypart`` day-parts.

    Returns
    -------
    A dict with the keys in :data:`EMISSION_PROPERTIES_DETAILED`.
    """
    veh_km = _vehicle_km(props)
    speed = _as_float(props.get(_FIELD_SPEED))
    correction = speed_multiplier(speed) * COLD_START_FACTOR * GRADIENT_FACTOR
    fractions = daypart_fractions(props.get(_FIELD_FLOWS_PER_DAYPART))

    result: dict = {PROP_VEHICLE_KM: round(veh_km, 3)}
    for pollutant in POLLUTANTS:
        total = combined_factor(pollutant) * veh_km * correction / _G_PER_KG
        result[_pollutant_prop(pollutant)] = round(total, 6)
        for daypart in DAYPARTS:
            result[_pollutant_daypart_prop(pollutant, daypart)] = round(
                total * fractions[daypart], 6
            )
    return result


def _enrich(fc: dict, compute: object, prop_total: str) -> dict:
    """Apply *compute* to every feature and merge the result onto its props."""
    features_in = fc.get("features") or []
    features_out: list[dict] = []
    n_with_emission = 0

    for feat in features_in:
        props = dict(feat.get("properties") or {})
        emissions = compute(props)  # type: ignore[operator]
        props.update(emissions)
        if emissions.get(prop_total, 0.0) > 0.0:
            n_with_emission += 1
        features_out.append(
            {
                "type": feat.get("type", "Feature"),
                "geometry": feat.get("geometry"),
                "properties": props,
            }
        )

    logger.info(
        "emissions computed for %d/%d links (with a positive total)",
        n_with_emission,
        len(features_out),
    )

    out: dict = {"type": "FeatureCollection", "features": features_out}
    if "properties" in fc:
        out["properties"] = fc["properties"]
    return out


def estimate_emissions(fc: dict) -> dict:
    """Stage 1: enrich a network FeatureCollection with per-link emissions.

    Fast and on-the-fly: emission factor times vehicle-km per link.  Geometry
    and existing properties are preserved.  Returns a new ``FeatureCollection``
    with the :data:`EMISSION_PROPERTIES` added to each feature.
    """
    return _enrich(fc, compute_link_emissions, _pollutant_prop(POLLUTANTS[0]))


def estimate_emissions_detailed(fc: dict) -> dict:
    """Stage 2: enrich a network FeatureCollection with the elaborate model.

    Slower than stage 1: speed-dependent factors, vehicle mix, correction
    hooks and a ``flowsPerDaypart`` day-part split.  Returns a new
    ``FeatureCollection`` with the :data:`EMISSION_PROPERTIES_DETAILED` added.
    """
    return _enrich(fc, compute_link_emissions_detailed, _pollutant_prop(POLLUTANTS[0]))
