"""Pure-Python emission_estimator core (no I/O, no boto3)."""
