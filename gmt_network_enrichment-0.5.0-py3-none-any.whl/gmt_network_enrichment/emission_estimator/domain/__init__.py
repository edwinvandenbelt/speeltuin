"""Domain helpers for emission_estimator (factors, day-part split)."""
