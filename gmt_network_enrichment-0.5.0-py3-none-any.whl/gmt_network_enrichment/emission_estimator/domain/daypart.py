"""Day-part splitter - distributes a link's daily emission over day-parts.

Stage 2 splits the per-link daily emission into the three prepare day-parts
carried by ``flowsPerDaypart``:

    mrh   morning rush hour
    erh   evening rush hour
    rest  remainder of the day

``flowsPerDaypart`` stores a per-hour intensity (vehicles/hour) for each
day-part.  To turn those into a share of the daily total we weight each
intensity by a representative number of hours in that day-part (calibratable).
The resulting fractions sum to 1.0 and can be applied to any daily quantity
(vehicle-km or emission).

Public API
----------
DAYPARTS: tuple[str, ...]
    The day-part keys ("mrh", "erh", "rest").
DAYPART_HOURS: dict[str, float]
    Representative number of hours per day-part.
daypart_fractions(flows_per_daypart) -> dict[str, float]
    Fraction of the daily total in each day-part (sums to 1.0, or all-zero).
"""

from __future__ import annotations

#: Day-part keys, in output order.
DAYPARTS: tuple[str, ...] = ("mrh", "erh", "rest")

#: Representative number of hours in each day-part (calibratable, sums to 24).
DAYPART_HOURS: dict[str, float] = {"mrh": 2.0, "erh": 2.0, "rest": 20.0}


def _as_float(value: object) -> float:
    """Coerce *value* to a float, returning 0.0 for missing / invalid input."""
    if value is None:
        return 0.0
    try:
        return float(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0.0


def daypart_fractions(flows_per_daypart: object) -> dict[str, float]:
    """Return the fraction of the daily total carried in each day-part.

    Parameters
    ----------
    flows_per_daypart:
        The link's ``flowsPerDaypart`` value: a mapping with ``mrh``/``erh``/
        ``rest`` per-hour intensities (vehicles/hour).  Missing or non-mapping
        input yields all-zero fractions.

    Returns
    -------
    dict with keys ``mrh``, ``erh``, ``rest``.  Each value is that day-part's
    share of the daily traffic (its intensity times its hours, normalised).
    When no day-part carries traffic all fractions are 0.0.
    """
    if not isinstance(flows_per_daypart, dict):
        return dict.fromkeys(DAYPARTS, 0.0)

    volumes = {
        part: _as_float(flows_per_daypart.get(part)) * DAYPART_HOURS[part] for part in DAYPARTS
    }
    total = sum(volumes.values())
    if total <= 0.0:
        return dict.fromkeys(DAYPARTS, 0.0)

    return {part: volumes[part] / total for part in DAYPARTS}
