"""Emission factors - g/vehicle-km per pollutant, calibratable via the env.

Stage 1 uses one constant factor per pollutant.  Stage 2 refines this with a
speed-dependent multiplier and a light/heavy vehicle mix.  All values are read
from the environment (so they can be tuned via the .env file used by the runner
/ notebook) and fall back to plausible, indicative defaults for light vehicles.

Public API
----------
POLLUTANTS: tuple[str, ...]
    The pollutant keys this module models ("co2", "nox", "pm10", "pm25").
EMISSION_FACTORS: dict[str, float]
    Base emission factor per pollutant in g/vehicle-km (env-overridable).
EMISSION_FACTORS_HEAVY: dict[str, float]
    Heavy-vehicle factors in g/vehicle-km (stage 2).
HEAVY_FRACTION: float
    Fraction of the flow assumed to be heavy vehicles (stage 2).
COLD_START_FACTOR / GRADIENT_FACTOR: float
    Multiplicative correction hooks (stage 2); default 1.0 (neutral).
speed_multiplier(speed) -> float
    Speed-dependent factor multiplier (stage 2); 1.0 at the reference speed.
"""

from __future__ import annotations

import os

#: Pollutant keys, in output order.
POLLUTANTS: tuple[str, ...] = ("co2", "nox", "pm10", "pm25")


def _env_float(name: str, default: float) -> float:
    """Read *name* from the environment as a float, falling back to *default*."""
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return float(raw)
    except ValueError:
        return default


# ---------------------------------------------------------------------------
# Stage 1 - base factors (light vehicles), g/vehicle-km
# ---------------------------------------------------------------------------
#   EMISSION_FACTOR_CO2   base CO2 factor    (default 120.0)
#   EMISSION_FACTOR_NOX   base NOx factor    (default 0.30)
#   EMISSION_FACTOR_PM10  base PM10 factor   (default 0.03)
#   EMISSION_FACTOR_PM25  base PM2.5 factor  (default 0.02)

#: Base emission factors in g/vehicle-km (env-overridable, plausible defaults).
EMISSION_FACTORS: dict[str, float] = {
    "co2": _env_float("EMISSION_FACTOR_CO2", 120.0),
    "nox": _env_float("EMISSION_FACTOR_NOX", 0.30),
    "pm10": _env_float("EMISSION_FACTOR_PM10", 0.03),
    "pm25": _env_float("EMISSION_FACTOR_PM25", 0.02),
}

# ---------------------------------------------------------------------------
# Stage 2 - heavy-vehicle factors, mix and correction hooks
# ---------------------------------------------------------------------------

#: Heavy-vehicle emission factors in g/vehicle-km (env-overridable).
EMISSION_FACTORS_HEAVY: dict[str, float] = {
    "co2": _env_float("EMISSION_FACTOR_CO2_HEAVY", 800.0),
    "nox": _env_float("EMISSION_FACTOR_NOX_HEAVY", 4.0),
    "pm10": _env_float("EMISSION_FACTOR_PM10_HEAVY", 0.20),
    "pm25": _env_float("EMISSION_FACTOR_PM25_HEAVY", 0.12),
}

#: Fraction of the flow assumed to be heavy vehicles (stage 2).
HEAVY_FRACTION: float = _env_float("EMISSION_HEAVY_FRACTION", 0.05)

#: Reference speed (km/h) at which the speed multiplier equals 1.0.
SPEED_REF: float = _env_float("EMISSION_SPEED_REF", 50.0)

#: Strength of the speed correction (0.0 disables it -> multiplier always 1.0).
SPEED_SENSITIVITY: float = _env_float("EMISSION_SPEED_SENSITIVITY", 0.30)

#: Multiplicative correction hooks; default 1.0 (neutral) unless configured.
COLD_START_FACTOR: float = _env_float("EMISSION_COLD_START_FACTOR", 1.0)
GRADIENT_FACTOR: float = _env_float("EMISSION_GRADIENT_FACTOR", 1.0)


def combined_factor(pollutant: str) -> float:
    """Return the mix-weighted base factor (light + heavy) in g/vehicle-km.

    Combines the light- and heavy-vehicle factors using
    :data:`HEAVY_FRACTION`.  Used by stage 2.
    """
    light = EMISSION_FACTORS[pollutant]
    heavy = EMISSION_FACTORS_HEAVY[pollutant]
    return (1.0 - HEAVY_FRACTION) * light + HEAVY_FRACTION * heavy


def speed_multiplier(speed: float) -> float:
    """Return the speed-dependent factor multiplier for stage 2.

    Emissions per km rise at low speeds (congestion) and, more mildly, at high
    speeds.  This is a simple, calibratable U-shaped correction around
    :data:`SPEED_REF`; it returns 1.0 at the reference speed and when the
    sensitivity is 0.  A non-positive speed falls back to the reference speed.
    """
    if SPEED_SENSITIVITY <= 0.0:
        return 1.0
    v = speed if speed > 0.0 else SPEED_REF
    # Relative deviation from the reference speed, symmetric (U-shaped).
    deviation = abs(v - SPEED_REF) / SPEED_REF
    return 1.0 + SPEED_SENSITIVITY * deviation
