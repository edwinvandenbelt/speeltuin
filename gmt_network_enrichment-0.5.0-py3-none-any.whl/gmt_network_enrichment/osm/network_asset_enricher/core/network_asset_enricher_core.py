"""Enrich network links with proximity counts of traffic assets.

This module adds four new integer fields to each network link, counting nearby
traffic assets (pedestrian crossings, cycle paths, and refuge areas):

- numPedestrianCrossings: count of pedestrian crossings within ~20m that are
  oriented (nearly) perpendicular to the link
- numCyclePaths: count of cycle paths that intersect the link (nearly)
  perpendicularly and lie within ~20m
- numRefugeAreas: count of refuge areas (all types: crossing, footway, traffic)
  that overlap or are within ~20m of the link

Each count is an integer >= 0. The existing trafficSignal (bool) field is
preserved and not modified.

The algorithm uses distance-based and geometric checks:

1. For pedestrian crossings: haversine distance to link center + perpendicularity
   check via dot product.
2. For cycle paths: geometry intersection + bearing angle check (80-100°).
3. For refuge areas: overlap check (Polygon) or proximity check (Point/Polygon).
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)

# Spatial matching parameters
CROSSING_BUFFER_M = 20.0  # max distance from crossing to link centerline
CYCLEPATH_BUFFER_M = 20.0  # max distance from cyclepath to link
REFUGE_BUFFER_M = 20.0  # max distance from refuge to link

# Perpendicularity tolerances
PERPENDICULAR_TOLERANCE = 0.2  # dot product threshold for crossings
BEARING_TOLERANCE_DEG = 20.0  # degrees from perfect perpendicular (90°) for cyclepaths


# ============================================================================
# Haversine distance (meters)
# ============================================================================


def haversine(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """Compute haversine distance between two points in meters.

    Parameters
    ----------
    lon1, lat1 : float
        First point (lon, lat) in decimal degrees.
    lon2, lat2 : float
        Second point (lon, lat) in decimal degrees.

    Returns
    -------
    float
        Distance in meters.
    """
    R = 6371000.0  # Earth radius in meters
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)

    a = (
        math.sin(delta_phi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return R * c


# ============================================================================
# Vector operations
# ============================================================================


def normalize(vec: tuple[float, float]) -> tuple[float, float]:
    """Normalize a 2D vector to unit length."""
    x, y = vec
    mag = math.sqrt(x * x + y * y)
    if mag < 1e-9:
        return (0.0, 0.0)
    return (x / mag, y / mag)


def dot_product(v1: tuple[float, float], v2: tuple[float, float]) -> float:
    """Compute dot product of two 2D vectors."""
    return v1[0] * v2[0] + v1[1] * v2[1]


# ============================================================================
# Perpendicularity checks
# ============================================================================


def is_perpendicular_crossing(
    crossing_lon: float,
    crossing_lat: float,
    link_lon_start: float,
    link_lat_start: float,
    link_lon_end: float,
    link_lat_end: float,
    tolerance: float = PERPENDICULAR_TOLERANCE,
) -> bool:
    """Check if a crossing is perpendicular to a link (via dot product).

    Parameters
    ----------
    crossing_lon, crossing_lat : float
        Crossing point coordinates.
    link_lon_start, link_lat_start : float
        Link start node (fromNode).
    link_lon_end, link_lat_end : float
        Link end node (toNode).
    tolerance : float
        Dot product tolerance (default 0.2). Perpendicular if |dot| < tolerance.

    Returns
    -------
    bool
        True if crossing is (nearly) perpendicular to link.
    """
    # Link direction vector (not normalized, for speed).
    link_vec = (link_lon_end - link_lon_start, link_lat_end - link_lat_start)

    # Crossing-to-link-start vector.
    cross_vec = (crossing_lon - link_lon_start, crossing_lat - link_lat_start)

    # Normalize both for dot product.
    link_norm = normalize(link_vec)
    cross_norm = normalize(cross_vec)

    # Perpendicular if dot product is close to 0.
    dot = abs(dot_product(link_norm, cross_norm))
    return dot < tolerance


def bearing_degrees(
    lon1: float,
    lat1: float,
    lon2: float,
    lat2: float,
) -> float:
    """Compute bearing (azimuth) from point 1 to point 2 in degrees (0-360).

    Parameters
    ----------
    lon1, lat1 : float
        Start point.
    lon2, lat2 : float
        End point.

    Returns
    -------
    float
        Bearing in degrees (0=North, 90=East, 180=South, 270=West).
    """
    lat1_rad = math.radians(lat1)
    lat2_rad = math.radians(lat2)
    dlon = math.radians(lon2 - lon1)

    y = math.sin(dlon) * math.cos(lat2_rad)
    x = math.cos(lat1_rad) * math.sin(lat2_rad) - math.sin(lat1_rad) * math.cos(
        lat2_rad
    ) * math.cos(dlon)

    bearing = math.degrees(math.atan2(y, x))
    return (bearing + 360) % 360  # Normalize to 0-360


def angle_between_bearings(bearing1: float, bearing2: float) -> float:
    """Compute acute angle between two bearings (0-90 degrees).

    Parameters
    ----------
    bearing1, bearing2 : float
        Bearings in degrees (0-360).

    Returns
    -------
    float
        Angle in degrees (0-90).
    """
    diff = abs(bearing1 - bearing2)
    if diff > 180:
        diff = 360 - diff
    return min(diff, 180 - diff)


# ============================================================================
# Geometry utilities
# ============================================================================


def linestring_vertices(geom: dict) -> list[tuple[float, float]] | None:
    """Extract vertices from a LineString geometry.

    Parameters
    ----------
    geom : dict
        GeoJSON geometry object with type='LineString'.

    Returns
    -------
    list[tuple[float, float]] | None
        List of (lon, lat) tuples, or None if invalid.
    """
    if geom.get("type") != "LineString":
        return None
    coords = geom.get("coordinates")
    if not isinstance(coords, list) or len(coords) < 2:
        return None
    return [(c[0], c[1]) for c in coords]


def polygon_vertices(geom: dict) -> list[tuple[float, float]] | None:
    """Extract exterior ring vertices from a Polygon geometry.

    Parameters
    ----------
    geom : dict
        GeoJSON geometry object with type='Polygon'.

    Returns
    -------
    list[tuple[float, float]] | None
        List of (lon, lat) tuples for exterior ring, or None if invalid.
    """
    if geom.get("type") != "Polygon":
        return None
    coords = geom.get("coordinates")
    if not isinstance(coords, list) or len(coords) == 0:
        return None
    exterior = coords[0]
    if not isinstance(exterior, list) or len(exterior) < 3:
        return None
    return [(c[0], c[1]) for c in exterior]


def point_coordinates(geom: dict) -> tuple[float, float] | None:
    """Extract coordinates from a Point geometry.

    Parameters
    ----------
    geom : dict
        GeoJSON geometry object with type='Point'.

    Returns
    -------
    tuple[float, float] | None
        (lon, lat) or None if invalid.
    """
    if geom.get("type") != "Point":
        return None
    coords = geom.get("coordinates")
    if not isinstance(coords, list) or len(coords) != 2:
        return None
    return (float(coords[0]), float(coords[1]))


# ============================================================================
# Projections and distances
# ============================================================================


def project_point_to_line(
    point: tuple[float, float],
    line_start: tuple[float, float],
    line_end: tuple[float, float],
) -> tuple[float, float]:
    """Project a point onto a line segment, returning the closest point.

    Uses parametric projection: clamps result to segment [0, 1].

    Parameters
    ----------
    point : tuple[float, float]
        Point to project.
    line_start, line_end : tuple[float, float]
        Line segment endpoints.

    Returns
    -------
    tuple[float, float]
        Closest point on the line segment.
    """
    px, py = point
    x1, y1 = line_start
    x2, y2 = line_end

    dx = x2 - x1
    dy = y2 - y1
    denom = dx * dx + dy * dy

    if denom < 1e-9:
        # Degenerate line (start == end)
        return line_start

    t = ((px - x1) * dx + (py - y1) * dy) / denom
    t = max(0.0, min(1.0, t))  # Clamp to [0, 1]

    return (x1 + t * dx, y1 + t * dy)


def point_to_line_distance(
    point: tuple[float, float],
    line_start: tuple[float, float],
    line_end: tuple[float, float],
) -> float:
    """Compute distance from point to line segment in meters.

    Parameters
    ----------
    point : tuple[float, float]
        Point (lon, lat).
    line_start, line_end : tuple[float, float]
        Line segment endpoints (lon, lat).

    Returns
    -------
    float
        Distance in meters.
    """
    closest = project_point_to_line(point, line_start, line_end)
    return haversine(point[0], point[1], closest[0], closest[1])


def min_distance_linestrings(
    line1_vertices: list[tuple[float, float]],
    line2_vertices: list[tuple[float, float]],
) -> float:
    """Compute minimum distance between two LineStrings.

    Parameters
    ----------
    line1_vertices, line2_vertices : list[tuple[float, float]]
        Vertex lists.

    Returns
    -------
    float
        Minimum distance in meters.
    """
    min_dist = float("inf")

    for i in range(len(line1_vertices) - 1):
        seg1_start = line1_vertices[i]
        seg1_end = line1_vertices[i + 1]

        for v2 in line2_vertices:
            dist = point_to_line_distance(v2, seg1_start, seg1_end)
            min_dist = min(min_dist, dist)

    return min_dist


# ============================================================================
# Crossing/LineString intersection detection
# ============================================================================


def linestring_intersects_linestring(
    line1_vertices: list[tuple[float, float]],
    line2_vertices: list[tuple[float, float]],
) -> bool:
    """Check if two LineStrings intersect (simple axis-aligned check).

    This is a conservative approximation: checks bounding boxes and segment
    proximity. For exact intersection, use shapely.

    Parameters
    ----------
    line1_vertices, line2_vertices : list[tuple[float, float]]
        Vertex lists.

    Returns
    -------
    bool
        True if lines likely intersect or touch.
    """
    # Bounding box check.
    if not _bbox_overlap(line1_vertices, line2_vertices):
        return False

    # Simple segment proximity check: if any vertex of line2 is very close
    # to any segment of line1, consider them intersecting.
    for i in range(len(line1_vertices) - 1):
        seg_start = line1_vertices[i]
        seg_end = line1_vertices[i + 1]
        for v2 in line2_vertices:
            dist = point_to_line_distance(v2, seg_start, seg_end)
            if dist < 1.0:  # Within 1 meter
                return True

    return False


def _bbox_overlap(
    line1_vertices: list[tuple[float, float]],
    line2_vertices: list[tuple[float, float]],
) -> bool:
    """Check if bounding boxes of two line strings overlap (with buffer)."""
    min_x1 = min(v[0] for v in line1_vertices)
    max_x1 = max(v[0] for v in line1_vertices)
    min_y1 = min(v[1] for v in line1_vertices)
    max_y1 = max(v[1] for v in line1_vertices)

    min_x2 = min(v[0] for v in line2_vertices)
    max_x2 = max(v[0] for v in line2_vertices)
    min_y2 = min(v[1] for v in line2_vertices)
    max_y2 = max(v[1] for v in line2_vertices)

    # Add small buffer (0.01 degrees ≈ 1 km).
    buffer = 0.01

    return not (
        max_x1 + buffer < min_x2
        or max_x2 + buffer < min_x1
        or max_y1 + buffer < min_y2
        or max_y2 + buffer < min_y1
    )


def find_cyclepath_link_bearing_angle(
    cyclepath_vertices: list[tuple[float, float]],
    link_vertices: list[tuple[float, float]],
) -> float | None:
    """Find intersection point and compute angle between cyclepath and link.

    Parameters
    ----------
    cyclepath_vertices, link_vertices : list[tuple[float, float]]
        Vertex lists for cyclepath and link.

    Returns
    -------
    float | None
        Acute angle (0-90°) between bearings at intersection, or None if
        no intersection found.
    """
    # Find closest point on cyclepath to link midpoint.
    link_mid = (
        (link_vertices[0][0] + link_vertices[-1][0]) / 2,
        (link_vertices[0][1] + link_vertices[-1][1]) / 2,
    )

    # Find closest segment of cyclepath to link midpoint.
    best_angle = None
    best_dist = float("inf")

    for i in range(len(cyclepath_vertices) - 1):
        cp_start = cyclepath_vertices[i]
        cp_end = cyclepath_vertices[i + 1]

        closest = project_point_to_line(link_mid, cp_start, cp_end)
        dist = haversine(link_mid[0], link_mid[1], closest[0], closest[1])

        if dist < best_dist:
            best_dist = dist
            # Bearing of cyclepath at this segment.
            cp_bearing = bearing_degrees(cp_start[0], cp_start[1], cp_end[0], cp_end[1])
            # Bearing of link.
            link_bearing = bearing_degrees(
                link_vertices[0][0], link_vertices[0][1], link_vertices[-1][0], link_vertices[-1][1]
            )
            best_angle = angle_between_bearings(cp_bearing, link_bearing)

    return best_angle


# ============================================================================
# Main enrichment function
# ============================================================================


def enrich_network_with_assets(
    network_fc: dict,
    assets_fc: dict,
) -> dict:
    """Enrich network links with asset proximity counts.

    Parameters
    ----------
    network_fc : dict
        GeoJSON FeatureCollection of network links with geometry (LineString)
        and properties including fromNode, toNode.
    assets_fc : dict
        GeoJSON FeatureCollection of OSM traffic assets with assetType property.

    Returns
    -------
    dict
        Modified network_fc with three new integer fields per link:
        - numPedestrianCrossings: int >= 0
        - numCyclePaths: int >= 0
        - numRefugeAreas: int >= 0

    Notes
    -----
    - Existing trafficSignal (bool) field is NOT modified.
    - All geometry is WGS-84 (lon, lat).
    - Counts are computed using distance + perpendicularity checks.
    """
    # Initialize counts for all links.
    for feature in network_fc.get("features", []):
        feature["properties"]["numPedestrianCrossings"] = 0
        feature["properties"]["numCyclePaths"] = 0
        feature["properties"]["numRefugeAreas"] = 0

    assets = assets_fc.get("features", [])
    if not assets:
        logger.info("enrich_network_with_assets: no assets to process")
        return network_fc

    # Group assets by type for efficiency.
    crossings = []
    cyclepaths = []
    refuges = []

    for asset in assets:
        asset_type = asset.get("properties", {}).get("assetType")
        geom = asset.get("geometry")

        if asset_type == "pedestrianCrossing":
            crossings.append(asset)
        elif asset_type == "cyclePath":
            cyclepaths.append(asset)
        elif asset_type in ("refugeAreaCrossing", "refugeAreaFootway", "refugeAreaTraffic"):
            refuges.append(asset)

    logger.info(
        "enrich_network_with_assets: processing %d crossings, %d cyclepaths, %d refuges",
        len(crossings),
        len(cyclepaths),
        len(refuges),
    )

    # Process each link.
    for feature in network_fc.get("features", []):
        geom = feature.get("geometry")
        props = feature.get("properties", {})

        # Extract link endpoints.
        link_vertices = linestring_vertices(geom)
        if not link_vertices or len(link_vertices) < 2:
            continue

        link_start = link_vertices[0]
        link_end = link_vertices[-1]

        # Count pedestrian crossings.
        crossing_count = 0
        for crossing in crossings:
            crossing_geom = crossing.get("geometry")
            crossing_pt = point_coordinates(crossing_geom)
            if crossing_pt is None:
                continue

            # Check distance to link centerline.
            dist = point_to_line_distance(crossing_pt, link_start, link_end)
            if dist > CROSSING_BUFFER_M:
                continue

            # Check perpendicularity.
            if not is_perpendicular_crossing(
                crossing_pt[0],
                crossing_pt[1],
                link_start[0],
                link_start[1],
                link_end[0],
                link_end[1],
            ):
                continue

            crossing_count += 1

        # Count cycle paths.
        cyclepath_count = 0
        for cyclepath in cyclepaths:
            cyclepath_geom = cyclepath.get("geometry")
            cyclepath_vertices = linestring_vertices(cyclepath_geom)
            if cyclepath_vertices is None or len(cyclepath_vertices) < 2:
                continue

            # Check distance.
            min_dist = min_distance_linestrings(link_vertices, cyclepath_vertices)
            if min_dist > CYCLEPATH_BUFFER_M:
                continue

            # Check intersection.
            if not linestring_intersects_linestring(link_vertices, cyclepath_vertices):
                continue

            # Check perpendicularity (bearing angle 80-100°).
            angle = find_cyclepath_link_bearing_angle(cyclepath_vertices, link_vertices)
            if angle is None:
                continue
            if not (90 - BEARING_TOLERANCE_DEG <= angle <= 90 + BEARING_TOLERANCE_DEG):
                continue

            cyclepath_count += 1

        # Count refuge areas.
        refuge_count = 0
        for refuge in refuges:
            refuge_geom = refuge.get("geometry")
            if refuge_geom is None:
                continue

            geom_type = refuge_geom.get("type")

            if geom_type == "Point":
                pt = point_coordinates(refuge_geom)
                if pt is None:
                    continue
                dist = point_to_line_distance(pt, link_start, link_end)
                if dist <= REFUGE_BUFFER_M:
                    refuge_count += 1

            elif geom_type == "Polygon":
                # For polygons, check overlap or proximity.
                # Simple heuristic: if any polygon vertex is close to link, count it.
                poly_verts = polygon_vertices(refuge_geom)
                if poly_verts is None:
                    continue

                # Check if any vertex is within buffer.
                found = False
                for pv in poly_verts:
                    dist = point_to_line_distance(pv, link_start, link_end)
                    if dist <= REFUGE_BUFFER_M:
                        found = True
                        break

                if found:
                    refuge_count += 1

        # Assign counts to link.
        props["numPedestrianCrossings"] = crossing_count
        props["numCyclePaths"] = cyclepath_count
        props["numRefugeAreas"] = refuge_count

    logger.info("enrich_network_with_assets: enrichment complete")
    return network_fc
