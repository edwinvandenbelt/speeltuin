"""Network asset enricher core module."""

from __future__ import annotations
