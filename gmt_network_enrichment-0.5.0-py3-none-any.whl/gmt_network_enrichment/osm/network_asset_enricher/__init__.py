"""Network asset enricher — enrich network links with asset proximity counts."""

from __future__ import annotations

from .core.network_asset_enricher_core import enrich_network_with_assets

__all__ = ["enrich_network_with_assets"]
