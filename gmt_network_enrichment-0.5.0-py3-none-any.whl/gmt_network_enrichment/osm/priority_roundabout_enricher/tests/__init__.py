"""Tests for priority_roundabout_enricher."""
