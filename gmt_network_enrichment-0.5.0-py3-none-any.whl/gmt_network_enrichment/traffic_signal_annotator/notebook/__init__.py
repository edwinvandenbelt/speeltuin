# src/traffic_signal_annotator/notebook/__init__.py
