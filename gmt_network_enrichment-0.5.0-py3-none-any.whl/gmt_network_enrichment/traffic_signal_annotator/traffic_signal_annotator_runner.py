"""Local debug runner for traffic_signal_annotator.

Reads a network GeoParquet file, queries Overpass for ``highway=traffic_signals``
nodes within its bounding box, annotates every link with a ``trafficSignal``
boolean property, and writes the enriched FeatureCollection back to the same
file (in-place update).

Usage
-----
    python -m traffic_signal_annotator.traffic_signal_annotator_runner \\
        --network output/deventer/abc123-NETWORK-CAR.parquet

    python -m traffic_signal_annotator.traffic_signal_annotator_runner \\
        --network s3://gmp-networks/network/abc123-NETWORK-CAR.parquet \\
        --tolerance-m 20 \\
        --overpass-timeout 90

Prerequisites
-------------
* numpy installed (used by KDTree2D).
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri.removeprefix("file://"), "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Annotate a network parquet with trafficSignal=True/False on every link "
            "whose toNode lies within --tolerance-m metres of an OSM traffic signal. "
            "The parquet is updated in-place."
        )
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="Network parquet URI (s3://bucket/key or local path). Updated in-place.",
    )
    parser.add_argument(
        "--tolerance-m",
        type=float,
        default=15.0,
        metavar="METRES",
        help="Max distance in metres to match a toNode to a traffic-signal node (default: 15).",
    )
    parser.add_argument(
        "--overpass-timeout",
        type=int,
        default=60,
        metavar="SECONDS",
        help="Overpass HTTP + server-side timeout in seconds (default: 60).",
    )
    parser.add_argument(
        "--osm-path",
        dest="osm_path",
        default=None,
        metavar="PATH",
        help=(
            "Path to a local .osm.pbf extract to read instead of querying the "
            "Overpass HTTP API. Falls back to the OSM_PBF_PATH environment "
            "variable / .env when omitted."
        ),
    )
    parser.add_argument(
        "--osm-workers",
        dest="osm_workers",
        type=int,
        default=None,
        metavar="N",
        help=(
            "Worker processes for reading the local .osm.pbf extract. Defaults "
            "to the OSM_PBF_WORKERS environment variable / CPU count (capped at 8)."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        metavar="PATH",
        help="Path to .env file for AWS credentials (auto-discovered if omitted).",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_network_enrichment.traffic_signal_annotator.core.traffic_signal_annotator_core import (
        annotate_network,
        fetch_signal_coords,
    )

    # Read network
    print(f"Reading  : {args.network}")
    fc = from_geoparquet(_read_uri(args.network))
    feature_count = len(fc.get("features") or [])
    print(f"Features : {feature_count:,}")

    # Determine bounding box from FC properties (written by network_fetcher / prepare).
    bbox: list[float] | None = (fc.get("properties") or {}).get("bbox")
    if not bbox or len(bbox) < 4:
        # Fallback: derive bbox from feature geometries.
        print("No bbox in FC properties — deriving from geometries …")
        lons: list[float] = []
        lats: list[float] = []
        for feat in fc.get("features") or []:
            for coord in (feat.get("geometry") or {}).get("coordinates") or []:
                lons.append(float(coord[0]))
                lats.append(float(coord[1]))
        if not lons:
            print(
                "[error] Cannot determine bounding box — network has no geometry.", file=sys.stderr
            )
            sys.exit(1)
        bbox = [min(lons), min(lats), max(lons), max(lats)]
    print(f"Bbox     : {bbox}")

    # Fetch traffic-signal nodes from Overpass.
    print(f"Querying Overpass (timeout={args.overpass_timeout}s) …")
    signal_coords = fetch_signal_coords(
        bbox,
        timeout=args.overpass_timeout,
        osm_path=args.osm_path,
        osm_workers=args.osm_workers,
    )
    print(f"Signals  : {len(signal_coords):,} nodes found")

    # Annotate network.
    print(f"Annotating (tolerance={args.tolerance_m} m) …")
    annotated_fc, stats = annotate_network(fc, signal_coords, tolerance_m=args.tolerance_m)
    print(f"Marked   : {stats['annotated']:,} / {stats['total']:,} links as trafficSignal=True")

    # Write back in-place.
    print(f"Writing  : {args.network}")
    _write_uri(args.network, to_geoparquet(annotated_fc))
    print("Done.")


if __name__ == "__main__":
    main()
