# src/traffic_signal_annotator/core/__init__.py
