"""Pure-Python traffic_signal_annotator core — no I/O, no boto3, no external deps.

Annotates a network FeatureCollection with a ``trafficSignal`` boolean property
on every link whose ``toNode`` endpoint lies within a given distance of an OSM
``highway=traffic_signals`` node.

The spatial matching works entirely in WGS-84 degree space, using a KD-tree for
efficient nearest-neighbour lookup and a flat-earth distance formula to convert
the result to metres before applying the tolerance threshold.

Public API
----------
build_signal_query(bbox, timeout) -> str
    Build an Overpass QL query string for ``highway=traffic_signals`` nodes.

parse_signal_elements(elements) -> list[tuple[float, float]]
    Extract ``(lon, lat)`` pairs from the raw Overpass response elements.

fetch_signal_coords(bbox, timeout) -> list[tuple[float, float]]
    Convenience wrapper: build query → call Overpass → parse elements.

signals_to_features(signal_coords) -> list[dict]
    Convert signal coordinates to GeoJSON Point Feature dicts tagged
    ``assetType="trafficSignal"`` (for the combined traffic-assets output).

annotate_network(network_fc, signal_coords, tolerance_m) -> tuple[dict, dict]
    Write ``trafficSignal: bool`` onto every feature in *network_fc*.
    Returns ``(annotated_fc, stats)``.
    stats: {
        "total": int,          # total number of features
        "annotated": int,      # features marked trafficSignal=True
        "signal_nodes_found":  # number of OSM signal nodes retrieved
    }
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

# Metres per degree of latitude (WGS-84 spheroid, mid-latitude approximation).
_M_PER_DEG_LAT: float = 111_320.0


# ---------------------------------------------------------------------------
# Overpass query builder
# ---------------------------------------------------------------------------


def build_signal_query(bbox: list[float], timeout: int = 60) -> str:
    """Build an Overpass QL query for ``highway=traffic_signals`` nodes.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    timeout:
        Overpass server-side timeout in seconds (written into the query header).

    Returns
    -------
    str
        A ready-to-submit Overpass QL string.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    # Overpass uses (south, west, north, east) coordinate order.
    coord_str = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    return (
        f"[out:json][timeout:{timeout}];\n"
        f'node["highway"="traffic_signals"]({coord_str});\n'
        f"out geom;"
    )


# ---------------------------------------------------------------------------
# Response parser
# ---------------------------------------------------------------------------


def parse_signal_elements(elements: list[dict]) -> list[tuple[float, float]]:
    """Extract ``(lon, lat)`` pairs from raw Overpass response elements.

    Only elements of type ``"node"`` with both ``lat`` and ``lon`` fields are
    included.  Invalid or incomplete elements are silently skipped.

    Parameters
    ----------
    elements:
        The ``"elements"`` list from an Overpass JSON response.

    Returns
    -------
    list of ``(lon, lat)`` float tuples.
    """
    coords: list[tuple[float, float]] = []
    for el in elements:
        if el.get("type") != "node":
            continue
        try:
            lat = float(el["lat"])
            lon = float(el["lon"])
        except (KeyError, TypeError, ValueError):
            continue
        coords.append((lon, lat))
    return coords


# ---------------------------------------------------------------------------
# Signal → asset feature conversion
# ---------------------------------------------------------------------------

#: Asset-type tag written on every produced traffic-signal feature.
ASSET_TYPE: str = "trafficSignal"


def signals_to_features(signal_coords: list[tuple[float, float]]) -> list[dict]:
    """Convert traffic-signal coordinates to GeoJSON Point Feature dicts.

    Each feature is tagged ``properties.assetType == "trafficSignal"`` so the
    result can be merged into the combined ``{area_id}-TRAFFIC-ASSETS.parquet``
    produced by the prepare pipeline, alongside traffic-sign features.

    Parameters
    ----------
    signal_coords:
        List of ``(lon, lat)`` tuples, e.g. from :func:`fetch_signal_coords`.

    Returns
    -------
    list of GeoJSON ``Feature`` dicts with ``Point`` geometry.
    """
    features: list[dict] = []
    for lon, lat in signal_coords:
        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [float(lon), float(lat)]},
                "properties": {"assetType": ASSET_TYPE},
            }
        )
    return features


# ---------------------------------------------------------------------------
# Convenience wrapper
# ---------------------------------------------------------------------------


def fetch_signal_coords(
    bbox: list[float],
    timeout: int = 60,
    *,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> list[tuple[float, float]]:
    """Query Overpass for traffic-signal nodes and return their coordinates.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    timeout:
        HTTP + server-side timeout in seconds.

    Returns
    -------
    list of ``(lon, lat)`` float tuples — one per OSM traffic-signal node
    found inside *bbox*.
    """
    from gmt_shared.overpass import (
        DEFAULT_OVERPASS_URL,
        _resolve_pbf_path,
        fetch_overpass,
    )

    query = build_signal_query(bbox, timeout=timeout)
    # Only advertise the HTTP Overpass endpoint/query when we will actually hit
    # it — a configured local ``.osm.pbf`` backend prints its own banner instead.
    if _resolve_pbf_path(osm_path) is None:
        print(f"  [Overpass] endpoint : {DEFAULT_OVERPASS_URL}")
        print(f"  [Overpass] query    :\n{query}")
    logger.info("Fetching traffic signals from Overpass  bbox=%s  timeout=%ds", bbox, timeout)
    response = fetch_overpass(query, timeout=timeout, osm_path=osm_path, osm_workers=osm_workers)
    n_raw = len(response.get("elements") or [])
    print(f"  [Overpass] response : {n_raw} elements")
    coords = parse_signal_elements(response.get("elements") or [])
    logger.info("Found %d traffic-signal nodes", len(coords))
    return coords


# ---------------------------------------------------------------------------
# Flat-earth distance (inline — avoids dependency on private geo_utils symbol)
# ---------------------------------------------------------------------------


def _dist_m(lon0: float, lat0: float, lon1: float, lat1: float) -> float:
    """Flat-earth distance in metres between two WGS-84 points."""
    cos_lat = math.cos(math.radians((lat0 + lat1) / 2.0))
    dx = (lon1 - lon0) * cos_lat * _M_PER_DEG_LAT
    dy = (lat1 - lat0) * _M_PER_DEG_LAT
    return math.hypot(dx, dy)


# ---------------------------------------------------------------------------
# Network annotator
# ---------------------------------------------------------------------------


def annotate_network(
    network_fc: dict,
    signal_coords: list[tuple[float, float]],
    tolerance_m: float = 15.0,
) -> tuple[dict, dict]:
    """Annotate every network link with a ``trafficSignal`` boolean property.

    A link is marked ``trafficSignal=True`` when its **toNode endpoint**
    (the last coordinate of the LineString geometry) lies within *tolerance_m*
    metres of any OSM ``highway=traffic_signals`` node.

    Parameters
    ----------
    network_fc:
        A GeoJSON FeatureCollection dict (network parquet deserialised via
        ``shared.geoparquet.from_geoparquet``).
    signal_coords:
        List of ``(lon, lat)`` tuples from :func:`fetch_signal_coords`.
    tolerance_m:
        Maximum distance in metres to consider a toNode as a signalised
        intersection.  Default: 15.0 m.

    Returns
    -------
    annotated_fc:
        A new FeatureCollection dict with ``trafficSignal`` set on every
        feature.  All other fields are unchanged.
    stats:
        ``{"total": int, "annotated": int, "signal_nodes_found": int}``
    """
    import numpy as np
    from gmt_shared.kd_tree import KDTree2D

    features: list[dict] = list(network_fc.get("features") or [])
    total = len(features)
    annotated = 0

    if not signal_coords:
        logger.warning("No traffic-signal nodes provided — all links marked trafficSignal=False.")
        for feat in features:
            feat.setdefault("properties", {})["trafficSignal"] = False
        return (
            {**network_fc, "features": features},
            {"total": total, "annotated": 0, "signal_nodes_found": 0},
        )

    # Build a KD-tree over signal node coordinates (lon, lat in degrees).
    signal_array = np.array(signal_coords, dtype=float)  # shape (N, 2)
    tree = KDTree2D(signal_array)

    for feat in features:
        props = feat.setdefault("properties", {})
        geom = feat.get("geometry") or {}
        coords = geom.get("coordinates") or []

        is_signal = False
        if coords:
            # toNode endpoint = last coordinate of the LineString.
            to_lon, to_lat = float(coords[-1][0]), float(coords[-1][1])
            query_pt = np.array([[to_lon, to_lat]], dtype=float)
            _deg_dists, indices = tree.query(query_pt, k=1)
            nearest_idx = int(indices[0, 0])
            s_lon, s_lat = signal_coords[nearest_idx]
            dist = _dist_m(to_lon, to_lat, s_lon, s_lat)
            is_signal = dist <= tolerance_m

        props["trafficSignal"] = is_signal
        if is_signal:
            annotated += 1

    logger.info("Annotation complete: %d/%d links marked as trafficSignal=True", annotated, total)

    return (
        {**network_fc, "features": features},
        {
            "total": total,
            "annotated": annotated,
            "signal_nodes_found": len(signal_coords),
        },
    )
