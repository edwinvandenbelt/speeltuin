# src/traffic_signal_annotator/__init__.py
