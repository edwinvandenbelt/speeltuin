# src/traffic_signal_annotator/tests/__init__.py
