"""Unit tests for bgt_fetcher core (pure functions + stubbed OGC client)."""

from __future__ import annotations

from gmt_network_enrichment.bgt_fetcher.core.bgt_fetcher_core import (
    ASSET_TYPE_BAK,
    ASSET_TYPE_BIKE_PATH,
    ASSET_TYPE_BRIDGE,
    ASSET_TYPE_SCREEN,
    ASSET_TYPE_SIDEWALK,
    ASSET_TYPE_SPEED_BUMP,
    ASSET_TYPE_TRAFFIC_ISLAND,
    ASSET_TYPE_TUNNEL,
    BGT_QUERY_VER,
    COLLECTION_BAK,
    COLLECTION_OVERBRUGGINGSDEEL,
    COLLECTION_SCHEIDING_LIJN,
    COLLECTION_SCHEIDING_VLAK,
    COLLECTION_TUNNELDEEL,
    COLLECTION_WEGDEEL,
    fetch_bgt_assets,
    filter_bike_paths,
    filter_screens,
    filter_sidewalks,
    filter_speed_bumps,
    filter_traffic_islands,
    tag_all,
)

# NL bbox (Lochem-ish) and a non-NL bbox (Paris).
_NL_BBOX = [6.39, 52.14, 6.43, 52.17]
_PARIS_BBOX = [2.2, 48.8, 2.4, 48.9]


def _polygon(offset: float = 0.0) -> dict:
    return {
        "type": "Polygon",
        "coordinates": [
            [
                [6.40 + offset, 52.15],
                [6.41 + offset, 52.15],
                [6.41 + offset, 52.16],
                [6.40 + offset, 52.15],
            ]
        ],
    }


def _linestring(offset: float = 0.0) -> dict:
    return {
        "type": "LineString",
        "coordinates": [[6.40 + offset, 52.15], [6.41 + offset, 52.16]],
    }


def _point(offset: float = 0.0) -> dict:
    return {"type": "Point", "coordinates": [6.40 + offset, 52.15]}


# ---------------------------------------------------------------------------
# filter_speed_bumps
# ---------------------------------------------------------------------------


def test_filter_speed_bumps_keeps_only_verkeersdrempel() -> None:
    features = [
        {
            "type": "Feature",
            "geometry": _polygon(),
            "properties": {"functie": "rijbaan lokale weg", "plus_functie": "verkeersdrempel"},
        },
        {
            "type": "Feature",
            "geometry": _polygon(0.02),
            "properties": {"functie": "rijbaan lokale weg", "plus_functie": None},
        },
    ]
    out = filter_speed_bumps(features)
    assert len(out) == 1
    assert out[0]["properties"]["assetType"] == ASSET_TYPE_SPEED_BUMP
    # Original polygon geometry is preserved.
    assert out[0]["geometry"]["type"] == "Polygon"


def test_filter_speed_bumps_ignores_functie_field() -> None:
    # "verkeersdrempel" must be in plus_functie, not functie.
    features = [
        {"type": "Feature", "geometry": _polygon(), "properties": {"functie": "verkeersdrempel"}},
    ]
    assert filter_speed_bumps(features) == []


# ---------------------------------------------------------------------------
# filter_sidewalks
# ---------------------------------------------------------------------------


def test_filter_sidewalks_keeps_only_voetpad() -> None:
    features = [
        {
            "type": "Feature",
            "geometry": _polygon(),
            "properties": {"functie": "voetpad"},
        },
        {
            "type": "Feature",
            "geometry": _polygon(0.02),
            "properties": {"functie": "rijbaan lokale weg"},
        },
    ]
    out = filter_sidewalks(features)
    assert len(out) == 1
    assert out[0]["properties"]["assetType"] == ASSET_TYPE_SIDEWALK
    # Original polygon geometry is preserved.
    assert out[0]["geometry"]["type"] == "Polygon"


def test_filter_sidewalks_ignores_plus_functie_field() -> None:
    # "voetpad" must be in functie, not plus_functie.
    features = [
        {"type": "Feature", "geometry": _polygon(), "properties": {"plus_functie": "voetpad"}},
    ]
    assert filter_sidewalks(features) == []


# ---------------------------------------------------------------------------
# filter_bike_paths
# ---------------------------------------------------------------------------


def test_filter_bike_paths_keeps_only_fietspad() -> None:
    features = [
        {
            "type": "Feature",
            "geometry": _polygon(),
            "properties": {"functie": "fietspad"},
        },
        {
            "type": "Feature",
            "geometry": _polygon(0.02),
            "properties": {"functie": "rijbaan lokale weg"},
        },
    ]
    out = filter_bike_paths(features)
    assert len(out) == 1
    assert out[0]["properties"]["assetType"] == ASSET_TYPE_BIKE_PATH
    # Original polygon geometry is preserved.
    assert out[0]["geometry"]["type"] == "Polygon"


def test_filter_bike_paths_ignores_plus_functie_field() -> None:
    # "fietspad" must be in functie, not plus_functie.
    features = [
        {"type": "Feature", "geometry": _polygon(), "properties": {"plus_functie": "fietspad"}},
    ]
    assert filter_bike_paths(features) == []


# ---------------------------------------------------------------------------
# filter_traffic_islands
# ---------------------------------------------------------------------------


def test_filter_traffic_islands_keeps_only_verkeerseiland() -> None:
    features = [
        {
            "type": "Feature",
            "geometry": _polygon(),
            "properties": {"functie": "verkeerseiland"},
        },
        {
            "type": "Feature",
            "geometry": _polygon(0.02),
            "properties": {"functie": "rijbaan lokale weg"},
        },
    ]
    out = filter_traffic_islands(features)
    assert len(out) == 1
    assert out[0]["properties"]["assetType"] == ASSET_TYPE_TRAFFIC_ISLAND
    # Original polygon geometry is preserved.
    assert out[0]["geometry"]["type"] == "Polygon"


def test_filter_traffic_islands_ignores_plus_functie_field() -> None:
    # "verkeerseiland" must be in functie, not plus_functie.
    features = [
        {
            "type": "Feature",
            "geometry": _polygon(),
            "properties": {"plus_functie": "verkeerseiland"},
        },
    ]
    assert filter_traffic_islands(features) == []


# ---------------------------------------------------------------------------
# filter_screens
# ---------------------------------------------------------------------------


def test_filter_screens_keeps_only_geluidsscherm() -> None:
    features = [
        {
            "type": "Feature",
            "geometry": _linestring(),
            "properties": {"type": "hek", "plus_type": "geluidsscherm"},
        },
        {
            "type": "Feature",
            "geometry": _polygon(),
            "properties": {"type": "muur", "plus_type": "geluidsscherm"},
        },
        {
            "type": "Feature",
            "geometry": _linestring(0.02),
            "properties": {"type": "hek", "plus_type": None},
        },
    ]
    out = filter_screens(features)
    assert len(out) == 2
    assert all(f["properties"]["assetType"] == ASSET_TYPE_SCREEN for f in out)
    # Original geometry (line + polygon) is preserved.
    assert {f["geometry"]["type"] for f in out} == {"LineString", "Polygon"}


def test_filter_screens_ignores_coarse_type_field() -> None:
    # "geluidsscherm" must be in plus_type, not the coarse type field.
    features = [
        {"type": "Feature", "geometry": _linestring(), "properties": {"type": "geluidsscherm"}},
    ]
    assert filter_screens(features) == []


# ---------------------------------------------------------------------------
# tag_all
# ---------------------------------------------------------------------------


def test_tag_all_tags_every_feature_and_preserves_geometry() -> None:
    features = [
        {"type": "Feature", "geometry": _polygon(), "properties": {"type": "dek"}},
        {"type": "Feature", "geometry": _point(), "properties": {}},
    ]
    out = tag_all(features, ASSET_TYPE_BRIDGE)
    assert len(out) == 2
    assert all(f["properties"]["assetType"] == ASSET_TYPE_BRIDGE for f in out)
    # Original properties + geometry are preserved.
    assert out[0]["properties"]["type"] == "dek"
    assert {f["geometry"]["type"] for f in out} == {"Polygon", "Point"}


# ---------------------------------------------------------------------------
# fetch_bgt_assets — NL path with stubbed OGC client
# ---------------------------------------------------------------------------


def test_fetch_bgt_assets_skips_outside_nl() -> None:
    fc, stats = fetch_bgt_assets(_PARIS_BBOX)
    assert stats["source"] == "skipped"
    assert stats["total"] == 0
    assert stats["bridge"] == 0
    assert stats["tunnel"] == 0
    assert stats["bak"] == 0
    assert stats["sidewalk"] == 0
    assert stats["bikePath"] == 0
    assert stats["trafficIsland"] == 0
    assert fc["features"] == []


def test_fetch_bgt_assets_returns_all_asset_types(monkeypatch) -> None:
    def _fake_fetch(collection: str, _bbox: list[float], **_kwargs) -> list[dict]:
        if collection == COLLECTION_WEGDEEL:
            return [
                {
                    "type": "Feature",
                    "geometry": _polygon(),
                    "properties": {"plus_functie": "verkeersdrempel"},
                },
                {
                    "type": "Feature",
                    "geometry": _polygon(0.02),
                    "properties": {"functie": "rijbaan lokale weg"},
                },
                {
                    "type": "Feature",
                    "geometry": _polygon(0.04),
                    "properties": {"functie": "voetpad"},
                },
                {
                    "type": "Feature",
                    "geometry": _polygon(0.06),
                    "properties": {"functie": "fietspad"},
                },
                {
                    "type": "Feature",
                    "geometry": _polygon(0.08),
                    "properties": {"functie": "verkeerseiland"},
                },
            ]
        if collection == COLLECTION_SCHEIDING_LIJN:
            return [
                {
                    "type": "Feature",
                    "geometry": _linestring(),
                    "properties": {"type": "hek", "plus_type": "geluidsscherm"},
                },
                {
                    "type": "Feature",
                    "geometry": _linestring(0.02),
                    "properties": {"type": "hek", "plus_type": None},
                },
            ]
        if collection == COLLECTION_SCHEIDING_VLAK:
            return [
                {
                    "type": "Feature",
                    "geometry": _polygon(),
                    "properties": {"type": "muur", "plus_type": "geluidsscherm"},
                },
            ]
        if collection == COLLECTION_OVERBRUGGINGSDEEL:
            return [
                {
                    "type": "Feature",
                    "geometry": _polygon(),
                    "properties": {"type_overbruggingsdeel": "dek"},
                },
            ]
        if collection == COLLECTION_TUNNELDEEL:
            return [
                {"type": "Feature", "geometry": _polygon(), "properties": {}},
                {"type": "Feature", "geometry": _polygon(0.02), "properties": {}},
            ]
        assert collection == COLLECTION_BAK
        return [
            {
                "type": "Feature",
                "geometry": _point(),
                "properties": {"plus_type": "zand- / zoutbak"},
            },
        ]

    monkeypatch.setattr("gmt_shared.ogc_features.fetch_collection_items", _fake_fetch, raising=True)

    fc, stats = fetch_bgt_assets(_NL_BBOX)
    assert stats["source"] == "BGT"
    assert stats["speedBump"] == 1
    assert stats["sidewalk"] == 1
    assert stats["bikePath"] == 1
    assert stats["trafficIsland"] == 1
    assert stats["screen"] == 2
    assert stats["bridge"] == 1
    assert stats["tunnel"] == 2
    assert stats["bak"] == 1
    assert stats["total"] == 10
    assert fc["properties"]["_qv"] == BGT_QUERY_VER
    from collections import Counter

    counts = Counter(f["properties"]["assetType"] for f in fc["features"])
    assert counts == {
        ASSET_TYPE_SPEED_BUMP: 1,
        ASSET_TYPE_SIDEWALK: 1,
        ASSET_TYPE_BIKE_PATH: 1,
        ASSET_TYPE_TRAFFIC_ISLAND: 1,
        ASSET_TYPE_SCREEN: 2,
        ASSET_TYPE_BRIDGE: 1,
        ASSET_TYPE_TUNNEL: 2,
        ASSET_TYPE_BAK: 1,
    }
