"""Diurnal splitter - splits a daily traffic total into Lden day-part intensities.

This is phase A of the noise model.  Road-traffic noise indicators (Lden /
Lnight) require the hourly traffic intensity in three standard EU periods:

    day     07-19 h  (12 h)
    evening 19-23 h  (4 h)
    night   23-07 h  (8 h)

The network links only carry a 24-hour total (``flow24hrs``).  Rather than
reusing the ``mrh``/``erh``/``rest`` day-parts (which cover different, partly
overlapping windows than the Lden periods), we apply a fixed, calibratable
diurnal profile that distributes the daily total over the three Lden periods
and converts each to a per-hour intensity.

Public API
----------
NOISE_DIURNAL_PROFILE: dict[str, float]
    Fraction of the daily total in each period (sums to 1.0).  Calibratable.
NOISE_PERIOD_HOURS: dict[str, float]
    Number of hours in each Lden period.
split_daily_flow(flow24hrs) -> dict[str, float]
    Return ``{day, evening, night}`` hourly intensities (vehicles/hour).
"""

from __future__ import annotations

#: Fraction of the 24-hour traffic total assigned to each Lden period.
#: Calibratable starting values; must sum to 1.0.
NOISE_DIURNAL_PROFILE: dict[str, float] = {"day": 0.65, "evening": 0.20, "night": 0.15}

#: Number of hours in each Lden period (day 07-19, evening 19-23, night 23-07).
NOISE_PERIOD_HOURS: dict[str, float] = {"day": 12.0, "evening": 4.0, "night": 8.0}


def split_daily_flow(flow24hrs: float) -> dict[str, float]:
    """Split *flow24hrs* into per-hour intensities for the three Lden periods.

    Parameters
    ----------
    flow24hrs:
        Total number of vehicles over the whole 24-hour day.

    Returns
    -------
    dict with keys ``day``, ``evening``, ``night``.  Each value is the mean
    hourly intensity (vehicles/hour) for that period:
    ``flow24hrs * fraction / hours_in_period``.  A non-positive daily total
    yields all-zero intensities.
    """
    if flow24hrs <= 0.0:
        return {"day": 0.0, "evening": 0.0, "night": 0.0}

    return {
        period: flow24hrs * NOISE_DIURNAL_PROFILE[period] / NOISE_PERIOD_HOURS[period]
        for period in ("day", "evening", "night")
    }
