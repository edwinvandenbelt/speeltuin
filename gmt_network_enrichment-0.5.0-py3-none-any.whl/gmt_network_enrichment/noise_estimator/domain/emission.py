"""Emission model - per-link road-traffic noise emission in dB(A).

This is phase A of the noise model: a simplified, calibratable SRM-I / RMG2012
style emission (source power) for light vehicles only.  It deliberately does
*not* model propagation, shielding or reflection - that is phase B.

Emission per Lden period:

    LE = C0 + 10*log10(Q) + Cv*log10(v / Vref) + Csurface + Cheavy

where ``Q`` is the per-hour traffic intensity (vehicles/hour) and ``v`` the
speed (km/h).  In this phase the surface and heavy-vehicle terms are hooks
that are held at 0 (light vehicles only, no surface correction).

The Lden indicator combines the three period emissions with the standard
evening (+5 dB) and night (+10 dB) penalties; Lnight is the night emission.

Public API
----------
NOISE_EMISSION_COEFFS: dict[str, float]
    Calibratable emission coefficients (env-overridable, plausible defaults).
NOISE_MIN_FLOW: float
    Per-hour intensity below which a period produces no emission (``None``).
EVENING_PENALTY_DB / NIGHT_PENALTY_DB: float
    Lden penalties per period.
emission_db(q_hourly, speed) -> float | None
    Emission level in dB(A) for one period, or ``None`` below the threshold.
combine_lden(l_day, l_evening, l_night) -> float | None
    Combine the three period emissions into a single Lden value.
"""

from __future__ import annotations

import math
import os

# ---------------------------------------------------------------------------
# Calibratable emission coefficients
# ---------------------------------------------------------------------------
#
# Values are read from the environment (so they can be tuned via the .env file
# used by the runner / notebook / server) and fall back to plausible defaults
# derived from a simplified light-vehicle RMG2012 / SRM-I emission:
#
#   NOISE_EMISSION_C0        base level in dB(A)                  (default 41.0)
#   NOISE_EMISSION_CV        speed slope (RMG2012 light vehicle)  (default 27.6)
#   NOISE_EMISSION_VREF      reference speed in km/h              (default 70.0)
#   NOISE_EMISSION_CSURFACE  road-surface correction (dB)         (default 0.0)
#   NOISE_EMISSION_CHEAVY    heavy-vehicle correction (dB)        (default 0.0)
#   NOISE_MIN_FLOW           silence threshold in vehicles/hour   (default 0.5)
#
# The surface and heavy-vehicle terms are calibration hooks; in phase A
# (light vehicles, no surface correction) they default to 0.


def _env_float(name: str, default: float) -> float:
    """Read *name* from the environment as a float, falling back to *default*."""
    raw = os.environ.get(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return float(raw)
    except ValueError:
        return default


#: Calibratable emission coefficients (env-overridable, plausible defaults).
NOISE_EMISSION_COEFFS: dict[str, float] = {
    "C0": _env_float("NOISE_EMISSION_C0", 41.0),
    "Cv": _env_float("NOISE_EMISSION_CV", 27.6),
    "Vref": _env_float("NOISE_EMISSION_VREF", 70.0),
    "Csurface": _env_float("NOISE_EMISSION_CSURFACE", 0.0),
    "Cheavy": _env_float("NOISE_EMISSION_CHEAVY", 0.0),
}

#: Per-hour intensity (vehicles/hour) below which a period yields no emission.
NOISE_MIN_FLOW: float = _env_float("NOISE_MIN_FLOW", 0.5)

#: Lden period penalties in dB.
EVENING_PENALTY_DB: float = 5.0
NIGHT_PENALTY_DB: float = 10.0


def emission_db(q_hourly: float, speed: float) -> float | None:
    """Return the road-traffic noise emission for one period in dB(A).

    Parameters
    ----------
    q_hourly:
        Per-hour traffic intensity (vehicles/hour) for the period.
    speed:
        Representative speed on the link (km/h).

    Returns
    -------
    Emission level in dB(A), rounded to 1 decimal, or ``None`` when the
    intensity is at or below :data:`NOISE_MIN_FLOW` (no meaningful source) or
    the speed is non-positive.
    """
    if q_hourly <= NOISE_MIN_FLOW or speed <= 0.0:
        return None

    coeffs = NOISE_EMISSION_COEFFS
    level = (
        coeffs["C0"]
        + 10.0 * math.log10(q_hourly)
        + coeffs["Cv"] * math.log10(speed / coeffs["Vref"])
        + coeffs["Csurface"]
        + coeffs["Cheavy"]
    )
    return round(level, 1)


def combine_lden(
    l_day: float | None,
    l_evening: float | None,
    l_night: float | None,
) -> float | None:
    """Combine period emissions into a single Lden value in dB(A).

    Uses the standard energy-weighted combination with a +5 dB evening and
    +10 dB night penalty:

        Lden = 10*log10( (12*10^(Lday/10)
                          + 4*10^((Leve+5)/10)
                          + 8*10^((Lnight+10)/10)) / 24 )

    ``None`` period emissions contribute no acoustic energy.  Returns ``None``
    when all three periods are silent.
    """
    energy = 0.0
    if l_day is not None:
        energy += 12.0 * 10.0 ** (l_day / 10.0)
    if l_evening is not None:
        energy += 4.0 * 10.0 ** ((l_evening + EVENING_PENALTY_DB) / 10.0)
    if l_night is not None:
        energy += 8.0 * 10.0 ** ((l_night + NIGHT_PENALTY_DB) / 10.0)

    if energy <= 0.0:
        return None
    return round(10.0 * math.log10(energy / 24.0), 1)
