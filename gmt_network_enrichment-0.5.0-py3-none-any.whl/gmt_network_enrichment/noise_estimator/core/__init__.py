# src/noise_estimator/core/__init__.py
