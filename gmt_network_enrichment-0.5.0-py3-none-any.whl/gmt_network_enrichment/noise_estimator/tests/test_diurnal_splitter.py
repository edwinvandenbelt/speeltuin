"""Unit tests for noise_estimator.domain.diurnal_splitter."""

from __future__ import annotations

import pytest

from gmt_network_enrichment.noise_estimator.domain.diurnal_splitter import (
    NOISE_DIURNAL_PROFILE,
    NOISE_PERIOD_HOURS,
    split_daily_flow,
)


def test_profile_fractions_sum_to_one() -> None:
    assert sum(NOISE_DIURNAL_PROFILE.values()) == pytest.approx(1.0)


def test_periods_cover_24_hours() -> None:
    assert sum(NOISE_PERIOD_HOURS.values()) == pytest.approx(24.0)


def test_zero_flow_yields_zero_intensities() -> None:
    assert split_daily_flow(0.0) == {"day": 0.0, "evening": 0.0, "night": 0.0}
    assert split_daily_flow(-5.0) == {"day": 0.0, "evening": 0.0, "night": 0.0}


def test_hourly_intensity_matches_profile() -> None:
    out = split_daily_flow(2400.0)
    # day: 2400 * 0.65 / 12 = 130.0
    assert out["day"] == pytest.approx(2400.0 * 0.65 / 12.0)
    # evening: 2400 * 0.20 / 4 = 120.0
    assert out["evening"] == pytest.approx(2400.0 * 0.20 / 4.0)
    # night: 2400 * 0.15 / 8 = 45.0
    assert out["night"] == pytest.approx(2400.0 * 0.15 / 8.0)


def test_keys_present() -> None:
    out = split_daily_flow(1000.0)
    assert set(out) == {"day", "evening", "night"}
