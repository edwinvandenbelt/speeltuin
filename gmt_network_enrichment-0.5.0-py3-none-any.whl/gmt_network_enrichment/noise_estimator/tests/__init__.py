"""Unit tests for the noise_estimator module."""
