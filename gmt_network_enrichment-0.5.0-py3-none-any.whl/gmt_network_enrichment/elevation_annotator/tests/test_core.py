"""Unit tests for elevation_annotator_core — pure functions, no network I/O."""

from __future__ import annotations

import gmt_network_enrichment.elevation_annotator.core.elevation_annotator_core as core_mod
from gmt_network_enrichment.elevation_annotator.core.elevation_annotator_core import add_elevation

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features), "properties": {}}


def _make_link(coords: list[list[float]]) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {},
    }


class _FakeElevations:
    """Callable stub replacing shared.elevation.fetch_elevations.

    Maps each ``(lat, lon)`` to a supplied elevation (or ``None``), records the
    coordinates it was called with, and returns a parallel list.
    """

    def __init__(self, mapping: dict[tuple[float, float], float | None]) -> None:
        self.mapping = mapping
        self.calls: list[list[tuple[float, float]]] = []

    def __call__(
        self,
        coords,
        *,
        url=None,  # noqa: ARG002
        batch_size=100,  # noqa: ARG002
        timeout=30,  # noqa: ARG002
        retries=8,  # noqa: ARG002
        pause=2.0,  # noqa: ARG002
    ):
        self.calls.append(list(coords))
        return [self.mapping.get((round(lat, 6), round(lon, 6))) for lat, lon in coords]


def _patch(monkeypatch, mapping):
    fake = _FakeElevations(mapping)
    monkeypatch.setattr(core_mod, "fetch_elevations", fake)
    return fake


# ---------------------------------------------------------------------------
# Basic annotation
# ---------------------------------------------------------------------------


def test_sets_elevation_from_and_to(monkeypatch) -> None:
    link = _make_link([[6.0, 52.0], [6.1, 52.1]])
    fc = _make_fc(link)
    _patch(monkeypatch, {(52.0, 6.0): 10.0, (52.1, 6.1): 25.0})

    out, stats = add_elevation(fc)

    props = out["features"][0]["properties"]
    assert props["elevationFrom"] == 10.0
    assert props["elevationTo"] == 25.0
    assert stats == {"links": 1, "nodes": 2, "resolved": 2, "updated": 1}


def test_direction_correct_on_reversed_link(monkeypatch) -> None:
    forward = _make_link([[6.0, 52.0], [6.1, 52.1]])
    reverse = _make_link([[6.1, 52.1], [6.0, 52.0]])
    fc = _make_fc(forward, reverse)
    _patch(monkeypatch, {(52.0, 6.0): 10.0, (52.1, 6.1): 25.0})

    out, _ = add_elevation(fc)

    fwd = out["features"][0]["properties"]
    rev = out["features"][1]["properties"]
    assert (fwd["elevationFrom"], fwd["elevationTo"]) == (10.0, 25.0)
    assert (rev["elevationFrom"], rev["elevationTo"]) == (25.0, 10.0)


def test_endpoints_deduplicated(monkeypatch) -> None:
    # Two links share the middle node (6.1, 52.1): 3 unique nodes, not 4.
    a = _make_link([[6.0, 52.0], [6.1, 52.1]])
    b = _make_link([[6.1, 52.1], [6.2, 52.2]])
    fc = _make_fc(a, b)
    fake = _patch(monkeypatch, {(52.0, 6.0): 1.0, (52.1, 6.1): 2.0, (52.2, 6.2): 3.0})

    _, stats = add_elevation(fc)

    assert stats["nodes"] == 3
    assert len(fake.calls) == 1
    assert len(fake.calls[0]) == 3


def test_unresolved_node_yields_none(monkeypatch) -> None:
    link = _make_link([[6.0, 52.0], [6.1, 52.1]])
    fc = _make_fc(link)
    _patch(monkeypatch, {(52.0, 6.0): 10.0, (52.1, 6.1): None})

    out, stats = add_elevation(fc)

    props = out["features"][0]["properties"]
    assert props["elevationFrom"] == 10.0
    assert props["elevationTo"] is None
    assert stats["resolved"] == 1
    assert stats["updated"] == 1


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------


def test_empty_feature_collection(monkeypatch) -> None:
    fake = _patch(monkeypatch, {})
    out, stats = add_elevation(_make_fc())
    assert out["features"] == []
    assert stats == {"links": 0, "nodes": 0, "resolved": 0, "updated": 0}
    assert fake.calls == []


def test_short_geometry_sets_none(monkeypatch) -> None:
    short = _make_link([[6.0, 52.0]])
    fc = _make_fc(short)
    fake = _patch(monkeypatch, {})

    out, stats = add_elevation(fc)

    props = out["features"][0]["properties"]
    assert props["elevationFrom"] is None
    assert props["elevationTo"] is None
    assert stats == {"links": 1, "nodes": 0, "resolved": 0, "updated": 0}
    assert fake.calls == []


def test_elevation_url_passed_through(monkeypatch) -> None:
    captured: dict = {}

    def _fake(coords, *, url=None, batch_size=100, timeout=30, retries=8, pause=2.0):
        captured["url"] = url
        captured["retries"] = retries
        captured["pause"] = pause
        return [1.0 for _ in coords]

    monkeypatch.setattr(core_mod, "fetch_elevations", _fake)
    fc = _make_fc(_make_link([[6.0, 52.0], [6.1, 52.1]]))

    add_elevation(
        fc,
        elevation_url="https://example.test/elevation",
        retries=12,
        pause=5.0,
    )

    assert captured["url"] == "https://example.test/elevation"
    assert captured["retries"] == 12
    assert captured["pause"] == 5.0
