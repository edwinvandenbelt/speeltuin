"""Unit tests for wkd_fetcher core — pure Python, no Databricks I/O."""

from __future__ import annotations

from gmt_network_enrichment.wkd_fetcher.core.wkd_fetcher_core import (
    apply_wkd_road_widths,
    match_wkd_features_to_network,
    rows_to_wkd_features,
)
from gmt_network_enrichment.wkd_fetcher.domain.sql import build_wegbreedtes_sql


class TestBuildWegbreedtesSql:
    def test_returns_parameterised_sql(self):
        sql = build_wegbreedtes_sql("nwb", "2026_01_jaarlijks")
        assert "wkd_wegbrdtv2" in sql
        assert "nwb.`2026_01_jaarlijks`" in sql
        assert "ST_AsGeoJSON" in sql
        assert "?" in sql

    def test_uses_defaults(self):
        sql = build_wegbreedtes_sql()
        assert "nwb.`2026_01_jaarlijks`" in sql


class TestRowsToWkdFeatures:
    def test_builds_features_and_parses_numeric_strings(self):
        rows = [
            (
                1001,
                0,
                500,
                "6.0",
                "5.0",
                "7.0",
                "goed",
                '{"type":"LineString","coordinates":[[0,0],[1,1]]}',
            ),
            (
                1002,
                0,
                200,
                "3,5",
                None,
                "4,0",
                None,
                '{"type":"LineString","coordinates":[[1,1],[2,2]]}',
            ),
        ]
        cols = ["WVK_ID", "VAN", "TOT", "BREEDTE", "BRDT_MIN", "BRDT_MAX", "BETR", "geom"]
        features = rows_to_wkd_features(rows, cols)

        assert len(features) == 2
        assert features[0]["properties"]["wvkId"] == 1001
        assert features[0]["properties"]["span"] == 500
        assert features[0]["properties"]["width"] == 6.0
        assert features[0]["properties"]["minWidth"] == 5.0
        assert features[0]["properties"]["maxWidth"] == 7.0
        assert features[0]["properties"]["reliability"] == "goed"

        assert features[1]["properties"]["width"] == 3.5
        assert features[1]["properties"]["minWidth"] is None
        assert features[1]["properties"]["maxWidth"] == 4.0
        assert features[1]["properties"]["reliability"] is None

    def test_skips_rows_without_geometry(self):
        rows = [(1003, 0, 100, "3.0", None, None, None, None)]
        cols = ["WVK_ID", "VAN", "TOT", "BREEDTE", "BRDT_MIN", "BRDT_MAX", "BETR", "geom"]
        features = rows_to_wkd_features(rows, cols)
        assert features == []


class TestMatchWkdFeaturesToNetwork:
    def _network(self, coords):
        return {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": coords},
                    "properties": {"linkId": 1, "mode": "CAR"},
                }
            ],
        }

    def test_matches_overlapping_wkd_segment(self):
        network_fc = self._network([[0.0, 0.0], [0.0001, 0.0]])  # ~11 m
        wkd_features = [
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [0.0001, 0.0]]},
                "properties": {
                    "wvkId": 9001,
                    "span": 100,
                    "width": 6.0,
                    "minWidth": 5.0,
                    "maxWidth": 7.0,
                    "reliability": "goed",
                },
            }
        ]
        lookup = match_wkd_features_to_network(wkd_features, network_fc, max_distance_m=15.0)
        assert lookup[1]["width"] == 6.0
        assert lookup[1]["minWidth"] == 5.0
        assert lookup[1]["maxWidth"] == 7.0
        assert lookup[1]["reliability"] == "goed"
        assert lookup[1]["wvkIds"] == [9001]

    def test_ignores_distant_wkd_segment(self):
        network_fc = self._network([[0.0, 0.0], [0.0001, 0.0]])
        wkd_features = [
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.0, 0.1], [0.0001, 0.1]]},
                "properties": {
                    "wvkId": 9002,
                    "span": 100,
                    "width": 6.0,
                },
            }
        ]
        lookup = match_wkd_features_to_network(wkd_features, network_fc, max_distance_m=15.0)
        assert lookup == {}

    def test_collects_multiple_wvk_ids_per_link(self):
        network_fc = self._network([[0.0, 0.0], [0.0002, 0.0]])  # ~22 m
        wkd_features = [
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [0.0001, 0.0]]},
                "properties": {"wvkId": 9001, "span": 100, "width": 6.0},
            },
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[0.0001, 0.0], [0.0002, 0.0]]},
                "properties": {"wvkId": 9002, "span": 200, "width": 7.0},
            },
        ]
        lookup = match_wkd_features_to_network(wkd_features, network_fc, max_distance_m=15.0)
        # Largest span wins for width.
        assert lookup[1]["width"] == 7.0
        assert lookup[1]["wvkIds"] == [9001, 9002]


class TestApplyWkdRoadWidths:
    def test_enriches_matching_car_and_bike_links_and_sets_wvkids(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
                    "properties": {"linkId": 1, "mode": "CAR"},
                },
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[1, 1], [2, 2]]},
                    "properties": {"linkId": 2, "mode": "BIKE"},
                },
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[2, 2], [3, 3]]},
                    "properties": {"linkId": 3, "mode": "CAR"},
                },
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[3, 3], [4, 4]]},
                    "properties": {"linkId": 4, "mode": "PEDESTRIAN"},
                },
            ],
        }
        lookup = {
            1: {
                "width": 6.0,
                "minWidth": 5.0,
                "maxWidth": 7.0,
                "reliability": "goed",
                "wvkIds": [9001],
            },
            2: {
                "width": 3.0,
                "minWidth": 2.5,
                "maxWidth": 3.5,
                "reliability": "matig",
                "wvkIds": [9002],
            },
        }
        result = apply_wkd_road_widths(network_fc, lookup)

        car = result["features"][0]["properties"]
        assert car["roadWidthM"] == 6.0
        assert car["roadWidthMinM"] == 5.0
        assert car["roadWidthMaxM"] == 7.0
        assert car["roadWidthReliability"] == "goed"
        assert car["wvkIds"] == [9001]

        bike = result["features"][1]["properties"]
        assert bike["roadWidthM"] == 3.0
        assert bike["wvkIds"] == [9002]

        unmatched = result["features"][2]["properties"]
        assert "roadWidthM" not in unmatched
        assert "wvkIds" not in unmatched

        pedestrian = result["features"][3]["properties"]
        assert "roadWidthM" not in pedestrian
        assert "wvkIds" not in pedestrian

    def test_extends_existing_wvkids(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
                    "properties": {"linkId": 1, "mode": "CAR", "wvkIds": [9001]},
                }
            ],
        }
        lookup = {1: {"width": 6.0, "wvkIds": [9002, 9003]}}
        result = apply_wkd_road_widths(network_fc, lookup)
        assert result["features"][0]["properties"]["wvkIds"] == [9001, 9002, 9003]

    def test_returns_empty_lookup_unchanged(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
                    "properties": {"linkId": 1, "mode": "CAR"},
                }
            ],
        }
        result = apply_wkd_road_widths(network_fc, {})
        assert "roadWidthM" not in result["features"][0]["properties"]
