"""SQL construction for WKD (NDW Wegkenmerkendatabase) fetcher — no I/O, no boto3."""

from __future__ import annotations

#: Default Unity Catalog / schema for the NWB/WKD tables.
DEFAULT_CATALOG: str = "nwb"
DEFAULT_SCHEMA: str = "2026_01_jaarlijks"

#: WKD Wegbreedtes table name.
WEGBREEDTES_TABLE: str = "wkd_wegbrdtv2"


def build_wegbreedtes_sql(catalog: str = DEFAULT_CATALOG, schema: str = DEFAULT_SCHEMA) -> str:
    """Return parameterised SQL that fetches WKD road widths for a bbox.

    Parameters
    ----------
    catalog:
        Unity Catalog name.  Defaults to ``"nwb"``.
    schema:
        Schema / dataset version.  Defaults to ``"2026_01_jaarlijks"``.

    The returned SQL has a single ``?`` placeholder for a GeoJSON polygon
    string in WGS-84 (EPSG:4326).  Results are keyed by ``WVK_ID`` and the
    linear-reference offsets ``VAN`` / ``TOT``.

    Selected columns
    ----------------
    - ``WVK_ID`` — NWB road segment identifier.
    - ``VAN`` / ``TOT`` — start/end offset on the segment (cm).
    - ``BREEDTE`` — median road width (m).
    - ``BRDT_MIN`` — minimum road width (m).
    - ``BRDT_MAX`` — maximum road width (m).
    - ``BETR`` — reliability class / code.
    """
    db = f"{catalog}.`{schema}`"
    return f"""\
SELECT CAST(WVK_ID AS BIGINT)      AS WVK_ID,
       VAN,
       TOT,
       BREEDTE,
       BRDT_MIN,
       BRDT_MAX,
       BETR,
       ST_AsGeoJSON(ST_Transform(geom_28992, 4326)) AS geom
FROM   {db}.{WEGBREEDTES_TABLE}
WHERE  ST_Intersects(
           geom_28992,
           ST_Transform(ST_GeomFromGeoJSON(?), 28992)
       )"""
