"""Pure-Python nvp_mapper core — no I/O, no boto3, no external deps beyond numpy.

Maps NVP (Nationale Verkeersprestatie) GPS trip IDs onto directed Spectrum network
links by spatial sub-link matching and writes the result to a Parquet file.

The NETWORK GeoJSON is used **read-only** for spatial geometry; it is never
modified by this module.

Public API
----------
map_nvp_trips(network, nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys,
              linktrips1, **kwargs)
    Return ``(stats, match_rows)`` where:

    - *stats* is a summary dict.
    - *match_rows* is a list of ``{"linkId", "nvpLinkIds", "nvpTripIds"}`` dicts —
      one row per matched Spectrum link, suitable for writing to a Parquet file.
"""

from __future__ import annotations

import logging
import math
from concurrent.futures import ThreadPoolExecutor

try:
    import numpy as np
except ImportError as _np_err:
    raise ImportError(
        "numpy is required for nvp_mapper. Install it with: pip install numpy"
    ) from _np_err

from shared.rd_projection import wgs84_to_rd

from nvp_mapper.domain.matching import (
    add_inbetween_sublinks,
    add_missing_sublinks,
    get_mapped_segments,
    get_sublinks,
    get_trips_per_link,
    get_unmapped_segments,
    get_vertices,
    map1to2,
    mapped_with_overlap,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal: extract Spectrum link data from NETWORK GeoJSON in RD New metres
# ---------------------------------------------------------------------------


def _get_spectrum_links_rd(
    network: dict,
) -> tuple[list, list[float], list[list[list[float]]]]:
    """Extract (link_ids, lengths_m, xys_rd) from a directed NETWORK GeoJSON.

    Coordinates are projected from WGS-84 to RD New (EPSG:28992) via
    ``shared.rd_projection.wgs84_to_rd`` so that distances are in metres.

    Features without a ``linkId`` or with fewer than 2 coordinate pairs are
    silently skipped.
    """
    links: list = []
    lengths: list[float] = []
    xys: list[list[list[float]]] = []

    for feature in network.get("features") or []:
        props = feature.get("properties") or {}
        geom  = feature.get("geometry") or {}
        if not geom:
            continue

        link_id = props.get("linkId")
        if link_id is None:
            continue

        coords_wgs84 = geom.get("coordinates") or []
        if len(coords_wgs84) < 2:
            continue

        coords_rd = [list(wgs84_to_rd(c[0], c[1])) for c in coords_wgs84]

        # Use the stored length when available (already in metres for RD network)
        raw_len = props.get("length")
        if raw_len is not None and float(raw_len) > 0:
            length = float(raw_len)
        else:
            length = sum(
                math.hypot(
                    coords_rd[j + 1][0] - coords_rd[j][0],
                    coords_rd[j + 1][1] - coords_rd[j][1],
                )
                for j in range(len(coords_rd) - 1)
            )

        links.append(link_id)
        lengths.append(length)
        xys.append(coords_rd)

    return links, lengths, xys


# ---------------------------------------------------------------------------
# Internal: build per-spectrum-link rows for Parquet output
# ---------------------------------------------------------------------------


def build_nvp_match_rows(
    nvpmatch: dict,
    nvp_links: np.ndarray,
    linktrips1: dict,
    linktrips: dict,
    links2: np.ndarray,
) -> list[dict]:
    """Build one Parquet row per matched Spectrum link.

    Each row aggregates all NVP links and all accepted trip IDs that were
    matched to a single Spectrum link.

    Parameters
    ----------
    nvpmatch:
        Output of :func:`~nvp_mapper.domain.matching.get_mapped_segments`.
    nvp_links:
        NVP link tuple array, shape ``(N, 3)`` — rows are
        ``(nodeId, next_nodeId, pairindex)``.
    linktrips1:
        Dict mapping ``(nodeId, next_nodeId, pairindex)`` → list of trip IDs.
    linktrips:
        Output of :func:`~nvp_mapper.domain.matching.get_trips_per_link` —
        maps ``spectrum_link_id (int)`` → ``ndarray`` of accepted trip IDs.
    links2:
        Spectrum link ID array, shape ``(N2,)``.

    Returns
    -------
    list[dict]
        One dict per Spectrum link that has at least one accepted NVP match.
        Each dict has keys:

        - ``"linkId"``     — Spectrum link ID (``int``)
        - ``"nvpLinkIds"`` — ordered list of NVP link ID strings
          ``"fromNode_toNode_pairIndex"`` (one entry per unique NVP link)
        - ``"nvpTripIds"`` — sorted list of all accepted trip ID strings
    """
    rows: list[dict] = []
    for ilink2, segments in nvpmatch.items():
        spectrum_link_id = int(links2[ilink2])
        accepted_trips = sorted({str(t) for t in linktrips.get(spectrum_link_id, [])})
        if not accepted_trips:
            continue

        # Collect all unique NVP link IDs in encounter order
        seen: set = set()
        nvp_link_ids: list[str] = []
        for segment_nvp_indices in segments:
            for ilink1 in segment_nvp_indices:
                if ilink1 == -1:
                    continue
                nvp_key = tuple(int(v) for v in nvp_links[ilink1])
                if nvp_key in seen:
                    continue
                seen.add(nvp_key)
                nvp_link_ids.append(f"{nvp_key[0]}_{nvp_key[1]}_{nvp_key[2]}")

        if nvp_link_ids:
            rows.append({
                "linkId":     spectrum_link_id,
                "nvpLinkIds": nvp_link_ids,
                "nvpTripIds": accepted_trips,
            })
    return rows


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def map_nvp_trips(
    network: dict,
    nvp_links: np.ndarray,
    nvp_vertlengths: np.ndarray,
    nvp_vertxys: np.ndarray,
    nvp_vertdxys: np.ndarray,
    linktrips1: dict,
    *,
    maxlength_sublink: float = 5.0,
    maxdist: float = 20.0,
    maxalpha_forward1: float = 15.0,
    maxalpha_forward2: float = 45.0,
    maxalpha_backward: float = 30.0,
    fmatch12: float = 0.5,
    nnb: int = 20,
) -> tuple[dict, list[dict]]:
    """Map NVP trip IDs onto Spectrum network links by spatial sub-link matching.

    The NETWORK GeoJSON is used **read-only** for geometry.  No fields are
    added to any feature — all output is in *match_rows*.

    The matching algorithm:

    1. Decomposes both networks into sub-links of ≤ *maxlength_sublink* metres.
    2. Forward pass (tight angle *maxalpha_forward1*): NVP → Spectrum.
    3. Forward pass (wide angle *maxalpha_forward2*): remaining NVP sub-links.
    4. Backward pass (*maxalpha_backward*): Spectrum → NVP for validation.
    5. Overlap filter: keeps only matches where ≥ *fmatch12* of either link
       is covered.
    6. Gap filling: inserts in-between and missing sub-links.
    7. Segment derivation and NVP trip aggregation per Spectrum link.
    8. Builds one Parquet row per matched Spectrum link.

    All spatial operations use RD New (EPSG:28992) metres.  NETWORK features
    are projected internally from WGS-84; NVP geometry must be pre-projected
    (as returned by ``domain.sql.get_links_nvp``).

    Parameters
    ----------
    network:
        Directed NETWORK GeoJSON FeatureCollection (WGS-84).  Read-only.
    nvp_links:
        NVP link tuple array, shape ``(N, 3)`` — rows are
        ``(nodeId, next_nodeId, pairindex)``.
    nvp_vertlengths:
        NVP link lengths in RD metres, shape ``(N,)``.
    nvp_vertxys:
        NVP link start-point coordinates in RD metres, shape ``(N, 2)``.
    nvp_vertdxys:
        NVP link unit direction vectors, shape ``(N, 2)``.
    linktrips1:
        Dict mapping ``(nodeId, next_nodeId, pairindex)`` → list of trip IDs.
    maxlength_sublink:
        Maximum sub-link length for spatial decomposition (metres, default 5).
    maxdist:
        Maximum perpendicular distance for a valid match (metres, default 20).
    maxalpha_forward1:
        Tight angular threshold for forward pass 1 (degrees, default 15).
    maxalpha_forward2:
        Wide angular threshold for forward pass 2 (degrees, default 45).
    maxalpha_backward:
        Angular threshold for backward validation pass (degrees, default 30).
    fmatch12:
        Minimum overlap fraction to accept a match (default 0.5 = 50 %).
    nnb:
        Number of nearest neighbours in the k-d tree query (default 20).

    Returns
    -------
    stats : dict
        ``{"spectrum_links": int, "nvp_links": int,
           "matched_links": int, "match_rows": int}``
    match_rows : list[dict]
        One dict per matched Spectrum link with keys ``"linkId"`` (int),
        ``"nvpLinkIds"`` (list[str]), ``"nvpTripIds"`` (list[str]).
        Empty list when no matches were found.
    """
    logger.info("map_nvp_trips: starting")

    # ------------------------------------------------------------------
    # 1. Build Spectrum sub-link arrays from the NETWORK GeoJSON (RD New)
    # ------------------------------------------------------------------
    links2_raw, linklengths2, xys2_rd = _get_spectrum_links_rd(network)
    if not links2_raw:
        logger.warning("No Spectrum links found in NETWORK GeoJSON — nothing to map.")
        return {
            "spectrum_links": 0,
            "nvp_links": int(len(nvp_links)),
            "matched_links": 0,
            "match_rows": 0,
        }, []

    links2 = np.array(links2_raw, dtype=object)

    vertlinks2, vertlengths2, vertxys21, vertdxys2 = get_vertices(links2, xys2_rd)
    sublinks2, sublengths2, subxys2, subdxys2 = get_sublinks(
        vertlinks2, vertlengths2, vertxys21, vertdxys2, maxlength_sublink
    )

    logger.info(
        "Spectrum: %d links  %d vertices  %d sub-links",
        len(links2), len(vertlinks2), len(sublinks2),
    )

    # ------------------------------------------------------------------
    # 2. Build NVP sub-link arrays  (NVP links ARE already vertices)
    # ------------------------------------------------------------------
    if len(nvp_links) == 0:
        logger.warning("No NVP links found — returning empty match rows.")
        return {
            "spectrum_links": len(links2_raw),
            "nvp_links": 0,
            "matched_links": 0,
            "match_rows": 0,
        }, []

    # NVP links act as their own vertices; vertlinks1[i] = i
    vertlinks1 = np.arange(len(nvp_links), dtype=int)
    sublinks1, sublengths1, subxys1, subdxys1 = get_sublinks(
        vertlinks1, nvp_vertlengths, nvp_vertxys, nvp_vertdxys, maxlength_sublink
    )

    logger.info(
        "NVP: %d links  %d sub-links", len(nvp_links), len(sublinks1)
    )

    # ------------------------------------------------------------------
    # 3–5. Forward passes (sequential) + backward pass (concurrent)
    #
    # The backward pass is fully independent of both forward passes: it
    # builds a different K-D tree (NVP sub-links as data, Spectrum as
    # query), writes to a separate mapped_back array, and shares no
    # mutable state with the forward passes.  scipy's cKDTree releases
    # the GIL during its C-level build and query, so true CPU parallelism
    # is possible even with threads.
    # ------------------------------------------------------------------
    with ThreadPoolExecutor(max_workers=2) as executor:
        # Submit backward pass before forward pass 1 starts so both
        # tree-builds overlap on multi-core hardware.
        _mapped_back = np.zeros(len(sublinks2), dtype=int)
        backward_future = executor.submit(
            map1to2,
            nvp_links, sublinks2, sublinks1,
            subxys2, subxys1, subdxys2, subdxys1, _mapped_back,
            maxlength_sublink, maxdist, maxalpha_backward,
            nnb, "same", False, False,
        )

        # Forward pass 1 — tight angle (NVP → Spectrum)
        mapped = np.zeros(len(sublinks1), dtype=int)
        findex1, findex2 = map1to2(
            nvp_links, sublinks1, sublinks2,
            subxys1, subxys2, subdxys1, subdxys2, mapped,
            maxlength_sublink, maxdist, maxalpha_forward1,
            nnb, "same", False, True,
        )

        # Forward pass 2 — wider angle (sequential; reads mapped updated by pass 1)
        mapped[findex1] = 1
        addfindex1, addfindex2 = map1to2(
            nvp_links, sublinks1, sublinks2,
            subxys1, subxys2, subdxys1, subdxys2, mapped,
            maxlength_sublink, maxdist, maxalpha_forward2,
            nnb, "same", False, True,
        )
        findex1 = np.concatenate((findex1, addfindex1))
        findex2 = np.concatenate((findex2, addfindex2))

        # Collect backward pass result
        bindex2, bindex1 = backward_future.result()

    # ------------------------------------------------------------------
    # 6. Overlap filter
    # ------------------------------------------------------------------
    mapindex = mapped_with_overlap(
        findex1, findex2, bindex1, bindex2,
        sublinks1, sublinks2,
        sublengths1, sublengths2,
        nvp_vertlengths, linklengths2, fmatch12,
    )

    if len(mapindex) == 0:
        logger.warning("No matches survived overlap filter — returning empty match rows.")
        return {
            "spectrum_links": len(links2_raw),
            "nvp_links": int(len(nvp_links)),
            "matched_links": 0,
            "match_rows": 0,
        }, []

    # Replace sub-link index with NVP link index in column 0
    mapindex[:, 0] = sublinks1[mapindex[:, 0]]

    # ------------------------------------------------------------------
    # 7. Gap filling
    # ------------------------------------------------------------------
    mapindex = add_inbetween_sublinks(mapindex, sublinks2)
    mapindex = add_missing_sublinks(mapindex, sublinks2)

    # ------------------------------------------------------------------
    # 8. Segment derivation and trip aggregation
    # ------------------------------------------------------------------
    tindex, nvpmatch = get_mapped_segments(mapindex, sublinks2)
    get_unmapped_segments(tindex, nvpmatch, sublinks2)

    linktrips = get_trips_per_link(
        tindex, nvpmatch,
        nvp_links, linktrips1,
        links2, linklengths2, sublengths2,
    )

    logger.info("Mapped %d Spectrum links with NVP trips", len(nvpmatch))

    # ------------------------------------------------------------------
    # 9. Build Parquet rows — one per matched Spectrum link
    # ------------------------------------------------------------------
    match_rows = build_nvp_match_rows(nvpmatch, nvp_links, linktrips1, linktrips, links2)

    stats = {
        "spectrum_links": len(links2_raw),
        "nvp_links": int(len(nvp_links)),
        "matched_links": len(nvpmatch),
        "match_rows": len(match_rows),
    }
    logger.info(
        "Mapping complete: %d Spectrum links matched, %d Parquet rows",
        len(nvpmatch), len(match_rows),
    )
    return stats, match_rows
