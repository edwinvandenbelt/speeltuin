"""Databricks SQL queries for nvp_mapper — no I/O beyond the DB connection.

Fetches NVP (Nationale Verkeersprestatie) link geometry and trip IDs from
``nvp_experimental.silver.vw_segments`` (or any compatible table) for a given
spatial polygon, transport mode, and year.

All geometry is returned in RD New (EPSG:28992) metres so that downstream
matching can work directly in a Cartesian coordinate system.

Public API
----------
fetch_nvp(cursor, table, polygon_json, mode, year)
    Single-query fetch of NVP vertex geometry arrays (RD New metres) and trip
    ID dict.  Replaces the older two-call ``get_links_nvp`` / ``get_trips_nvp``
    pattern with one round-trip that avoids EXPLODE and leverages H3-based
    file-level skipping (the table is Z-ordered on ``node_h3_8``).
"""

from __future__ import annotations

import json
import logging
from typing import Any

try:
    import numpy as np
except ImportError as _np_err:
    raise ImportError(
        "numpy is required for nvp_mapper. Install it with: pip install numpy"
    ) from _np_err

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Transport-mode mapping  (repo convention → NVP table convention)
# ---------------------------------------------------------------------------

#: Maps repo transport-mode strings to the ``trip_mode`` values in the NVP table.
_NVP_MODE_MAP: dict[str, str] = {
    "CAR":  "Car",
    "BIKE": "Fiets",
}


def _nvp_mode(mode: str) -> str:
    """Translate a repo mode string (e.g. ``"CAR"``) to the NVP table value."""
    mapped = _NVP_MODE_MAP.get(mode.upper())
    if mapped is None:
        raise ValueError(
            f"Mode {mode!r} is not supported by nvp_mapper. "
            f"Supported modes: {', '.join(_NVP_MODE_MAP)}"
        )
    return mapped


def _bbox_from_polygon_json(polygon_json: str) -> tuple[float, float, float, float]:
    """Extract ``(minX, minY, maxX, maxY)`` from a GeoJSON Polygon string.

    Used to pass four scalar parameters to ``ST_MakeEnvelope`` instead of
    parsing the full GeoJSON string once per row with ``ST_GeomFromGeoJSON``.
    Non-rectangular polygons are reduced to their bounding envelope, which is
    the correct coarse spatial filter for nvp_mapper's use case.
    """
    coords = json.loads(polygon_json)["coordinates"][0]
    xs = [c[0] for c in coords]
    ys = [c[1] for c in coords]
    return min(xs), min(ys), max(xs), max(ys)


# ---------------------------------------------------------------------------
# Combined NVP fetch
# ---------------------------------------------------------------------------


def fetch_nvp(
    cursor: Any,
    table_nvp: str,
    polygon_json: str,
    mode: str,
    year: int,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray, dict]:
    """Fetch NVP link geometry **and** trip IDs in a single Databricks query.

    Uses an H3-based pre-filter (``h3_polyfillash3`` + ``h3_kring``) to
    exploit the Z-ordering on ``node_h3_8`` for file-level skipping before
    ``ST_Intersects`` runs.  A 1-ring buffer (``h3_kring(..., 1)``) is applied
    because ``node_h3_8`` records the **start-node** cell — segments whose
    start-node lies just outside the bbox but whose geometry still intersects
    the area would otherwise be missed.

    Trip IDs are collected as an array column (``array_distinct(flatten(
    collect_list(trip_ids)))``) in the same aggregation that produces the
    geometry, avoiding the expensive ``EXPLODE`` round-trip of the old
    ``get_trips_nvp`` approach.

    Parameters
    ----------
    cursor:
        An active ``shared.databricks_sql._Cursor`` instance.
    table_nvp:
        Fully qualified Databricks table name,
        e.g. ``"nvp_experimental.silver.vw_segments"``.
    polygon_json:
        GeoJSON Polygon geometry string used for spatial filtering,
        e.g. the AREA feature geometry from the ZONES file.
    mode:
        Repo transport mode (``"CAR"`` or ``"BIKE"``).
    year:
        ``location_year`` value to filter on (e.g. ``2025``).

    Returns
    -------
    links : ndarray, shape (N, 3)
        Rows of ``[nodeId, next_nodeId, pairindex]``.
    vertlengths : ndarray, shape (N,)
        Length of each NVP link in RD metres.
    vertxys : ndarray, shape (N, 2)
        Start-point ``[x, y]`` in RD New metres for each NVP link.
    vertdxys : ndarray, shape (N, 2)
        Unit direction vectors ``[dx, dy]`` for each NVP link.
    linktrips : dict[(nodeId, next_nodeId, pairindex), list]
        Mapping from NVP segment key to list of trip IDs.  Only valid
        (non-degenerate) segments are included; degenerate segments
        (``length_m <= 0.01``) are dropped from all five outputs.
    """
    nvp_mode = _nvp_mode(mode)
    bbox = _bbox_from_polygon_json(polygon_json)

    # bbox is passed twice: once for the H3 polyfill envelope, once for
    # ST_Intersects.  Parameter order: (*bbox, mode, year, *bbox).
    sql = f"""
    WITH bbox_h3 AS (
        SELECT DISTINCT EXPLODE(h3_kring(cell, 1)) AS h3
        FROM (
            SELECT EXPLODE(
                h3_polyfillash3(ST_SetSRID(ST_MakeEnvelope(?, ?, ?, ?), 4326), 8)
            ) AS cell
        )
    ),
    base AS (
        SELECT
            t.nodeId,
            t.next_nodeId,
            t.segment_id                                              AS pairindex,
            ST_Transform(ANY_VALUE(t.line_geom_4326), 28992)         AS g28992,
            array_distinct(flatten(collect_list(t.trip_ids)))         AS trip_ids_all
        FROM   {table_nvp} t
        JOIN   bbox_h3 ON t.node_h3_8 = bbox_h3.h3
        WHERE  t.trip_mode     = ?
          AND  t.location_year = ?
          AND  ST_Intersects(
                   t.line_geom_4326,
                   ST_SetSRID(ST_MakeEnvelope(?, ?, ?, ?), 4326)
               )
        GROUP BY t.nodeId, t.next_nodeId, t.segment_id
    ),
    pts AS (
        SELECT
            nodeId, next_nodeId, pairindex,
            ST_StartPoint(g28992)  AS sp,
            ST_EndPoint(g28992)    AS ep,
            ST_Length(g28992)      AS length_m,
            trip_ids_all
        FROM base
    )
    SELECT
        nodeId,
        next_nodeId,
        pairindex,
        ST_X(sp)   AS x1,
        ST_Y(sp)   AS y1,
        ST_X(ep)   AS x2,
        ST_Y(ep)   AS y2,
        length_m,
        trip_ids_all
    FROM pts
    """

    logger.info(
        "Querying NVP (combined): table=%s  mode=%s  year=%d", table_nvp, nvp_mode, year
    )
    cursor.execute(sql, (*bbox, nvp_mode, str(year), *bbox))
    rows = cursor.fetchall()
    logger.info("NVP query returned %d rows", len(rows))

    if not rows:
        empty2 = np.empty((0, 2), dtype=float)
        return np.empty((0, 3), dtype=object), np.array([]), empty2, empty2, {}

    # Unpack columns: (nodeId, next_nodeId, pairindex, x1, y1, x2, y2, length_m, trip_ids_all)
    node_ids  = [r[0] for r in rows]
    next_ids  = [r[1] for r in rows]
    pair_idxs = [r[2] for r in rows]
    x1s       = np.array([float(r[3]) for r in rows])
    y1s       = np.array([float(r[4]) for r in rows])
    x2s       = np.array([float(r[5]) for r in rows])
    y2s       = np.array([float(r[6]) for r in rows])
    lengths   = np.array([float(r[7]) for r in rows])
    trips_col = [r[8] for r in rows]  # list[str] | None per row

    links = np.array(
        [[n1, n2, pi] for n1, n2, pi in zip(node_ids, next_ids, pair_idxs)],
        dtype=object,
    )

    # Filter out degenerate segments (length ≤ 1 cm)
    valid     = lengths > 0.01
    links     = links[valid]
    lengths   = lengths[valid]
    x1s, y1s  = x1s[valid], y1s[valid]
    x2s, y2s  = x2s[valid], y2s[valid]
    trips_col = [trips_col[i] for i, ok in enumerate(valid) if ok]

    vertxys          = np.stack([x1s, y1s], axis=1)
    vertdxys         = np.zeros((len(links), 2))
    vertdxys[:, 0]   = (x2s - x1s) / lengths
    vertdxys[:, 1]   = (y2s - y1s) / lengths

    linktrips: dict = {
        (links[i, 0], links[i, 1], links[i, 2]): (
            list(trips_col[i]) if trips_col[i] is not None else []
        )
        for i in range(len(links))
    }

    return links, lengths, vertxys, vertdxys, linktrips
