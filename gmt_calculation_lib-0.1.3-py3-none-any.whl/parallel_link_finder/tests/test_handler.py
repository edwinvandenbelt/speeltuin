"""Smoke tests for the parallel-link-finder Lambda handler.

S3 calls are mocked so these tests run without LocalStack or AWS credentials.
Tests verify the APIGW response shape is consistent with the desired format:
  { area_id, job_id, modes, status, links (when GMT_BASE_URL set),
    features_enriched (per-mode dict), features_skipped (per-mode dict) }
"""

from __future__ import annotations

import importlib.util
import json
import os
import pathlib
import sys
from unittest.mock import patch

import pytest

# ---------------------------------------------------------------------------
# Load handler via importlib (avoids the `lambda` keyword in the import path)
# ---------------------------------------------------------------------------
_HANDLER_FILE = pathlib.Path(__file__).parent.parent / "lambda" / "parallel_link_finder.py"
_spec = importlib.util.spec_from_file_location("parallel_link_finder_handler", _HANDLER_FILE)
_mod = importlib.util.module_from_spec(_spec)
sys.modules["parallel_link_finder_handler"] = _mod
_spec.loader.exec_module(_mod)

handler = _mod.handler

# ---------------------------------------------------------------------------
# Minimal valid network GeoJSON that find_parallel_links can process
# ---------------------------------------------------------------------------
_TWO_LINK_NETWORK = json.dumps({
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.1, 52.0]]},
            "properties": {"fromNode": 1, "toNode": 2, "linkId": 1001},
        },
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[5.1, 52.0], [5.0, 52.0]]},
            "properties": {"fromNode": 2, "toNode": 1, "linkId": 1002},
        },
    ],
    "properties": {"bbox": [5.0, 52.0, 5.1, 52.0]},
})


def _make_apigw_event(inputs: dict) -> dict:
    return {
        "httpMethod": "POST",
        "body": json.dumps(inputs),
    }


def _call_apigw(inputs: dict, env: dict | None = None) -> tuple[int, dict]:
    """Call the handler with an APIGW event; return (status_code, body_dict)."""
    event = _make_apigw_event(inputs)
    env = env or {}
    with (
        patch.dict(os.environ, {**env}),
        patch.object(_mod, "get_bytes_s3", return_value=_TWO_LINK_NETWORK.encode()),
        patch.object(_mod, "put_bytes_s3"),
    ):
        resp = handler(event, None)
    body = json.loads(resp["body"])
    return resp["statusCode"], body


# ---------------------------------------------------------------------------
# Happy-path shape tests
# ---------------------------------------------------------------------------

class TestApigwResponseShape:
    def test_status_code_200(self):
        code, _ = _call_apigw({"area_id": "test-area", "modes": ["CAR"]})
        assert code == 200

    def test_area_id_present(self):
        _, body = _call_apigw({"area_id": "test-area", "modes": ["CAR"]})
        assert body["area_id"] == "test-area"

    def test_job_id_equals_area_id(self):
        _, body = _call_apigw({"area_id": "test-area", "modes": ["CAR"]})
        assert body["job_id"] == body["area_id"]

    def test_modes_list_present(self):
        _, body = _call_apigw({"area_id": "test-area", "modes": ["CAR", "BIKE"]})
        assert set(body["modes"]) == {"CAR", "BIKE"}

    def test_status_is_successful(self):
        _, body = _call_apigw({"area_id": "test-area", "modes": ["CAR"]})
        assert body["status"] == "successful"

    def test_features_enriched_is_per_mode_dict(self):
        _, body = _call_apigw({"area_id": "test-area", "modes": ["CAR"]})
        assert "features_enriched" in body
        assert "CAR" in body["features_enriched"]
        assert isinstance(body["features_enriched"]["CAR"], int)

    def test_features_skipped_is_per_mode_dict(self):
        _, body = _call_apigw({"area_id": "test-area", "modes": ["CAR"]})
        assert "features_skipped" in body
        assert "CAR" in body["features_skipped"]
        assert isinstance(body["features_skipped"]["CAR"], int)

    def test_multi_mode_enriched_has_all_modes(self):
        _, body = _call_apigw({"area_id": "test-area", "modes": ["CAR", "BIKE"]})
        assert set(body["features_enriched"].keys()) == {"CAR", "BIKE"}
        assert set(body["features_skipped"].keys()) == {"CAR", "BIKE"}

    def test_no_status_code_in_body(self):
        """statusCode must not appear in the JSON body — only in the HTTP envelope."""
        _, body = _call_apigw({"area_id": "test-area", "modes": ["CAR"]})
        assert "statusCode" not in body

    def test_no_network_key_in_body(self):
        """Legacy networkKey field must not appear in the response body."""
        _, body = _call_apigw({"area_id": "test-area", "modes": ["CAR"]})
        assert "network_key" not in body


# ---------------------------------------------------------------------------
# Links tests
# ---------------------------------------------------------------------------

class TestApigwLinks:
    def test_links_absent_without_gmt_base_url(self):
        _, body = _call_apigw(
            {"area_id": "test-area", "modes": ["CAR"]},
            env={"GMT_BASE_URL": ""},
        )
        assert "links" not in body

    def test_links_present_with_gmt_base_url(self):
        _, body = _call_apigw(
            {"area_id": "test-area", "modes": ["CAR"]},
            env={"GMT_BASE_URL": "http://host.docker.internal:8080/gmt"},
        )
        assert "links" in body
        assert len(body["links"]) == 2  # results + items for CAR

    def test_links_two_per_mode(self):
        _, body = _call_apigw(
            {"area_id": "test-area", "modes": ["CAR", "BIKE"]},
            env={"GMT_BASE_URL": "http://host.docker.internal:8080/gmt"},
        )
        assert len(body["links"]) == 4  # 2 links × 2 modes

    def test_results_link_href_contains_job_id_and_mode(self):
        area_id = "33aed018-30b2-46f7-b21b-55d03d6fd555"
        _, body = _call_apigw(
            {"area_id": area_id, "modes": ["CAR"]},
            env={"GMT_BASE_URL": "http://host.docker.internal:8080/gmt"},
        )
        results_links = [lk for lk in body["links"] if lk["rel"] == "results"]
        assert len(results_links) == 1
        assert area_id in results_links[0]["href"]
        assert "CAR" in results_links[0]["href"]

    def test_items_link_href_contains_area_id_and_mode(self):
        area_id = "33aed018-30b2-46f7-b21b-55d03d6fd555"
        _, body = _call_apigw(
            {"area_id": area_id, "modes": ["CAR"]},
            env={"GMT_BASE_URL": "http://host.docker.internal:8080/gmt"},
        )
        items_links = [lk for lk in body["links"] if lk["rel"] == "items"]
        assert len(items_links) == 1
        assert f"area_id={area_id}" in items_links[0]["href"]
        assert "mode=CAR" in items_links[0]["href"]

    def test_links_have_type_field(self):
        _, body = _call_apigw(
            {"area_id": "test-area", "modes": ["CAR"]},
            env={"GMT_BASE_URL": "http://host.docker.internal:8080/gmt"},
        )
        for lk in body["links"]:
            assert lk.get("type") == "application/geo+json"

    def test_gmt_base_url_trailing_slash_stripped(self):
        _, body = _call_apigw(
            {"area_id": "test-area", "modes": ["CAR"]},
            env={"GMT_BASE_URL": "http://host.docker.internal:8080/gmt/"},
        )
        for lk in body["links"]:
            assert "//" not in lk["href"].split("://", 1)[1]


# ---------------------------------------------------------------------------
# Error cases
# ---------------------------------------------------------------------------

class TestApigwErrors:
    def test_missing_area_id_returns_400(self):
        code, _ = _call_apigw({"modes": ["CAR"]})
        assert code == 400

    def test_missing_modes_returns_400(self):
        code, _ = _call_apigw({"area_id": "test-area"})
        assert code == 400

    def test_invalid_json_body_returns_400(self):
        event = {"httpMethod": "POST", "body": "not-json"}
        with patch.dict(os.environ, {}):
            resp = handler(event, None)
        assert resp["statusCode"] == 400
