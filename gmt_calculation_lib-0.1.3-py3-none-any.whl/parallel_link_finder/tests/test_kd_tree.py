"""Unit tests for src/kd_tree.py — pure Python + numpy, no I/O."""
from __future__ import annotations

import sys

import numpy as np
import pytest
from scipy.spatial import cKDTree

sys.path.insert(0, "src")

from shared.kd_tree import KDTree2D


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _brute_force_knn(data: np.ndarray, queries: np.ndarray, k: int):
    """Reference implementation: brute-force k-nearest neighbours."""
    m = len(queries)
    eff_k = min(k, len(data))
    dist_out = np.empty((m, eff_k))
    idx_out = np.empty((m, eff_k), dtype=int)
    for i, q in enumerate(queries):
        diffs = data - q
        sq_d = (diffs ** 2).sum(axis=1)
        order = np.argsort(sq_d)[:eff_k]
        dist_out[i] = np.sqrt(sq_d[order])
        idx_out[i] = order
    return dist_out, idx_out


# ---------------------------------------------------------------------------
# Basic correctness against brute-force and scipy cKDTree
# ---------------------------------------------------------------------------

class TestKDTree2DCorrectness:
    def setup_method(self):
        rng = np.random.default_rng(0)
        self.data = rng.random((300, 2)) * 10_000.0
        self.queries = rng.random((40, 2)) * 10_000.0
        self.k = 10

    def test_distances_match_scipy(self):
        our = KDTree2D(self.data)
        ref = cKDTree(self.data)
        our_d, _ = our.query(self.queries, k=self.k)
        ref_d, _ = ref.query(self.queries, k=self.k)
        np.testing.assert_allclose(our_d, ref_d, atol=1e-8,
                                   err_msg="Distances differ from scipy cKDTree")

    def test_distances_match_brute_force(self):
        our = KDTree2D(self.data)
        our_d, our_i = our.query(self.queries, k=self.k)
        bf_d, _ = _brute_force_knn(self.data, self.queries, self.k)
        np.testing.assert_allclose(our_d, bf_d, atol=1e-8,
                                   err_msg="Distances differ from brute-force")

    def test_indices_give_correct_distances(self):
        """Returned indices must point to the closest points in data."""
        our = KDTree2D(self.data)
        our_d, our_i = our.query(self.queries, k=self.k)
        for qi in range(len(self.queries)):
            for ki in range(self.k):
                expected_d = float(np.linalg.norm(self.data[our_i[qi, ki]] - self.queries[qi]))
                assert abs(expected_d - our_d[qi, ki]) < 1e-8

    def test_distances_sorted_ascending(self):
        our = KDTree2D(self.data)
        d, _ = our.query(self.queries, k=self.k)
        for i in range(len(self.queries)):
            assert list(d[i]) == sorted(d[i]), f"Row {i} is not sorted ascending"


class TestKDTree2DSingleQueryPoint:
    """Test with a 1-D (single point) input for x."""

    def setup_method(self):
        rng = np.random.default_rng(1)
        self.data = rng.random((100, 2)) * 1000.0

    def test_single_point_shape(self):
        tree = KDTree2D(self.data)
        d, i = tree.query(self.data[0], k=5)
        assert d.shape == (1, 5)
        assert i.shape == (1, 5)

    def test_single_point_nearest_is_itself(self):
        tree = KDTree2D(self.data)
        d, i = tree.query(self.data[42], k=1)
        assert d[0, 0] == pytest.approx(0.0, abs=1e-10)
        assert i[0, 0] == 42


class TestKDTree2DEdgeCases:
    def test_k_equals_n(self):
        """k == N should return all points."""
        rng = np.random.default_rng(2)
        data = rng.random((20, 2))
        tree = KDTree2D(data)
        d, idx = tree.query(data[:3], k=20)
        assert d.shape == (3, 20)
        # Nearest (rank 0) must be distance 0 (query == data point)
        np.testing.assert_allclose(d[:, 0], 0.0, atol=1e-10)

    def test_k_greater_than_n(self):
        """When k > N, result has N columns (mirrors cKDTree behaviour)."""
        data = np.array([[0.0, 0.0], [1.0, 1.0], [2.0, 2.0]])
        tree = KDTree2D(data)
        d, idx = tree.query(np.array([[0.5, 0.5]]), k=10)
        assert d.shape[1] == 3  # only 3 points available

    def test_empty_dataset(self):
        tree = KDTree2D(np.empty((0, 2)))
        d, idx = tree.query(np.array([[1.0, 2.0]]), k=5)
        assert d.shape[1] == 0
        assert idx.shape[1] == 0

    def test_single_data_point(self):
        data = np.array([[3.0, 7.0]])
        tree = KDTree2D(data)
        d, idx = tree.query(np.array([[0.0, 0.0]]), k=1)
        assert d.shape == (1, 1)
        assert idx[0, 0] == 0

    def test_all_coincident_points(self):
        """All data points at the same location — all distances to query are equal."""
        data = np.ones((50, 2)) * 5.0
        tree = KDTree2D(data)
        d, idx = tree.query(np.array([[0.0, 0.0]]), k=10)
        assert d.shape == (1, 10)
        expected_dist = float(np.linalg.norm(np.array([5.0, 5.0])))
        np.testing.assert_allclose(d[0], expected_dist, atol=1e-8)

    def test_k_equals_1(self):
        rng = np.random.default_rng(3)
        data = rng.random((200, 2))
        tree = KDTree2D(data)
        ref = cKDTree(data)
        q = rng.random((30, 2))
        our_d, _ = tree.query(q, k=1)
        ref_d, _ = ref.query(q, k=1)
        # cKDTree returns shape (M,) for k=1; our implementation always returns (M, k).
        np.testing.assert_allclose(our_d[:, 0], ref_d, atol=1e-8)


class TestKDTree2DLargeScale:
    """Performance smoke test — should complete in a reasonable time."""

    def test_large_dataset(self):
        rng = np.random.default_rng(99)
        data = rng.random((50_000, 2)) * 100_000.0
        queries = rng.random((100, 2)) * 100_000.0
        tree = KDTree2D(data)
        ref = cKDTree(data)
        our_d, _ = tree.query(queries, k=10)
        ref_d, _ = ref.query(queries, k=10)
        np.testing.assert_allclose(our_d, ref_d, atol=1e-6)
