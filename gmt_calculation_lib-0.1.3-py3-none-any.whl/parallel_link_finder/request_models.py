"""Pydantic input schema for the parallel-link-finder Lambda handler."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class HandlerInput(BaseModel):
    """Validated event payload for the parallel-link-finder Lambda handler.

    Required
    --------
    input_network_files
        List of S3 URLs for input GeoJSON network files: ``["s3://bucket/key", ...]``.

    Optional
    --------
    output_network_file
        S3 URL where the enriched GeoJSON will be written.
    maxlength_sublink
        Maximum sub-link length (metres) used during spatial matching.  Default: 5.0.
    maxdist
        Maximum lateral distance (metres) between a link centroid and a candidate
        parallel/reverse link.  Default: 20.0.
    maxalpha
        Maximum angular difference (degrees) allowed between matching links.
        Default: 15.0.
    """

    model_config = ConfigDict(extra="ignore")

    input_network_files: list[str]

    output_network_file: str | None = None
    maxlength_sublink: float = 5.0
    maxdist: float = 20.0
    maxalpha: float = 15.0
