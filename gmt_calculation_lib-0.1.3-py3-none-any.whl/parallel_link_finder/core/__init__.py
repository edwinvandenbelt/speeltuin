# parallel_link_finder.core
