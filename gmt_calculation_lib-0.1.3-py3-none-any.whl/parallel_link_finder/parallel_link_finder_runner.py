"""Local debug runner for parallel_link_finder.

Calls parallel_link_finder_core.find_parallel_links() directly — no Lambda handler involved.

Usage
-----
    python -m parallel_link_finder.parallel_link_finder_runner \\
        --networks /tmp/network-CAR.parquet /tmp/network-BIKE.parquet

    # Single file, separate output:
    python -m parallel_link_finder.parallel_link_finder_runner \\
        --networks /tmp/network.parquet \\
        --output /tmp/network-enriched.parquet

    # S3 input (overwrites in place):
    python -m parallel_link_finder.parallel_link_finder_runner \\
        --networks s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.parquet

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
* numpy installed (pip install numpy).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for parallel_link_finder (calls core directly)."
    )
    parser.add_argument(
        "--networks",
        nargs="+",
        required=True,
        metavar="URI",
        help="One or more full network GeoParquet URIs (s3:// or local path). Each is overwritten in place.",
    )
    parser.add_argument(
        "--output",
        metavar="URI",
        default=None,
        help="Output URI; only valid with a single --networks entry. Defaults to overwriting the input.",
    )
    parser.add_argument("--maxlength-sublink", type=float, default=5.0,
                        help="Max sub-link length in metres (default: 5).")
    parser.add_argument("--maxdist",  type=float, default=20.0,
                        help="Max lateral distance in metres (default: 20).")
    parser.add_argument("--maxalpha", type=float, default=15.0,
                        help="Max angular difference in degrees (default: 15).")
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    if args.output and len(args.networks) > 1:
        print("[error] --output can only be used with a single --networks entry.", file=sys.stderr)
        sys.exit(1)

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from parallel_link_finder.core.parallel_link_finder_core import find_parallel_links  # noqa: PLC0415
    from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

    for in_uri in args.networks:
        out_uri = args.output or in_uri
        print(f"\nReading  : {in_uri}")
        fc = from_geoparquet(_read_uri(in_uri))
        enriched_fc, stats = find_parallel_links(
            fc,
            maxlength_sublink=args.maxlength_sublink,
            maxdist=args.maxdist,
            maxalpha=args.maxalpha,
        )
        print(f"Writing  : {out_uri}")
        _write_uri(out_uri, to_geoparquet(enriched_fc))
        print(f"  enriched={stats['features_enriched']}  skipped={stats['features_skipped']}")


if __name__ == "__main__":
    main()
