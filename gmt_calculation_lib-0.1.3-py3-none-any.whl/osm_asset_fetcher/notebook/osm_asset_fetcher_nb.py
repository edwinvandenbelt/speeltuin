# Databricks notebook source
# ---------------------------------------------------------------------------
# osm_asset_fetcher_nb.py — Databricks notebook interface.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Derives the bounding box (explicit widget or from a network GeoParquet).
#   3. Fetches OSM traffic objects (pedestrian crossings, speed bumps, stop /
#      give-way signs, mini-roundabouts) from the OpenStreetMap Overpass API.
#   4. Writes the result as a GeoParquet FeatureCollection.
#   5. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("osm_asset_fetcher_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "bbox",
    "",
    "Bounding box 'minLon,minLat,maxLon,maxLat' (leave empty to derive from network_uri)",
)
dbutils.widgets.text(  # noqa: F821
    "network_uri",
    "",
    "Network GeoParquet URI to derive the bbox from (used when bbox is empty)",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri",
    "",
    "Output GeoParquet URI for the OSM asset FeatureCollection",
)
dbutils.widgets.text(  # noqa: F821
    "kinds",
    "",
    "Comma-separated asset kinds (leave empty for all)",
)
dbutils.widgets.text(  # noqa: F821
    "tiles",
    "3",
    "NxN Overpass tile grid",
)
dbutils.widgets.text(  # noqa: F821
    "timeout",
    "60",
    "Overpass HTTP + server-side timeout in seconds",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from osm_asset_fetcher.core.osm_asset_fetcher_core import fetch_osm_assets  # noqa: E402, PLC0415

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

BBOX_RAW = dbutils.widgets.get("bbox").strip()  # noqa: F821
NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip()  # noqa: F821
KINDS_RAW = dbutils.widgets.get("kinds").strip()  # noqa: F821
TILES = int(dbutils.widgets.get("tiles").strip() or "3")  # noqa: F821
TIMEOUT = int(dbutils.widgets.get("timeout").strip() or "60")  # noqa: F821

KINDS = [k.strip() for k in KINDS_RAW.split(",") if k.strip()] or None

if not OUTPUT_URI:
    raise ValueError("Widget 'output_uri' is empty.")
if not BBOX_RAW and not NETWORK_URI:
    raise ValueError("Provide either 'bbox' or 'network_uri'.")

logger.info(
    "bbox=%s  network_uri=%s  output_uri=%s  kinds=%s",
    BBOX_RAW,
    NETWORK_URI,
    OUTPUT_URI,
    KINDS,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/vnd.apache.parquet",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    import os  # noqa: PLC0415

    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run OsmAssetFetcher
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402, PLC0415

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")

# Determine bbox
if BBOX_RAW:
    _bbox = [float(v) for v in BBOX_RAW.split(",")]
else:
    _fc = from_geoparquet(_read_uri(NETWORK_URI))
    _bbox = (_fc.get("properties") or {}).get("bbox")
    if not _bbox or len(_bbox) < 4:
        _lons, _lats = [], []
        for _f in _fc.get("features") or []:
            for _c in (_f.get("geometry") or {}).get("coordinates") or []:
                _lons.append(float(_c[0]))
                _lats.append(float(_c[1]))
        _bbox = [min(_lons), min(_lats), max(_lons), max(_lats)]
print(f"Bbox      : {_bbox}")

# Fetch OSM assets
_fc_out, _stats = fetch_osm_assets(_bbox, kinds=KINDS, tiles=TILES, timeout=TIMEOUT)

# Write result
_write_uri(OUTPUT_URI, to_geoparquet(_fc_out))

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"OsmAssetFetcher complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Output URI     : {OUTPUT_URI}")
print(f"  Counts         : {_stats['counts']}")
print(f"  Total          : {_stats['total']:,}")
print(f"  Source         : {_stats['source']}")
print(_SEP)
