"""Unit tests for osm_asset_fetcher core (pure functions + stubbed Overpass)."""

from __future__ import annotations

from osm_asset_fetcher.core.osm_asset_fetcher_core import (
    DEFAULT_KINDS,
    KIND_GIVE_WAY,
    KIND_MINI_ROUNDABOUT,
    KIND_PEDESTRIAN_CROSSING,
    KIND_SPEED_BUMP,
    KIND_STOP_SIGN,
    OSM_ASSET_QUERY_VER,
    classify_element,
    elements_to_asset_features,
    fetch_osm_assets,
    overpass_query_for_bbox,
)

_BBOX = [6.39, 52.14, 6.43, 52.17]


# ---------------------------------------------------------------------------
# classify_element
# ---------------------------------------------------------------------------


def test_classify_element_matches_each_kind() -> None:
    assert classify_element({"highway": "crossing"}, DEFAULT_KINDS) == KIND_PEDESTRIAN_CROSSING
    assert classify_element({"traffic_calming": "bump"}, DEFAULT_KINDS) == KIND_SPEED_BUMP
    assert classify_element({"highway": "stop"}, DEFAULT_KINDS) == KIND_STOP_SIGN
    assert classify_element({"highway": "give_way"}, DEFAULT_KINDS) == KIND_GIVE_WAY
    assert classify_element({"highway": "mini_roundabout"}, DEFAULT_KINDS) == KIND_MINI_ROUNDABOUT


def test_classify_element_returns_none_for_unmatched() -> None:
    assert classify_element({"highway": "residential"}, DEFAULT_KINDS) is None
    assert classify_element({}, DEFAULT_KINDS) is None


def test_classify_element_respects_requested_kinds() -> None:
    # speedBump excluded from the requested kinds -> not classified.
    assert classify_element({"traffic_calming": "hump"}, [KIND_PEDESTRIAN_CROSSING]) is None


# ---------------------------------------------------------------------------
# overpass_query_for_bbox
# ---------------------------------------------------------------------------


def test_overpass_query_uses_south_west_north_east_order() -> None:
    query = overpass_query_for_bbox(_BBOX, [KIND_STOP_SIGN], timeout=30)
    # Overpass order: south,west,north,east => minLat,minLon,maxLat,maxLon
    assert "52.14,6.39,52.17,6.43" in query
    assert '"highway"="stop"' in query
    assert "[timeout:30]" in query


def test_overpass_query_skips_unknown_kinds() -> None:
    query = overpass_query_for_bbox(_BBOX, ["notAKind", KIND_SPEED_BUMP])
    assert '"traffic_calming"' in query
    assert "notAKind" not in query


# ---------------------------------------------------------------------------
# elements_to_asset_features
# ---------------------------------------------------------------------------


def test_elements_to_asset_features_tags_and_filters() -> None:
    elements = [
        {"type": "node", "id": 1, "lat": 52.15, "lon": 6.40, "tags": {"highway": "crossing"}},
        {"type": "node", "id": 2, "lat": 52.15, "lon": 6.41, "tags": {"highway": "residential"}},
        {"type": "way", "id": 3, "tags": {"highway": "crossing"}},
    ]
    feats = elements_to_asset_features(elements, DEFAULT_KINDS)
    assert len(feats) == 1
    assert feats[0]["geometry"] == {"type": "Point", "coordinates": [6.40, 52.15]}
    assert feats[0]["properties"]["assetType"] == KIND_PEDESTRIAN_CROSSING
    assert feats[0]["properties"]["osm_id"] == 1


# ---------------------------------------------------------------------------
# fetch_osm_assets — stubbed Overpass client
# ---------------------------------------------------------------------------


def test_fetch_osm_assets_empty_kinds_skips() -> None:
    fc, stats = fetch_osm_assets(_BBOX, kinds=[])
    assert stats["source"] == "skipped"
    assert stats["total"] == 0
    assert fc["features"] == []


def test_fetch_osm_assets_counts_by_type(monkeypatch) -> None:
    def _fake_tiled(_query_fn, _bbox, **_kwargs) -> dict:
        return {
            "elements": [
                {"type": "node", "id": 1, "lat": 52.15, "lon": 6.40, "tags": {"highway": "stop"}},
                {"type": "node", "id": 2, "lat": 52.16, "lon": 6.41, "tags": {"highway": "stop"}},
                {
                    "type": "node",
                    "id": 3,
                    "lat": 52.16,
                    "lon": 6.42,
                    "tags": {"highway": "crossing"},
                },
            ]
        }

    monkeypatch.setattr("shared.overpass.fetch_overpass_tiled", _fake_tiled, raising=True)

    fc, stats = fetch_osm_assets(_BBOX, kinds=[KIND_STOP_SIGN, KIND_PEDESTRIAN_CROSSING])
    assert stats["source"] == "OSM"
    assert stats["total"] == 3
    assert stats["counts"][KIND_STOP_SIGN] == 2
    assert stats["counts"][KIND_PEDESTRIAN_CROSSING] == 1
    assert fc["properties"]["_qv"] == OSM_ASSET_QUERY_VER
