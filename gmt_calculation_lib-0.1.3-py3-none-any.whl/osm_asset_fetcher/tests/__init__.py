# src/osm_asset_fetcher/tests/__init__.py
