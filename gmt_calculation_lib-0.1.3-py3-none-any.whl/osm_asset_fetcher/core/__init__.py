# src/osm_asset_fetcher/core/__init__.py
