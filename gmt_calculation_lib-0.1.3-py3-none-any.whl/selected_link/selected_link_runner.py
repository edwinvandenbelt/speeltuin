"""Local runner for selected_link.

Reads a ROUTES parquet and a NETWORK parquet from an input folder, runs the
selected-link analysis for a given anchor link ID, and writes a SELECTEDLINK
parquet to the output folder.

File naming convention (consistent with other modules):
    Input  : {input_folder}/{areaId}-ROUTES-{mode}.parquet
    Input  : {input_folder}/{areaId}-NETWORK-{mode}.parquet
    Output : {output_folder}/{areaId}-SELECTEDLINK-{mode}-{linkId}.parquet

Usage
-----
    python -m selected_link.selected_link_runner \\
        --area-id deventer-centrum \\
        --mode CAR \\
        --link-id 123456 \\
        --input-folder output/deventer-centrum \\
        --output-folder output/deventer-centrum
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


def _resolve_uri(folder: str, filename: str) -> str:
    """Join a folder URI and a filename, supporting both s3:// and local paths."""
    if folder.startswith("s3://"):
        return folder.rstrip("/") + "/" + filename
    return str(Path(folder) / filename)


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Selected-link analysis: aggregates route trips onto all links "
            "that pass through a chosen anchor link."
        )
    )
    parser.add_argument(
        "--area-id",
        required=True,
        metavar="ID",
        help="Area identifier, e.g. 'deventer-centrum'.",
    )
    parser.add_argument(
        "--mode",
        required=True,
        metavar="MODE",
        help="Transport mode, e.g. 'CAR'.",
    )
    parser.add_argument(
        "--link-id",
        required=True,
        metavar="LINKID",
        help="linkId of the selected (anchor) link.",
    )
    parser.add_argument(
        "--input-folder",
        required=True,
        metavar="URI",
        help=(
            "Folder containing the ROUTES and NETWORK GeoJSON files "
            "(s3://bucket/prefix or local path)."
        ),
    )
    parser.add_argument(
        "--output-folder",
        default=None,
        metavar="URI",
        help="Output folder URI. Defaults to --input-folder.",
    )
    parser.add_argument(
        "--routes-file",
        default=None,
        metavar="URI",
        help=(
            "Override the ROUTES file URI directly "
            "(default: {input-folder}/{areaId}-ROUTES-{mode}.geojson)."
        ),
    )
    parser.add_argument(
        "--network-file",
        default=None,
        metavar="URI",
        help=(
            "Override the NETWORK file URI directly "
            "(default: {input-folder}/{areaId}-NETWORK-{mode}.geojson)."
        ),
    )
    parser.add_argument(
        "--output-file",
        default=None,
        metavar="URI",
        help=(
            "Override the output file URI directly "
            "(default: {output-folder}/{areaId}-SELECTEDLINK-{mode}-{linkId}.geojson)."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from selected_link.core.selected_link_core import compute_selected_link
    from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

    output_folder = args.output_folder or args.input_folder

    routes_uri = args.routes_file or _resolve_uri(
        args.input_folder, f"{args.area_id}-ROUTES-{args.mode}.parquet"
    )
    network_uri = args.network_file or _resolve_uri(
        args.input_folder, f"{args.area_id}-NETWORK-{args.mode}.parquet"
    )
    # Sanitise linkId for use in filename (replace characters unsafe for filenames)
    safe_link_id = args.link_id.replace("/", "_").replace("\\", "_")
    output_uri = args.output_file or _resolve_uri(
        output_folder,
        f"{args.area_id}-SELECTEDLINK-{args.mode}-{safe_link_id}.parquet",
    )

    print(f"Reading routes  : {routes_uri}")
    routes_fc: dict = from_geoparquet(_read_uri(routes_uri))

    print(f"Reading network : {network_uri}")
    network_fc: dict = from_geoparquet(_read_uri(network_uri))

    n_od_pairs = len(routes_fc.get("features") or [])
    n_links = len(network_fc.get("features") or [])
    print(f"OD pairs        : {n_od_pairs}")
    print(f"Network links   : {n_links}")
    print(f"Anchor link ID  : {args.link_id}")

    result_fc = compute_selected_link(routes_fc, network_fc, args.link_id)

    n_out = len(result_fc.get("features") or [])
    print(f"Output links    : {n_out}")
    print(f"Writing output  : {output_uri}")

    _write_uri(output_uri, to_geoparquet(result_fc))
    print("Done.")


if __name__ == "__main__":
    main()
