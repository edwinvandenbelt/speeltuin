# Databricks notebook source
# ---------------------------------------------------------------------------
# selected_link_nb.py — Databricks notebook interface for selected-link analysis.
#
# This notebook:
#   1. Reads widget parameters (area_id, mode, anchor_link_id, input_folder,
#      output_folder).
#   2. Reads {area_id}-ROUTES-{mode}.geojson and {area_id}-NETWORK-{mode}.geojson
#      from input_folder (s3:// or local).
#   3. Calls compute_selected_link() — no Spark I/O.
#   4. Writes {area_id}-SELECTEDLINK-{mode}-{anchor_link_id}.geojson to
#      output_folder.
#
# Requirements (Databricks cluster):
#   pip install boto3
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("selected_link_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text("area_id",         "",     "Area ID (e.g. deventer-centrum)")  # noqa: F821
dbutils.widgets.text("mode",            "CAR",  "Transport mode (CAR / BIKE / …)")  # noqa: F821
dbutils.widgets.text("anchor_link_id",  "",     "linkId of the selected (anchor) link")  # noqa: F821
dbutils.widgets.text("input_folder",    "",     "Input folder URI (s3://bucket/prefix or local path)")  # noqa: F821
dbutils.widgets.text("output_folder",   "",     "Output folder URI (leave empty to use input_folder)")  # noqa: F821
dbutils.widgets.text("LOG_LEVEL",       "INFO", "Log level (DEBUG / INFO / WARNING / ERROR)")  # noqa: F821

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from selected_link.core.selected_link_core import compute_selected_link

# COMMAND ----------
# Widget read + validation
AREA_ID        = dbutils.widgets.get("area_id").strip()         # noqa: F821
MODE           = dbutils.widgets.get("mode").strip().upper()    # noqa: F821
ANCHOR_LINK_ID = dbutils.widgets.get("anchor_link_id").strip()  # noqa: F821
INPUT_FOLDER   = dbutils.widgets.get("input_folder").strip()    # noqa: F821
OUTPUT_FOLDER  = (dbutils.widgets.get("output_folder").strip()  # noqa: F821
                  or INPUT_FOLDER)

for _name, _val in [
    ("area_id", AREA_ID),
    ("mode", MODE),
    ("anchor_link_id", ANCHOR_LINK_ID),
    ("input_folder", INPUT_FOLDER),
]:
    if not _val:
        raise ValueError(f"Widget '{_name}' is required but was not filled in.")

logger.info(
    "area_id=%s  mode=%s  anchor_link_id=%s  input_folder=%s  output_folder=%s",
    AREA_ID, MODE, ANCHOR_LINK_ID, INPUT_FOLDER, OUTPUT_FOLDER,
)

# COMMAND ----------
# S3 / local I/O helpers
import boto3  # noqa: E402


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read  s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


def _resolve(folder: str, filename: str) -> str:
    if folder.startswith("s3://"):
        return folder.rstrip("/") + "/" + filename
    import pathlib
    return str(pathlib.Path(folder) / filename)


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Selected-Link Analysis
# MAGIC Adjust widget values above, then **re-run from this cell**.

# COMMAND ----------
_t_start = datetime.now(timezone.utc)

_safe_link_id = ANCHOR_LINK_ID.replace("/", "_").replace("\\", "_")
_routes_uri  = _resolve(INPUT_FOLDER,  f"{AREA_ID}-ROUTES-{MODE}.geojson")
_network_uri = _resolve(INPUT_FOLDER,  f"{AREA_ID}-NETWORK-{MODE}.geojson")
_output_uri  = _resolve(OUTPUT_FOLDER, f"{AREA_ID}-SELECTEDLINK-{MODE}-{_safe_link_id}.geojson")

logger.info("routes_uri=%s",  _routes_uri)
logger.info("network_uri=%s", _network_uri)
logger.info("output_uri=%s",  _output_uri)

# COMMAND ----------
_routes_fc  = json.loads(_read_uri(_routes_uri))
_network_fc = json.loads(_read_uri(_network_uri))

logger.info("OD pairs: %d", len(_routes_fc.get("features") or []))
logger.info("Network links: %d", len(_network_fc.get("features") or []))

# COMMAND ----------
_result_fc = compute_selected_link(_routes_fc, _network_fc, ANCHOR_LINK_ID)

_n_out = len(_result_fc.get("features") or [])
logger.info("Selected-link output: %d link features", _n_out)

# COMMAND ----------
_payload = json.dumps(_result_fc, ensure_ascii=False).encode("utf-8")
_write_uri(_output_uri, _payload)

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# Results summary
_SEP = "─" * 60
print(_SEP)
print(f"Selected-link analysis complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Area ID       : {AREA_ID}")
print(f"  Mode          : {MODE}")
print(f"  Anchor link   : {ANCHOR_LINK_ID}")
print(f"  Output links  : {_n_out}")
print(f"  Output URI    : {_output_uri}")
print(_SEP)
