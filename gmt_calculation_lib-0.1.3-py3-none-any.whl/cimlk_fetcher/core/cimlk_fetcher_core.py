"""Pure-Python cimlk_fetcher core — CIMLK road-segment heights & structures.

Reads the Dutch **CIMLK** air-quality road network (``LineString Z`` wegvakken in
EPSG:28992 / RD New, with real absolute Z heights in metres) from a local
shapefile and derives, for a bounding box:

* ``assets_fc`` — display-ready **construction objects** in WGS-84 that merge into
  the combined ``{area_id}-TRAFFIC-ASSETS.parquet``:
    - **viaduct / bridge** (``assetType = "viaduct"``) — an elevated wegvak, keeping
      its 3D geometry, tagged ``heightM`` (height above ground), ``wvkId``,
      ``bstCode``, ``belowGround``.
    - **noise screen** (``assetType = "screen"``) — a line parallel to the road axis,
      offset per side (``left``/``right``) by the CIMLK screen distance, tagged
      ``side``, ``heightM``, ``screenKind``, ``wvkId``, ``belowGround``.
* ``heights_fc`` — **all** clipped wegvakken in WGS-84 with their 3D geometry and
  height / tunnel / talud / screen attributes, written to a separate
  ``{area_id}-HEIGHTS.parquet`` for a later (deferred) pipeline phase.

CIMLK only covers the Netherlands and is a non-OSM, local-file source: outside NL,
or when no source path is configured, an empty result is returned (silent no-op),
mirroring the ``bgt_fetcher`` pattern.

Screen offsets are computed in RD (EPSG:28992, metres) with shapely and the whole
result is reprojected to WGS-84 (EPSG:4326) once at the end.  Z coordinates are
preserved verbatim (metres) — never rounded.

Public API
----------
fetch_cimlk(bbox, *, source_path, timeout) -> tuple[dict, dict, dict]
    High-level entry: read + clip + derive.  Returns (assets_fc, heights_fc, stats).
"""

from __future__ import annotations

import logging
import math
import os
from typing import Any

from shared.geo import is_netherlands

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached CIMLK output.
CIMLK_QUERY_VER: int = 1

#: Asset-type tags written on produced features.
ASSET_TYPE_VIADUCT: str = "viaduct"
ASSET_TYPE_SCREEN: str = "screen"

#: Source CRS of the CIMLK shapefile (RD New).
SOURCE_CRS: str = "EPSG:28992"
#: Target CRS for all emitted geometry (WGS-84).
TARGET_CRS: str = "EPSG:4326"

#: Numeric sentinel values meaning "not filled" in the CIMLK attributes.
NUMERIC_SENTINELS: frozenset[float] = frozenset({-999.0, -99.0})

#: A wegvak counts as a viaduct when its derived height above ground exceeds
#: this many metres (used for the Z minus maaiveld fallback criterion).
VIADUCT_MIN_HEIGHT_M: float = 1.0

#: A wegvak is flagged ``belowGround`` when its median Z sits at least this many
#: metres below the local maaiveld height.
BELOW_GROUND_MARGIN_M: float = 0.5

#: Environment variable holding the default CIMLK shapefile path.
CIMLK_PATH_ENV: str = "CIMLK_PATH"


# ---------------------------------------------------------------------------
# Sentinel / value normalisation (pure)
# ---------------------------------------------------------------------------


def _clean_num(value: Any) -> float | None:
    """Return *value* as a float, or ``None`` for sentinels / blanks / NaN.

    Treats ``-999`` and ``-99`` (CIMLK "not filled" sentinels), empty strings and
    ``NaN`` as absent.
    """
    if value is None:
        return None
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return None
        try:
            value = float(text)
        except ValueError:
            return None
    try:
        num = float(value)
    except ValueError, TypeError:
        return None
    if math.isnan(num) or math.isinf(num):
        return None
    if num in NUMERIC_SENTINELS:
        return None
    return num


def _clean_str(value: Any) -> str | None:
    """Return *value* as a stripped string, or ``None`` for blanks / NaN."""
    if value is None:
        return None
    if isinstance(value, float) and math.isnan(value):
        return None
    text = str(value).strip()
    if not text or text.lower() == "nan":
        return None
    return text


def normalize_props(raw: dict) -> dict:
    """Map raw CIMLK attribute columns to sentinel-normalised camelCase props.

    Numeric sentinels (``-999``/``-99``), empty strings and ``NaN`` become
    ``None``.  ``wvkId`` is always a string (or ``None``).
    """
    wvk = raw.get("WVK_ID")
    wvk_id = None if wvk is None or (isinstance(wvk, float) and math.isnan(wvk)) else str(wvk)
    if wvk_id is not None:
        wvk_id = wvk_id.strip() or None
        # Shapefile numeric ids often arrive as e.g. "600113621.0".
        if wvk_id is not None and wvk_id.endswith(".0"):
            wvk_id = wvk_id[:-2]
    return {
        "wvkId": wvk_id,
        "bstCode": _clean_str(raw.get("BST_CODE")),
        "tunnelfact": _clean_num(raw.get("TUNNELFACT")),
        "hoogte": _clean_num(raw.get("HOOGTE")),
        "taludsoort": _clean_str(raw.get("TALUDSOORT")),
        "hNwb": _clean_num(raw.get("H_NWB")),
        "hMaaiveld": _clean_num(raw.get("H_MAAIVELD")),
        "overdrlSrt": _clean_str(raw.get("OVERDRLSRT")),
        "overdrlAfs": _clean_num(raw.get("OVERDRLAFS")),
        "overdrlHgt": _clean_num(raw.get("OVERDRLHGT")),
        "overdrrSrt": _clean_str(raw.get("OVERDRRSRT")),
        "overdrrAfs": _clean_num(raw.get("OVERDRRAFS")),
        "overdrrHgt": _clean_num(raw.get("OVERDRRHGT")),
    }


# ---------------------------------------------------------------------------
# Geometry-derived helpers (pure — operate on coordinate lists)
# ---------------------------------------------------------------------------


def _median_z(coords: list[tuple]) -> float | None:
    """Return the median Z of 3D *coords*, or ``None`` when no Z is present."""
    zs = sorted(float(c[2]) for c in coords if len(c) >= 3)
    if not zs:
        return None
    mid = len(zs) // 2
    if len(zs) % 2:
        return zs[mid]
    return (zs[mid - 1] + zs[mid]) / 2.0


def is_below_ground(coords: list[tuple], h_maaiveld: float | None) -> bool:
    """Whether the wegvak sits structurally below the local maaiveld.

    ``True`` when the median Z is at least :data:`BELOW_GROUND_MARGIN_M` metres
    below *h_maaiveld*.  Unknown Z or maaiveld ⇒ ``False`` (assume at grade).
    """
    mz = _median_z(coords)
    if mz is None or h_maaiveld is None:
        return False
    return mz < (h_maaiveld - BELOW_GROUND_MARGIN_M)


def viaduct_height_m(
    coords: list[tuple], hoogte: float | None, h_maaiveld: float | None
) -> float | None:
    """Return a wegvak's height above ground when it qualifies as a viaduct.

    Criterion: an explicit ``HOOGTE > 0``, or a median-Z that rises more than
    :data:`VIADUCT_MIN_HEIGHT_M` metres above *h_maaiveld*.  Returns the derived
    height in metres, or ``None`` when the wegvak is not elevated.
    """
    if hoogte is not None and hoogte > 0:
        return float(hoogte)
    mz = _median_z(coords)
    if mz is not None and h_maaiveld is not None:
        diff = mz - h_maaiveld
        if diff > VIADUCT_MIN_HEIGHT_M:
            return float(diff)
    return None


def screen_specs(props: dict) -> list[dict]:
    """Return one spec per side that has a defined noise screen.

    A screen exists on a side when its *soort* (``overdr[l|r]Srt``) is present and
    its offset distance (``overdr[l|r]Afs``) is a real (non-sentinel) value.  Each
    spec is ``{"side", "afs", "heightM", "screenKind"}`` where ``side`` is
    ``"left"`` / ``"right"`` relative to the LineString digitisation direction.
    """
    specs: list[dict] = []
    for side, srt_key, afs_key, hgt_key in (
        ("left", "overdrlSrt", "overdrlAfs", "overdrlHgt"),
        ("right", "overdrrSrt", "overdrrAfs", "overdrrHgt"),
    ):
        kind = props.get(srt_key)
        afs = props.get(afs_key)
        if kind is None or afs is None:
            continue
        specs.append(
            {
                "side": side,
                "afs": float(afs),
                "heightM": props.get(hgt_key),
                "screenKind": kind,
            }
        )
    return specs


def viaduct_props(props: dict, height_m: float, below_ground: bool) -> dict:
    """Build the property dict for a viaduct feature (camelCase)."""
    return {
        "assetType": ASSET_TYPE_VIADUCT,
        "heightM": height_m,
        "belowGround": below_ground,
        "wvkId": props.get("wvkId"),
        "bstCode": props.get("bstCode"),
    }


def screen_props(props: dict, spec: dict, below_ground: bool) -> dict:
    """Build the property dict for a noise-screen feature (camelCase)."""
    return {
        "assetType": ASSET_TYPE_SCREEN,
        "side": spec["side"],
        "heightM": spec.get("heightM"),
        "screenKind": spec.get("screenKind"),
        "belowGround": below_ground,
        "wvkId": props.get("wvkId"),
    }


# ---------------------------------------------------------------------------
# Result assembly helpers
# ---------------------------------------------------------------------------


def _empty_fc() -> dict:
    return {"type": "FeatureCollection", "features": [], "properties": {"_qv": CIMLK_QUERY_VER}}


def _skipped_stats(source: str) -> dict:
    return {
        "viaduct": 0,
        "screen": 0,
        "heights": 0,
        "belowGround": 0,
        "source": source,
    }


def _resolve_source_path(source_path: str | None) -> str | None:
    """Resolve the CIMLK shapefile path from *source_path* or ``CIMLK_PATH`` env."""
    candidate = source_path if source_path else os.environ.get(CIMLK_PATH_ENV, "")
    candidate = (candidate or "").strip()
    if not candidate:
        return None
    if not os.path.isfile(candidate):
        logger.info("CIMLK source path %r not found — skipping CIMLK fetch.", candidate)
        return None
    return candidate


# ---------------------------------------------------------------------------
# High-level entry point
# ---------------------------------------------------------------------------


def fetch_cimlk(
    bbox: list[float],
    *,
    source_path: str | None = None,
    timeout: int = 60,  # noqa: ARG001 — kept for fetcher-signature symmetry.
) -> tuple[dict, dict, dict]:
    """Read CIMLK wegvakken for *bbox* and derive construction objects + heights.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    source_path:
        Path to the CIMLK shapefile (EPSG:28992, ``LineString Z``).  Defaults to
        the ``CIMLK_PATH`` environment variable.  When neither is set, or the file
        is missing, or the bbox lies outside the Netherlands, an empty result is
        returned (silent no-op).
    timeout:
        Accepted for signature symmetry with the other fetchers; unused (local
        file read).

    Returns
    -------
    assets_fc:
        WGS-84 ``FeatureCollection`` of viaduct + screen features for the combined
        traffic-assets parquet.
    heights_fc:
        WGS-84 ``FeatureCollection`` of all clipped wegvakken with 3D geometry and
        height / tunnel / talud / screen attributes.
    stats:
        ``{"viaduct": int, "screen": int, "heights": int, "belowGround": int,
        "source": str}``.  ``source`` is ``"CIMLK"``, or ``"skipped"`` when no data
        was read.
    """
    path = _resolve_source_path(source_path)
    if path is None:
        return _empty_fc(), _empty_fc(), _skipped_stats("skipped")
    if not is_netherlands(bbox):
        logger.info("bbox centroid outside NL — skipping CIMLK fetch.")
        return _empty_fc(), _empty_fc(), _skipped_stats("skipped")

    import geopandas as gpd  # noqa: PLC0415
    import shapely  # noqa: PLC0415
    from shapely.geometry import mapping  # noqa: PLC0415

    gdf_rd = _read_cimlk_gdf(gpd, path, bbox)
    if gdf_rd is None or gdf_rd.empty:
        logger.info("No CIMLK wegvakken intersect the bbox.")
        return _empty_fc(), _empty_fc(), _skipped_stats("CIMLK")

    records = gdf_rd.drop(columns=gdf_rd.geometry.name).to_dict("records")
    geoms_rd = list(gdf_rd.geometry)

    heights_props: list[dict] = []
    asset_geoms_rd: list = []
    asset_props: list[dict] = []
    n_below = 0

    for raw, geom_rd in zip(records, geoms_rd, strict=True):
        if geom_rd is None or geom_rd.is_empty:
            continue
        props = normalize_props(raw)
        coords = list(geom_rd.coords)
        below = is_below_ground(coords, props["hMaaiveld"])
        if below:
            n_below += 1
        heights_props.append(props)

        # ── viaduct (keeps the 3D RD line; reprojected below) ────────────────
        v_height = viaduct_height_m(coords, props["hoogte"], props["hMaaiveld"])
        if v_height is not None:
            asset_geoms_rd.append(geom_rd)
            asset_props.append(viaduct_props(props, v_height, below))

        # ── noise screens (2D parallel offset in RD metres) ──────────────────
        line_2d = shapely.force_2d(geom_rd)
        for spec in screen_specs(props):
            distance = spec["afs"] if spec["side"] == "left" else -spec["afs"]
            try:
                offset = line_2d.offset_curve(distance)
            except Exception as exc:  # noqa: BLE001 — degenerate geometry, skip screen.
                logger.debug("screen offset failed for wvk %s: %s", props.get("wvkId"), exc)
                continue
            if offset.is_empty or offset.length == 0:
                continue
            asset_geoms_rd.append(offset)
            asset_props.append(screen_props(props, spec, below))

    # ── single reprojection pass RD → WGS-84 ─────────────────────────────────
    heights_features: list[dict] = []
    for geom_wgs, props in zip(gdf_rd.to_crs(TARGET_CRS).geometry, heights_props, strict=True):
        heights_features.append(
            {"type": "Feature", "geometry": mapping(geom_wgs), "properties": props}
        )

    asset_features: list[dict] = []
    if asset_geoms_rd:
        assets_wgs = gpd.GeoSeries(asset_geoms_rd, crs=SOURCE_CRS).to_crs(TARGET_CRS)
        for geom_wgs, props in zip(assets_wgs, asset_props, strict=True):
            asset_features.append(
                {"type": "Feature", "geometry": mapping(geom_wgs), "properties": props}
            )

    assets_fc = {
        "type": "FeatureCollection",
        "features": asset_features,
        "properties": {"_qv": CIMLK_QUERY_VER, "source": "CIMLK"},
    }
    heights_fc = {
        "type": "FeatureCollection",
        "features": heights_features,
        "properties": {"_qv": CIMLK_QUERY_VER, "source": "CIMLK"},
    }
    n_viaduct = sum(1 for p in asset_props if p["assetType"] == ASSET_TYPE_VIADUCT)
    n_screen = sum(1 for p in asset_props if p["assetType"] == ASSET_TYPE_SCREEN)
    stats = {
        "viaduct": n_viaduct,
        "screen": n_screen,
        "heights": len(heights_features),
        "belowGround": n_below,
        "source": "CIMLK",
    }
    logger.info(
        "CIMLK: %d wegvakken -> %d viaducts, %d screens (%d below ground)",
        len(heights_features),
        n_viaduct,
        n_screen,
        n_below,
    )
    return assets_fc, heights_fc, stats


def _read_cimlk_gdf(gpd: Any, path: str, bbox: list[float]):
    """Read the CIMLK shapefile and select wegvakken intersecting *bbox* (in RD).

    The bbox (WGS-84) is projected to RD via the shared polynomial so the fast
    ``.cx`` spatial index selects whole intersecting wegvakken without cutting
    geometry (preserving each 3D LineString and its Z).
    """
    from shared.rd_projection import wgs84_to_rd  # noqa: PLC0415

    gdf = gpd.read_file(path)
    if gdf.crs is None:
        gdf = gdf.set_crs(SOURCE_CRS)
    # Project the four bbox corners to RD and take their axis-aligned envelope.
    min_lon, min_lat, max_lon, max_lat = bbox
    corners = [
        wgs84_to_rd(min_lon, min_lat),
        wgs84_to_rd(min_lon, max_lat),
        wgs84_to_rd(max_lon, min_lat),
        wgs84_to_rd(max_lon, max_lat),
    ]
    xs = [c[0] for c in corners]
    ys = [c[1] for c in corners]
    return gdf.cx[min(xs) : max(xs), min(ys) : max(ys)]
