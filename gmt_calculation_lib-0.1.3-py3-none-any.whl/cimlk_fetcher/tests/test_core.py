"""Unit tests for cimlk_fetcher_core.

Pure-function tests need no shapefile; a single integration test writes a tiny
``.shp`` fixture and exercises the full ``fetch_cimlk`` read/derive/reproject path.
"""

from __future__ import annotations

import math

from cimlk_fetcher.core.cimlk_fetcher_core import (
    ASSET_TYPE_SCREEN,
    ASSET_TYPE_VIADUCT,
    CIMLK_QUERY_VER,
    fetch_cimlk,
    is_below_ground,
    normalize_props,
    screen_props,
    screen_specs,
    viaduct_height_m,
    viaduct_props,
)

# The fixture sits at RD (155000, 463000) ≈ WGS84 (5.387, 52.155); this bbox
# covers it (and its centroid lies inside the Netherlands).
_NL_BBOX = [5.35, 52.14, 5.42, 52.18]
_PARIS_BBOX = [2.2, 48.8, 2.4, 48.9]


# ---------------------------------------------------------------------------
# _clean_num / normalize_props — sentinel normalisation
# ---------------------------------------------------------------------------


def test_normalize_props_maps_sentinels_to_none() -> None:
    raw = {
        "WVK_ID": 600113621.0,
        "BST_CODE": "HR",
        "TUNNELFACT": 1.0,
        "HOOGTE": float("nan"),
        "TALUDSOORT": "zvz",
        "OVERDRLSRT": "nan",
        "OVERDRLAFS": -999,
        "OVERDRLHGT": -999,
        "OVERDRRSRT": "s",
        "OVERDRRAFS": 8,
        "OVERDRRHGT": 4,
        "H_NWB": 5.0,
        "H_MAAIVELD": -0.98,
        "BETR_TALUD": -99,
    }
    p = normalize_props(raw)
    assert p["wvkId"] == "600113621"  # ".0" stripped
    assert p["bstCode"] == "HR"
    assert p["tunnelfact"] == 1.0
    assert p["hoogte"] is None  # NaN -> None
    assert p["taludsoort"] == "zvz"
    assert p["overdrlSrt"] is None  # "nan" -> None
    assert p["overdrlAfs"] is None  # -999 -> None
    assert p["overdrlHgt"] is None
    assert p["overdrrSrt"] == "s"
    assert p["overdrrAfs"] == 8.0
    assert p["overdrrHgt"] == 4.0
    assert p["hMaaiveld"] == -0.98


def test_normalize_props_blank_and_missing() -> None:
    p = normalize_props({"WVK_ID": None, "BST_CODE": "", "HOOGTE": ""})
    assert p["wvkId"] is None
    assert p["bstCode"] is None
    assert p["hoogte"] is None


# ---------------------------------------------------------------------------
# viaduct_height_m — elevation criterion
# ---------------------------------------------------------------------------


def test_viaduct_from_explicit_hoogte() -> None:
    coords = [(0.0, 0.0, 2.0), (1.0, 0.0, 2.0)]
    assert viaduct_height_m(coords, hoogte=6.0, h_maaiveld=0.0) == 6.0


def test_viaduct_from_z_above_maaiveld() -> None:
    coords = [(0.0, 0.0, 5.0), (1.0, 0.0, 5.0)]
    # median Z 5.0, maaiveld 0.5 -> diff 4.5 > 1.0 -> viaduct
    assert viaduct_height_m(coords, hoogte=None, h_maaiveld=0.5) == 4.5


def test_flat_road_is_not_a_viaduct() -> None:
    coords = [(0.0, 0.0, 0.4), (1.0, 0.0, 0.6)]
    assert viaduct_height_m(coords, hoogte=None, h_maaiveld=0.5) is None
    assert viaduct_height_m(coords, hoogte=0.0, h_maaiveld=None) is None


# ---------------------------------------------------------------------------
# is_below_ground
# ---------------------------------------------------------------------------


def test_below_ground_true_when_z_under_maaiveld() -> None:
    coords = [(0.0, 0.0, -4.0), (1.0, 0.0, -4.0)]
    assert is_below_ground(coords, h_maaiveld=0.0) is True


def test_below_ground_false_at_grade_or_unknown() -> None:
    coords = [(0.0, 0.0, 0.2), (1.0, 0.0, 0.2)]
    assert is_below_ground(coords, h_maaiveld=0.0) is False
    assert is_below_ground([(0.0, 0.0), (1.0, 0.0)], h_maaiveld=0.0) is False
    assert is_below_ground(coords, h_maaiveld=None) is False


# ---------------------------------------------------------------------------
# screen_specs — per-side screen detection
# ---------------------------------------------------------------------------


def test_screen_specs_both_sides() -> None:
    props = {
        "overdrlSrt": "scherm",
        "overdrlAfs": 8.0,
        "overdrlHgt": 4.0,
        "overdrrSrt": "wal",
        "overdrrAfs": 12.0,
        "overdrrHgt": 2.0,
    }
    specs = screen_specs(props)
    assert {s["side"] for s in specs} == {"left", "right"}
    left = next(s for s in specs if s["side"] == "left")
    assert left["afs"] == 8.0
    assert left["heightM"] == 4.0
    assert left["screenKind"] == "scherm"


def test_screen_specs_skips_sentinel_distance() -> None:
    props = {
        "overdrlSrt": "scherm",
        "overdrlAfs": None,
        "overdrlHgt": None,
        "overdrrSrt": None,
        "overdrrAfs": None,
        "overdrrHgt": None,
    }
    assert screen_specs(props) == []


# ---------------------------------------------------------------------------
# property builders — camelCase contract
# ---------------------------------------------------------------------------


def test_viaduct_and_screen_props_are_camelcase() -> None:
    base = {"wvkId": "42", "bstCode": "HR"}
    vp = viaduct_props(base, height_m=6.0, below_ground=False)
    assert vp == {
        "assetType": ASSET_TYPE_VIADUCT,
        "heightM": 6.0,
        "belowGround": False,
        "wvkId": "42",
        "bstCode": "HR",
    }
    spec = {"side": "left", "afs": 8.0, "heightM": 4.0, "screenKind": "scherm"}
    sp = screen_props(base, spec, below_ground=False)
    assert sp == {
        "assetType": ASSET_TYPE_SCREEN,
        "side": "left",
        "heightM": 4.0,
        "screenKind": "scherm",
        "belowGround": False,
        "wvkId": "42",
    }


# ---------------------------------------------------------------------------
# fetch_cimlk — no-op guards
# ---------------------------------------------------------------------------


def test_fetch_cimlk_noop_without_source(monkeypatch) -> None:
    monkeypatch.delenv("CIMLK_PATH", raising=False)
    assets_fc, heights_fc, stats = fetch_cimlk(_NL_BBOX)
    assert assets_fc["features"] == []
    assert heights_fc["features"] == []
    assert stats["source"] == "skipped"
    assert assets_fc["properties"]["_qv"] == CIMLK_QUERY_VER


def test_fetch_cimlk_skips_outside_nl(tmp_path, monkeypatch) -> None:
    # Even with a valid file, an outside-NL bbox short-circuits before reading.
    shp = _write_fixture_shapefile(tmp_path)
    monkeypatch.setenv("CIMLK_PATH", str(shp))
    _assets, _heights, stats = fetch_cimlk(_PARIS_BBOX)
    assert stats["source"] == "skipped"


# ---------------------------------------------------------------------------
# fetch_cimlk — full integration against a tiny shapefile fixture
# ---------------------------------------------------------------------------


def _write_fixture_shapefile(tmp_path):
    """Write a 2-wegvak CIMLK-like shapefile (EPSG:28992, LineString Z)."""
    import geopandas as gpd
    from shapely.geometry import LineString

    # Amersfoort origin (RD ~155000, 463000) ≈ WGS84 (5.387, 52.155) — inside NL.
    x0, y0 = 155000.0, 463000.0
    # Feature 0: an elevated viaduct WITH a left screen.
    via = LineString([(x0, y0, 6.0), (x0 + 40, y0, 6.0), (x0 + 80, y0, 6.0)])
    # Feature 1: a flat at-grade road, no screens, no elevation.
    flat = LineString([(x0, y0 + 200, 0.3), (x0 + 60, y0 + 200, 0.4)])
    gdf = gpd.GeoDataFrame(
        {
            "WVK_ID": [111, 222],
            "BST_CODE": ["HR", "HR"],
            "TUNNELFACT": [1.0, 1.0],
            "HOOGTE": [6.0, None],
            "TALUDSOORT": ["zvz", None],
            "OVERDRLSRT": ["scherm", None],
            "OVERDRLAFS": [8.0, -999.0],
            "OVERDRLHGT": [4.0, -999.0],
            "OVERDRRSRT": [None, None],
            "OVERDRRAFS": [-999.0, -999.0],
            "OVERDRRHGT": [-999.0, -999.0],
            "H_NWB": [6.0, 0.3],
            "H_MAAIVELD": [0.0, 0.3],
            "geometry": [via, flat],
        },
        crs="EPSG:28992",
    )
    shp = tmp_path / "cimlk_fixture.shp"
    gdf.to_file(shp)
    return shp


def test_fetch_cimlk_integration(tmp_path, monkeypatch) -> None:
    shp = _write_fixture_shapefile(tmp_path)
    monkeypatch.setenv("CIMLK_PATH", str(shp))

    assets_fc, heights_fc, stats = fetch_cimlk(_NL_BBOX)

    # Both wegvakken land in HEIGHTS; one viaduct + one screen in assets.
    assert stats["source"] == "CIMLK"
    assert stats["heights"] == 2
    assert stats["viaduct"] == 1
    assert stats["screen"] == 1

    # Output is WGS-84 (lon ~5.39, lat ~52.15) and Z is preserved on the viaduct.
    types = sorted(f["properties"]["assetType"] for f in assets_fc["features"])
    assert types == [ASSET_TYPE_SCREEN, ASSET_TYPE_VIADUCT]

    viaduct = next(
        f for f in assets_fc["features"] if f["properties"]["assetType"] == ASSET_TYPE_VIADUCT
    )
    first = viaduct["geometry"]["coordinates"][0]
    assert 3.0 < first[0] < 7.5  # lon in NL range
    assert 50.5 < first[1] < 53.7  # lat in NL range
    assert len(first) == 3  # Z preserved
    assert math.isclose(first[2], 6.0, abs_tol=1e-6)
    assert viaduct["properties"]["heightM"] == 6.0
    assert viaduct["properties"]["wvkId"] == "111"

    screen = next(
        f for f in assets_fc["features"] if f["properties"]["assetType"] == ASSET_TYPE_SCREEN
    )
    assert screen["properties"]["side"] == "left"
    assert screen["properties"]["heightM"] == 4.0
    assert screen["properties"]["screenKind"] == "scherm"

    # HEIGHTS carries tunnelfact + 3D geometry.
    h0 = heights_fc["features"][0]
    assert "tunnelfact" in h0["properties"]
    assert len(h0["geometry"]["coordinates"][0]) == 3
