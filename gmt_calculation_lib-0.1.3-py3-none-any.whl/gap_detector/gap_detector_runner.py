"""Local debug runner for gap_detector.

Reads a NETWORK-SIMPLE bidirectional GeoJSON FeatureCollection and detects
physical gaps between non-connected near-collinear links.

By default only gap detection is performed and results are written to
``--gaps-file``.  Pass ``--repair`` to also insert bridging links and write
the repaired network to ``--output-file``.

Usage
-----
    # Detect only (default):
    python -m gap_detector.gap_detector_runner \\
        --network-file /path/to/{areaId}-NETWORK-SIMPLE-CAR.geojson \\
        --gaps-file    /path/to/{areaId}-GAPS-CAR.json

    # Detect and repair:
    python -m gap_detector.gap_detector_runner \\
        --network-file /path/to/{areaId}-NETWORK-SIMPLE-CAR.geojson \\
        --output-file  /path/to/{areaId}-NETWORK-SIMPLE-CAR.geojson \\
        --gaps-file    /path/to/{areaId}-GAPS-CAR.geojson \\
        --repair

    # With custom thresholds:
    python -m gap_detector.gap_detector_runner \\
        --network-file /path/to/network.geojson \\
        --output-file  /path/to/network.geojson \\
        --repair \\
        --max-distance 30 \\
        --max-angle    20
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Detect physical gaps in a NETWORK-SIMPLE bidirectional GeoJSON. "
            "By default only detection is performed and results are written to "
            "--gaps-file.  Pass --repair to also insert bridging links and write "
            "the repaired network to --output-file."
        )
    )
    parser.add_argument(
        "--network-file", required=True, metavar="URI",
        help="URI of the input NETWORK-SIMPLE GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--repair", action="store_true", default=False,
        help="Insert bridging links for detected gaps and write the repaired network.",
    )
    parser.add_argument(
        "--output-file", default=None, metavar="URI",
        help=(
            "URI for the repaired NETWORK-SIMPLE GeoJSON output (s3:// or local path). "
            "Required when --repair is set."
        ),
    )
    parser.add_argument(
        "--gaps-file", default=None, metavar="URI",
        help=(
            "Optional URI for a JSON file containing the detected gaps as "
            "link-inserter change objects.  Not written when omitted."
        ),
    )
    parser.add_argument(
        "--max-distance", type=float, default=50.0, metavar="METRES",
        help="Maximum physical break distance to consider a gap (default: 50 m).",
    )
    parser.add_argument(
        "--max-angle", type=float, default=30.0, metavar="DEGREES",
        help="Maximum heading difference to consider links co-directional (default: 30°).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    if args.repair and not args.output_file:
        parser.error("--output-file is required when --repair is set.")

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gap_detector.core.gap_detector_core import detect_gaps, gaps_to_changes, repair_network_gaps  # noqa: PLC0415

    print(f"Reading  : {args.network_file}")
    fc: dict = json.loads(_read_uri(args.network_file))
    n_links = len(fc.get("features") or [])
    print(f"Links    : {n_links}")
    print(f"Max dist : {args.max_distance} m")
    print(f"Max angle: {args.max_angle}°")
    print(f"Repair   : {'yes' if args.repair else 'no (detect only)'}")

    if args.repair:
        repaired_fc, added_links_fc = repair_network_gaps(
            fc,
            max_distance_m=args.max_distance,
            max_angle_deg=args.max_angle,
        )
        n_added = added_links_fc["properties"]["totalAdded"]
        print(f"Bridges  : {n_added} added")
        print(f"Links out: {len(repaired_fc.get('features') or [])}")
        print(f"Writing  : {args.output_file}")
        _write_uri(
            args.output_file,
            json.dumps(repaired_fc, ensure_ascii=False, indent=2).encode("utf-8"),
        )
        gaps_changes = gaps_to_changes(added_links_fc["features"], fc.get("features") or [])
    else:
        gap_features = detect_gaps(
            fc.get("features") or [],
            max_distance_m=args.max_distance,
            max_angle_deg=args.max_angle,
        )
        n_gaps = len(gap_features)
        print(f"Gaps     : {n_gaps} detected")
        gaps_changes = gaps_to_changes(gap_features, fc.get("features") or [])

    if args.gaps_file:
        print(f"Writing  : {args.gaps_file}  (gaps)")
        _write_uri(
            args.gaps_file,
            json.dumps(gaps_changes, ensure_ascii=False, indent=2).encode("utf-8"),
        )

    print("Done.")


if __name__ == "__main__":
    main()
