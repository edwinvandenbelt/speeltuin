"""gap_detector — detects physical gaps between non-connected near-collinear network links."""
