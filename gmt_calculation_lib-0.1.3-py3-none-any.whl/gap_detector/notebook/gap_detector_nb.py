# Databricks notebook source
# ---------------------------------------------------------------------------
# gap_detector_nb.py — Databricks notebook interface for network gap detection.
#
# This notebook:
#   1. Reads widget parameters (network_uri, mode, optional output_uri).
#   2. Reads the network GeoJSON (s3:// or local path).
#   3. Calls pure core functions (detect_network_gaps or repair_network_gaps).
#   4. Writes the output GeoJSON back to output_uri (or overwrites network_uri).
#   5. Prints a summary of detected / repaired gaps.
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("gap_detector_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uri", "",
    "Full URI of the input network GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri", "",
    "Full URI for the output GeoJSON (leave blank to overwrite network_uri)",
)
dbutils.widgets.dropdown(  # noqa: F821
    "mode", "detect",
    ["detect", "repair"],
    "Operation mode: detect (gaps FC) or repair (repaired network FC)",
)
dbutils.widgets.text(  # noqa: F821
    "max_distance_m", "50",
    "Maximum gap width in metres to detect/repair (default 50)",
)
dbutils.widgets.text(  # noqa: F821
    "max_angle_deg", "30",
    "Maximum heading difference in degrees (default 30)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from gap_detector.core.gap_detector_core import detect_network_gaps, repair_network_gaps

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip() or NETWORK_URI  # noqa: F821
MODE = dbutils.widgets.get("mode").strip()  # noqa: F821
MAX_DISTANCE_M = float(dbutils.widgets.get("max_distance_m").strip() or "50")  # noqa: F821
MAX_ANGLE_DEG = float(dbutils.widgets.get("max_angle_deg").strip() or "30")  # noqa: F821

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty — provide a full network URI.")

logger.info(
    "network_uri=%s  output_uri=%s  mode=%s  max_distance_m=%s  max_angle_deg=%s",
    NETWORK_URI, OUTPUT_URI, MODE, MAX_DISTANCE_M, MAX_ANGLE_DEG,
)

# COMMAND ----------
# ── S3 helpers ────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Gap Detector
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
print(f"Starting  {_t_start.isoformat()}")
print(f"Mode      : {MODE}")
print()

_raw = _read_uri(NETWORK_URI)
_fc = json.loads(_raw)

if MODE == "repair":
    _output_fc, _added_links_fc = repair_network_gaps(
        _fc, max_distance_m=MAX_DISTANCE_M, max_angle_deg=MAX_ANGLE_DEG
    )
    _stats = _output_fc.get("properties") or {}
    _n_added = len(_added_links_fc.get("features") or [])
else:
    _output_fc = detect_network_gaps(_fc)
    _stats = _output_fc.get("properties") or {}
    _n_added = None

_payload = json.dumps(_output_fc, ensure_ascii=False).encode("utf-8")
_write_uri(OUTPUT_URI, _payload)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("Done in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"Gap detector complete — {_total_elapsed:.1f}s total")
print(_SEP)
print()
print(f"  Mode          : {MODE}")
print(f"  Input links   : {_stats.get('totalLinks', '?')}")

if MODE == "repair":
    print(f"  Bridges added : {_n_added}")
else:
    print(f"  Gaps found    : {_stats.get('totalGaps', '?')}")

print(f"  Output URI    : {OUTPUT_URI}")
print()
print(_SEP)
