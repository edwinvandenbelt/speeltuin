"""Unit tests for gap_detector.core.gap_detector_core — pure Python, no I/O."""
from __future__ import annotations

import pytest

from gap_detector.core.gap_detector_core import (
    _build_adjacency,
    _find_components,
    _segments_cross,
    detect_gaps,
    detect_network_gaps,
    gaps_to_changes,
    repair_network_gaps,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_link(
    link_id: str | int,
    from_node: int,
    to_node: int,
    coords: list,
    street_name: str | None = None,
) -> dict:
    props: dict = {"linkId": link_id, "fromNode": from_node, "toNode": to_node, "mode": "CAR"}
    if street_name is not None:
        props["streetName"] = street_name
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": props,
    }


def _make_bidir_link(
    link_id: int,
    from_node: int,
    to_node: int,
    coords: list,
    *,
    street_name: str | None = None,
    cap: int = 1800,
    lanes: int = 2,
    speed: int = 80,
) -> dict:
    """NETWORK-SIMPLE bidirectional feature."""
    _zero_motives = {"work": 0, "recreational": 0, "education": 0, "shopping": 0, "unknown": 0}
    _zero_dp = {"mrh": 0.0, "erh": 0.0, "rest": 0.0}
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "mode": "CAR",
            "fromNode": from_node,
            "toNode": to_node,
            "streetName": street_name,
            "rijrichting_heen": True,
            "cap_heen": cap,
            "rijstroken_heen": lanes,
            "max_snelheid_heen": speed,
            "flow_heen": dict(_zero_motives),
            "flow_dp_heen": dict(_zero_dp),
            "rijrichting_terug": True,
            "cap_terug": cap,
            "rijstroken_terug": lanes,
            "max_snelheid_terug": speed,
            "flow_terug": dict(_zero_motives),
            "flow_dp_terug": dict(_zero_dp),
            "length": 100.0,
        },
    }


# ---------------------------------------------------------------------------
# _find_components
# ---------------------------------------------------------------------------


class TestFindComponents:
    def test_single_edge_one_component(self):
        components = _find_components({1, 2}, [(1, 2)])
        assert len(components) == 1
        assert {1, 2} in components

    def test_two_disconnected_edges_two_components(self):
        components = _find_components({1, 2, 3, 4}, [(1, 2), (3, 4)])
        assert len(components) == 2

    def test_connected_chain_one_component(self):
        components = _find_components({1, 2, 3}, [(1, 2), (2, 3)])
        assert len(components) == 1

    def test_empty_graph(self):
        assert _find_components(set(), []) == []

    def test_isolated_node_is_own_component(self):
        components = _find_components({1, 2, 3}, [(1, 2)])
        assert len(components) == 2


# ---------------------------------------------------------------------------
# _build_adjacency — terug direction
# ---------------------------------------------------------------------------


class TestBuildAdjacencyTerug:
    def test_terug_direction_adds_reverse_edge(self):
        feat = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        adj = _build_adjacency([feat])
        assert 2 in adj[1]   # heen: 1 → 2
        assert 1 in adj[2]   # terug: 2 → 1

    def test_no_terug_flag_no_reverse_edge(self):
        feat = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        adj = _build_adjacency([feat])
        assert 2 in adj[1]
        assert 2 not in adj  # no reverse edge

    def test_terug_false_no_reverse_edge(self):
        feat = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        feat["properties"]["rijrichting_terug"] = False
        adj = _build_adjacency([feat])
        assert 2 not in adj


# ---------------------------------------------------------------------------
# detect_gaps — dangling-node + proximity + heading strategy
# ---------------------------------------------------------------------------


class TestDetectGaps:
    def test_empty_features_returns_empty(self):
        assert detect_gaps([]) == []

    def test_single_link_no_gap(self):
        """A single link has dangling nodes but no other link to pair with."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        assert detect_gaps([a]) == []

    def test_connected_chain_no_gap(self):
        """Shared node has degree 2 — not dangling — so no gap is reported."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 2, 3, [[4.001, 52.0], [4.0015, 52.0]])
        assert detect_gaps([a, b]) == []

    def test_dangling_nodes_gap_detected(self):
        """toNode of A and fromNode of B are both dangling and close → gap."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        gaps = detect_gaps([a, b])
        assert len(gaps) == 1

    def test_gap_feature_is_geojson_linestring(self):
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        gap = detect_gaps([a, b])[0]
        assert gap["type"] == "Feature"
        assert gap["geometry"]["type"] == "LineString"
        assert len(gap["geometry"]["coordinates"]) == 2

    def test_gap_properties_contain_required_fields(self):
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        gap = detect_gaps([a, b])[0]
        p = gap["properties"]
        assert "fromNode" in p
        assert "toNode" in p
        assert "distance_m" in p
        assert "angleDiff_deg" in p
        assert p["distance_m"] > 0

    def test_gap_connects_dangling_tonode_to_dangling_fromnode(self):
        """fromNode of gap = toNode of A; toNode of gap = fromNode of B."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        gap = detect_gaps([a, b])[0]
        assert {gap["properties"]["fromNode"], gap["properties"]["toNode"]} == {2, 3}

    def test_gap_geometry_uses_dangling_endpoint_coords(self):
        """Gap line connects the actual gap endpoints (not arbitrary nodes)."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        coords = detect_gaps([a, b])[0]["geometry"]["coordinates"]
        # tail = [4.001, 52.0], head = [4.0013, 52.0]
        assert coords[0] == pytest.approx([4.001, 52.0], abs=1e-6) or \
               coords[0] == pytest.approx([4.0013, 52.0], abs=1e-6)

    def test_distance_too_far_no_gap(self):
        """Nodes > max_distance_m apart are not reported."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.1, 52.0], [4.2, 52.0]])
        assert detect_gaps([a, b], max_distance_m=50.0) == []

    def test_angle_too_different_no_gap(self):
        """Links heading in opposite directions (> max_angle_deg) are not paired."""
        # A goes East, B goes West — 180° apart
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.0003, 52.0]])  # going West
        assert detect_gaps([a, b], max_angle_deg=30.0) == []

    def test_no_dangling_tail_no_gap(self):
        """When toNode of A has degree > 1, A provides no dangling tail."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        # extra link that also touches node 2, raising its degree
        c = _make_link("C", 5, 2, [[4.002, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        gaps = detect_gaps([a, c, b])
        # node 2 has degree 2; node 5 toNode has degree 1 → gap 5→3 might exist
        # but the *original* a→b gap (node2→node3) must not appear
        for gap in gaps:
            assert {gap["properties"]["fromNode"], gap["properties"]["toNode"]} != {2, 3}

    def test_already_connected_no_gap(self):
        """Nodes already connected via another link are not reported."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        bridge = _make_link("X", 2, 3, [[4.001, 52.0], [4.0013, 52.0]])
        assert detect_gaps([a, b, bridge]) == []

    def test_no_street_name_gap_still_detected(self):
        """streetName is not required — dangling-node check is the primary criterion."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        gaps = detect_gaps([a, b])
        assert len(gaps) == 1

    def test_street_name_inherited_in_gap_properties(self):
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]], street_name="Kerkstraat")
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]], street_name="Kerkstraat")
        gap = detect_gaps([a, b])[0]
        assert gap["properties"]["streetName"] == "Kerkstraat"

    def test_two_separate_gap_pairs(self):
        """Two independent gaps (different street, different location)."""
        a1 = _make_link("A1", 1, 2, [[4.0, 52.0], [4.001, 52.0]], street_name="Straat A")
        a2 = _make_link("A2", 3, 4, [[4.0013, 52.0], [4.003, 52.0]], street_name="Straat A")
        b1 = _make_link("B1", 5, 6, [[4.0, 52.1], [4.001, 52.1]], street_name="Straat B")
        b2 = _make_link("B2", 7, 8, [[4.0013, 52.1], [4.003, 52.1]], street_name="Straat B")
        gaps = detect_gaps([a1, a2, b1, b2])
        assert len(gaps) == 2
        streets = {g["properties"]["streetName"] for g in gaps}
        assert streets == {"Straat A", "Straat B"}

    def test_three_links_two_dangling_gaps(self):
        """A → [gap] → B → [gap] → C: two gaps where each is within 50 m."""
        # spacing 0.0005° ≈ 34 m, well within 50 m default
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.0005, 52.0]])
        b = _make_link("B", 3, 4, [[4.001, 52.0], [4.0015, 52.0]])
        c = _make_link("C", 5, 6, [[4.002, 52.0], [4.0025, 52.0]])
        gaps = detect_gaps([a, b, c])
        # toNode(A)=2 → fromNode(B)=3 and toNode(B)=4 → fromNode(C)=5
        assert len(gaps) == 2

    def test_no_duplicate_gap_for_same_node_pair(self):
        """Each unordered node pair is reported at most once."""
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        gaps = detect_gaps([a, b])
        pairs = [frozenset({g["properties"]["fromNode"], g["properties"]["toNode"]}) for g in gaps]
        assert len(pairs) == len(set(pairs))


# ---------------------------------------------------------------------------
# detect_network_gaps
# ---------------------------------------------------------------------------


class TestDetectNetworkGaps:
    def test_returns_feature_collection(self):
        fc = {"type": "FeatureCollection", "features": [
            _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]]),
        ]}
        result = detect_network_gaps(fc)
        assert result["type"] == "FeatureCollection"
        assert "features" in result
        assert "properties" in result

    def test_summary_properties_present(self):
        fc = {"type": "FeatureCollection", "features": []}
        result = detect_network_gaps(fc)
        assert "totalLinks" in result["properties"]
        assert "totalGaps" in result["properties"]

    def test_gap_detected_in_fc(self):
        features = [
            _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]]),
            _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]]),
        ]
        fc = {"type": "FeatureCollection", "features": features}
        result = detect_network_gaps(fc)
        assert result["properties"]["totalGaps"] == 1

    def test_no_gap_connected_links(self):
        features = [
            _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]]),
            _make_link("B", 2, 3, [[4.001, 52.0], [4.002, 52.0]]),
        ]
        fc = {"type": "FeatureCollection", "features": features}
        result = detect_network_gaps(fc)
        assert result["properties"]["totalGaps"] == 0

    def test_empty_fc(self):
        fc = {"type": "FeatureCollection", "features": []}
        result = detect_network_gaps(fc)
        assert result["properties"]["totalLinks"] == 0
        assert result["properties"]["totalGaps"] == 0


# ---------------------------------------------------------------------------
# repair_network_gaps
# ---------------------------------------------------------------------------


class TestRepairNetworkGaps:
    def test_returns_two_feature_collections(self):
        fc = {"type": "FeatureCollection", "features": []}
        repaired, added = repair_network_gaps(fc)
        assert repaired["type"] == "FeatureCollection"
        assert added["type"] == "FeatureCollection"

    def test_no_gap_no_bridge(self):
        a = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_bidir_link(2, 2, 3, [[4.001, 52.0], [4.002, 52.0]])
        fc = {"type": "FeatureCollection", "features": [a, b]}
        repaired, added = repair_network_gaps(fc)
        assert added["properties"]["totalAdded"] == 0
        assert len(repaired["features"]) == 2

    def test_gap_produces_one_bridge(self):
        a = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_bidir_link(2, 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        fc = {"type": "FeatureCollection", "features": [a, b]}
        repaired, added = repair_network_gaps(fc)
        assert added["properties"]["totalAdded"] == 1
        assert len(repaired["features"]) == 3

    def test_no_street_name_still_produces_bridge(self):
        """Links without streetName can still receive a bridge via dangling-node detection."""
        a = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_bidir_link(2, 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        fc = {"type": "FeatureCollection", "features": [a, b]}
        _, added = repair_network_gaps(fc)
        assert added["properties"]["totalAdded"] == 1

    def test_gap_wider_than_max_distance_not_bridged(self):
        a = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_bidir_link(2, 3, 4, [[4.1, 52.0], [4.2, 52.0]])
        fc = {"type": "FeatureCollection", "features": [a, b]}
        _, added = repair_network_gaps(fc, max_distance_m=50.0)
        assert added["properties"]["totalAdded"] == 0

    def test_bridge_link_id_is_max_plus_one(self):
        a = _make_bidir_link(10, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_bidir_link(20, 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        fc = {"type": "FeatureCollection", "features": [a, b]}
        _, added = repair_network_gaps(fc)
        assert added["features"][0]["properties"]["linkId"] == 21

    def test_bridge_nodes_connect_gap(self):
        a = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_bidir_link(2, 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        fc = {"type": "FeatureCollection", "features": [a, b]}
        _, added = repair_network_gaps(fc)
        bp = added["features"][0]["properties"]
        assert {bp["fromNode"], bp["toNode"]} == {2, 3}

    def test_bridge_is_bidirectional(self):
        a = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_bidir_link(2, 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        fc = {"type": "FeatureCollection", "features": [a, b]}
        _, added = repair_network_gaps(fc)
        bp = added["features"][0]["properties"]
        assert bp["rijrichting_heen"] is True
        assert bp["rijrichting_terug"] is True

    def test_bridge_flows_are_zero(self):
        a = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_bidir_link(2, 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        fc = {"type": "FeatureCollection", "features": [a, b]}
        _, added = repair_network_gaps(fc)
        bp = added["features"][0]["properties"]
        assert all(v == 0 for v in bp["flow_heen"].values())
        assert all(v == 0 for v in bp["flow_terug"].values())

    def test_reverse_link_prevents_bridge(self):
        """Nodes already connected via any direction must not receive a bridge."""
        a = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_bidir_link(2, 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        rev = _make_bidir_link(3, 3, 2, [[4.0013, 52.0], [4.001, 52.0]])
        fc = {"type": "FeatureCollection", "features": [a, b, rev]}
        _, added = repair_network_gaps(fc)
        assert added["properties"]["totalAdded"] == 0

    def test_added_links_fc_has_total_added_property(self):
        fc = {"type": "FeatureCollection", "features": []}
        _, added = repair_network_gaps(fc)
        assert "totalAdded" in added["properties"]
        assert added["properties"]["totalAdded"] == 0


# ---------------------------------------------------------------------------
# _segments_cross
# ---------------------------------------------------------------------------


class TestSegmentsCross:
    def test_proper_crossing_detected(self):
        # + shape: horizontal segment (0,1)-(2,1) crosses vertical (1,0)-(1,2)
        assert _segments_cross((0.0, 1.0), (2.0, 1.0), (1.0, 0.0), (1.0, 2.0)) is True

    def test_parallel_segments_not_crossing(self):
        assert _segments_cross((0.0, 0.0), (2.0, 0.0), (0.0, 1.0), (2.0, 1.0)) is False

    def test_t_junction_endpoint_on_line_not_crossing(self):
        # q shares endpoint with p (p2 == q1); not a proper crossing
        assert _segments_cross((0.0, 0.0), (1.0, 1.0), (1.0, 1.0), (2.0, 0.0)) is False

    def test_non_overlapping_collinear_not_crossing(self):
        assert _segments_cross((0.0, 0.0), (1.0, 0.0), (2.0, 0.0), (3.0, 0.0)) is False

    def test_shared_endpoint_not_crossing(self):
        assert _segments_cross((0.0, 0.0), (1.0, 1.0), (1.0, 1.0), (2.0, 0.0)) is False


# ---------------------------------------------------------------------------
# crossesExistingLink flag in detect_gaps
# ---------------------------------------------------------------------------


class TestDetectGapsCrossCheck:
    def _make_perpendicular_blocker(self) -> dict:
        """A blocker link that crosses the gap between node 2 (4.001,52.0) and node 3 (4.0013,52.0)."""
        # Gap is roughly East–West at lat 52.0; blocker runs North–South across it.
        mid_lon = (4.001 + 4.0013) / 2
        return _make_link("X", 99, 100, [
            [mid_lon, 51.9999],
            [mid_lon, 52.0001],
        ])

    def test_crossing_link_is_flagged(self):
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        blocker = self._make_perpendicular_blocker()
        gaps = detect_gaps([a, b, blocker])
        assert len(gaps) == 1
        assert gaps[0]["properties"]["crossesExistingLink"] is True

    def test_non_crossing_link_not_flagged(self):
        a = _make_link("A", 1, 2, [[4.0, 52.0], [4.001, 52.0]])
        b = _make_link("B", 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        gaps = detect_gaps([a, b])
        assert len(gaps) == 1
        assert gaps[0]["properties"]["crossesExistingLink"] is False


# ---------------------------------------------------------------------------
# gaps_to_changes
# ---------------------------------------------------------------------------


class TestGapsToChanges:
    def _setup(self):
        net_feat = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]], cap=1800, lanes=2, speed=80)
        net_feat2 = _make_bidir_link(2, 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        network = [net_feat, net_feat2]
        gap_feats = detect_gaps(network)
        return gap_feats, network

    def test_returns_list_of_dicts(self):
        gap_feats, network = self._setup()
        changes = gaps_to_changes(gap_feats, network)
        assert isinstance(changes, list)
        assert all(isinstance(c, dict) for c in changes)

    def test_linkid_is_null(self):
        gap_feats, network = self._setup()
        changes = gaps_to_changes(gap_feats, network)
        assert changes[0]["linkId"] is None

    def test_geometry_is_linestring(self):
        gap_feats, network = self._setup()
        changes = gaps_to_changes(gap_feats, network)
        assert changes[0]["geometry"]["type"] == "LineString"
        assert len(changes[0]["geometry"]["coordinates"]) == 2

    def test_direction_is_both(self):
        gap_feats, network = self._setup()
        changes = gaps_to_changes(gap_feats, network)
        assert changes[0]["direction"] == "both"

    def test_speed_capacity_lanes_inherited_from_tail_feature(self):
        net_feat = _make_bidir_link(1, 1, 2, [[4.0, 52.0], [4.001, 52.0]], cap=1800, lanes=2, speed=80)
        net_feat2 = _make_bidir_link(2, 3, 4, [[4.0013, 52.0], [4.003, 52.0]])
        network = [net_feat, net_feat2]
        gap_feats = detect_gaps(network)
        changes = gaps_to_changes(gap_feats, network)
        # find the change whose fromNode == 2 (toNode of net_feat)
        c = next(ch for ch in changes if ch["fromNode"] == 2)
        assert c["speed"] == 80
        assert c["capacity"] == 1800
        assert c["lanes"] == 2

    def test_review_metadata_fields_present(self):
        gap_feats, network = self._setup()
        changes = gaps_to_changes(gap_feats, network)
        c = changes[0]
        assert "fromNode" in c
        assert "toNode" in c
        assert "distance_m" in c
        assert "angleDiff_deg" in c
        assert "streetName" in c
        assert "crossesExistingLink" in c

    def test_crosses_flag_propagated(self):
        gap_feats, network = self._setup()
        changes = gaps_to_changes(gap_feats, network)
        # crossesExistingLink should be a bool (False for a clean gap)
        assert isinstance(changes[0]["crossesExistingLink"], bool)

    def test_empty_gaps_returns_empty_list(self):
        assert gaps_to_changes([], []) == []
