"""Unit tests for geojson_feature_modifier_core — pure Python, no I/O."""

from __future__ import annotations

import pytest

from geojson_feature_modifier.core.geojson_feature_modifier_core import (
    _parse_value,
    modify_geojson,
)


# ---------------------------------------------------------------------------
# _parse_value
# ---------------------------------------------------------------------------

class TestParseValue:
    def test_positive_delta_int(self):
        assert _parse_value("+3", 10) == 13

    def test_negative_delta_int(self):
        assert _parse_value("-2", 10) == 8

    def test_positive_delta_float(self):
        assert _parse_value("+1.5", 10.0) == 11.5

    def test_negative_delta_float(self):
        assert _parse_value("-0.5", 2.0) == 1.5

    def test_delta_on_none_original(self):
        # Missing original treated as 0
        assert _parse_value("+5", None) == 5

    def test_overwrite_int(self):
        assert _parse_value("42", 99) == 42

    def test_overwrite_float(self):
        assert _parse_value("3.14", 0) == 3.14

    def test_overwrite_string(self):
        assert _parse_value("highway", "motorway") == "highway"

    def test_overwrite_zero_string(self):
        assert _parse_value("0", 5) == 0

    def test_result_is_int_when_whole(self):
        # +2.0 on 3.0 → 5, should come back as int 5
        result = _parse_value("+2", 3)
        assert result == 5
        assert isinstance(result, int)

    def test_invalid_delta_raises(self):
        with pytest.raises(ValueError, match="numeric"):
            _parse_value("+abc", 1)


# ---------------------------------------------------------------------------
# modify_geojson — happy path
# ---------------------------------------------------------------------------

def _make_fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features, "properties": {"bbox": []}}


def _feat(link_id: str, **props) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {"linkId": link_id, **props},
    }


class TestModifyGeoJsonHappyPath:
    def test_numeric_delta_applied(self):
        fc = _make_fc([_feat("1", flow=10)])
        result, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "flow": "+5"}])
        assert result["features"][0]["properties"]["flow"] == 15

    def test_numeric_overwrite(self):
        fc = _make_fc([_feat("1", flow=10)])
        result, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "flow": "99"}])
        assert result["features"][0]["properties"]["flow"] == 99

    def test_string_overwrite(self):
        fc = _make_fc([_feat("1", wegtype="local")])
        result, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "wegtype": "highway"}])
        assert result["features"][0]["properties"]["wegtype"] == "highway"

    def test_multiple_fields_in_one_change(self):
        fc = _make_fc([_feat("1", flow=5, speed=50)])
        result, stats = modify_geojson(
            fc, "linkId", [{"linkId": "1", "flow": "+10", "speed": "60"}]
        )
        props = result["features"][0]["properties"]
        assert props["flow"] == 15
        assert props["speed"] == 60

    def test_multiple_changes(self):
        fc = _make_fc([_feat("1", flow=5), _feat("2", flow=10)])
        changes = [{"linkId": "1", "flow": "+1"}, {"linkId": "2", "flow": "-2"}]
        result, stats = modify_geojson(fc, "linkId", changes)
        assert result["features"][0]["properties"]["flow"] == 6
        assert result["features"][1]["properties"]["flow"] == 8

    def test_all_matching_features_updated(self):
        # Two features with the same linkId — both should be updated
        fc = _make_fc([_feat("dup", flow=1), _feat("dup", flow=2)])
        result, stats = modify_geojson(fc, "linkId", [{"linkId": "dup", "flow": "+10"}])
        assert result["features"][0]["properties"]["flow"] == 11
        assert result["features"][1]["properties"]["flow"] == 12

    def test_unrelated_features_untouched(self):
        fc = _make_fc([_feat("1", flow=5), _feat("2", flow=10)])
        result, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "flow": "+1"}])
        assert result["features"][1]["properties"]["flow"] == 10

    def test_new_property_created_when_absent(self):
        fc = _make_fc([_feat("1")])
        result, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "newField": "hello"}])
        assert result["features"][0]["properties"]["newField"] == "hello"

    def test_fc_properties_preserved(self):
        fc = _make_fc([_feat("1")])
        fc["properties"]["custom"] = "value"
        result, _ = modify_geojson(fc, "linkId", [{"linkId": "1", "flow": "1"}])
        assert result["properties"]["custom"] == "value"


# ---------------------------------------------------------------------------
# modify_geojson — stats
# ---------------------------------------------------------------------------

class TestModifyGeoJsonStats:
    def test_stats_total(self):
        fc = _make_fc([_feat("1"), _feat("2")])
        _, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "flow": "1"}])
        assert stats["total"] == 2

    def test_stats_changes(self):
        fc = _make_fc([_feat("1")])
        _, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "flow": "1"}, {"linkId": "1", "speed": "50"}])
        assert stats["changes"] == 2

    def test_stats_modified(self):
        fc = _make_fc([_feat("1"), _feat("1")])  # two matching features
        _, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "flow": "+1"}])
        assert stats["modified"] == 2

    def test_stats_no_warnings_on_success(self):
        fc = _make_fc([_feat("1")])
        _, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "flow": "1"}])
        assert stats["warnings"] == []


# ---------------------------------------------------------------------------
# modify_geojson — warnings
# ---------------------------------------------------------------------------

class TestModifyGeoJsonWarnings:
    def test_unmatched_change_produces_warning(self):
        fc = _make_fc([_feat("1")])
        _, stats = modify_geojson(fc, "linkId", [{"linkId": "999", "flow": "+1"}])
        assert len(stats["warnings"]) == 1
        assert "999" in stats["warnings"][0]

    def test_change_missing_match_field_produces_warning(self):
        fc = _make_fc([_feat("1")])
        _, stats = modify_geojson(fc, "linkId", [{"flow": "+1"}])
        assert len(stats["warnings"]) == 1

    def test_change_with_only_match_field_produces_warning(self):
        fc = _make_fc([_feat("1")])
        _, stats = modify_geojson(fc, "linkId", [{"linkId": "1"}])
        assert len(stats["warnings"]) == 1

    def test_non_dict_change_produces_warning(self):
        fc = _make_fc([_feat("1")])
        _, stats = modify_geojson(fc, "linkId", ["not-a-dict"])  # type: ignore[list-item]
        assert len(stats["warnings"]) == 1

    def test_unmatched_does_not_modify_features(self):
        fc = _make_fc([_feat("1", flow=5)])
        result, _ = modify_geojson(fc, "linkId", [{"linkId": "999", "flow": "+1"}])
        assert result["features"][0]["properties"]["flow"] == 5


# ---------------------------------------------------------------------------
# modify_geojson — error cases
# ---------------------------------------------------------------------------

class TestModifyGeoJsonErrors:
    def test_empty_match_field_raises(self):
        fc = _make_fc([_feat("1")])
        with pytest.raises(ValueError, match="match_field"):
            modify_geojson(fc, "", [{"linkId": "1", "flow": "1"}])

    def test_non_list_changes_raises(self):
        fc = _make_fc([_feat("1")])
        with pytest.raises(TypeError, match="list"):
            modify_geojson(fc, "linkId", {"linkId": "1", "flow": "1"})  # type: ignore[arg-type]

    def test_empty_fc_returns_zero_total(self):
        fc = {"type": "FeatureCollection", "features": [], "properties": {}}
        result, stats = modify_geojson(fc, "linkId", [{"linkId": "1", "flow": "1"}])
        assert stats["total"] == 0
        assert len(stats["warnings"]) == 1  # unmatched

    def test_different_match_field(self):
        fc = _make_fc([{
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0, 0]},
            "properties": {"zoneId": "Z1", "area": 100},
        }])
        result, stats = modify_geojson(fc, "zoneId", [{"zoneId": "Z1", "area": "+50"}])
        assert result["features"][0]["properties"]["area"] == 150
        assert stats["warnings"] == []
