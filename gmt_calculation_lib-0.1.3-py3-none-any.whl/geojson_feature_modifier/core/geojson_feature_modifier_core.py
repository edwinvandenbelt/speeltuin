"""Pure-Python GeoJSON feature modifier core — no I/O, no boto3, no external deps.

Applies a list of changes to a GeoJSON FeatureCollection.  Each change object
identifies one or more features by a match field and updates one or more of
their properties.

Value syntax
------------
* ``"+3"`` / ``"-1.5"``  — numeric delta: add/subtract from the existing value
  (existing value is treated as 0 when absent).
* ``"42"`` / ``"3.14"``  — overwrite with a number.
* ``"highway"``          — overwrite with a string (any value without a
  leading ``+`` or ``-`` that cannot be parsed as a number).

Public API
----------
modify_geojson(fc, match_field, changes) -> tuple[dict, dict]
    Apply changes to a FeatureCollection.
    Returns (modified_fc, stats).
    stats: {"total": int, "changes": int, "modified": int, "warnings": list[str]}
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def _parse_value(value_str: str, original: object) -> int | float | str:
    """Translate a change value string into the new property value.

    Parameters
    ----------
    value_str:
        The raw string from the change object.
    original:
        The current value of the property on the feature (may be ``None``).

    Returns
    -------
    The new value to assign to the property.
    """
    s = str(value_str)

    # Delta mode: leading + or -
    if s and s[0] in ("+", "-"):
        try:
            delta = float(s)
        except ValueError as exc:
            raise ValueError(
                f"Cannot parse delta value {s!r}: expected a numeric string with a leading + or -."
            ) from exc
        base = float(original) if original is not None else 0.0
        result = base + delta
        # Preserve integer type when the result is whole
        if result == int(result):
            return int(result)
        return result

    # Overwrite mode: try int, float, fall back to string
    try:
        return int(s)
    except ValueError:
        pass
    try:
        return float(s)
    except ValueError:
        pass
    return s


def modify_geojson(
    fc: dict,
    match_field: str,
    changes: list[dict],
) -> tuple[dict, dict]:
    """Apply a list of changes to a GeoJSON FeatureCollection.

    Parameters
    ----------
    fc:
        A GeoJSON FeatureCollection dict.  Modified in place (features list
        items are mutated); a new top-level dict is returned.
    match_field:
        The property name used to identify which features to update,
        e.g. ``"linkId"``.
    changes:
        A list of change objects.  Each must contain a key equal to
        *match_field* (the match value) plus one or more additional keys
        (the fields to update with their new value strings).

    Returns
    -------
    modified_fc:
        The FeatureCollection with updated feature properties.
    stats:
        ``{"total": int, "changes": int, "modified": int, "warnings": list[str]}``
    """
    if not match_field:
        raise ValueError("match_field must be a non-empty string.")
    if not isinstance(changes, list):
        raise TypeError("changes must be a list of objects.")

    features: list[dict] = fc.get("features") or []

    # Build a lookup index: str(match_value) -> [feature_index, ...]
    index: dict[str, list[int]] = {}
    for i, feat in enumerate(features):
        props = (feat.get("properties") or {})
        mv = props.get(match_field)
        if mv is not None:
            index.setdefault(str(mv), []).append(i)

    warnings: list[str] = []
    modified = 0

    for change in changes:
        if not isinstance(change, dict):
            warnings.append(f"Skipping non-dict change entry: {change!r}")
            continue

        match_value = change.get(match_field)
        if match_value is None:
            warnings.append(
                f"Change object has no '{match_field}' key — skipping: {change}"
            )
            continue

        key = str(match_value)
        matched_indices = index.get(key, [])

        if not matched_indices:
            warnings.append(
                f"No features matched {match_field}={match_value!r} — change skipped."
            )
            continue

        update_fields = {k: v for k, v in change.items() if k != match_field}
        if not update_fields:
            warnings.append(
                f"Change for {match_field}={match_value!r} has no update fields — skipping."
            )
            continue

        for i in matched_indices:
            props = features[i].setdefault("properties", {})
            for field, value_str in update_fields.items():
                try:
                    props[field] = _parse_value(str(value_str), props.get(field))
                except ValueError as exc:
                    warnings.append(
                        f"Field '{field}' on {match_field}={match_value!r}: {exc}"
                    )
            modified += 1

    if warnings:
        for w in warnings:
            logger.warning(w)

    logger.info(
        "modify_geojson complete: %d features, %d changes, %d feature-updates applied, %d warnings",
        len(features), len(changes), modified, len(warnings),
    )

    modified_fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": fc.get("properties"),
    }
    stats: dict = {
        "total": len(features),
        "changes": len(changes),
        "modified": modified,
        "warnings": warnings,
    }
    return modified_fc, stats
