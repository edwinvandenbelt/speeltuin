"""Local debug runner for geojson_feature_modifier.

Calls geojson_feature_modifier_core.modify_geojson() directly — no Lambda handler involved.

Usage
-----
    # S3:
    python -m geojson_feature_modifier.geojson_feature_modifier_runner \\
        --input  s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.parquet \\
        --output s3://gmp-networks/network/deventer-centrum-NETWORK-CAR-modified.parquet \\
        --match-field linkId \\
        --changes '[{"linkId": "342", "flow": "+3"}, {"linkId": "500", "wegtype": "highway"}]'

    # Local files:
    python -m geojson_feature_modifier.geojson_feature_modifier_runner \\
        --input  /tmp/network.parquet \\
        --output /tmp/network-modified.parquet \\
        --match-field linkId \\
        --changes /path/to/changes.json

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Changes loader
# ---------------------------------------------------------------------------

def _load_changes(changes_arg: str) -> list[dict]:
    p = Path(changes_arg)
    if p.exists() and p.is_file():
        return json.loads(p.read_text(encoding="utf-8"))
    return json.loads(changes_arg)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for geojson_feature_modifier (calls core directly)."
    )
    parser.add_argument("--input",  required=True, help="Input URI: s3://… or file path.")
    parser.add_argument("--output", required=True, help="Output URI: s3://… or file path.")
    parser.add_argument(
        "--match-field", required=True,
        help="Feature property name used to identify features (e.g. linkId).",
    )
    parser.add_argument(
        "--changes", required=True,
        help="Change list as inline JSON array or path to a .json file.",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    # Parse changes
    try:
        changes = _load_changes(args.changes)
    except (json.JSONDecodeError, ValueError) as exc:
        print(f"[error] Could not parse --changes: {exc}", file=sys.stderr)
        sys.exit(1)

    from geojson_feature_modifier.core.geojson_feature_modifier_core import modify_geojson  # noqa: PLC0415
    from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

    # Read input
    print(f"Reading  : {args.input}")
    fc = from_geoparquet(_read_uri(args.input))

    # Call core
    modified_fc, stats = modify_geojson(fc, args.match_field, changes)

    # Write output
    print(f"Writing  : {args.output}")
    _write_uri(args.output, to_geoparquet(modified_fc))

    print()
    print(f"Total    : {stats['total']} features")
    print(f"Changes  : {stats['changes']} change objects")
    print(f"Modified : {stats['modified']} feature-updates applied")
    if stats["warnings"]:
        print(f"Warnings : {len(stats['warnings'])}")
        for w in stats["warnings"]:
            print(f"  ! {w}")


if __name__ == "__main__":
    main()
