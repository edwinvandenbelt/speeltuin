"""
Configuration for the Link-Based STAQ algorithm.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Optional


class FundamentalDiagramType(str, Enum):
    NEWELL = "Newell"
    QUADRATIC_LINEAR = "QuadraticLinear"


# Default values (mirror LinkBasedStaqConfigurationDefaults.java)
DEFAULT_EPSILON = 0.001
DEFAULT_MAX_ITERATIONS = 100
DEFAULT_FIXED_POINT_EPSILON = 0.0001
DEFAULT_FIXED_POINT_MAX_ITERATIONS = 10


@dataclass
class Config:
    value_of_distance_per_km: float
    value_of_time_per_hour: float
    fundamental_diagram_type: FundamentalDiagramType
    duration_hours: float
    epsilon: float = DEFAULT_EPSILON
    max_iterations: int = DEFAULT_MAX_ITERATIONS
    fixed_point_epsilon: float = DEFAULT_FIXED_POINT_EPSILON
    fixed_point_max_iterations: int = DEFAULT_FIXED_POINT_MAX_ITERATIONS


def parse_config(data: dict) -> Config:
    """Parse a configuration dict (from the Lambda event) into a Config object."""
    fd_raw = data.get("fundamentalDiagramType", FundamentalDiagramType.NEWELL.value)
    try:
        fd_type = FundamentalDiagramType(fd_raw)
    except ValueError:
        raise ValueError(
            f"Unknown fundamentalDiagramType: {fd_raw!r}. "
            f"Allowed values: {[e.value for e in FundamentalDiagramType]}"
        )
    return Config(
        value_of_distance_per_km=float(data["valueOfDistancePerKilometer"]),
        value_of_time_per_hour=float(data["valueOfTimePerHour"]),
        fundamental_diagram_type=fd_type,
        duration_hours=float(data["durationInHours"]),
        epsilon=float(data.get("epsilon", DEFAULT_EPSILON)),
        max_iterations=int(data.get("maxIterations", DEFAULT_MAX_ITERATIONS)),
        fixed_point_epsilon=float(data.get("fixedPointEpsilon", DEFAULT_FIXED_POINT_EPSILON)),
        fixed_point_max_iterations=int(
            data.get("fixedPointMaxIterations", DEFAULT_FIXED_POINT_MAX_ITERATIONS)
        ),
    )
