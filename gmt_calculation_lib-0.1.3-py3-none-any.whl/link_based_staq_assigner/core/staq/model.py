"""
StaqModel – ties all components together.

Mirrors StaqModel.java (run() method) but without Java infrastructure:
  - No threads (single-threaded Python)
  - No writers / loggers (returns results directly)
  - No GraphHopper (uses our own Dijkstra)

Entry point: run_staq(config, network, demand_matrix) → (link_results, rdg, iterations)
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from .assignment import AssignmentResult, assign, store_turn_demands
from .calculations import (
    apply_msa,
    calc_link_demands,
    calc_link_flows,
    calc_rdg,
    calc_turn_demands,
    create_link_results,
    store_msa_demands,
    update_congested_costs,
    update_free_flow_costs,
)
from .config import Config
from .domain import Centroid, LinkResult, Matrix, Network, Turn
from .fixed_point import solve_fixed_point


def run_staq(
    cfg: Config,
    network: Network,
    demand_matrix: Matrix,
) -> Tuple[List[LinkResult], float, int]:
    """
    Run the full STAQ algorithm.

    Parameters
    ----------
    cfg            : Configuration (costs, iterations, convergence criteria)
    network        : Built and validated Network object
    demand_matrix  : OD demand matrix (rows = origins, cols = destinations,
                     both 0-indexed by zone_index_1based - 1)

    Returns
    -------
    (link_results, relative_duality_gap, iterations_executed)
    """
    # ---- Step 1: free-flow costs ----
    update_free_flow_costs(network, cfg)

    # ---- Step 2: initial all-or-nothing assignment ----
    aon_result: AssignmentResult = assign(network, demand_matrix)
    store_turn_demands(aon_result.demand_per_dest_per_turn, network)

    prev_avg: Optional[Dict[Turn, Dict[Centroid, float]]] = None
    final_link_results: List[LinkResult] = []
    final_rdg = 0.0
    final_iter = 0

    for iteration in range(1, cfg.max_iterations + 1):

        # ---- Step 3: MSA averaging ----
        current_demand = {
            turn: dict(turn.demand_per_dest)
            for turn in network.turns.values()
            if turn.demand_per_dest
        }
        msa_avg = apply_msa(prev_avg, current_demand, iteration)
        store_msa_demands(msa_avg, network)
        prev_avg = msa_avg

        link_demands = calc_link_demands(network)
        turn_demands = calc_turn_demands(network)

        # ---- Step 4: fixed-point solve ----
        solve_fixed_point(
            network,
            cfg.fixed_point_max_iterations,
            cfg.fixed_point_epsilon,
        )

        # ---- Step 5: update congested link costs ----
        link_flows = calc_link_flows(network)
        update_congested_costs(network, cfg, link_demands, link_flows)

        # Snapshot of link costs after update (used for RDG + next Dijkstra)
        link_costs = {lnk: lnk.generalized_cost for lnk in network.links}

        # ---- Step 6: all-or-nothing assignment with congested costs ----
        aon_result = assign(network, demand_matrix)
        store_turn_demands(aon_result.demand_per_dest_per_turn, network)

        # ---- Step 7: relative duality gap ----
        if aon_result.cost_matrix is None:
            raise RuntimeError("Assignment returned no cost matrix.")
        rdg = calc_rdg(
            network,
            demand_matrix,
            link_demands,
            link_costs,
            turn_demands,
            aon_result.cost_matrix,
        )

        # ---- Step 8: build intermediate / final results ----
        iter_link_flows = calc_link_flows(network)
        iter_link_results = create_link_results(network, link_demands, iter_link_flows)

        final_iter = iteration
        final_rdg = rdg
        final_link_results = iter_link_results

        if iteration == cfg.max_iterations or rdg < cfg.epsilon:
            break

    return final_link_results, final_rdg, final_iter
