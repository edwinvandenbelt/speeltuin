"""
Fixed-point solver for the Link-Based STAQ algorithm.

Implements:
 1. Turn-fractions calculator   (TurnFractionsCalculator.java)
 2. Connector-demand determiner (ConnectorDemandDeterminer.java)
 3. Propagator                  (PropagatorCallable.java / Propagator.java)
 4. Tampere node model          (TampereNodeModel.java / NodeModelRunner.java)
 5. Fixed-point loop            (FixedPointSolver.java)

No external dependencies – stdlib only.
"""

from __future__ import annotations

import math
from collections import defaultdict, deque
from typing import Dict, List, Optional, Tuple

from .domain import Centroid, Link, Network, Node, Turn


# ---------------------------------------------------------------------------
# 1. Turn-fractions calculator
# ---------------------------------------------------------------------------

def calculate_turn_fractions(network: Network) -> None:
    """
    Compute turn_fraction_per_dest for every turn and store it in-place.

    fraction = turn.demand_per_dest[dest] / link.demand_per_dest[dest]

    where link.demand_per_dest[dest] = sum of demand_per_dest[dest] over all
    turns whose from_link == this link.
    """
    turns = list(network.turns.values())

    # Reset fractions
    for turn in turns:
        turn.fraction_per_dest.clear()

    # Aggregate link demand per destination
    # link_demand_per_dest[link][centroid] = sum of turn demands
    link_demand_per_dest: Dict[Link, Dict[Centroid, float]] = {}
    for turn in turns:
        lnk = turn.from_link
        if lnk not in link_demand_per_dest:
            link_demand_per_dest[lnk] = {}
        ld = link_demand_per_dest[lnk]
        for dest, demand in turn.demand_per_dest.items():
            ld[dest] = ld.get(dest, 0.0) + demand

    # Compute fractions
    for turn in turns:
        ld = link_demand_per_dest.get(turn.from_link, {})
        for dest, link_demand in ld.items():
            if link_demand > 0.0:
                turn_demand = turn.demand_per_dest.get(dest, 0.0)
                turn.fraction_per_dest[dest] = turn_demand / link_demand


# ---------------------------------------------------------------------------
# 2. Connector-demand determiner
# ---------------------------------------------------------------------------

class ConnectorWithDemand:
    """Pairs a virtual origin-connector link with its demand-per-destination."""

    def __init__(self, connector: Link, demand_per_dest: Dict[Centroid, float]) -> None:
        self.connector = connector
        self.demand_per_dest = demand_per_dest


def determine_connector_demands(network: Network) -> List[ConnectorWithDemand]:
    """
    Collect origin connector links and sum up their demand per destination.

    An origin connector is a link that starts at a zone centroid node — i.e. its
    from_node_index is a key in network.centroids.  Two identification styles are
    supported for backward compatibility:

    * Old-style virtual connectors: ``from_link.external_id is None``
    * New-style feedlink connectors: ``from_link.is_virtual`` and
      ``from_link.from_node_index`` is a centroid node
    """
    centroid_node_indices = set(network.centroids.keys())

    connector_map: Dict[Link, Dict[Centroid, float]] = {}
    for turn in network.turns.values():
        from_link = turn.from_link
        is_origin_connector = (
            from_link.external_id is None  # old-style virtual connector
            or (
                from_link.is_virtual
                and from_link.from_node_index in centroid_node_indices
            )
        )
        if is_origin_connector:
            if from_link not in connector_map:
                connector_map[from_link] = {}
            dd = connector_map[from_link]
            for dest, demand in turn.demand_per_dest.items():
                dd[dest] = dd.get(dest, 0.0) + demand

    return [ConnectorWithDemand(link, dd) for link, dd in connector_map.items()]


# ---------------------------------------------------------------------------
# 3. Propagator
# ---------------------------------------------------------------------------

_MINIMUM_DEMAND_TO_PROPAGATE = 1e-3


def propagate(
    network: Network,
    connector_demands: List[ConnectorWithDemand],
) -> None:
    """
    Propagate demands from origin connectors through the network, computing
    candidate_flow for every turn.  Stores results in-place on Turn objects.

    Mirrors PropagatorCallable.java + Propagator.java (single-threaded).
    """
    # Reset all candidate flows
    for turn in network.turns.values():
        turn.candidate_flow = 0.0

    # Build turns-per-in-link index
    turns_per_in_link: Dict[Link, List[Turn]] = defaultdict(list)
    for turn in network.turns.values():
        turns_per_in_link[turn.from_link].append(turn)

    # Process each destination centroid separately (mirrors Java parallel loop)
    all_centroids = list(network.centroids.values())

    for dest_centroid in all_centroids:
        candidate_flow_per_turn: Dict[Turn, float] = {}
        _propagate_for_destination(
            dest_centroid, connector_demands, turns_per_in_link, candidate_flow_per_turn
        )
        for turn, flow in candidate_flow_per_turn.items():
            turn.candidate_flow += flow


def _propagate_for_destination(
    dest: Centroid,
    connector_demands: List[ConnectorWithDemand],
    turns_per_in_link: Dict[Link, List[Turn]],
    candidate_flow_per_turn: Dict[Turn, float],
) -> None:
    """
    Propagate demand for one destination centroid using a depth-first stack.

    PathState = (in_link, flow_to_distribute)
    """
    # Seed initial active links from connectors
    # deque used as stack (addLast / removeLast in Java)
    active: deque[Tuple[Link, float]] = deque()

    for cwd in connector_demands:
        demand = cwd.demand_per_dest.get(dest, 0.0)
        if demand >= _MINIMUM_DEMAND_TO_PROPAGATE:
            active.append((cwd.connector, demand))

    # Cache of (link, dest) → list of (turn, fraction) with positive fraction
    # (avoids recomputing per-destination fractions repeatedly)
    fractions_cache: Dict[Link, List[Tuple[Turn, float]]] = {}

    while active:
        in_link, flow = active.pop()

        if flow < _MINIMUM_DEMAND_TO_PROPAGATE:
            continue

        turns_for_link = turns_per_in_link.get(in_link)
        if not turns_for_link:
            continue

        if in_link not in fractions_cache:
            fractions_cache[in_link] = [
                (t, t.fraction_per_dest[dest])
                for t in turns_for_link
                if t.fraction_per_dest.get(dest, 0.0) > 0.0
            ]

        frac_list = fractions_cache[in_link]
        if not frac_list:
            continue

        accepted_flow = flow * in_link.acceptance_factor

        for i, (turn, fraction) in enumerate(frac_list):
            in_flow = fraction * flow
            out_flow = fraction * accepted_flow

            # Accumulate candidate flow (inflow side, as in Java)
            candidate_flow_per_turn[turn] = (
                candidate_flow_per_turn.get(turn, 0.0) + in_flow
            )

            if out_flow >= _MINIMUM_DEMAND_TO_PROPAGATE:
                if i == len(frac_list) - 1:
                    active.append((turn.to_link, out_flow))
                else:
                    active.appendleft((turn.to_link, out_flow))


# ---------------------------------------------------------------------------
# 4. Tampere node model
# ---------------------------------------------------------------------------

_MAX_SCALE_ITERATIONS = 10


def _run_node_model(node: Node) -> Dict[Link, float]:
    """
    Run the Tampere node model for *node* and return acceptance factors per
    from-link.

    If the node is a simple pass-through (1 in-link, 1 out-link, equal
    capacity), acceptance factors are determined directly from demand ratios
    without running the full Tampere algorithm.

    Returns
    -------
    Dict[Link, float]
        from_link → acceptance_factor in [0, 1]
    """
    from_links = node.from_links
    to_links = node.to_links
    turns = node.turns

    if not turns:
        return {}

    n_from = len(from_links)
    n_to = len(to_links)

    # Build turn-demand matrix: turnDemands[i][j] = candidate_flow on turn(i→j)
    turn_demands = [[0.0] * n_to for _ in range(n_from)]
    from_link_index = {lnk: i for i, lnk in enumerate(from_links)}
    to_link_index = {lnk: j for j, lnk in enumerate(to_links)}

    for turn in turns:
        fi = from_link_index.get(turn.from_link)
        ti = to_link_index.get(turn.to_link)
        if fi is not None and ti is not None:
            turn_demands[fi][ti] += turn.candidate_flow

    # Simple pass-through shortcut
    if _is_simple_passthrough(node, from_links, to_links):
        turn_flows = [row[:] for row in turn_demands]
    else:
        scaled_demands, in_caps, out_caps = _prepare_tampere_input(
            from_links, to_links, turn_demands
        )
        turn_flows_raw = _tampere(scaled_demands, in_caps, out_caps)
        turn_flows = turn_flows_raw

    # Compute acceptance factors per from-link
    acceptance_factors: Dict[Link, float] = {}
    for i, from_link in enumerate(from_links):
        total_demand = sum(turn_demands[i])
        total_flow = sum(turn_flows[i])
        if total_demand > 0.0:
            acceptance_factors[from_link] = total_flow / total_demand
        else:
            acceptance_factors[from_link] = 1.0

    return acceptance_factors


def _is_simple_passthrough(node: Node, from_links: List[Link], to_links: List[Link]) -> bool:
    if len(from_links) != 1 or len(to_links) != 1:
        return False
    return from_links[0].capacity == to_links[0].capacity


def _prepare_tampere_input(
    from_links: List[Link],
    to_links: List[Link],
    turn_demands: List[List[float]],
) -> Tuple[List[List[float]], List[float], List[float]]:
    """Scale turn demands so no from-link demand exceeds its capacity, then return inputs."""
    n_from = len(from_links)
    n_to = len(to_links)

    in_caps = [
        max(0.0, lnk.capacity - (lnk.preload or 0.0)) for lnk in from_links
    ]
    out_caps = [
        max(0.0, lnk.capacity - (lnk.preload or 0.0)) for lnk in to_links
    ]

    scaled = []
    for i, from_link in enumerate(from_links):
        row_sum = sum(turn_demands[i])
        cap = in_caps[i]
        if row_sum > 0.0 and row_sum > cap:
            row = _scale_row(turn_demands[i], row_sum, cap)
        else:
            row = turn_demands[i][:]
        scaled.append(row)

    return scaled, in_caps, out_caps


def _scale_row(row: List[float], row_sum: float, capacity: float) -> List[float]:
    """Scale a row so its sum fits within capacity (with floating-point safety)."""
    scaled = row[:]
    scale = capacity / row_sum
    for _ in range(_MAX_SCALE_ITERATIONS):
        scaled = [v * scale for v in row]
        if sum(scaled) <= capacity:
            break
        scale = math.nextafter(scale, 0.0)
    return scaled


def _safe_mul(a: float, b: float) -> float:
    """
    Multiply two non-negative floats safely.

    IEEE 754 gives ``0.0 * inf = nan``, but in the Tampere algorithm the
    product ``lor * oriented_capacity`` represents *accepted flow*, so
    ``0 * inf`` should be 0 (a zero level-of-reduction means nothing passes).
    Similarly, ``inf * 0 = 0`` in that context.
    """
    if a == 0.0 or b == 0.0:
        return 0.0
    return a * b


def _tampere(
    turn_demands: List[List[float]],
    in_caps: List[float],
    out_caps: List[float],
) -> List[List[float]]:
    """
    Tampere node model.

    Parameters
    ----------
    turn_demands : n_in × n_out matrix of (scaled) turn demands
    in_caps      : capacity of each in-link
    out_caps     : capacity of each out-link

    Returns
    -------
    n_in × n_out matrix of accepted turn flows
    """
    n_in = len(turn_demands)
    n_out = len(out_caps)

    total_demand_per_inlink = [sum(turn_demands[i]) for i in range(n_in)]

    accepted = [[0.0] * n_out for _ in range(n_in)]
    remaining_out_caps = out_caps[:]

    # remaining_inlinks_per_outlink[j] = list of in-link indices still unresolved for out j
    remaining_in_per_out: List[List[int]] = [
        [
            i
            for i in range(n_in)
            if turn_demands[i][j] > 0 and total_demand_per_inlink[i] > 0
        ]
        for j in range(n_out)
    ]

    # Active outlinks: those that have unresolved in-links
    active_out = {j for j in range(n_out) if remaining_in_per_out[j]}

    while active_out:
        # Compute oriented capacities matrix (demand-weighted share of in-link capacity)
        oriented = [[0.0] * n_out for _ in range(n_in)]
        for i in range(n_in):
            cap_i = in_caps[i]
            td_i = total_demand_per_inlink[i]
            if td_i > 0:
                for j in range(n_out):
                    d = turn_demands[i][j]
                    if d > 0:
                        # Oriented capacity = demand-weighted share of in-link capacity.
                        # Clamp to demand: oriented capacity cannot exceed the turn demand
                        # (relevant when cap_i is infinite, e.g. virtual connectors).
                        oc = _safe_mul(d / td_i, cap_i)
                        oriented[i][j] = min(oc, d)

        # Level of reduction per outlink: remaining_cap / sum_oriented_cap
        lor: Dict[int, float] = {}
        for j in active_out:
            remaining_ins = remaining_in_per_out[j]
            if remaining_ins:
                total_oc = sum(oriented[i][j] for i in remaining_ins)
                if total_oc <= 0:
                    raise RuntimeError(
                        f"Total oriented capacity for out-link {j} is zero or negative."
                    )
                lor[j] = remaining_out_caps[j] / total_oc
            elif remaining_out_caps[j] <= 0:
                lor[j] = 1.0

        if not lor:
            break

        # Most restrictive outlink (smallest level of reduction)
        mrj = min(lor, key=lor.__getitem__)
        lor_mrj = lor[mrj]

        remaining_ins = list(remaining_in_per_out[mrj])

        # Find demand-constrained in-links for mrj
        # Guard: lor_mrj * in_caps[i] can be nan when lor_mrj==0 and in_caps[i]==inf.
        # In that case, 0 * inf = nan (IEEE 754), which makes the comparison False,
        # meaning no in-link would be treated as demand-constrained — correct behaviour
        # because when lor_mrj==0 the out-link is the bottleneck and nothing passes through.
        # We make this explicit with a helper to avoid silent nan propagation.
        def _prop_cap(lor: float, cap: float) -> float:
            if math.isinf(cap):
                return math.inf if lor > 0.0 else 0.0
            return lor * cap

        demand_constrained = [
            i for i in remaining_ins
            if total_demand_per_inlink[i] <= _prop_cap(lor_mrj, in_caps[i])
        ]

        outlinks_to_remove: set = set()

        if demand_constrained:
            # Allocate full demand for these in-links
            for i in demand_constrained:
                for j in active_out:
                    d = turn_demands[i][j]
                    if d > 0:
                        accepted[i][j] = d
                        remaining_out_caps[j] -= d
                        if i in remaining_in_per_out[j]:
                            remaining_in_per_out[j].remove(i)
                        if not remaining_in_per_out[j]:
                            outlinks_to_remove.add(j)
        else:
            # All remaining in-links are capacity-constrained → partial allocation
            for i in remaining_ins:
                for j in active_out:
                    oc = oriented[i][j]
                    if turn_demands[i][j] > 0:
                        accepted[i][j] = _safe_mul(lor_mrj, oc)
                    # Update remaining capacity & remaining-inlinks
                    if i in remaining_in_per_out[j]:
                        remaining_out_caps[j] -= _safe_mul(lor_mrj, oc)
                        if j != mrj:
                            remaining_in_per_out[j].remove(i)
                            if not remaining_in_per_out[j]:
                                outlinks_to_remove.add(j)

            outlinks_to_remove.add(mrj)

        active_out -= outlinks_to_remove

    return accepted


# ---------------------------------------------------------------------------
# 5. Fixed-point solver
# ---------------------------------------------------------------------------

def solve_fixed_point(
    network: Network,
    fixed_point_max_iterations: int,
    fixed_point_epsilon: float,
) -> None:
    """
    Solve the fixed-point problem and set turn flows and acceptance factors
    in the network in-place.

    Algorithm:
      1. Compute turn fractions (once, before the loop)
      2. Determine connector demands (once, before the loop)
      3. Initialise all acceptance factors to 1.0
      4. Loop:
           a. Propagate → sets candidate_flow on all turns
           b. Run node model for each node → update acceptance factors on links
           c. Check convergence
      5. Final propagate (to get final candidate flows)
      6. Compute turn flows: flow = candidate_flow * from_link.acceptance_factor
    """
    calculate_turn_fractions(network)
    connector_demands = determine_connector_demands(network)

    # Initialise acceptance factors
    for link in network.links:
        link.acceptance_factor = 1.0

    prev_afs: Optional[Dict[Link, float]] = None

    for fp_iter in range(1, fixed_point_max_iterations + 1):
        # a. Propagate
        propagate(network, connector_demands)

        # b. Node model → new acceptance factors
        current_afs: Dict[Link, float] = {}
        for node in network.nodes:
            if node.turns:
                node_afs = _run_node_model(node)
                current_afs.update(node_afs)

        for link, af in current_afs.items():
            link.acceptance_factor = af

        # c. Convergence check
        if prev_afs is not None:
            mad = _mean_abs_diff(current_afs, prev_afs)
            if mad < fixed_point_epsilon:
                break

        prev_afs = dict(current_afs)

    # Final propagate
    propagate(network, connector_demands)

    # Set turn flows
    for turn in network.turns.values():
        turn.flow = turn.candidate_flow * turn.from_link.acceptance_factor


def _mean_abs_diff(
    current: Dict[Link, float], previous: Dict[Link, float]
) -> float:
    """Mean absolute difference between two acceptance-factor dicts."""
    all_links = set(current) | set(previous)
    if not all_links:
        return 0.0
    total = sum(
        abs(current.get(lnk, 1.0) - previous.get(lnk, 1.0))
        for lnk in all_links
    )
    return total / len(all_links)
