"""
Demand assignment for the Link-Based STAQ algorithm.

Implements an edge-based (turn-aware) one-to-many Dijkstra and uses it to
route origin-centroid demand onto the network, storing demand-per-destination
on each traversed turn.

The "edge-based" Dijkstra keeps state as (node, incoming_link_index) so that
banned turns (U-turns, centroid-through turns) are respected.

Key difference from the Java version: we work directly with our own domain
objects instead of GraphHopper, so no graph library dependency is needed.
"""

from __future__ import annotations

import heapq
from collections import defaultdict
from typing import Dict, List, Optional, Set, Tuple

from .domain import Centroid, Link, Matrix, Network, Turn
from .network_builder import _turn_id


# Sentinel: link index meaning "no previous link" (start of path)
_NO_PREV_LINK = -1

# ---------------------------------------------------------------------------
# Edge-based Dijkstra
# ---------------------------------------------------------------------------

def _dijkstra_one_to_many(
    origin_node_idx: int,
    destination_node_indices: Set[int],
    network: Network,
) -> Dict[int, List[int]]:
    """
    Edge-based one-to-many Dijkstra from *origin_node_idx* to all nodes in
    *destination_node_indices*.

    State: (cost, node_idx, prev_link_idx)
    Traversal id: (node_idx, prev_link_idx) — ensures turn-awareness.

    Returns
    -------
    Dict[dest_node_idx, path_link_indices]
        Each path is the ordered list of link indices from the origin connector
        to the destination connector (inclusive).
    """
    if not destination_node_indices:
        return {}

    # Pre-build adjacency: node_index → list of outgoing links
    outgoing: Dict[int, List[Link]] = defaultdict(list)
    for lnk in network.links:
        outgoing[lnk.from_node_index].append(lnk)

    # Banned turns: stored as a set of turn_ids for O(1) lookup
    # We enforce bans by checking: a turn (prev_link, curr_link) is allowed
    # iff _turn_id(prev, curr) is in network.turns  (banned turns are simply
    # absent from the turns dict).

    # Priority queue entries: (cost, node_idx, prev_link_idx, path_so_far)
    # path_so_far is a tuple of link indices (immutable for sharing)
    INIT_PATH: Tuple[int, ...] = ()
    start_entry = (0.0, origin_node_idx, _NO_PREV_LINK, INIT_PATH)
    pq: list = [start_entry]

    # best[(node_idx, prev_link_idx)] = (cost, path)
    best: Dict[Tuple[int, int], Tuple[float, Tuple[int, ...]]] = {
        (origin_node_idx, _NO_PREV_LINK): (0.0, INIT_PATH)
    }

    found: Dict[int, List[int]] = {}

    while pq and len(found) < len(destination_node_indices):
        cost, node_idx, prev_link_idx, path = heapq.heappop(pq)

        # Skip stale entries
        key = (node_idx, prev_link_idx)
        if best.get(key, (float("inf"),))[0] < cost:
            continue

        # Check if this is a destination
        if node_idx in destination_node_indices and node_idx not in found:
            found[node_idx] = list(path)

        # Relax outgoing edges
        for to_link in outgoing.get(node_idx, []):
            # Check turn legality (only matters when we have a previous link)
            if prev_link_idx != _NO_PREV_LINK:
                tid = _turn_id(prev_link_idx, to_link.index)
                if tid not in network.turns:
                    # This turn is banned — skip
                    continue

            new_cost = cost + to_link.generalized_cost
            new_key = (to_link.to_node_index, to_link.index)
            prev_best = best.get(new_key, (float("inf"),))[0]
            if new_cost < prev_best:
                new_path = path + (to_link.index,)
                best[new_key] = (new_cost, new_path)
                heapq.heappush(pq, (new_cost, to_link.to_node_index, to_link.index, new_path))

    return found


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

class AssignmentResult:
    """Holds the outputs of a single demand assignment pass."""

    def __init__(self) -> None:
        # demand_per_dest_per_turn[turn][centroid] = demand
        self.demand_per_dest_per_turn: Dict[Turn, Dict[Centroid, float]] = {}
        # cost_matrix[origin_zone_0based][dest_zone_0based] = generalised cost
        self.cost_matrix: Optional[Matrix] = None


def assign(network: Network, demand_matrix: Matrix) -> AssignmentResult:
    """
    Run the all-or-nothing demand assignment.

    For each origin centroid (with positive demand to at least one destination)
    run Dijkstra and load demand onto the resulting paths.

    The centroid virtual node is the Dijkstra source; destination virtual nodes
    are the targets.

    Returns an :class:`AssignmentResult` with per-turn demand and the
    generalised cost matrix.
    """
    result = AssignmentResult()
    result.demand_per_dest_per_turn = {}
    n_zones = len(network.centroids)
    result.cost_matrix = Matrix(n_zones, n_zones)

    # Build inverse lookup: node_index → Centroid
    centroid_per_node: Dict[int, Centroid] = dict(network.centroids)

    # Build link-index → Link for quick path reconstruction
    link_by_index: Dict[int, Link] = {lnk.index: lnk for lnk in network.links}

    # Turn lookup by id
    turn_by_id: Dict[int, Turn] = network.turns

    for origin_centroid in centroid_per_node.values():
        origin_node_idx = origin_centroid.node_index
        origin_zone_0 = origin_centroid.zone_index_1based - 1

        # Destination nodes with positive demand
        dest_node_indices: Set[int] = set()
        for dest_centroid in centroid_per_node.values():
            if dest_centroid.node_index == origin_node_idx:
                continue
            dest_zone_0 = dest_centroid.zone_index_1based - 1
            if demand_matrix.get(origin_zone_0, dest_zone_0) > 0.0:
                dest_node_indices.add(dest_centroid.node_index)

        if not dest_node_indices:
            continue

        path_per_dest = _dijkstra_one_to_many(
            origin_node_idx, dest_node_indices, network
        )

        for dest_node_idx, path_link_indices in path_per_dest.items():
            dest_centroid = centroid_per_node[dest_node_idx]
            dest_zone_0 = dest_centroid.zone_index_1based - 1
            demand = demand_matrix.get(origin_zone_0, dest_zone_0)
            if demand <= 0.0:
                continue

            # Store generalised cost (sum of link costs along path)
            total_cost = sum(
                link_by_index[li].generalized_cost for li in path_link_indices
            )
            result.cost_matrix.set(origin_zone_0, dest_zone_0, total_cost)

            # Store demand on turns (consecutive link pairs in the path)
            for i in range(1, len(path_link_indices)):
                prev_li = path_link_indices[i - 1]
                curr_li = path_link_indices[i]
                tid = _turn_id(prev_li, curr_li)
                turn = turn_by_id.get(tid)
                if turn is None:
                    raise RuntimeError(
                        f"Turn not found for path edges ({prev_li}, {curr_li}). "
                        "This should not happen after network construction."
                    )
                if turn not in result.demand_per_dest_per_turn:
                    result.demand_per_dest_per_turn[turn] = {}
                dest_map = result.demand_per_dest_per_turn[turn]
                dest_map[dest_centroid] = dest_map.get(dest_centroid, 0.0) + demand

    return result


def store_turn_demands(
    demand_per_dest_per_turn: Dict[Turn, Dict[Centroid, float]],
    network: Network,
) -> None:
    """Write demand_per_dest from an assignment result into each Turn object."""
    # Clear existing values first
    for turn in network.turns.values():
        turn.demand_per_dest.clear()

    for turn, dest_map in demand_per_dest_per_turn.items():
        turn.demand_per_dest.update(dest_map)
