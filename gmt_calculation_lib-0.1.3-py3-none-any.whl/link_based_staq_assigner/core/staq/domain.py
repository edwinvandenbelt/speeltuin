"""
Domain objects for the Link-Based STAQ algorithm.

These mirror the Java domain classes but are simplified for Python:
- No GraalVM/EMME bindings
- Mutable state stored directly on objects (no Optional wrappers)
- Identity-based equality for Link, Node, Turn, Centroid (using id())
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ---------------------------------------------------------------------------
# Link
# ---------------------------------------------------------------------------

class Link:
    """A directed road link (or virtual centroid connector)."""

    VIRTUAL_LINK_LENGTH_M = 0.0
    VIRTUAL_LINK_SPEED_KMH = 1.0
    VIRTUAL_LINK_SPEED_AT_CAP_KMH = 0.99
    VIRTUAL_LINK_CAPACITY = float("inf")

    def __init__(
        self,
        index: int,
        external_id: Optional[str],
        from_node_index: int,
        to_node_index: int,
        length_m: float,
        speed_kmh: float,
        speed_at_cap_kmh: Optional[float],
        capacity: float,
        preload: Optional[float] = None,
        is_virtual: bool = False,
    ) -> None:
        self.index = index
        self.external_id = external_id          # None for virtual connector links
        self.from_node_index = from_node_index
        self.to_node_index = to_node_index
        self.length_m = length_m
        self.speed_kmh = speed_kmh
        self.speed_at_cap_kmh = speed_at_cap_kmh
        self.capacity = capacity
        self.preload = preload                  # optional background flow
        self.is_virtual = is_virtual

        # Mutable state updated during the algorithm
        self.opposite_link: Optional[Link] = None
        self.generalized_cost: float = 0.0
        self.free_flow_cost: float = 0.0
        self.acceptance_factor: float = 1.0

    # Links are equal iff they share the same index (same semantics as Java)
    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Link):
            return NotImplemented
        return self.index == other.index

    def __hash__(self) -> int:
        return hash(self.index)

    def __repr__(self) -> str:
        return (
            f"Link(index={self.index}, ext={self.external_id!r}, "
            f"{self.from_node_index}->{self.to_node_index}, "
            f"virtual={self.is_virtual})"
        )


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------

class Node:
    """A road intersection node."""

    def __init__(self, index: int, external_id: Optional[str] = None) -> None:
        self.index = index
        self.external_id = external_id

        # Populated by network_builder after all links/turns are known
        self.from_links: List[Link] = []   # links whose to_node == this node
        self.to_links: List[Link] = []     # links whose from_node == this node
        self.turns: List[Turn] = []        # turns passing through this node

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Node):
            return NotImplemented
        return self.index == other.index

    def __hash__(self) -> int:
        return hash(self.index)

    def __repr__(self) -> str:
        return f"Node(index={self.index}, ext={self.external_id!r})"


# ---------------------------------------------------------------------------
# Centroid
# ---------------------------------------------------------------------------

class Centroid:
    """A traffic analysis zone centroid."""

    def __init__(self, zone_index_1based: int, node_index: int) -> None:
        assert zone_index_1based > 0
        assert node_index >= 0
        self.zone_index_1based = zone_index_1based
        self.node_index = node_index

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Centroid):
            return NotImplemented
        return self.node_index == other.node_index

    def __hash__(self) -> int:
        return hash(self.node_index)

    def __repr__(self) -> str:
        return f"Centroid(zone={self.zone_index_1based}, node={self.node_index})"


# ---------------------------------------------------------------------------
# Turn
# ---------------------------------------------------------------------------

class Turn:
    """A movement from one link to another through a via-node."""

    def __init__(
        self,
        turn_id: int,
        from_link: Link,
        to_link: Link,
        free_flow_cost: float = 0.0,
    ) -> None:
        self.id = turn_id
        self.from_link = from_link
        self.to_link = to_link
        self.free_flow_cost = free_flow_cost

        # demand_per_dest: centroid -> demand (averaged via MSA)
        self.demand_per_dest: Dict[Centroid, float] = {}
        # fraction_per_dest: centroid -> fraction of from_link demand routed via this turn
        self.fraction_per_dest: Dict[Centroid, float] = {}

        # Populated by the fixed-point solver
        self.candidate_flow: float = 0.0
        self.flow: float = 0.0

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Turn):
            return NotImplemented
        return self.id == other.id

    def __hash__(self) -> int:
        return hash(self.id)

    def __repr__(self) -> str:
        return (
            f"Turn(id={self.id}, "
            f"from={self.from_link.index}, to={self.to_link.index})"
        )


# ---------------------------------------------------------------------------
# Network
# ---------------------------------------------------------------------------

class Network:
    """Container for the complete network used by the STAQ algorithm."""

    def __init__(
        self,
        links: List[Link],
        nodes: List[Node],
        turns: Dict[int, Turn],            # turn_id -> Turn (allowed turns only)
        centroids: Dict[int, Centroid],    # node_index -> Centroid
    ) -> None:
        self.links = links
        self.nodes = nodes
        self.turns = turns
        self.centroids = centroids

    def __repr__(self) -> str:
        return (
            f"Network(links={len(self.links)}, nodes={len(self.nodes)}, "
            f"turns={len(self.turns)}, centroids={len(self.centroids)})"
        )


# ---------------------------------------------------------------------------
# Matrix
# ---------------------------------------------------------------------------

class Matrix:
    """A 2-D demand or cost matrix (zero-indexed)."""

    def __init__(self, rows: int, cols: int) -> None:
        self.rows = rows
        self.cols = cols
        self._data: List[List[float]] = [[0.0] * cols for _ in range(rows)]

    @classmethod
    def from_list(cls, data: List[List[float]]) -> "Matrix":
        rows = len(data)
        cols = len(data[0]) if rows else 0
        m = cls(rows, cols)
        for i, row in enumerate(data):
            for j, v in enumerate(row):
                m._data[i][j] = float(v)
        return m

    def get(self, i: int, j: int) -> float:
        return self._data[i][j]

    def set(self, i: int, j: int, value: float) -> None:
        self._data[i][j] = value

    def __repr__(self) -> str:
        return f"Matrix({self.rows}x{self.cols})"


# ---------------------------------------------------------------------------
# LinkResult  (output)
# ---------------------------------------------------------------------------

@dataclass
class LinkResult:
    link_id: str
    cost: float
    demand: float
    flow: float
    acceptance_factor: float
