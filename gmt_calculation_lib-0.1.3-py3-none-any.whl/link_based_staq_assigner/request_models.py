"""Request models for the link_based_staq_assigner Lambda."""

from __future__ import annotations

from pydantic import BaseModel, Field


class HandlerInput(BaseModel):
    """Validated input for the link_based_staq_assigner handler."""

    network_file: str = Field(
        ..., description="S3 URI or local path of the network GeoJSON file."
    )
    feedlink_file: str = Field(
        ..., description="S3 URI or local path of the feedlinks GeoJSON file."
    )
    od_matrix_file: str = Field(
        ..., description="S3 URI or local path of the completed OD matrix GeoJSON file."
    )
    output_folder: str = Field(
        ...,
        description="S3 URI or local path of the output folder.",
    )
    value_of_distance_per_km: float = Field(
        ..., description="Value of distance per kilometre (euros/km)."
    )
    value_of_time_per_hour: float = Field(
        ..., description="Value of time per hour (euros/h)."
    )
    duration_hours: float = Field(
        ..., description="Modelling period length in hours."
    )
    fundamental_diagram_type: str = Field(
        "Newell",
        description="Fundamental diagram type: 'Newell' or 'QuadraticLinear'.",
    )
    epsilon: float = Field(0.001, description="RDG convergence threshold.")
    max_iterations: int = Field(100, description="Maximum number of outer STAQ iterations.")
    fixed_point_epsilon: float = Field(
        0.0001, description="Fixed-point solver convergence threshold."
    )
    fixed_point_max_iterations: int = Field(
        10, description="Fixed-point solver maximum iterations."
    )
