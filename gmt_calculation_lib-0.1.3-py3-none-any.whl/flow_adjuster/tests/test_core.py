"""Unit tests for flow_adjuster_core — pure Python, no I/O."""

from __future__ import annotations

import pytest

from flow_adjuster.core.flow_adjuster_core import (
    apply_flow_adjustments,
    selected_link_trips,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _zone_fc(*zones: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(zones)}


def _zone(zone_id: str, production: float = 100.0, attraction: float = 80.0) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [0.0, 0.0]},
        "properties": {
            "zoneId": zone_id,
            "production": production,
            "attraction": attraction,
        },
    }


def _net_fc(*links: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(links)}


def _link(
    link_id: str,
    from_node: str = "A",
    to_node: str = "B",
    flow24hrs: float = 1000.0,
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "flow": flow24hrs,
            "flow24hrs": flow24hrs,
            "flowsPerDaypart": {"mrh": flow24hrs * 0.1, "erh": flow24hrs * 0.08},
            "flowsPerMotive": {"work": flow24hrs * 0.7, "other": flow24hrs * 0.3},
        },
    }


def _routes_fc(*pairs: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(pairs)}


def _od_pair(
    from_zone: str,
    to_zone: str,
    origin_production: float,
    trip_fraction: float,
    routes: list[dict],
) -> dict:
    """Create a ROUTES feature in fraction convention."""
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {
            "fromZoneId": from_zone,
            "toZoneId": to_zone,
            "fromType": "zone",
            "toType": "zone",
            "originProduction": origin_production,
            "tripFraction": trip_fraction,
            "routes": routes,
        },
    }


def _route(trips: float, link_path: list[str]) -> dict:
    return {"trips": trips, "linkPath": link_path}


# ---------------------------------------------------------------------------
# selected_link_trips
# ---------------------------------------------------------------------------


class TestSelectedLinkTrips:
    def test_single_pair_single_route(self):
        """One OD pair, one route through the target link."""
        routes = _routes_fc(_od_pair("Z1", "Z2", 200.0, 0.5, [_route(0.5, ["L1", "L2"])]))
        zone_prod = {"Z1": 200.0}
        via, total = selected_link_trips(routes, "L1", zone_prod)
        # trips_via_link = 0.5 × 200 = 100
        assert abs(via[("Z1", "Z2", "zone", "zone")] - 100.0) < 1e-6
        assert abs(total - 100.0) < 1e-6

    def test_only_routes_through_link_counted(self):
        """Routes that do NOT pass through the link are ignored."""
        routes = _routes_fc(
            _od_pair(
                "Z1",
                "Z2",
                200.0,
                1.0,
                [
                    _route(0.6, ["L1", "L2"]),  # uses target link
                    _route(0.4, ["L3", "L4"]),  # does not
                ],
            )
        )
        zone_prod = {"Z1": 200.0}
        via, total = selected_link_trips(routes, "L1", zone_prod)
        assert abs(via[("Z1", "Z2", "zone", "zone")] - 0.6 * 200.0) < 1e-6
        assert abs(total - 0.6 * 200.0) < 1e-6

    def test_multiple_pairs(self):
        """Two pairs, both using the link."""
        routes = _routes_fc(
            _od_pair("Z1", "Z2", 200.0, 0.5, [_route(0.5, ["L1"])]),
            _od_pair("Z3", "Z4", 100.0, 0.8, [_route(0.8, ["L1"])]),
        )
        zone_prod = {"Z1": 200.0, "Z3": 100.0}
        via, total = selected_link_trips(routes, "L1", zone_prod)
        assert abs(via[("Z1", "Z2", "zone", "zone")] - 100.0) < 1e-6
        assert abs(via[("Z3", "Z4", "zone", "zone")] - 80.0) < 1e-6
        assert abs(total - 180.0) < 1e-6

    def test_no_routes_through_link_returns_empty(self):
        routes = _routes_fc(_od_pair("Z1", "Z2", 200.0, 0.5, [_route(0.5, ["L3", "L4"])]))
        via, total = selected_link_trips(routes, "L1", {"Z1": 200.0})
        assert via == {}
        assert total == 0.0

    def test_falls_back_to_zone_production(self):
        """When originProduction is absent, zone_production dict is used."""
        pair = _od_pair("Z1", "Z2", 0.0, 0.5, [_route(0.5, ["L1"])])
        # Remove originProduction
        del pair["properties"]["originProduction"]
        routes = _routes_fc(pair)
        via, total = selected_link_trips(routes, "L1", {"Z1": 300.0})
        assert abs(via[("Z1", "Z2", "zone", "zone")] - 150.0) < 1e-6


# ---------------------------------------------------------------------------
# apply_flow_adjustments
# ---------------------------------------------------------------------------


class TestApplyFlowAdjustmentsBasic:
    def _simple_setup(self):
        """One link, two zones, one OD pair with one route through the link."""
        net = _net_fc(_link("L1", flow24hrs=1000.0))
        zones = _zone_fc(_zone("Z1", production=200.0), _zone("Z2", attraction=150.0))
        routes = _routes_fc(_od_pair("Z1", "Z2", 200.0, 0.5, [_route(0.5, ["L1"])]))
        return net, zones, routes

    def test_no_adjustments_returns_unchanged(self):
        net, zones, routes = self._simple_setup()
        upd_routes, upd_zones, od_delta, stats = apply_flow_adjustments(net, routes, zones, [])
        assert upd_routes["features"] == routes["features"]
        assert upd_zones is zones
        assert od_delta["features"] == []
        assert stats == []

    def test_absolute_flow_sets_target(self):
        """flow='1500' on a link with current flow=1000 → delta=+500."""
        net, zones, routes = self._simple_setup()
        upd_routes, upd_zones, od_delta, stats = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "1500"}]
        )
        assert len(stats) == 1
        assert abs(stats[0]["flow_delta"] - 500.0) < 1e-6
        assert stats[0]["affected_pairs"] == 1

    def test_delta_plus_adds_to_current(self):
        net, zones, routes = self._simple_setup()
        _, _, _, stats = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "+200"}]
        )
        assert abs(stats[0]["flow_delta"] - 200.0) < 1e-6
        assert abs(stats[0]["flow_before"] - 1000.0) < 1e-6
        assert abs(stats[0]["flow_after"] - 1200.0) < 1e-6

    def test_delta_minus_subtracts(self):
        net, zones, routes = self._simple_setup()
        _, _, _, stats = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "-300"}]
        )
        assert abs(stats[0]["flow_delta"] - (-300.0)) < 1e-6

    def test_zero_delta_skips_pair_update(self):
        net, zones, routes = self._simple_setup()
        upd_routes, upd_zones, od_delta, stats = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "1000"}]
        )
        assert stats[0]["flow_delta"] == 0.0
        assert od_delta["features"] == []

    def test_unknown_link_id_raises(self):
        net, zones, routes = self._simple_setup()
        with pytest.raises(ValueError, match="L99"):
            apply_flow_adjustments(net, routes, zones, [{"linkId": "L99", "flow": "+100"}])

    def test_missing_link_id_and_nodes_raises(self):
        net, zones, routes = self._simple_setup()
        with pytest.raises(ValueError, match="linkId"):
            apply_flow_adjustments(net, routes, zones, [{"flow": "+100"}])


class TestApplyFlowAdjustmentsRouteScaling:
    def test_route_trips_scaled_only_for_routes_thru_link(self):
        """Routes not passing through the target link must remain unchanged."""
        net = _net_fc(_link("L1", flow24hrs=1000.0))
        zones = _zone_fc(_zone("Z1", 200.0), _zone("Z2"))
        routes = _routes_fc(
            _od_pair(
                "Z1",
                "Z2",
                200.0,
                1.0,
                [
                    _route(0.6, ["L1", "L2"]),  # through target link
                    _route(0.4, ["L3", "L4"]),  # alternative, not through link
                ],
            )
        )
        upd_routes, _, _, _ = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "+100"}]
        )
        feat = upd_routes["features"][0]
        r0, r1 = feat["properties"]["routes"]
        # Route through L1 should have increased trips
        assert r0["trips"] > 0.6
        # Route not through L1 must be unchanged
        assert abs(r1["trips"] - 0.4) < 1e-9

    def test_trip_fraction_equals_sum_of_route_trips(self):
        """tripFraction must equal sum(route.trips) after adjustment."""
        net = _net_fc(_link("L1", flow24hrs=1000.0))
        zones = _zone_fc(_zone("Z1", 200.0), _zone("Z2"))
        routes = _routes_fc(_od_pair("Z1", "Z2", 200.0, 0.5, [_route(0.5, ["L1"])]))
        upd_routes, _, _, _ = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "+200"}]
        )
        feat = upd_routes["features"][0]
        p = feat["properties"]
        total_route_trips = sum(r["trips"] for r in p["routes"])
        assert abs(p["tripFraction"] - total_route_trips) < 1e-5

    def test_exact_delta_on_target_link(self):
        """The total extra trips on the target link must equal flow_delta exactly."""
        origin_prod = 500.0
        # Two pairs, each contributing half the link flow
        net = _net_fc(_link("L1", flow24hrs=1000.0))
        zones = _zone_fc(_zone("Z1", origin_prod), _zone("Z3", origin_prod), _zone("Z2"))
        routes = _routes_fc(
            _od_pair("Z1", "Z2", origin_prod, 1.0, [_route(1.0, ["L1"])]),
            _od_pair("Z3", "Z2", origin_prod, 1.0, [_route(1.0, ["L1"])]),
        )
        flow_delta = 400.0
        upd_routes, _, _, _ = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": f"+{flow_delta}"}]
        )
        # Recompute trips on L1 after adjustment
        total_after = 0.0
        for feat in upd_routes["features"]:
            p = feat["properties"]
            prod = float(p.get("originProduction") or 0.0)
            for r in p.get("routes") or []:
                if "L1" in (r.get("linkPath") or []):
                    total_after += r["trips"] * prod
        # original was 1000, should now be 1400
        assert abs(total_after - (1000.0 + flow_delta)) < 1e-4


class TestApplyFlowAdjustmentsZones:
    def test_production_updated_for_origin_zones(self):
        net = _net_fc(_link("L1", flow24hrs=500.0))
        zones = _zone_fc(_zone("Z1", production=200.0), _zone("Z2", attraction=100.0))
        routes = _routes_fc(_od_pair("Z1", "Z2", 200.0, 1.0, [_route(1.0, ["L1"])]))
        _, upd_zones, _, _ = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "+100"}]
        )
        z1_props = next(
            f["properties"] for f in upd_zones["features"] if f["properties"]["zoneId"] == "Z1"
        )
        # All 100 extra trips originate from Z1
        assert abs(z1_props["production"] - 300.0) < 1e-4

    def test_attraction_updated_for_destination_zones(self):
        net = _net_fc(_link("L1", flow24hrs=500.0))
        zones = _zone_fc(_zone("Z1", production=200.0), _zone("Z2", attraction=100.0))
        routes = _routes_fc(_od_pair("Z1", "Z2", 200.0, 1.0, [_route(1.0, ["L1"])]))
        _, upd_zones, _, _ = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "+100"}]
        )
        z2_props = next(
            f["properties"] for f in upd_zones["features"] if f["properties"]["zoneId"] == "Z2"
        )
        assert abs(z2_props["attraction"] - 200.0) < 1e-4

    def test_unaffected_zones_unchanged(self):
        net = _net_fc(_link("L1", flow24hrs=500.0))
        zones = _zone_fc(
            _zone("Z1", production=200.0),
            _zone("Z2", attraction=100.0),
            _zone("Z3", production=999.0, attraction=999.0),  # never touched
        )
        routes = _routes_fc(_od_pair("Z1", "Z2", 200.0, 1.0, [_route(1.0, ["L1"])]))
        _, upd_zones, _, _ = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "+100"}]
        )
        z3_props = next(
            f["properties"] for f in upd_zones["features"] if f["properties"]["zoneId"] == "Z3"
        )
        assert z3_props["production"] == 999.0
        assert z3_props["attraction"] == 999.0


class TestApplyFlowAdjustmentsEdgeCases:
    def test_no_routes_through_link_produces_warning(self):
        """When no routes use the link a warning is emitted and zones unchanged."""
        net = _net_fc(_link("L1", flow24hrs=500.0))
        zones = _zone_fc(_zone("Z1"), _zone("Z2"))
        routes = _routes_fc(
            _od_pair("Z1", "Z2", 200.0, 1.0, [_route(1.0, ["L2", "L3"])])  # no L1
        )
        upd_routes, upd_zones, od_delta, stats = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "+100"}]
        )
        assert "warning" in stats[0]
        assert stats[0]["affected_pairs"] == 0
        assert od_delta["features"] == []
        # Zones unchanged
        assert upd_zones is zones

    def test_fromnode_tonode_resolves_link(self):
        """fromNode+toNode should resolve to the correct link."""
        net = _net_fc(_link("L1", from_node="N1", to_node="N2", flow24hrs=500.0))
        zones = _zone_fc(_zone("Z1"), _zone("Z2"))
        routes = _routes_fc(_od_pair("Z1", "Z2", 200.0, 1.0, [_route(1.0, ["L1"])]))
        _, _, _, stats = apply_flow_adjustments(
            net, routes, zones, [{"fromNode": "N1", "toNode": "N2", "flow": "+100"}]
        )
        assert stats[0]["linkId"] == "L1"
        assert stats[0]["affected_pairs"] == 1

    def test_od_delta_fc_contains_modified_pairs_only(self):
        net = _net_fc(_link("L1", flow24hrs=500.0))
        zones = _zone_fc(_zone("Z1"), _zone("Z2"), _zone("Z3"))
        routes = _routes_fc(
            _od_pair("Z1", "Z2", 200.0, 0.5, [_route(0.5, ["L1"])]),
            _od_pair("Z1", "Z3", 200.0, 0.5, [_route(0.5, ["L2"])]),  # no L1
        )
        _, _, od_delta, _ = apply_flow_adjustments(
            net, routes, zones, [{"linkId": "L1", "flow": "+100"}]
        )
        assert len(od_delta["features"]) == 1
        assert od_delta["features"][0]["properties"]["toZoneId"] == "Z2"
