# Databricks notebook source
# ---------------------------------------------------------------------------
# network_simplifier_nb.py — Databricks notebook interface for network simplification.
#
# This notebook:
#   1. Reads widget parameters (network_uris — full URIs, comma-separated).
#   2. For each URI, reads the RAW network GeoJSON (s3:// or local path).
#   3. Calls pure core function (simplify_network) — no Spark I/O.
#   4. Writes the simplified GeoJSON back to the same URI (overwrites in-place).
#   5. Prints a summary of removed nodes and merged links per URI.
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("network_simplifier_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uris", "",
    "Comma-separated full URIs of RAW network GeoJSON files to simplify (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from network_simplifier.core.network_simplifier_core import simplify_network

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

_uris_raw = dbutils.widgets.get("network_uris").strip()  # noqa: F821
NETWORK_URIS = [u.strip() for u in _uris_raw.split(",") if u.strip()]
if not NETWORK_URIS:
    raise ValueError("Widget 'network_uris' is empty — provide at least one full network URI.")

logger.info("network_uris=%s", NETWORK_URIS)

# COMMAND ----------
# ── S3 helpers ────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Network Simplifier
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
_created = _t_start.isoformat()

print(f"Starting  {_created}")
print(f"URIs     : {len(NETWORK_URIS)}")
print()

_results: dict = {}

for _uri in NETWORK_URIS:
    logger.info("─── Simplifying: %s ───", _uri)
    _t_uri = datetime.now(timezone.utc)
    try:
        _raw = _read_uri(_uri)
        _fc = json.loads(_raw)

        _simplified_fc, _stats = simplify_network(_fc)

        _payload = json.dumps(_simplified_fc, ensure_ascii=False).encode("utf-8")
        _write_uri(_uri, _payload)

        _elapsed = (datetime.now(timezone.utc) - _t_uri).total_seconds()
        logger.info(
            "%s done: original=%d removed_nodes=%d merged=%d final=%d  %.2fs",
            _uri,
            _stats["original_links"],
            _stats["removed_nodes"],
            _stats["merged_links"],
            _stats["final_links"],
            _elapsed,
        )
        _results[_uri] = _stats

    except Exception as _exc:
        import traceback  # noqa: PLC0415
        logger.error("%s FAILED: %s\n%s", _uri, _exc, traceback.format_exc())
        _results[_uri] = {"error": str(_exc)}

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("All URIs complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"Network simplifier complete — {_total_elapsed:.1f}s total")
print(_SEP)
print()

for _uri, _s in _results.items():
    print(f"  {_uri}")
    if "error" in _s:
        print(f"    ERROR: {_s['error']}")
    else:
        _orig  = _s["original_links"]
        _final = _s["final_links"]
        _pct   = (_orig - _final) / max(_orig, 1) * 100
        print(f"    Original links : {_orig:,}")
        print(f"    Removed nodes  : {_s['removed_nodes']:,}")
        print(f"    Merged links   : {_s['merged_links']:,}")
        print(f"    Final links    : {_final:,}  ({_pct:.1f}% reduction)")
    print()

print(_SEP)
