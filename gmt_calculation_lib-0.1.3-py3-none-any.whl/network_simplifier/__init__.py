# src/network_simplifier/__init__.py
