# Databricks notebook source
# ---------------------------------------------------------------------------
# network_intersector_nb.py — Databricks notebook interface for network intersection.
#
# This notebook:
#   1. Reads widget parameters (modes, bbox, area_id, catalog, schema, …).
#   2. Optionally loads the holiday-regions GeoJSON from S3 to determine region.
#   3. Queries the Spectrum network tables via spark.sql() using SQL built by
#      network_intersector.network_intersector_core.build_intersection_sql().
#      NOTE: spark.sql() does not support ? placeholders — the polygon GeoJSON
#      is embedded directly in the SQL string (single-quote–escaped).
#   4. Calls pure core functions (rows_to_feature_collection,
#      post_process_features) — no I/O.
#   5. Writes GeoJSON, GeoParquet, and Markdown outputs to S3 or a local path.
#
# Requirements (Databricks cluster):
#   pip install boto3 geopandas pyarrow   (or attach via cluster library)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
import tempfile
from datetime import datetime, timezone
from uuid import uuid4

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("network_intersector_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib

# COMMAND ----------
# MAGIC %pip install geopandas pyarrow

# COMMAND ----------
# geopandas is optional — GeoParquet output is skipped when unavailable.
try:
    import geopandas as gpd
    from shapely.geometry import shape as _shapely_shape
    _HAS_GEOPANDAS = True
except ImportError:
    _HAS_GEOPANDAS = False
    logger.warning(
        "geopandas / pyarrow not installed — GeoParquet output will be skipped."
    )

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "modes", "CAR,BIKE",
    "Transport modes — comma-separated (CAR, BIKE, PEDESTRIAN, BUS, TRAM, METRO, TRAIN)",
)
dbutils.widgets.text(  # noqa: F821
    "bbox", "4.9140989669,52.0270039292,4.9837934859,52.0587847105",
    "Bounding box — minX,minY,maxX,maxY in WGS-84",
)
dbutils.widgets.text(  # noqa: F821
    "area_id", "",
    "Area identifier (empty → auto UUID)",
)
dbutils.widgets.text(  # noqa: F821
    "DATABRICKS_CATALOG", "spectrum",
    "Unity Catalog name",
)
dbutils.widgets.text(  # noqa: F821
    "DATABRICKS_SCHEMA", "2023_01",
    "Schema / dataset version (e.g. 2024_01)",
)
dbutils.widgets.text(  # noqa: F821
    "regions_uri", "",
    "Full URI for holiday_regions.geojson (s3://bucket/key or local path; empty = skip region lookup)",
)
dbutils.widgets.text(  # noqa: F821
    "output_folder", "",
    "Output folder: s3://bucket/prefix  or  /dbfs/path  or empty for ./network/",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
# dbutils.import_notebook("network_intersector.core.network_intersector_core")  # noqa: F821
# dbutils.import_notebook("network_cleaner.core.network_cleaner_core")          # noqa: F821
from stalled.network_intersector.core.network_intersector_core import (  # noqa: E402
    VALID_MODES,
    assemble_network,
    build_intersection_sql,
    determine_region,
    to_bbox,
    to_polygon_geojson,
)

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

_VALID_MODES: set = set(VALID_MODES)  # noqa: F811  re-bind for local clarity

modes_raw = dbutils.widgets.get("modes").strip()  # noqa: F821
bbox_raw  = dbutils.widgets.get("bbox").strip()   # noqa: F821
AREA_ID   = dbutils.widgets.get("area_id").strip() or str(uuid4())  # noqa: F821
CATALOG   = dbutils.widgets.get("DATABRICKS_CATALOG").strip() or "spectrum"  # noqa: F821
SCHEMA    = dbutils.widgets.get("DATABRICKS_SCHEMA").strip() or "2023_01"    # noqa: F821
REGIONS_URI = dbutils.widgets.get("regions_uri").strip()  # noqa: F821
OUT_PATH    = dbutils.widgets.get("output_folder").strip()  # noqa: F821

MODES = [m.strip().upper() for m in modes_raw.split(",") if m.strip()]
if not MODES:
    raise ValueError("Widget 'modes' is empty — provide at least one mode (e.g. CAR,BIKE).")
invalid = [m for m in MODES if m not in _VALID_MODES]
if invalid:
    raise ValueError(f"Unknown mode(s): {invalid}.  Valid values: {sorted(_VALID_MODES)}.")

try:
    _bbox_floats = [float(x.strip()) for x in bbox_raw.split(",")]
except ValueError as _exc:
    raise ValueError(
        f"'bbox' must be four comma-separated numbers (minX,minY,maxX,maxY), "
        f"got: {bbox_raw!r}"
    ) from _exc
if len(_bbox_floats) != 4:
    raise ValueError(f"'bbox' must have exactly 4 values, got {len(_bbox_floats)}.")

INPUTS = {"bbox": _bbox_floats}
BBOX    = to_bbox(INPUTS)
DB      = f"{CATALOG}.`{SCHEMA}`"
ORIGIN  = f"{CATALOG}_{SCHEMA}"

logger.info(
    "area_id=%s  modes=%s  bbox=%s  catalog=%s.%s",
    AREA_ID, MODES, BBOX, CATALOG, SCHEMA,
)

# COMMAND ----------
# ── Region lookup (s3:// URI or local file) ───────────────────────────────────

_region_features: list = []

_regions_uri = REGIONS_URI

if _regions_uri.startswith("s3://"):
    try:
        import boto3  # noqa: PLC0415
        _reg_bucket, _reg_key = _regions_uri[5:].split("/", 1)
        _body = boto3.client("s3").get_object(Bucket=_reg_bucket, Key=_reg_key)["Body"].read()
        _region_features = json.loads(_body).get("features", [])
        logger.info(
            "Loaded %d region features from %s",
            len(_region_features), _regions_uri,
        )
    except Exception as _exc:
        logger.warning("Could not load holiday regions: %s — region will be None", _exc)
elif _regions_uri:
    try:
        with open(_regions_uri, "rb") as _fh:
            _region_features = json.loads(_fh.read()).get("features", [])
        logger.info(
            "Loaded %d region features from local file %s",
            len(_region_features), _regions_uri,
        )
    except Exception as _exc:
        logger.warning(
            "Could not load holiday regions from %s: %s — region will be None",
            _regions_uri, _exc,
        )

REGION = determine_region(BBOX, _region_features)
logger.info("Region: %s", REGION)

# COMMAND ----------
# ── Output helpers ────────────────────────────────────────────────────────────

def _s3_split(uri: str) -> tuple:
    without = uri[5:]
    bucket, _, prefix = without.partition("/")
    return bucket, prefix


def _put_s3(bucket: str, key: str, data: bytes, content_type: str) -> None:
    import boto3  # noqa: PLC0415
    boto3.client("s3").put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _output_dir() -> str:
    return OUT_PATH.rstrip("/") if OUT_PATH else "./network"


def _ensure_dir(path: str) -> None:
    if not path.startswith("s3://"):
        os.makedirs(path, exist_ok=True)


def _write_file(
    path: str, filename: str, data: bytes, content_type: str
) -> str:
    if path.startswith("s3://"):
        bucket, prefix = _s3_split(path)
        key = f"{prefix}/{filename}".lstrip("/")
        _put_s3(bucket, key, data, content_type)
        return f"s3://{bucket}/{key}"
    fp = os.path.join(path, filename)
    with open(fp, "wb") as fh:
        fh.write(data)
    logger.info("Wrote %s  (%d bytes)", fp, len(data))
    return fp


def _write_geoparquet(fc: dict, mode: str, out_dir: str, area_id: str):
    if not _HAS_GEOPANDAS:
        logger.warning("geopandas not installed — skipping GeoParquet for mode %s.", mode)
        return None
    filename = f"{area_id}-NETWORK-{mode}.parquet"
    records  = []
    for feat in fc["features"]:
        props = dict(feat["properties"])
        flow  = props.pop("flowsPerMotive", {}) or {}
        for k, v in flow.items():
            props[f"flow_{k}"] = v
        try:
            props["geometry"] = _shapely_shape(feat["geometry"])
        except Exception as exc:
            logger.warning("Skipping feature with bad geometry: %s", exc)
            continue
        records.append(props)
    if not records:
        return None
    gdf = gpd.GeoDataFrame(records, crs="EPSG:4326")
    if out_dir.startswith("s3://"):
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tmp:
            tmp_path = tmp.name
        try:
            gdf.to_parquet(tmp_path)
            bucket, prefix = _s3_split(out_dir)
            key = f"{prefix}/{filename}".lstrip("/")
            with open(tmp_path, "rb") as fh:
                _put_s3(bucket, key, fh.read(), "application/octet-stream")
            return f"s3://{bucket}/{key}"
        finally:
            os.unlink(tmp_path)
    fp = os.path.join(out_dir, filename)
    gdf.to_parquet(fp)
    logger.info("Wrote %s  (%d features)", fp, len(gdf))
    return fp


_MOTIEF_KEYS = ("work", "recreational", "education", "shopping", "unknown")


def _write_markdown(metadata: dict, mode: str, out_dir: str, area_id: str) -> str:
    filename = f"{area_id}-NETWORK-{mode}.md"
    bbox     = metadata.get("bbox", [])
    bbox_str = ", ".join(str(v) for v in bbox) if bbox else "N/A"
    lines = [
        f"# Intersection Result — {mode}",
        "",
        "## Metadata",
        "",
        "| Field          | Value |",
        "|----------------|-------|",
        f"| **Created**    | `{metadata.get('created', 'N/A')}` |",
        f"| **Mode**       | `{metadata.get('mode', mode)}` |",
        f"| **Origin**     | `{metadata.get('origin', 'N/A')}` |",
        f"| **Area ID**    | `{metadata.get('area_id', 'N/A')}` |",
        f"| **BBox**       | `[{bbox_str}]` |",
        f"| **Region**     | `{metadata.get('region') or 'N/A'}` |",
        f"| **Features**   | {metadata.get('feature_count', 'N/A')} directed links |",
        "",
        "## Flow trip-purpose keys",
        "",
        *[f"- `{k}`" for k in _MOTIEF_KEYS],
        "",
        "## Data source",
        "",
        f"Sourced from Databricks catalog **`{metadata.get('catalog', 'N/A')}`**, "
        f"schema **`{metadata.get('schema', 'N/A')}`**.",
        "",
    ]
    payload = "\n".join(lines).encode("utf-8")
    return _write_file(out_dir, filename, payload, "text/markdown")

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Intersection
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start  = datetime.now(timezone.utc)
_created  = _t_start.isoformat()

polygon_json = to_polygon_geojson(INPUTS)
logger.info("Polygon: %s", polygon_json)

out_dir = _output_dir()
_ensure_dir(out_dir)
logger.info("Output directory: %s", out_dir)

print(f"Starting  {_created}")
print(f"Area ID : {AREA_ID}")
print(f"Modes   : {', '.join(MODES)}")
print(f"BBox    : {BBOX}")
print(f"Origin  : {ORIGIN}")
print(f"Region  : {REGION or 'N/A'}")
print()

_results       = {}
_written_files = {}

for _mode in MODES:
    logger.info("─── Processing mode: %s ───", _mode)
    _t_mode = datetime.now(timezone.utc)
    try:
        # 1. Build SQL — embed polygon as string literal (spark.sql has no ? params).
        _sql_template = build_intersection_sql(_mode, CATALOG, SCHEMA)
        _poly_esc     = polygon_json.replace("'", "''")
        _sql          = _sql_template.replace("?", f"'{_poly_esc}'")
        logger.debug("SQL for %s (first 300 chars): %s…", _mode, _sql[:300])

        # 2. Execute via Spark
        _df       = spark.sql(_sql)  # noqa: F821 — Databricks-injected
        _col_names = _df.columns
        _rows      = _df.collect()
        logger.info("Query returned %d rows for mode=%s", len(_rows), _mode)

        # 3. Assemble, post-process, attach metadata, and clean in one step
        _fc, _clean_stats = assemble_network(
            _rows, _col_names, _mode, BBOX,
            determine_region(BBOX, _region_features),
            created=_created, origin=ORIGIN, area_id=AREA_ID,
        )
        logger.info(
            "Cleaned mode=%s: kept=%d  removed=%d  seed_node=%s",
            _mode, _clean_stats["kept"], _clean_stats["removed"],
            _clean_stats.get("seed_node"),
        )

        # 4. Write all three output formats
        _geojson_payload = json.dumps(_fc, ensure_ascii=False, indent=2).encode("utf-8")
        _geojson_path    = _write_file(
            out_dir, f"{AREA_ID}-NETWORK-{_mode}.geojson",
            _geojson_payload, "application/geo+json",
        )
        _parquet_path = _write_geoparquet(_fc, _mode, out_dir, AREA_ID)
        _md_path      = _write_markdown(
            {
                **_fc["properties"],
                "catalog":       CATALOG,
                "schema":        SCHEMA,
                "feature_count": len(_fc["features"]),
            },
            _mode, out_dir, AREA_ID,
        )

        _elapsed = (datetime.now(timezone.utc) - _t_mode).total_seconds()
        logger.info(
            "Mode %s done: %d directed links  %.2fs",
            _mode, len(_fc["features"]), _elapsed,
        )

        _results[_mode]       = _fc
        _written_files[_mode] = {
            "geojson":  _geojson_path,
            "parquet":  _parquet_path,
            "markdown": _md_path,
        }

    except Exception as _exc:
        import traceback  # noqa: PLC0415
        logger.error("Mode %s FAILED: %s\n%s", _mode, _exc, traceback.format_exc())
        _results[_mode]       = {"error": str(_exc)}
        _written_files[_mode] = {"error": str(_exc)}

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("All modes complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"Intersector complete — {_total_elapsed:.1f}s total")
print(_SEP)
print(f"  Area ID : {AREA_ID}")
print(f"  Origin  : {ORIGIN}")
print(f"  BBox    : {BBOX}")
print(f"  Region  : {REGION or 'N/A'}")
print(f"  Output  : {out_dir}")
print()

for _mode in MODES:
    _fc = _results.get(_mode, {})
    if "error" in _fc:
        print(f"  [FAILED] {_mode}")
        print(f"           {_fc['error']}")
    else:
        _n = len(_fc.get("features", []))
        print(f"  [OK] {_mode}  —  {_n} directed links")
        for _label, _path in (_written_files.get(_mode) or {}).items():
            if _path:
                print(f"       {_label:<12}  {_path}")
    print()

print(_SEP)
