"""Geometry helpers for the network-intersector — re-exported from shared.displacer.

All canonical implementations live in ``src/shared/displacer.py`` so they can be
shared with other modules (e.g. network_link_inserter) without creating a
cross-module dependency on network_intersector.
"""

from shared.displacer import (  # noqa: F401  (public re-exports)
    _OFFSET_M,
    _NEAR_NODE_M,
    _NEAR_NODE_M_MED,
    _NEAR_NODE_M_SHT,
    _DENSIFY_M,
    _OPPOSITE_SEARCH_M,
    _OPPOSITE_HEADING_TOL,
    _densify,
    heading,
    offset_linestring,
    assign_reverse_link_ids,
)
