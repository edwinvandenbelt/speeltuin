"""Backward-compatible re-exports — SQL logic has moved to network_fetcher.domain.sql.

Import directly from ``network_fetcher.domain.sql`` or
``network_fetcher.core.network_fetcher_core`` in new code.
"""

from __future__ import annotations

from network_fetcher.domain.sql import (  # noqa: F401
    _DAYPART_KEYS,
    _FLOW_DP_HEEN_CTE,
    _FLOW_DP_HEEN_PT_CTE,
    _FLOW_DP_OUTER_HEEN,
    _FLOW_DP_OUTER_TERUG,
    _FLOW_DP_TERUG_CTE,
    _FLOW_DP_TERUG_PT_CTE,
    _FLOW_HEEN_PIVOT,
    _FLOW_TERUG_PIVOT,
    _FLOW_WEIGHT,
    _MOTIEF_CASE,
    _MOTIEF_KEYS,
    _PT_PARAMS,
    VALID_MODES,
    build_intersection_sql,
    get_pt_params,
)
