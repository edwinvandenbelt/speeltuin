"""Backward-compatible re-exports — logic has moved to network_fetcher and bidirectional_splitter.

Import directly from those modules in new code:
- ``network_fetcher.domain.network``      — LINK_PROPERTIES, rows_to_feature_collection
- ``bidirectional_splitter.domain.network`` — post_process_features, _estimate_capacity
"""

from __future__ import annotations

from bidirectional_splitter.domain.network import (  # noqa: F401
    _estimate_capacity,
    post_process_features,
)
from network_fetcher.domain.network import (  # noqa: F401
    LINK_PROPERTIES,
    rows_to_feature_collection,
)
