"""Local debug runner for network_intersector.

Runs the full network-production pipeline step-by-step using the individual modules:
  1. network_fetcher    — query Databricks, assemble raw GeoJSON
  2. bidirectional_splitter — split bi-directional links into directed ones
  3. network_cleaner    — BFS dead-link removal
  4. parallel_link_finder   — enrich with parallelLinkIds / reverseLinkIds

Usage
-----
    # Using a bounding box:
    python -m network_intersector.network_intersector_runner \\
        --modes CAR BIKE --bbox 6.0 52.0 6.2 52.1 \\
        --output-folder s3://gmp-networks/network/ \\
        --area-id deventer-centrum \\
        --catalog spectrum --schema 2024_01

    # Using a GeoJSON polygon file (takes precedence over --bbox):
    python -m network_intersector.network_intersector_runner \\
        --modes CAR BIKE --polygon path/to/polygon.geojson \\
        --output-folder s3://gmp-networks/network/ \\
        --area-id deventer-centrum \\
        --catalog spectrum --schema 2024_01

Prerequisites
-------------
* Databricks credentials in a .env file or os.environ:
  DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID and one of:
  - DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET  (OAuth M2M, preferred)
  - DATABRICKS_TOKEN  (personal access token, fallback)
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from uuid import uuid4
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for the network-intersector pipeline "
            "(network_fetcher → bidirectional_splitter → network_cleaner → parallel_link_finder)."
        )
    )
    parser.add_argument(
        "--modes",
        nargs="+",
        required=True,
        metavar="MODE",
        help="One or more transport modes, e.g. CAR BIKE PEDESTRIAN",
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        default=None,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box as four floats (converted internally to a polygon).",
    )
    parser.add_argument(
        "--polygon",
        default=None,
        metavar="JSON_OR_PATH",
        help=(
            "Area of interest as a GeoJSON Polygon geometry — either an inline JSON string "
            "or a path to a .geojson/.json file. Takes precedence over --bbox when both are given."
        ),
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help=(
            "Output folder URI (s3://bucket/prefix/ or local directory). "
            "Output files are named {area_id}-NETWORK-{mode}.geojson."
        ),
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help="Area identifier stored in the output FC properties.area_id (optional).",
    )
    parser.add_argument("--name", default=None, help="Human-readable area name (stored in FC properties).")
    parser.add_argument("--catalog", default="spectrum", help="Databricks Unity Catalog name")
    parser.add_argument("--schema",  default="2024_01",  help="Databricks schema / dataset version")
    parser.add_argument(
        "--regions-uri",
        default="s3://gmp-networks/indices/holiday_regions.geojson",
        metavar="URI",
        help=(
            "Full URI for holiday_regions.geojson used to determine the 'region' "
            "field in output FC properties (s3:// or local path). "
            "Pass an empty string to skip region detection."
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    parser.add_argument(
        "--no-cleaner",
        action="store_true",
        default=False,
        help="Skip the BFS network cleaner step (keep all raw features).",
    )
    parser.add_argument(
        "--no-parallel-link-finder",
        action="store_true",
        default=False,
        help="Skip the parallel-link finder enrichment step.",
    )
    parser.add_argument(
        "--export-intermediate",
        action="store_true",
        default=False,
        help=(
            "Also write intermediate GeoJSON files per step: "
            "{area_id}-NETWORK-RAW-{MODE}.geojson (after fetch), "
            "{area_id}-SPLIT-{MODE}.geojson (after bidirectional split), "
            "{area_id}-CLEAN-{MODE}.geojson (after BFS cleaner)."
        ),
    )
    args = parser.parse_args()

    modes = [m.upper() for m in args.modes]

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    # --- individual module imports ---
    from network_fetcher.core.network_fetcher_core import (  # noqa: PLC0415
        build_intersection_sql,
        get_pt_params,
        rows_to_feature_collection,
        VALID_MODES,
    )
    from bidirectional_splitter.core.bidirectional_splitter_core import (  # noqa: PLC0415
        post_process_features,
    )
    from network_cleaner.core.network_cleaner_core import clean_network  # noqa: PLC0415
    from parallel_link_finder.core.parallel_link_finder_core import find_parallel_links  # noqa: PLC0415
    from stalled.network_intersector.domain.region import (  # noqa: PLC0415
        determine_region,
        to_bbox,
        to_polygon_geojson,
    )
    import shared.databricks_sql as databricks_sql  # noqa: PLC0415

    # --- resolve polygon JSON string ---
    if args.polygon is not None:
        polygon_src = args.polygon.strip()
        if not polygon_src.startswith("{"):
            polygon_path = Path(polygon_src)
            if not polygon_path.exists():
                parser.error(f"--polygon file not found: {polygon_path}")
            polygon_src = polygon_path.read_text(encoding="utf-8").strip()
        try:
            polygon_obj = json.loads(polygon_src)
        except json.JSONDecodeError as exc:
            parser.error(f"--polygon is not valid JSON: {exc}")
        polygon_json = json.dumps(polygon_obj, ensure_ascii=False)
        geom_type = polygon_obj.get("type", "")
        raw_coords = polygon_obj.get("coordinates", [])
        all_lons: list[float] = []
        all_lats: list[float] = []
        if geom_type == "MultiPolygon":
            for poly in raw_coords:
                for ring in poly:
                    for c in ring:
                        all_lons.append(c[0])
                        all_lats.append(c[1])
        else:
            for ring in raw_coords:
                for c in ring:
                    if isinstance(c[0], (int, float)):
                        all_lons.append(c[0])
                        all_lats.append(c[1])
        if all_lons:
            normalised_bbox = [min(all_lons), min(all_lats), max(all_lons), max(all_lats)]
        else:
            normalised_bbox = []
    elif args.bbox is not None:
        polygon_json = to_polygon_geojson({"bbox": args.bbox})
        normalised_bbox = to_bbox({"bbox": args.bbox})
    else:
        parser.error("Provide at least one of --bbox or --polygon.")

    # Load holiday regions (for region detection) — optional
    region_features: list = []
    if args.regions_uri:
        try:
            print(f"Reading regions      : {args.regions_uri}")
            regions_raw = json.loads(_read_uri(args.regions_uri))
            region_features = regions_raw.get("features", [])
        except Exception as exc:
            print(
                f"[warn] Could not load holiday regions from {args.regions_uri!r}: {exc}"
                " — region will be None",
                file=sys.stderr,
            )

    _PT_MODES = {"BUS", "TRAM", "METRO", "TRAIN"}

    if not args.area_id:
        args.area_id = str(uuid4())

    from shared.output_path import build_output_path  # noqa: PLC0415

    region = determine_region(normalised_bbox, region_features)

    with databricks_sql.connect_from_env() as conn:
        for mode in modes:
            if mode not in VALID_MODES:
                print(f"[warn] Unknown mode {mode!r} — skipping.", file=sys.stderr)
                continue

            print(f"\nMode     : {mode}")

            # Step 1 — fetch raw rows from Databricks
            sql = build_intersection_sql(mode, args.catalog, args.schema)
            with conn.cursor() as cur:
                if mode in _PT_MODES:
                    link_mode, modaliteit = get_pt_params(mode)
                    cur.execute(sql, (link_mode, polygon_json, modaliteit, mode))
                else:
                    cur.execute(sql, (polygon_json,))
                col_names = [d[0] for d in cur.description]
                rows      = cur.fetchall()
            print(f"Raw rows : {len(rows)}")

            # Step 2 — assemble raw FeatureCollection + add metadata
            fc = rows_to_feature_collection(rows, col_names, mode)
            meta: dict = {"bbox": normalised_bbox, "region": region}
            if args.area_id:
                meta["area_id"] = args.area_id
            if args.name:
                meta["name"] = args.name
            fc["properties"].update(meta)

            if args.export_intermediate:
                raw_uri = build_output_path(args.output_folder, args.area_id, "NETWORK-RAW", mode)
                print(f"Writing  : {raw_uri}  (NETWORK-RAW — bidirectioneel, voor splitsing)")
                _write_uri(raw_uri, json.dumps(fc, ensure_ascii=False).encode("utf-8"))

            # Step 3 — split bidirectional links into directed ones
            fc["features"] = post_process_features(fc["features"])
            print(f"Directed : {len(fc['features'])}")

            if args.export_intermediate:
                split_uri = build_output_path(args.output_folder, args.area_id, "SPLIT", mode)
                print(f"Writing  : {split_uri}  (SPLIT — na bidirectionele splitsing)")
                _write_uri(split_uri, json.dumps(fc, ensure_ascii=False).encode("utf-8"))

            # Step 4 — BFS dead-link removal
            if not args.no_cleaner:
                fc, clean_stats = clean_network(fc)
                print(
                    f"Cleaned  : kept={clean_stats['kept']}  "
                    f"removed={clean_stats['removed']}  "
                    f"seed_node={clean_stats.get('seed_node')}"
                )
                if args.export_intermediate:
                    clean_uri = build_output_path(args.output_folder, args.area_id, "CLEAN", mode)
                    print(f"Writing  : {clean_uri}  (CLEAN — na BFS cleaner)")
                    _write_uri(clean_uri, json.dumps(fc, ensure_ascii=False).encode("utf-8"))
            else:
                print("Cleaned  : skipped")

            # Step 5 — parallel-link enrichment
            if not args.no_parallel_link_finder:
                fc, plf_stats = find_parallel_links(fc)
                print(
                    f"PLF      : enriched={plf_stats['features_enriched']}  "
                    f"skipped={plf_stats['features_skipped']}"
                )
            else:
                print("PLF      : skipped")

            print(f"Features : {len(fc['features'])}")

            out_uri = build_output_path(args.output_folder, args.area_id, "NETWORK", mode)
            print(f"Writing  : {out_uri}")
            _write_uri(out_uri, json.dumps(fc, ensure_ascii=False).encode("utf-8"))

    print("\nDone.")


if __name__ == "__main__":
    main()
