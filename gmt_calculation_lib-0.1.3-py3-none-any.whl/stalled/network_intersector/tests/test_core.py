"""Unit tests for network_intersector.network_intersector_core — pure Python, no I/O."""
from __future__ import annotations

import json
import math

import pytest

from stalled.network_intersector.core.network_intersector_core import (
    _MOTIEF_KEYS,
    _NEAR_NODE_M,
    _NEAR_NODE_M_MED,
    _NEAR_NODE_M_SHT,
    _OFFSET_M,
    _OPPOSITE_HEADING_TOL,
    _OPPOSITE_SEARCH_M,
    _PT_PARAMS,
    VALID_MODES,
    assign_reverse_link_ids,
    build_intersection_sql,
    determine_region,
    get_pt_params,
    heading,
    offset_linestring,
    point_in_polygon,
    post_process_features,
    rows_to_feature_collection,
    slugify,
    to_bbox,
    to_polygon_geojson,
)
from stalled.network_intersector.domain.sql import _DAYPART_KEYS


# ---------------------------------------------------------------------------
# build_intersection_sql
# ---------------------------------------------------------------------------

class TestBuildIntersectionSql:
    def test_car_contains_db_prefix(self):
        sql = build_intersection_sql("CAR", "spectrum", "2024_01")
        assert "spectrum.`2024_01`.d110_toedeelbaar_autonetwerk" in sql

    def test_bike_contains_fiets_table(self):
        sql = build_intersection_sql("BIKE", "spectrum", "2023_01")
        assert "d120_toedeelbaar_fietsnetwerk" in sql

    def test_pedestrian_uses_catalog_dot_pedestrians(self):
        sql = build_intersection_sql("PEDESTRIAN", "spectrum", "2023_01")
        assert "spectrum.pedestrians.flows" in sql

    @pytest.mark.parametrize("mode", ["BUS", "TRAM", "METRO", "TRAIN"])
    def test_pt_modes_contain_ov_table(self, mode):
        sql = build_intersection_sql(mode, "spectrum", "2023_01")
        assert "d140_toedeelbaar_ov_netwerk_links" in sql

    def test_car_has_single_placeholder(self):
        sql = build_intersection_sql("CAR", "spectrum", "2023_01")
        assert sql.count("?") == 1

    def test_bike_has_single_placeholder(self):
        sql = build_intersection_sql("BIKE", "spectrum", "2023_01")
        assert sql.count("?") == 1

    def test_pedestrian_has_single_placeholder(self):
        sql = build_intersection_sql("PEDESTRIAN", "spectrum", "2023_01")
        assert sql.count("?") == 1

    @pytest.mark.parametrize("mode", ["BUS", "TRAM", "METRO", "TRAIN"])
    def test_pt_has_four_placeholders(self, mode):
        sql = build_intersection_sql(mode, "spectrum", "2023_01")
        assert sql.count("?") == 4

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError, match="Unsupported mode"):
            build_intersection_sql("HELICOPTER", "spectrum", "2023_01")

    def test_all_valid_modes_accepted(self):
        for mode in VALID_MODES:
            sql = build_intersection_sql(mode, "spectrum", "2023_01")
            assert "?" in sql

    def test_catalog_schema_in_sql_car(self):
        sql = build_intersection_sql("CAR", "mycatalog", "2025_01")
        assert "mycatalog.`2025_01`" in sql

    def test_flow_pivot_columns_present(self):
        sql = build_intersection_sql("CAR", "spectrum", "2023_01")
        for key in _MOTIEF_KEYS:
            assert f"flow_heen_{key}" in sql
            assert f"flow_terug_{key}" in sql

    def test_daypart_pivot_columns_present(self):
        for mode in ("CAR", "BIKE"):
            sql = build_intersection_sql(mode, "spectrum", "2023_01")
            for dp in _DAYPART_KEYS:
                assert f"flow_dp_heen_{dp}" in sql, f"Missing flow_dp_heen_{dp} in {mode} SQL"
                assert f"flow_dp_terug_{dp}" in sql, f"Missing flow_dp_terug_{dp} in {mode} SQL"

    def test_daypart_pivot_columns_present_pedestrian(self):
        sql = build_intersection_sql("PEDESTRIAN", "spectrum", "2023_01")
        for dp in _DAYPART_KEYS:
            assert f"flow_dp_heen_{dp}" in sql
            assert f"flow_dp_terug_{dp}" in sql

    @pytest.mark.parametrize("mode", ["BUS", "TRAM", "METRO", "TRAIN"])
    def test_daypart_pivot_columns_present_pt(self, mode):
        sql = build_intersection_sql(mode, "spectrum", "2023_01")
        for dp in _DAYPART_KEYS:
            assert f"flow_dp_heen_{dp}" in sql
            assert f"flow_dp_terug_{dp}" in sql


# ---------------------------------------------------------------------------
# get_pt_params
# ---------------------------------------------------------------------------

class TestGetPtParams:
    @pytest.mark.parametrize("mode,link_mode,modaliteit", [
        ("BUS",   "other", "bus"),
        ("TRAM",  "other", "tram"),
        ("METRO", "other", "metro"),
        ("TRAIN", "train", "trein"),
    ])
    def test_known_modes(self, mode, link_mode, modaliteit):
        lm, mod = get_pt_params(mode)
        assert lm == link_mode
        assert mod == modaliteit

    def test_unknown_raises_key_error(self):
        with pytest.raises(KeyError):
            get_pt_params("FERRY")


# ---------------------------------------------------------------------------
# to_polygon_geojson
# ---------------------------------------------------------------------------

class TestToPolygonGeojson:
    def test_4element_bbox(self):
        result = to_polygon_geojson({"bbox": [4.0, 52.0, 5.0, 53.0]})
        obj = json.loads(result)
        assert obj["type"] == "Polygon"
        ring = obj["coordinates"][0]
        assert len(ring) == 5
        assert ring[0] == ring[-1]  # closed

    def test_6element_bbox_ignores_z(self):
        result = to_polygon_geojson({"bbox": [4.0, 52.0, 0.0, 5.0, 53.0, 100.0]})
        obj = json.loads(result)
        assert obj["type"] == "Polygon"

    def test_polygon_ring_input(self):
        ring = [[4.0, 52.0], [5.0, 52.0], [5.0, 53.0], [4.0, 53.0]]
        result = to_polygon_geojson({"bbox": ring})
        obj = json.loads(result)
        assert obj["type"] == "Polygon"
        # ring should be auto-closed
        assert obj["coordinates"][0][0] == obj["coordinates"][0][-1]

    def test_polygon_ring_already_closed(self):
        ring = [[4.0, 52.0], [5.0, 52.0], [5.0, 53.0], [4.0, 53.0], [4.0, 52.0]]
        result = to_polygon_geojson({"bbox": ring})
        obj = json.loads(result)
        assert len(obj["coordinates"][0]) == 5  # not doubled

    def test_missing_bbox_raises(self):
        with pytest.raises(ValueError, match="bbox is required"):
            to_polygon_geojson({})

    def test_wrong_length_raises(self):
        with pytest.raises(ValueError, match="4 or 6"):
            to_polygon_geojson({"bbox": [1.0, 2.0, 3.0]})


# ---------------------------------------------------------------------------
# to_bbox
# ---------------------------------------------------------------------------

class TestToBbox:
    def test_4element(self):
        assert to_bbox({"bbox": [4.0, 52.0, 5.0, 53.0]}) == [4.0, 52.0, 5.0, 53.0]

    def test_6element(self):
        result = to_bbox({"bbox": [4.0, 52.0, 0.0, 5.0, 53.0, 100.0]})
        assert result == [4.0, 52.0, 5.0, 53.0]

    def test_ring_input_gives_extent(self):
        ring = [[4.0, 52.0], [5.0, 52.0], [5.0, 53.0], [3.5, 53.5]]
        result = to_bbox({"bbox": ring})
        assert result == [3.5, 52.0, 5.0, 53.5]

    def test_missing_bbox_raises(self):
        with pytest.raises(ValueError):
            to_bbox({})

    def test_wrong_length_raises(self):
        with pytest.raises(ValueError):
            to_bbox({"bbox": [1.0, 2.0]})


# ---------------------------------------------------------------------------
# rows_to_feature_collection
# ---------------------------------------------------------------------------

class TestRowsToFeatureCollection:
    def _make_rows(self):
        """Return (rows, col_names) for a minimal two-row result."""
        geom_str = json.dumps({"type": "LineString", "coordinates": [[0, 0], [1, 1]]})
        col_names = (
            ["segment_id", "geom", "mode", "from_node", "to_node",
             "rijrichting_heen", "cap_heen", "rijstroken_heen", "max_snelheid_heen"]
            + [f"flow_heen_{k}" for k in _MOTIEF_KEYS]
            + ["rijrichting_terug", "cap_terug", "rijstroken_terug", "max_snelheid_terug"]
            + [f"flow_terug_{k}" for k in _MOTIEF_KEYS]
            + [f"flow_dp_heen_{k}" for k in _DAYPART_KEYS]
            + [f"flow_dp_terug_{k}" for k in _DAYPART_KEYS]
            + ["length"]
        )
        row = (
            1, geom_str, "CAR", 10, 20,
            True, 2000, 2, 80,
            100.0, 50.0, 0.0, 0.0, 0.0,
            80.0, 40.0, 0.0, 0.0, 0.0,
            True, 2000, 2, 80,
            # daypart heen: os, as, rd
            60.0, 50.0, 30.0,
            # daypart terug: os, as, rd
            45.0, 40.0, 25.0,
            150.0,
        )
        return [row, row], col_names

    def test_returns_feature_collection(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        assert fc["type"] == "FeatureCollection"
        assert len(fc["features"]) == 2

    def test_flow_pivot_folded(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert "flow_heen" in props
        assert "flow_terug" in props
        assert props["flow_heen"]["work"] == 100.0

    def test_daypart_pivot_folded(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert "flow_dp_heen" in props
        assert "flow_dp_terug" in props
        assert props["flow_dp_heen"]["mrh"] == 60.0
        assert props["flow_dp_terug"]["rest"] == 25.0

    def test_geom_is_parsed(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        geom = fc["features"][0]["geometry"]
        assert geom["type"] == "LineString"

    def test_geom_column_removed_from_props(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert "geom" not in props

    def test_empty_rows(self):
        fc = rows_to_feature_collection([], ["segment_id", "geom", "mode"], "CAR")
        assert fc["features"] == []

    def test_modes_in_properties(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "BIKE")
        assert fc["properties"]["modes"] == ["BIKE"]

    def test_link_properties_in_properties(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        assert "link_properties" in fc["properties"]
        assert isinstance(fc["properties"]["link_properties"], list)


# ---------------------------------------------------------------------------
# heading
# ---------------------------------------------------------------------------

class TestHeading:
    def test_north(self):
        # going straight north (increasing lat)
        assert heading([[0.0, 0.0], [0.0, 1.0]]) == pytest.approx(0.0, abs=1.0)

    def test_east(self):
        # going east (increasing lon), at equator cos_lat ≈ 1
        h = heading([[0.0, 0.0], [1.0, 0.0]])
        assert abs(h - 90.0) < 2.0

    def test_south(self):
        h = heading([[0.0, 1.0], [0.0, 0.0]])
        assert abs(h - 180.0) < 2.0

    def test_west(self):
        h = heading([[1.0, 0.0], [0.0, 0.0]])
        assert abs(h - 270.0) < 2.0

    def test_in_range(self):
        for lon_diff in [-1.0, 0.0, 1.0]:
            h = heading([[0.0, 0.0], [lon_diff, 1.0]])
            assert 0.0 <= h < 360.0


# ---------------------------------------------------------------------------
# offset_linestring
# ---------------------------------------------------------------------------

class TestOffsetLinestring:
    def _simple_ns(self, lon: float = 0.0, lat0: float = 52.0, lat1: float = 52.01):
        """A simple north–south two-point LineString."""
        return [[lon, lat0], [lon, lat1]]

    def test_same_point_count_for_short_segment(self):
        coords = self._simple_ns()
        result = offset_linestring(coords, _OFFSET_M)
        # 2 original + up to 2 transition nodes
        assert len(result) >= 2

    def test_endpoints_unchanged(self):
        coords = [[4.0, 52.0], [4.1, 52.05], [4.2, 52.0]]
        result = offset_linestring(coords, _OFFSET_M)
        assert result[0] == pytest.approx(coords[0], abs=1e-10)
        assert result[-1] == pytest.approx(coords[-1], abs=1e-10)

    def test_offset_is_applied(self):
        coords = [[4.0, 52.0], [4.0, 52.1]]
        result = offset_linestring(coords, _OFFSET_M)
        # Interior nodes must be shifted east (positive lon offset for northward travel)
        interior = result[1:-1]
        assert any(pt[0] != 4.0 for pt in interior)

    def test_single_coord_returns_itself(self):
        coords = [[4.0, 52.0]]
        result = offset_linestring(coords, _OFFSET_M)
        assert result == [[4.0, 52.0]]

    def test_near_node_m_constants_exported(self):
        # Ensure the constants are accessible and have expected relative order
        assert _NEAR_NODE_M > _NEAR_NODE_M_MED > _NEAR_NODE_M_SHT > 0


# ---------------------------------------------------------------------------
# post_process_features
# ---------------------------------------------------------------------------

def _make_raw_feature(
    seg_id: int,
    coords: list,
    *,
    heen: bool = True,
    terug: bool = True,
    flow_heen: float = 100.0,
    flow_terug: float = 80.0,
) -> dict:
    """Construct a raw feature as returned by rows_to_feature_collection."""
    return {
        "type":     "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId":            seg_id,
            "mode":              "CAR",
            "fromNode":         1,
            "toNode":           2,
            "rijrichting_heen":  heen,
            "cap_heen":          2000,
            "rijstroken_heen":   2,
            "max_snelheid_heen": 80,
            "rijrichting_terug": terug,
            "cap_terug":         2000,
            "rijstroken_terug":  2,
            "max_snelheid_terug": 80,
            "length":            100.0,
            "flow_heen":  {"work": flow_heen, "recreational": 0, "education": 0,
                           "shopping": 0, "unknown": 0},
            "flow_terug": {"work": flow_terug, "recreational": 0, "education": 0,
                           "shopping": 0, "unknown": 0},
            "flow_dp_heen":  {"mrh": 60.0, "erh": 50.0, "rest": 30.0},
            "flow_dp_terug": {"mrh": 45.0, "erh": 40.0, "rest": 25.0},
        },
    }


_COORDS_NS = [[4.0, 52.0], [4.0, 52.1]]
_COORDS_EW = [[4.0, 52.0], [4.1, 52.0]]


class TestPostProcessFeatures:
    def test_bidir_produces_two_features(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        assert len(result) == 2

    def test_heen_only_produces_one_feature(self):
        features = [_make_raw_feature(1, _COORDS_NS, terug=False)]
        result = post_process_features(features)
        assert len(result) == 1

    def test_terug_only_produces_one_feature(self):
        features = [_make_raw_feature(1, _COORDS_NS, heen=False)]
        result = post_process_features(features)
        assert len(result) == 1

    def test_neither_direction_omitted(self):
        features = [_make_raw_feature(1, _COORDS_NS, flow_heen=0.0, flow_terug=0.0)]
        result = post_process_features(features)
        assert len(result) == 0

    def test_bidir_opposite_ids_set(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        ids = {r["properties"]["spectrumId"] for r in result}
        assert 1 in ids
        assert -1 in ids
        for r in result:
            assert r["properties"]["reverseLinkIds"] is not None

    def test_heading_present(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            h = r["properties"]["heading"]
            assert 0.0 <= h < 360.0

    def test_flow24hrs_computed(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            assert r["properties"]["flow24hrs"] > 0
            assert r["properties"]["flow"] > 0
            assert isinstance(r["properties"]["flowsPerMotive"], dict)

    def test_flow_temporal_unit_is_24(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            assert r["properties"]["flowTemporalUnit"] == 24

    def test_flows_per_daypart_present(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            dp = r["properties"]["flowsPerDaypart"]
            assert isinstance(dp, dict)
            assert set(dp.keys()) == {"mrh", "erh", "rest"}

    def test_terug_only_geometry_reversed(self):
        features = [_make_raw_feature(1, _COORDS_NS, heen=False)]
        result = post_process_features(features)
        coords = result[0]["geometry"]["coordinates"]
        # first point should be the original last point
        assert coords[0] == pytest.approx(_COORDS_NS[-1], abs=1e-9)

    def test_empty_input(self):
        assert post_process_features([]) == []

    def test_multiple_features_processed(self):
        features = [
            _make_raw_feature(1, _COORDS_NS),
            _make_raw_feature(2, _COORDS_EW),
        ]
        result = post_process_features(features)
        assert len(result) == 4  # 2 bidir × 2 directions


# ---------------------------------------------------------------------------
# assign_reverse_link_ids
# ---------------------------------------------------------------------------

class TestAssignReverseLinkIds:
    def _make_directed(self, seg_id, coords):
        return {
            "type":     "Feature",
            "geometry": {"type": "LineString", "coordinates": coords},
            "properties": {
                "spectrumId":    seg_id,
                "reverseLinkIds": [],
            },
        }

    def test_parallel_reverse_pair_matched(self):
        # Two N–S links with 3 coords so len//2==1 picks the centre node.
        # Centre nodes differ by 0.0002° lon at lat 52° ≈ 13.7 m — within 25 m threshold.
        f1 = self._make_directed(1, [[4.0000, 52.00], [4.0000, 52.005], [4.0000, 52.01]])
        f2 = self._make_directed(2, [[4.0002, 52.01], [4.0002, 52.005], [4.0002, 52.00]])
        features = [f1, f2]
        assign_reverse_link_ids(features)
        assert f1["properties"]["reverseLinkIds"] == [2]
        assert f2["properties"]["reverseLinkIds"] == [1]

    def test_no_match_far_apart(self):
        f1 = self._make_directed(1, [[4.0, 52.0], [4.0, 52.1]])
        f2 = self._make_directed(2, [[6.0, 52.0], [6.0, 52.1]])  # far away
        features = [f1, f2]
        assign_reverse_link_ids(features)
        assert f1["properties"]["reverseLinkIds"] == []
        assert f2["properties"]["reverseLinkIds"] == []

    def test_already_assigned_skipped(self):
        f1 = self._make_directed(1, [[4.0, 52.0], [4.0, 52.1]])
        f1["properties"]["reverseLinkIds"] = [99]  # already set
        f2 = self._make_directed(2, [[4.001, 52.1], [4.001, 52.0]])
        features = [f1, f2]
        assign_reverse_link_ids(features)
        # f1 already has reverseLinkIds — should remain unchanged
        assert f1["properties"]["reverseLinkIds"] == [99]


# ---------------------------------------------------------------------------
# point_in_polygon
# ---------------------------------------------------------------------------

class TestPointInPolygon:
    _SQUARE = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.0, 0.0]]

    def test_inside(self):
        assert point_in_polygon(0.5, 0.5, self._SQUARE) is True

    def test_outside(self):
        assert point_in_polygon(2.0, 2.0, self._SQUARE) is False

    def test_on_edge_corner(self):
        # Ray-casting corner case — just verify no exception
        point_in_polygon(0.0, 0.0, self._SQUARE)

    def test_empty_ring(self):
        assert point_in_polygon(0.5, 0.5, []) is False


# ---------------------------------------------------------------------------
# determine_region
# ---------------------------------------------------------------------------

class TestDetermineRegion:
    _REGION_FC = [
        {
            "geometry": {
                "type": "Polygon",
                "coordinates": [[[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0], [0.0, 0.0]]],
            },
            "properties": {"regio": "Randstad"},
        }
    ]

    def test_inside_returns_region(self):
        bbox = [0.5, 0.5, 1.5, 1.5]  # centroid (1,1) is inside
        assert determine_region(bbox, self._REGION_FC) == "Randstad"

    def test_outside_returns_none(self):
        bbox = [5.0, 5.0, 6.0, 6.0]  # centroid far outside
        assert determine_region(bbox, self._REGION_FC) is None

    def test_empty_features_returns_none(self):
        assert determine_region([0.5, 0.5, 1.5, 1.5], []) is None

    def test_empty_bbox_returns_none(self):
        assert determine_region([], self._REGION_FC) is None

    def test_non_polygon_feature_skipped(self):
        features = [
            {
                "geometry": {"type": "Point", "coordinates": [1.0, 1.0]},
                "properties": {"regio": "Nowhere"},
            }
        ]
        assert determine_region([0.5, 0.5, 1.5, 1.5], features) is None


# ---------------------------------------------------------------------------
# slugify
# ---------------------------------------------------------------------------

class TestSlugify:
    def test_basic(self):
        assert slugify("Hello World") == "hello-world"

    def test_special_chars_removed(self):
        assert slugify("My Test Area!") == "my-test-area"

    def test_underscores_to_hyphens(self):
        assert slugify("test_area") == "test-area"

    def test_consecutive_hyphens_collapsed(self):
        assert slugify("test--area") == "test-area"

    def test_empty_string_returns_uuid(self):
        result = slugify("")
        # UUID fallback — should be non-empty
        assert len(result) > 0

    def test_leading_trailing_hyphens_stripped(self):
        result = slugify("-hello-")
        assert not result.startswith("-")
        assert not result.endswith("-")
