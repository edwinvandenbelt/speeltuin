"""
Smoke tests for the intersect-area Lambda handler.

The Databricks SQL warehouse is not available during CI, so
databricks.sql.connect is mocked.  Tests verify:
  - _to_polygon_geojson input normalisation
  - correct SQL is dispatched per mode
  - the handler returns 200 with the expected shape on a happy path
  - the handler returns 400 on bad inputs
"""

import importlib.util
import json
import os
import pathlib
import sys
from unittest.mock import MagicMock, patch

# Load the Lambda handler from lambda/network_intersector.py via importlib so that
# "lambda" (a Python keyword) never appears in a Python import statement.
# Registering as "network_intersector_handler" keeps patch() target strings stable.
_HANDLER_FILE = pathlib.Path(__file__).parent.parent / "lambda" / "network_intersector.py"
_spec = importlib.util.spec_from_file_location("network_intersector_handler", _HANDLER_FILE)
_mod = importlib.util.module_from_spec(_spec)
sys.modules["network_intersector_handler"] = _mod
_spec.loader.exec_module(_mod)

_to_polygon_geojson    = _mod.to_polygon_geojson
_intersect_mode        = _mod._intersect_mode
_post_process_features = _mod.post_process_features
_determine_region      = _mod.determine_region
handler                = _mod.handler

# offset_linestring, heading and point_in_polygon are not re-exported by the
# handler; load them directly from network_intersector_core.
import sys as _sys2
import importlib.util as _ilu2
import pathlib as _pl2
_CORE_FILE = _pl2.Path(__file__).parent.parent / "network_intersector_core.py"
_core_spec = _ilu2.spec_from_file_location("network_intersector_core_test", _CORE_FILE)
_core_mod  = _ilu2.module_from_spec(_core_spec)
_sys2.modules["network_intersector_core_test"] = _core_mod
_core_spec.loader.exec_module(_core_mod)
_offset_linestring = _core_mod.offset_linestring
_heading           = _core_mod.heading
_point_in_polygon  = _core_mod.point_in_polygon


# ---------------------------------------------------------------------------
# Fake DB helpers
# ---------------------------------------------------------------------------

_EMPTY_FC = json.dumps({"type": "FeatureCollection", "features": []})


def _mock_conn():
    """Return a mock Databricks connection whose cursor returns no rows."""
    cur = MagicMock()
    cur.__enter__ = lambda s: s
    cur.__exit__ = MagicMock(return_value=False)
    cur.fetchall.return_value = []
    cur.description = []

    conn = MagicMock()
    conn.cursor.return_value = cur
    conn.close = MagicMock()
    return conn, cur


# ---------------------------------------------------------------------------
# _to_polygon_geojson
# ---------------------------------------------------------------------------

def test_polygon_from_flat_bbox():
    poly = _to_polygon_geojson({"bbox": [4.9, 52.3, 5.0, 52.4]})
    obj = json.loads(poly)
    assert obj["type"] == "Polygon"
    ring = obj["coordinates"][0]
    # must be closed
    assert ring[0] == ring[-1]
    # must cover the bbox corners
    xs = [p[0] for p in ring]
    ys = [p[1] for p in ring]
    assert min(xs) == 4.9 and max(xs) == 5.0
    assert min(ys) == 52.3 and max(ys) == 52.4


def test_polygon_from_3d_bbox():
    poly = _to_polygon_geojson({"bbox": [4.9, 52.3, 0.0, 5.0, 52.4, 100.0]})
    obj = json.loads(poly)
    ring = obj["coordinates"][0]
    xs = [p[0] for p in ring]
    ys = [p[1] for p in ring]
    assert min(xs) == 4.9 and max(xs) == 5.0
    assert min(ys) == 52.3 and max(ys) == 52.4


def test_polygon_from_ring():
    ring_input = [[4.9, 52.3], [5.0, 52.3], [5.0, 52.4], [4.9, 52.4]]
    poly = _to_polygon_geojson({"bbox": ring_input})
    obj = json.loads(poly)
    assert obj["type"] == "Polygon"
    # ring is auto-closed
    assert len(obj["coordinates"][0]) == 5


def test_polygon_from_closed_ring():
    ring_input = [[4.9, 52.3], [5.0, 52.3], [5.0, 52.4], [4.9, 52.4], [4.9, 52.3]]
    poly = _to_polygon_geojson({"bbox": ring_input})
    obj = json.loads(poly)
    # should not double-close
    assert len(obj["coordinates"][0]) == 5


def test_polygon_missing_bbox_raises():
    try:
        _to_polygon_geojson({})
        assert False, "should have raised ValueError"
    except ValueError:
        pass


# ---------------------------------------------------------------------------
# _intersect_mode – SQL dispatch
# ---------------------------------------------------------------------------

def test_intersect_mode_car_uses_correct_sql():
    conn, cur = _mock_conn()
    polygon = '{"type":"Polygon","coordinates":[[[4.9,52.3],[5.0,52.3],[5.0,52.4],[4.9,52.4],[4.9,52.3]]]}'

    _intersect_mode("CAR", polygon, conn)

    called_sql = cur.execute.call_args[0][0]
    assert "CAR" in called_sql
    assert cur.execute.call_args[0][1] == (polygon,)


def test_intersect_mode_bike_uses_correct_sql():
    conn, cur = _mock_conn()
    polygon = _EMPTY_FC
    _intersect_mode("BIKE", polygon, conn)
    assert "BIKE" in cur.execute.call_args[0][0]


def test_intersect_mode_train_uses_pt_sql():
    conn, cur = _mock_conn()
    polygon = '{"type":"Polygon","coordinates":[[]]}'
    _intersect_mode("TRAIN", polygon, conn)
    called_sql, params = cur.execute.call_args[0]
    assert "TRAIN" in called_sql or "modaliteit" in called_sql
    link_mode, poly_param, modaliteit, mode_label = params
    assert link_mode == "train"
    assert modaliteit == "trein"
    assert mode_label == "TRAIN"
    assert poly_param == polygon


def test_intersect_mode_bus_uses_pt_sql():
    conn, cur = _mock_conn()
    _intersect_mode("BUS", _EMPTY_FC, conn)
    called_sql, params = cur.execute.call_args[0]
    assert "BUS" in called_sql or "modaliteit" in called_sql
    assert params[0] == "other"   # link_mode
    assert params[2] == "bus"     # modaliteit


def test_intersect_mode_unknown_raises():
    conn, cur = _mock_conn()
    try:
        _intersect_mode("HOVERCRAFT", _EMPTY_FC, conn)
        assert False, "should have raised ValueError"
    except ValueError as exc:
        assert "Unsupported mode" in str(exc)


def test_intersect_mode_returns_empty_fc_on_no_rows():
    conn, cur = _mock_conn()
    cur.fetchall.return_value = []
    result = _intersect_mode("CAR", _EMPTY_FC, conn)
    assert result == {
        "type": "FeatureCollection",
        "features": [],
        "properties": {"link_properties": list(_core_mod.LINK_PROPERTIES)},
    }


# ---------------------------------------------------------------------------
# _post_process_features
# ---------------------------------------------------------------------------

def _make_raw_feature(heen=True, terug=True, seg_id=42):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString",
                     "coordinates": [[5.0, 52.0], [5.05, 52.0], [5.1, 52.0]]},
        "properties": {
            "linkId": seg_id, "mode": "CAR",
            "fromNode": 1, "toNode": 2,
            "rijrichting_heen": heen,  "rijrichting_terug": terug,
            "cap_heen": 1500,  "rijstroken_heen": 1,  "max_snelheid_heen": 50.0,
            "flow_heen": {"work": 10.0},
            "cap_terug": 1400, "rijstroken_terug": 1, "max_snelheid_terug": 50.0,
            "flow_terug": {"work": 8.0},
            "length": 100.0,
        },
    }


def test_post_process_bidirectional_splits_into_two():
    result = _post_process_features([_make_raw_feature(heen=True, terug=True)])
    assert len(result) == 2
    ids = {f["properties"]["spectrumId"] for f in result}
    assert ids == {42, -42}


def test_post_process_heen_only_keeps_one():
    result = _post_process_features([_make_raw_feature(heen=True, terug=False)])
    assert len(result) == 1
    p = result[0]["properties"]
    assert p["spectrumId"] == 42
    assert p["fromNode"] == 1 and p["toNode"] == 2
    assert p["capacity"] == 1500
    assert p["flowsPerMotive"] == {"work": 10.0}
    assert p["flow"] == 10.0
    assert p["flow24hrs"] == 10.0
    assert p["length"] == 100.0
    # east-going link → heading ≈ 90°
    assert abs(p["heading"] - 90.0) < 1.0
    # single feature, no other link to pair with → reverseLinkIds stays []
    assert p["reverseLinkIds"] == []
    assert "rijrichting_heen" not in p


def test_post_process_terug_only_reverses():
    result = _post_process_features([_make_raw_feature(heen=False, terug=True)])
    assert len(result) == 1
    feat = result[0]
    p = feat["properties"]
    assert p["spectrumId"] == -42
    assert p["fromNode"] == 2 and p["toNode"] == 1   # flipped
    assert p["capacity"] == 1400
    assert p["flowsPerMotive"] == {"work": 8.0}
    assert p["flow"] == 8.0
    assert p["flow24hrs"] == 8.0
    assert p["length"] == 100.0
    # reversed east-going link → goes west → heading ≈ 270°
    assert abs(p["heading"] - 270.0) < 1.0
    assert p["reverseLinkIds"] == []
    # geometry starts at the original end coordinate (reversed)
    orig_end = [5.1, 52.0]
    assert feat["geometry"]["coordinates"][0] == orig_end


def test_post_process_flow24hrs():
    """flow_24_hrs equals sum of all entries in the flow dict."""
    feat = _make_raw_feature(heen=True, terug=True)
    feat["properties"]["flow_heen"]  = {"work": 10.0, "recreational": 5.0,
                                        "education": 3.0, "shopping": 2.0, "unknown": 1.0}
    feat["properties"]["flow_terug"] = {"work": 8.0,  "recreational": 0.0,
                                        "education": 0.0, "shopping": 0.0, "unknown": 0.5}
    result = _post_process_features([feat])
    heen  = next(f for f in result if f["properties"]["spectrumId"] ==  42)
    terug = next(f for f in result if f["properties"]["spectrumId"] == -42)
    assert heen["properties"]["flow24hrs"]  == 21.0
    assert heen["properties"]["flow"]       == 21.0
    assert terug["properties"]["flow24hrs"] == 8.5
    assert terug["properties"]["flow"]      == 8.5


def test_post_process_heading_and_opposite_bidir():
    """Bidir split: heen ≈ 90° (east), terug ≈ 270° (west); reverseLinkIds cross-reference."""
    result = _post_process_features([_make_raw_feature(heen=True, terug=True)])
    heen  = next(f for f in result if f["properties"]["spectrumId"] ==  42)
    terug = next(f for f in result if f["properties"]["spectrumId"] == -42)

    assert abs(heen["properties"]["heading"]  -  90.0) < 1.0
    assert abs(terug["properties"]["heading"] - 270.0) < 1.0

    assert heen["properties"]["reverseLinkIds"]  == [-42]
    assert terug["properties"]["reverseLinkIds"] == [42]


def _make_unidirectional(seg_id, lat, *, going_east: bool):
    """Helper: heen-only (east) or terug-only (will be reversed to west) at given lat."""
    coords = [[5.0, lat], [5.05, lat], [5.1, lat]]
    if going_east:
        return {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": coords},
            "properties": {
                "linkId": seg_id, "mode": "CAR",
                "fromNode": 10, "toNode": 20,
                "rijrichting_heen": True,  "rijrichting_terug": False,
                "cap_heen": 1500, "rijstroken_heen": 1, "max_snelheid_heen": 50.0,
                "flow_heen":  {"work": 10.0},
                "cap_terug": 0, "rijstroken_terug": 0, "max_snelheid_terug": 0,
                "flow_terug": {"work": 0.0},
                "length": 5500.0,
            },
        }
    else:
        return {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": coords},
            "properties": {
                "linkId": seg_id, "mode": "CAR",
                "fromNode": 10, "toNode": 20,
                "rijrichting_heen": False, "rijrichting_terug": True,
                "cap_heen": 0, "rijstroken_heen": 0, "max_snelheid_heen": 0,
                "flow_heen":  {"work": 0.0},
                "cap_terug": 1400, "rijstroken_terug": 1, "max_snelheid_terug": 50.0,
                "flow_terug": {"work": 8.0},
                "length": 5500.0,
            },
        }


def test_post_process_unidirectional_opposite_detection():
    """Two unidirectional links ~11 m apart going in opposite directions find each other."""
    # spectrum_id 100 → heen-only going east at lat 52.0
    # spectrum_id 200 → terug-only reversed to go west at lat 52.0001 (~11 m north)
    feat_a = _make_unidirectional(100, 52.0,    going_east=True)
    feat_b = _make_unidirectional(200, 52.0001, going_east=False)

    result = _post_process_features([feat_a, feat_b])
    assert len(result) == 2

    a = next(f for f in result if f["properties"]["spectrumId"] ==  100)
    b = next(f for f in result if f["properties"]["spectrumId"] == -200)

    assert abs(a["properties"]["heading"] -  90.0) < 1.0, "a should go east"
    assert abs(b["properties"]["heading"] - 270.0) < 1.0, "b should go west"

    assert a["properties"]["reverseLinkIds"] == [-200]
    assert b["properties"]["reverseLinkIds"] == [100]


def test_post_process_unidirectional_no_opposite_when_too_far():
    """Links > _OPPOSITE_SEARCH_M apart must not be paired."""
    feat_a = _make_unidirectional(100, 52.0,  going_east=True)
    feat_b = _make_unidirectional(200, 52.002, going_east=False)  # ~222 m north

    result = _post_process_features([feat_a, feat_b])
    a = next(f for f in result if f["properties"]["spectrumId"] ==  100)
    b = next(f for f in result if f["properties"]["spectrumId"] == -200)

    assert a["properties"]["reverseLinkIds"] == []
    assert b["properties"]["reverseLinkIds"] == []



def test_offset_near_node_adapts_to_link_length():
    """
    _offset_linestring uses a shorter transition distance for shorter links.

    For a purely eastward 2-node link the near-start transition node sits at
    x = near_m / d_lon east of the origin (udx=1, nx=0).  We verify the ratio
    of x-offsets matches the expected near_m ratios:

        long  (≥10 m) → near_m = 3.0
        medium (3-10 m) → near_m = 1.0   (ratio long/med  ≈ 3)
        short   (<3 m) → near_m = 0.5   (ratio med/short ≈ 2)
    """
    import math
    lat0  = 52.0
    d_lon = 111_320.0 * math.cos(math.radians(lat0))

    # ~68 m link  → near_m = 3.0
    out_long  = _offset_linestring([[0.0, lat0], [0.001,   lat0]], 2.0)
    # ~6.9 m link → near_m = 1.0
    out_med   = _offset_linestring([[0.0, lat0], [0.0001,  lat0]], 2.0)
    # ~2.1 m link → near_m = 0.5
    out_short = _offset_linestring([[0.0, lat0], [0.00003, lat0]], 2.0)

    # All three: 2-node input → 4-node output (start, near_start, near_end, end)
    assert len(out_long)  == 4, f"long: expected 4 nodes, got {len(out_long)}"
    assert len(out_med)   == 4, f"med:  expected 4 nodes, got {len(out_med)}"
    assert len(out_short) == 4, f"short: expected 4 nodes, got {len(out_short)}"

    # near_start is index 1; its x-coordinate = near_m / d_lon
    # (origin is [0.0, lat0], direction is east, right-normal is south → no x shift from offset)
    near_x_long  = out_long[1][0]
    near_x_med   = out_med[1][0]
    near_x_short = out_short[1][0]

    assert abs(near_x_long / near_x_med  - 3.0) < 0.01, \
        f"expected long/med ratio 3.0, got {near_x_long / near_x_med:.4f}"
    assert abs(near_x_med  / near_x_short - 2.0) < 0.01, \
        f"expected med/short ratio 2.0, got {near_x_med / near_x_short:.4f}"


def test_post_process_bidir_geometry_is_offset():
    """
    For a 3-node input (segments >> _NEAR_NODE_M) the output must be 5 nodes:
      [orig_start, near_start_offset, interior_offset, near_end_offset, orig_end]

    Assertions:
    - endpoints unchanged
    - interior and transition nodes are offset (differ from original coords)
    - heen and terug are offset to opposite sides (different y for an E-W link)
    - terug endpoint order matches reversed original (orig_end first, orig_start last)
    """
    _NEAR_NODE_M = _core_mod._NEAR_NODE_M  # import constant for clarity

    result = _post_process_features([_make_raw_feature(heen=True, terug=True)])
    heen  = next(f for f in result if f["properties"]["spectrumId"] ==  42)
    terug = next(f for f in result if f["properties"]["spectrumId"] == -42)

    orig = [[5.0, 52.0], [5.05, 52.0], [5.1, 52.0]]

    heen_coords  = heen["geometry"]["coordinates"]
    terug_coords = terug["geometry"]["coordinates"]

    # --- node count: start + near_start + interior + near_end + end = 5 ---
    assert len(heen_coords)  == 5, f"expected 5 nodes for heen, got {len(heen_coords)}"
    assert len(terug_coords) == 5, f"expected 5 nodes for terug, got {len(terug_coords)}"

    # --- endpoints stay at original positions ---
    assert heen_coords[0]  == orig[0],  "heen start must equal orig start"
    assert heen_coords[-1] == orig[-1], "heen end must equal orig end"
    assert terug_coords[0]  == orig[-1], "terug start must equal orig end (reversed)"
    assert terug_coords[-1] == orig[0],  "terug end must equal orig start (reversed)"

    # --- interior + transition nodes are offset from their original positions ---
    # node 1 is the transition node near the start
    assert heen_coords[1]  != orig[0], "near-start transition must be offset"
    # node 2 is the interior (middle) node
    assert heen_coords[2]  != orig[1], "interior node must be offset from orig mid"
    # node 3 is the transition node near the end
    assert heen_coords[3]  != orig[-1], "near-end transition must be offset"

    # --- heen and terug offset to opposite sides ---
    # For a purely east-west link (lat=52.0) the right-hand offset is southward
    # for heen (going east) and northward for terug (going west).
    heen_mid_y  = heen_coords[2][1]
    terug_mid_y = terug_coords[2][1]
    assert heen_mid_y != terug_mid_y, "heen and terug middle nodes must be on opposite sides"
    assert heen_mid_y  < orig[1][1], "heen (eastward) offset should be south of centreline"
    assert terug_mid_y > orig[1][1], "terug (westward) offset should be north of centreline"


def test_post_process_neither_direction_dropped():
    result = _post_process_features([_make_raw_feature(heen=False, terug=False)])
    assert result == []


def test_post_process_zero_flow_overrides_rijrichting():
    """rijrichting_heen=True but flow_heen all zeros → treated as heen=False."""
    feat = _make_raw_feature(heen=True, terug=True)
    feat["properties"]["flow_heen"] = {"work": 0.0, "recreational": 0.0,
                                       "education": 0.0, "shopping": 0.0, "unknown": 0.0}
    result = _post_process_features([feat])
    # Only terug should survive
    assert len(result) == 1
    assert result[0]["properties"]["spectrumId"] == -42


# ---------------------------------------------------------------------------
# handler – happy path (mocked DB)
# ---------------------------------------------------------------------------

BASE_INPUTS = {
    "modes": ["CAR", "BIKE"],
    "bbox": [4.9, 52.3, 5.0, 52.4],
}

BASE_EVENT = BASE_INPUTS


def _env_vars():
    return {
        "DATABRICKS_HOST": "dbc-test.cloud.databricks.com",
        "DATABRICKS_WAREHOUSE_ID": "test-warehouse-id",
        "DATABRICKS_TOKEN": "dapitest",
    }


def test_handler_returns_200():
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, patch.dict(os.environ, _env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(BASE_EVENT, None)
    assert result["statusCode"] == 200


def test_handler_body_shape():
    """Modes are top-level keys (lowercase) alongside statusCode."""
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, patch.dict(os.environ, _env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(BASE_EVENT, None)
    assert set(result.keys()) == {"statusCode", "car", "bike"}
    for key in ("car", "bike"):
        fc = result[key]
        assert fc["type"] == "FeatureCollection"
        assert isinstance(fc["features"], list)


def test_handler_body_metadata():
    """Each FeatureCollection has a 'properties' object with created/mode/origin/bbox/region."""
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, patch.dict(os.environ, _env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(BASE_EVENT, None)
    for key in ("car", "bike"):
        props = result[key]["properties"]
        assert props["mode"]   == key.upper()
        assert props["origin"] == "spectrum_2023_01"
        assert props["bbox"]   == BASE_INPUTS["bbox"]
        assert isinstance(props["created"], str) and props["created"]
        assert "region" in props


def test_handler_accepts_networks_alias():
    event = {
        "networks": ["CAR"],
        "bbox": [4.9, 52.3, 5.0, 52.4],
    }
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, patch.dict(os.environ, _env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(event, None)
    assert result["statusCode"] == 200
    assert result["car"]["type"] == "FeatureCollection"


# ---------------------------------------------------------------------------
# handler – error cases (400)
# ---------------------------------------------------------------------------

def test_handler_missing_modes_returns_400():
    event = {"bbox": [4.9, 52.3, 5.0, 52.4]}
    with patch.dict(os.environ, _env_vars()):
        result = handler(event, None)
    assert result["statusCode"] == 400
    assert "error" in result


def test_handler_missing_bbox_returns_400():
    event = {"modes": ["CAR"]}
    with patch.dict(os.environ, _env_vars()):
        result = handler(event, None)
    assert result["statusCode"] == 400
    assert "error" in result


def test_intersect_mode_pedestrian_uses_correct_sql():
    conn, cur = _mock_conn()
    _intersect_mode("PEDESTRIAN", _EMPTY_FC, conn)
    assert "PEDESTRIAN" in cur.execute.call_args[0][0]


def test_post_process_segment_id_matches_spectrum_id():
    """Every output feature must have segment_id == spectrum_id."""
    feats = _post_process_features([
        _make_raw_feature(heen=True, terug=True,  seg_id=42),
        _make_raw_feature(heen=True, terug=False, seg_id=99),
        _make_raw_feature(heen=False, terug=True, seg_id=7),
    ])
    for f in feats:
        p = f["properties"]
        assert p["linkId"] == p["spectrumId"], (
            f"linkId {p['linkId']!r} != spectrumId {p['spectrumId']!r}"
        )


def test_handler_connects_once_per_mode():
    """Each mode must open its own Databricks connection (parallel execution)."""
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, patch.dict(os.environ, _env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(BASE_EVENT, None)   # BASE_EVENT has modes: ["CAR", "BIKE"]
    assert result["statusCode"] == 200
    assert mock_connect.call_count == 2      # one connect per mode


# ---------------------------------------------------------------------------
# handler – HTTP API Gateway path (links in response)
# ---------------------------------------------------------------------------

_APIGW_V1_EVENT = {
    "httpMethod": "POST",
    "path": "/processes/intersect-area/execute",
    "headers": {"Content-Type": "application/json"},
    "body": json.dumps({
        "modes": ["CAR", "BIKE"],
        "bbox": [4.9, 52.3, 5.0, 52.4],
    }),
}

_APIGW_V2_EVENT = {
    "version": "2.0",
    "requestContext": {"domainName": "api.example.com"},
    "rawPath": "/processes/intersect-area/execute",
    "body": json.dumps({
        "modes": ["CAR"],
        "bbox": [4.9, 52.3, 5.0, 52.4],
    }),
}


def _apigw_env_vars():
    return {
        **_env_vars(),
        "GMT_BASE_URL": "https://mobilitytwin.goudappel.nl",
    }


def _patch_apigw():
    """Context manager patches for the HTTP API Gateway path."""
    return [
        patch("network_intersector_handler._dbsql.connect_from_env"),
        patch("network_intersector_handler._s3_put_json"),
        patch.dict(os.environ, _apigw_env_vars()),
    ]


def test_apigw_handler_returns_200():
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, \
         patch("network_intersector_handler._s3_put_json"), \
         patch.dict(os.environ, _apigw_env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(_APIGW_V1_EVENT, None)
    assert result["statusCode"] == 200
    body = json.loads(result["body"])
    assert body["status"] == "successful"
    assert "area_id" in body


def test_apigw_handler_response_contains_links():
    """HTTP response body must include a 'links' list."""
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, \
         patch("network_intersector_handler._s3_put_json"), \
         patch.dict(os.environ, _apigw_env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(_APIGW_V1_EVENT, None)
    body = json.loads(result["body"])
    assert "links" in body, "response body must contain 'links'"
    assert isinstance(body["links"], list)
    assert len(body["links"]) > 0


def test_apigw_handler_links_use_external_url():
    """Every link href must start with GMT_BASE_URL."""
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, \
         patch("network_intersector_handler._s3_put_json"), \
         patch.dict(os.environ, _apigw_env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(_APIGW_V1_EVENT, None)
    body = json.loads(result["body"])
    base = _apigw_env_vars()["GMT_BASE_URL"]
    for link in body["links"]:
        assert link["href"].startswith(base), (
            f"Link href {link['href']!r} does not start with {base!r}"
        )


def test_apigw_handler_links_contain_results_and_items():
    """Each mode must produce one 'results' link and one 'items' link."""
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, \
         patch("network_intersector_handler._s3_put_json") as mock_s3, \
         patch.dict(os.environ, _apigw_env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        # _write_modes_to_s3 iterates over internal_result; we simulate two modes
        # by using the V2 single-mode event so we can check predictable output.
        result = handler(_APIGW_V2_EVENT, None)
    body = json.loads(result["body"])
    area_id = body["area_id"]
    base = _apigw_env_vars()["GMT_BASE_URL"]

    rels = {link["rel"] for link in body.get("links", [])}
    # At least one results and one items link must be present (per written mode)
    assert "results" in rels, f"Expected 'results' rel in links, got: {rels}"
    assert "items" in rels,   f"Expected 'items' rel in links, got: {rels}"

    hrefs = [link["href"] for link in body["links"]]
    # results links point to /jobs/{area_id}/results/{MODE}
    assert any(f"/jobs/{area_id}/results/" in h for h in hrefs), (
        "No results link found with /jobs/{area_id}/results/ pattern"
    )
    # items links point to /collections/segments/items?area_id=...&mode=...
    assert any(f"/collections/segments/items" in h and f"area_id={area_id}" in h
               for h in hrefs), (
        "No items link found with /collections/segments/items?area_id=... pattern"
    )


def test_apigw_handler_no_links_when_no_gmt_base_url():
    """When GMT_BASE_URL is absent the response must not contain 'links'."""
    env = {k: v for k, v in _apigw_env_vars().items() if k != "GMT_BASE_URL"}
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, \
         patch("network_intersector_handler._s3_put_json"), \
         patch.dict(os.environ, env, clear=False):
        # Remove GMT_BASE_URL if set in the real environment
        os.environ.pop("GMT_BASE_URL", None)
        mock_connect.return_value = _mock_conn()[0]
        result = handler(_APIGW_V1_EVENT, None)
    body = json.loads(result["body"])
    assert "links" not in body


# ---------------------------------------------------------------------------
# _point_in_polygon unit tests
# ---------------------------------------------------------------------------

# A simple unit square [0,0] – [1,0] – [1,1] – [0,1] – [0,0]
_UNIT_SQUARE = [[0, 0], [1, 0], [1, 1], [0, 1], [0, 0]]


def test_point_in_polygon_inside():
    assert _point_in_polygon(0.5, 0.5, _UNIT_SQUARE) is True


def test_point_in_polygon_outside():
    assert _point_in_polygon(2.0, 2.0, _UNIT_SQUARE) is False


def test_point_in_polygon_on_edge_row():
    # Point exactly on the bottom edge – result is implementation-defined (False
    # for the ray-casting algorithm when y == y_i and y_j > y_i), but must not
    # raise.
    result = _point_in_polygon(0.5, 0.0, _UNIT_SQUARE)
    assert isinstance(result, bool)


# ---------------------------------------------------------------------------
# _determine_region unit tests
# ---------------------------------------------------------------------------

_REGIONS_GEOJSON = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [[[4.0, 52.0], [5.0, 52.0], [5.0, 53.0], [4.0, 53.0], [4.0, 52.0]]],
            },
            "properties": {"regio": "west"},
        },
        {
            "type": "Feature",
            "geometry": {
                "type": "Polygon",
                "coordinates": [[[5.0, 52.0], [6.0, 52.0], [6.0, 53.0], [5.0, 53.0], [5.0, 52.0]]],
            },
            "properties": {"regio": "oost"},
        },
    ],
}


def test_determine_region_hits_west():
    # Centroid of bbox is at lon=4.45, lat=52.35 → inside "west" polygon
    bbox = [4.4, 52.3, 4.5, 52.4]
    assert _determine_region(bbox, _REGIONS_GEOJSON["features"]) == "west"


def test_determine_region_hits_oost():
    # Centroid of bbox is at lon=5.45, lat=52.35 → inside "oost" polygon
    bbox = [5.4, 52.3, 5.5, 52.4]
    assert _determine_region(bbox, _REGIONS_GEOJSON["features"]) == "oost"


def test_determine_region_no_match_returns_none():
    # Centroid far outside both polygons
    bbox = [10.0, 60.0, 11.0, 61.0]
    assert _determine_region(bbox, _REGIONS_GEOJSON["features"]) is None


def test_determine_region_empty_features_returns_none():
    assert _determine_region([4.9, 52.3, 5.0, 52.4], []) is None


def test_determine_region_empty_bbox_returns_none():
    assert _determine_region([], _REGIONS_GEOJSON["features"]) is None


# ---------------------------------------------------------------------------
# handler – region in metadata
# ---------------------------------------------------------------------------

def test_handler_body_metadata_contains_region_key():
    """Each FeatureCollection properties must contain a 'region' key."""
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, patch.dict(os.environ, _env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(BASE_EVENT, None)
    for key in ("car", "bike"):
        props = result[key]["properties"]
        assert "region" in props, f"'region' missing from {key} properties"


def test_handler_body_region_from_s3():
    """When NETWORK_BASE_URI is set and S3 returns regions, region is populated."""
    bbox = [4.4, 52.3, 4.5, 52.4]  # centroid falls in "west"
    event = {"modes": ["CAR"], "bbox": bbox}
    env = {**_env_vars()}
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, \
         patch("network_intersector_handler._s3_get_json", return_value=_REGIONS_GEOJSON), \
         patch.dict(os.environ, env):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(event, None)
    assert result["statusCode"] == 200
    assert result["car"]["properties"]["region"] == "west"


def test_handler_body_region_none_when_no_bucket():
    """When NETWORK_BASE_URI is absent, region must be None (graceful fallback)."""
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, patch.dict(os.environ, _env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(BASE_EVENT, None)
    for key in ("car", "bike"):
        assert result[key]["properties"]["region"] is None


def test_handler_body_region_none_on_s3_error():
    """When S3 raises, region falls back to None without crashing."""
    bbox = [4.4, 52.3, 4.5, 52.4]
    event = {"modes": ["CAR"], "bbox": bbox}
    env = {**_env_vars()}
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, \
         patch("network_intersector_handler._s3_get_json", side_effect=Exception("S3 unavailable")), \
         patch.dict(os.environ, env):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(event, None)
    assert result["statusCode"] == 200
    assert result["car"]["properties"]["region"] is None


# ---------------------------------------------------------------------------
# handler – name in FeatureCollection properties
# ---------------------------------------------------------------------------

def test_handler_name_in_properties_when_provided():
    """name from inputs must appear in each FeatureCollection's properties."""
    event = {**BASE_INPUTS, "name": "Deventer Centrum"}
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, \
         patch.dict(os.environ, _env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(event, None)
    for key in ("car", "bike"):
        assert result[key]["properties"]["name"] == "Deventer Centrum"


def test_handler_name_none_when_absent():
    """When name is not supplied the property must be None (backward-compat)."""
    with patch("network_intersector_handler._dbsql.connect_from_env") as mock_connect, \
         patch.dict(os.environ, _env_vars()):
        mock_connect.return_value = _mock_conn()[0]
        result = handler(BASE_EVENT, None)
    for key in ("car", "bike"):
        assert result[key]["properties"]["name"] is None


# ---------------------------------------------------------------------------
# Direct runner
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import traceback

    tests = [
        test_polygon_from_flat_bbox,
        test_polygon_from_3d_bbox,
        test_polygon_from_ring,
        test_polygon_from_closed_ring,
        test_polygon_missing_bbox_raises,
        test_intersect_mode_car_uses_correct_sql,
        test_intersect_mode_bike_uses_correct_sql,
        test_intersect_mode_pedestrian_uses_correct_sql,
        test_intersect_mode_train_uses_pt_sql,
        test_intersect_mode_bus_uses_pt_sql,
        test_intersect_mode_unknown_raises,
        test_intersect_mode_returns_empty_fc_on_no_rows,
        test_post_process_bidirectional_splits_into_two,
        test_post_process_heen_only_keeps_one,
        test_post_process_terug_only_reverses,
        test_post_process_flow24hrs,
        test_post_process_heading_and_opposite_bidir,
        test_post_process_unidirectional_opposite_detection,
        test_post_process_unidirectional_no_opposite_when_too_far,
        test_offset_near_node_adapts_to_link_length,
        test_post_process_bidir_geometry_is_offset,
        test_post_process_neither_direction_dropped,
        test_post_process_zero_flow_overrides_rijrichting,
        test_handler_returns_200,
        test_handler_body_shape,
        test_handler_body_metadata,
        test_handler_accepts_networks_alias,
        test_handler_missing_modes_returns_400,
        test_handler_missing_bbox_returns_400,
        test_post_process_segment_id_matches_spectrum_id,
        test_handler_connects_once_per_mode,
        test_apigw_handler_returns_200,
        test_apigw_handler_response_contains_links,
        test_apigw_handler_links_use_external_url,
        test_apigw_handler_links_contain_results_and_items,
        test_apigw_handler_no_links_when_no_gmt_base_url,
        test_point_in_polygon_inside,
        test_point_in_polygon_outside,
        test_point_in_polygon_on_edge_row,
        test_determine_region_hits_west,
        test_determine_region_hits_oost,
        test_determine_region_no_match_returns_none,
        test_determine_region_empty_features_returns_none,
        test_determine_region_empty_bbox_returns_none,
        test_handler_body_metadata_contains_region_key,
        test_handler_body_region_from_s3,
        test_handler_body_region_none_when_no_bucket,
        test_handler_body_region_none_on_s3_error,
    ]
    passed = failed = 0
    for t in tests:
        try:
            t()
            print(f"  PASS  {t.__name__}")
            passed += 1
        except Exception:
            print(f"  FAIL  {t.__name__}")
            traceback.print_exc()
            failed += 1

    print(f"\n{passed} passed, {failed} failed")
    sys.exit(1 if failed else 0)

