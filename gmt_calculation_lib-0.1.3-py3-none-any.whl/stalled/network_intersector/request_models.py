"""Request model for the network-intersector Lambda."""

from __future__ import annotations

from pydantic import BaseModel


class HandlerInput(BaseModel):
    output_folder: str
    modes: list[str]
    bbox: list[float]
    area_id: str | None = None
    name: str | None = None
    catalog: str | None = None
    db_schema: str | None = None
    regions_file: str | None = None
    run_cleaner: bool = True
    run_parallel_link_finder: bool = True
