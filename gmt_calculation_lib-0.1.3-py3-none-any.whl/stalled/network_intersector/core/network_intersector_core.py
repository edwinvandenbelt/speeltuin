"""Pure-Python intersector logic — no I/O, no boto3, no Databricks connections.

Public API
----------
build_intersection_sql(mode, catalog, schema) -> str
to_polygon_geojson(inputs) -> str
to_bbox(inputs) -> list
rows_to_feature_collection(rows, col_names, mode) -> dict
post_process_features(features) -> list
assemble_network(rows, col_names, mode, bbox, region, **meta) -> tuple[dict, dict]
point_in_polygon(px, py, ring) -> bool
determine_region(bbox, region_features) -> str | None
slugify(text) -> str
"""

from __future__ import annotations

import logging

from network_cleaner.core.network_cleaner_core import clean_network
from parallel_link_finder.core.parallel_link_finder_core import find_parallel_links

from bidirectional_splitter.core.bidirectional_splitter_core import (  # noqa: F401
    post_process_features,
)
from network_fetcher.core.network_fetcher_core import (  # noqa: F401
    _DAYPART_KEYS,
    _MOTIEF_KEYS,
    _PT_PARAMS,
    LINK_PROPERTIES,
    VALID_MODES,
    build_intersection_sql,
    get_pt_params,
    rows_to_feature_collection,
)
from stalled.network_intersector.domain.geometry import (  # noqa: F401
    _NEAR_NODE_M,
    _NEAR_NODE_M_MED,
    _NEAR_NODE_M_SHT,
    _OFFSET_M,
    _OPPOSITE_HEADING_TOL,
    _OPPOSITE_SEARCH_M,
    assign_reverse_link_ids,
    heading,
    offset_linestring,
)
from stalled.network_intersector.domain.region import (  # noqa: F401
    determine_region,
    point_in_polygon,
    slugify,
    to_bbox,
    to_polygon_geojson,
)

logger = logging.getLogger(__name__)


def assemble_network(
    rows: list[tuple],
    col_names: list[str],
    mode: str,
    bbox: list[float],
    region: str | None,
    *,
    run_cleaner: bool = True,
    run_parallel_link_finder: bool = True,
    **meta: object,
) -> tuple[dict, dict]:
    """Run the full network-production pipeline for a single mode.

    Steps
    -----
    1. Build raw FeatureCollection from Databricks rows  (network_fetcher).
    2. Post-process: split bidirectional links, rename fields, compute headings
       (bidirectional_splitter).
    3. Clean: BFS dead-link removal  (network_cleaner).
    4. Enrich: add ``parallelLinkIds`` and extend ``reverseLinkIds`` via KD-tree
       (parallel_link_finder).

    Parameters
    ----------
    run_cleaner:
        When ``True`` (default) the BFS network cleaner is applied and
        unreachable dead links are removed.  Set to ``False`` to skip this
        step and keep all raw features.
    run_parallel_link_finder:
        When ``True`` (default) the parallel-link finder enriches each feature
        with ``parallelLinkIds``.  Set to ``False`` to skip this step.

    Returns
    -------
    tuple[dict, dict]
        ``(feature_collection, clean_stats)`` where *clean_stats* contains
        ``{"total", "kept", "removed", "seed_node"}``.  When the cleaner is
        skipped, *clean_stats* reflects a no-op (``removed=0``).
    """
    fc = rows_to_feature_collection(rows, col_names, mode)
    fc["features"] = post_process_features(fc["features"])
    fc["properties"].update({"bbox": bbox, "region": region, **meta})

    if run_cleaner:
        fc, stats = clean_network(fc)
        logger.debug(
            "assemble_network mode=%s: kept=%d removed=%d seed_node=%s",
            mode, stats["kept"], stats["removed"], stats.get("seed_node"),
        )
    else:
        n = len(fc["features"])
        stats = {"total": n, "kept": n, "removed": 0, "seed_node": None}
        logger.debug("assemble_network mode=%s: cleaner skipped (%d features)", mode, n)

    if run_parallel_link_finder:
        fc, plf_stats = find_parallel_links(fc)
        logger.debug(
            "assemble_network PLF mode=%s: enriched=%d skipped=%d",
            mode, plf_stats["features_enriched"], plf_stats["features_skipped"],
        )
    else:
        logger.debug("assemble_network mode=%s: parallel-link finder skipped", mode)

    return fc, stats
