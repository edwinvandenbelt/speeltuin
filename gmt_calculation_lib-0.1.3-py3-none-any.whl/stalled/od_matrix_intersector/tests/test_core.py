"""
Unit tests for od_matrix_intersector.od_matrix_intersector_core

All tests use pure Python objects — no I/O, no boto3, no Databricks.
"""

from __future__ import annotations

import csv
import io
import json
import math

import pytest

from stalled.od_matrix_intersector.core.od_matrix_intersector_core import (
    _OD_TABLE,
    _CSV_COLS,
    aggregate_od,
    build_od_feature_collection,
    build_od_sql,
    parse_zone_geojson,
    records_to_csv_bytes,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features)}


def _inner_feature(gid: int, zone_id: str = "z1",
                   clon: float = 6.1, clat: float = 52.2) -> dict:
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {
            "gid":          gid,
            "zoneId":      zone_id,
            "zoneType":    "inner",
            "centroidLon": clon,
            "centroidLat": clat,
        },
    }


def _agg_feature(gid: int, constituents: list[int], zone_id: str = "agg_z",
                 clon: float = 6.5, clat: float = 52.5) -> dict:
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {
            "gid":                  gid,
            "zoneId":              zone_id,
            "zoneType":            "aggregate",
            "centroidLon":         clon,
            "centroidLat":         clat,
            "constituentZoneIds": constituents,
        },
    }


def _raw_row(from_gid: int, to_gid: int, trips: float) -> dict:
    return {"from_zone_gid": from_gid, "to_zone_gid": to_gid, "trips": trips}


# ---------------------------------------------------------------------------
# build_od_sql
# ---------------------------------------------------------------------------

class TestBuildOdSql:
    def test_contains_table_name(self):
        sql = build_od_sql("spectrum", "2023_01", {1, 2})
        assert _OD_TABLE in sql

    def test_contains_catalog_and_schema(self):
        sql = build_od_sql("mycat", "2024_01", {1})
        assert "mycat" in sql
        assert "`2024_01`" in sql

    def test_inner_gids_inlined(self):
        sql = build_od_sql("spectrum", "2023_01", {10, 20})
        assert "10" in sql
        assert "20" in sql

    def test_no_placeholders(self):
        sql = build_od_sql("spectrum", "2023_01", {5})
        assert "?" not in sql

    def test_groups_by_gid_pair(self):
        sql = build_od_sql("spectrum", "2023_01", {1})
        assert "GROUP BY" in sql

    def test_sums_ritten(self):
        sql = build_od_sql("spectrum", "2023_01", {1})
        assert "SUM" in sql
        assert "ritten" in sql

    def test_or_clause_present(self):
        sql = build_od_sql("spectrum", "2023_01", {1})
        assert " OR " in sql

    def test_empty_inner_gids_returns_no_rows(self):
        sql = build_od_sql("spectrum", "2023_01", set())
        assert "1=0" in sql

    def test_gids_sorted(self):
        # Use gids/schema that don't overlap with each other as substrings
        sql = build_od_sql("mycat", "schema_a", {300, 100, 200})
        # Extract only the IN clause to avoid false matches in catalog/schema names
        in_clause_start = sql.index("IN (")
        in_section = sql[in_clause_start:]
        idx100 = in_section.index("100")
        idx200 = in_section.index("200")
        idx300 = in_section.index("300")
        assert idx100 < idx200 < idx300


# ---------------------------------------------------------------------------
# parse_zone_geojson
# ---------------------------------------------------------------------------

class TestParseZoneGeojson:
    def test_inner_zone_maps_to_self(self):
        fc = _make_fc(_inner_feature(1))
        gid_to_output, _, inner_gids, _ = parse_zone_geojson(fc)
        assert gid_to_output[1] == 1
        assert 1 in inner_gids

    def test_aggregate_zone_ignored(self):
        """Aggregate zones are skipped entirely — only inner zones enter the matrix."""
        fc = _make_fc(_agg_feature(100, [10, 20, 30]))
        gid_to_output, zone_info, inner_gids, known_gids = parse_zone_geojson(fc)
        assert gid_to_output == {}
        assert zone_info == {}
        assert inner_gids == set()
        assert known_gids == set()

    def test_zone_info_contains_centroid(self):
        fc = _make_fc(_inner_feature(1, clon=6.1, clat=52.2))
        _, zone_info, _, _ = parse_zone_geojson(fc)
        assert pytest.approx(zone_info[1]["centroid_lon"]) == 6.1
        assert pytest.approx(zone_info[1]["centroid_lat"]) == 52.2

    def test_zone_info_zone_type(self):
        fc = _make_fc(_inner_feature(1))
        _, zone_info, _, _ = parse_zone_geojson(fc)
        assert zone_info[1]["zone_type"] == "inner"

    def test_empty_fc_returns_empty_structures(self):
        fc = _make_fc()
        gid_to_output, zone_info, inner_gids, known_gids = parse_zone_geojson(fc)
        assert gid_to_output == {}
        assert zone_info == {}
        assert inner_gids == set()
        assert known_gids == set()

    def test_known_gids_contains_only_inner(self):
        fc = _make_fc(
            _inner_feature(1),
            _agg_feature(100, [50, 51]),
        )
        _, _, _, known_gids = parse_zone_geojson(fc)
        assert known_gids == {1}

    def test_missing_gid_skipped(self):
        feature = {"type": "Feature", "geometry": None, "properties": {"zone_type": "inner"}}
        fc = _make_fc(feature)
        gid_to_output, zone_info, _, _ = parse_zone_geojson(fc)
        assert gid_to_output == {}
        assert zone_info == {}

    def test_inner_gid_in_zone_info(self):
        fc = _make_fc(_inner_feature(42, zone_id="z42"))
        _, zone_info, _, _ = parse_zone_geojson(fc)
        assert 42 in zone_info
        assert zone_info[42]["zone_id"] == "z42"

    def test_nan_centroid_on_missing_value(self):
        feature = {
            "type": "Feature",
            "geometry": None,
            "properties": {"gid": 1, "zoneType": "inner"},
        }
        fc = _make_fc(feature)
        _, zone_info, _, _ = parse_zone_geojson(fc)
        assert math.isnan(zone_info[1]["centroid_lon"])
        assert math.isnan(zone_info[1]["centroid_lat"])


# ---------------------------------------------------------------------------
# aggregate_od
# ---------------------------------------------------------------------------

class TestAggregateOd:
    def _setup_inner_only(self):
        """Two inner zones (gid 1 and 2), no aggregates."""
        fc = _make_fc(
            _inner_feature(1, clon=6.0, clat=52.0),
            _inner_feature(2, clon=6.1, clat=52.1),
        )
        return parse_zone_geojson(fc)

    def test_empty_raw_returns_empty(self):
        gid_to_output, zone_info, inner_gids, _ = self._setup_inner_only()
        assert aggregate_od([], gid_to_output, zone_info, inner_gids) == []

    def test_inner_inner_direct_pass_through(self):
        gid_to_output, zone_info, inner_gids, _ = self._setup_inner_only()
        raw = [_raw_row(1, 2, 100.0)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert len(records) == 1
        assert records[0]["fromZoneGid"] == 1
        assert records[0]["toZoneGid"]   == 2
        assert records[0]["trips"]         == 100.0

    def test_ritten_accumulated(self):
        gid_to_output, zone_info, inner_gids, _ = self._setup_inner_only()
        raw = [_raw_row(1, 2, 40.0), _raw_row(1, 2, 60.0)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert len(records) == 1
        assert records[0]["trips"] == pytest.approx(100.0)

    def test_aggregate_endpoint_dropped(self):
        """OD rows referencing aggregate constituent gids are dropped (unknown gid)."""
        fc = _make_fc(
            _inner_feature(1, clon=6.0, clat=52.0),
            _agg_feature(100, [50, 51]),
        )
        gid_to_output, zone_info, inner_gids, _ = parse_zone_geojson(fc)
        # gid 50 is a constituent of an aggregate — no longer in gid_to_output
        raw = [_raw_row(1, 50, 200.0)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert records == []

    def test_agg_agg_dropped(self):
        """OD rows between two aggregate constituent gids are dropped."""
        fc = _make_fc(
            _inner_feature(1),
            _agg_feature(100, [50]),
            _agg_feature(200, [60]),
        )
        gid_to_output, zone_info, inner_gids, _ = parse_zone_geojson(fc)
        raw = [_raw_row(50, 60, 99.0)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert records == []

    def test_unknown_gid_dropped(self):
        gid_to_output, zone_info, inner_gids, _ = self._setup_inner_only()
        raw = [_raw_row(999, 1, 50.0)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert records == []

    def test_records_sorted_by_gid_pair(self):
        gid_to_output, zone_info, inner_gids, _ = self._setup_inner_only()
        raw = [_raw_row(2, 1, 10.0), _raw_row(1, 2, 20.0)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert records[0]["fromZoneGid"] == 1
        assert records[1]["fromZoneGid"] == 2

    def test_od_id_starts_at_1(self):
        gid_to_output, zone_info, inner_gids, _ = self._setup_inner_only()
        raw = [_raw_row(1, 2, 10.0)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert records[0]["odId"] == 1

    def test_centroid_coords_in_record(self):
        gid_to_output, zone_info, inner_gids, _ = self._setup_inner_only()
        raw = [_raw_row(1, 2, 10.0)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert records[0]["_from_lon"] == pytest.approx(6.0)
        assert records[0]["_to_lat"]   == pytest.approx(52.1)

    def test_from_zone_type_in_record(self):
        gid_to_output, zone_info, inner_gids, _ = self._setup_inner_only()
        raw = [_raw_row(1, 2, 10.0)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert records[0]["fromZoneType"] == "inner"
        assert records[0]["toZoneType"]   == "inner"

    def test_ritten_rounded_4dp(self):
        gid_to_output, zone_info, inner_gids, _ = self._setup_inner_only()
        raw = [_raw_row(1, 2, 1 / 3)]
        records = aggregate_od(raw, gid_to_output, zone_info, inner_gids)
        assert records[0]["trips"] == round(1 / 3, 4)


# ---------------------------------------------------------------------------
# build_od_feature_collection
# ---------------------------------------------------------------------------

class TestBuildOdFeatureCollection:
    def _make_record(self, od_id=1, fgid=1, tgid=2,
                     flon=6.0, flat=52.0, tlon=6.1, tlat=52.1,
                     trips=100.0):
        return {
            "odId":          od_id,
            "fromZoneGid":  fgid,
            "toZoneGid":    tgid,
            "fromZoneId":   "z1",
            "toZoneId":     "z2",
            "fromZoneType": "inner",
            "toZoneType":   "inner",
            "trips":          trips,
            "_from_lon": flon, "_from_lat": flat,
            "_to_lon": tlon,   "_to_lat": tlat,
        }

    def test_returns_feature_collection(self):
        fc = build_od_feature_collection([self._make_record()])
        assert fc["type"] == "FeatureCollection"

    def test_one_feature_per_record(self):
        records = [self._make_record(od_id=i) for i in range(5)]
        fc = build_od_feature_collection(records)
        assert len(fc["features"]) == 5

    def test_linestring_geometry(self):
        fc = build_od_feature_collection([self._make_record()])
        geom = fc["features"][0]["geometry"]
        assert geom["type"] == "LineString"
        assert len(geom["coordinates"]) == 2

    def test_linestring_coordinates_correct(self):
        fc = build_od_feature_collection([self._make_record(
            flon=6.0, flat=52.0, tlon=6.1, tlat=52.1)])
        coords = fc["features"][0]["geometry"]["coordinates"]
        assert coords[0] == pytest.approx([6.0, 52.0])
        assert coords[1] == pytest.approx([6.1, 52.1])

    def test_internal_coords_not_in_properties(self):
        fc = build_od_feature_collection([self._make_record()])
        props = fc["features"][0]["properties"]
        assert "_from_lon" not in props
        assert "_to_lat"   not in props

    def test_trips_in_properties(self):
        fc = build_od_feature_collection([self._make_record(trips=42.5)])
        props = fc["features"][0]["properties"]
        assert props["trips"] == 42.5

    def test_null_geometry_on_nan_coords(self):
        rec = self._make_record(flon=float("nan"), flat=float("nan"))
        fc = build_od_feature_collection([rec])
        assert fc["features"][0]["geometry"] is None

    def test_empty_records(self):
        fc = build_od_feature_collection([])
        assert fc["features"] == []

    def test_intrazonal_linestring_same_coords(self):
        rec = self._make_record(fgid=1, tgid=1, flon=6.0, flat=52.0, tlon=6.0, tlat=52.0)
        fc = build_od_feature_collection([rec])
        coords = fc["features"][0]["geometry"]["coordinates"]
        assert coords[0] == coords[1]

    def test_link_properties_present(self):
        fc = build_od_feature_collection([self._make_record()])
        assert "link_properties" in fc["properties"]

    def test_metadata_embedded_in_properties(self):
        meta = {"area_id": "abc", "mode": "CAR", "catalog": "spectrum", "db_schema": "2024_01",
                "origin": "spectrum_2024_01", "created": "2026-01-01T00:00:00+00:00"}
        fc = build_od_feature_collection([self._make_record()], metadata=meta)
        props = fc["properties"]
        assert props["area_id"] == "abc"
        assert props["mode"] == "CAR"
        assert props["catalog"] == "spectrum"
        assert props["db_schema"] == "2024_01"
        assert props["origin"] == "spectrum_2024_01"
        assert props["created"] == "2026-01-01T00:00:00+00:00"

    def test_no_metadata_only_link_properties(self):
        fc = build_od_feature_collection([self._make_record()])
        assert list(fc["properties"].keys()) == ["link_properties"]


# ---------------------------------------------------------------------------
# records_to_csv_bytes
# ---------------------------------------------------------------------------

class TestRecordsToCsvBytes:
    def _make_record(self, od_id=1, fgid=1, tgid=2):
        return {
            "odId":          od_id,
            "fromZoneGid":  fgid,
            "toZoneGid":    tgid,
            "fromZoneId":   "z1",
            "toZoneId":     "z2",
            "fromZoneType": "inner",
            "toZoneType":   "inner",
            "trips":          100.0,
            "_from_lon": 6.0, "_from_lat": 52.0,
            "_to_lon": 6.1,   "_to_lat": 52.1,
        }

    def test_returns_bytes(self):
        result = records_to_csv_bytes([self._make_record()])
        assert isinstance(result, bytes)

    def test_utf8_decodable(self):
        result = records_to_csv_bytes([self._make_record()])
        text = result.decode("utf-8")
        assert len(text) > 0

    def test_header_row(self):
        result = records_to_csv_bytes([self._make_record()])
        reader = csv.DictReader(io.StringIO(result.decode("utf-8")))
        assert set(reader.fieldnames or []) == set(_CSV_COLS)

    def test_internal_fields_excluded(self):
        result = records_to_csv_bytes([self._make_record()])
        text = result.decode("utf-8")
        assert "_from_lon" not in text
        assert "_to_lat" not in text

    def test_data_row_count(self):
        records = [self._make_record(od_id=i) for i in range(5)]
        result = records_to_csv_bytes(records)
        reader = csv.DictReader(io.StringIO(result.decode("utf-8")))
        rows = list(reader)
        assert len(rows) == 5

    def test_empty_records(self):
        result = records_to_csv_bytes([])
        reader = csv.DictReader(io.StringIO(result.decode("utf-8")))
        rows = list(reader)
        assert rows == []

    def test_trips_value_present(self):
        result = records_to_csv_bytes([self._make_record()])
        reader = csv.DictReader(io.StringIO(result.decode("utf-8")))
        row = next(reader)
        assert float(row["trips"]) == pytest.approx(100.0)

    def test_zone_ids_present(self):
        result = records_to_csv_bytes([self._make_record(fgid=1, tgid=2)])
        reader = csv.DictReader(io.StringIO(result.decode("utf-8")))
        row = next(reader)
        assert row["fromZoneId"] == "z1"
        assert row["toZoneId"] == "z2"
