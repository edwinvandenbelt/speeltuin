"""
Pure-Python core for the OD-matrix-intersector Lambda.

No I/O, no boto3, no Databricks connections.  All functions accept and return
plain Python objects (lists, dicts, strings, floats, bytes).

Public API
----------
build_od_sql(catalog, schema, inner_gids) -> str
    SQL with inner gids inlined as integer literals (no placeholders).

parse_zone_geojson(fc) -> tuple[dict, dict, set, set]
    Parse a zone GeoJSON FeatureCollection into the four lookup structures
    needed by aggregate_od and build_od_feature_collection.

aggregate_od(raw_rows, gid_to_output, zone_info, inner_gids) -> list[dict]
    Map raw d030 gid pairs to output zone gids; sum ritten; return OD records.

build_od_feature_collection(records) -> dict
    Build a GeoJSON FeatureCollection with one LineString per OD record.

records_to_csv_bytes(records) -> bytes
    Serialise OD records as UTF-8 CSV (no geometry columns).
"""

from __future__ import annotations

# Re-export everything the public API and tests expect from domain modules.
from stalled.od_matrix_intersector.domain.sql import (
    _OD_TABLE,
    build_od_sql,
)
from stalled.od_matrix_intersector.domain.zone import (
    parse_zone_geojson,
)
from stalled.od_matrix_intersector.domain.od import (
    _CSV_COLS,
    OD_PROPERTIES,
    aggregate_od,
    build_od_feature_collection,
    records_to_csv_bytes,
)

__all__ = [
    "_OD_TABLE",
    "_CSV_COLS",
    "OD_PROPERTIES",
    "build_od_sql",
    "parse_zone_geojson",
    "aggregate_od",
    "build_od_feature_collection",
    "records_to_csv_bytes",
]
