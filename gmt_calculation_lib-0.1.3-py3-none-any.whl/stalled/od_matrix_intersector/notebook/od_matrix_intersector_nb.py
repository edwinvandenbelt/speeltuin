# Databricks notebook source
# ---------------------------------------------------------------------------
# od_matrix_intersector_nb.py — Databricks notebook interface for OD matrix derivation.
#
# This notebook:
#   1. Reads widget parameters (uuid, zone_geojson_path, catalog, schema, …).
#   2. Loads the zone GeoJSON FeatureCollection ({uuid}-ZONE.geojson) from S3
#      or a local path — produced by zone_aggregator_nb or zone_intersector_nb.
#   3. Parses zone FC into lookup structures via parse_zone_geojson (pure).
#   4. Queries d083_hb_matrices_met_2018_kalibratie_effect_auto via spark.sql()
#      using SQL built by od_matrix_intersector.od_matrix_intersector_core.build_od_sql().
#      NOTE: build_od_sql inlines inner_gids as integer literals — no ? params.
#   5. Calls pure core functions (aggregate_od, build_od_feature_collection,
#      records_to_csv_bytes) — no I/O.
#   6. Writes GeoJSON, CSV, and GeoParquet outputs to S3 or a local path.
#
# Requirements (Databricks cluster):
#   pip install boto3 geopandas pyarrow   (or attach via cluster library)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
import tempfile
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("od_matrix_intersector_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install geopandas pyarrow

# COMMAND ----------
# geopandas / shapely are optional — GeoParquet output is skipped when unavailable.
try:
    import geopandas as gpd
    from shapely.geometry import LineString as _LineString
    _HAS_GEOPANDAS = True
except ImportError:
    _HAS_GEOPANDAS = False
    logger.warning(
        "geopandas / shapely not installed — GeoParquet output will be skipped."
    )

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "output_folder", "",
    "Output folder: s3://bucket/prefix  or  /dbfs/path (required)",
)
dbutils.widgets.text(  # noqa: F821
    "zone_geojson_path", "",
    "S3 URI or path of the zone GeoJSON ({uuid}-ZONE.geojson) from zone_aggregator_nb",
)
dbutils.widgets.text(  # noqa: F821
    "DATABRICKS_CATALOG", "spectrum",
    "Unity Catalog name",
)
dbutils.widgets.text(  # noqa: F821
    "DATABRICKS_SCHEMA", "2023_01",
    "Schema / dataset version (e.g. 2024_01)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from stalled.od_matrix_intersector.core.od_matrix_intersector_core import (  # noqa: E402
    aggregate_od,
    build_od_feature_collection,
    build_od_sql,
    parse_zone_geojson,
    records_to_csv_bytes,
)

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

ZONE_GEOJSON   = dbutils.widgets.get("zone_geojson_path").strip()                # noqa: F821
CATALOG        = dbutils.widgets.get("DATABRICKS_CATALOG").strip() or "spectrum" # noqa: F821
SCHEMA         = dbutils.widgets.get("DATABRICKS_SCHEMA").strip() or "2023_01"   # noqa: F821
OUT_PATH       = dbutils.widgets.get("output_folder").strip()                    # noqa: F821

if not OUT_PATH:
    raise ValueError("output_folder widget must not be empty.")

if not ZONE_GEOJSON:
    raise ValueError(
        "Widget 'zone_geojson_path' must not be empty. "
        "Provide an S3 URI or local path to the {uuid}-ZONE.geojson file."
    )

logger.info(
    "zone_geojson=%s  catalog=%s.%s",
    ZONE_GEOJSON, CATALOG, SCHEMA,
)
print(f"Zone GeoJSON: {ZONE_GEOJSON}")
print(f"Catalog     : {CATALOG}.{SCHEMA}")

# COMMAND ----------
# ── I/O helpers ───────────────────────────────────────────────────────────────


def _s3_split(uri: str) -> tuple:
    without = uri[5:]
    bucket, _, prefix = without.partition("/")
    return bucket, prefix


def _read_bytes(path: str) -> bytes:
    """Read bytes from an S3 URI or local path."""
    if path.startswith("s3://"):
        import boto3  # noqa: PLC0415
        bucket, key = _s3_split(path)
        logger.info("Reading s3://%s/%s", bucket, key)
        return boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
    logger.info("Reading local file %s", path)
    with open(path, "rb") as fh:
        return fh.read()


def _put_s3(bucket: str, key: str, data: bytes, content_type: str) -> None:
    import boto3  # noqa: PLC0415
    boto3.client("s3").put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _ensure_dir(path: str) -> None:
    if not path.startswith("s3://"):
        os.makedirs(path, exist_ok=True)


def _write_file(path: str, filename: str, data: bytes, content_type: str) -> str:
    if path.startswith("s3://"):
        bucket, prefix = _s3_split(path)
        key = f"{prefix}/{filename}".lstrip("/")
        _put_s3(bucket, key, data, content_type)
        return f"s3://{bucket}/{key}"
    fp = os.path.join(path, filename)
    with open(fp, "wb") as fh:
        fh.write(data)
    logger.info("Wrote %s  (%d bytes)", fp, len(data))
    return fp


def _output_dir() -> str:
    return OUT_PATH.rstrip("/")


def _write_geoparquet(records: list, out_dir: str, area_id: str, mode: str | None = None):
    """Build a GeoDataFrame from OD records and write as GeoParquet."""
    if not _HAS_GEOPANDAS:
        logger.warning("geopandas not installed — skipping GeoParquet output.")
        return None
    mode_suffix = f"-{mode}" if mode else ""
    filename = f"{area_id}-OD{mode_suffix}.parquet"
    geoms, cleaned = [], []
    for rec in records:
        r    = dict(rec)
        flon = r.pop("_from_lon")
        flat = r.pop("_from_lat")
        tlon = r.pop("_to_lon")
        tlat = r.pop("_to_lat")
        geoms.append(_LineString([(flon, flat), (tlon, tlat)]))
        cleaned.append(r)
    gdf = gpd.GeoDataFrame(cleaned, geometry=geoms, crs="EPSG:4326")
    if out_dir.startswith("s3://"):
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tmp:
            tmp_path = tmp.name
        try:
            gdf.to_parquet(tmp_path)
            bucket, prefix = _s3_split(out_dir)
            key = f"{prefix}/{filename}".lstrip("/")
            with open(tmp_path, "rb") as fh:
                _put_s3(bucket, key, fh.read(), "application/octet-stream")
            return f"s3://{bucket}/{key}"
        finally:
            os.unlink(tmp_path)
    fp = os.path.join(out_dir, filename)
    gdf.to_parquet(fp)
    logger.info("Wrote %s  (%d OD pairs)", fp, len(gdf))
    return fp

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run OD Matrix
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
logger.info("Starting OD matrix derivation at %s", _t_start.isoformat())

# 1. Load zone GeoJSON from S3 or local path
_zone_bytes = _read_bytes(ZONE_GEOJSON)
_zone_fc    = json.loads(_zone_bytes)
logger.info(
    "Loaded zone GeoJSON: %d features",
    len(_zone_fc.get("features", [])),
)

# Read AREA_ID and MODE from zone FC properties
_zone_top = _zone_fc.get("properties") or {}
AREA_ID = _zone_top.get("area_id") or ""
if not AREA_ID:
    from uuid import uuid4  # noqa: PLC0415
    AREA_ID = str(uuid4())
    logger.warning("Zone FC has no 'area_id' property — using generated ID: %s", AREA_ID)

MODE: str | None = _zone_top.get("mode") or None
if not MODE:
    import re  # noqa: PLC0415
    _m = re.search(r"-ZONE-([A-Z0-9]+)\.", ZONE_GEOJSON.upper())
    if _m:
        MODE = _m.group(1)
        logger.info("Mode derived from filename: %s", MODE)
    else:
        logger.warning("Could not determine mode from zone FC or filename.")

print(f"Area ID     : {AREA_ID}")
print(f"Mode        : {MODE or '(unknown)'}")

# 2. Parse zone FC → lookup structures (pure — no I/O)
_gid_to_output, _zone_info, _inner_gids, _known_gids = parse_zone_geojson(_zone_fc)
logger.info(
    "Zone mapping: %d inner gids, %d total known gids",
    len(_inner_gids), len(_known_gids),
)

# 3. Build OD SQL — gids are inlined as integer literals (no ? placeholders)
_sql = build_od_sql(CATALOG, SCHEMA, _inner_gids)
logger.debug("OD SQL (first 300 chars): %s…", _sql[:300])

# 4. Execute via Spark
_df       = spark.sql(_sql)  # noqa: F821 — Databricks-injected
_raw_rows = [row.asDict() for row in _df.collect()]
logger.info("OD query returned %d raw rows", len(_raw_rows))

# 5. Aggregate OD records (pure — no I/O)
_records = aggregate_od(_raw_rows, _gid_to_output, _zone_info, _inner_gids)
logger.info("OD aggregation produced %d output pairs", len(_records))

if not _records:
    raise RuntimeError(
        "OD aggregation produced no records. "
        "Verify that zone_geojson_path is correct and the Spectrum table is reachable."
    )

# 6. Build output artefacts (pure — no I/O)
_metadata = {
    "area_id":   AREA_ID,
    "mode":      MODE,
    "catalog":   CATALOG,
    "db_schema": SCHEMA,
    "origin":    f"{CATALOG}_{SCHEMA}",
    "created":   _t_start.isoformat(),
}
_od_fc      = build_od_feature_collection(_records, metadata=_metadata)
_csv_bytes  = records_to_csv_bytes(_records)

# 7. Prepare output directory
_out_dir = _output_dir()
_ensure_dir(_out_dir)
logger.info("Output directory: %s", _out_dir)

# 8. Write GeoJSON
_mode_suffix = f"-{MODE}" if MODE else ""
_geojson_payload = json.dumps(_od_fc, ensure_ascii=False, indent=2).encode("utf-8")
_geojson_path    = _write_file(
    _out_dir, f"{AREA_ID}-OD{_mode_suffix}.geojson", _geojson_payload, "application/geo+json",
)

# 9. Write CSV
_csv_path = _write_file(
    _out_dir, f"{AREA_ID}-OD{_mode_suffix}.csv", _csv_bytes, "text/csv",
)

# 10. Write GeoParquet (optional — requires geopandas)
_parquet_path = _write_geoparquet(_records, _out_dir, AREA_ID, MODE)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("OD matrix complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

_n_inner_inner = sum(
    1 for r in _records
    if r["fromZoneType"] == "inner" and r["toZoneType"] == "inner"
)
_n_inner_agg = sum(
    1 for r in _records
    if r["fromZoneType"] == "inner" and r["toZoneType"] == "aggregate"
)
_n_agg_inner = sum(
    1 for r in _records
    if r["fromZoneType"] == "aggregate" and r["toZoneType"] == "inner"
)
_total_trips = sum(r["trips"] for r in _records)

print(_SEP)
print(f"OD Matrix complete — {_total_elapsed:.1f}s total")
print(_SEP)
print(f"  Area ID       : {AREA_ID}")
print(f"  Zone GeoJSON  : {ZONE_GEOJSON}")
print(f"  Catalog       : {CATALOG}.{SCHEMA}")
print(f"  Output        : {_out_dir}")
print()
print(f"  OD pairs      : {len(_records)}")
print(f"    inner×inner : {_n_inner_inner}")
print(f"    inner×agg   : {_n_inner_agg}")
print(f"    agg×inner   : {_n_agg_inner}")
print(f"  Total trips   : {_total_trips:,.0f}")
print()
print(f"  GeoJSON       : {_geojson_path}")
print(f"  CSV           : {_csv_path}")
print(f"  GeoParquet    : {_parquet_path or '(skipped — geopandas unavailable)'}")
print(_SEP)
