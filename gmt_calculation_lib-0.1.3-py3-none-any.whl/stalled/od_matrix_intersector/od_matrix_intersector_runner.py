"""Local debug runner for od_matrix_intersector.

Calls od_matrix_intersector_core directly — no Lambda handler involved.

Usage
-----
    python -m od_matrix_intersector.od_matrix_intersector_runner \\
        --zone s3://gmp-networks/zones/deventer-centrum-ZONE-CAR.geojson \\
        --output-geojson s3://gmp-networks/od-matrices/deventer-centrum-OD.geojson \\
        --output-csv     s3://gmp-networks/od-matrices/deventer-centrum-OD.csv \\
        --catalog spectrum --schema 2024_01

Prerequisites
-------------
* Databricks credentials in a .env file or os.environ:
  DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID and one of:
  - DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET  (OAuth M2M, preferred)
  - DATABRICKS_TOKEN  (personal access token, fallback)
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Local runner for od_matrix_intersector (calls core directly)."
    )
    parser.add_argument(
        "--zone",
        required=True,
        metavar="URI",
        help="Full URI of the input zone GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder URI (s3://bucket/prefix/ or local dir). Writes {area_id}-OD.geojson and {area_id}-OD.csv.",
    )
    parser.add_argument("--catalog", default="spectrum", help="Databricks Unity Catalog name")
    parser.add_argument("--schema",  default="2024_01",  help="Databricks schema / dataset version")
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from stalled.od_matrix_intersector.core.od_matrix_intersector_core import (  # noqa: PLC0415
        parse_zone_geojson,
        build_od_sql,
        aggregate_od,
        build_od_feature_collection,
        records_to_csv_bytes,
    )
    import shared.databricks_sql as databricks_sql  # noqa: PLC0415

    # 1. Read zone GeoJSON
    print(f"Reading zone : {args.zone}")
    zone_fc = json.loads(_read_uri(args.zone))

    # Resolve area_id from zone properties
    zone_props = zone_fc.get("properties") or {}
    area_id = zone_props.get("area_id")
    if not area_id:
        from uuid import uuid4  # noqa: PLC0415
        area_id = str(uuid4())
        print(f"area_id auto-generated: {area_id}")

    # Resolve mode: prefer zone FC top-level property, fall back to filename heuristic.
    mode: str | None = zone_props.get("mode") or None
    if not mode:
        # Try to extract from filename, e.g. "…-ZONE-CAR.geojson" → "CAR"
        import re  # noqa: PLC0415
        _m = re.search(r"-ZONE-([A-Z0-9]+)\.", args.zone.upper())
        if _m:
            mode = _m.group(1)
    if mode:
        print(f"Mode         : {mode}")
    else:
        print("Mode         : (unknown)")

    # 2. Parse zone layer
    gid_to_output, zone_info, inner_gids, known_gids = parse_zone_geojson(zone_fc)
    print(f"Inner zones  : {len(inner_gids)}  total known gids: {len(known_gids)}")

    # 3. Query Databricks for OD data
    print(f"Querying Databricks: catalog={args.catalog!r}  schema={args.schema!r}")
    sql = build_od_sql(args.catalog, args.schema, inner_gids)
    with databricks_sql.connect_from_env() as conn:
        with conn.cursor() as cur:
            cur.execute(sql)
            col_names = [d[0] for d in cur.description]
            raw_tuples = cur.fetchall()
    print(f"OD rows returned : {len(raw_tuples)}")

    # Convert tuples to dicts for aggregate_od
    raw_rows = [dict(zip(col_names, row)) for row in raw_tuples]

    # 4. Aggregate
    records = aggregate_od(raw_rows, gid_to_output, zone_info, inner_gids)
    print(f"OD records   : {len(records)}")

    # 5. Build outputs
    from datetime import datetime, timezone  # noqa: PLC0415
    metadata = {
        "area_id":   area_id,
        "mode":      mode,
        "catalog":   args.catalog,
        "db_schema": args.schema,
        "origin":    f"{args.catalog}_{args.schema}",
        "created":   datetime.now(timezone.utc).isoformat(),
    }
    od_fc      = build_od_feature_collection(records, metadata=metadata)
    csv_bytes  = records_to_csv_bytes(records)

    # 6. Write outputs
    from shared.output_path import build_output_path  # noqa: PLC0415
    geojson_uri = build_output_path(args.output_folder, area_id, "OD", mode=mode)
    csv_uri     = build_output_path(args.output_folder, area_id, "OD", mode=mode, extension="csv")
    print(f"Writing GeoJSON : {geojson_uri}")
    _write_uri(geojson_uri, json.dumps(od_fc, ensure_ascii=False).encode("utf-8"))
    print(f"Writing CSV     : {csv_uri}")
    _write_uri(csv_uri, csv_bytes)
    print("Done.")


if __name__ == "__main__":
    main()
