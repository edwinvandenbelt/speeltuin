"""Pydantic input schema for the od-matrix-intersector Lambda handler."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class HandlerInput(BaseModel):
    """Validated event payload for the od-matrix-intersector Lambda handler.

    Required
    --------
    input_zone_file
        S3 URL of the input zone GeoJSON: ``s3://bucket/key``.
    output_geojson_file
        S3 URL where the resulting OD GeoJSON FeatureCollection will be written.
    output_csv_file
        S3 URL where the resulting OD CSV will be written.
    output_network_format
        Format of the output file.  Currently only ``"ogc-geojson"`` is supported.

    Optional
    --------
    catalog
        Databricks Unity Catalog name.  Defaults to ``"spectrum"``.
    db_schema
        Databricks schema (date slug).  Defaults to ``"2024_01"``.
    """

    model_config = ConfigDict(extra="ignore")

    input_zone_file: str
    output_folder: str

    catalog: str = "spectrum"
    db_schema: str = "2024_01"
