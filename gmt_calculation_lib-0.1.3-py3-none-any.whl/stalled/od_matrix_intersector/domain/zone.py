"""Zone GeoJSON parser for the OD-matrix-intersector."""

from __future__ import annotations


def _safe_float(value: object) -> float:
    """Convert *value* to float; return NaN if not possible."""
    if value is None:
        return float("nan")
    try:
        return float(value)
    except (TypeError, ValueError):
        return float("nan")


def parse_zone_geojson(fc: dict) -> tuple[dict, dict, set, set]:
    """Parse a zone GeoJSON FeatureCollection into OD lookup structures.

    Only inner zones are included in the matrix.  Aggregate zones are ignored.
    """
    gid_to_output: dict[int, int] = {}
    zone_info: dict[int, dict] = {}
    inner_gids: set[int] = set()

    for feature in fc.get("features", []):
        props = feature.get("properties") or {}
        if props.get("zoneType") != "inner":
            continue
        out_gid_raw = props.get("gid")
        if out_gid_raw is None:
            continue
        out_gid = int(out_gid_raw)

        zone_info[out_gid] = {
            "zone_id":      str(props.get("zoneId") or ""),
            "zone_type":    "inner",
            "centroid_lon": _safe_float(props.get("centroidLon")),
            "centroid_lat": _safe_float(props.get("centroidLat")),
        }
        gid_to_output[out_gid] = out_gid
        inner_gids.add(out_gid)

    known_gids: set[int] = set(gid_to_output.keys())
    return gid_to_output, zone_info, inner_gids, known_gids
