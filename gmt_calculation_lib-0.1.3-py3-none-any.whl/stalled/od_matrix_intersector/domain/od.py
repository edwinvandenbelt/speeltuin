"""OD aggregation, GeoJSON building, and CSV serialisation for od_matrix_intersector."""

from __future__ import annotations

import csv
import io
import math

_CSV_COLS = [
    "fromZoneId",
    "toZoneId",
    "trips",
]

OD_PROPERTIES: tuple[str, ...] = (
    "odId",
    "fromZoneGid",
    "toZoneGid",
    "fromZoneId",
    "toZoneId",
    "fromZoneType",
    "toZoneType",
    "trips",
)


def _is_valid_coord(lon: float, lat: float) -> bool:
    """Return True when (lon, lat) are finite numbers."""
    return (
        not math.isnan(lon) and not math.isnan(lat)
        and not math.isinf(lon) and not math.isinf(lat)
    )


def aggregate_od(
    raw_rows: list[dict],
    gid_to_output: dict[int, int],
    zone_info: dict[int, dict],
    inner_gids: set[int],
) -> list[dict]:
    """Map raw d030 gid pairs to output zone gids and accumulate ritten."""
    ritten_acc: dict[tuple[int, int], float] = {}

    for raw in raw_rows:
        f_orig = raw.get("from_zone_gid")
        t_orig = raw.get("to_zone_gid")
        trips = float(raw.get("trips") or 0)

        if f_orig is None or t_orig is None:
            continue

        f_orig = int(f_orig)
        t_orig = int(t_orig)

        f_out = gid_to_output.get(f_orig)
        t_out = gid_to_output.get(t_orig)

        if f_out is None or t_out is None:
            continue

        if f_orig not in inner_gids and t_orig not in inner_gids:
            continue

        key = (f_out, t_out)
        ritten_acc[key] = ritten_acc.get(key, 0.0) + trips

    records: list[dict] = []
    for od_id, ((f_gid, t_gid), trips) in enumerate(sorted(ritten_acc.items()), start=1):
        f_info = zone_info.get(f_gid, {})
        t_info = zone_info.get(t_gid, {})
        records.append({
            "odId":          od_id,
            "fromZoneGid":  f_gid,
            "toZoneGid":    t_gid,
            "fromZoneId":   f_info.get("zone_id",   ""),
            "toZoneId":     t_info.get("zone_id",   ""),
            "fromZoneType": f_info.get("zone_type", ""),
            "toZoneType":   t_info.get("zone_type", ""),
            "trips":          round(trips, 4),
            "_from_lon":      f_info.get("centroid_lon", float("nan")),
            "_from_lat":      f_info.get("centroid_lat", float("nan")),
            "_to_lon":        t_info.get("centroid_lon", float("nan")),
            "_to_lat":        t_info.get("centroid_lat", float("nan")),
        })

    return records


def build_od_feature_collection(
    records: list[dict],
    metadata: dict | None = None,
) -> dict:
    """Build a GeoJSON FeatureCollection with one LineString per OD record.

    Parameters
    ----------
    records:
        Output of :func:`aggregate_od`.
    metadata:
        Optional dict of top-level properties to embed alongside
        ``link_properties``.  Typical keys: ``area_id``, ``mode``,
        ``catalog``, ``db_schema``, ``origin``, ``created``.
    """
    features: list[dict] = []
    _SKIP = {"_from_lon", "_from_lat", "_to_lon", "_to_lat"}

    for rec in records:
        flon = rec.get("_from_lon", float("nan"))
        flat = rec.get("_from_lat", float("nan"))
        tlon = rec.get("_to_lon",   float("nan"))
        tlat = rec.get("_to_lat",   float("nan"))

        if _is_valid_coord(flon, flat) and _is_valid_coord(tlon, tlat):
            geometry: dict | None = {
                "type":        "LineString",
                "coordinates": [[flon, flat], [tlon, tlat]],
            }
        else:
            geometry = None

        props = {k: v for k, v in rec.items() if k not in _SKIP}
        features.append({
            "type":       "Feature",
            "geometry":   geometry,
            "properties": props,
        })

    fc_properties: dict = {"link_properties": list(OD_PROPERTIES)}
    if metadata:
        fc_properties.update(metadata)

    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": fc_properties,
    }


def records_to_csv_bytes(records: list[dict]) -> bytes:
    """Serialise OD records as UTF-8 CSV."""
    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=_CSV_COLS, extrasaction="ignore")
    writer.writeheader()
    writer.writerows(records)
    return buf.getvalue().encode("utf-8")
