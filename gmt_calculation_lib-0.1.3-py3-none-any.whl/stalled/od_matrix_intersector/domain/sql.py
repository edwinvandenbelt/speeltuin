"""SQL builder for the OD-matrix-intersector."""

from __future__ import annotations

_OD_TABLE = "d083_hb_matrices_met_2018_kalibratie_effect_auto"


def build_od_sql(catalog: str, schema: str, inner_gids: set[int]) -> str:
    """Return the OD SQL with inner_gids inlined as integer literals."""
    if not inner_gids:
        return (
            f"SELECT od.from_zone_gid, od.to_zone_gid, SUM(od.ritten) AS trips\n"
            f"FROM {catalog}.`{schema}`.{_OD_TABLE} od\n"
            "WHERE 1=0\n"
            "GROUP BY od.from_zone_gid, od.to_zone_gid"
        )

    gids_csv = ", ".join(str(int(g)) for g in sorted(inner_gids))
    return (
        f"SELECT od.from_zone_gid, od.to_zone_gid, SUM(od.ritten) AS trips\n"
        f"FROM {catalog}.`{schema}`.{_OD_TABLE} od\n"
        f"WHERE od.from_zone_gid IN ({gids_csv})\n"
        f"   OR od.to_zone_gid   IN ({gids_csv})\n"
        "GROUP BY od.from_zone_gid, od.to_zone_gid"
    )
