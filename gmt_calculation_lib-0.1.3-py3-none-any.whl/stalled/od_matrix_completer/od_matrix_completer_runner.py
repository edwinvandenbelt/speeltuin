"""Local debug runner for od_matrix_completer.

Calls od_matrix_completer_core directly — no Lambda handler involved.

Takes explicit file paths for all inputs.  By default the completed OD GeoJSON
is written back to the same location as ``--od-file`` (in-place overwrite).

Usage
-----
    python -m od_matrix_completer.od_matrix_completer_runner \\
        --od-file output/deventer/AREA_ID-OD-CAR.geojson \\
        --network-file output/deventer/AREA_ID-NETWORK-CAR.geojson \\
        --feedlink-file output/deventer/AREA_ID-FEEDLINK-CAR.geojson \\
        --zone-file output/deventer/AREA_ID-ZONE-CAR.geojson

    # Write to a different output location:
    python -m od_matrix_completer.od_matrix_completer_runner \\
        --od-file ...  --network-file ...  --feedlink-file ...  --zone-file ... \\
        --output-geojson output/deventer/AREA_ID-OD-COMPLETED-CAR.geojson

    # S3 inputs/outputs:
    python -m od_matrix_completer.od_matrix_completer_runner \\
        --od-file      s3://gmp-networks/deventer/AREA_ID-OD-CAR.geojson \\
        --network-file s3://gmp-networks/deventer/AREA_ID-NETWORK-CAR.geojson \\
        --feedlink-file s3://gmp-networks/deventer/AREA_ID-FEEDLINK-CAR.geojson \\
        --zone-file    s3://gmp-networks/deventer/AREA_ID-ZONE-CAR.geojson

Prerequisites
-------------
* AWS credentials available in the environment or a .env file
  (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for od_matrix_completer. "
            "Builds graph from network+feedlinks, runs gravity model, "
            "and writes a completed OD matrix (overwrites --od-file by default)."
        )
    )
    parser.add_argument(
        "--od-file",
        required=True,
        metavar="URI",
        help="URI of the partial OD GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="URI of the network GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--feedlink-file",
        required=True,
        metavar="URI",
        help="URI of the feedlinks GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--zone-file",
        required=True,
        metavar="URI",
        help="URI of the zones GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--output-geojson",
        default=None,
        metavar="URI",
        help=(
            "URI for the completed OD GeoJSON output.  "
            "Defaults to --od-file (overwrites the input file in place)."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from od_matrix_completer.core.od_matrix_completer_core import (  # noqa: PLC0415
        complete_od_matrix,
    )

    # 1. Read inputs
    print(f"Reading OD        : {args.od_file}")
    od_fc = json.loads(_read_uri(args.od_file))
    print(f"Reading network   : {args.network_file}")
    network_fc = json.loads(_read_uri(args.network_file))
    print(f"Reading feedlinks : {args.feedlink_file}")
    feedlinks_fc = json.loads(_read_uri(args.feedlink_file))
    print(f"Reading zones     : {args.zone_file}")
    zones_fc = json.loads(_read_uri(args.zone_file))

    # 2. Run core
    print("Completing OD matrix ...")
    completed_fc, stats = complete_od_matrix(od_fc, network_fc, feedlinks_fc, zones_fc)

    print(
        f"  {stats['n_zones']} zones  |  "
        f"{stats['n_pairs_total']} pairs total  |  "
        f"{stats['n_observed']} observed  |  "
        f"{stats['n_estimated']} estimated  |  "
        f"{stats['n_unreachable']} unreachable"
    )
    print(f"  Gravity: gamma={stats['gravity_gamma']:.4f}  A={stats['gravity_A']:.4f}")

    # 3. Write output (default: overwrite the input OD file)
    out_uri = args.output_geojson if args.output_geojson else args.od_file
    print(f"Writing output    : {out_uri}")
    _write_uri(out_uri, json.dumps(completed_fc, ensure_ascii=False).encode("utf-8"))
    print("Done.")


if __name__ == "__main__":
    main()
