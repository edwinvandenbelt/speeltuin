# Databricks notebook source
# ---------------------------------------------------------------------------
# od_matrix_completer_nb.py — Databricks notebook for OD matrix completion.
#
# This notebook:
#   1. Reads widget parameters (od_uri, network_uri, feedlinks_uri, zones_uri,
#      output_uri).
#   2. Reads all four input GeoJSON files (s3:// or local path).
#   3. Calls complete_od_matrix (gravity-model gap filling for missing OD pairs).
#   4. Writes the completed OD GeoJSON to output_uri.
#   5. Prints a summary (zones, observed, estimated, unreachable pairs).
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("od_matrix_completer_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "od_uri", "",
    "Full URI of the partial OD matrix GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "network_uri", "",
    "Full URI of the network GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "feedlinks_uri", "",
    "Full URI of the feedlinks GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "zones_uri", "",
    "Full URI of the zones GeoJSON (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri", "",
    "Full URI for the completed OD output GeoJSON (leave blank to overwrite od_uri)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from od_matrix_completer.core.od_matrix_completer_core import complete_od_matrix

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

OD_URI = dbutils.widgets.get("od_uri").strip()  # noqa: F821
NETWORK_URI = dbutils.widgets.get("network_uri").strip()  # noqa: F821
FEEDLINKS_URI = dbutils.widgets.get("feedlinks_uri").strip()  # noqa: F821
ZONES_URI = dbutils.widgets.get("zones_uri").strip()  # noqa: F821
OUTPUT_URI = dbutils.widgets.get("output_uri").strip() or OD_URI  # noqa: F821

if not OD_URI:
    raise ValueError("Widget 'od_uri' is empty — provide a full OD matrix URI.")
if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")
if not FEEDLINKS_URI:
    raise ValueError("Widget 'feedlinks_uri' is empty.")
if not ZONES_URI:
    raise ValueError("Widget 'zones_uri' is empty.")

logger.info(
    "od_uri=%s  network_uri=%s  feedlinks_uri=%s  zones_uri=%s  output_uri=%s",
    OD_URI, NETWORK_URI, FEEDLINKS_URI, ZONES_URI, OUTPUT_URI,
)

# COMMAND ----------
# ── S3 helpers ────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run OD Matrix Completer
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)
print(f"Starting  {_t_start.isoformat()}")
print()

_od_fc = json.loads(_read_uri(OD_URI))
_network_fc = json.loads(_read_uri(NETWORK_URI))
_feedlinks_fc = json.loads(_read_uri(FEEDLINKS_URI))
_zones_fc = json.loads(_read_uri(ZONES_URI))

_completed_fc, _stats = complete_od_matrix(_od_fc, _network_fc, _feedlinks_fc, _zones_fc)

_payload = json.dumps(_completed_fc, ensure_ascii=False).encode("utf-8")
_write_uri(OUTPUT_URI, _payload)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("Done in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"OD matrix completer complete — {_total_elapsed:.1f}s total")
print(_SEP)
print()
print(f"  Zones          : {_stats.get('n_zones', '?')}")
print(f"  Total pairs    : {_stats.get('n_pairs_total', '?')}")
print(f"  Observed       : {_stats.get('n_observed', '?')}")
print(f"  Estimated      : {_stats.get('n_estimated', '?')}")
print(f"  Unreachable    : {_stats.get('n_unreachable', '?')}")
print(
    f"  Gravity model  : gamma={_stats.get('gravity_gamma', '?'):.4f}  "
    f"A={_stats.get('gravity_A', '?'):.4f}"
)
print(f"  Output URI     : {OUTPUT_URI}")
print()
print(_SEP)
