# src/od_matrix_completer/domain/__init__.py
