"""Calibrated power-law gravity model for OD trip estimation.

The model is:

    trips(i, j) = A * cost(i, j) ^ (-gamma)

where ``cost`` is a weighted combination of travel time and distance:

    cost(i, j) = travel_time_s + lambda_ * distance_m

Parameters ``A`` and ``gamma`` are estimated by ordinary least-squares on the
log-transformed equation:

    log(trips) = log(A) - gamma * log(cost)

Only calibration pairs with ``trips > 0`` and ``cost > 0`` are used.  When
fewer than two usable pairs are available the model falls back to sensible
defaults (``gamma = 2.0``, ``A`` chosen so the median estimated trip equals the
median observed trip).

All functions are pure — no I/O, no external dependencies beyond stdlib.
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Default / fallback parameters
# ---------------------------------------------------------------------------

_DEFAULT_GAMMA: float = 2.0
_DEFAULT_LAMBDA: float = 1.0 / 1000.0  # weight for distance (m → km-equivalent)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_cost(
    travel_time_s: float | None,
    distance_m: float | None,
    lambda_: float = _DEFAULT_LAMBDA,
) -> float | None:
    """Combine travel time and distance into a single impedance value.

    Returns ``None`` when neither value is available or when the result is not
    positive.
    """
    tt = travel_time_s if travel_time_s is not None and math.isfinite(travel_time_s) else None
    dm = distance_m if distance_m is not None and math.isfinite(distance_m) else None

    if tt is None and dm is None:
        return None

    cost = (tt or 0.0) + lambda_ * (dm or 0.0)
    return cost if cost > 0.0 else None


def calibrate(
    observed: dict[tuple[str, str], float],
    costs: dict[tuple[str, str], float],
) -> tuple[float, float]:
    """Estimate gravity parameters (A, gamma) from observed OD pairs.

    Parameters
    ----------
    observed:
        ``{(from_zone_id, to_zone_id): trips}`` — known OD trips (inner zones).
    costs:
        ``{(from_zone_id, to_zone_id): cost}`` — impedance from the support
        matrix, produced by :func:`build_cost`.

    Returns
    -------
    A:
        Scale factor (intercept on log scale).
    gamma:
        Impedance decay exponent (slope on log scale, positive value).
    """
    log_trips: list[float] = []
    log_costs: list[float] = []

    for pair, trips in observed.items():
        if trips <= 0.0:
            continue
        cost = costs.get(pair)
        if cost is None or cost <= 0.0:
            continue
        log_trips.append(math.log(trips))
        log_costs.append(math.log(cost))

    n = len(log_trips)
    if n < 2:
        logger.warning(
            "Too few calibration pairs (%d) for gravity model; using defaults "
            "(gamma=%.2f).",
            n,
            _DEFAULT_GAMMA,
        )
        # Derive A from the median observed trip and median cost if possible.
        if n == 1:
            A = math.exp(log_trips[0]) * (math.exp(log_costs[0]) ** _DEFAULT_GAMMA)
        else:
            A = 1.0
        return A, _DEFAULT_GAMMA

    # OLS on  log_trips = log_A - gamma * log_cost
    # i.e.   y = b0 + b1 * x   with x = log_cost, y = log_trips
    mean_x = sum(log_costs) / n
    mean_y = sum(log_trips) / n

    ss_xx = sum((x - mean_x) ** 2 for x in log_costs)
    ss_xy = sum((x - mean_x) * (y - mean_y) for x, y in zip(log_costs, log_trips))

    if ss_xx == 0.0:
        logger.warning("All calibration costs are identical; using default gamma.")
        gamma = _DEFAULT_GAMMA
        log_A = mean_y + gamma * mean_x
    else:
        b1 = ss_xy / ss_xx          # slope  → -gamma
        gamma = max(-b1, 0.01)      # enforce positive decay
        log_A = mean_y + gamma * mean_x

    A = math.exp(log_A)
    r2 = _r_squared(log_trips, log_costs, -gamma, log_A)
    logger.info(
        "Gravity calibration: n=%d  gamma=%.4f  A=%.4f  R²=%.3f",
        n,
        gamma,
        A,
        r2,
    )
    return A, gamma


def estimate(
    cost: float,
    A: float,
    gamma: float,
) -> float:
    """Estimate trips for a single OD pair given its impedance.

    Returns 0.0 when ``cost`` is not positive.
    """
    if cost <= 0.0:
        return 0.0
    return A * (cost ** (-gamma))


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _r_squared(
    log_trips: list[float],
    log_costs: list[float],
    slope: float,
    intercept: float,
) -> float:
    """Coefficient of determination for the log-linear fit."""
    mean_y = sum(log_trips) / len(log_trips)
    ss_tot = sum((y - mean_y) ** 2 for y in log_trips)
    if ss_tot == 0.0:
        return 1.0
    ss_res = sum(
        (y - (intercept + slope * x)) ** 2
        for x, y in zip(log_costs, log_trips)
    )
    return 1.0 - ss_res / ss_tot
