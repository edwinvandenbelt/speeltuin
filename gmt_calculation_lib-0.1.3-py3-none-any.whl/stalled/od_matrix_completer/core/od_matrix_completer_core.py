"""Pure-Python OD-matrix completer core — no I/O, no boto3, no external deps.

Completes a partial OD matrix (which covers only inner-zone pairs) by
estimating trip counts for all remaining zone-pairs using a calibrated
power-law gravity model.

The gravity model is:

    trips(i, j) = A * cost(i, j) ^ (-gamma)

where ``cost`` is derived from Dijkstra routing through *network_fc* +
*feedlinks_fc* (travel time in seconds plus a distance penalty).  ``A`` and
``gamma`` are calibrated by log-linear OLS from the existing inner-zone OD
pairs so that the estimated values are consistent with the observed data.

Public API
----------
parse_od_matrix(fc) -> dict[tuple[str, str], float]
    Extract ``{(fromZoneId, toZoneId): trips}`` from an OD GeoJSON.

parse_zone_ids(fc) -> list[str]
    Extract all unique zone IDs from a zones GeoJSON.

complete_od_matrix(od_fc, network_fc, feedlinks_fc, zones_fc) -> tuple[dict, dict]
    Complete the OD matrix; return (completed_geojson, stats).
"""

from __future__ import annotations

import logging

from od_matrix_completer.domain.gravity import build_cost, calibrate, estimate
from od_support_matrices_creator.core.od_support_matrices_creator_core import (
    build_graph,
    compute_matrix,
    extract_zone_centroids,
    extract_zone_ids,
)

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Output field definitions
# ---------------------------------------------------------------------------

OD_COMPLETED_PROPERTIES: tuple[str, ...] = (
    "odId",
    "fromZoneId",
    "toZoneId",
    "trips",
    "source",       # "observed" | "estimated" | "unreachable" | "zero"
    "travelTime",   # seconds  (float | None)
    "distance",     # metres   (float | None)
)


# ---------------------------------------------------------------------------
# Parsers
# ---------------------------------------------------------------------------


def parse_od_matrix(fc: dict) -> dict[tuple[str, str], float]:
    """Extract ``{(fromZoneId, toZoneId): trips}`` from an OD GeoJSON FC."""
    result: dict[tuple[str, str], float] = {}
    for feat in fc.get("features", []):
        props = feat.get("properties") or {}
        f_id = str(props.get("fromZoneId") or "").strip()
        t_id = str(props.get("toZoneId") or "").strip()
        trips_raw = props.get("trips")
        if not f_id or not t_id or trips_raw is None:
            continue
        try:
            trips = float(trips_raw)
        except (TypeError, ValueError):
            continue
        result[(f_id, t_id)] = trips
    return result


def parse_zone_ids(fc: dict) -> list[str]:
    """Return all unique zoneId values from a zones GeoJSON FeatureCollection."""
    ids: list[str] = []
    seen: set[str] = set()
    for feat in fc.get("features", []):
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "").strip()
        if zone_id and zone_id not in seen:
            ids.append(zone_id)
            seen.add(zone_id)
    return ids


def parse_zone_centroids(fc: dict) -> dict[str, tuple[float, float]]:
    """Return ``{zoneId: (lon, lat)}`` from centroid properties or geometry."""
    centroids: dict[str, tuple[float, float]] = {}
    for feat in fc.get("features", []):
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "").strip()
        if not zone_id:
            continue
        lon_raw = props.get("centroidLon")
        lat_raw = props.get("centroidLat")
        if lon_raw is not None and lat_raw is not None:
            try:
                centroids[zone_id] = (float(lon_raw), float(lat_raw))
                continue
            except (TypeError, ValueError):
                pass
        # Fall back to geometry centroid
        geom = feat.get("geometry") or {}
        coords = _flatten_coords(geom)
        if coords:
            avg_lon = sum(c[0] for c in coords) / len(coords)
            avg_lat = sum(c[1] for c in coords) / len(coords)
            centroids[zone_id] = (avg_lon, avg_lat)
    return centroids


# ---------------------------------------------------------------------------
# Core completion logic
# ---------------------------------------------------------------------------


def complete_od_matrix(
    od_fc: dict,
    network_fc: dict,
    feedlinks_fc: dict,
    zones_fc: dict,
) -> tuple[dict, dict]:
    """Complete a partial OD matrix using a calibrated gravity model.

    Parameters
    ----------
    od_fc:
        Existing (partial) OD GeoJSON FeatureCollection.  May contain only
        inner-zone pairs.
    network_fc:
        Network GeoJSON (output of ``network_intersector`` / ``flow_scaler``).
        Used to build the Dijkstra graph for computing travel times and
        distances between zones.
    feedlinks_fc:
        Feedlinks GeoJSON (output of ``feedlink_creator``).  Connects zone
        centroids to the road network.
    zones_fc:
        Zones GeoJSON (output of ``zone_intersector`` / ``zone_aggregator``).
        Defines the full set of zones to include in the completed matrix.

    Returns
    -------
    completed_fc:
        GeoJSON FeatureCollection with one Feature per OD pair covering every
        (fromZone, toZone) combination for all zones in ``zones_fc``.
    stats:
        Dictionary with keys:
        - ``n_zones`` — number of zones
        - ``n_pairs_total`` — total zone-pair combinations attempted
        - ``n_observed`` — pairs taken directly from the OD matrix
        - ``n_estimated`` — pairs estimated by the gravity model
        - ``n_unreachable`` — pairs with no routing cost (set to 0)
        - ``gravity_gamma`` — calibrated decay exponent
        - ``gravity_A`` — calibrated scale factor
    """
    # 1. Parse observed trips
    observed: dict[tuple[str, str], float] = parse_od_matrix(od_fc)

    # 2. Get zone IDs and centroids from zones_fc
    zone_ids: list[str] = extract_zone_ids(zones_fc)
    zone_centroids: dict[str, tuple[float, float]] = extract_zone_centroids(zones_fc)

    logger.info(
        "OD completer: %d zones, %d observed pairs",
        len(zone_ids),
        len(observed),
    )

    # 3. Build graph and run Dijkstra to get travel times + distances
    adj, zone_node_ids, _ = build_graph(network_fc, feedlinks_fc)
    records = compute_matrix(zone_ids, zone_node_ids, zone_centroids, adj)

    # Build lookup: (fromZoneId, toZoneId) -> {travelTime, distance}
    routing: dict[tuple[str, str], dict] = {
        (r["fromZoneId"], r["toZoneId"]): {
            "travelTime": r["travelTime"],
            "distance": r["distance"],
        }
        for r in records
    }

    # 4. Build cost lookup for gravity model calibration
    costs: dict[tuple[str, str], float] = {}
    for pair, data in routing.items():
        c = build_cost(data.get("travelTime"), data.get("distance"))
        if c is not None:
            costs[pair] = c

    logger.info("OD completer: %d routable zone pairs", len(costs))

    # 5. Calibrate gravity model from observed pairs
    A, gamma = calibrate(observed, costs)

    # 6. Build complete records for every zone combination
    n_observed = 0
    n_estimated = 0
    n_unreachable = 0
    result_records: list[dict] = []

    for od_id, from_id in enumerate(zone_ids, start=1):
        for to_id in zone_ids:
            pair = (from_id, to_id)
            routing_data = routing.get(pair, {})
            travel_time = routing_data.get("travelTime")
            distance = routing_data.get("distance")

            if from_id == to_id:
                trips = 0.0
                source = "zero"
                n_observed += 1
            elif pair in observed:
                trips = observed[pair]
                source = "observed"
                n_observed += 1
            else:
                cost = costs.get(pair)
                if cost is not None:
                    trips = round(estimate(cost, A, gamma), 4)
                    source = "estimated"
                    n_estimated += 1
                else:
                    trips = 0.0
                    source = "unreachable"
                    n_unreachable += 1

            result_records.append({
                "odId": od_id,
                "fromZoneId": from_id,
                "toZoneId": to_id,
                "trips": round(trips, 4),
                "source": source,
                "travelTime": travel_time,
                "distance": distance,
            })

    # 7. Build GeoJSON FeatureCollection
    fc_props = (od_fc.get("properties") or {}).copy()
    fc_props["link_properties"] = list(OD_COMPLETED_PROPERTIES)
    fc_props["gravity_gamma"] = round(gamma, 6)
    fc_props["gravity_A"] = round(A, 6)

    completed_fc = _build_feature_collection(result_records, zone_centroids, fc_props)

    stats: dict = {
        "n_zones": len(zone_ids),
        "n_pairs_total": len(result_records),
        "n_observed": n_observed,
        "n_estimated": n_estimated,
        "n_unreachable": n_unreachable,
        "gravity_gamma": round(gamma, 6),
        "gravity_A": round(A, 6),
    }
    logger.info(
        "OD completion done: %d total pairs — %d observed, %d estimated, %d unreachable",
        len(result_records),
        n_observed,
        n_estimated,
        n_unreachable,
    )
    return completed_fc, stats


# ---------------------------------------------------------------------------
# GeoJSON helpers
# ---------------------------------------------------------------------------


def _build_feature_collection(
    records: list[dict],
    zone_centroids: dict[str, tuple[float, float]],
    fc_properties: dict,
) -> dict:
    """Build a GeoJSON FeatureCollection with one LineString per OD record."""
    _SKIP = {"_from_lon", "_from_lat", "_to_lon", "_to_lat"}
    features: list[dict] = []

    for rec in records:
        from_id = rec["fromZoneId"]
        to_id = rec["toZoneId"]
        f_pt = zone_centroids.get(from_id)
        t_pt = zone_centroids.get(to_id)

        if f_pt is not None and t_pt is not None and from_id != to_id:
            geometry: dict | None = {
                "type": "LineString",
                "coordinates": [list(f_pt), list(t_pt)],
            }
        else:
            geometry = None

        props = {k: v for k, v in rec.items() if k not in _SKIP}
        features.append({
            "type": "Feature",
            "geometry": geometry,
            "properties": props,
        })

    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": fc_properties,
    }


def _flatten_coords(geometry: dict) -> list[tuple[float, float]]:
    """Flatten any GeoJSON geometry to a list of (lon, lat) tuples."""
    gtype = geometry.get("type", "")
    raw = geometry.get("coordinates")
    if raw is None:
        return []
    if gtype == "Point":
        return [(raw[0], raw[1])]
    if gtype in ("LineString", "MultiPoint"):
        return [(c[0], c[1]) for c in raw]
    if gtype in ("Polygon", "MultiLineString"):
        return [(c[0], c[1]) for ring in raw for c in ring]
    if gtype == "MultiPolygon":
        return [(c[0], c[1]) for poly in raw for ring in poly for c in ring]
    return []
