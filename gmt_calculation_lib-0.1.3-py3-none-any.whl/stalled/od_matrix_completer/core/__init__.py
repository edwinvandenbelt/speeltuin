# src/od_matrix_completer/core/__init__.py
