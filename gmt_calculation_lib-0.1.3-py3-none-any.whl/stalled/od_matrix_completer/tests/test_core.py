"""Tests for od_matrix_completer core and gravity model."""

from __future__ import annotations

import pytest

from od_matrix_completer.domain.gravity import build_cost, calibrate, estimate
from od_matrix_completer.core.od_matrix_completer_core import (
    complete_od_matrix,
    parse_od_matrix,
    parse_zone_ids,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _zone_fc(*zone_ids: str) -> dict:
    """Minimal zones FeatureCollection."""
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [float(i), 0.0]},
                "properties": {
                    "zoneId": zid,
                    "centroidLon": float(i),
                    "centroidLat": 0.0,
                },
            }
            for i, zid in enumerate(zone_ids)
        ],
    }


def _od_fc(pairs: dict[tuple[str, str], float]) -> dict:
    """Minimal OD FeatureCollection from a (fromZoneId, toZoneId) → trips dict."""
    features = []
    for (f, t), trips in pairs.items():
        features.append({
            "type": "Feature",
            "geometry": None,
            "properties": {"fromZoneId": f, "toZoneId": t, "trips": trips},
        })
    return {"type": "FeatureCollection", "features": features}


def _net_feature(from_node, to_node, speed, length, capacity):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "fromNode": from_node,
            "toNode": to_node,
            "speed": speed,
            "length": length,
            "capacity": capacity,
            "flowsPerDaypart": {},
        },
    }


def _feedlink_feature(zone_id, network_node_id, direction, length, capacity=1000.0):
    """Build a feedlink feature.

    direction: ``"production"`` -> zone centroid -> network node
               ``"attraction"`` -> network node -> zone centroid
    """
    fake_zone_node = f"gid{zone_id}"
    network_node_str = str(network_node_id)
    if direction == "attraction":
        from_node, to_node = network_node_str, fake_zone_node
    else:
        from_node, to_node = fake_zone_node, network_node_str
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "zoneId": zone_id,
            "fromNode": from_node,
            "toNode": to_node,
            "length": length,
            "capacity": capacity,
        },
    }


def _simple_network_and_feedlinks(zone_ids: list[str]) -> tuple[dict, dict]:
    """Build a simple chain network connecting all zones via nodes 1..N.

    Zone Z_i has a production feedlink to node i and an attraction feedlink
    from node i.  Nodes are connected in a chain: 1→2→…→N (bidirectional via
    pairs of directed links).
    """
    n = len(zone_ids)
    net_features = []
    for i in range(1, n):
        net_features.append(_net_feature(i, i + 1, 36.0, 360.0, 1000.0))
        net_features.append(_net_feature(i + 1, i, 36.0, 360.0, 1000.0))

    fl_features = []
    for idx, zid in enumerate(zone_ids, start=1):
        fl_features.append(_feedlink_feature(zid, idx, "production", 36.0, 800.0))
        fl_features.append(_feedlink_feature(zid, idx, "attraction", 36.0, 800.0))

    return (
        {"type": "FeatureCollection", "features": net_features},
        {"type": "FeatureCollection", "features": fl_features},
    )


# ---------------------------------------------------------------------------
# gravity.build_cost
# ---------------------------------------------------------------------------


def test_build_cost_basic():
    cost = build_cost(600.0, 5000.0)
    assert cost is not None
    assert cost > 600.0  # distance contributes


def test_build_cost_no_distance():
    cost = build_cost(300.0, None)
    assert cost == pytest.approx(300.0)


def test_build_cost_zero_returns_none():
    assert build_cost(0.0, 0.0) is None


def test_build_cost_none_inputs():
    assert build_cost(None, None) is None


# ---------------------------------------------------------------------------
# gravity.calibrate
# ---------------------------------------------------------------------------


def test_calibrate_power_law():
    """Calibrate from trips = A * cost^(-gamma) with known A and gamma."""
    A_true = 1000.0
    gamma_true = 2.0

    costs_raw = [100.0, 200.0, 400.0, 800.0, 1600.0]
    observed = {
        (f"z{i}", f"z{i+10}"): A_true * c ** (-gamma_true)
        for i, c in enumerate(costs_raw)
    }
    costs = {(f"z{i}", f"z{i+10}"): c for i, c in enumerate(costs_raw)}

    A_est, gamma_est = calibrate(observed, costs)

    assert abs(gamma_est - gamma_true) < 0.01
    assert abs(A_est - A_true) / A_true < 0.01


def test_calibrate_insufficient_data_uses_defaults():
    """With fewer than 2 usable pairs, falls back to defaults."""
    _, gamma = calibrate({}, {})
    assert gamma == pytest.approx(2.0)


# ---------------------------------------------------------------------------
# gravity.estimate
# ---------------------------------------------------------------------------


def test_estimate_decreases_with_cost():
    A, gamma = 1000.0, 2.0
    t1 = estimate(100.0, A, gamma)
    t2 = estimate(200.0, A, gamma)
    assert t1 > t2


def test_estimate_zero_cost():
    assert estimate(0.0, 1000.0, 2.0) == 0.0


# ---------------------------------------------------------------------------
# parse_od_matrix
# ---------------------------------------------------------------------------


def test_parse_od_matrix_basic():
    fc = _od_fc({("A", "B"): 100.0, ("B", "A"): 50.0})
    result = parse_od_matrix(fc)
    assert result[("A", "B")] == pytest.approx(100.0)
    assert result[("B", "A")] == pytest.approx(50.0)


def test_parse_od_matrix_skips_missing_fields():
    fc = {
        "type": "FeatureCollection",
        "features": [
            {"type": "Feature", "geometry": None, "properties": {"fromZoneId": "A"}},
        ],
    }
    assert parse_od_matrix(fc) == {}


# ---------------------------------------------------------------------------
# parse_zone_ids
# ---------------------------------------------------------------------------


def test_parse_zone_ids_order_preserved():
    fc = _zone_fc("Z1", "Z2", "Z3")
    assert parse_zone_ids(fc) == ["Z1", "Z2", "Z3"]


def test_parse_zone_ids_no_duplicates():
    fc = _zone_fc("Z1", "Z1", "Z2")
    assert parse_zone_ids(fc) == ["Z1", "Z2"]


# ---------------------------------------------------------------------------
# complete_od_matrix (integration)
# ---------------------------------------------------------------------------


def test_complete_od_matrix_preserves_observed():
    """Observed pairs must be kept as-is in the output."""
    zones = _zone_fc("Z1", "Z2", "Z3")
    od = _od_fc({("Z1", "Z2"): 500.0, ("Z2", "Z1"): 250.0})
    network, feedlinks = _simple_network_and_feedlinks(["Z1", "Z2", "Z3"])

    completed_fc, stats = complete_od_matrix(od, network, feedlinks, zones)

    features = {
        (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"]
        for f in completed_fc["features"]
    }

    assert features[("Z1", "Z2")]["trips"] == pytest.approx(500.0)
    assert features[("Z1", "Z2")]["source"] == "observed"
    assert features[("Z2", "Z1")]["trips"] == pytest.approx(250.0)
    assert features[("Z2", "Z1")]["source"] == "observed"


def test_complete_od_matrix_estimated_pairs_use_gravity():
    """Estimated pairs must have source='estimated' and trips > 0."""
    zones = _zone_fc("Z1", "Z2", "Z3")
    od = _od_fc({("Z1", "Z2"): 500.0, ("Z2", "Z1"): 250.0})
    network, feedlinks = _simple_network_and_feedlinks(["Z1", "Z2", "Z3"])

    completed_fc, stats = complete_od_matrix(od, network, feedlinks, zones)

    features = {
        (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"]
        for f in completed_fc["features"]
    }

    assert features[("Z1", "Z3")]["source"] == "estimated"
    assert features[("Z1", "Z3")]["trips"] > 0

    # Z1→Z3 is farther than Z1→Z2, so fewer trips
    assert features[("Z1", "Z3")]["trips"] < features[("Z1", "Z2")]["trips"]


def test_complete_od_matrix_diagonal_is_zero():
    """Self-pairs must be zero."""
    zones = _zone_fc("Z1", "Z2")
    od = _od_fc({("Z1", "Z2"): 100.0})
    network, feedlinks = _simple_network_and_feedlinks(["Z1", "Z2"])

    completed_fc, _ = complete_od_matrix(od, network, feedlinks, zones)

    features = {
        (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"]
        for f in completed_fc["features"]
    }
    assert features[("Z1", "Z1")]["trips"] == pytest.approx(0.0)
    assert features[("Z2", "Z2")]["trips"] == pytest.approx(0.0)


def test_complete_od_matrix_unreachable_pair():
    """Zone with no feedlink gets trips=0 and source='unreachable'."""
    zones = _zone_fc("Z1", "Z2", "Z3")
    od = _od_fc({("Z1", "Z2"): 100.0})
    # Z3 has no feedlink
    network = {
        "type": "FeatureCollection",
        "features": [
            _net_feature(1, 2, 36.0, 360.0, 1000.0),
            _net_feature(2, 1, 36.0, 360.0, 1000.0),
        ],
    }
    feedlinks = {
        "type": "FeatureCollection",
        "features": [
            _feedlink_feature("Z1", 1, "production", 36.0),
            _feedlink_feature("Z1", 1, "attraction", 36.0),
            _feedlink_feature("Z2", 2, "production", 36.0),
            _feedlink_feature("Z2", 2, "attraction", 36.0),
            # Z3: no feedlink
        ],
    }

    completed_fc, stats = complete_od_matrix(od, network, feedlinks, zones)

    features = {
        (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"]
        for f in completed_fc["features"]
    }
    assert features[("Z1", "Z3")]["source"] == "unreachable"
    assert features[("Z1", "Z3")]["trips"] == pytest.approx(0.0)
    assert stats["n_unreachable"] > 0


def test_complete_od_matrix_stats_counts():
    zones = _zone_fc("Z1", "Z2")
    od = _od_fc({("Z1", "Z2"): 100.0})
    network, feedlinks = _simple_network_and_feedlinks(["Z1", "Z2"])

    _, stats = complete_od_matrix(od, network, feedlinks, zones)

    # 2 zones → 4 pairs
    assert stats["n_pairs_total"] == 4
    assert stats["n_zones"] == 2
    assert stats["n_observed"] >= 1


def test_complete_od_matrix_output_has_travel_time_distance():
    """Output features must carry travelTime and distance from graph routing."""
    zones = _zone_fc("Z1", "Z2")
    od = _od_fc({("Z1", "Z2"): 100.0})
    network, feedlinks = _simple_network_and_feedlinks(["Z1", "Z2"])

    completed_fc, _ = complete_od_matrix(od, network, feedlinks, zones)

    features = {
        (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"]
        for f in completed_fc["features"]
    }
    ab = features[("Z1", "Z2")]
    assert ab["travelTime"] is not None
    assert ab["travelTime"] > 0
    assert ab["distance"] is not None
    assert ab["distance"] > 0
