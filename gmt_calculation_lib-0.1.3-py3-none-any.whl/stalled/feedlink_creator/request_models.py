"""Pydantic input schema for the feedlink-creator Lambda handler."""

from __future__ import annotations

from pydantic import BaseModel, ConfigDict


class HandlerInput(BaseModel):
    """Validated event payload for the feedlink-creator Lambda handler.

    Required
    --------
    input_network_file
        S3 URL of the input network GeoJSON: ``s3://bucket/key``.
    input_zone_file
        S3 URL of the input zone GeoJSON: ``s3://bucket/key``.
    output_network_file
        S3 URL where the resulting feedlink GeoJSON will be written.
    output_network_format
        Format of the output file.  Currently only ``"ogc-geojson"`` is supported.
    mode
        Transport mode.  One of: ``CAR``, ``BIKE``, ``PEDESTRIAN``, ``BUS``,
        ``TRAM``, ``METRO``, ``TRAIN``.

    Optional
    --------
    catalog
        Databricks Unity Catalog name.  Defaults to ``"spectrum"``.
    db_schema
        Databricks schema (date slug).  Defaults to ``"2024_01"``.
    overwrite
        Overwrite the output file if it already exists.  Defaults to ``False``.
    """

    model_config = ConfigDict(extra="ignore")

    input_network_file: str
    input_zone_file: str
    output_folder: str
    mode: str

    catalog: str = "spectrum"
    db_schema: str = "2024_01"
