"""Core orchestrator for feedlink_creator. Delegates to domain modules."""

from __future__ import annotations

import logging

from stalled.feedlink_creator.domain.sql import (
    VOEDINGSLINKS_TABLE,
    build_voedingslinks_sql,
)
from stalled.feedlink_creator.domain.geometry import (
    _D_LAT,
    _flat_earth_dist_m,
    _iter_geojson_coords,
    _WKT_PAIR_RE,
    _WKT_NUM,
    _parse_wkt_geometry,
    _straight_line,
)
from stalled.feedlink_creator.domain.network import (
    parse_network_geojson,
    _derive_inner_bbox,
    _nodes_outside_bbox,
    _boundary_clip_nodes,
)
from stalled.feedlink_creator.domain.zone import parse_zone_geojson
from stalled.feedlink_creator.domain.feedlink import (
    FEEDLINK_PROPERTIES,
    _RING_DIST_EXPONENT,
    _GRAVITY_CANDIDATE_COUNT,
    _GRAVITY_SCORE_MIN_DIST_M,
    _build_inner_feedlinks,
    _best_node,
    _build_aggregate_feedlinks,
)

logger = logging.getLogger(__name__)


def derive_feedlinks(
    network: dict,
    zones: list,
    voedingslinks_rows: list,
    mode: str,
) -> dict:
    """Derive a feedlink FeatureCollection from parsed network + zone data."""
    inner_zones = [z for z in zones if z.get("zoneType") == "inner"]
    agg_zones   = [z for z in zones if z.get("zoneType") == "aggregate"]
    zone_by_gid = {int(z["gid"]): z for z in inner_zones if z.get("gid") is not None}

    inner_bbox = _derive_inner_bbox(zones)

    vl_rows = []
    for r in voedingslinks_rows:
        if r.get("naar_knoop_id") in network["all_node_ids"]:
            vl_rows.append(r)
        else:
            logger.debug(
                "VL row gid=%s: node %s not in network — row dropped",
                r.get("van_centroid_gid"), r.get("naar_knoop_id"),
            )
    if voedingslinks_rows and len(vl_rows) < len(voedingslinks_rows):
        logger.info(
            "Voedingslinks rows after network-clip filter: %d / %d",
            len(vl_rows), len(voedingslinks_rows),
        )

    records, fid = _build_inner_feedlinks(
        vl_rows, zone_by_gid, network["node_positions"], network["all_node_ids"],
        mode, 1,
    )

    agg_records, _ = _build_aggregate_feedlinks(
        agg_zones, network, inner_bbox, mode, fid,
    )
    records.extend(agg_records)

    logger.info(
        "Feedlinks total: %d  (%d inner ringIndex==-1, %d aggregate ringIndex>=0)",
        len(records),
        sum(1 for r in records if r["properties"]["ringIndex"] == -1),
        sum(1 for r in records if r["properties"]["ringIndex"] >= 0),
    )
    return {
        "type": "FeatureCollection",
        "features": records,
        "properties": {"link_properties": list(FEEDLINK_PROPERTIES)},
    }


def derive_centroids(feedlinks_fc: dict) -> dict:
    """Derive a centroids GeoJSON from a feedlinks FeatureCollection.

    One ``Point`` feature is produced per zone.  The centroid's ``nodeId`` is
    the zone-side node of the feedlink — i.e. ``fromNode`` of a production
    feedlink (which equals ``str(zoneGid)``), or ``toNode`` of an attraction
    feedlink as a fallback.  This virtual zone node is the origin/destination
    node for demand in the STAQ assignment model; the feedlinks themselves
    connect these virtual nodes to the real network.

    Priority: production feedlink > attraction feedlink > any other direction.

    Each output feature carries:
    - ``zoneId``    — zone identifier (string)
    - ``nodeId``    — zone centroid node ID in the STAQ network (string)
    - ``zoneIndex`` — 1-based integer index, sorted by ``zoneId``

    The result is consumed by ``link_based_staq_assigner`` (needs ``nodeId`` + ``zoneIndex``).
    """
    production: dict[str, tuple] = {}  # zoneId -> (feat, zone_node_id)
    fallback:   dict[str, tuple] = {}  # zoneId -> (feat, zone_node_id)

    for feat in feedlinks_fc.get("features", []):
        props     = feat.get("properties") or {}
        zone_id   = str(props.get("zoneId")   or "").strip()

        # Determine the zone-side node: fromNode for production, toNode for attraction.
        # Feedlinks in the new schema always have fromNode / toNode.
        from_node = str(props.get("fromNode") or "").strip()
        to_node   = str(props.get("toNode")   or "").strip()

        # Heuristic: for a production feedlink fromNode is the zone centroid (digit-like id).
        # For an attraction feedlink toNode is the zone centroid.
        # We detect direction by checking which of fromNode/toNode looks like a zone node.
        # Since zone node IDs are str(gid) they tend to be numeric, but we rely on the
        # explicit linkDirection field when present (legacy) and fall back to fromNode
        # from production feedlinks when the field is absent (new schema).
        direction  = props.get("linkDirection")        # may be None in new schema
        # In the new schema there is no linkDirection; instead the geometry encodes direction.
        # Production feedlink: fromNode = zone centroid, toNode = network node.
        # We detect "production" either via the explicit field or by the absence of the field
        # combined with fromNode appearing to be a zone centroid (numeric gid string).

        if not zone_id:
            continue

        # Resolve zone-side node id
        if direction == "production":
            zone_node_id = from_node
        elif direction == "attraction":
            zone_node_id = to_node
        elif direction is None:
            # New schema: production feedlinks have fromNode = str(gid), which is numeric.
            # Use fromNode as the zone-side node (it will be numeric for production records
            # and an alphanumeric network-node id for attraction records produced first).
            zone_node_id = from_node if from_node else to_node
        else:
            zone_node_id = from_node if from_node else to_node

        if not zone_node_id:
            continue

        if direction == "production" and zone_id not in production:
            production[zone_id] = (feat, zone_node_id)
        if zone_id not in fallback:
            fallback[zone_id] = (feat, zone_node_id)

    # Production feedlinks take priority; fallback covers zones with only
    # attraction feedlinks.
    chosen: dict[str, tuple] = {**fallback, **production}

    features = []
    for idx, zone_id in enumerate(sorted(chosen), start=1):
        feat, zone_node_id = chosen[zone_id]
        geom   = feat.get("geometry") or {}
        coords = geom.get("coordinates") or []
        # For a LineString the zone-side endpoint is coords[0].
        if geom.get("type") == "LineString" and coords:
            point_coords = coords[0]
        elif geom.get("type") == "Point":
            point_coords = coords
        else:
            point_coords = [0.0, 0.0]

        features.append({
            "type": "Feature",
            "id": zone_id,
            "geometry": {"type": "Point", "coordinates": point_coords},
            "properties": {
                "zoneId":    zone_id,
                "nodeId":    zone_node_id,
                "zoneIndex": idx,
            },
        })

    logger.info("derive_centroids: %d centroids from %d feedlinks", len(features),
                len(feedlinks_fc.get("features", [])))
    return {"type": "FeatureCollection", "features": features}


__all__ = [
    "VOEDINGSLINKS_TABLE",
    "FEEDLINK_PROPERTIES",
    "_D_LAT",
    "_RING_DIST_EXPONENT",
    "_GRAVITY_CANDIDATE_COUNT",
    "_GRAVITY_SCORE_MIN_DIST_M",
    "_WKT_NUM",
    "_WKT_PAIR_RE",
    "build_voedingslinks_sql",
    "parse_network_geojson",
    "parse_zone_geojson",
    "derive_feedlinks",
    "derive_centroids",
    "_flat_earth_dist_m",
    "_iter_geojson_coords",
    "_parse_wkt_geometry",
    "_straight_line",
    "_derive_inner_bbox",
    "_nodes_outside_bbox",
    "_boundary_clip_nodes",
    "_build_inner_feedlinks",
    "_best_node",
    "_build_aggregate_feedlinks",
]
