# Databricks notebook source
# ---------------------------------------------------------------------------
# feedlink_creator_nb.py — Databricks notebook interface for feedlink creation.
#
# This notebook:
#   1. Reads widget parameters (network_uri, zone_uri, output_folder, mode, …).
#   2. Loads the network and zone GeoJSON from the provided full URIs.
#   3. Queries the voedingslinks table via spark.sql() using the SQL string
#      built by feedlink_creator.feedlink_creator_core.build_voedingslinks_sql().
#   4. Calls feedlink_creator.feedlink_creator_core.derive_feedlinks() — pure Python, no I/O.
#   5. Always writes two outputs to output_folder:
#        {area_id}-FEEDLINK-{mode}.geojson
#        {area_id}-MERGED-NETWORK-{mode}.geojson
#
# Requirements (Databricks cluster):
#   pip install boto3   (or attach via cluster library; only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" or set these before executing cells.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text("network_uri",   "", "Full URI of the input network GeoJSON (s3:// or local path)")  # noqa: F821
dbutils.widgets.text("zone_uri",      "", "Full URI of the input zone GeoJSON (s3:// or local path)")     # noqa: F821
dbutils.widgets.text("output_folder", "", "Output folder: s3://bucket/prefix  or  /dbfs/path (required)")  # noqa: F821
dbutils.widgets.text("mode",          "CAR", "Transport mode")                                             # noqa: F821
dbutils.widgets.text("catalog",       "spectrum", "Unity Catalog name")                                    # noqa: F821
dbutils.widgets.text("schema",        "2023_01",  "Schema / dataset version")                              # noqa: F821

# COMMAND ----------
NETWORK_URI   = dbutils.widgets.get("network_uri").strip()    # noqa: F821
ZONE_URI      = dbutils.widgets.get("zone_uri").strip()       # noqa: F821
OUT_FOLDER    = dbutils.widgets.get("output_folder").strip()  # noqa: F821
MODE          = dbutils.widgets.get("mode").strip().upper()   # noqa: F821
CATALOG       = dbutils.widgets.get("catalog").strip()        # noqa: F821
SCHEMA        = dbutils.widgets.get("schema").strip()         # noqa: F821

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' must not be empty.")
if not ZONE_URI:
    raise ValueError("Widget 'zone_uri' must not be empty.")
if not OUT_FOLDER:
    raise ValueError("Widget 'output_folder' must not be empty.")
if not MODE:
    raise ValueError("Widget 'mode' must not be empty.")
logger.info(
    "network_uri=%s  zone_uri=%s  output_folder=%s  mode=%s  catalog=%s  schema=%s",
    NETWORK_URI, ZONE_URI, OUT_FOLDER, MODE, CATALOG, SCHEMA,
)

# COMMAND ----------
from stalled.feedlink_creator.core.feedlink_creator_core import (  # noqa: E402
    VOEDINGSLINKS_TABLE,
    build_voedingslinks_sql,
    derive_feedlinks,
    parse_network_geojson,
    parse_zone_geojson,
)

# COMMAND ----------
# ── URI helpers ────────────────────────────────────────────────────────────────

def _read_bytes(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        import boto3  # noqa: PLC0415
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read %s  (%d bytes)", uri, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_file(folder: str, filename: str, data: bytes) -> str:
    if folder.startswith("s3://"):
        bucket, prefix = folder[5:].split("/", 1)
        key = f"{prefix}/{filename}".lstrip("/")
        import boto3  # noqa: PLC0415
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
        )
        uri = f"s3://{bucket}/{key}"
        logger.info("Wrote %s  (%d bytes)", uri, len(data))
        return uri
    os.makedirs(folder, exist_ok=True)
    fp = os.path.join(folder, filename)
    with open(fp, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", fp, len(data))
    return fp

# COMMAND ----------
# 1. Load network GeoJSON
print(f"Reading network : {NETWORK_URI}")
raw_network_fc = json.loads(_read_bytes(NETWORK_URI))
network = parse_network_geojson(raw_network_fc)

# Read AREA_ID from network properties
AREA_ID = (raw_network_fc.get("properties") or {}).get("area_id") or ""
if not AREA_ID:
    from uuid import uuid4  # noqa: PLC0415
    AREA_ID = str(uuid4())
    logger.warning("Network has no 'area_id' property — using generated ID: %s", AREA_ID)
print(f"Area ID         : {AREA_ID}")

# COMMAND ----------
# 2. Load zone GeoJSON
print(f"Reading zones   : {ZONE_URI}")
zones = parse_zone_geojson(json.loads(_read_bytes(ZONE_URI)))

# COMMAND ----------
# 3. Query voedingslinks via spark.sql (if applicable)
table_name = VOEDINGSLINKS_TABLE.get(MODE)
vl_rows: list = []

inner_zones = [z for z in zones if z.get("zoneType") == "inner"]
inner_gids  = [int(z["gid"]) for z in inner_zones if z.get("gid") is not None]

if table_name and inner_gids:
    sql = build_voedingslinks_sql(CATALOG, SCHEMA, table_name, inner_gids)
    logger.info(
        "Querying %s.%s.%s for %d inner zone gids …",
        CATALOG, SCHEMA, table_name, len(inner_gids),
    )
    df = spark.sql(sql)  # noqa: F821 — spark is Databricks-injected
    vl_rows = [row.asDict() for row in df.collect()]
    logger.info("Voedingslinks query returned %d rows", len(vl_rows))
elif not table_name:
    logger.info("Mode %s has no voedingslinks table — no inner feedlinks.", MODE)

# COMMAND ----------
# 4. Derive feedlinks (pure — no I/O)
feedlinks_fc = derive_feedlinks(network, zones, vl_rows, MODE)
n_fl = len(feedlinks_fc["features"])
logger.info(
    "Feedlinks derived: %d total  (%d inner, %d aggregate)",
    n_fl,
    sum(1 for f in feedlinks_fc["features"] if f["properties"]["zone_type"] == "inner"),
    sum(1 for f in feedlinks_fc["features"] if f["properties"]["zone_type"] == "aggregate"),
)

# COMMAND ----------
# 5. Write outputs
_feedlink_path = _write_file(
    OUT_FOLDER,
    f"{AREA_ID}-FEEDLINK-{MODE}.geojson",
    json.dumps(feedlinks_fc).encode(),
)

# COMMAND ----------
# Results summary
_SEP = "─" * 60
print(_SEP)
print(f"Feedlink Creator complete")
print(_SEP)
print(f"  Area ID          : {AREA_ID}")
print(f"  Mode             : {MODE}")
print(f"  Feedlinks        : {n_fl}")
print()
print(f"  FEEDLINK         : {_feedlink_path}")
print(_SEP)
