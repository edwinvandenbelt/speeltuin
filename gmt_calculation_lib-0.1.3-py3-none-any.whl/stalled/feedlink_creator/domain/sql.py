"""SQL builder and voedingslinks table mapping for feedlink_creator."""

from __future__ import annotations

# None → no Spectrum voedingslinks table for this mode
VOEDINGSLINKS_TABLE: dict[str, str | None] = {
    "CAR":        "d110_voedingslinks",
    "BIKE":       "d120_voedingslinks",
    "PEDESTRIAN": None,
    "BUS":        "d140_voedingslinks",
    "TRAM":       "d140_voedingslinks",
    "METRO":      "d140_voedingslinks",
    "TRAIN":      "d140_voedingslinks",
}


def build_voedingslinks_sql(
    catalog: str,
    schema: str,
    table: str,
    inner_gids: list,
) -> str:
    """Return a SELECT statement for the given inner-zone gids."""
    where = (
        "WHERE FALSE"
        if not inner_gids
        else "WHERE van_centroid_gid IN (" + ", ".join(str(int(g)) for g in inner_gids) + ")"
    )
    return (
        f"SELECT link_id,\n"
        f"       van_centroid_gid,\n"
        f"       naar_knoop_id,\n"
        f"       link_type_heen,\n"
        f"       link_type_terug,\n"
        f"       capaciteit_heen_pae_per_uur,\n"
        f"       capaciteit_terug_pae_per_uur,\n"
        f"       wkt_geom_4326\n"
        f"FROM `{catalog}`.`{schema}`.{table}\n"
        f"{where}"
    )
