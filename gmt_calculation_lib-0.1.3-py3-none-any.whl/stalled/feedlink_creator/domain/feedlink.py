"""Feedlink building logic for feedlink_creator."""

from __future__ import annotations

import heapq
import logging

from stalled.feedlink_creator.domain.geometry import _flat_earth_dist_m, _parse_wkt_geometry, _straight_line
from stalled.feedlink_creator.domain.network import _boundary_clip_nodes, _nodes_outside_bbox

logger = logging.getLogger(__name__)

# Property keys present on every feature in the feedlinks FeatureCollection.
# These mirror the fields used on regular network links so that the lbs-assigner
# can treat feedlinks and regular links uniformly.
FEEDLINK_PROPERTIES: tuple[str, ...] = (
    "feedlinkId",
    "reverseLinkIds",
    "zoneId",
    "fromNode",
    "toNode",
    "length",
    "capacity",
    "mode",
    "ringIndex",
    "ringLabel",
    "sectorIndex",
    "type",
)

# Aggregate-zone gravity scoring: distance exponent by ring_index
_RING_DIST_EXPONENT: dict[int, float] = {
    0: 2.00,
    1: 1.50,
    2: 1.00,
    3: 0.75,
    4: 0.50,
}
_GRAVITY_CANDIDATE_COUNT  = 10
_GRAVITY_SCORE_MIN_DIST_M = 500.0


def _build_inner_feedlinks(
    vl_rows: list,
    zone_by_gid: dict,
    node_positions: dict,
    all_node_ids: set,
    mode: str,
    fid_start: int,
) -> tuple[list, int]:
    """Convert voedingslinks rows into GeoJSON feature records for inner zones.

    Each row produces two records: one production feedlink (zone -> node) and
    one attraction feedlink (node -> zone).  The zone-centroid node ID is
    ``str(gid)``.
    """
    records = []
    fid     = fid_start

    for raw in vl_rows:
        gid     = raw.get("van_centroid_gid")
        node_id = raw.get("naar_knoop_id")

        if gid is None or node_id is None:
            continue
        gid = int(gid)
        zone = zone_by_gid.get(gid)
        if zone is None:
            logger.debug("VL row gid=%d: zone not found in zone_by_gid — skipped", gid)
            continue
        if node_id not in node_positions:
            logger.debug(
                "VL row gid=%d zone=%s: node %s not in node_positions — skipped",
                gid, zone.get("zoneId"), node_id,
            )
            continue

        zone_node_id = str(gid)
        node_lon, node_lat = node_positions[node_id]
        zone_lon   = float(zone.get("centroidLon") or 0)
        zone_lat   = float(zone.get("centroidLat") or 0)
        production = float(zone.get("production")  or 0.0)
        attraction = float(zone.get("attraction")  or 0.0)
        dist_m     = _flat_earth_dist_m(zone_lon, zone_lat, node_lon, node_lat)

        geom_prod = _parse_wkt_geometry(raw.get("wkt_geom_4326"))
        if geom_prod is None:
            geom_prod = _straight_line(zone_lon, zone_lat, node_lon, node_lat)
        # Attraction geometry is the reverse direction.
        geom_attr = _straight_line(node_lon, node_lat, zone_lon, zone_lat)

        zone_id  = str(zone.get("zoneId") or "")
        length   = round(dist_m, 1)

        prod_fid = fid
        attr_fid = fid + 1

        # Production: zone centroid -> network node
        if production > 0.0:
            records.append({
                "type": "Feature",
                "geometry": geom_prod,
                "properties": {
                    "feedlinkId":     prod_fid,
                    "reverseLinkIds": [attr_fid],
                    "zoneId":         zone_id,
                    "fromNode":       zone_node_id,
                    "toNode":         node_id,
                    "length":         length,
                    "capacity":       production,
                    "mode":           mode,
                    "ringIndex":      -1,
                    "ringLabel":      "",
                    "sectorIndex":    -1,
                    "type":           "feedlink",
                },
            })
        else:
            logger.debug(
                "Zone %s (gid=%d): production=0 — production feedlink suppressed",
                zone_id, gid,
            )

        # Attraction: network node -> zone centroid
        if attraction > 0.0:
            records.append({
                "type": "Feature",
                "geometry": geom_attr,
                "properties": {
                    "feedlinkId":     attr_fid,
                    "reverseLinkIds": [prod_fid],
                    "zoneId":         zone_id,
                    "fromNode":       node_id,
                    "toNode":         zone_node_id,
                    "length":         length,
                    "capacity":       attraction,
                    "mode":           mode,
                    "ringIndex":      -1,
                    "ringLabel":      "",
                    "sectorIndex":    -1,
                    "type":           "feedlink",
                },
            })
        else:
            logger.debug(
                "Zone %s (gid=%d): attraction=0 — attraction feedlink suppressed",
                zone_id, gid,
            )
        fid += 2

    logger.info("Built %d inner feedlinks for mode %s", len(records), mode)
    return records, fid


def _best_node(
    zone_lon: float,
    zone_lat: float,
    candidates: list,
    node_positions: dict,
    node_flow: dict,
    node_speed: dict,
    ring_idx: int,
) -> tuple | None:
    """Select the single best node for one zone/direction via gravity model."""
    if not candidates:
        return None

    alpha = _RING_DIST_EXPONENT.get(ring_idx, _RING_DIST_EXPONENT[4])

    heap: list = []
    for nid in candidates:
        if nid not in node_positions:
            continue
        nlon, nlat = node_positions[nid]
        dist_m   = _flat_earth_dist_m(zone_lon, zone_lat, nlon, nlat)
        neg_dist = -dist_m
        if len(heap) < _GRAVITY_CANDIDATE_COUNT:
            heapq.heappush(heap, (neg_dist, nid))
        elif neg_dist > heap[0][0]:
            heapq.heapreplace(heap, (neg_dist, nid))

    if not heap:
        return None

    best_score = -1.0
    best_nid   = None
    best_dist  = 0.0

    for neg_dist, nid in heap:
        dist_m = -neg_dist
        flow   = float(node_flow.get(nid, 0.0))
        speed  = float(node_speed.get(nid, 0.0))
        score  = flow * speed / max(dist_m, _GRAVITY_SCORE_MIN_DIST_M) ** alpha
        if score > best_score:
            best_score = score
            best_nid   = nid
            best_dist  = dist_m

    return (best_nid, best_dist) if best_nid is not None else None


def _build_aggregate_feedlinks(
    agg_zones: list,
    network: dict,
    inner_bbox: tuple,
    mode: str,
    fid_start: int,
) -> tuple[list, int]:
    """Build one production + one attraction feedlink per aggregate zone.

    Capacity is the zone's production (production feedlink) or attraction
    (attraction feedlink).
    """
    node_positions     = network["node_positions"]
    node_speed_out     = network["node_speed_out"]
    node_speed_in      = network["node_speed_in"]
    node_flow_out      = network["node_flow_out"]
    node_flow_in       = network["node_flow_in"]
    node_cap_out       = network["node_capacity"]
    node_cap_in        = network["node_cap_incoming"]
    from_nodes         = network["from_nodes"]
    to_nodes           = network["to_nodes"]
    node_out_neighbors = network["node_out_neighbors"]
    node_in_neighbors  = network["node_in_neighbors"]

    from_candidates = _boundary_clip_nodes(
        from_nodes, node_positions, node_out_neighbors, inner_bbox,
    )
    to_candidates = _boundary_clip_nodes(
        to_nodes, node_positions, node_in_neighbors, inner_bbox,
    )
    logger.info(
        "Aggregate candidates — from-nodes: %d (boundary: %d), "
        "to-nodes: %d (boundary: %d)",
        len(from_nodes), len(from_candidates),
        len(to_nodes),   len(to_candidates),
    )

    records = []
    fid     = fid_start

    for zone in agg_zones:
        ring_idx     = int(zone.get("ringIndex") or 0)
        zone_lon     = float(zone.get("centroidLon") or 0)
        zone_lat     = float(zone.get("centroidLat") or 0)
        gid          = int(zone.get("gid") or 0)
        zone_id      = str(zone.get("zoneId") or "")
        ring_lbl     = str(zone.get("ringLabel") or "")
        sec_idx      = int(zone.get("sectorIndex") or 0)
        zone_node_id = str(gid)
        production   = float(zone.get("production") or 0.0)
        attraction   = float(zone.get("attraction") or 0.0)

        pinned_node_id = zone.get("nodeId")
        if pinned_node_id is not None and pinned_node_id in node_positions:
            nlon, nlat = node_positions[pinned_node_id]
            dist_m     = _flat_earth_dist_m(zone_lon, zone_lat, nlon, nlat)
            logger.debug(
                "Zone gid=%d: using pinned nodeId=%s  dist=%.0f m",
                gid, pinned_node_id, dist_m,
            )
            length   = round(dist_m, 1)
            prod_fid = fid
            attr_fid = fid + 1
            for direction in ("production", "attraction"):
                if direction == "production":
                    geom      = _straight_line(zone_lon, zone_lat, nlon, nlat)
                    from_node = zone_node_id
                    to_node   = pinned_node_id
                    capacity  = production
                    this_fid  = prod_fid
                    rev_ids   = [attr_fid]
                else:
                    geom      = _straight_line(nlon, nlat, zone_lon, zone_lat)
                    from_node = pinned_node_id
                    to_node   = zone_node_id
                    capacity  = attraction
                    this_fid  = attr_fid
                    rev_ids   = [prod_fid]
                if capacity == 0.0:
                    continue
                records.append({
                    "type": "Feature",
                    "geometry": geom,
                    "properties": {
                        "feedlinkId":     this_fid,
                        "reverseLinkIds": rev_ids,
                        "zoneId":         zone_id,
                        "fromNode":       from_node,
                        "toNode":         to_node,
                        "length":         length,
                        "capacity":       capacity,
                        "mode":           mode,
                        "ringIndex":      ring_idx,
                        "ringLabel":      ring_lbl,
                        "sectorIndex":    sec_idx,
                        "type":           "feedlink",
                    },
                })
            fid += 2
            continue

        for direction, candidates, flow_dict, speed_dict in (
            ("production", from_candidates, node_flow_out, node_speed_out),
            ("attraction", to_candidates,   node_flow_in,  node_speed_in),
        ):
            result = _best_node(
                zone_lon, zone_lat,
                candidates,
                node_positions,
                flow_dict,
                speed_dict,
                ring_idx,
            )
            if result is None:
                logger.debug(
                    "Zone gid=%d ring=%d dir=%s: no candidate — skipping.",
                    gid, ring_idx, direction,
                )
                continue

            node_id, dist_m = result
            nlon, nlat = node_positions[node_id]

            if direction == "production":
                geom      = _straight_line(zone_lon, zone_lat, nlon, nlat)
                from_node = zone_node_id
                to_node   = node_id
                capacity  = production
            else:
                geom      = _straight_line(nlon, nlat, zone_lon, zone_lat)
                from_node = node_id
                to_node   = zone_node_id
                capacity  = attraction

            if capacity == 0.0:
                continue

            records.append({
                "type": "Feature",
                "geometry": geom,
                "properties": {
                    "feedlinkId":     fid,
                    "reverseLinkIds": [],
                    "zoneId":         zone_id,
                    "fromNode":       from_node,
                    "toNode":         to_node,
                    "length":         round(dist_m, 1),
                    "capacity":       capacity,
                    "mode":           mode,
                    "ringIndex":      ring_idx,
                    "ringLabel":      ring_lbl,
                    "sectorIndex":    sec_idx,
                    "type":           "feedlink",
                },
            })
            fid += 1

    logger.info(
        "Built %d aggregate feedlinks for mode %s",
        len(records), mode,
    )
    return records, fid
