"""Zone GeoJSON parser for feedlink_creator."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def parse_zone_geojson(fc: dict) -> list:
    """Parse a zone FeatureCollection dict into a list of property dicts."""
    result = []
    for feat in fc.get("features") or []:
        props = dict(feat.get("properties") or {})
        props["_geometry"] = feat.get("geometry")
        result.append(props)
    logger.info(
        "Parsed %d zones (%d inner, %d aggregate)",
        len(result),
        sum(1 for z in result if z.get("zoneType") == "inner"),
        sum(1 for z in result if z.get("zoneType") == "aggregate"),
    )
    return result
