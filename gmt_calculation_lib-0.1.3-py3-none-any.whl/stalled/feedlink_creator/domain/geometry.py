"""Geometry helpers for feedlink_creator: distance, WKT parsing, straight lines.

All implementations live in ``shared.geo_utils``; this module re-exports
the subset used by feedlink_creator so that intra-module imports are unchanged.
"""

from __future__ import annotations

from shared.geo_utils import (  # noqa: F401
    _D_LAT,
    _flat_earth_dist_m,
    _iter_geojson_coords,
    _WKT_NUM,
    _WKT_PAIR_RE,
    _parse_wkt_geometry,
    _straight_line,
)
