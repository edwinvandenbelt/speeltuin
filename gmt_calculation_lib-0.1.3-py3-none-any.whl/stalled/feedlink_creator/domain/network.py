"""Network GeoJSON parser and boundary-node helpers for feedlink_creator."""

from __future__ import annotations

import logging

from stalled.feedlink_creator.domain.geometry import _iter_geojson_coords

logger = logging.getLogger(__name__)


def parse_network_geojson(fc: dict) -> dict:
    """Parse a network FeatureCollection dict into per-node lookup tables."""
    features = fc.get("features") or []
    logger.info("Parsing network: %d features", len(features))

    node_positions:     dict = {}
    node_cap:           dict = {}
    node_cap_in:        dict = {}
    node_speed_out:     dict = {}
    node_speed_in:      dict = {}
    node_flow_out:      dict = {}
    node_flow_in:       dict = {}
    node_out_neighbors: dict = {}
    node_in_neighbors:  dict = {}
    has_outgoing: set = set()
    has_incoming: set = set()

    for feat in features:
        props  = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords:
            continue

        from_node = props.get("fromNode")
        to_node   = props.get("toNode")
        capacity  = float(props.get("capacity") or 0)
        speed     = float(props.get("speed")    or 0)
        flow24    = float(props.get("flow24hrs") or 0)

        if from_node is not None:
            node_positions.setdefault(from_node, (coords[0][0], coords[0][1]))
            has_outgoing.add(from_node)
            if capacity > node_cap.get(from_node, 0.0):
                node_cap[from_node] = capacity
            if speed > node_speed_out.get(from_node, 0.0):
                node_speed_out[from_node] = speed
            node_flow_out[from_node] = node_flow_out.get(from_node, 0.0) + flow24

        if to_node is not None:
            node_positions.setdefault(to_node, (coords[-1][0], coords[-1][1]))
            has_incoming.add(to_node)
            if capacity > node_cap_in.get(to_node, 0.0):
                node_cap_in[to_node] = capacity
            if speed > node_speed_in.get(to_node, 0.0):
                node_speed_in[to_node] = speed
            node_flow_in[to_node] = node_flow_in.get(to_node, 0.0) + flow24

        if from_node is not None and to_node is not None:
            node_out_neighbors.setdefault(from_node, set()).add(to_node)
            node_in_neighbors.setdefault(to_node,   set()).add(from_node)

    all_node_ids   = set(node_positions.keys())
    entry_nodes    = has_outgoing - has_incoming
    exit_nodes     = has_incoming - has_outgoing
    boundary_nodes = entry_nodes | exit_nodes

    logger.info(
        "Network nodes: %d total, %d from-nodes, %d to-nodes, "
        "%d entry (production), %d exit (attraction)",
        len(all_node_ids), len(has_outgoing), len(has_incoming),
        len(entry_nodes), len(exit_nodes),
    )
    return {
        "node_positions":      node_positions,
        "node_capacity":       node_cap,
        "node_cap_incoming":   node_cap_in,
        "node_speed_out":      node_speed_out,
        "node_speed_in":       node_speed_in,
        "node_flow_out":       node_flow_out,
        "node_flow_in":        node_flow_in,
        "node_out_neighbors":  node_out_neighbors,
        "node_in_neighbors":   node_in_neighbors,
        "from_nodes":          has_outgoing,
        "to_nodes":            has_incoming,
        "entry_nodes":         entry_nodes,
        "exit_nodes":          exit_nodes,
        "boundary_nodes":      boundary_nodes,
        "all_node_ids":        all_node_ids,
    }


def _derive_inner_bbox(zone_features: list) -> tuple:
    """Return (min_lon, min_lat, max_lon, max_lat) of all inner-zone geometries.

    Falls back to all zone geometries when no zones carry ``zoneType == 'inner'``.
    """
    min_lon = min_lat = float("inf")
    max_lon = max_lat = float("-inf")

    # Try inner zones first; fall back to all zones.
    candidates = [z for z in zone_features if z.get("zoneType") == "inner"]
    fallback    = not candidates
    if fallback:
        candidates = zone_features
        logger.warning(
            "_derive_inner_bbox: no inner zones found — using all %d zone(s) as bbox fallback.",
            len(candidates),
        )

    for z in candidates:
        for lon, lat in _iter_geojson_coords(z.get("_geometry") or {}):
            if lon < min_lon: min_lon = lon  # noqa: E701
            if lon > max_lon: max_lon = lon  # noqa: E701
            if lat < min_lat: min_lat = lat  # noqa: E701
            if lat > max_lat: max_lat = lat  # noqa: E701

    if min_lon == float("inf"):
        raise ValueError("No zone geometries found — cannot derive inner bbox.")
    logger.info(
        "Inner-zone bbox (WGS84): lon [%.4f, %.4f]  lat [%.4f, %.4f]%s",
        min_lon, max_lon, min_lat, max_lat,
        " (fallback: all zones)" if fallback else "",
    )
    return min_lon, min_lat, max_lon, max_lat


def _nodes_outside_bbox(node_ids, node_positions: dict, bbox: tuple) -> list:
    """Filter *node_ids* to those whose position lies outside *bbox*."""
    min_lon, min_lat, max_lon, max_lat = bbox
    outside = [
        n for n in node_ids
        if n in node_positions and (
            node_positions[n][0] < min_lon
            or node_positions[n][0] > max_lon
            or node_positions[n][1] < min_lat
            or node_positions[n][1] > max_lat
        )
    ]
    if not outside:
        logger.warning(
            "_nodes_outside_bbox: no nodes outside bbox — falling back to all %d nodes.",
            len(node_ids),
        )
        return list(node_ids)
    return outside


def _boundary_clip_nodes(
    node_ids,
    node_positions: dict,
    directed_neighbors: dict,
    bbox: tuple,
) -> list:
    """Nodes outside the inner bbox that have ≥1 directed neighbour inside it."""
    min_lon, min_lat, max_lon, max_lat = bbox

    def _inside(nid) -> bool:
        pos = node_positions.get(nid)
        return (
            pos is not None
            and min_lon <= pos[0] <= max_lon
            and min_lat <= pos[1] <= max_lat
        )

    result = []
    for nid in node_ids:
        pos = node_positions.get(nid)
        if pos is None:
            continue
        if min_lon <= pos[0] <= max_lon and min_lat <= pos[1] <= max_lat:
            continue
        if any(_inside(nb) for nb in directed_neighbors.get(nid, ())):
            result.append(nid)

    if not result:
        logger.warning(
            "_boundary_clip_nodes: no boundary nodes found — "
            "falling back to outside-bbox nodes.",
        )
        return _nodes_outside_bbox(node_ids, node_positions, bbox)
    return result
