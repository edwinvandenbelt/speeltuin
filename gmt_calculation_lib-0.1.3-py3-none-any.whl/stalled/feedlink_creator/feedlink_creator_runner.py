"""Local debug runner for feedlink_creator.

Calls feedlink_creator_core directly — no Lambda handler involved.

Usage
-----
    python -m feedlink_creator.feedlink_creator_runner \\
        --network s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.geojson \\
        --zone    s3://gmp-networks/zones/deventer-centrum-ZONE-CAR.geojson \\
        --output-folder s3://gmp-networks/feedlinks/ \\
        --mode CAR --catalog spectrum --schema 2024_01

    # area_id is read from the network GeoJSON properties.area_id;
    # outputs written: {area_id}-FEEDLINK-{mode}.geojson,
    #                  {area_id}-MERGED-NETWORK-{mode}.geojson

Prerequisites
-------------
* Databricks credentials in a .env file or os.environ:
  DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID and one of:
  - DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET  (OAuth M2M, preferred)
  - DATABRICKS_TOKEN  (personal access token, fallback)
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Local runner for feedlink_creator (calls core directly)."
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="Full URI of the input network GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--zone",
        required=True,
        metavar="URI",
        help="Full URI of the input zone GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help=(
            "Output folder URI (s3://bucket/prefix/ or local dir). "
            "Always writes a FEEDLINK file."
        ),
    )
    parser.add_argument("--mode", required=True, help="Transport mode, e.g. CAR")
    parser.add_argument("--catalog", default="spectrum", help="Databricks Unity Catalog name")
    parser.add_argument("--schema",  default="2024_01",  help="Databricks schema / dataset version")
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from stalled.feedlink_creator.core.feedlink_creator_core import (  # noqa: PLC0415
        VOEDINGSLINKS_TABLE,
        build_voedingslinks_sql,
        parse_network_geojson,
        parse_zone_geojson,
        derive_feedlinks,
    )
    import shared.databricks_sql as databricks_sql  # noqa: PLC0415
    from shared.output_path import build_output_path  # noqa: PLC0415

    mode = args.mode.upper()

    # 1. Read network + zone files
    print(f"Reading network : {args.network}")
    raw_network_fc = json.loads(_read_uri(args.network))
    print(f"Reading zones   : {args.zone}")
    raw_zone_fc    = json.loads(_read_uri(args.zone))

    # Resolve area_id from network properties
    area_id = (raw_network_fc.get("properties") or {}).get("area_id")
    if not area_id:
        from uuid import uuid4  # noqa: PLC0415
        area_id = str(uuid4())
        print(f"area_id auto-generated: {area_id}")

    # 2. Parse
    network = parse_network_geojson(raw_network_fc)
    zones   = parse_zone_geojson(raw_zone_fc)

    # 3. Query voedingslinks from Databricks (if table exists for this mode)
    table_name = VOEDINGSLINKS_TABLE.get(mode)
    vl_rows: list = []
    if table_name:
        inner_gids = [
            int(z["gid"])
            for z in zones
            if z.get("zoneType") == "inner" and z.get("gid") is not None
        ]
        print(
            f"Querying Databricks voedingslinks: table={table_name!r}  "
            f"inner_gids={len(inner_gids)}"
        )
        sql = build_voedingslinks_sql(args.catalog, args.schema, table_name, inner_gids)
        with databricks_sql.connect_from_env() as conn:
            with conn.cursor() as cur:
                cur.execute(sql)
                col_names  = [d[0] for d in cur.description]
                vl_rows    = [dict(zip(col_names, row)) for row in cur.fetchall()]
        print(f"Voedingslinks rows : {len(vl_rows)}")
    else:
        print(f"No voedingslinks table for mode {mode!r} — skipping Databricks query.")

    # 4. Derive feedlinks
    feedlinks_fc = derive_feedlinks(network, zones, vl_rows, mode)
    print(f"Feedlinks produced : {len(feedlinks_fc['features'])}")

    # 5. Write outputs to the folder
    feedlinks_fc.setdefault("properties", {})["area_id"] = area_id

    feedlinks_uri = build_output_path(args.output_folder, area_id, "FEEDLINK", mode)

    print(f"Writing feedlinks       : {feedlinks_uri}")
    _write_uri(feedlinks_uri, json.dumps(feedlinks_fc, ensure_ascii=False).encode("utf-8"))

    print("Done.")


if __name__ == "__main__":
    main()
