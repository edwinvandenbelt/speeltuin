"""Unit tests for feedlink_creator.feedlink_creator_core — pure functions, no I/O."""

from __future__ import annotations

import pytest

from stalled.feedlink_creator.core.feedlink_creator_core import (
    VOEDINGSLINKS_TABLE,
    _boundary_clip_nodes,
    _build_aggregate_feedlinks,
    _build_inner_feedlinks,
    _best_node,
    _derive_inner_bbox,
    _flat_earth_dist_m,
    _nodes_outside_bbox,
    _parse_wkt_geometry,
    _straight_line,
    build_voedingslinks_sql,
    derive_centroids,
    derive_feedlinks,
    parse_network_geojson,
    parse_zone_geojson,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_network_fc(*edges):
    """Build a minimal network FeatureCollection.

    Each edge is a dict with keys: from_node, to_node, lon0, lat0, lon1, lat1,
    and optional capacity, speed, flow24.
    """
    features = []
    for e in edges:
        features.append({
            "type": "Feature",
            "geometry": {
                "type": "LineString",
                "coordinates": [
                    [e["lon0"], e["lat0"]],
                    [e["lon1"], e["lat1"]],
                ],
            },
            "properties": {
                "fromNode": e["from_node"],
                "toNode":   e["to_node"],
                "capacity": e.get("capacity", 1000.0),
                "speed":    e.get("speed", 60.0),
                "flow24hrs": e.get("flow24", 500.0),
            },
        })
    return {"type": "FeatureCollection", "features": features}


def _make_zone_fc(*zones):
    """Build a minimal zone FeatureCollection.

    Each zone is a dict with at least: gid, zone_id, zone_type,
    centroid_lon, centroid_lat, and optional ring_index, ring_label,
    sector_index, geometry (raw GeoJSON geometry dict).
    """
    features = []
    for z in zones:
        geom = z.get("geometry") or {
            "type": "Point",
            "coordinates": [z.get("centroid_lon", 0), z.get("centroid_lat", 0)],
        }
        props = {k: v for k, v in z.items() if k != "geometry"}
        features.append({"type": "Feature", "geometry": geom, "properties": props})
    return {"type": "FeatureCollection", "features": features}


# ---------------------------------------------------------------------------
# VOEDINGSLINKS_TABLE
# ---------------------------------------------------------------------------

def test_voedingslinks_table_car():
    assert VOEDINGSLINKS_TABLE["CAR"] == "d110_voedingslinks"


def test_voedingslinks_table_pedestrian_is_none():
    assert VOEDINGSLINKS_TABLE["PEDESTRIAN"] is None


def test_voedingslinks_table_pt_modes_all_same():
    for mode in ("BUS", "TRAM", "METRO", "TRAIN"):
        assert VOEDINGSLINKS_TABLE[mode] == "d140_voedingslinks"


# ---------------------------------------------------------------------------
# build_voedingslinks_sql
# ---------------------------------------------------------------------------

def test_build_voedingslinks_sql_basic():
    sql = build_voedingslinks_sql("cat", "sch", "d110_voedingslinks", [1, 2, 3])
    assert "FROM `cat`.`sch`.d110_voedingslinks" in sql
    assert "WHERE van_centroid_gid IN (1, 2, 3)" in sql
    assert "van_centroid_gid" in sql
    assert "naar_knoop_id" in sql
    assert "wkt_geom_4326" in sql


def test_build_voedingslinks_sql_single_gid():
    sql = build_voedingslinks_sql("c", "s", "t", [42])
    assert "IN (42)" in sql


def test_build_voedingslinks_sql_empty_gids():
    sql = build_voedingslinks_sql("c", "s", "t", [])
    assert "WHERE FALSE" in sql
    assert "IN (" not in sql


# ---------------------------------------------------------------------------
# _flat_earth_dist_m
# ---------------------------------------------------------------------------

def test_flat_earth_dist_same_point():
    assert _flat_earth_dist_m(5.0, 52.0, 5.0, 52.0) == pytest.approx(0.0)


def test_flat_earth_dist_one_degree_lat():
    # ~111 320 m per degree latitude
    d = _flat_earth_dist_m(5.0, 52.0, 5.0, 53.0)
    assert 110_000 < d < 112_000


def test_flat_earth_dist_one_degree_lon_at_52():
    # ~68 700 m per degree longitude at 52°N
    d = _flat_earth_dist_m(5.0, 52.0, 6.0, 52.0)
    assert 68_000 < d < 70_000


# ---------------------------------------------------------------------------
# _parse_wkt_geometry
# ---------------------------------------------------------------------------

def test_parse_wkt_linestring():
    geom = _parse_wkt_geometry("LINESTRING (4.9 52.3, 5.0 52.4)")
    assert geom is not None
    assert geom["type"] == "LineString"
    assert len(geom["coordinates"]) == 2
    assert geom["coordinates"][0] == pytest.approx([4.9, 52.3])


def test_parse_wkt_multilinestring():
    geom = _parse_wkt_geometry("MULTILINESTRING ((1 2, 3 4), (5 6, 7 8))")
    assert geom is not None
    assert geom["type"] == "MultiLineString"
    assert len(geom["coordinates"]) == 2


def test_parse_wkt_none_input():
    assert _parse_wkt_geometry(None) is None


def test_parse_wkt_empty_string():
    assert _parse_wkt_geometry("") is None


def test_parse_wkt_single_point_linestring():
    # Only one coordinate pair — not a valid line
    assert _parse_wkt_geometry("LINESTRING (1 2)") is None


def test_parse_wkt_unknown_type():
    assert _parse_wkt_geometry("POINT (1 2)") is None


# ---------------------------------------------------------------------------
# _straight_line
# ---------------------------------------------------------------------------

def test_straight_line():
    geom = _straight_line(4.9, 52.3, 5.1, 52.5)
    assert geom["type"] == "LineString"
    assert geom["coordinates"] == [[4.9, 52.3], [5.1, 52.5]]


# ---------------------------------------------------------------------------
# parse_network_geojson
# ---------------------------------------------------------------------------

def test_parse_network_geojson_basic():
    fc = _make_network_fc(
        {"from_node": "A", "to_node": "B", "lon0": 5.0, "lat0": 52.0, "lon1": 5.1, "lat1": 52.1},
        {"from_node": "B", "to_node": "C", "lon0": 5.1, "lat0": 52.1, "lon1": 5.2, "lat1": 52.2},
    )
    net = parse_network_geojson(fc)
    assert "A" in net["node_positions"]
    assert "C" in net["node_positions"]
    assert net["entry_nodes"] == {"A"}
    assert net["exit_nodes"]  == {"C"}
    assert net["all_node_ids"] == {"A", "B", "C"}


def test_parse_network_geojson_empty():
    net = parse_network_geojson({"type": "FeatureCollection", "features": []})
    assert net["all_node_ids"] == set()
    assert net["entry_nodes"] == set()
    assert net["exit_nodes"]  == set()


def test_parse_network_geojson_flow_accumulates():
    fc = _make_network_fc(
        {"from_node": "X", "to_node": "Y", "lon0": 0.0, "lat0": 0.0, "lon1": 1.0, "lat1": 0.0,
         "flow24": 100.0},
        {"from_node": "X", "to_node": "Z", "lon0": 0.0, "lat0": 0.0, "lon1": -1.0, "lat1": 0.0,
         "flow24": 200.0},
    )
    net = parse_network_geojson(fc)
    assert net["node_flow_out"]["X"] == pytest.approx(300.0)


# ---------------------------------------------------------------------------
# parse_zone_geojson
# ---------------------------------------------------------------------------

def test_parse_zone_geojson_basic():
    fc = _make_zone_fc(
        {"gid": 1, "zoneId": "z1", "zoneType": "inner",     "centroidLon": 5.0, "centroidLat": 52.0},
        {"gid": 2, "zoneId": "z2", "zoneType": "aggregate", "centroidLon": 6.0, "centroidLat": 53.0,
         "ringIndex": 1, "ringLabel": "ring1", "sectorIndex": 0},
    )
    zones = parse_zone_geojson(fc)
    assert len(zones) == 2
    inner = next(z for z in zones if z["zoneType"] == "inner")
    assert inner["gid"] == 1
    assert "_geometry" in inner


def test_parse_zone_geojson_empty():
    zones = parse_zone_geojson({"type": "FeatureCollection", "features": []})
    assert zones == []


# ---------------------------------------------------------------------------
# _derive_inner_bbox
# ---------------------------------------------------------------------------

def test_derive_inner_bbox():
    fc = _make_zone_fc(
        {"gid": 1, "zoneType": "inner", "centroidLon": 5.0, "centroidLat": 52.0,
         "geometry": {"type": "Point", "coordinates": [5.0, 52.0]}},
        {"gid": 2, "zoneType": "inner", "centroidLon": 5.5, "centroidLat": 52.5,
         "geometry": {"type": "Point", "coordinates": [5.5, 52.5]}},
        {"gid": 3, "zoneType": "aggregate", "centroidLon": 10.0, "centroidLat": 60.0,
         "geometry": {"type": "Point", "coordinates": [10.0, 60.0]}},
    )
    zones = parse_zone_geojson(fc)
    bbox = _derive_inner_bbox(zones)
    min_lon, min_lat, max_lon, max_lat = bbox
    assert min_lon == pytest.approx(5.0)
    assert min_lat == pytest.approx(52.0)
    assert max_lon == pytest.approx(5.5)
    assert max_lat == pytest.approx(52.5)


def test_derive_inner_bbox_no_inner_zones_falls_back_to_all_zones():
    """When no inner zones exist the bbox should be derived from all zones."""
    fc = _make_zone_fc(
        {"gid": 1, "zoneType": "aggregate", "centroidLon": 5.0, "centroidLat": 52.0,
         "geometry": {"type": "Point", "coordinates": [5.0, 52.0]}},
        {"gid": 2, "zoneType": "aggregate", "centroidLon": 5.5, "centroidLat": 52.5,
         "geometry": {"type": "Point", "coordinates": [5.5, 52.5]}},
    )
    zones = parse_zone_geojson(fc)
    min_lon, min_lat, max_lon, max_lat = _derive_inner_bbox(zones)
    assert min_lon == pytest.approx(5.0)
    assert min_lat == pytest.approx(52.0)
    assert max_lon == pytest.approx(5.5)
    assert max_lat == pytest.approx(52.5)


def test_derive_inner_bbox_no_zones_raises():
    zones = parse_zone_geojson({"type": "FeatureCollection", "features": []})
    with pytest.raises(ValueError, match="No zone geometries found"):
        _derive_inner_bbox(zones)


# ---------------------------------------------------------------------------
# _nodes_outside_bbox / _boundary_clip_nodes
# ---------------------------------------------------------------------------

def test_nodes_outside_bbox():
    positions = {
        "A": (4.0, 51.0),   # outside (west)
        "B": (5.2, 52.2),   # inside
        "C": (6.0, 52.0),   # outside (east)
    }
    bbox = (5.0, 52.0, 5.5, 52.5)
    outside = _nodes_outside_bbox({"A", "B", "C"}, positions, bbox)
    assert set(outside) == {"A", "C"}


def test_nodes_outside_bbox_fallback_when_all_inside():
    positions = {"A": (5.1, 52.1)}
    bbox = (5.0, 52.0, 5.5, 52.5)
    result = _nodes_outside_bbox({"A"}, positions, bbox)
    assert result == ["A"]  # fallback: return all


def test_boundary_clip_nodes():
    # A is outside bbox but has neighbour B inside -> boundary node
    # C is outside but has no inside neighbours -> not a boundary node
    positions = {
        "A": (4.9, 52.2),   # outside
        "B": (5.1, 52.2),   # inside
        "C": (6.0, 52.2),   # outside
        "D": (7.0, 52.2),   # outside
    }
    directed_neighbors = {
        "A": {"B"},
        "C": {"D"},
    }
    bbox = (5.0, 52.0, 5.5, 52.5)
    result = _boundary_clip_nodes({"A", "C"}, positions, directed_neighbors, bbox)
    assert result == ["A"]


# ---------------------------------------------------------------------------
# _best_node
# ---------------------------------------------------------------------------

def test_best_node_picks_highest_scorer():
    positions = {
        "near":  (5.00001, 52.0),   # very close — high score
        "far":   (6.0,     52.0),   # far — lower score
    }
    flow  = {"near": 1000.0, "far": 1000.0}
    speed = {"near": 60.0,   "far": 60.0}
    result = _best_node(5.0, 52.0, ["near", "far"], positions, flow, speed, ring_idx=0)
    assert result is not None
    nid, dist = result
    assert nid == "near"
    assert dist < 1000


def test_best_node_empty_candidates():
    assert _best_node(5.0, 52.0, [], {}, {}, {}, ring_idx=0) is None


def test_best_node_zero_flow_and_speed():
    # All scores are 0 — function should still return a node (first non-negative)
    positions = {"A": (5.1, 52.1)}
    flow  = {"A": 0.0}
    speed = {"A": 0.0}
    result = _best_node(5.0, 52.0, ["A"], positions, flow, speed, ring_idx=0)
    # score=0 never beats best_score=-1 unless we handle 0 correctly
    # Our implementation: score=0 > -1.0 -> best_nid = "A"
    assert result is not None
    assert result[0] == "A"


# ---------------------------------------------------------------------------
# _build_inner_feedlinks
# ---------------------------------------------------------------------------

def test_build_inner_feedlinks_basic():
    zone_by_gid = {
        10: {
            "zoneId": "inner-10", "centroidLon": 5.05, "centroidLat": 52.05, "gid": 10,
            "production": 400.0, "attraction": 300.0,
        },
    }
    node_positions = {"N1": (5.06, 52.06)}
    vl_rows = [{
        "van_centroid_gid": 10,
        "naar_knoop_id":    "N1",
        "wkt_geom_4326":    None,
        "link_type_heen":   "access",
        "link_type_terug":  "access",
        "capaciteit_heen_pae_per_uur":  500.0,
        "capaciteit_terug_pae_per_uur": 500.0,
    }]
    records, next_fid = _build_inner_feedlinks(
        vl_rows, zone_by_gid, node_positions, {"N1"}, "CAR", 1
    )
    # Each VL row produces 2 feedlinks: production + attraction
    assert len(records) == 2
    assert next_fid == 3

    prod = records[0]
    attr = records[1]

    assert prod["properties"]["feedlinkId"]     == 1
    assert prod["properties"]["reverseLinkIds"] == [2]
    assert prod["properties"]["fromNode"]       == "10"   # str(gid) = zone centroid node
    assert prod["properties"]["toNode"]         == "N1"
    assert prod["properties"]["mode"]           == "CAR"
    assert prod["properties"]["ringIndex"]      == -1
    assert prod["properties"]["capacity"]       == pytest.approx(400.0)
    assert prod["properties"]["type"]           == "feedlink"
    assert prod["geometry"]["type"]             == "LineString"

    assert attr["properties"]["feedlinkId"]     == 2
    assert attr["properties"]["reverseLinkIds"] == [1]
    assert attr["properties"]["fromNode"]       == "N1"   # network node
    assert attr["properties"]["toNode"]         == "10"   # zone centroid node
    assert attr["properties"]["capacity"]       == pytest.approx(300.0)
    assert attr["properties"]["type"]           == "feedlink"
    assert attr["geometry"]["type"]             == "LineString"
    # Attraction geometry runs from network node to zone centroid
    assert attr["geometry"]["coordinates"][0]   == pytest.approx([5.06, 52.06])


def test_build_inner_feedlinks_flow_values():
    """Production feedlink carries zone production as capacity; attraction carries zone attraction."""
    zone_by_gid = {
        10: {
            "zoneId": "inner-10", "centroidLon": 5.05, "centroidLat": 52.05, "gid": 10,
            "production": 1234.0, "attraction": 567.0,
        },
    }
    node_positions = {"N1": (5.06, 52.06)}
    vl_rows = [{
        "van_centroid_gid": 10, "naar_knoop_id": "N1", "wkt_geom_4326": None,
        "link_type_heen": None, "link_type_terug": None,
        "capaciteit_heen_pae_per_uur": 500.0, "capaciteit_terug_pae_per_uur": 500.0,
    }]
    records, _ = _build_inner_feedlinks(vl_rows, zone_by_gid, node_positions, {"N1"}, "CAR", 1)
    prod = next(r for r in records if r["properties"]["fromNode"] == "10")
    attr = next(r for r in records if r["properties"]["toNode"]   == "10")
    assert prod["properties"]["capacity"] == pytest.approx(1234.0)
    assert attr["properties"]["capacity"] == pytest.approx(567.0)


def test_build_inner_feedlinks_node_not_in_network():
    zone_by_gid = {1: {"zoneId": "z1", "centroidLon": 5.0, "centroidLat": 52.0, "gid": 1}}
    node_positions = {}  # node absent from network
    vl_rows = [{"van_centroid_gid": 1, "naar_knoop_id": "MISSING",
                "wkt_geom_4326": None, "link_type_heen": None, "link_type_terug": None,
                "capaciteit_heen_pae_per_uur": None, "capaciteit_terug_pae_per_uur": None}]
    records, _ = _build_inner_feedlinks(vl_rows, zone_by_gid, node_positions, set(), "CAR", 1)
    assert records == []


def test_build_inner_feedlinks_uses_wkt_geometry():
    zone_by_gid = {5: {"zoneId": "z5", "centroidLon": 5.0, "centroidLat": 52.0, "gid": 5,
                       "production": 200.0, "attraction": 150.0}}
    node_positions = {"N": (5.1, 52.1)}
    vl_rows = [{
        "van_centroid_gid": 5,
        "naar_knoop_id":    "N",
        "wkt_geom_4326":    "LINESTRING (5.0 52.0, 5.1 52.1)",
        "link_type_heen": None, "link_type_terug": None,
        "capaciteit_heen_pae_per_uur": None, "capaciteit_terug_pae_per_uur": None,
    }]
    records, _ = _build_inner_feedlinks(vl_rows, zone_by_gid, node_positions, {"N"}, "CAR", 1)
    # Production uses the WKT geometry
    assert records[0]["geometry"]["type"] == "LineString"
    assert len(records[0]["geometry"]["coordinates"]) == 2
    # Attraction is always a straight-line (reversed direction)
    assert records[1]["geometry"]["type"] == "LineString"
    assert records[1]["geometry"]["coordinates"][0] == pytest.approx([5.1, 52.1])
    assert records[1]["geometry"]["coordinates"][1] == pytest.approx([5.0, 52.0])


# ---------------------------------------------------------------------------
# _build_aggregate_feedlinks
# ---------------------------------------------------------------------------

def _simple_network_and_bbox():
    """Return (network, inner_bbox) for a small deterministic test case."""
    # Inner area: lon 5.0-5.5, lat 52.0-52.5
    # Network: one edge from outside (4.9) into inside (5.1)
    #          one edge from inside (5.4) to outside (5.6)
    fc = _make_network_fc(
        {"from_node": "EXT_A", "to_node": "INT_A",
         "lon0": 4.9, "lat0": 52.2, "lon1": 5.1, "lat1": 52.2,
         "capacity": 1500.0, "speed": 80.0, "flow24": 800.0},
        {"from_node": "INT_B", "to_node": "EXT_B",
         "lon0": 5.4, "lat0": 52.3, "lon1": 5.6, "lat1": 52.3,
         "capacity": 1200.0, "speed": 70.0, "flow24": 600.0},
    )
    net = parse_network_geojson(fc)
    inner_bbox = (5.0, 52.0, 5.5, 52.5)
    return net, inner_bbox


def test_build_aggregate_feedlinks_produces_records():
    net, inner_bbox = _simple_network_and_bbox()
    agg_zones = [{
        "gid": 99, "zone_id": "agg-99", "zone_type": "aggregate",
        "centroid_lon": 3.0, "centroid_lat": 52.0,
        "ring_index": 0, "ring_label": "r0", "sector_index": 1,
    }]
    records, _ = _build_aggregate_feedlinks(agg_zones, net, inner_bbox, "CAR", fid_start=10)
    # Should get at most 2 records (production + attraction)
    assert len(records) <= 2
    for r in records:
        props = r["properties"]
        assert props["mode"]   == "CAR"
        assert props["type"]   == "feedlink"
        # One end of each feedlink must be the zone centroid node "99"
        assert "99" in (props["fromNode"], props["toNode"])


def test_build_aggregate_feedlinks_pinned_node_used_directly():
    """When a zone has nodeId and the node is in the network, skip the gravity model."""
    net, inner_bbox = _simple_network_and_bbox()
    # EXT_A is an entry node in the simple network (outside bbox, has outgoing edge)
    agg_zones = [{
        "gid": 50, "zoneId": "agg-50", "zoneType": "aggregate",
        "centroidLon": 3.0, "centroidLat": 51.0,
        "ringIndex": 0, "ringLabel": "r0", "sectorIndex": 2,
        "nodeId": "EXT_A",
        "production": 800.0, "attraction": 600.0,
    }]
    records, next_fid = _build_aggregate_feedlinks(agg_zones, net, inner_bbox, "CAR", fid_start=1)
    # Must produce exactly 2 feedlinks (one per direction)
    assert len(records) == 2
    assert next_fid == 3

    prod = next(r for r in records if r["properties"]["fromNode"] == "50")
    attr = next(r for r in records if r["properties"]["toNode"]   == "50")

    # Production: zone centroid (str gid) -> EXT_A
    assert prod["properties"]["fromNode"]       == "50"
    assert prod["properties"]["toNode"]         == "EXT_A"
    assert prod["properties"]["reverseLinkIds"] == [2]
    assert prod["geometry"]["coordinates"][0]   == pytest.approx([3.0, 51.0])
    assert prod["geometry"]["coordinates"][1]   == pytest.approx([4.9, 52.2])

    # Attraction: EXT_A -> zone centroid
    assert attr["properties"]["fromNode"]       == "EXT_A"
    assert attr["properties"]["toNode"]         == "50"
    assert attr["properties"]["reverseLinkIds"] == [1]
    assert attr["geometry"]["coordinates"][0]   == pytest.approx([4.9, 52.2])
    assert attr["geometry"]["coordinates"][1]   == pytest.approx([3.0, 51.0])


def test_build_aggregate_feedlinks_capacity_inherited_from_network():
    """Production capacity = zone production; attraction capacity = zone attraction."""
    net, inner_bbox = _simple_network_and_bbox()
    agg_zones = [{
        "gid": 77, "zoneId": "agg-77", "zoneType": "aggregate",
        "centroidLon": 3.0, "centroidLat": 51.0,
        "ringIndex": 0, "ringLabel": "r0", "sectorIndex": 0,
        "nodeId": "EXT_A",
        "production": 1500.0, "attraction": 1200.0,
    }]
    records, _ = _build_aggregate_feedlinks(agg_zones, net, inner_bbox, "CAR", fid_start=1)
    prod = next(r for r in records if r["properties"]["fromNode"] == "77")
    attr = next(r for r in records if r["properties"]["toNode"]   == "77")
    assert prod["properties"]["capacity"] == pytest.approx(1500.0)
    assert attr["properties"]["capacity"] == pytest.approx(1200.0)


def test_build_aggregate_feedlinks_flow_values():
    """Production feedlink carries zone production as capacity; attraction carries zone attraction."""
    net, inner_bbox = _simple_network_and_bbox()
    agg_zones = [{
        "gid": 77, "zoneId": "agg-77", "zoneType": "aggregate",
        "centroidLon": 3.0, "centroidLat": 51.0,
        "ringIndex": 0, "ringLabel": "r0", "sectorIndex": 0,
        "nodeId": "EXT_A",
        "production": 2500.0, "attraction": 1800.0,
    }]
    records, _ = _build_aggregate_feedlinks(agg_zones, net, inner_bbox, "CAR", fid_start=1)
    prod = next(r for r in records if r["properties"]["fromNode"] == "77")
    attr = next(r for r in records if r["properties"]["toNode"]   == "77")
    assert prod["properties"]["capacity"] == pytest.approx(2500.0)
    assert attr["properties"]["capacity"] == pytest.approx(1800.0)


def test_build_aggregate_feedlinks_pinned_node_missing_falls_back_to_gravity():
    """When nodeId is set but the node is not in the network, fall back to gravity model."""
    net, inner_bbox = _simple_network_and_bbox()
    agg_zones = [{
        "gid": 51, "zoneId": "agg-51", "zoneType": "aggregate",
        "centroidLon": 3.0, "centroidLat": 51.0,
        "ringIndex": 0, "ringLabel": "r0", "sectorIndex": 2,
        "nodeId": "NONEXISTENT_NODE",
    }]
    records, _ = _build_aggregate_feedlinks(agg_zones, net, inner_bbox, "CAR", fid_start=1)
    # Gravity model is used — none of the records should connect to the missing node
    for r in records:
        assert r["properties"]["fromNode"] != "NONEXISTENT_NODE"
        assert r["properties"]["toNode"]   != "NONEXISTENT_NODE"


def test_build_aggregate_feedlinks_gravity_path_has_empty_reverse_link_ids():
    """Gravity-model feedlinks have reverseLinkIds=[] as they may connect to different nodes."""
    net, inner_bbox = _simple_network_and_bbox()
    agg_zones = [{
        "gid": 52, "zoneId": "agg-52", "zoneType": "aggregate",
        "centroidLon": 3.0, "centroidLat": 51.0,
        "ringIndex": 0, "ringLabel": "r0", "sectorIndex": 0,
        # No nodeId → gravity model path
    }]
    records, _ = _build_aggregate_feedlinks(agg_zones, net, inner_bbox, "CAR", fid_start=1)
    for r in records:
        assert r["properties"]["reverseLinkIds"] == []


def test_build_inner_feedlinks_reverse_link_ids_cross_reference():
    """Production and attraction feedlinks reference each other via reverseLinkIds."""
    zone_by_gid = {
        7: {"zoneId": "inner-7", "centroidLon": 5.0, "centroidLat": 52.0, "gid": 7,
            "production": 300.0, "attraction": 250.0},
    }
    node_positions = {"N7": (5.1, 52.1)}
    vl_rows = [{
        "van_centroid_gid": 7,
        "naar_knoop_id":    "N7",
        "wkt_geom_4326":    None,
        "capaciteit_heen_pae_per_uur":  400.0,
        "capaciteit_terug_pae_per_uur": 400.0,
    }]
    records, _ = _build_inner_feedlinks(vl_rows, zone_by_gid, node_positions, {"N7"}, "CAR", 5)
    prod = records[0]
    attr = records[1]
    assert prod["properties"]["feedlinkId"]     == 5
    assert prod["properties"]["reverseLinkIds"] == [6]
    assert attr["properties"]["feedlinkId"]     == 6
    assert attr["properties"]["reverseLinkIds"] == [5]


def test_build_inner_feedlinks_min_capacity_applied():
    """min_capacity parameter was removed; capacity = zone production/attraction."""
    zone_by_gid = {
        10: {
            "zoneId": "inner-10", "centroidLon": 5.05, "centroidLat": 52.05, "gid": 10,
            "production": 100.0, "attraction": 0.0,
        },
    }
    node_positions = {"N1": (5.06, 52.06)}
    vl_rows = [{
        "van_centroid_gid": 10,
        "naar_knoop_id":    "N1",
        "wkt_geom_4326":    None,
        "link_type_heen":   "access",
        "link_type_terug":  "access",
        "capaciteit_heen_pae_per_uur":  100.0,
        "capaciteit_terug_pae_per_uur": 0.0,
    }]
    records, _ = _build_inner_feedlinks(
        vl_rows, zone_by_gid, node_positions, {"N1"}, "CAR", 1,
    )
    # attraction=0.0 → attraction feedlink is suppressed; only production is created
    assert len(records) == 1
    prod = records[0]
    assert prod["properties"]["capacity"] == pytest.approx(100.0)
    assert prod["properties"]["fromNode"] == "10"


def test_build_aggregate_feedlinks_min_capacity_applied():
    """min_capacity parameter was removed; capacity = zone production/attraction."""
    net, inner_bbox = _simple_network_and_bbox()
    agg_zones = [{
        "gid": 77, "zoneId": "agg-77", "zoneType": "aggregate",
        "centroidLon": 3.0, "centroidLat": 51.0,
        "ringIndex": 0, "ringLabel": "r0", "sectorIndex": 0,
        "nodeId": "EXT_A",
        "production": 1500.0, "attraction": 0.0,
    }]
    records, _ = _build_aggregate_feedlinks(
        agg_zones, net, inner_bbox, "CAR", fid_start=1,
    )
    # attraction=0.0 → attraction feedlink is suppressed; only production is created
    assert len(records) == 1
    prod = next(r for r in records if r["properties"]["fromNode"] == "77")
    assert prod["properties"]["capacity"] == pytest.approx(1500.0)


# ---------------------------------------------------------------------------
# derive_feedlinks (integration, no I/O)
# ---------------------------------------------------------------------------

def _make_simple_inputs():
    """Return (network, zones, vl_rows) for a small end-to-end test."""
    net_fc = _make_network_fc(
        {"from_node": "EXT_A", "to_node": "INT_A",
         "lon0": 4.9, "lat0": 52.2, "lon1": 5.1, "lat1": 52.2,
         "capacity": 1500.0, "speed": 80.0, "flow24": 800.0},
        {"from_node": "INT_B", "to_node": "EXT_B",
         "lon0": 5.4, "lat0": 52.3, "lon1": 5.6, "lat1": 52.3,
         "capacity": 1200.0, "speed": 70.0, "flow24": 600.0},
    )
    zone_fc = _make_zone_fc(
        {"gid": 1, "zone_id": "inner-1", "zoneType": "inner",
         "centroidLon": 5.2, "centroidLat": 52.2,
         "production": 500.0, "attraction": 400.0,
         "geometry": {"type": "Point", "coordinates": [5.2, 52.2]}},
        {"gid": 100, "zone_id": "agg-100", "zoneType": "aggregate",
         "centroidLon": 3.0, "centroidLat": 51.5,
         "ringIndex": 1, "ringLabel": "r1", "sectorIndex": 0,
         "production": 800.0, "attraction": 700.0,
         "geometry": {"type": "Point", "coordinates": [3.0, 51.5]}},
    )
    network = parse_network_geojson(net_fc)
    zones   = parse_zone_geojson(zone_fc)
    vl_rows = [{
        "van_centroid_gid": 1,
        "naar_knoop_id":    "EXT_A",
        "wkt_geom_4326":    None,
        "link_type_heen":   "access",
        "link_type_terug":  "access",
        "capaciteit_heen_pae_per_uur":  800.0,
        "capaciteit_terug_pae_per_uur": 800.0,
    }]
    return network, zones, vl_rows


def test_derive_feedlinks_returns_feature_collection():
    network, zones, vl_rows = _make_simple_inputs()
    result = derive_feedlinks(network, zones, vl_rows, "CAR")
    assert result["type"] == "FeatureCollection"
    assert isinstance(result["features"], list)


def test_derive_feedlinks_has_inner_and_aggregate():
    """Inner feedlinks have ringIndex==-1; aggregate feedlinks have ringIndex>=0."""
    network, zones, vl_rows = _make_simple_inputs()
    result = derive_feedlinks(network, zones, vl_rows, "CAR")
    ring_indices = {f["properties"]["ringIndex"] for f in result["features"]}
    assert -1 in ring_indices          # inner feedlinks
    assert any(r >= 0 for r in ring_indices)  # aggregate feedlinks


def test_derive_feedlinks_no_voedingslinks_rows():
    network, zones, _ = _make_simple_inputs()
    result = derive_feedlinks(network, zones, [], "CAR")
    # No inner feedlinks (ringIndex==-1), but aggregate ones should still be present
    inner_count = sum(
        1 for f in result["features"] if f["properties"]["ringIndex"] == -1
    )
    assert inner_count == 0


def test_derive_feedlinks_pedestrian_empty_rows():
    """PEDESTRIAN has no voedingslinks table — caller passes [] and core handles it."""
    network, zones, _ = _make_simple_inputs()
    result = derive_feedlinks(network, zones, [], "PEDESTRIAN")
    assert result["type"] == "FeatureCollection"


def test_derive_feedlinks_feedlink_ids_are_sequential():
    network, zones, vl_rows = _make_simple_inputs()
    result = derive_feedlinks(network, zones, vl_rows, "CAR")
    ids = [f["properties"]["feedlinkId"] for f in result["features"]]
    assert ids == list(range(1, len(ids) + 1))


def test_derive_feedlinks_all_features_have_required_properties():
    required = {
        "feedlinkId", "reverseLinkIds", "zoneId", "fromNode", "toNode", "length",
        "capacity", "mode", "ringIndex", "ringLabel", "sectorIndex", "type",
    }
    network, zones, vl_rows = _make_simple_inputs()
    result = derive_feedlinks(network, zones, vl_rows, "CAR")
    for feat in result["features"]:
        missing = required - feat["properties"].keys()
        assert not missing, f"Feature missing properties: {missing}"


def test_derive_feedlinks_inner_zone_produces_two_feedlinks():
    """Each inner zone (VL row) produces one production + one attraction feedlink."""
    network, zones, vl_rows = _make_simple_inputs()
    result = derive_feedlinks(network, zones, vl_rows, "CAR")
    inner = [f for f in result["features"] if f["properties"]["ringIndex"] == -1]
    # VL row for gid=1 -> zone node "1"; one production, one attraction
    prod = [f for f in inner if f["properties"]["fromNode"] == "1"]
    attr = [f for f in inner if f["properties"]["toNode"]   == "1"]
    assert len(prod) == 1
    assert len(attr) == 1


def test_derive_feedlinks_all_type_feedlink():
    network, zones, vl_rows = _make_simple_inputs()
    result = derive_feedlinks(network, zones, vl_rows, "CAR")
    for feat in result["features"]:
        assert feat["properties"]["type"] == "feedlink"


# ---------------------------------------------------------------------------
# derive_centroids
# ---------------------------------------------------------------------------

def _fl(zone_id: str, from_node: str, to_node: str, direction: str | None,
        coords: list | None = None) -> dict:
    """Build a minimal feedlink feature in the new schema.

    from_node: zone-centroid node for production, network node for attraction.
    to_node:   network node for production, zone-centroid node for attraction.
    """
    if coords is None:
        coords = [[5.0, 52.0], [5.1, 52.1]]
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "zoneId":        zone_id,
            "fromNode":      from_node,
            "toNode":        to_node,
            "linkDirection": direction,
        },
    }


def test_derive_centroids_basic():
    """One production feedlink per zone -> one centroid per zone, nodeId = fromNode."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _fl("z1", "Z_1", "NET_100", "production"),
            _fl("z2", "Z_2", "NET_200", "production"),
        ],
    }
    result = derive_centroids(fc)
    assert result["type"] == "FeatureCollection"
    assert len(result["features"]) == 2

    by_zone = {f["properties"]["zoneId"]: f for f in result["features"]}
    # nodeId = fromNode of production feedlink = zone centroid node
    assert by_zone["z1"]["properties"]["nodeId"] == "Z_1"
    assert by_zone["z2"]["properties"]["nodeId"] == "Z_2"


def test_derive_centroids_zone_index_sorted():
    """zoneIndex should be 1-based and assigned in sorted zoneId order."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _fl("zC", "ZC", "NC", "production"),
            _fl("zA", "ZA", "NA", "production"),
            _fl("zB", "ZB", "NB", "production"),
        ],
    }
    result = derive_centroids(fc)
    by_zone = {f["properties"]["zoneId"]: f["properties"]["zoneIndex"]
               for f in result["features"]}
    assert by_zone["zA"] == 1
    assert by_zone["zB"] == 2
    assert by_zone["zC"] == 3


def test_derive_centroids_production_preferred_over_attraction():
    """When a zone has both directions, the production fromNode is used as nodeId."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _fl("z1", "NET_ATTR", "Z_1",     "attraction"),
            _fl("z1", "Z_1",      "NET_PROD", "production"),
        ],
    }
    result = derive_centroids(fc)
    assert len(result["features"]) == 1
    assert result["features"][0]["properties"]["nodeId"] == "Z_1"


def test_derive_centroids_fallback_to_attraction():
    """When no production feedlink exists, attraction toNode (zone centroid) is used."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _fl("z1", "NET_ATTR", "Z_1", "attraction"),
        ],
    }
    result = derive_centroids(fc)
    assert result["features"][0]["properties"]["nodeId"] == "Z_1"


def test_derive_centroids_fallback_to_none_direction():
    """linkDirection=None feedlinks are also accepted as fallback; fromNode used."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _fl("z1", "Z_NODE", "NET_NODE", None),
        ],
    }
    result = derive_centroids(fc)
    assert result["features"][0]["properties"]["nodeId"] == "Z_NODE"


def test_derive_centroids_point_geometry():
    """Feedlinks with Point geometry are handled gracefully."""
    feat = {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [6.0, 52.5]},
        "properties": {
            "zoneId":        "z1",
            "fromNode":      "Z_1",
            "toNode":        "NET_99",
            "linkDirection": "production",
        },
    }
    result = derive_centroids({"type": "FeatureCollection", "features": [feat]})
    assert result["features"][0]["geometry"]["coordinates"] == [6.0, 52.5]


def test_derive_centroids_linestring_uses_first_coord():
    """For a LineString feedlink the zone-side endpoint (coords[0]) is used."""
    coords = [[1.0, 2.0], [3.0, 4.0]]
    fc = {"type": "FeatureCollection",
          "features": [_fl("z1", "Z_1", "42", "production", coords)]}
    result = derive_centroids(fc)
    assert result["features"][0]["geometry"]["coordinates"] == [1.0, 2.0]


def test_derive_centroids_deduplicates_zones():
    """Multiple feedlinks for the same zone (prod + attr) produce one centroid."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _fl("z1", "Z_1", "N1", "production"),
            _fl("z1", "N2",  "Z_1", "attraction"),
            _fl("z1", "Z_1", "N3", "production"),   # second production — ignored
        ],
    }
    result = derive_centroids(fc)
    assert len(result["features"]) == 1
    assert result["features"][0]["properties"]["nodeId"] == "Z_1"


def test_derive_centroids_skips_missing_zone_or_node():
    """Features without zoneId or fromNode/toNode are silently skipped."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _fl("",   "Z_X",  "NET_X",   "production"),   # empty zoneId
            _fl("z1", "",     "NET_Z1",  "production"),   # empty fromNode
            _fl("z2", "Z_2",  "NET_Z2",  "production"),   # valid
        ],
    }
    result = derive_centroids(fc)
    assert len(result["features"]) == 1
    assert result["features"][0]["properties"]["zoneId"] == "z2"


def test_derive_centroids_empty_input():
    """Empty feedlinks FeatureCollection produces empty centroids."""
    result = derive_centroids({"type": "FeatureCollection", "features": []})
    assert result["features"] == []


def test_derive_centroids_feature_id_equals_zone_id():
    """Each centroid feature's top-level id should equal its zoneId."""
    fc = {"type": "FeatureCollection",
          "features": [_fl("myZone", "Z_MY", "7", "production")]}
    result = derive_centroids(fc)
    assert result["features"][0]["id"] == "myZone"
