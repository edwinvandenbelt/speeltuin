"""Gap detector core — pure Python, no I/O, no boto3.

Detects physical gaps between network segments and can repair them by inserting
bridging links.

A *gap* exists when:
  1. The ``toNode`` of link A has undirected degree 1 (dangling tail).
  2. The ``fromNode`` of link B has undirected degree 1 (dangling head).
  3. The tail coordinate and head coordinate are within ``max_distance_m`` metres.
  4. The heading at the end of A and the heading at the start of B differ by at
     most ``max_angle_deg`` degrees.
  5. There is no directed edge between the two nodes in either direction.

Public API
----------
detect_gaps, detect_network_gaps, repair_network_gaps
"""

from __future__ import annotations

import math

__all__ = ["detect_gaps", "detect_network_gaps", "gaps_to_changes", "repair_network_gaps"]

# ---------------------------------------------------------------------------
# Output field definitions (authoritative)
# ---------------------------------------------------------------------------

#: Properties on every feature in the gaps FeatureCollection.
GAP_PROPERTIES: tuple[str, ...] = (
    "fromNode",
    "toNode",
    "fromLinkId",
    "toLinkId",
    "distance_m",
    "angleDiff_deg",
    "streetName",
    "crossesExistingLink",
)

#: Properties on every feature in the bridging-links FeatureCollection.
BRIDGE_LINK_PROPERTIES: tuple[str, ...] = (
    "linkId",
    "mode",
    "fromNode",
    "toNode",
    "length",
    "streetName",
)

# Flat-earth constants calibrated around the Netherlands (lat ≈ 52°N).
_M_PER_DEG_LAT: float = 111_320.0
_M_PER_DEG_LON: float = 111_320.0 * math.cos(math.radians(52.0))

# Default flow dicts for synthesised bridging links.
_ZERO_MOTIVES: dict[str, float] = {
    "work": 0.0, "recreational": 0.0, "education": 0.0, "shopping": 0.0, "unknown": 0.0,
}
_ZERO_DAYPARTS: dict[str, float] = {"mrh": 0.0, "erh": 0.0, "rest": 0.0}


def _distance_m(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """Flat-earth distance in metres between two WGS-84 points."""
    dx = (lon2 - lon1) * _M_PER_DEG_LON
    dy = (lat2 - lat1) * _M_PER_DEG_LAT
    return math.hypot(dx, dy)


def _heading_deg(coords: list, *, at_start: bool) -> float | None:
    """Compass heading (0 = N, 90 = E) at the start or end of a coordinate sequence."""
    if len(coords) < 2:
        return None
    p0, p1 = (coords[0], coords[1]) if at_start else (coords[-2], coords[-1])
    dx = (p1[0] - p0[0]) * _M_PER_DEG_LON
    dy = (p1[1] - p0[1]) * _M_PER_DEG_LAT
    if abs(dx) < 1e-9 and abs(dy) < 1e-9:
        return None
    return math.degrees(math.atan2(dx, dy)) % 360.0


def _angle_diff(a: float, b: float) -> float:
    """Smallest angular difference between two headings (0–180°)."""
    diff = abs(a - b) % 360.0
    return diff if diff <= 180.0 else 360.0 - diff


def _node_degrees(features: list[dict]) -> dict[int, int]:
    """Return undirected degree count per node (each link contributes 1 to each endpoint)."""
    degrees: dict[int, int] = {}
    for feat in features:
        props = feat.get("properties") or {}
        try:
            fn = int(props.get("fromNode"))  # type: ignore[arg-type]
            tn = int(props.get("toNode"))    # type: ignore[arg-type]
        except (ValueError, TypeError):
            continue
        if fn == 0 and tn == 0:
            continue
        degrees[fn] = degrees.get(fn, 0) + 1
        degrees[tn] = degrees.get(tn, 0) + 1
    return degrees


def _find_components(nodes: set[int], edges: list[tuple[int, int]]) -> list[set[int]]:
    """Return the connected components of an undirected graph as a list of node sets."""
    adj: dict[int, list[int]] = {}
    for a, b in edges:
        adj.setdefault(a, []).append(b)
        adj.setdefault(b, []).append(a)

    remaining = set(nodes)
    components: list[set[int]] = []
    while remaining:
        start = next(iter(remaining))
        component: set[int] = set()
        queue = [start]
        while queue:
            node = queue.pop()
            if node in component:
                continue
            component.add(node)
            remaining.discard(node)
            for neighbour in adj.get(node, []):
                if neighbour not in component:
                    queue.append(neighbour)
        components.append(component)
    return components


def _build_adjacency(features: list[dict]) -> dict[int, list[int]]:
    """Build a directed adjacency map ``{from_node: [to_node, ...]}``.

    For bidirectional NETWORK-SIMPLE features the ``rijrichting_terug`` flag is
    respected: when it is truthy a reverse edge (toNode → fromNode) is also added.
    """
    adj: dict[int, list[int]] = {}
    for feat in features:
        props = feat.get("properties") or {}
        try:
            fn = int(props.get("fromNode"))  # type: ignore[arg-type]
            tn = int(props.get("toNode"))    # type: ignore[arg-type]
        except (ValueError, TypeError):
            continue
        if fn == 0 and tn == 0:
            continue
        adj.setdefault(fn, []).append(tn)
        if props.get("rijrichting_terug"):
            adj.setdefault(tn, []).append(fn)  # type: ignore[arg-type]
    return adj


def _ccw(ax: float, ay: float, bx: float, by: float, cx: float, cy: float) -> bool:
    return (cy - ay) * (bx - ax) > (by - ay) * (cx - ax)


def _segments_cross(
    p1: tuple[float, float],
    p2: tuple[float, float],
    q1: tuple[float, float],
    q2: tuple[float, float],
) -> bool:
    """Return True iff line segments p1-p2 and q1-q2 *properly* cross.

    Endpoint-touching (T-intersections or shared endpoints) is NOT counted as
    a crossing so that a bridge that merely meets an existing node does not
    trigger the check.
    """
    return (
        _ccw(p1[0], p1[1], q1[0], q1[1], q2[0], q2[1])
        != _ccw(p2[0], p2[1], q1[0], q1[1], q2[0], q2[1])
        and _ccw(p1[0], p1[1], p2[0], p2[1], q1[0], q1[1])
        != _ccw(p1[0], p1[1], p2[0], p2[1], q2[0], q2[1])
    )


def _bridge_crosses_network(
    tail_coord: list[float],
    head_coord: list[float],
    features: list[dict],
) -> bool:
    """Return True if the bridge segment tail→head properly crosses any existing link."""
    t = (tail_coord[0], tail_coord[1])
    h = (head_coord[0], head_coord[1])
    for feat in features:
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        for i in range(len(coords) - 1):
            c1 = (float(coords[i][0]), float(coords[i][1]))
            c2 = (float(coords[i + 1][0]), float(coords[i + 1][1]))
            if _segments_cross(t, h, c1, c2):
                return True
    return False


def detect_gaps(
    features: list[dict],
    *,
    max_distance_m: float = 50.0,
    max_angle_deg: float = 30.0,
) -> list[dict]:
    """Detect physical gaps using a dangling-node + proximity + heading strategy.

    A gap is reported for each pair (A, B) where the *toNode* of A and the
    *fromNode* of B are both dangling (undirected degree == 1), are within
    ``max_distance_m`` metres of each other, have headings differing by at most
    ``max_angle_deg`` degrees, and are not already connected in either direction.

    Parameters
    ----------
    features:
        Network link features in NETWORK-SIMPLE bidirectional format.
    max_distance_m:
        Maximum gap width in metres to report (default 50 m).
    max_angle_deg:
        Maximum heading difference in degrees to consider as a gap (default 30°).

    Returns
    -------
    list[dict]
        GeoJSON Feature dicts (LineString from tail to head).  Properties:
        ``fromNode``, ``toNode``, ``fromLinkId``, ``toLinkId``, ``distance_m``,
        ``angleDiff_deg``, ``streetName`` (may be ``None``).
    """
    degrees = _node_degrees(features)

    # Build directed adjacency for the connectivity check.
    adj = _build_adjacency(features)
    connected: set[tuple[int, int]] = {
        (fn, tn) for fn, neighbours in adj.items() for tn in neighbours
    }

    # Collect dangling tails (toNode with degree 1) and dangling heads (fromNode with degree 1).
    # Each entry: (node_id, coord, heading, link_id, feature)
    tails: list[tuple[int, list[float], float | None, object, dict]] = []
    heads: list[tuple[int, list[float], float | None, object, dict]] = []

    for feat in features:
        props = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        try:
            fn = int(props.get("fromNode"))  # type: ignore[arg-type]
            tn = int(props.get("toNode"))    # type: ignore[arg-type]
        except (ValueError, TypeError):
            continue
        if fn == 0 and tn == 0:
            continue

        link_id = props.get("linkId", 0)

        if degrees.get(tn, 0) == 1:
            tails.append((tn, list(coords[-1]), _heading_deg(coords, at_start=False), link_id, feat))

        if degrees.get(fn, 0) == 1:
            heads.append((fn, list(coords[0]), _heading_deg(coords, at_start=True), link_id, feat))

    gaps: list[dict] = []
    seen: set[frozenset] = set()

    for (tail_node, tail_coord, tail_heading, tail_lid, tail_feat) in tails:
        for (head_node, head_coord, head_heading, head_lid, head_feat) in heads:
            if tail_node == head_node:
                continue

            pair: frozenset = frozenset({tail_node, head_node})
            if pair in seen:
                continue

            dist = _distance_m(tail_coord[0], tail_coord[1], head_coord[0], head_coord[1])
            if dist > max_distance_m:
                continue

            if (tail_node, head_node) in connected or (head_node, tail_node) in connected:
                continue

            # Angle check — skip only when both headings are defined and differ too much.
            angle_diff = 0.0
            if tail_heading is not None and head_heading is not None:
                angle_diff = _angle_diff(tail_heading, head_heading)
                if angle_diff > max_angle_deg:
                    continue

            seen.add(pair)
            street_name = (
                (tail_feat.get("properties") or {}).get("streetName")
                or (head_feat.get("properties") or {}).get("streetName")
            )
            gaps.append({
                "type": "Feature",
                "geometry": {
                    "type": "LineString",
                    "coordinates": [tail_coord, head_coord],
                },
                "properties": {
                    "fromNode":           tail_node,
                    "toNode":             head_node,
                    "fromLinkId":         tail_lid,
                    "toLinkId":           head_lid,
                    "distance_m":         round(dist, 2),
                    "angleDiff_deg":      round(angle_diff, 2),
                    "streetName":         street_name,
                    "crossesExistingLink": _bridge_crosses_network(
                        tail_coord, head_coord, features
                    ),
                },
            })

    return gaps


def detect_network_gaps(fc: dict) -> dict:
    """Detect gaps in a network FeatureCollection and return a GeoJSON FeatureCollection.

    Parameters
    ----------
    fc:
        GeoJSON FeatureCollection with network links.

    Returns
    -------
    dict
        GeoJSON FeatureCollection where each Feature is a LineString gap,
        with a ``properties`` block containing ``totalLinks`` and ``totalGaps``.
    """
    features: list[dict] = fc.get("features") or []
    gap_features = detect_gaps(features)
    return {
        "type": "FeatureCollection",
        "features": gap_features,
        "properties": {
            "totalLinks": len(features),
            "totalGaps":  len(gap_features),
            "fields": list(GAP_PROPERTIES),
        },
    }


def gaps_to_changes(gap_features: list[dict], network_features: list[dict]) -> list[dict]:
    """Convert gap GeoJSON features to link-inserter change objects.

    Each returned object can be fed directly to
    ``network_link_inserter.core.insert_links`` (after the user has reviewed
    and pruned the list).  The link-inserter reads ``linkId``, ``geometry``,
    ``speed``, ``capacity``, ``lanes``, and ``direction``; all other fields are
    carried through for human review and are silently ignored by the inserter.

    Road properties (speed, capacity, lanes) are inherited from the network
    feature whose ``toNode`` matches the gap's ``fromNode`` (i.e. the feature
    whose dangling tail is the bridge start).

    Parameters
    ----------
    gap_features:
        List of gap GeoJSON Features as returned by :func:`detect_gaps`.
    network_features:
        Original network features used to look up road properties.

    Returns
    -------
    list[dict]
        List of change objects ready for link-inserter consumption.
    """
    # Build toNode → feature lookup for property inheritance.
    feat_by_to_node: dict[int, dict] = {}
    for feat in network_features:
        props = feat.get("properties") or {}
        try:
            tn = int(props.get("toNode"))  # type: ignore[arg-type]
        except (ValueError, TypeError):
            continue
        feat_by_to_node.setdefault(tn, feat)

    changes: list[dict] = []
    for gap in gap_features:
        gp = gap.get("properties") or {}
        from_node = gp.get("fromNode")  # = toNode of the tail feature
        to_node   = gp.get("toNode")

        src = feat_by_to_node.get(from_node, {})
        sp = src.get("properties") or {}

        speed    = sp.get("max_snelheid_heen") or sp.get("speed") or 50
        capacity = sp.get("cap_heen") or sp.get("capacity") or 800
        lanes    = sp.get("rijstroken_heen") or sp.get("lanes") or 1

        changes.append({
            "linkId":             None,
            "geometry":           gap.get("geometry"),
            "speed":              speed,
            "capacity":           capacity,
            "lanes":              lanes,
            "direction":          "both",
            # --- review metadata (ignored by link-inserter) ---
            "fromNode":           from_node,
            "toNode":             to_node,
            "distance_m":         gp.get("distance_m"),
            "angleDiff_deg":      gp.get("angleDiff_deg"),
            "streetName":         gp.get("streetName"),
            "crossesExistingLink": gp.get("crossesExistingLink", False),
        })

    return changes


def _make_bridge_link(
    feat_a: dict,
    feat_b: dict,
    tail_coord: list,
    head_coord: list,
    new_link_id: int,
    dist_m: float,
) -> dict:
    """Create a bridging link in NETWORK-SIMPLE bidirectional format.

    Parameters
    ----------
    feat_a:
        A feature whose node is at *tail_coord* (the fromNode side of the bridge).
    feat_b:
        A feature whose node is at *head_coord* (the toNode side of the bridge).
    tail_coord:
        ``[lon, lat]`` of the bridge start.
    head_coord:
        ``[lon, lat]`` of the bridge end.
    new_link_id:
        Integer ID to assign to the new link.
    dist_m:
        Physical gap distance in metres (becomes the bridge ``length``).
    """
    pa = feat_a.get("properties") or {}
    pb = feat_b.get("properties") or {}

    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [tail_coord, head_coord]},
        "properties": {
            "linkId":             new_link_id,
            "mode":               pa.get("mode") or pb.get("mode") or "CAR",
            "fromNode":           int(pa.get("fromNode") or pa.get("toNode") or 0),
            "toNode":             int(pb.get("fromNode") or pb.get("toNode") or 0),
            # heen direction
            "rijrichting_heen":   True,
            "cap_heen":           pa.get("cap_heen") or pa.get("capacity") or 0,
            "rijstroken_heen":    pa.get("rijstroken_heen") or pa.get("lanes") or 1,
            "max_snelheid_heen":  pa.get("max_snelheid_heen") or pa.get("speed") or 0,
            "flow_heen":          dict(_ZERO_MOTIVES),
            "flow_dp_heen":       dict(_ZERO_DAYPARTS),
            # terug direction
            "rijrichting_terug":  True,
            "cap_terug":          pb.get("cap_heen") or pb.get("capacity") or 0,
            "rijstroken_terug":   pb.get("rijstroken_heen") or pb.get("lanes") or 1,
            "max_snelheid_terug": pb.get("max_snelheid_heen") or pb.get("speed") or 0,
            "flow_terug":         dict(_ZERO_MOTIVES),
            "flow_dp_terug":      dict(_ZERO_DAYPARTS),
            "length":             round(dist_m, 2),
            "streetName":         pa.get("streetName") or pb.get("streetName"),
        },
    }


def repair_network_gaps(
    fc: dict,
    *,
    max_distance_m: float = 50.0,
    max_angle_deg: float = 30.0,
) -> tuple[dict, dict]:
    """Detect gaps and repair them by inserting bridging links.

    For each detected gap a new bidirectional bridging link is inserted into the
    network, connecting the dangling tail of one segment to the dangling head of
    another.  Gaps wider than *max_distance_m* or with heading differences above
    *max_angle_deg* are not bridged.  The bridge inherits capacity/lanes/speed
    from the adjacent source links and carries zero flow.

    New link IDs are assigned as consecutive integers starting just above the
    highest existing numeric ``linkId`` in the collection.

    Parameters
    ----------
    fc:
        GeoJSON FeatureCollection with NETWORK-SIMPLE bidirectional links.
    max_distance_m:
        Maximum gap width (metres) to repair (default 50 m).
    max_angle_deg:
        Maximum heading difference (degrees) to repair (default 30°).

    Returns
    -------
    tuple[dict, dict]
        ``(repaired_fc, added_links_fc)`` where *repaired_fc* is the input
        FeatureCollection with bridge links appended, and *added_links_fc* is a
        GeoJSON FeatureCollection containing only the newly added bridge links.
    """
    features: list[dict] = list(fc.get("features") or [])

    gaps = detect_gaps(features, max_distance_m=max_distance_m, max_angle_deg=max_angle_deg)

    # Index features by node ID so we can find neighbours for bridge construction.
    feats_by_node: dict[int, list[dict]] = {}
    for feat in features:
        props = feat.get("properties") or {}
        try:
            fn = int(props.get("fromNode"))  # type: ignore[arg-type]
            tn = int(props.get("toNode"))    # type: ignore[arg-type]
        except (ValueError, TypeError):
            continue
        feats_by_node.setdefault(fn, []).append(feat)
        feats_by_node.setdefault(tn, []).append(feat)

    # Determine the starting ID for new bridge links.
    max_id = 0
    for feat in features:
        lid = (feat.get("properties") or {}).get("linkId")
        try:
            max_id = max(max_id, int(lid))  # type: ignore[arg-type]
        except (ValueError, TypeError):
            pass
    new_id = max_id + 1

    bridge_features: list[dict] = []
    for gap in gaps:
        gp = gap["properties"]
        from_node = int(gp["fromNode"])
        to_node   = int(gp["toNode"])
        dist_m    = float(gp["distance_m"])

        # Skip gaps whose bridge would cross an existing link.
        if gp.get("crossesExistingLink"):
            continue

        # Pick representative source features for inheriting road properties.
        feats_a = feats_by_node.get(from_node, [])
        feats_b = feats_by_node.get(to_node, [])
        feat_a = feats_a[0] if feats_a else {}
        feat_b = feats_b[0] if feats_b else {}

        tail_coord = gap["geometry"]["coordinates"][0]
        head_coord = gap["geometry"]["coordinates"][1]

        bridge = _make_bridge_link(feat_a, feat_b, tail_coord, head_coord, new_id, dist_m)
        # Override fromNode/toNode with the exact gap node IDs.
        bridge["properties"]["fromNode"] = from_node
        bridge["properties"]["toNode"]   = to_node

        bridge_features.append(bridge)
        features.append(bridge)
        new_id += 1

    repaired_fc = {**fc, "features": features}
    added_links_fc = {
        "type": "FeatureCollection",
        "features": bridge_features,
        "properties": {
            "totalAdded": len(bridge_features),
            "fields": list(BRIDGE_LINK_PROPERTIES),
        },
    }
    return repaired_fc, added_links_fc
