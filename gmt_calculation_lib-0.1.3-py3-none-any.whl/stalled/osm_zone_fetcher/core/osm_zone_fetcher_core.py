"""Pure-Python OSM zone fetcher core — no I/O beyond Overpass HTTP.

Fetches administrative boundaries from the Overpass API for a bounding box
and produces a zone GeoJSON FeatureCollection compatible with zone_intersector.

Public API
----------
derive_osm_zones(bbox, *, admin_level, min_zones, estimate_cbs,
                 overpass_url, timeout) -> dict
    Fetch OSM admin boundaries and produce a zone FeatureCollection.
    When *estimate_cbs* is True (default), a second Overpass query fetches
    all buildings in the bbox and estimates CBS demographic values per zone.
relations_to_zone_features(elements, admin_level, bbox) -> list[dict]
    Convert Overpass elements to zone features for a known admin_level.
detect_finest_admin_level(elements, min_zones) -> int
    Auto-detect the finest admin_level with enough zones.
ZONE_PROPERTIES: tuple[str, ...]
    Ordered property keys for every zone feature.
"""

from __future__ import annotations

import datetime
import logging

from osm_zone_fetcher.domain.admin_level import (  # noqa: F401
    count_zones_by_level,
    detect_finest_admin_level,
)
from osm_zone_fetcher.domain.cbs_estimator import enrich_zones_with_cbs  # noqa: F401
from osm_zone_fetcher.domain.overpass import (  # noqa: F401
    build_buildings_query,
    build_zone_query,
)
from osm_zone_fetcher.domain.zone import (  # noqa: F401
    ZONE_PROPERTIES,
    _CBS_COLS,
    relation_to_feature,
    relations_to_zone_features,
)
from shared.overpass import DEFAULT_OVERPASS_URL, fetch_overpass, fetch_overpass_tiled  # noqa: F401

logger = logging.getLogger(__name__)


def derive_osm_zones(
    bbox: list[float],
    *,
    admin_level: int | None = None,
    min_zones: int = 5,
    estimate_cbs: bool = True,
    tiles: tuple[int, int] = (1, 1),
    overpass_url: str = DEFAULT_OVERPASS_URL,
    timeout: int = 90,
) -> dict:
    """Fetch OSM administrative boundaries and produce a zone FeatureCollection.

    The output schema is compatible with ``zone_intersector`` inner-zone input.
    When *estimate_cbs* is ``True`` (the default), a second Overpass query
    fetches all building footprints in the bbox and estimates CBS demographic
    values (``inwoners``, ``huishoudens``, ``arbeidsplaatsen_*``,
    ``leerlingplaatsen_*``) for each zone based on building type, footprint
    area, and height/levels.  CBS columns that cannot be derived from buildings
    remain ``None``.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS 84.
    admin_level:
        Specific OSM ``admin_level`` to use, or ``None`` to auto-detect
        the finest level with >= *min_zones* zones.
    min_zones:
        Minimum zone count required for auto-detection level selection.
    estimate_cbs:
        When ``True`` (default), fetch buildings and estimate CBS values.
        Set to ``False`` to skip the building query (all CBS columns stay
        ``None``).
    tiles:
        ``(nx, ny)`` tile grid for splitting the Overpass query into smaller
        sub-requests.  ``(1, 1)`` (default) sends a single request.  Use
        e.g. ``(2, 2)`` for a 2 × 2 grid of 4 tiles when the bbox is large
        or the server returns 504 errors.
    overpass_url:
        Overpass API endpoint URL.
    timeout:
        HTTP request timeout in seconds.

    Returns
    -------
    GeoJSON FeatureCollection dict.  The ``"properties"`` dict includes:
    - ``"zone_properties"``:  list of ZONE_PROPERTIES keys
    - ``"origin"``:           ``"osm"``
    - ``"admin_level"``:      the detected or provided admin_level
    - ``"bbox"``:             the input bbox
    - ``"nZones"``:           number of zone features
    - ``"cbsEstimated"``:     ``True`` when CBS values were estimated
    - ``"tiles"``:            tile grid used, e.g. ``[2, 2]``
    - ``"created"``:          ISO-8601 UTC timestamp

    Raises
    ------
    urllib.error.URLError / RuntimeError:
        On Overpass API errors.
    """
    logger.info(
        "Fetching OSM zones  bbox=%s  admin_level=%s  tiles=%s",
        bbox,
        admin_level,
        tiles,
    )
    data = fetch_overpass_tiled(
        lambda b: build_zone_query(b, admin_level, timeout=timeout),
        bbox,
        tiles=tiles,
        url=overpass_url,
        timeout=timeout,
    )
    elements: list[dict] = data.get("elements") or []
    logger.info("Overpass returned %d elements", len(elements))

    if admin_level is None:
        admin_level = detect_finest_admin_level(elements, min_zones=min_zones)
        logger.info("Auto-detected admin_level=%d", admin_level)

    features = relations_to_zone_features(elements, admin_level, bbox)

    cbs_estimated = False
    n_buildings = 0
    cbs_error: str | None = None

    if estimate_cbs and features:
        import urllib.error  # noqa: PLC0415

        logger.info("Fetching buildings for CBS estimation  bbox=%s  tiles=%s", bbox, tiles)
        try:
            bdata = fetch_overpass_tiled(
                lambda b: build_buildings_query(b, timeout=timeout),
                bbox,
                tiles=tiles,
                url=overpass_url,
                timeout=timeout,
            )
            buildings: list[dict] = bdata.get("elements") or []
            n_buildings = len(buildings)
            logger.info("Overpass returned %d building elements", n_buildings)
            if buildings:
                enrich_zones_with_cbs(features, buildings)
                cbs_estimated = True
                n_enriched = sum(
                    1 for f in features if (f.get("properties") or {}).get("inwoners") is not None
                )
                logger.info(
                    "CBS estimation complete: %d/%d zones enriched",
                    n_enriched,
                    len(features),
                )
        except (urllib.error.HTTPError, urllib.error.URLError, RuntimeError, OSError) as exc:
            cbs_error = str(exc)
            logger.warning(
                "Buildings query failed (%s) — CBS columns will be None. "
                "Use --no-cbs to suppress this warning.",
                exc,
            )

    return {
        "type": "FeatureCollection",
        "crs": {
            "type": "name",
            "properties": {"name": "EPSG:4326"},
        },
        "features": features,
        "properties": {
            "zone_properties": list(ZONE_PROPERTIES),
            "origin": "osm",
            "admin_level": admin_level,
            "bbox": bbox,
            "nZones": len(features),
            "cbsEstimated": cbs_estimated,
            "nBuildings": n_buildings,
            "cbsError": cbs_error,
            "tiles": list(tiles),
            "created": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        },
    }
