"""Polygon reconstruction from OSM relation member ways.

OSM administrative boundaries are stored as relations with ``outer`` and
optionally ``inner`` member ways.  These ways must be stitched together
to form closed polygon rings.

Public API
----------
calc_centroid(coords) -> tuple[float, float]
    Arithmetic-mean centroid of a coordinate ring.
assemble_polygon(members) -> list[list] | None
    Build GeoJSON-style coordinate rings from an Overpass relation's member list.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

Coord = tuple[float, float]  # (lon, lat)
Ring = list[Coord]


# ---------------------------------------------------------------------------
# Centroid
# ---------------------------------------------------------------------------


def calc_centroid(coords: Ring) -> tuple[float, float]:
    """Return the (lon, lat) centroid of a polygon ring using the arithmetic mean.

    The closing vertex (equal to the first) is excluded from the calculation.
    """
    if not coords:
        return 0.0, 0.0
    # Exclude closing vertex if present
    pts = coords[:-1] if len(coords) > 1 and coords[0] == coords[-1] else list(coords)
    if not pts:
        return 0.0, 0.0
    lon = sum(c[0] for c in pts) / len(pts)
    lat = sum(c[1] for c in pts) / len(pts)
    return round(lon, 7), round(lat, 7)


# ---------------------------------------------------------------------------
# Segment chaining ("chain merging")
# ---------------------------------------------------------------------------

_COORD_TOL = 1e-7  # ≈ 1 cm at equator


def _coords_close(a: Coord, b: Coord) -> bool:
    """Return True when two coordinates are within tolerance."""
    return abs(a[0] - b[0]) < _COORD_TOL and abs(a[1] - b[1]) < _COORD_TOL


def _chain_segments(segments: list[Ring]) -> Ring:
    """Chain unordered coordinate segments into a single closed ring.

    Parameters
    ----------
    segments:
        Each segment is a list of (lon, lat) coordinates representing one OSM way.
        Segments may be in any order and any direction.

    Returns
    -------
    Assembled ring (list of (lon, lat) tuples), closed (first == last).
    Returns an empty list if *segments* is empty.
    """
    if not segments:
        return []
    if len(segments) == 1:
        ring = list(segments[0])
        if ring and ring[0] != ring[-1]:
            ring.append(ring[0])
        return ring

    remaining: list[Ring] = [list(s) for s in segments]
    chain: Ring = remaining.pop(0)

    # Safety limit: at most 2 passes over all remaining segments
    max_iters = len(remaining) * 2 + 1
    iters = 0
    while remaining and iters < max_iters:
        iters += 1
        end = chain[-1]
        matched = False
        for i, seg in enumerate(remaining):
            if not seg:
                remaining.pop(i)
                matched = True
                break
            if _coords_close(seg[0], end):
                chain.extend(seg[1:])
                remaining.pop(i)
                matched = True
                break
            if _coords_close(seg[-1], end):
                chain.extend(reversed(seg[:-1]))
                remaining.pop(i)
                matched = True
                break
        if not matched:
            # Gap in topology — append next segment directly
            logger.debug("Topology gap in ring — appending next segment")
            chain.extend(remaining.pop(0))

    # Close the ring
    if chain and not _coords_close(chain[0], chain[-1]):
        chain.append(chain[0])

    return chain


# ---------------------------------------------------------------------------
# Polygon assembly
# ---------------------------------------------------------------------------


def assemble_polygon(members: list[dict]) -> list[Ring] | None:
    """Build GeoJSON-style coordinate rings from an Overpass relation's member list.

    The first ring is the outer boundary; subsequent rings are holes (inner boundaries).
    Coordinates are ``(lon, lat)`` tuples matching GeoJSON convention.

    Parameters
    ----------
    members:
        Member list from an Overpass relation element (``relation["members"]``).
        Each member dict has ``type``, ``role``, and ``geometry``
        (list of ``{lat, lon}`` dicts, populated by ``out geom``).

    Returns
    -------
    List of rings ``[[ring_outer], [ring_inner], ...]``, or ``None`` if no
    valid outer ring could be assembled (< 4 coordinate pairs).
    """
    outer_segs: list[Ring] = []
    inner_segs: list[Ring] = []

    for member in members:
        if member.get("type") != "way":
            continue
        raw_geom = member.get("geometry") or []
        if len(raw_geom) < 2:  # noqa: PLR2004
            continue
        coords: Ring = [(g["lon"], g["lat"]) for g in raw_geom]
        role = (member.get("role") or "outer").lower()
        if role == "inner":
            inner_segs.append(coords)
        else:
            outer_segs.append(coords)

    if not outer_segs:
        return None

    outer_ring = _chain_segments(outer_segs)
    if len(outer_ring) < 4:  # noqa: PLR2004
        return None

    rings: list[Ring] = [outer_ring]
    if inner_segs:
        inner_ring = _chain_segments(inner_segs)
        if len(inner_ring) >= 4:  # noqa: PLR2004
            rings.append(inner_ring)

    return rings
