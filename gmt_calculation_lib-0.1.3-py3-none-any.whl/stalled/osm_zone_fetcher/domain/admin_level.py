"""Admin-level auto-detection for osm_zone_fetcher.

OSM ``admin_level`` values differ per country and region.  This module
detects the finest (highest-numbered) admin_level that yields at least
*min_zones* zones within the queried bounding box.

Public API
----------
count_zones_by_level(elements) -> dict[int, int]
    Count relation elements grouped by their ``admin_level`` tag.
detect_finest_admin_level(elements, min_zones) -> int
    Auto-detect the finest admin_level with enough zones.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

# Admin levels to consider for auto-detection (inclusive range)
_MIN_LEVEL = 7
_MAX_LEVEL = 12


def count_zones_by_level(elements: list[dict]) -> dict[int, int]:
    """Count OSM relation elements by ``admin_level`` tag.

    Non-relation elements and relations without a valid integer
    ``admin_level`` tag are silently ignored.

    Parameters
    ----------
    elements:
        Overpass API response elements.

    Returns
    -------
    Mapping ``{admin_level: count}``.
    """
    counts: dict[int, int] = {}
    for el in elements:
        if el.get("type") != "relation":
            continue
        tags = el.get("tags") or {}
        raw = tags.get("admin_level", "")
        try:
            level = int(raw)
        except ValueError, TypeError:
            continue
        counts[level] = counts.get(level, 0) + 1
    return counts


def detect_finest_admin_level(
    elements: list[dict],
    min_zones: int = 5,
) -> int:
    """Return the finest admin_level in the range 7–12 with >= *min_zones* zones.

    Strategy
    --------
    1. Count zones per level for levels 7–12.
    2. Select the highest level (finest granularity) with ``count >= min_zones``.
    3. If no level qualifies, select the level with the most zones.
    4. Fall back to level 8 when no relations are found at all.
    5. Warn when the selected level < 8 (possibly too coarse).

    Parameters
    ----------
    elements:
        Overpass API response elements.
    min_zones:
        Minimum zone count required for a level to be considered.

    Returns
    -------
    Selected admin_level integer.
    """
    counts = count_zones_by_level(elements)
    if not counts:
        logger.warning("No relations with admin_level found; defaulting to level 8")
        return 8

    # Filter to the supported level range and sort finest-first (descending)
    candidates = sorted(
        [(lvl, cnt) for lvl, cnt in counts.items() if _MIN_LEVEL <= lvl <= _MAX_LEVEL],
        key=lambda x: -x[0],
    )

    if not candidates:
        # Levels outside range; pick the highest available level
        best = max(counts, key=lambda k: (counts[k], k))
        logger.warning(
            "No admin_levels in range %d–%d found; using level %d (%d zones)",
            _MIN_LEVEL,
            _MAX_LEVEL,
            best,
            counts[best],
        )
        return best

    # Pick finest level with enough zones
    for level, count in candidates:
        if count >= min_zones:
            logger.info("Auto-detected admin_level=%d  (%d zones)", level, count)
            if level < 8:  # noqa: PLR2004
                logger.warning(
                    "Selected admin_level=%d may be too coarse for fine-grained analysis", level
                )
            return level

    # Fall back: level with most zones
    best_level, best_count = max(candidates, key=lambda x: x[1])
    logger.warning(
        "No level has >= %d zones; falling back to level=%d with %d zones",
        min_zones,
        best_level,
        best_count,
    )
    if best_level < 8:  # noqa: PLR2004
        logger.warning(
            "Selected admin_level=%d may be too coarse for fine-grained analysis", best_level
        )
    return best_level
