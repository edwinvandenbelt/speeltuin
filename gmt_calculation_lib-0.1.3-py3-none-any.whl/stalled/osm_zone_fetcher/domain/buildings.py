"""Building type classification and floor-area estimation for CBS derivation.

This module is pure Python (stdlib only) — no I/O, no external deps.

Classification
--------------
``classify_building(tags)`` maps an OSM ``building=*`` tag value to one of the
``BuildingCategory`` literals.  The category determines which CBS column(s)
receive the estimated floor-area contribution.

Floor-area estimation
---------------------
``building_floor_area_m2(element)`` returns an estimated gross floor area:

    floor_area = footprint_m2 × floors

where ``footprint_m2`` is derived from the way polygon geometry (or a
per-category default for node buildings that have no polygon), and ``floors``
comes from the ``building:levels`` tag, the ``height`` tag divided by
``_FLOOR_HEIGHT_M``, or a per-category default.

Density constants
-----------------
``DENSITY`` maps each BuildingCategory to the number of m² of gross floor
area per occupant/worker/student.  Multiply floor area by ``1 / DENSITY[cat]``
to obtain a head-count estimate.
"""

from __future__ import annotations

import math
from typing import Literal

# ---------------------------------------------------------------------------
# Building category literals
# ---------------------------------------------------------------------------

BuildingCategory = Literal[
    "residential",
    "school_basis",  # primary school / kindergarten
    "school_middelbaar",  # secondary school
    "school_mbo",  # vocational (MBO)
    "school_ho",  # higher education (university / college)
    "office",
    "industrial",
    "retail",
    "supermarket",
    "healthcare",
    "sports",
    "hotel",
    "community",  # church, civic, government, community centre
    "farm",
    "other",
]

# ---------------------------------------------------------------------------
# OSM tag → category sets
# ---------------------------------------------------------------------------

_RESIDENTIAL: frozenset[str] = frozenset(
    {
        "house",
        "detached",
        "semidetached_house",
        "terrace",
        "bungalow",
        "cabin",
        "houseboat",
        "static_caravan",
        "dwelling_house",
        "residential",
        "apartments",
        "flats",
        "apartment",
        "dormitory",
    }
)
_SCHOOL_BASIS: frozenset[str] = frozenset({"kindergarten", "primary_school"})
_SCHOOL_MIDDELBAAR: frozenset[str] = frozenset({"school", "secondary_school", "high_school"})
_SCHOOL_MBO: frozenset[str] = frozenset(
    {
        "vocational",
    }
)
_SCHOOL_HO: frozenset[str] = frozenset({"university", "college"})
_OFFICE: frozenset[str] = frozenset({"office"})
_INDUSTRIAL: frozenset[str] = frozenset(
    {
        "industrial",
        "warehouse",
        "factory",
        "storage_tank",
        "data_centre",
    }
)
_RETAIL: frozenset[str] = frozenset(
    {
        "commercial",
        "retail",
        "shop",
        "kiosk",
        "bakehouse",
        "mixed_use",
    }
)
_SUPERMARKET: frozenset[str] = frozenset({"supermarket"})
_HEALTHCARE: frozenset[str] = frozenset(
    {
        "hospital",
        "clinic",
        "doctors",
        "dentist",
        "medical_centre",
    }
)
_SPORTS: frozenset[str] = frozenset(
    {
        "sports_hall",
        "stadium",
        "sport",
        "sports_centre",
        "riding_hall",
        "grandstand",
        "pavilion",
    }
)
_HOTEL: frozenset[str] = frozenset(
    {
        "hotel",
        "hostel",
        "motel",
        "guest_house",
        "bed_and_breakfast",
    }
)
_COMMUNITY: frozenset[str] = frozenset(
    {
        "church",
        "cathedral",
        "mosque",
        "temple",
        "synagogue",
        "chapel",
        "public",
        "civic",
        "community_centre",
        "hall",
        "government",
        "townhall",
        "fire_station",
        "police",
    }
)
_FARM: frozenset[str] = frozenset(
    {
        "farm",
        "barn",
        "greenhouse",
        "silo",
        "cowshed",
        "stable",
        "pigsty",
        "slurry_tank",
        "agricultural",
    }
)

# ---------------------------------------------------------------------------
# Floor-area estimation parameters
# ---------------------------------------------------------------------------

_FLOOR_HEIGHT_M: float = 3.5  # assumed storey height when only height= is known

# Default number of floors per category when neither building:levels nor height
# is available.
_DEFAULT_FLOORS: dict[str, float] = {
    "residential": 2.0,
    "school_basis": 1.5,
    "school_middelbaar": 2.0,
    "school_mbo": 2.0,
    "school_ho": 3.0,
    "office": 3.0,
    "industrial": 1.0,
    "retail": 1.0,
    "supermarket": 1.0,
    "healthcare": 2.0,
    "sports": 1.0,
    "hotel": 4.0,
    "community": 1.5,
    "farm": 1.0,
    "other": 1.0,
}

# Default footprint (m²) for *node* buildings that have no polygon geometry.
_DEFAULT_FOOTPRINT_M2: dict[str, float] = {
    "residential": 70.0,
    "school_basis": 500.0,
    "school_middelbaar": 800.0,
    "school_mbo": 1_000.0,
    "school_ho": 2_000.0,
    "office": 300.0,
    "industrial": 500.0,
    "retail": 100.0,
    "supermarket": 1_000.0,
    "healthcare": 400.0,
    "sports": 600.0,
    "hotel": 500.0,
    "community": 300.0,
    "farm": 400.0,
    "other": 100.0,
}

# Gross floor area (m²) per occupant/worker/student.
DENSITY: dict[str, float] = {
    "residential": 40.0,  # m² per resident
    "school_basis": 8.0,  # m² per pupil
    "school_middelbaar": 8.0,
    "school_mbo": 8.0,
    "school_ho": 10.0,
    "office": 20.0,  # m² per worker
    "industrial": 50.0,
    "retail": 30.0,
    "supermarket": 15.0,
    "healthcare": 20.0,
    "sports": 100.0,
    "hotel": 30.0,
    "community": 50.0,
    "farm": 200.0,
    "other": 50.0,
}

# m² per household (used to derive huishoudens from residential floor area)
M2_PER_HOUSEHOLD: float = 80.0


# ---------------------------------------------------------------------------
# Classify
# ---------------------------------------------------------------------------


def classify_building(tags: dict) -> BuildingCategory:
    """Return the ``BuildingCategory`` for a set of OSM tags.

    The ``building=*`` value drives classification.  Additional tags (e.g.
    ``amenity=school``) are used as a fallback when ``building=yes`` or
    the tag is absent.

    Parameters
    ----------
    tags:
        OSM tag dict for a building element.

    Returns
    -------
    BuildingCategory string.
    """
    btype = (tags.get("building") or "").lower().strip()

    if btype in _RESIDENTIAL:
        return "residential"
    if btype in _SCHOOL_BASIS:
        return "school_basis"
    if btype in _SCHOOL_MIDDELBAAR:
        return "school_middelbaar"
    if btype in _SCHOOL_MBO:
        return "school_mbo"
    if btype in _SCHOOL_HO:
        return "school_ho"
    if btype in _OFFICE:
        return "office"
    if btype in _INDUSTRIAL:
        return "industrial"
    if btype in _SUPERMARKET:
        return "supermarket"
    if btype in _RETAIL:
        return "retail"
    if btype in _HEALTHCARE:
        return "healthcare"
    if btype in _SPORTS:
        return "sports"
    if btype in _HOTEL:
        return "hotel"
    if btype in _COMMUNITY:
        return "community"
    if btype in _FARM:
        return "farm"

    # Fallback: inspect amenity / shop / leisure tags
    amenity = (tags.get("amenity") or "").lower()
    shop = (tags.get("shop") or "").lower()
    leisure = (tags.get("leisure") or "").lower()

    if amenity in {"school", "college"}:
        return "school_middelbaar"
    if amenity == "kindergarten":
        return "school_basis"
    if amenity == "university":
        return "school_ho"
    if amenity in {"hospital", "clinic", "doctors", "dentist"}:
        return "healthcare"
    if amenity in {"place_of_worship"}:
        return "community"
    if shop in {"supermarket", "convenience", "grocery"}:
        return "supermarket"
    if shop:
        return "retail"
    if leisure in {"sports_centre", "fitness_centre", "stadium", "pitch"}:
        return "sports"

    return "other"


# ---------------------------------------------------------------------------
# Floor estimation
# ---------------------------------------------------------------------------


def estimate_floors(tags: dict, category: BuildingCategory) -> float:
    """Return the estimated number of above-ground storeys.

    Priority: ``building:levels`` tag → ``height`` tag / floor height →
    per-category default.

    Parameters
    ----------
    tags:
        OSM tag dict for the building element.
    category:
        Already-classified ``BuildingCategory`` (used for the default).

    Returns
    -------
    Positive float number of floors.
    """
    levels_raw = tags.get("building:levels") or tags.get("levels")
    if levels_raw is not None:
        try:
            v = float(str(levels_raw).split(";")[0].strip())
            if v > 0:
                return v
        except ValueError:
            pass

    height_raw = tags.get("height") or tags.get("building:height")
    if height_raw is not None:
        try:
            # Strip non-numeric suffix (e.g. "12 m", "12m")
            h = float("".join(c for c in str(height_raw) if c.isdigit() or c == ".").strip())
            if h > 0:
                return max(1.0, h / _FLOOR_HEIGHT_M)
        except ValueError:
            pass

    return _DEFAULT_FLOORS.get(category, 1.0)


# ---------------------------------------------------------------------------
# Footprint area
# ---------------------------------------------------------------------------


def footprint_m2_from_coords(coords: list[tuple[float, float]]) -> float:
    """Return the footprint area in m² for a polygon ring.

    Uses the shoelace formula projected onto a local flat-Earth coordinate
    system — accurate for small polygons (< ~1 km²).

    Parameters
    ----------
    coords:
        List of ``(lon, lat)`` pairs (WGS 84, degrees).  The ring may or may
        not be closed (first == last); both forms are handled.

    Returns
    -------
    Area in m².  Returns ``0.0`` for degenerate input (fewer than 3 points).
    """
    pts = list(coords)
    # Drop explicit closure
    if len(pts) > 1 and pts[0] == pts[-1]:
        pts = pts[:-1]
    if len(pts) < 3:  # noqa: PLR2004
        return 0.0

    mid_lat = sum(lat for _, lat in pts) / len(pts)
    cos_lat = math.cos(math.radians(mid_lat))
    # 1 degree latitude ≈ 111 319.5 m; 1 degree longitude ≈ cos(lat) × 111 319.5 m
    deg_to_m = 111_319.5
    xs = [lon * cos_lat * deg_to_m for lon, _ in pts]
    ys = [lat * deg_to_m for _, lat in pts]

    n = len(xs)
    area = 0.0
    for i in range(n):
        j = (i + 1) % n
        area += xs[i] * ys[j] - xs[j] * ys[i]
    return abs(area) / 2.0


def building_floor_area_m2(element: dict) -> float:
    """Return the estimated gross floor area (m²) for an OSM building element.

    For ``way`` elements the footprint is computed from the embedded
    ``geometry`` list (``[{lat, lon}, ...]`` as returned by ``out geom``).
    For ``node`` elements a per-category default footprint is used.

    Parameters
    ----------
    element:
        Overpass element dict (``way`` or ``node``) with ``tags`` and
        optionally ``geometry``.

    Returns
    -------
    Estimated gross floor area in m².  Returns ``0.0`` when the area cannot
    be computed (e.g. malformed geometry).
    """
    tags: dict = element.get("tags") or {}
    category = classify_building(tags)
    floors = estimate_floors(tags, category)

    geom: list[dict] | None = element.get("geometry")
    if geom and len(geom) >= 3:  # noqa: PLR2004
        coords = [(pt["lon"], pt["lat"]) for pt in geom if "lon" in pt and "lat" in pt]
        footprint = footprint_m2_from_coords(coords)
    else:
        # Node building or missing geometry — use category default
        footprint = _DEFAULT_FOOTPRINT_M2.get(category, 100.0)

    return footprint * floors
