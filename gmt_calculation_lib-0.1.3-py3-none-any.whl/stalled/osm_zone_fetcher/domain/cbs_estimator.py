"""CBS demographic estimation by spatially joining OSM buildings to zone polygons.

This module is pure Python (stdlib only) — no I/O, no external deps.

Workflow
--------
1. ``assign_buildings_to_zones(buildings, zone_features)``
   Assigns each building element to the zone whose polygon contains the
   building's representative point (centroid for ways, lat/lon for nodes).
   Buildings outside all zones are silently dropped.

2. ``estimate_cbs(buildings)``
   Aggregates CBS column estimates for a list of building elements that all
   belong to the *same* zone.

3. ``enrich_zones_with_cbs(zone_features, buildings)``
   Convenience wrapper that calls (1) and (2) and updates each zone feature's
   ``properties`` dict in-place.

CBS columns populated
---------------------
Only fields that can be meaningfully derived from building footprint data are
set.  Everything else remains ``None``.

Residents / households (from residential buildings):
    inwoners, huishoudens

Workers (from non-residential, non-education buildings):
    arbeidsplaatsen, arbeidsplaatsen_kantoorfunctie,
    arbeidsplaatsen_industriefunctie, arbeidsplaatsen_overige_winkelfunctie,
    arbeidsplaatsen_supermarkt_voedselwinkelfunctie,
    arbeidsplaatsen_gezondheidszorgfunctie, arbeidsplaatsen_sportfunctie,
    arbeidsplaatsen_bijeenkomstfunctie, arbeidsplaatsen_logiesfunctie,
    arbeidsplaatsen_boerderijfunctie, arbeidsplaatsen_onderwijsfunctie

Student capacity (from educational buildings):
    leerlingplaatsen_basisonderwijs, leerlingplaatsen_middelbaaronderwijs,
    leerlingplaatsen_middelbaarberoepsonderwijs, leerlingplaatsen_hogeronderwijs
"""

from __future__ import annotations

from osm_zone_fetcher.domain.buildings import (
    BuildingCategory,
    DENSITY,
    M2_PER_HOUSEHOLD,
    building_floor_area_m2,
    classify_building,
)

# ---------------------------------------------------------------------------
# Point-in-polygon (ray-casting)
# ---------------------------------------------------------------------------


def _point_in_ring(lon: float, lat: float, ring: list[tuple[float, float]]) -> bool:
    """Test whether a point is inside a polygon ring using ray-casting.

    Parameters
    ----------
    lon, lat:
        The point to test (WGS 84 degrees).
    ring:
        List of ``(lon, lat)`` pairs forming the polygon ring.  May or may
        not be explicitly closed.

    Returns
    -------
    ``True`` if the point is inside the ring.
    """
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i]
        xj, yj = ring[j]
        if ((yi > lat) != (yj > lat)) and (lon < (xj - xi) * (lat - yi) / (yj - yi + 1e-15) + xi):
            inside = not inside
        j = i
    return inside


def _building_centroid(element: dict) -> tuple[float, float] | None:
    """Return ``(lon, lat)`` representative point for a building element.

    For ``way`` elements the centroid of the polygon ring is used.
    For ``node`` elements the node coordinates are returned directly.

    Returns ``None`` when the element has no usable geometry.
    """
    etype = element.get("type", "")
    if etype == "node":
        lat = element.get("lat")
        lon = element.get("lon")
        if lat is not None and lon is not None:
            return float(lon), float(lat)
        return None

    if etype == "way":
        geom: list[dict] | None = element.get("geometry")
        if not geom:
            return None
        pts = [(pt["lon"], pt["lat"]) for pt in geom if "lon" in pt and "lat" in pt]
        if not pts:
            return None
        lon_c = sum(p[0] for p in pts) / len(pts)
        lat_c = sum(p[1] for p in pts) / len(pts)
        return lon_c, lat_c

    return None


def _zone_ring(zone_feature: dict) -> list[tuple[float, float]] | None:
    """Return the exterior ring of a zone polygon feature as ``[(lon, lat), ...]``.

    Returns ``None`` for non-polygon geometries.
    """
    geom = zone_feature.get("geometry") or {}
    if geom.get("type") != "Polygon":
        return None
    coords = geom.get("coordinates")
    if not coords:
        return None
    # exterior ring = first ring; coords are [lon, lat] pairs in GeoJSON
    return [(c[0], c[1]) for c in coords[0]]


# ---------------------------------------------------------------------------
# Spatial join
# ---------------------------------------------------------------------------


def assign_buildings_to_zones(
    buildings: list[dict],
    zone_features: list[dict],
) -> dict[str, list[dict]]:
    """Assign each building to the zone whose polygon contains its centroid.

    Parameters
    ----------
    buildings:
        List of Overpass building elements (``way`` or ``node`` type) as
        returned by ``fetch_overpass``.
    zone_features:
        List of zone GeoJSON Feature dicts (must have Polygon geometry).

    Returns
    -------
    Dict mapping ``zoneId`` → list of building elements whose centroid falls
    inside that zone.  Buildings that fall outside all zones are excluded.
    """
    # Pre-compute rings for each zone (skip non-polygon zones such as AREA)
    zone_rings: list[tuple[str, list[tuple[float, float]]]] = []
    for feat in zone_features:
        props = feat.get("properties") or {}
        zone_id = props.get("zoneId")
        if zone_id is None:
            continue
        ring = _zone_ring(feat)
        if ring:
            zone_rings.append((zone_id, ring))

    result: dict[str, list[dict]] = {zid: [] for zid, _ in zone_rings}

    for building in buildings:
        pt = _building_centroid(building)
        if pt is None:
            continue
        lon, lat = pt
        for zone_id, ring in zone_rings:
            if _point_in_ring(lon, lat, ring):
                result[zone_id].append(building)
                break  # assign to first matching zone only

    return result


# ---------------------------------------------------------------------------
# CBS estimation for a single zone's buildings
# ---------------------------------------------------------------------------

# Maps BuildingCategory → the CBS arbeidsplaatsen sub-column to populate.
_ARBEIDSPLAATSEN_COL: dict[str, str] = {
    "office": "arbeidsplaatsen_kantoorfunctie",
    "industrial": "arbeidsplaatsen_industriefunctie",
    "retail": "arbeidsplaatsen_overige_winkelfunctie",
    "supermarket": "arbeidsplaatsen_supermarkt_voedselwinkelfunctie",
    "healthcare": "arbeidsplaatsen_gezondheidszorgfunctie",
    "sports": "arbeidsplaatsen_sportfunctie",
    "community": "arbeidsplaatsen_bijeenkomstfunctie",
    "hotel": "arbeidsplaatsen_logiesfunctie",
    "farm": "arbeidsplaatsen_boerderijfunctie",
    # school staff is accounted for under onderwijsfunctie
    "school_basis": "arbeidsplaatsen_onderwijsfunctie",
    "school_middelbaar": "arbeidsplaatsen_onderwijsfunctie",
    "school_mbo": "arbeidsplaatsen_onderwijsfunctie",
    "school_ho": "arbeidsplaatsen_onderwijsfunctie",
}

# Maps BuildingCategory → the CBS leerlingplaatsen sub-column.
_LEERLINGPLAATSEN_COL: dict[str, str] = {
    "school_basis": "leerlingplaatsen_basisonderwijs",
    "school_middelbaar": "leerlingplaatsen_middelbaaronderwijs",
    "school_mbo": "leerlingplaatsen_middelbaarberoepsonderwijs",
    "school_ho": "leerlingplaatsen_hogeronderwijs",
}


def estimate_cbs(buildings: list[dict]) -> dict[str, float]:
    """Estimate CBS column values for a collection of buildings in one zone.

    Parameters
    ----------
    buildings:
        Building elements (all assumed to be within the same zone).

    Returns
    -------
    Partial dict of CBS column name → estimated float value.  Only columns
    with non-zero estimates are included; the caller is responsible for
    filling the remaining columns with ``None``.
    """
    totals: dict[str, float] = {}

    def _add(col: str, value: float) -> None:
        totals[col] = totals.get(col, 0.0) + value

    for element in buildings:
        tags: dict = element.get("tags") or {}
        cat: BuildingCategory = classify_building(tags)
        area = building_floor_area_m2(element)
        if area <= 0:
            continue

        density = DENSITY.get(cat, 50.0)
        count = area / density

        if cat == "residential":
            _add("inwoners", count)
            _add("huishoudens", area / M2_PER_HOUSEHOLD)

        elif cat in _LEERLINGPLAATSEN_COL:
            # School buildings contribute to student-capacity AND staff.
            # Staff: roughly 1 staff per 20 students.
            leerling_col = _LEERLINGPLAATSEN_COL[cat]
            _add(leerling_col, count)
            ap_col = _ARBEIDSPLAATSEN_COL[cat]
            _add(ap_col, count / 20.0)

        elif cat in _ARBEIDSPLAATSEN_COL:
            ap_col = _ARBEIDSPLAATSEN_COL[cat]
            _add(ap_col, count)

    # Derive total arbeidsplaatsen from all sub-columns.
    _AP_SUBS = set(_ARBEIDSPLAATSEN_COL.values())
    arbeidsplaatsen_total = sum(v for k, v in totals.items() if k in _AP_SUBS)
    if arbeidsplaatsen_total > 0:
        totals["arbeidsplaatsen"] = arbeidsplaatsen_total

    # Round all values to integers (counts are integer quantities in CBS data).
    return {k: round(v) for k, v in totals.items() if v > 0}


# ---------------------------------------------------------------------------
# Zone enrichment
# ---------------------------------------------------------------------------


def enrich_zones_with_cbs(
    zone_features: list[dict],
    buildings: list[dict],
) -> list[dict]:
    """Estimate CBS column values for each zone and update feature properties.

    Runs ``assign_buildings_to_zones`` followed by ``estimate_cbs`` for each
    zone and writes the results into the feature ``properties`` dicts
    in-place.

    Parameters
    ----------
    zone_features:
        Zone GeoJSON Feature dicts (modified in-place).
    buildings:
        All building elements for the whole area (spatially joined per zone).

    Returns
    -------
    The same ``zone_features`` list (mutated).
    """
    per_zone = assign_buildings_to_zones(buildings, zone_features)

    for feat in zone_features:
        props = feat.get("properties") or {}
        zone_id = props.get("zoneId")
        if zone_id is None:
            continue
        zone_buildings = per_zone.get(zone_id, [])
        if not zone_buildings:
            continue
        cbs = estimate_cbs(zone_buildings)
        props.update(cbs)

    return zone_features
