"""OSM relation → ZONE_PROPERTIES feature assembly for osm_zone_fetcher.

Converts Overpass relation elements (administrative boundaries) into GeoJSON
features with the ZONE_PROPERTIES schema, compatible with zone_intersector input.

Public API
----------
ZONE_PROPERTIES: tuple[str, ...]
    Ordered property keys for every zone feature.
relation_to_feature(element) -> dict | None
    Convert one OSM relation element to a ZONE_PROPERTIES GeoJSON Feature.
relations_to_zone_features(elements, admin_level, bbox) -> list[dict]
    Convert all relation elements at a given admin_level to zone features.
"""

from __future__ import annotations

import logging

from osm_zone_fetcher.domain.geometry import assemble_polygon, calc_centroid

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# CBS demographic columns — identical to zone_fetcher._CBS_COLS
# (all set to None for OSM-derived zones; no demographic data available via OSM)
# ---------------------------------------------------------------------------

_CBS_COLS: tuple[str, ...] = (
    "inwoners",
    "huishoudens",
    "arbeidsplaatsen",
    "leerlingplaatsen_basisonderwijs",
    "leerlingplaatsen_middelbaaronderwijs",
    "leerlingplaatsen_middelbaarberoepsonderwijs",
    "leerlingplaatsen_hogeronderwijs",
)

# ---------------------------------------------------------------------------
# ZONE_PROPERTIES schema — compatible with zone_intersector output (inner zones)
# ---------------------------------------------------------------------------

ZONE_PROPERTIES: tuple[str, ...] = (
    "gid",
    "zoneId",
    "zoneName",
    "zoneType",
    "ringIndex",
    "ringLabel",
    "sectorIndex",
    "constituentZoneIds",
    "centroidLon",
    "centroidLat",
    "production",
    "attraction",
    "nodeId",
    "mode",
    "nCrossingLinks",
    *_CBS_COLS,
)


# ---------------------------------------------------------------------------
# Feature builder
# ---------------------------------------------------------------------------


def relation_to_feature(element: dict) -> dict | None:
    """Convert an OSM relation element to a ZONE_PROPERTIES GeoJSON Feature.

    Parameters
    ----------
    element:
        Overpass relation element with ``id``, ``tags``, and ``members``
        (with embedded geometry from ``out geom``).

    Returns
    -------
    GeoJSON Feature dict with ZONE_PROPERTIES on ``properties``, or ``None``
    if the polygon geometry cannot be assembled.
    """
    rel_id: int = element["id"]
    tags: dict = element.get("tags") or {}
    members: list = element.get("members") or []

    rings = assemble_polygon(members)
    if not rings:
        logger.warning("Could not assemble polygon for relation %d — skipped", rel_id)
        return None

    outer_ring = rings[0]
    centroid_lon, centroid_lat = calc_centroid(outer_ring)

    geometry: dict = {
        "type": "Polygon",
        "coordinates": [list(r) for r in rings],
    }

    zone_id = f"osm_{rel_id}"
    zone_name: str = tags.get("name") or zone_id

    props: dict = {
        "gid": rel_id,
        "zoneId": zone_id,
        "zoneName": zone_name,
        "zoneType": "inner",
        "ringIndex": -1,
        "ringLabel": "",
        "sectorIndex": -1,
        "constituentZoneIds": [],
        "centroidLon": centroid_lon,
        "centroidLat": centroid_lat,
        "production": 0,
        "attraction": 0,
        "nodeId": None,
        "mode": None,
        "nCrossingLinks": 0,
        **{col: None for col in _CBS_COLS},
    }

    return {
        "type": "Feature",
        "geometry": geometry,
        "properties": props,
    }


# ---------------------------------------------------------------------------
# Batch conversion
# ---------------------------------------------------------------------------


def relations_to_zone_features(
    elements: list[dict],
    admin_level: int,
    bbox: list[float],  # noqa: ARG001 (reserved for future spatial filtering)
) -> list[dict]:
    """Convert Overpass relation elements to ZONE_PROPERTIES GeoJSON features.

    Only relations with ``boundary=administrative`` and the given *admin_level*
    are included.

    Parameters
    ----------
    elements:
        Overpass API response elements.
    admin_level:
        The OSM admin_level to filter on.
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` — kept for API compatibility;
        spatial filtering can be added here in the future.

    Returns
    -------
    List of GeoJSON Feature dicts with ZONE_PROPERTIES.
    """
    features: list[dict] = []
    skipped = 0

    for el in elements:
        if el.get("type") != "relation":
            continue
        tags = el.get("tags") or {}
        # Must be an administrative boundary at the requested level
        if tags.get("boundary") != "administrative":
            continue
        try:
            level = int(tags.get("admin_level", ""))
        except ValueError, TypeError:
            continue
        if level != admin_level:
            continue

        feat = relation_to_feature(el)
        if feat is None:
            skipped += 1
            continue
        features.append(feat)

    if skipped:
        logger.info("Skipped %d relations with invalid geometry", skipped)
    logger.info("Assembled %d zone features for admin_level=%d", len(features), admin_level)
    return features
