"""Overpass API query builders for osm_zone_fetcher.

Constructs Overpass QL queries that fetch administrative boundary relations
and building footprints for a given bounding box.
"""

from __future__ import annotations


def build_zone_query(bbox: list[float], admin_level: int | None, timeout: int = 90) -> str:
    """Build an Overpass QL query for administrative boundary relations.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS 84.
    admin_level:
        Specific OSM admin_level to query (e.g. ``11`` for Dutch
        neighbourhoods), or ``None`` to fetch all levels 7–12 for
        auto-detection.

    Returns
    -------
    Overpass QL query string.  Uses ``out geom`` so member-way geometries
    are embedded directly in the relation elements.
    """
    # Overpass bbox order: south, west, north, east
    s, w, n, e = bbox[1], bbox[0], bbox[3], bbox[2]
    coord_str = f"{s},{w},{n},{e}"

    if admin_level is not None:
        level_filter = f'["admin_level"="{admin_level}"]'
    else:
        # Fetch all fine-grained levels for auto-detection (7–12)
        level_filter = '["admin_level"~"^([7-9]|1[0-2])$"]'

    return f"""[out:json][timeout:{timeout}];
(
  relation["boundary"="administrative"]{level_filter}({coord_str});
);
out geom;"""


def build_buildings_query(bbox: list[float], timeout: int = 90) -> str:
    """Build an Overpass QL query for all building footprints in a bbox.

    Fetches both ``way`` and ``node`` elements tagged ``building=*``.
    Uses ``out geom`` so polygon coordinates are embedded in each way element.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS 84.
    timeout:
        Overpass query timeout in seconds.

    Returns
    -------
    Overpass QL query string.
    """
    s, w, n, e = bbox[1], bbox[0], bbox[3], bbox[2]
    coord_str = f"{s},{w},{n},{e}"

    return f"""[out:json][timeout:{timeout}];
(
  way["building"]({coord_str});
  node["building"]({coord_str});
);
out geom;"""
