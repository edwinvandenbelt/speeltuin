"""Local debug runner for osm_zone_fetcher.

Fetches administrative zone boundaries from the Overpass API for a bounding box
and writes a zone GeoJSON FeatureCollection to disk or S3.

Usage
-----
    # Auto-detect finest admin_level for Deventer centrum:
    python -m osm_zone_fetcher.osm_zone_fetcher_runner \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder ./out/ \\
        --area-id deventer-centrum

    # Explicitly use Dutch buurten (level 11):
    python -m osm_zone_fetcher.osm_zone_fetcher_runner \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder s3://gmp-networks/zones/ \\
        --area-id deventer-centrum \\
        --admin-level 11

Output files
------------
``{output_folder}{area_id}-ZONES-OSM.parquet`` — one file with all zone features.

Prerequisites
-------------
* AWS credentials (only needed for s3:// output URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path
from uuid import uuid4


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):  # noqa: PLR2004
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Local runner for osm_zone_fetcher — fetches administrative zone boundaries "
            "from the Overpass API and writes a zone GeoJSON file."
        )
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        required=True,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box in WGS 84.",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help=(
            "Output folder URI (s3://bucket/prefix/ or local directory). "
            "Output file is named {area_id}-ZONES-OSM.parquet."
        ),
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help="Area identifier for output file naming (UUID generated if absent).",
    )
    parser.add_argument(
        "--admin-level",
        type=int,
        default=None,
        metavar="LEVEL",
        help=(
            "OSM admin_level to use (e.g. 11 for Dutch neighbourhoods, 10 for wijken). "
            "Auto-detected when not provided."
        ),
    )
    parser.add_argument(
        "--min-zones",
        type=int,
        default=5,
        metavar="N",
        help="Minimum zone count for admin_level auto-detection (default: 5).",
    )
    parser.add_argument(
        "--overpass-url",
        default="https://overpass-api.de/api/interpreter",
        metavar="URL",
        help="Overpass API endpoint URL.",
    )
    parser.add_argument(
        "--overpass-timeout",
        type=int,
        default=90,
        metavar="SEC",
        help="Overpass request timeout in seconds (default: 90).",
    )
    parser.add_argument(
        "--tiles",
        default="1x1",
        metavar="NxM",
        help=(
            "Split the bbox into an N × M tile grid, sending one Overpass "
            "request per tile (default: 1x1 = single request). "
            "Use e.g. --tiles 2x2 when the server returns 504 errors."
        ),
    )
    parser.add_argument(
        "--no-cbs",
        action="store_true",
        default=False,
        help=(
            "Skip the building-based CBS estimation step. "
            "All CBS demographic columns will be None in the output."
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for AWS credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from osm_zone_fetcher.core.osm_zone_fetcher_core import derive_osm_zones  # noqa: PLC0415
    from shared.geoparquet import to_geoparquet  # noqa: PLC0415

    area_id = args.area_id or str(uuid4())
    bbox: list[float] = args.bbox
    output_folder = args.output_folder.rstrip("/") + "/"

    # Parse --tiles NxM
    try:
        nx_s, ny_s = args.tiles.lower().split("x")
        tiles: tuple[int, int] = (int(nx_s), int(ny_s))
        if tiles[0] < 1 or tiles[1] < 1:
            raise ValueError
    except ValueError, AttributeError:
        parser.error(f"--tiles must be in NxM format with positive integers, got: {args.tiles!r}")

    print(f"Area ID        : {area_id}")
    print(f"BBox           : {bbox}")
    print(f"Admin level    : {args.admin_level or '(auto-detect)'}")
    print(f"Tiles          : {tiles[0]}×{tiles[1]}")
    print(f"Overpass URL   : {args.overpass_url}")
    print(f"CBS estimation : {'no (--no-cbs)' if args.no_cbs else 'yes'}")

    fc = derive_osm_zones(
        bbox,
        admin_level=args.admin_level,
        min_zones=args.min_zones,
        estimate_cbs=not args.no_cbs,
        tiles=tiles,
        overpass_url=args.overpass_url,
        timeout=args.overpass_timeout,
    )

    fc_props = fc.get("properties") or {}
    n_zones = len(fc.get("features") or [])
    admin_level_used = fc_props.get("admin_level")
    cbs_estimated = fc_props.get("cbsEstimated", False)
    n_buildings = fc_props.get("nBuildings", 0)
    cbs_error = fc_props.get("cbsError")

    # Count zones that actually received a CBS estimate
    n_enriched = sum(
        1
        for f in (fc.get("features") or [])
        if (f.get("properties") or {}).get("inwoners") is not None
    )

    print(f"\nAdmin level    : {admin_level_used}")
    print(f"Zone features  : {n_zones}")
    if not args.no_cbs:
        if cbs_error:
            print(f"CBS estimation : FAILED — {cbs_error}")
        elif not cbs_estimated:
            print(f"CBS estimation : skipped (0 buildings returned)")
        else:
            print(f"Buildings found: {n_buildings}")
            print(f"Zones enriched : {n_enriched}/{n_zones}")

    out_uri = f"{output_folder}{area_id}-ZONES-OSM.parquet"
    print(f"Writing        : {out_uri}")
    payload = to_geoparquet(fc)
    _write_uri(out_uri, payload)

    print("\nDone.")


if __name__ == "__main__":
    main()
