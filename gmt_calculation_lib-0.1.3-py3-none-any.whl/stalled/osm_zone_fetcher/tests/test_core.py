"""Unit tests for osm_zone_fetcher core — pure Python, no I/O."""

from __future__ import annotations

import pytest

from osm_zone_fetcher.domain.overpass import build_zone_query
from osm_zone_fetcher.domain.zone import (
    ZONE_PROPERTIES,
    _CBS_COLS,
    relation_to_feature,
    relations_to_zone_features,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_member(coords: list[tuple[float, float]], role: str = "outer") -> dict:
    return {
        "type": "way",
        "role": role,
        "geometry": [{"lon": c[0], "lat": c[1]} for c in coords],
    }


def _make_relation(
    rel_id: int,
    name: str = "Test Zone",
    admin_level: int = 11,
    members: list | None = None,
) -> dict:
    if members is None:
        # Default: simple square polygon
        members = [
            _make_member([(6.0, 52.0), (6.1, 52.0), (6.1, 52.1), (6.0, 52.1), (6.0, 52.0)]),
        ]
    return {
        "type": "relation",
        "id": rel_id,
        "tags": {
            "boundary": "administrative",
            "admin_level": str(admin_level),
            "name": name,
        },
        "members": members,
    }


# ---------------------------------------------------------------------------
# ZONE_PROPERTIES schema
# ---------------------------------------------------------------------------


class TestZonePropertiesSchema:
    required_non_cbs = [
        "gid",
        "zoneId",
        "zoneName",
        "zoneType",
        "ringIndex",
        "ringLabel",
        "sectorIndex",
        "constituentZoneIds",
        "centroidLon",
        "centroidLat",
        "production",
        "attraction",
        "nodeId",
        "mode",
        "nCrossingLinks",
    ]

    def test_all_required_keys_present(self):
        for key in self.required_non_cbs:
            assert key in ZONE_PROPERTIES, f"Missing: {key}"

    def test_cbs_cols_present(self):
        for col in _CBS_COLS:
            assert col in ZONE_PROPERTIES, f"Missing CBS col: {col}"

    def test_zone_properties_is_tuple(self):
        assert isinstance(ZONE_PROPERTIES, tuple)

    def test_no_duplicate_keys(self):
        assert len(ZONE_PROPERTIES) == len(set(ZONE_PROPERTIES))


# ---------------------------------------------------------------------------
# relation_to_feature
# ---------------------------------------------------------------------------


class TestRelationToFeature:
    def test_gid_is_osm_relation_id(self):
        rel = _make_relation(rel_id=12345)
        feat = relation_to_feature(rel)
        assert feat is not None
        assert feat["properties"]["gid"] == 12345

    def test_zone_id_format(self):
        feat = relation_to_feature(_make_relation(rel_id=9999))
        assert feat["properties"]["zoneId"] == "osm_9999"

    def test_zone_name_from_tag(self):
        feat = relation_to_feature(_make_relation(rel_id=1, name="Centrum"))
        assert feat["properties"]["zoneName"] == "Centrum"

    def test_zone_name_fallback_to_zone_id(self):
        rel = _make_relation(rel_id=42)
        rel["tags"].pop("name")
        feat = relation_to_feature(rel)
        assert feat["properties"]["zoneName"] == "osm_42"

    def test_zone_type_is_inner(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        assert feat["properties"]["zoneType"] == "inner"

    def test_ring_index_is_minus_1(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        assert feat["properties"]["ringIndex"] == -1

    def test_sector_index_is_minus_1(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        assert feat["properties"]["sectorIndex"] == -1

    def test_constituent_zone_ids_is_empty_list(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        assert feat["properties"]["constituentZoneIds"] == []

    def test_production_and_attraction_are_zero(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        assert feat["properties"]["production"] == 0
        assert feat["properties"]["attraction"] == 0

    def test_node_id_and_mode_are_none(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        assert feat["properties"]["nodeId"] is None
        assert feat["properties"]["mode"] is None

    def test_n_crossing_links_is_zero(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        assert feat["properties"]["nCrossingLinks"] == 0

    def test_cbs_columns_are_none(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        for col in _CBS_COLS:
            assert feat["properties"][col] is None, f"{col} should be None"

    def test_all_zone_properties_present(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        for key in ZONE_PROPERTIES:
            assert key in feat["properties"], f"Missing: {key}"

    def test_centroid_within_bbox(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        p = feat["properties"]
        assert 6.0 <= p["centroidLon"] <= 6.1
        assert 52.0 <= p["centroidLat"] <= 52.1

    def test_geometry_is_polygon(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        assert feat["geometry"]["type"] == "Polygon"

    def test_polygon_ring_is_closed(self):
        feat = relation_to_feature(_make_relation(rel_id=1))
        outer_ring = feat["geometry"]["coordinates"][0]
        assert outer_ring[0] == outer_ring[-1]

    def test_no_members_returns_none(self):
        rel = _make_relation(rel_id=1, members=[])
        assert relation_to_feature(rel) is None

    def test_only_inner_members_returns_none(self):
        members = [_make_member([(6.0, 52.0), (6.1, 52.0), (6.1, 52.1)], role="inner")]
        rel = _make_relation(rel_id=1, members=members)
        assert relation_to_feature(rel) is None


# ---------------------------------------------------------------------------
# relations_to_zone_features
# ---------------------------------------------------------------------------


class TestRelationsToZoneFeatures:
    def test_filters_by_admin_level(self):
        elements = [
            _make_relation(1, admin_level=11),
            _make_relation(2, admin_level=10),
            _make_relation(3, admin_level=11),
        ]
        feats = relations_to_zone_features(elements, admin_level=11, bbox=[6.0, 52.0, 6.2, 52.2])
        assert len(feats) == 2

    def test_ignores_non_administrative_boundaries(self):
        rel = _make_relation(1, admin_level=11)
        rel["tags"]["boundary"] = "natural"  # not administrative
        feats = relations_to_zone_features([rel], admin_level=11, bbox=[6.0, 52.0, 6.2, 52.2])
        assert feats == []

    def test_ignores_non_relation_elements(self):
        elements = [
            {"type": "node", "id": 99, "lat": 52.0, "lon": 6.0},
            _make_relation(1, admin_level=11),
        ]
        feats = relations_to_zone_features(elements, admin_level=11, bbox=[6.0, 52.0, 6.2, 52.2])
        assert len(feats) == 1

    def test_empty_elements_returns_empty(self):
        assert relations_to_zone_features([], admin_level=11, bbox=[6.0, 52.0, 6.2, 52.2]) == []

    def test_all_features_have_complete_zone_properties(self):
        elements = [_make_relation(i, admin_level=11) for i in range(1, 4)]
        feats = relations_to_zone_features(elements, admin_level=11, bbox=[6.0, 52.0, 6.2, 52.2])
        for feat in feats:
            for key in ZONE_PROPERTIES:
                assert key in feat["properties"]


# ---------------------------------------------------------------------------
# build_zone_query
# ---------------------------------------------------------------------------


class TestBuildZoneQuery:
    def test_explicit_admin_level_in_query(self):
        q = build_zone_query([6.0, 52.0, 6.1, 52.1], admin_level=11)
        assert '"admin_level"="11"' in q

    def test_auto_detect_uses_range_filter(self):
        q = build_zone_query([6.0, 52.0, 6.1, 52.1], admin_level=None)
        assert "admin_level" in q
        assert "~" in q  # regex filter

    def test_bbox_order_south_west_north_east(self):
        q = build_zone_query([6.0, 52.0, 6.1, 52.1], admin_level=11)
        # south=52.0, west=6.0, north=52.1, east=6.1
        assert "52.0,6.0,52.1,6.1" in q

    def test_administrative_boundary_filter(self):
        q = build_zone_query([6.0, 52.0, 6.1, 52.1], admin_level=11)
        assert '"boundary"="administrative"' in q

    def test_out_geom_present(self):
        q = build_zone_query([6.0, 52.0, 6.1, 52.1], admin_level=11)
        assert "out geom" in q
