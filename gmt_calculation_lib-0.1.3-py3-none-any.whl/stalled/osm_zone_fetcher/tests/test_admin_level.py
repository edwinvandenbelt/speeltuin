"""Unit tests for osm_zone_fetcher.domain.admin_level — pure Python, no I/O."""

from __future__ import annotations

import pytest

from osm_zone_fetcher.domain.admin_level import count_zones_by_level, detect_finest_admin_level


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_relation(rel_id: int, admin_level: int, name: str = "") -> dict:
    return {
        "type": "relation",
        "id": rel_id,
        "tags": {
            "boundary": "administrative",
            "admin_level": str(admin_level),
            "name": name or f"Zone {rel_id}",
        },
        "members": [],
    }


def _make_elements(counts_by_level: dict[int, int]) -> list[dict]:
    """Build a flat list of relation elements with the given level counts."""
    elements: list[dict] = []
    rel_id = 1
    for level, count in counts_by_level.items():
        for _ in range(count):
            elements.append(_make_relation(rel_id, level))
            rel_id += 1
    return elements


# ---------------------------------------------------------------------------
# count_zones_by_level
# ---------------------------------------------------------------------------


class TestCountZonesByLevel:
    def test_counts_single_level(self):
        els = _make_elements({11: 3})
        assert count_zones_by_level(els) == {11: 3}

    def test_counts_multiple_levels(self):
        els = _make_elements({10: 2, 11: 5})
        counts = count_zones_by_level(els)
        assert counts[10] == 2
        assert counts[11] == 5

    def test_ignores_non_relations(self):
        els = [
            {"type": "node", "id": 1, "lat": 52.0, "lon": 6.0},
            {"type": "way", "id": 2, "nodes": [], "tags": {"admin_level": "11"}},
            _make_relation(3, 11),
        ]
        counts = count_zones_by_level(els)
        assert counts.get(11) == 1

    def test_ignores_invalid_admin_level(self):
        els = [
            {"type": "relation", "id": 1, "tags": {"admin_level": "not_a_number"}, "members": []},
            {"type": "relation", "id": 2, "tags": {}, "members": []},
        ]
        assert count_zones_by_level(els) == {}

    def test_empty_elements(self):
        assert count_zones_by_level([]) == {}


# ---------------------------------------------------------------------------
# detect_finest_admin_level
# ---------------------------------------------------------------------------


class TestDetectFinestAdminLevel:
    def test_picks_finest_level_with_enough_zones(self):
        # level 11 has 8, level 10 has 3 — should pick 11
        els = _make_elements({10: 3, 11: 8})
        assert detect_finest_admin_level(els, min_zones=5) == 11

    def test_falls_back_to_coarser_if_finest_too_few(self):
        # level 11 has 2, level 10 has 7 — should pick 10
        els = _make_elements({10: 7, 11: 2})
        assert detect_finest_admin_level(els, min_zones=5) == 10

    def test_falls_back_to_most_populated_if_none_qualify(self):
        # level 11 has 2, level 10 has 3 — neither >= 5 → pick 11 (most zones... no wait)
        # max by count: 10 has 3, which is more than 11's 2 → picks 10
        els = _make_elements({10: 3, 11: 2})
        result = detect_finest_admin_level(els, min_zones=5)
        assert result == 10

    def test_single_level_with_enough_zones(self):
        els = _make_elements({11: 10})
        assert detect_finest_admin_level(els, min_zones=5) == 11

    def test_defaults_to_8_when_no_elements(self):
        assert detect_finest_admin_level([], min_zones=5) == 8

    def test_prefers_higher_level_when_both_qualify(self):
        # Both level 9 and 10 have enough zones — should pick 10 (finest)
        els = _make_elements({9: 10, 10: 8})
        assert detect_finest_admin_level(els, min_zones=5) == 10

    def test_min_zones_1_picks_finest_level(self):
        # With min_zones=1, any level qualifies; should return finest (highest number)
        els = _make_elements({8: 1, 9: 1, 10: 1, 11: 1})
        assert detect_finest_admin_level(els, min_zones=1) == 11

    @pytest.mark.parametrize("level,n", [(7, 6), (8, 6), (9, 6)])
    def test_various_valid_levels(self, level, n):
        els = _make_elements({level: n})
        result = detect_finest_admin_level(els, min_zones=5)
        assert result == level


# ---------------------------------------------------------------------------
# Polygon reconstruction tests
# ---------------------------------------------------------------------------

from osm_zone_fetcher.domain.geometry import (  # noqa: E402
    _chain_segments,
    assemble_polygon,
    calc_centroid,
)


def _way_member(coords: list[tuple[float, float]], role: str = "outer") -> dict:
    """Build a minimal Overpass member dict with embedded geometry."""
    return {
        "type": "way",
        "role": role,
        "geometry": [{"lon": c[0], "lat": c[1]} for c in coords],
    }


class TestCalcCentroid:
    def test_square_centroid(self):
        ring = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0), (0.0, 0.0)]
        lon, lat = calc_centroid(ring)
        assert lon == pytest.approx(0.5, abs=1e-6)
        assert lat == pytest.approx(0.5, abs=1e-6)

    def test_single_point(self):
        ring = [(6.0, 52.0)]
        assert calc_centroid(ring) == (6.0, 52.0)

    def test_empty_returns_zero_zero(self):
        assert calc_centroid([]) == (0.0, 0.0)


class TestChainSegments:
    def test_two_connected_segments(self):
        a = [(0.0, 0.0), (1.0, 0.0)]
        b = [(1.0, 0.0), (1.0, 1.0), (0.0, 0.0)]
        ring = _chain_segments([a, b])
        assert ring[0] == ring[-1]  # closed
        assert len(ring) >= 4  # noqa: PLR2004

    def test_reversed_segment_stitches_correctly(self):
        # Segment b is reversed: should be flipped and connected
        a = [(0.0, 0.0), (1.0, 0.0)]
        b = [(0.0, 1.0), (1.0, 0.0)]  # ends at (1,0) which matches a's end
        ring = _chain_segments([a, b])
        assert ring[0] == ring[-1]

    def test_single_segment_closes(self):
        seg = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0)]
        ring = _chain_segments([seg])
        assert ring[0] == ring[-1]

    def test_empty_returns_empty(self):
        assert _chain_segments([]) == []


class TestAssemblePolygon:
    def test_simple_triangle_three_ways(self):
        """Three ways forming a triangle → one outer ring of ≥ 4 coords."""
        members = [
            _way_member([(0.0, 0.0), (1.0, 0.0)]),
            _way_member([(1.0, 0.0), (0.5, 1.0)]),
            _way_member([(0.5, 1.0), (0.0, 0.0)]),
        ]
        rings = assemble_polygon(members)
        assert rings is not None
        assert len(rings) >= 1
        outer = rings[0]
        assert outer[0] == outer[-1]  # closed ring

    def test_no_outer_members_returns_none(self):
        members = [_way_member([(0.0, 0.0), (1.0, 0.0)], role="inner")]
        assert assemble_polygon(members) is None

    def test_empty_members_returns_none(self):
        assert assemble_polygon([]) is None

    def test_reversed_way_stitches_correctly(self):
        """One way is stored in reverse order in the relation → should still assemble."""
        members = [
            _way_member([(0.0, 0.0), (1.0, 0.0), (1.0, 1.0)]),
            _way_member([(0.0, 0.0), (1.0, 1.0)]),  # reversed connection
        ]
        rings = assemble_polygon(members)
        assert rings is not None
