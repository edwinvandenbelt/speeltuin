"""Tests for osm_zone_fetcher.domain.cbs_estimator."""

from __future__ import annotations

import pytest

from osm_zone_fetcher.domain.cbs_estimator import (
    _point_in_ring,
    assign_buildings_to_zones,
    enrich_zones_with_cbs,
    estimate_cbs,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _square_ring(cx: float, cy: float, half: float) -> list[tuple[float, float]]:
    """Return a square polygon ring centred on (cx, cy) with given half-side."""
    return [
        (cx - half, cy - half),
        (cx + half, cy - half),
        (cx + half, cy + half),
        (cx - half, cy + half),
    ]


def _zone_feature(zone_id: str, cx: float, cy: float, half: float) -> dict:
    ring = _square_ring(cx, cy, half)
    closed = ring + [ring[0]]
    return {
        "type": "Feature",
        "geometry": {
            "type": "Polygon",
            "coordinates": [[[lon, lat] for lon, lat in closed]],
        },
        "properties": {"zoneId": zone_id, "zoneName": zone_id},
    }


def _way_building(tags: dict, cx: float, cy: float, half: float = 0.0001) -> dict:
    """Return a simple square way building element."""
    ring = _square_ring(cx, cy, half)
    return {
        "type": "way",
        "tags": tags,
        "geometry": [{"lon": lon, "lat": lat} for lon, lat in ring],
    }


def _node_building(tags: dict, lon: float, lat: float) -> dict:
    return {"type": "node", "tags": tags, "lon": lon, "lat": lat}


# ---------------------------------------------------------------------------
# _point_in_ring
# ---------------------------------------------------------------------------


class TestPointInRing:
    def test_centre_inside(self):
        ring = _square_ring(0.0, 0.0, 1.0)
        assert _point_in_ring(0.0, 0.0, ring) is True

    def test_outside(self):
        ring = _square_ring(0.0, 0.0, 1.0)
        assert _point_in_ring(2.0, 0.0, ring) is False

    def test_corner_outside(self):
        ring = _square_ring(0.0, 0.0, 1.0)
        # A point slightly outside a corner
        assert _point_in_ring(1.01, 1.01, ring) is False

    def test_near_edge_inside(self):
        ring = _square_ring(0.0, 0.0, 1.0)
        assert _point_in_ring(0.99, 0.0, ring) is True


# ---------------------------------------------------------------------------
# assign_buildings_to_zones
# ---------------------------------------------------------------------------


class TestAssignBuildingsToZones:
    def test_single_building_in_zone(self):
        zones = [_zone_feature("z1", 0.0, 0.0, 0.01)]
        buildings = [_node_building({"building": "house"}, 0.0, 0.0)]
        result = assign_buildings_to_zones(buildings, zones)
        assert result["z1"] == buildings

    def test_building_outside_all_zones(self):
        zones = [_zone_feature("z1", 0.0, 0.0, 0.01)]
        buildings = [_node_building({"building": "house"}, 1.0, 1.0)]
        result = assign_buildings_to_zones(buildings, zones)
        assert result["z1"] == []

    def test_two_zones_two_buildings(self):
        zones = [
            _zone_feature("z1", 0.0, 0.0, 0.01),
            _zone_feature("z2", 1.0, 0.0, 0.01),
        ]
        b1 = _node_building({"building": "house"}, 0.0, 0.0)
        b2 = _node_building({"building": "office"}, 1.0, 0.0)
        result = assign_buildings_to_zones([b1, b2], zones)
        assert result["z1"] == [b1]
        assert result["z2"] == [b2]

    def test_building_assigned_to_first_matching_zone_only(self):
        # Overlapping zones: b1 is in both, but should only appear in z1
        zones = [
            _zone_feature("z1", 0.0, 0.0, 0.02),
            _zone_feature("z2", 0.0, 0.0, 0.01),
        ]
        b = _node_building({"building": "house"}, 0.0, 0.0)
        result = assign_buildings_to_zones([b], zones)
        assert result["z1"] == [b]
        assert result["z2"] == []

    def test_way_building_centroid_used(self):
        zones = [_zone_feature("z1", 0.0, 0.0, 0.01)]
        b = _way_building({"building": "house"}, 0.0, 0.0)
        result = assign_buildings_to_zones([b], zones)
        assert result["z1"] == [b]

    def test_empty_buildings(self):
        zones = [_zone_feature("z1", 0.0, 0.0, 0.01)]
        result = assign_buildings_to_zones([], zones)
        assert result == {"z1": []}

    def test_empty_zones(self):
        buildings = [_node_building({"building": "house"}, 0.0, 0.0)]
        result = assign_buildings_to_zones(buildings, [])
        assert result == {}


# ---------------------------------------------------------------------------
# estimate_cbs
# ---------------------------------------------------------------------------


class TestEstimateCbs:
    def test_residential_building_produces_inwoners(self):
        b = _way_building({"building": "house"}, 0.0, 0.0)
        result = estimate_cbs([b])
        assert "inwoners" in result
        assert result["inwoners"] > 0

    def test_residential_building_produces_huishoudens(self):
        b = _way_building({"building": "house"}, 0.0, 0.0)
        result = estimate_cbs([b])
        assert "huishoudens" in result
        assert result["huishoudens"] > 0

    def test_office_building_produces_arbeidsplaatsen_kantoor(self):
        b = _way_building({"building": "office"}, 0.0, 0.0)
        result = estimate_cbs([b])
        assert "arbeidsplaatsen_kantoorfunctie" in result
        assert result["arbeidsplaatsen_kantoorfunctie"] > 0

    def test_school_produces_leerlingplaatsen_and_arbeidsplaatsen(self):
        b = _way_building({"building": "school"}, 0.0, 0.0)
        result = estimate_cbs([b])
        assert "leerlingplaatsen_middelbaaronderwijs" in result
        assert "arbeidsplaatsen_onderwijsfunctie" in result

    def test_kindergarten_produces_leerlingplaatsen_basis(self):
        b = _way_building({"building": "kindergarten"}, 0.0, 0.0)
        result = estimate_cbs([b])
        assert "leerlingplaatsen_basisonderwijs" in result

    def test_university_produces_leerlingplaatsen_ho(self):
        b = _way_building({"building": "university"}, 0.0, 0.0)
        result = estimate_cbs([b])
        assert "leerlingplaatsen_hogeronderwijs" in result

    def test_supermarket_produces_correct_column(self):
        b = _way_building({"building": "supermarket"}, 0.0, 0.0)
        result = estimate_cbs([b])
        assert "arbeidsplaatsen_supermarkt_voedselwinkelfunctie" in result

    def test_arbeidsplaatsen_total_equals_sum_of_subs(self):
        buildings = [
            _way_building({"building": "office"}, 0.0, 0.0),
            _way_building({"building": "retail"}, 0.0, 0.0),
        ]
        result = estimate_cbs(buildings)
        total = result.get("arbeidsplaatsen", 0)
        kantoor = result.get("arbeidsplaatsen_kantoorfunctie", 0)
        winkel = result.get("arbeidsplaatsen_overige_winkelfunctie", 0)
        assert total == kantoor + winkel

    def test_empty_buildings_returns_empty(self):
        assert estimate_cbs([]) == {}

    def test_values_are_rounded_integers(self):
        b = _way_building({"building": "house"}, 0.0, 0.0)
        result = estimate_cbs([b])
        for v in result.values():
            assert isinstance(v, int)


# ---------------------------------------------------------------------------
# enrich_zones_with_cbs
# ---------------------------------------------------------------------------


class TestEnrichZonesWithCbs:
    def test_residential_zone_gets_inwoners(self):
        zone = _zone_feature("z1", 0.0, 0.0, 0.01)
        buildings = [_node_building({"building": "house"}, 0.0, 0.0)]
        enrich_zones_with_cbs([zone], buildings)
        props = zone["properties"]
        assert "inwoners" in props
        assert props["inwoners"] > 0

    def test_zone_without_buildings_unchanged(self):
        zone = _zone_feature("z1", 0.0, 0.0, 0.01)
        enrich_zones_with_cbs([zone], [])
        # No CBS keys should have been added
        assert "inwoners" not in zone["properties"]

    def test_returns_same_list(self):
        zones = [_zone_feature("z1", 0.0, 0.0, 0.01)]
        result = enrich_zones_with_cbs(zones, [])
        assert result is zones
