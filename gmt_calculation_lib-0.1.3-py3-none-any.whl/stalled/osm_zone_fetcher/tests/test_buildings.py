"""Tests for osm_zone_fetcher.domain.buildings."""

from __future__ import annotations

import math

import pytest

from osm_zone_fetcher.domain.buildings import (
    DENSITY,
    M2_PER_HOUSEHOLD,
    BuildingCategory,
    building_floor_area_m2,
    classify_building,
    estimate_floors,
    footprint_m2_from_coords,
)


# ---------------------------------------------------------------------------
# classify_building
# ---------------------------------------------------------------------------


class TestClassifyBuilding:
    def test_residential_house(self):
        assert classify_building({"building": "house"}) == "residential"

    def test_residential_apartments(self):
        assert classify_building({"building": "apartments"}) == "residential"

    def test_residential_detached(self):
        assert classify_building({"building": "detached"}) == "residential"

    def test_school_middelbaar(self):
        assert classify_building({"building": "school"}) == "school_middelbaar"

    def test_school_basis_kindergarten(self):
        assert classify_building({"building": "kindergarten"}) == "school_basis"

    def test_school_ho_university(self):
        assert classify_building({"building": "university"}) == "school_ho"

    def test_school_ho_college(self):
        assert classify_building({"building": "college"}) == "school_ho"

    def test_office(self):
        assert classify_building({"building": "office"}) == "office"

    def test_industrial(self):
        assert classify_building({"building": "industrial"}) == "industrial"

    def test_warehouse(self):
        assert classify_building({"building": "warehouse"}) == "industrial"

    def test_retail(self):
        assert classify_building({"building": "retail"}) == "retail"

    def test_supermarket(self):
        assert classify_building({"building": "supermarket"}) == "supermarket"

    def test_healthcare_hospital(self):
        assert classify_building({"building": "hospital"}) == "healthcare"

    def test_sports_hall(self):
        assert classify_building({"building": "sports_hall"}) == "sports"

    def test_hotel(self):
        assert classify_building({"building": "hotel"}) == "hotel"

    def test_community_church(self):
        assert classify_building({"building": "church"}) == "community"

    def test_farm(self):
        assert classify_building({"building": "farm"}) == "farm"

    def test_yes_falls_back_to_amenity_school(self):
        assert classify_building({"building": "yes", "amenity": "school"}) == "school_middelbaar"

    def test_yes_falls_back_to_shop(self):
        assert classify_building({"building": "yes", "shop": "bakery"}) == "retail"

    def test_yes_falls_back_to_shop_supermarket(self):
        assert classify_building({"building": "yes", "shop": "supermarket"}) == "supermarket"

    def test_unknown_returns_other(self):
        assert classify_building({"building": "shed"}) == "other"

    def test_empty_tags_returns_other(self):
        assert classify_building({}) == "other"


# ---------------------------------------------------------------------------
# estimate_floors
# ---------------------------------------------------------------------------


class TestEstimateFloors:
    def test_building_levels_tag(self):
        assert estimate_floors({"building:levels": "3"}, "residential") == 3.0

    def test_building_levels_float(self):
        assert estimate_floors({"building:levels": "2.5"}, "residential") == 2.5

    def test_building_levels_semicolon(self):
        # e.g. "3;4" — take first value
        assert estimate_floors({"building:levels": "3;4"}, "residential") == 3.0

    def test_height_tag(self):
        floors = estimate_floors({"height": "10.5"}, "residential")
        assert floors == pytest.approx(10.5 / 3.5, rel=1e-3)

    def test_height_with_unit(self):
        floors = estimate_floors({"height": "14m"}, "office")
        assert floors == pytest.approx(14 / 3.5, rel=1e-3)

    def test_default_residential(self):
        assert estimate_floors({}, "residential") == 2.0

    def test_default_industrial(self):
        assert estimate_floors({}, "industrial") == 1.0

    def test_default_hotel(self):
        assert estimate_floors({}, "hotel") == 4.0

    def test_invalid_levels_falls_back_to_height(self):
        floors = estimate_floors({"building:levels": "abc", "height": "7"}, "office")
        assert floors == pytest.approx(7 / 3.5, rel=1e-3)

    def test_zero_levels_falls_back(self):
        # building:levels=0 should be treated as invalid
        assert estimate_floors({"building:levels": "0"}, "office") == 3.0


# ---------------------------------------------------------------------------
# footprint_m2_from_coords
# ---------------------------------------------------------------------------


class TestFootprintM2:
    def test_small_square(self):
        # ~100 m × 100 m square near equator
        # 0.001 deg ≈ 111.3 m
        side_deg = 100 / 111_319.5
        coords = [
            (0.0, 0.0),
            (side_deg, 0.0),
            (side_deg, side_deg),
            (0.0, side_deg),
        ]
        area = footprint_m2_from_coords(coords)
        assert area == pytest.approx(10_000.0, rel=0.01)  # 100 × 100 m²

    def test_closed_ring_same_as_open(self):
        side_deg = 100 / 111_319.5
        coords_open = [
            (0.0, 0.0),
            (side_deg, 0.0),
            (side_deg, side_deg),
            (0.0, side_deg),
        ]
        coords_closed = coords_open + [coords_open[0]]
        assert footprint_m2_from_coords(coords_open) == pytest.approx(
            footprint_m2_from_coords(coords_closed), rel=1e-9
        )

    def test_degenerate_two_points_returns_zero(self):
        assert footprint_m2_from_coords([(0.0, 0.0), (1.0, 0.0)]) == 0.0

    def test_empty_returns_zero(self):
        assert footprint_m2_from_coords([]) == 0.0


# ---------------------------------------------------------------------------
# building_floor_area_m2
# ---------------------------------------------------------------------------


class TestBuildingFloorAreaM2:
    def _make_way(self, tags: dict, coords: list[tuple]) -> dict:
        return {
            "type": "way",
            "tags": tags,
            "geometry": [{"lon": lon, "lat": lat} for lon, lat in coords],
        }

    def _make_node(self, tags: dict) -> dict:
        return {"type": "node", "tags": tags, "lat": 52.0, "lon": 6.0}

    def test_way_residential_2_floors(self):
        # 10 m × 10 m footprint, 2 default floors → 200 m²
        s = 10 / 111_319.5
        coords = [(0.0, 0.0), (s, 0.0), (s, s), (0.0, s)]
        element = self._make_way({"building": "house"}, coords)
        area = building_floor_area_m2(element)
        assert area == pytest.approx(200.0, rel=0.02)

    def test_way_with_levels_tag(self):
        s = 10 / 111_319.5
        coords = [(0.0, 0.0), (s, 0.0), (s, s), (0.0, s)]
        element = self._make_way({"building": "house", "building:levels": "3"}, coords)
        area = building_floor_area_m2(element)
        assert area == pytest.approx(300.0, rel=0.02)

    def test_node_uses_default_footprint(self):
        element = self._make_node({"building": "house"})
        area = building_floor_area_m2(element)
        # 70 m² footprint × 2 default floors = 140 m²
        assert area == pytest.approx(140.0, rel=1e-6)

    def test_node_office_default_footprint(self):
        element = self._make_node({"building": "office"})
        area = building_floor_area_m2(element)
        # 300 m² × 3 floors = 900 m²
        assert area == pytest.approx(900.0, rel=1e-6)

    def test_missing_geometry_uses_default(self):
        element = {"type": "way", "tags": {"building": "school"}, "geometry": []}
        area = building_floor_area_m2(element)
        assert area > 0

    def test_density_constants_defined_for_all_categories(self):
        # Every BuildingCategory should have a DENSITY entry
        all_cats = [
            "residential",
            "school_basis",
            "school_middelbaar",
            "school_mbo",
            "school_ho",
            "office",
            "industrial",
            "retail",
            "supermarket",
            "healthcare",
            "sports",
            "hotel",
            "community",
            "farm",
            "other",
        ]
        for cat in all_cats:
            assert cat in DENSITY, f"DENSITY missing category: {cat}"
            assert DENSITY[cat] > 0

    def test_m2_per_household_positive(self):
        assert M2_PER_HOUSEHOLD > 0
