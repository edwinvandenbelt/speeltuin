# Databricks notebook source
# ---------------------------------------------------------------------------
# osm_zone_fetcher_nb.py — Databricks notebook interface
#
# This notebook:
#   1. Leest widget-parameters.
#   2. Bouwt een Overpass QL-query voor de opgegeven bounding box.
#   3. Haalt administratieve grenzen op via Overpass API (internet vereist).
#   4. Detecteert of gebruikt het opgegeven admin_level.
#   5. Converteert relaties naar ZONE_PROPERTIES features.
#   6. Schrijft de output naar S3 (of lokaal pad).
#   7. Drukt een samenvatting af.
#
# Vereisten:
#   - Databricks cluster heeft internettoegang (voor Overpass API).
#   - AWS-credentials beschikbaar voor S3-schrijfacties.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("osm_zone_fetcher_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "bbox",
    "6.143,52.248,6.184,52.272",
    "Bounding box: minLon,minLat,maxLon,maxLat",
)
dbutils.widgets.text(  # noqa: F821
    "output_folder",
    "",
    "S3 output folder URI (s3://bucket/prefix/) or local path",
)
dbutils.widgets.text(  # noqa: F821
    "area_id",
    "",
    "Area identifier (UUID generated if empty)",
)
dbutils.widgets.text(  # noqa: F821
    "admin_level",
    "",
    "OSM admin_level (e.g. 11 for Dutch buurten). Leave empty for auto-detect.",
)
dbutils.widgets.text(  # noqa: F821
    "min_zones",
    "5",
    "Minimum zone count for auto-detection",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_url",
    "https://overpass-api.de/api/interpreter",
    "Overpass API endpoint URL",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_timeout",
    "90",
    "Overpass request timeout in seconds",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
import sys  # noqa: E402

for _candidate in ["/Workspace/src", "/dbfs/FileStore/gmt/src"]:
    if _candidate not in sys.path:
        sys.path.insert(0, _candidate)

from osm_zone_fetcher.core.osm_zone_fetcher_core import derive_osm_zones  # noqa: E402, F401
from osm_zone_fetcher.domain.zone import ZONE_PROPERTIES  # noqa: E402, F401

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

import uuid  # noqa: E402

_bbox_raw = dbutils.widgets.get("bbox").strip()  # noqa: F821
try:
    BBOX = [float(x.strip()) for x in _bbox_raw.split(",")]
    assert len(BBOX) == 4  # noqa: PLR2004, S101
except ValueError, AssertionError:
    raise ValueError(f"Widget 'bbox' must be 4 comma-separated floats. Got: {_bbox_raw!r}")

OUTPUT_FOLDER = dbutils.widgets.get("output_folder").strip().rstrip("/") + "/"  # noqa: F821
if not OUTPUT_FOLDER.replace("/", ""):
    raise ValueError("Widget 'output_folder' is empty.")

AREA_ID = dbutils.widgets.get("area_id").strip() or str(uuid.uuid4())  # noqa: F821

_al_raw = dbutils.widgets.get("admin_level").strip()  # noqa: F821
ADMIN_LEVEL: int | None = int(_al_raw) if _al_raw else None

MIN_ZONES = int(dbutils.widgets.get("min_zones").strip() or "5")  # noqa: F821
OVERPASS_URL = dbutils.widgets.get("overpass_url").strip()  # noqa: F821
OVERPASS_TIMEOUT = int(dbutils.widgets.get("overpass_timeout").strip() or "90")  # noqa: F821

logger.info(
    "bbox=%s  area_id=%s  admin_level=%s  output_folder=%s",
    BBOX,
    AREA_ID,
    ADMIN_LEVEL,
    OUTPUT_FOLDER,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402


def _write_output(uri: str, data: bytes) -> None:
    """Write bytes to S3 or local path."""
    if uri.startswith("s3://"):
        rest = uri[5:]
        bucket, _, key = rest.partition("/")
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/geo+json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
    else:
        import os  # noqa: PLC0415

        os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
        with open(uri, "wb") as _fh:
            _fh.write(data)
        logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run OSM Zone Fetcher
# MAGIC
# MAGIC Pas de widget-waarden hierboven aan en **voer deze cel opnieuw uit** om
# MAGIC een ander gebied of admin-level te verwerken.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)

print(f"Start         : {_t_start.isoformat()}")
print(f"Area ID       : {AREA_ID}")
print(f"BBox          : {BBOX}")
print(f"Admin level   : {ADMIN_LEVEL or '(auto-detect)'}")
print()

_fc = derive_osm_zones(
    BBOX,
    admin_level=ADMIN_LEVEL,
    min_zones=MIN_ZONES,
    overpass_url=OVERPASS_URL,
    timeout=OVERPASS_TIMEOUT,
)

_n_zones = len(_fc.get("features") or [])
_admin_level_used = (_fc.get("properties") or {}).get("admin_level")

_out_uri = f"{OUTPUT_FOLDER}{AREA_ID}-ZONES-OSM.geojson"
print(f"Writing       : {_out_uri}")
_write_output(_out_uri, json.dumps(_fc, ensure_ascii=False).encode("utf-8"))

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"OSM Zone Fetcher complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Area ID      : {AREA_ID}")
print(f"  BBox         : {BBOX}")
print(f"  Admin level  : {_admin_level_used}")
print(f"  Zone features: {_n_zones}")
print(f"  Output       : {_out_uri}")
print(_SEP)
