# src/bidirectional_splitter/core/__init__.py
