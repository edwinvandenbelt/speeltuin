"""Local debug runner for bidirectional_splitter.

Reads a raw bidirectional GeoJSON network from S3 or disk, splits it into directed
unidirectional links, and writes the result back.

Usage
-----
    python -m bidirectional_splitter.bidirectional_splitter_runner \\
        --input-uri  s3://gmp-networks/network/deventer-centrum-RAW-CAR.parquet \\
        --output-uri s3://gmp-networks/network/deventer-centrum-SPLIT-CAR.parquet

Prerequisites
-------------
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Local runner for bidirectional_splitter (converts bidir → directed GeoJSON)."
    )
    parser.add_argument(
        "--input-uri", required=True, metavar="URI",
        help="Full URI of the raw bidirectional GeoJSON (s3://bucket/key or local path).",
    )
    parser.add_argument(
        "--output-uri", required=True, metavar="URI",
        help="Full URI for the directed output GeoJSON (s3://bucket/key or local path).",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from bidirectional_splitter.core.bidirectional_splitter_core import (  # noqa: PLC0415
        post_process_features,
    )
    from bidirectional_splitter.domain.network import (  # noqa: PLC0415
        DIRECTED_LINK_PROPERTIES,
    )
    from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

    print(f"Reading  : {args.input_uri}")
    fc = from_geoparquet(_read_uri(args.input_uri))
    raw_count = len(fc.get("features", []))
    print(f"Raw      : {raw_count} features")

    fc["features"] = post_process_features(fc["features"])
    directed_count = len(fc["features"])
    print(f"Directed : {directed_count} features")

    # Update the FeatureCollection metadata to reflect the directed schema.
    fc.setdefault("properties", {})["fields"] = list(DIRECTED_LINK_PROPERTIES)

    payload = to_geoparquet(fc)
    print(f"Writing  : {args.output_uri}")
    _write_uri(args.output_uri, payload)
    print("Done.")


if __name__ == "__main__":
    main()
