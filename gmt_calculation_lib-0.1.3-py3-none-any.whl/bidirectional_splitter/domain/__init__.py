# src/bidirectional_splitter/domain/__init__.py
