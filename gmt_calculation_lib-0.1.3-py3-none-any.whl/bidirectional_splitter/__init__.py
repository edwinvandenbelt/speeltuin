# src/bidirectional_splitter/__init__.py
