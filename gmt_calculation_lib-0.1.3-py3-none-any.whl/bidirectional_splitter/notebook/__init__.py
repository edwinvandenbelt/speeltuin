# src/bidirectional_splitter/notebook/__init__.py
