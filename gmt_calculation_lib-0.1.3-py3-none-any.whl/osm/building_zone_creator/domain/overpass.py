"""Overpass QL query builder for streets used in block formation.

Public API
----------
build_streets_query(bbox, timeout) -> str
    Returns an Overpass QL query that fetches road ways (highway tag) for the
    given bounding box.  Purely pedestrian infrastructure (footways, steps,
    paths, tracks) is excluded so that the resulting polygons represent
    meaningful city blocks rather than micro-patches.
"""

from __future__ import annotations

DEFAULT_TIMEOUT = 90

# highway values that divide land into meaningful blocks
_BLOCK_HIGHWAY_FILTER = (
    "motorway|motorway_link|trunk|trunk_link|primary|primary_link"
    "|secondary|secondary_link|tertiary|tertiary_link"
    "|unclassified|residential|living_street|service|road"
)


def build_streets_query(
    bbox: list[float],
    timeout: int = DEFAULT_TIMEOUT,
) -> str:
    """Build an Overpass QL query for block-forming roads in a bounding box.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]``
    timeout:
        Overpass query timeout in seconds.

    Returns
    -------
    str
        Complete Overpass QL query string.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    bb = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    return (
        f"[out:json][timeout:{timeout}];\n"
        f"(\n"
        f'  way["highway"~"{_BLOCK_HIGHWAY_FILTER}"]({bb});\n'
        f");\n"
        f"out geom;\n"
    )
