# src/building_zone_creator/domain/__init__.py
