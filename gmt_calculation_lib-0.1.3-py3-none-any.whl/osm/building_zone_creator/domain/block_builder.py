"""Planaire blokvorming via straatwegen + bbox-grens.

Splits the bounding box into "blocks" (city-block polygons) by:
1. Collecting all street-way line geometries from Overpass elements.
2. Adding the four edges of the bounding box as extra lines so that open
   blocks at the study-area boundary are closed.
3. Applying ``shapely.ops.unary_union`` to snap and merge all lines (this
   automatically splits lines at their intersections — a prerequisite for
   ``polygonize`` to work correctly).
4. Running ``shapely.ops.polygonize`` to recover all closed faces.
5. Clipping each polygon to the bounding box and discarding empty results.

Requires ``shapely >= 2.0``.

Public API
----------
build_blocks(streets, bbox) -> list[shapely.geometry.Polygon]
    Return the list of block polygons for the given street elements and bbox.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

try:
    from shapely.geometry import LineString, box
    from shapely.ops import polygonize, unary_union

    _HAS_SHAPELY = True
except ImportError:
    _HAS_SHAPELY = False


def _require_shapely() -> None:
    if not _HAS_SHAPELY:
        raise ImportError(
            "shapely >= 2.0 is required for building_zone_creator. "
            "Install it with: pip install shapely"
        )


def build_blocks(
    streets: list[dict],
    bbox: list[float],
) -> list:
    """Build block polygons from Overpass street elements and a bounding box.

    Open blocks (polygons that touch the bbox boundary) are automatically
    closed because the bbox boundary is included in the input lines.

    Parameters
    ----------
    streets:
        List of Overpass way elements with a ``geometry`` key containing
        ``[{"lon": float, "lat": float}, ...]`` dicts.
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.

    Returns
    -------
    list[shapely.geometry.Polygon]
        Block polygons, each clipped to the bounding box.  May be empty if
        no streets are provided.
    """
    _require_shapely()

    min_lon, min_lat, max_lon, max_lat = bbox
    bbox_poly = box(min_lon, min_lat, max_lon, max_lat)

    lines = []

    # Street geometries
    for el in streets:
        geom = el.get("geometry") or []
        coords = [(float(p["lon"]), float(p["lat"])) for p in geom if "lon" in p and "lat" in p]
        if len(coords) >= 2:
            lines.append(LineString(coords))

    if not lines:
        logger.warning("No street lines — returning single block equal to bbox")
        return [bbox_poly]

    # Add bbox boundary so open blocks at the edges are closed
    lines.append(
        LineString(
            [
                (min_lon, min_lat),
                (max_lon, min_lat),
                (max_lon, max_lat),
                (min_lon, max_lat),
                (min_lon, min_lat),
            ]
        )
    )

    # Merge all lines — unary_union splits at intersections
    merged = unary_union(lines)

    # Polygonize recovers closed faces
    blocks_raw = list(polygonize(merged))

    if not blocks_raw:
        logger.warning("polygonize produced no blocks — returning single bbox block")
        return [bbox_poly]

    # Clip to bbox and discard empty/degenerate results
    result = []
    for poly in blocks_raw:
        clipped = poly.intersection(bbox_poly)
        if clipped.is_empty:
            continue
        # polygonize may return non-Polygon types (e.g. GeometryCollection)
        if clipped.geom_type == "Polygon" and clipped.area > 0:
            result.append(clipped)
        elif clipped.geom_type in ("MultiPolygon", "GeometryCollection"):
            for part in getattr(clipped, "geoms", []):
                if part.geom_type == "Polygon" and part.area > 0:
                    result.append(part)

    if not result:
        logger.warning("All blocks were empty after clipping — returning single bbox block")
        return [bbox_poly]

    logger.debug("build_blocks produced %d blocks from %d street ways", len(result), len(streets))
    return result
