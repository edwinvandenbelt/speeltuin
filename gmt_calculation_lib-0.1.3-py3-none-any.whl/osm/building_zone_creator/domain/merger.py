"""Greedy block-merging algorithm to create building zones.

Starting from the initial set of blocks (city-block polygons), this module
iteratively merges the block with the smallest building footprint into its
best-fitting adjacent neighbour, until every zone reaches the
``target_footprint_m2`` threshold or no further merges are possible.

"Best-fitting" means the neighbour whose combination with the current zone
minimises ``|combined_footprint - target_footprint_m2|``.

The adjacency relation is derived by a buffered spatial query: two blocks
are considered adjacent when they *touch* (share a boundary) or are within
a tiny tolerance (``_ADJ_TOLERANCE`` degrees) of each other — this accounts
for floating-point gaps left by ``polygonize``.

Requires ``shapely >= 2.0``.

Public API
----------
greedy_merge(blocks, block_buildings, block_footprints, target_m2)
    -> list[dict]
    Return merged zones as dicts with keys
    ``geom``, ``building_indices``, ``total_footprint``.
"""

from __future__ import annotations

import heapq
import logging
from collections import defaultdict

logger = logging.getLogger(__name__)

_ADJ_TOLERANCE = 1e-7  # degrees — buffer for adjacency detection

try:
    from shapely import STRtree
    from shapely.ops import unary_union

    _HAS_SHAPELY = True
except ImportError:
    _HAS_SHAPELY = False


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_adjacency(blocks: list) -> dict[int, set[int]]:
    """Return adjacency sets for all blocks.

    Two blocks are adjacent when their buffered geometries intersect
    (i.e. they share a boundary or are within ``_ADJ_TOLERANCE`` degrees).
    """
    adj: dict[int, set[int]] = defaultdict(set)
    if len(blocks) <= 1:
        return dict(adj)

    buffered = [b.buffer(_ADJ_TOLERANCE) for b in blocks]
    tree = STRtree(buffered)

    for i, buf_i in enumerate(buffered):
        candidates = tree.query(buf_i)
        for j_raw in candidates:
            j = int(j_raw)
            if j <= i:
                continue
            if buf_i.intersects(buffered[j]):
                adj[i].add(j)
                adj[j].add(i)

    return dict(adj)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def greedy_merge(
    blocks: list,
    block_buildings: dict[int, list[int]],
    block_footprints: dict[int, float],
    target_m2: float,
) -> list[dict]:
    """Merge blocks greedily to form building zones.

    Parameters
    ----------
    blocks:
        List of shapely ``Polygon`` objects (original city blocks).
    block_buildings:
        ``{block_idx: [building_feature_index, ...]}`` — which buildings
        are assigned to each block.
    block_footprints:
        ``{block_idx: total_footprint_m2}`` — total building footprint per
        block.
    target_m2:
        Target total building footprint per zone in m².

    Returns
    -------
    list[dict]
        Each element is a zone dict::

            {
                "geom": shapely.Polygon,
                "building_indices": list[int],
                "total_footprint": float,
            }
    """
    if not _HAS_SHAPELY:
        raise ImportError(
            "shapely >= 2.0 is required for building_zone_creator. "
            "Install it with: pip install shapely"
        )

    n = len(blocks)
    if n == 0:
        return []

    # ── Initialise zones (one per block) ────────────────────────────────────
    # Use dict[id → zone_dict] so we can delete merged entries efficiently.
    zones: dict[int, dict] = {}
    for i in range(n):
        zones[i] = {
            "geom": blocks[i],
            "building_indices": list(block_buildings.get(i, [])),
            "total_footprint": float(block_footprints.get(i, 0.0)),
        }

    # Build adjacency
    adj: dict[int, set[int]] = _build_adjacency(blocks)
    # Ensure every zone has an entry (even if isolated)
    for i in range(n):
        adj.setdefault(i, set())

    next_id = n
    alive: set[int] = set(range(n))

    # ── Priority queue: (footprint, zone_id) — smallest footprint first ────
    heap: list[tuple[float, int]] = [(zones[i]["total_footprint"], i) for i in range(n)]
    heapq.heapify(heap)

    # ── Greedy merge loop ────────────────────────────────────────────────────
    while heap:
        fp, zid = heapq.heappop(heap)

        # Skip stale heap entries
        if zid not in alive:
            continue
        # Already reached the target
        if zones[zid]["total_footprint"] >= target_m2:
            continue

        # Find alive neighbours
        neighbours = [nid for nid in adj.get(zid, set()) if nid in alive]
        if not neighbours:
            continue  # isolated block — cannot merge further

        # Pick neighbour that minimises |combined − target|
        best = min(
            neighbours,
            key=lambda nid: abs(
                zones[zid]["total_footprint"] + zones[nid]["total_footprint"] - target_m2
            ),
        )

        z1 = zones[zid]
        z2 = zones[best]

        # Merge geometry
        try:
            new_geom = unary_union([z1["geom"], z2["geom"]])
        except Exception:
            new_geom = z1["geom"]

        new_zone: dict = {
            "geom": new_geom,
            "building_indices": z1["building_indices"] + z2["building_indices"],
            "total_footprint": z1["total_footprint"] + z2["total_footprint"],
        }

        # Update adjacency: new zone inherits combined neighbours minus itself
        new_adj: set[int] = (adj.get(zid, set()) | adj.get(best, set())) - {zid, best}
        for nid in new_adj:
            adj[nid].discard(zid)
            adj[nid].discard(best)
            adj[nid].add(next_id)

        # Commit changes
        del zones[zid]
        del zones[best]
        alive.discard(zid)
        alive.discard(best)
        adj.pop(zid, None)
        adj.pop(best, None)

        zones[next_id] = new_zone
        adj[next_id] = new_adj
        alive.add(next_id)

        heapq.heappush(heap, (new_zone["total_footprint"], next_id))
        next_id += 1

    return list(zones.values())
