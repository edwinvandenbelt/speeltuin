"""Tests for building_zone_creator domain modules and core.

Covers:
- overpass.build_streets_query — Overpass QL correctness
- footprint.polygon_area_m2 — shoelace formula
- footprint.building_footprint_m2 — polygon, point, default
- block_builder.build_blocks — polygonize with simple grids, no-street fallback
- building_assigner.assign_buildings_to_blocks — PIP, fallback, empty blocks
- merger.greedy_merge — merge smallest block, stop at target, isolated block
- create_zones (integration) — mocked Overpass, two-block case
"""

from __future__ import annotations

import math
from unittest.mock import patch

import pytest

from osm.building_zone_creator.domain.overpass import build_streets_query
from osm.building_zone_creator.domain.footprint import building_footprint_m2, polygon_area_m2

# ---------------------------------------------------------------------------
# shapely guard — skip spatial tests if shapely is not installed
# ---------------------------------------------------------------------------
shapely = pytest.importorskip("shapely", reason="shapely not installed")
from shapely.geometry import LineString, Polygon, box  # noqa: E402

from osm.building_zone_creator.domain.block_builder import build_blocks  # noqa: E402
from osm.building_zone_creator.domain.building_assigner import assign_buildings_to_blocks  # noqa: E402
from osm.building_zone_creator.domain.merger import greedy_merge  # noqa: E402


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _poly_feature(coords: list[list[float]], btype: str = "house") -> dict:
    """Build a minimal GeoJSON Feature with a Polygon geometry."""
    ring = list(coords)
    if ring[0] != ring[-1]:
        ring.append(ring[0])
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {"buildingType": btype},
    }


def _point_feature(lon: float, lat: float, btype: str = "other") -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": {"buildingType": btype},
    }


def _parking_point_feature(lon: float, lat: float, capacity: int | None = None) -> dict:
    """Build a parking-type point feature with optional OSM capacity."""
    props: dict = {"buildingType": "parking"}
    if capacity is not None:
        props["parkingCapacity"] = capacity
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": props,
    }


# helper used by TestCreateZones + TestAutoTarget
_SHARED_BUILDINGS_FC: dict = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0.5, 1.0]},
            "properties": {"buildingType": "house"},
        },
        {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [1.5, 1.0]},
            "properties": {"buildingType": "school"},
        },
    ],
}


def _street_element(coords: list[tuple[float, float]]) -> dict:
    """Minimal Overpass street element with geometry list."""
    return {
        "type": "way",
        "id": 1,
        "tags": {"highway": "residential"},
        "geometry": [{"lon": lon, "lat": lat} for lon, lat in coords],
    }


# ---------------------------------------------------------------------------
# build_streets_query
# ---------------------------------------------------------------------------


class TestBuildStreetsQuery:
    def test_json_output(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "[out:json]" in q

    def test_bbox_order_is_lat_lon(self) -> None:
        q = build_streets_query([6.143, 52.248, 6.184, 52.272])
        assert "52.248,6.143,52.272,6.184" in q

    def test_highway_filter_present(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert '"highway"' in q

    def test_custom_timeout(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1], timeout=120)
        assert "[timeout:120]" in q

    def test_out_geom(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "out geom" in q

    def test_excludes_footway(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "footway" not in q

    def test_includes_residential(self) -> None:
        q = build_streets_query([6.0, 52.0, 6.1, 52.1])
        assert "residential" in q


# ---------------------------------------------------------------------------
# polygon_area_m2
# ---------------------------------------------------------------------------


class TestPolygonAreaM2:
    def test_unit_square_approx(self) -> None:
        # 1° × 1° square near equator ≈ 111_320² m²
        coords = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]
        area = polygon_area_m2(coords, ref_lat=0.0)
        assert area == pytest.approx(111_320.0**2, rel=0.01)

    def test_smaller_square(self) -> None:
        # 0.1° × 0.1° square
        coords = [[0.0, 0.0], [0.1, 0.0], [0.1, 0.1], [0.0, 0.1]]
        area = polygon_area_m2(coords, ref_lat=0.0)
        assert area == pytest.approx((0.1 * 111_320) ** 2, rel=0.01)

    def test_degenerate_less_than_three_points(self) -> None:
        assert polygon_area_m2([[0.0, 0.0], [1.0, 1.0]], ref_lat=52.0) == 0.0

    def test_longitude_scaling_at_52_degrees(self) -> None:
        # At 52°N, 1° lon ≈ cos(52°) * 111_320 m
        coords = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]
        area = polygon_area_m2(coords, ref_lat=52.0)
        expected = 111_320.0 * math.cos(math.radians(52.0)) * 111_320.0
        assert area == pytest.approx(expected, rel=0.01)

    def test_closed_polygon_same_as_open(self) -> None:
        coords_open = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0]]
        coords_closed = coords_open + [[0.0, 0.0]]
        area_open = polygon_area_m2(coords_open, ref_lat=0.0)
        area_closed = polygon_area_m2(coords_closed, ref_lat=0.0)
        assert area_open == pytest.approx(area_closed, rel=1e-9)


# ---------------------------------------------------------------------------
# building_footprint_m2
# ---------------------------------------------------------------------------


class TestBuildingFootprintM2:
    def test_polygon_feature(self) -> None:
        feat = _poly_feature([[0.0, 0.0], [0.01, 0.0], [0.01, 0.01], [0.0, 0.01]])
        area = building_footprint_m2(feat, ref_lat=52.0)
        assert area > 0.0

    def test_point_feature_returns_default(self) -> None:
        from osm.building_zone_creator.domain.footprint import _DEFAULT_FOOTPRINT_M2

        feat = _point_feature(6.15, 52.25)
        area = building_footprint_m2(feat, ref_lat=52.0)
        assert area == _DEFAULT_FOOTPRINT_M2

    def test_degenerate_polygon_returns_default(self) -> None:
        from osm.building_zone_creator.domain.footprint import _DEFAULT_FOOTPRINT_M2

        feat = _poly_feature([[0.0, 0.0], [0.0, 0.0]])
        area = building_footprint_m2(feat, ref_lat=52.0)
        assert area == _DEFAULT_FOOTPRINT_M2

    def test_missing_geometry_returns_default(self) -> None:
        from osm.building_zone_creator.domain.footprint import _DEFAULT_FOOTPRINT_M2

        feat = {"type": "Feature", "geometry": None, "properties": {}}
        area = building_footprint_m2(feat, ref_lat=52.0)
        assert area == _DEFAULT_FOOTPRINT_M2


# ---------------------------------------------------------------------------
# build_blocks
# ---------------------------------------------------------------------------


class TestBuildBlocks:
    _BBOX = [0.0, 0.0, 2.0, 2.0]

    def _cross_streets(self) -> list[dict]:
        """Two crossing roads at (1,0)-(1,2) and (0,1)-(2,1) → 4 blocks."""
        return [
            _street_element([(1.0, 0.0), (1.0, 2.0)]),
            _street_element([(0.0, 1.0), (2.0, 1.0)]),
        ]

    def test_cross_streets_produce_four_blocks(self) -> None:
        blocks = build_blocks(self._cross_streets(), self._BBOX)
        assert len(blocks) == 4

    def test_all_blocks_are_polygons(self) -> None:
        blocks = build_blocks(self._cross_streets(), self._BBOX)
        for b in blocks:
            assert b.geom_type == "Polygon"

    def test_no_streets_returns_single_bbox_block(self) -> None:
        blocks = build_blocks([], self._BBOX)
        assert len(blocks) == 1
        assert blocks[0].geom_type == "Polygon"

    def test_blocks_union_covers_bbox(self) -> None:
        from shapely.ops import unary_union  # noqa: PLC0415

        blocks = build_blocks(self._cross_streets(), self._BBOX)
        bbox_poly = box(*self._BBOX)
        union = unary_union(blocks)
        assert union.area == pytest.approx(bbox_poly.area, rel=1e-6)

    def test_blocks_clipped_within_bbox(self) -> None:
        bbox_poly = box(*self._BBOX)
        blocks = build_blocks(self._cross_streets(), self._BBOX)
        for b in blocks:
            assert b.within(bbox_poly.buffer(1e-9))

    def test_single_street_produces_two_blocks(self) -> None:
        # One vertical road through the middle → 2 blocks
        streets = [_street_element([(1.0, 0.0), (1.0, 2.0)])]
        blocks = build_blocks(streets, self._BBOX)
        assert len(blocks) == 2


# ---------------------------------------------------------------------------
# assign_buildings_to_blocks
# ---------------------------------------------------------------------------


class TestAssignBuildingsToBlocks:
    def _two_blocks(self) -> list:
        """Left block [0,0]–[1,2] and right block [1,0]–[2,2]."""
        return [
            Polygon([(0, 0), (1, 0), (1, 2), (0, 2), (0, 0)]),
            Polygon([(1, 0), (2, 0), (2, 2), (1, 2), (1, 0)]),
        ]

    def test_left_building_assigned_to_block_0(self) -> None:
        blocks = self._two_blocks()
        feat = _point_feature(0.25, 1.0)
        result = assign_buildings_to_blocks([feat], blocks)
        assert result[0] == 0

    def test_right_building_assigned_to_block_1(self) -> None:
        blocks = self._two_blocks()
        feat = _point_feature(1.75, 1.0)
        result = assign_buildings_to_blocks([feat], blocks)
        assert result[0] == 1

    def test_empty_buildings_returns_empty(self) -> None:
        result = assign_buildings_to_blocks([], self._two_blocks())
        assert result == []

    def test_empty_blocks_returns_minus_one(self) -> None:
        feat = _point_feature(0.5, 0.5)
        result = assign_buildings_to_blocks([feat], [])
        assert result == [-1]

    def test_polygon_building_uses_centroid(self) -> None:
        blocks = self._two_blocks()
        # Centroid of this polygon is at (0.5, 1.0) — in block 0
        feat = _poly_feature([[0.1, 0.5], [0.9, 0.5], [0.9, 1.5], [0.1, 1.5]])
        result = assign_buildings_to_blocks([feat], blocks)
        assert result[0] == 0

    def test_multiple_buildings(self) -> None:
        blocks = self._two_blocks()
        feats = [_point_feature(0.5, 1.0), _point_feature(1.5, 1.0)]
        result = assign_buildings_to_blocks(feats, blocks)
        assert result == [0, 1]


# ---------------------------------------------------------------------------
# greedy_merge
# ---------------------------------------------------------------------------


class TestGreedyMerge:
    def _four_blocks(self) -> list:
        """2×2 grid of 1×1 squares."""
        return [
            box(0, 0, 1, 1),
            box(1, 0, 2, 1),
            box(0, 1, 1, 2),
            box(1, 1, 2, 2),
        ]

    def test_no_blocks_returns_empty(self) -> None:
        result = greedy_merge([], {}, {}, 100.0)
        assert result == []

    def test_all_blocks_above_target_not_merged(self) -> None:
        blocks = self._four_blocks()
        fp = {i: 200.0 for i in range(4)}
        zones = greedy_merge(blocks, {}, fp, target_m2=100.0)
        assert len(zones) == 4

    def test_smallest_block_merged_with_neighbour(self) -> None:
        blocks = self._four_blocks()
        # Block 0 has 0 footprint → should merge with smallest-combined neighbour
        fp = {0: 0.0, 1: 50.0, 2: 50.0, 3: 200.0}
        zones = greedy_merge(blocks, {i: [] for i in range(4)}, fp, target_m2=100.0)
        # There should be fewer zones than blocks (some merging happened)
        assert len(zones) < 4

    def test_merged_zone_has_combined_footprint(self) -> None:
        blocks = [box(0, 0, 1, 1), box(1, 0, 2, 1)]
        fp = {0: 30.0, 1: 30.0}
        bi = {0: [0], 1: [1]}
        zones = greedy_merge(blocks, bi, fp, target_m2=1000.0)
        # Both blocks should be merged into one zone
        assert len(zones) == 1
        assert zones[0]["total_footprint"] == pytest.approx(60.0)

    def test_merged_zone_contains_all_buildings(self) -> None:
        blocks = [box(0, 0, 1, 1), box(1, 0, 2, 1)]
        fp = {0: 30.0, 1: 30.0}
        bi = {0: [0, 1], 1: [2]}
        zones = greedy_merge(blocks, bi, fp, target_m2=1000.0)
        assert len(zones) == 1
        assert set(zones[0]["building_indices"]) == {0, 1, 2}

    def test_isolated_block_stays_isolated(self) -> None:
        # Two non-adjacent blocks (far apart)
        blocks = [box(0, 0, 1, 1), box(10, 10, 11, 11)]
        fp = {0: 10.0, 1: 10.0}
        zones = greedy_merge(blocks, {0: [], 1: []}, fp, target_m2=1000.0)
        assert len(zones) == 2

    def test_zone_geom_is_union_of_merged_blocks(self) -> None:
        blocks = [box(0, 0, 1, 1), box(1, 0, 2, 1)]
        fp = {0: 10.0, 1: 10.0}
        zones = greedy_merge(blocks, {}, fp, target_m2=1000.0)
        assert len(zones) == 1
        # Area of merged zone should equal sum of both blocks
        assert zones[0]["geom"].area == pytest.approx(2.0, rel=1e-6)


# ---------------------------------------------------------------------------
# create_zones (integration — Overpass mocked)
# ---------------------------------------------------------------------------


class TestCreateZones:
    _BBOX = [0.0, 0.0, 2.0, 2.0]

    _MOCK_STREETS = [
        {
            "type": "way",
            "id": 1,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 1.0, "lat": 0.0}, {"lon": 1.0, "lat": 2.0}],
        }
    ]

    _BUILDINGS_FC: dict = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [0.5, 1.0]},
                "properties": {"buildingType": "house"},
            },
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [1.5, 1.0]},
                "properties": {"buildingType": "school"},
            },
        ],
    }

    def _call(self, target: float = 1_000_000.0) -> tuple[dict, dict]:
        from osm.building_zone_creator.core.building_zone_creator_core import create_zones  # noqa: PLC0415

        mock_data = {"elements": self._MOCK_STREETS}
        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = mock_data
            return create_zones(
                self._BUILDINGS_FC,
                self._BBOX,
                area_id="test",
                target_footprint_m2=target,
            )

    def test_returns_feature_collection(self) -> None:
        fc, _ = self._call()
        assert fc["type"] == "FeatureCollection"

    def test_stats_total_matches_feature_count(self) -> None:
        fc, stats = self._call()
        assert stats["total"] == len(fc["features"])

    def test_zones_created(self) -> None:
        _, stats = self._call()
        assert stats["zones"] >= 1

    def test_blocks_at_least_two_from_one_road(self) -> None:
        _, stats = self._call()
        assert stats["blocks"] >= 2

    def test_both_buildings_assigned(self) -> None:
        _, stats = self._call()
        assert stats["assigned_buildings"] == 2

    def test_zone_properties_present(self) -> None:
        fc, _ = self._call()
        feat = fc["features"][0]
        props = feat["properties"]
        assert "zoneId" in props
        assert "nBuildings" in props
        assert "totalFootprintM2" in props
        assert "buildingByType" in props
        assert "centroidLon" in props
        assert "centroidLat" in props

    def test_building_types_are_m2_floats(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            for val in feat["properties"]["buildingByType"].values():
                assert isinstance(val, float)
                assert val >= 0.0

    def test_zone_id_prefix_matches_area_id(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert feat["properties"]["zoneId"].startswith("test_")

    def test_zone_geometry_is_polygon(self) -> None:
        fc, _ = self._call()
        for feat in fc["features"]:
            assert feat["geometry"]["type"] in ("Polygon", "MultiPolygon")

    def test_large_target_produces_fewer_zones(self) -> None:
        _, stats_large = self._call(target=1_000_000.0)
        _, stats_small = self._call(target=1.0)
        assert stats_large["zones"] <= stats_small["zones"]

    def test_empty_buildings_still_produces_zones(self) -> None:
        from osm.building_zone_creator.core.building_zone_creator_core import create_zones  # noqa: PLC0415

        empty_fc: dict = {"type": "FeatureCollection", "features": []}
        mock_data = {"elements": self._MOCK_STREETS}
        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = mock_data
            fc, stats = create_zones(empty_fc, self._BBOX, area_id="test")
        assert fc["type"] == "FeatureCollection"
        assert stats["zones"] >= 1
        assert stats["assigned_buildings"] == 0


# ===========================================================================
# TestAutoTarget
# ===========================================================================


class TestAutoTarget:
    """Verify the auto-computation of target_footprint_m2 from total building footprint."""

    _BBOX = [0.0, 0.0, 2.0, 2.0]

    _MOCK_STREETS = [
        {
            "type": "way",
            "id": 1,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 1.0, "lat": 0.0}, {"lon": 1.0, "lat": 2.0}],
        }
    ]

    _BUILDINGS_FC: dict = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [0.5, 1.0]},
                "properties": {"buildingType": "house"},
            },
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [1.5, 1.0]},
                "properties": {"buildingType": "school"},
            },
        ],
    }

    def _call_no_target(self) -> tuple[dict, dict]:
        from osm.building_zone_creator.core.building_zone_creator_core import create_zones  # noqa: PLC0415

        mock_data = {"elements": self._MOCK_STREETS}
        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = mock_data
            # No target_footprint_m2 → auto-compute
            return create_zones(self._BUILDINGS_FC, self._BBOX, area_id="test")

    def test_target_stored_in_fc_properties(self) -> None:
        fc, _ = self._call_no_target()
        assert "targetFootprintM2" in fc["properties"]
        assert fc["properties"]["targetFootprintM2"] > 0.0

    def test_auto_target_equals_total_footprint_divided_by_100(self) -> None:
        from osm.building_zone_creator.core.building_zone_creator_core import _TARGET_ZONE_COUNT  # noqa: PLC0415
        from osm.building_zone_creator.domain.footprint import _DEFAULT_FOOTPRINT_M2  # noqa: PLC0415

        fc, _ = self._call_no_target()
        # Both buildings are Points → each contributes _DEFAULT_FOOTPRINT_M2
        total_fp = 2 * _DEFAULT_FOOTPRINT_M2
        expected = total_fp / _TARGET_ZONE_COUNT
        assert fc["properties"]["targetFootprintM2"] == pytest.approx(expected, rel=1e-3)

    def test_target_zone_count_is_100(self) -> None:
        from osm.building_zone_creator.core.building_zone_creator_core import _TARGET_ZONE_COUNT  # noqa: PLC0415

        assert _TARGET_ZONE_COUNT == 100

    def test_auto_target_falls_back_to_default_when_no_buildings(self) -> None:
        from osm.building_zone_creator.core.building_zone_creator_core import (  # noqa: PLC0415
            _DEFAULT_TARGET_FOOTPRINT_M2,
            create_zones,
        )

        empty_fc: dict = {"type": "FeatureCollection", "features": []}
        mock_data = {"elements": self._MOCK_STREETS}
        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = mock_data
            fc, _ = create_zones(empty_fc, self._BBOX, area_id="test")
        assert fc["properties"]["targetFootprintM2"] == pytest.approx(_DEFAULT_TARGET_FOOTPRINT_M2)

    def test_explicit_target_overrides_auto(self) -> None:
        from osm.building_zone_creator.core.building_zone_creator_core import create_zones  # noqa: PLC0415

        explicit = 12345.0
        mock_data = {"elements": self._MOCK_STREETS}
        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = mock_data
            fc, _ = create_zones(
                self._BUILDINGS_FC, self._BBOX, area_id="test", target_footprint_m2=explicit
            )
        assert fc["properties"]["targetFootprintM2"] == pytest.approx(explicit)


# ===========================================================================
# TestParkingCapacity
# ===========================================================================


class TestParkingCapacity:
    """Verify that parkingCapacity is aggregated correctly in create_zones."""

    _BBOX = [0.0, 0.0, 2.0, 2.0]

    _MOCK_STREETS = [
        {
            "type": "way",
            "id": 1,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 1.0, "lat": 0.0}, {"lon": 1.0, "lat": 2.0}],
        }
    ]

    def _make_buildings_fc(self, *features: dict) -> dict:
        return {"type": "FeatureCollection", "features": list(features)}

    def _call(self, buildings_fc: dict) -> tuple[dict, dict]:
        from osm.building_zone_creator.core.building_zone_creator_core import create_zones  # noqa: PLC0415

        mock_data = {"elements": self._MOCK_STREETS}
        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = mock_data
            return create_zones(buildings_fc, self._BBOX, area_id="test", target_footprint_m2=1e9)

    def test_parking_capacity_key_present_on_every_zone(self) -> None:
        fc, _ = self._call(self._make_buildings_fc(_point_feature(0.5, 1.0, "house")))
        for feat in fc["features"]:
            assert "parkingCapacity" in feat["properties"]

    def test_parking_with_known_capacity_summed(self) -> None:
        # Two parking features in the left block (x < 1.0)
        buildings_fc = self._make_buildings_fc(
            _parking_point_feature(0.3, 1.0, capacity=50),
            _parking_point_feature(0.6, 1.0, capacity=30),
        )
        fc, _ = self._call(buildings_fc)
        left_zone = next(f for f in fc["features"] if f["properties"].get("parkingCapacity", 0) > 0)
        assert left_zone["properties"]["parkingCapacity"] == 80

    def test_parking_without_capacity_uses_footprint_estimate(self) -> None:
        # A parking point with capacity=0 (absent) → footprint estimate (≥ 1)
        buildings_fc = self._make_buildings_fc(_parking_point_feature(0.5, 1.0, capacity=0))
        fc, _ = self._call(buildings_fc)
        cap = fc["features"][0]["properties"]["parkingCapacity"]
        assert cap >= 1  # must be positive (footprint / 25 fallback)

    def test_non_parking_zone_has_zero_capacity(self) -> None:
        buildings_fc = self._make_buildings_fc(
            _point_feature(0.5, 1.0, "house"),
            _point_feature(1.5, 1.0, "school"),
        )
        fc, _ = self._call(buildings_fc)
        for feat in fc["features"]:
            assert feat["properties"]["parkingCapacity"] == 0


# ---------------------------------------------------------------------------
# zoneClass — STUDY / INFLUENCE assignment
# ---------------------------------------------------------------------------


class TestZoneClass:
    """Tests that create_zones assigns zoneClass correctly.

    The bbox is [0, 0, 2, 2].  A vertical street at x=1 splits it into two
    blocks: left (x 0–1) and right (x 1–2).  Both blocks touch the bbox
    boundary, so both should be INFLUENCE.

    To get a guaranteed STUDY zone we use a bbox with two parallel streets
    that create an interior block: streets at x=0.5 and x=1.5 divide
    [0,0,2,2] into three columns — the middle column [0.5,0,1.5,2] touches
    neither the left nor the right edge of the bbox, so it is STUDY.
    The left and right columns touch the bbox edge → INFLUENCE.

    Buildings are placed in each column and ``target_footprint_m2`` is set
    below a single building's footprint so that greedy_merge does not combine
    any blocks (blocks only merge when their footprint is below the target).
    """

    _BBOX = [0.0, 0.0, 2.0, 2.0]
    # One building per column: placed clearly inside each block.
    # Default footprint for a Point feature is 70 m²; target is set to 10 m²
    # so each block (footprint=70) is already above target → no merging.
    _TARGET = 10.0

    # Two parallel vertical streets → three columns; middle is interior.
    _TWO_STREETS = [
        {
            "type": "way",
            "id": 1,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 0.5, "lat": 0.0}, {"lon": 0.5, "lat": 2.0}],
        },
        {
            "type": "way",
            "id": 2,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 1.5, "lat": 0.0}, {"lon": 1.5, "lat": 2.0}],
        },
    ]

    # Grid of streets: two vertical + two horizontal streets divide the bbox
    # into 9 cells.  The centre cell [0.5,0.5,1.5,1.5] is completely enclosed
    # by streets on all four sides and does not touch the bbox boundary → STUDY.
    # The eight surrounding cells all share at least one edge with the bbox → INFLUENCE.
    _GRID_STREETS = [
        {
            "type": "way",
            "id": 1,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 0.5, "lat": 0.0}, {"lon": 0.5, "lat": 2.0}],
        },
        {
            "type": "way",
            "id": 2,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 1.5, "lat": 0.0}, {"lon": 1.5, "lat": 2.0}],
        },
        {
            "type": "way",
            "id": 3,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 0.0, "lat": 0.5}, {"lon": 2.0, "lat": 0.5}],
        },
        {
            "type": "way",
            "id": 4,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 0.0, "lat": 1.5}, {"lon": 2.0, "lat": 1.5}],
        },
    ]

    # One vertical street → two columns; both touch bbox edge.
    _ONE_STREET = [
        {
            "type": "way",
            "id": 1,
            "tags": {"highway": "residential"},
            "geometry": [{"lon": 1.0, "lat": 0.0}, {"lon": 1.0, "lat": 2.0}],
        }
    ]

    def _buildings(self, *lons_lats: tuple[float, float]) -> dict:
        """One Point building per (lon, lat) pair."""
        return {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Point", "coordinates": [lon, lat]},
                    "properties": {"buildingType": "work"},
                }
                for lon, lat in lons_lats
            ],
        }

    def _call(self, streets: list, buildings: dict) -> dict:
        from osm.building_zone_creator.core.building_zone_creator_core import create_zones  # noqa: PLC0415

        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = {"elements": streets}
            fc, _ = create_zones(
                buildings,
                self._BBOX,
                area_id="test",
                target_footprint_m2=self._TARGET,
            )
        return fc

    def test_zone_class_present_on_all_features(self) -> None:
        buildings = self._buildings((0.5, 1.0), (1.5, 1.0))
        fc = self._call(self._ONE_STREET, buildings)
        for feat in fc["features"]:
            assert "zoneClass" in feat["properties"]

    def test_zone_class_is_study_or_influence(self) -> None:
        buildings = self._buildings((0.5, 1.0), (1.5, 1.0))
        fc = self._call(self._ONE_STREET, buildings)
        valid = {"STUDY", "INFLUENCE"}
        for feat in fc["features"]:
            assert feat["properties"]["zoneClass"] in valid

    def test_edge_zones_are_influence(self) -> None:
        """All zones produced by a single street touch the bbox → INFLUENCE."""
        buildings = self._buildings((0.5, 1.0), (1.5, 1.0))
        fc = self._call(self._ONE_STREET, buildings)
        for feat in fc["features"]:
            assert feat["properties"]["zoneClass"] == "INFLUENCE"

    def test_interior_zone_is_study(self) -> None:
        """Grid streets create a centre cell that does not touch the bbox → STUDY."""
        # Buildings in each of the 9 grid cells; target below one building's footprint
        # so cells are not merged.
        buildings = self._buildings(
            (0.25, 0.25),
            (1.0, 0.25),
            (1.75, 0.25),
            (0.25, 1.0),
            (1.0, 1.0),
            (1.75, 1.0),
            (0.25, 1.75),
            (1.0, 1.75),
            (1.75, 1.75),
        )
        fc = self._call(self._GRID_STREETS, buildings)
        classes = {f["properties"]["zoneClass"] for f in fc["features"]}
        assert "STUDY" in classes

    def test_outer_zones_of_two_streets_are_influence(self) -> None:
        """The left-most and right-most columns touch the bbox → INFLUENCE."""
        buildings = self._buildings((0.25, 1.0), (1.0, 1.0), (1.75, 1.0))
        fc = self._call(self._TWO_STREETS, buildings)
        influence = [f for f in fc["features"] if f["properties"]["zoneClass"] == "INFLUENCE"]
        assert len(influence) >= 2

    def test_zone_class_survives_merge(self) -> None:
        """When blocks are merged, zoneClass is still set on the resulting zone."""
        # Use a large target to force merging of the two blocks.
        buildings = self._buildings((0.5, 1.0), (1.5, 1.0))
        from osm.building_zone_creator.core.building_zone_creator_core import create_zones  # noqa: PLC0415

        with patch(
            "osm.building_zone_creator.core.building_zone_creator_core.fetch_overpass"
        ) as mock_fp:
            mock_fp.return_value = {"elements": self._ONE_STREET}
            fc, _ = create_zones(
                buildings, self._BBOX, area_id="test", target_footprint_m2=1_000_000.0
            )
        for feat in fc["features"]:
            assert feat["properties"]["zoneClass"] in {"STUDY", "INFLUENCE"}
