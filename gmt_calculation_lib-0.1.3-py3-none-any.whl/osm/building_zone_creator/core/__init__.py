# src/building_zone_creator/core/__init__.py
