"""Extract network nodes and their importance scores from a network GeoJSON.

Each network link's ``fromNode`` maps to the first coordinate of its LineString
geometry, and ``toNode`` to the last coordinate.  The importance score of a
node is the sum of ``speed × capacity`` over all links incident on that node.

Supports both directed-network format (``speed``, ``capacity``) produced by
``bidirectional_splitter`` and raw-network format (``max_snelheid_heen``,
``cap_heen``) produced by ``osm_network_fetcher``.

Public API
----------
NodeInfo
    NamedTuple: node_id (str), lon (float), lat (float), score (float).
extract_nodes(network_fc) -> dict[str, NodeInfo]
    Return a mapping of node_id → NodeInfo for every node in the network.
"""

from __future__ import annotations

import math
from typing import NamedTuple

__all__ = ["NodeInfo", "extract_nodes"]


class NodeInfo(NamedTuple):
    node_id: str
    lon: float
    lat: float
    score: float


def _link_score(props: dict) -> float:
    """Return speed × capacity for a single link.

    Tries directed-network fields first (``speed``, ``capacity``), then falls
    back to raw-network fields (``max_snelheid_heen`` / ``cap_heen``).
    Returns 0.0 if neither set is present.
    """
    speed = props.get("speed")
    cap = props.get("capacity")
    if speed is None:
        speed = props.get("max_snelheid_heen") or props.get("max_snelheid_terug") or 0.0
    if cap is None:
        cap = props.get("cap_heen") or props.get("cap_terug") or 0.0
    return float(speed or 0.0) * float(cap or 0.0)


def extract_nodes(network_fc: dict) -> dict[str, NodeInfo]:
    """Build a node index from a network GeoJSON FeatureCollection.

    Parameters
    ----------
    network_fc:
        GeoJSON FeatureCollection where each Feature is a directed link with
        ``fromNode`` / ``toNode`` properties and a LineString geometry.

    Returns
    -------
    dict mapping node_id → NodeInfo (lon, lat, accumulated score).
    The score is the sum of ``speed × capacity`` for every incident link.
    Nodes with no score contribution get score 0.0.
    """
    coords: dict[str, tuple[float, float]] = {}
    scores: dict[str, float] = {}

    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        geom = feat.get("geometry") or {}
        if geom.get("type") != "LineString":
            continue
        coord_list: list[list[float]] = geom.get("coordinates") or []
        if len(coord_list) < 2:
            continue

        from_id = str(props.get("fromNode") or "").strip()
        to_id = str(props.get("toNode") or "").strip()
        if not from_id or not to_id:
            continue

        # Derive node coordinates from link endpoints.
        if from_id not in coords:
            c = coord_list[0]
            coords[from_id] = (float(c[0]), float(c[1]))
        if to_id not in coords:
            c = coord_list[-1]
            coords[to_id] = (float(c[0]), float(c[1]))

        score = _link_score(props)
        scores[from_id] = scores.get(from_id, 0.0) + score
        scores[to_id] = scores.get(to_id, 0.0) + score

    return {
        nid: NodeInfo(
            node_id=nid,
            lon=lon,
            lat=lat,
            score=scores.get(nid, 0.0),
        )
        for nid, (lon, lat) in coords.items()
        if not (math.isnan(lon) or math.isnan(lat))
    }
