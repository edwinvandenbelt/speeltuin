"""Match each zone polygon to the best network node.

"Best" is defined as the node with the highest importance score (speed ×
capacity) that lies *inside* the zone polygon.  If no network node falls
inside the zone, the nearest node to the zone centroid is used as a fallback.

Public API
----------
find_best_node(zone_feature, nodes) -> NodeInfo
    Return the best NodeInfo for a single zone GeoJSON Feature.
"""

from __future__ import annotations

import math

from osm.osm_feedlink_creator.domain.network_nodes import NodeInfo

__all__ = ["find_best_node"]

# ---------------------------------------------------------------------------
# Geometry helpers (pure Python — no shapely dependency in core)
# ---------------------------------------------------------------------------


def _point_in_polygon(lon: float, lat: float, ring: list[list[float]]) -> bool:
    """Ray-casting point-in-polygon test for a single exterior ring."""
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if ((yi > lat) != (yj > lat)) and (lon < (xj - xi) * (lat - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside


def _contains(zone_geom: dict, lon: float, lat: float) -> bool:
    """Return True if (lon, lat) is inside the zone geometry (Polygon only)."""
    gtype = zone_geom.get("type")
    coords = zone_geom.get("coordinates") or []
    if gtype == "Polygon" and coords:
        exterior: list[list[float]] = coords[0]
        if not _point_in_polygon(lon, lat, exterior):
            return False
        # Test that the point is NOT inside any hole.
        for hole in coords[1:]:
            if _point_in_polygon(lon, lat, hole):
                return False
        return True
    return False


def _haversine_m(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """Haversine distance in metres between two WGS-84 points."""
    r = 6_371_000.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def find_best_node(zone_feature: dict, nodes: dict[str, NodeInfo]) -> NodeInfo | None:
    """Return the best network node for a zone.

    Strategy
    --------
    1. Collect all nodes whose coordinates fall inside the zone polygon.
    2. Return the node with the highest ``score`` (speed × capacity).
    3. If no node is inside the polygon, return the nearest node to the
       zone centroid as a fallback.

    Parameters
    ----------
    zone_feature:
        A GeoJSON Feature with Polygon geometry and properties including
        ``centroidLon`` and ``centroidLat``.
    nodes:
        Node index as returned by ``extract_nodes``.

    Returns
    -------
    NodeInfo or None if the nodes dict is empty.
    """
    if not nodes:
        return None

    props = zone_feature.get("properties") or {}
    centroid_lon = float(props.get("centroidLon") or 0.0)
    centroid_lat = float(props.get("centroidLat") or 0.0)
    geom = zone_feature.get("geometry") or {}

    # Pass 1 — candidates inside the polygon.
    inside: list[NodeInfo] = [n for n in nodes.values() if _contains(geom, n.lon, n.lat)]

    if inside:
        return max(inside, key=lambda n: n.score)

    # Fallback — nearest node to centroid.
    return min(
        nodes.values(),
        key=lambda n: _haversine_m(centroid_lon, centroid_lat, n.lon, n.lat),
    )
