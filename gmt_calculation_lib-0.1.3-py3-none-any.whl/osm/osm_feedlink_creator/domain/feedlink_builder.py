"""Build feedlink GeoJSON Feature pairs for a zone.

Each zone gets two feedlinks:
- **Production** link: virtual zone-centroid node  →  network attachment node
- **Attraction** link: network attachment node  →  virtual zone-centroid node

The virtual zone-centroid node ID is ``"ZONE_{zoneId}"``.  Because real OSM
node IDs are integers, this string prefix guarantees no collision with the
real network.

The ``build_graph`` function in ``od_support_matrices_creator`` infers
feedlink direction automatically by checking which node appears in the real
network, so the zone-centroid node just needs to be absent from the network.

Properties on every feedlink feature
--------------------------------------
``zoneId``    – zone identifier
``fromNode``  – origin node ID
``toNode``    – destination node ID
``length``    – Haversine distance (metres) between centroid and network node
``capacity``  – fixed at DEFAULT_CAPACITY (9999 cars/h)
``flow``      – fixed at 0.0

Public API
----------
FEEDLINK_PROPERTIES: tuple[str, ...]
build_feedlink_pair(zone_id, centroid_lon, centroid_lat, node) -> list[dict]
"""

from __future__ import annotations

import math

from osm.osm_feedlink_creator.domain.network_nodes import NodeInfo

__all__ = ["FEEDLINK_PROPERTIES", "DEFAULT_CAPACITY", "build_feedlink_pair"]

FEEDLINK_PROPERTIES: tuple[str, ...] = (
    "zoneId",
    "fromNode",
    "toNode",
    "length",
    "capacity",
    "flow",
)

DEFAULT_CAPACITY: float = 9999.0
DEFAULT_FLOW: float = 0.0


def _haversine_m(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """Haversine distance in metres between two WGS-84 points."""
    r = 6_371_000.0
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlam = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlam / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def build_feedlink_pair(
    zone_id: str,
    centroid_lon: float,
    centroid_lat: float,
    node: NodeInfo,
) -> list[dict]:
    """Return the production and attraction feedlink Features for one zone.

    Parameters
    ----------
    zone_id:
        Zone identifier string (e.g. ``"deventer_0"``).
    centroid_lon / centroid_lat:
        WGS-84 coordinates of the zone centroid.
    node:
        The selected network attachment node.

    Returns
    -------
    list of two GeoJSON Feature dicts (production first, then attraction).
    """
    zone_node_id = f"ZONE_{zone_id}"
    length_m = round(_haversine_m(centroid_lon, centroid_lat, node.lon, node.lat), 2)

    centroid_coord = [centroid_lon, centroid_lat]
    node_coord = [node.lon, node.lat]

    production = {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [centroid_coord, node_coord],
        },
        "properties": {
            "zoneId": zone_id,
            "fromNode": zone_node_id,
            "toNode": node.node_id,
            "length": length_m,
            "capacity": DEFAULT_CAPACITY,
            "flow": DEFAULT_FLOW,
        },
    }
    attraction = {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [node_coord, centroid_coord],
        },
        "properties": {
            "zoneId": zone_id,
            "fromNode": node.node_id,
            "toNode": zone_node_id,
            "length": length_m,
            "capacity": DEFAULT_CAPACITY,
            "flow": DEFAULT_FLOW,
        },
    }
    return [production, attraction]
