# src/osm_network_fetcher/core/__init__.py
