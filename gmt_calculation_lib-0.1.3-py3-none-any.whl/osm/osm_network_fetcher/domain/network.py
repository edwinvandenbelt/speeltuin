"""OSM tag → LINK_PROPERTIES feature conversion for osm_network_fetcher.

Converts Overpass way segments (output of :mod:`way_splitter`) into GeoJSON
features that match the NETWORK-RAW LINK_PROPERTIES schema consumed by
``bidirectional_splitter``.

Public API
----------
LINK_PROPERTIES: tuple[str, ...]
    Ordered property keys for every NETWORK-RAW feature.
parse_maxspeed(tag, highway) -> float | None
    Parse an OSM maxspeed tag to km/h.
build_feature(segment, mode) -> dict
    Build a single LINK_PROPERTIES GeoJSON Feature from a way segment.
ways_to_features(elements, mode) -> list[dict]
    Convert all Overpass elements to LINK_PROPERTIES features for one mode.
"""

from __future__ import annotations

import logging
import re

from osm.osm_network_fetcher.domain.way_splitter import segment_length_m

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# LINK_PROPERTIES schema — identical to network_fetcher.domain.network
# ---------------------------------------------------------------------------

LINK_PROPERTIES: tuple[str, ...] = (
    "linkId",  # OSM way ID or "{way_id}_{segment_index}"
    "mode",  # "CAR" | "BIKE" | "PEDESTRIAN"
    "fromNode",  # OSM start-node ID (int); 0 for PEDESTRIAN
    "toNode",  # OSM end-node ID (int); 0 for PEDESTRIAN
    "rijrichting_heen",  # bool — forward direction passable
    "cap_heen",  # float | None; None → splitter estimates
    "rijstroken_heen",  # int | None
    "max_snelheid_heen",  # float | None (km/h)
    "flow_heen",  # {work, recreational, education, shopping, unknown}
    "flow_dp_heen",  # {mrh, erh, rest}
    "rijrichting_terug",  # bool — return direction passable
    "cap_terug",  # float | None
    "rijstroken_terug",  # int | None
    "max_snelheid_terug",  # float | None (km/h)
    "flow_terug",  # same structure as flow_heen
    "flow_dp_terug",  # same structure as flow_dp_heen
    "length",  # float (metres, Haversine)
    "highway",  # OSM highway tag value, e.g. "residential", "primary"
    "ref",  # OSM ref tag, e.g. "A1", "N337" (empty string when absent)
    "name",  # OSM name tag, e.g. "Dorpsstraat" (empty string when absent)
    # --- optional OSM attributes (only present when the OSM tag exists) ---
    "surface",  # str  — e.g. "asphalt", "cobblestone", "gravel"
    "width",  # float — carriageway width in metres
    "lit",  # str  — "yes" | "no"
    "bridge",  # str  — "yes" | "1"
    "tunnel",  # str  — "yes" | "1"
    "layer",  # str  — vertical layer, e.g. "-1", "0", "1"
    "sidewalk",  # str  — "both" | "left" | "right" | "none"
)

# Properties that are always present on every feature (subset of LINK_PROPERTIES).
LINK_MANDATORY_PROPERTIES: tuple[str, ...] = LINK_PROPERTIES[:20]

# Properties that are only present when the corresponding OSM tag exists.
LINK_OPTIONAL_PROPERTIES: tuple[str, ...] = LINK_PROPERTIES[20:]

# OSM tags mapped 1-to-1 to optional output properties.
# "width" is handled separately (parsed to float).
_OSM_EXTRA_STR_TAGS: tuple[str, ...] = ("surface", "lit", "bridge", "tunnel", "layer", "sidewalk")

# ---------------------------------------------------------------------------
# Speed defaults per highway type (km/h)
# ---------------------------------------------------------------------------

_SPEED_DEFAULTS: dict[str, float] = {
    "motorway": 120.0,
    "motorway_link": 120.0,
    "trunk": 100.0,
    "trunk_link": 100.0,
    "primary": 80.0,
    "primary_link": 80.0,
    "secondary": 60.0,
    "secondary_link": 60.0,
    "tertiary": 50.0,
    "tertiary_link": 50.0,
    "unclassified": 40.0,
    "residential": 30.0,
    "living_street": 15.0,
    "service": 20.0,
    # Bike / pedestrian fallbacks
    "cycleway": 15.0,
    "path": 10.0,
    "track": 10.0,
    "footway": 5.0,
    "pedestrian": 5.0,
    "steps": 2.0,
}

# ---------------------------------------------------------------------------
# Zero-flow factory functions (return new dict each call)
# ---------------------------------------------------------------------------


def _zero_flow() -> dict[str, int]:
    return {}


def _zero_dp() -> dict[str, int]:
    return {"mrh": 0, "erh": 0, "rest": 0}


# ---------------------------------------------------------------------------
# Tag parsing helpers
# ---------------------------------------------------------------------------

_NAMED_SPEEDS: dict[str, float] = {
    "walk": 7.0,
    "walking": 7.0,
    "foot": 7.0,
    "bicycle": 15.0,
    "cycling": 15.0,
}

_ONEWAY_YES: frozenset[str] = frozenset({"yes", "1", "true"})
_ONEWAY_NO: frozenset[str] = frozenset({"no", "0", "false"})

# ---------------------------------------------------------------------------
# Width tag parser
# ---------------------------------------------------------------------------

_WIDTH_RE = re.compile(r"^\s*(\d+(?:[.,]\d+)?)\s*(?:m(?:eters?)?)?\s*$", re.IGNORECASE)


def _parse_width(tag: str | None) -> float | None:
    """Parse an OSM ``width`` tag to a float number of metres.

    Accepts formats like ``"5"``, ``"5.5"``, ``"5,5"``, ``"5 m"``, ``"5.5m"``.
    Returns ``None`` for absent, empty, or non-numeric values (e.g. ``"narrow"``).
    """
    if not tag:
        return None
    m = _WIDTH_RE.match(tag.strip())
    if not m:
        return None
    try:
        return float(m.group(1).replace(",", "."))
    except ValueError:
        return None


def parse_maxspeed(tag: str | None, highway: str) -> float | None:
    """Parse an OSM ``maxspeed`` tag to km/h.

    Parameters
    ----------
    tag:
        Raw OSM maxspeed tag value, e.g. ``"50"``, ``"30 mph"``, ``"DE:rural"``.
    highway:
        OSM highway tag value, used to look up the default speed as a fallback.

    Returns
    -------
    Speed in km/h, or ``None`` when the tag is ``"none"`` / ``"unlimited"``.
    """
    if not tag:
        return _SPEED_DEFAULTS.get(highway)
    tag = tag.strip()
    lc = tag.lower()
    if lc in ("none", "unlimited", ""):
        return None
    if lc in _NAMED_SPEEDS:
        return _NAMED_SPEEDS[lc]
    # "50 mph" or "50mph"
    m = re.match(r"^(\d+(?:\.\d+)?)\s*mph$", tag, re.IGNORECASE)
    if m:
        return round(float(m.group(1)) * 1.60934, 1)
    # Plain integer or float
    m = re.match(r"^(\d+(?:\.\d+)?)$", tag)
    if m:
        return float(m.group(1))
    # Country-specific code like "DE:rural" → highway-class default
    return _SPEED_DEFAULTS.get(highway)


def _parse_lanes(tags: dict, direction_key: str) -> int:
    """Return lane count for *direction_key*, defaulting to 1.

    Falls back to ``lanes // 2`` when the direction-specific key is absent,
    and to 1 when no usable lane tag exists at all.
    """
    val = tags.get(direction_key)
    if val is not None:
        try:
            return max(1, int(val))
        except ValueError, TypeError:
            pass
    val = tags.get("lanes")
    if val is not None:
        try:
            total = int(val)
            return max(1, total // 2) if total >= 2 else 1  # noqa: PLR2004
        except ValueError, TypeError:
            pass
    return 1


# ---------------------------------------------------------------------------
# Direction helpers
# ---------------------------------------------------------------------------


def _car_directions(tags: dict) -> tuple[bool, bool]:
    """Return (rijrichting_heen, rijrichting_terug) for a CAR segment."""
    ow = tags.get("oneway", "").lower()
    omv = tags.get("oneway:motor_vehicle", "").lower()

    if ow in _ONEWAY_YES or omv in _ONEWAY_YES:
        return True, False
    if ow == "-1" or omv == "-1":
        return False, True
    return True, True


def _bike_directions(tags: dict) -> tuple[bool, bool]:
    """Return (rijrichting_heen, rijrichting_terug) for a BIKE segment.

    Bikes may legally cycle against a car-oneway street unless
    ``oneway:bicycle`` restricts this.
    """
    ow = tags.get("oneway", "").lower()
    ob = tags.get("oneway:bicycle", "").lower()

    # Explicit bicycle oneway overrides everything
    if ob in _ONEWAY_YES:
        return True, False
    if ob == "-1":
        return False, True

    # Car oneway: bikes can go backward only if oneway:bicycle=no
    if ow in _ONEWAY_YES:
        return True, ob in _ONEWAY_NO

    if ow == "-1":
        return ob in _ONEWAY_NO, True

    # Bidirectional or no oneway tag
    return True, True


# ---------------------------------------------------------------------------
# Feature builder
# ---------------------------------------------------------------------------


def build_feature(segment: dict, mode: str) -> dict:
    """Convert a way segment to a LINK_PROPERTIES GeoJSON Feature.

    Parameters
    ----------
    segment:
        Segment dict from :func:`~osm_network_fetcher.domain.way_splitter.split_way`
        (keys: ``way_id``, ``segment_index``, ``from_node_id``, ``to_node_id``,
        ``coords``, ``tags``).
    mode:
        Transport mode: ``"CAR"``, ``"BIKE"``, or ``"PEDESTRIAN"``.

    Returns
    -------
    GeoJSON Feature dict with LINK_PROPERTIES properties.
    """
    tags: dict = segment["tags"]
    coords: list[tuple[float, float]] = segment["coords"]
    way_id: int = segment["way_id"]
    seg_idx: int = segment["segment_index"]
    from_nid: int = segment["from_node_id"]
    to_nid: int = segment["to_node_id"]

    hw = tags.get("highway", "")
    road_ref: str = tags.get("ref", "")
    road_name: str = tags.get("name", "")
    length = segment_length_m(coords)

    # Link ID: integer for uniform output with the normal (Databricks) prepare pipeline.
    # Unsplit way → bare way_id; split way → way_id * 1000 + segment_index.
    # The bidirectional_splitter then uses arithmetic negation for the return direction,
    # matching the -linkId convention of the normal prepare.
    link_id: int = way_id if seg_idx == 0 else way_id * 1000 + seg_idx

    if mode == "PEDESTRIAN":
        max_spd: float | None = 5.0
        lanes_heen: int | None = 1
        lanes_terug: int | None = 1
        rr_heen = True
        rr_terug = True
        flow_heen = _zero_flow()
        flow_terug = _zero_flow()
        from_node: int = 0
        to_node: int = 0

    elif mode == "BIKE":
        raw_spd = tags.get("maxspeed:bicycle") or tags.get("maxspeed")
        max_spd = parse_maxspeed(raw_spd, hw) or 15.0
        lanes_heen = _parse_lanes(tags, "lanes:bicycle") or 1
        lanes_terug = lanes_heen
        rr_heen, rr_terug = _bike_directions(tags)
        flow_heen = {"unknown": 1 if rr_heen else 0}
        flow_terug = {"unknown": 1 if rr_terug else 0}
        from_node = from_nid
        to_node = to_nid

    else:  # CAR
        max_spd = parse_maxspeed(tags.get("maxspeed"), hw)
        lanes_heen = _parse_lanes(tags, "lanes:forward")
        lanes_terug = _parse_lanes(tags, "lanes:backward")
        rr_heen, rr_terug = _car_directions(tags)
        flow_heen = _zero_flow()
        flow_terug = _zero_flow()
        from_node = from_nid
        to_node = to_nid

    props: dict = {
        "linkId": link_id,
        "mode": mode,
        "fromNode": from_node,
        "toNode": to_node,
        "rijrichting_heen": rr_heen,
        "cap_heen": None,
        "rijstroken_heen": lanes_heen,
        "max_snelheid_heen": max_spd,
        "flow_heen": flow_heen,
        "flow_dp_heen": _zero_dp(),
        "rijrichting_terug": rr_terug,
        "cap_terug": None,
        "rijstroken_terug": lanes_terug,
        "max_snelheid_terug": max_spd,
        "flow_terug": flow_terug,
        "flow_dp_terug": _zero_dp(),
        "length": round(length, 2),
        "highway": hw,
        "ref": road_ref,
        "name": road_name,
    }

    # Optional OSM attributes — only included when the tag is present.
    for _tag in _OSM_EXTRA_STR_TAGS:
        if _tag in tags:
            props[_tag] = tags[_tag]
    _width = _parse_width(tags.get("width"))
    if _width is not None:
        props["width"] = _width

    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [list(c) for c in coords],
        },
        "properties": props,
    }


# ---------------------------------------------------------------------------
# Public batch conversion
# ---------------------------------------------------------------------------


def ways_to_features(elements: list[dict], mode: str) -> list[dict]:
    """Convert Overpass response elements to LINK_PROPERTIES features for *mode*.

    Parameters
    ----------
    elements:
        Raw Overpass API response elements (nodes + ways).
    mode:
        ``"CAR"``, ``"BIKE"``, or ``"PEDESTRIAN"``.

    Returns
    -------
    List of GeoJSON Feature dicts conforming to LINK_PROPERTIES.
    """
    from osm.osm_network_fetcher.domain.mode_filter import is_way_for_mode  # noqa: PLC0415
    from osm.osm_network_fetcher.domain.way_splitter import split_all_ways  # noqa: PLC0415

    # Keep only nodes and ways that pass the mode filter
    filtered: list[dict] = [
        e
        for e in elements
        if e.get("type") == "node"
        or (e.get("type") == "way" and is_way_for_mode(e.get("tags") or {}, mode))
    ]

    segments = split_all_ways(filtered)
    features: list[dict] = []
    skipped = 0
    for seg in segments:
        if len(seg.get("coords") or []) < 2:  # noqa: PLR2004
            skipped += 1
            continue
        try:
            feat = build_feature(seg, mode)
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "Skipped segment way=%s seg=%s: %s",
                seg.get("way_id"),
                seg.get("segment_index"),
                exc,
            )
            skipped += 1
            continue
        features.append(feat)

    if skipped:
        logger.info("Skipped %d segments for mode %s (too short or error)", skipped, mode)
    return features
