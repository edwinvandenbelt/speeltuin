"""Overpass API query builders for osm_network_fetcher.

Constructs Overpass QL queries that fetch road/path ways for one or more
transport modes within a bounding box.
"""

from __future__ import annotations

CAR_HIGHWAY_FILTER = (
    "motorway|motorway_link|trunk|trunk_link|primary|primary_link|"
    "secondary|secondary_link|tertiary|tertiary_link|unclassified|"
    "residential|living_street|service"
)

BIKE_HIGHWAY_FILTER = CAR_HIGHWAY_FILTER + "|cycleway|path|track"

PEDESTRIAN_HIGHWAY_FILTER = "footway|path|pedestrian|steps|track"

VALID_MODES: frozenset[str] = frozenset({"CAR", "BIKE", "PEDESTRIAN"})


def build_network_query(bbox: list[float], modes: list[str]) -> str:
    """Build an Overpass QL query for road ways within a bounding box.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS 84.
    modes:
        Subset of ``["CAR", "BIKE", "PEDESTRIAN"]``.

    Returns
    -------
    Overpass QL query string that returns ways + their nodes with geometry.

    Raises
    ------
    ValueError:
        If *modes* is empty or contains only unsupported values.
    """
    # Overpass bbox order: south, west, north, east
    s, w, n, e = bbox[1], bbox[0], bbox[3], bbox[2]
    coord_str = f"{s},{w},{n},{e}"

    parts: list[str] = []
    if "CAR" in modes:
        parts.append(f'way["highway"~"^({CAR_HIGHWAY_FILTER})$"]({coord_str});')
    if "BIKE" in modes:
        parts.append(f'way["highway"~"^({BIKE_HIGHWAY_FILTER})$"]({coord_str});')
    if "PEDESTRIAN" in modes:
        parts.append(f'way["highway"~"^({PEDESTRIAN_HIGHWAY_FILTER})$"]({coord_str});')

    if not parts:
        raise ValueError(f"No valid modes in: {modes!r}. Supported: {sorted(VALID_MODES)}")

    union = "\n  ".join(parts)
    return f"""[out:json][timeout:90];
(
  {union}
);
(._;>;);
out geom;"""
