# src/osm_network_fetcher/domain/__init__.py
