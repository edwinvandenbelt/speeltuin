"""Unit tests for osm_network_fetcher.domain.way_splitter — pure Python, no I/O."""

from __future__ import annotations

import math

import pytest

from osm_network_fetcher.domain.way_splitter import (
    _build_node_use_count,
    haversine_m,
    segment_length_m,
    split_all_ways,
    split_way,
)


# ---------------------------------------------------------------------------
# haversine_m
# ---------------------------------------------------------------------------


class TestHaversineM:
    def test_same_point_is_zero(self):
        assert haversine_m(6.0, 52.0, 6.0, 52.0) == pytest.approx(0.0)

    def test_one_degree_latitude_approx_111km(self):
        d = haversine_m(6.0, 52.0, 6.0, 53.0)
        assert 110_000 < d < 112_000

    def test_one_degree_longitude_at_52_lat(self):
        d = haversine_m(6.0, 52.0, 7.0, 52.0)
        # cos(52°) * 111 km ≈ 68 km
        assert 67_000 < d < 70_000

    def test_symmetric(self):
        a = haversine_m(6.0, 52.0, 6.1, 52.1)
        b = haversine_m(6.1, 52.1, 6.0, 52.0)
        assert a == pytest.approx(b)


class TestSegmentLengthM:
    def test_single_segment(self):
        coords = [(6.0, 52.0), (6.0, 53.0)]
        d = segment_length_m(coords)
        assert 110_000 < d < 112_000

    def test_two_segments_additive(self):
        c = [(6.0, 52.0), (6.0, 52.5), (6.0, 53.0)]
        total = segment_length_m(c)
        first = haversine_m(6.0, 52.0, 6.0, 52.5)
        second = haversine_m(6.0, 52.5, 6.0, 53.0)
        assert total == pytest.approx(first + second, rel=1e-6)

    def test_empty_coords_is_zero(self):
        assert segment_length_m([]) == pytest.approx(0.0)

    def test_single_point_is_zero(self):
        assert segment_length_m([(6.0, 52.0)]) == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# _build_node_use_count
# ---------------------------------------------------------------------------


class TestBuildNodeUseCount:
    def test_single_way(self):
        ways = [{"type": "way", "nodes": [1, 2, 3]}]
        count = _build_node_use_count(ways)
        assert count == {1: 1, 2: 1, 3: 1}

    def test_shared_node_counted_twice(self):
        ways = [
            {"type": "way", "nodes": [1, 2, 3]},
            {"type": "way", "nodes": [3, 4, 5]},
        ]
        count = _build_node_use_count(ways)
        assert count[3] == 2

    def test_empty_ways(self):
        assert _build_node_use_count([]) == {}


# ---------------------------------------------------------------------------
# split_way
# ---------------------------------------------------------------------------


def _make_way(way_id, node_ids, tags=None):
    """Build a minimal Overpass way element with embedded geometry."""
    geom = [{"lon": float(i), "lat": float(i)} for i in range(len(node_ids))]
    return {
        "type": "way",
        "id": way_id,
        "nodes": node_ids,
        "geometry": geom,
        "tags": tags or {"highway": "residential"},
    }


class TestSplitWay:
    def test_isolated_way_no_split(self):
        """A way whose interior nodes appear in no other way → 1 segment."""
        way = _make_way(1, [10, 11, 12, 13])
        count = {10: 1, 11: 1, 12: 1, 13: 1}
        segs = split_way(way, count)
        assert len(segs) == 1
        assert segs[0]["from_node_id"] == 10
        assert segs[0]["to_node_id"] == 13
        assert segs[0]["segment_index"] == 0

    def test_split_at_single_intersection(self):
        """Way A–B–C–D–E where B is also in another way → 2 segments: A–B and B–C–D–E."""
        way = _make_way(1, [10, 11, 12, 13, 14])
        count = {10: 1, 11: 2, 12: 1, 13: 1, 14: 1}  # node 11 is shared
        segs = split_way(way, count)
        assert len(segs) == 2
        assert segs[0]["from_node_id"] == 10
        assert segs[0]["to_node_id"] == 11
        assert segs[1]["from_node_id"] == 11
        assert segs[1]["to_node_id"] == 14

    def test_split_at_two_intersections(self):
        """Way [A,B,C,D,E] where B and D are shared → 3 segments."""
        way = _make_way(1, [10, 11, 12, 13, 14])
        count = {10: 1, 11: 2, 12: 1, 13: 2, 14: 1}
        segs = split_way(way, count)
        assert len(segs) == 3
        assert segs[0]["to_node_id"] == 11
        assert segs[1]["from_node_id"] == 11
        assert segs[1]["to_node_id"] == 13
        assert segs[2]["from_node_id"] == 13

    def test_last_node_intersection_no_split(self):
        """Intersection at the last node only → still 1 segment (last node always ends)."""
        way = _make_way(1, [10, 11, 12])
        count = {10: 1, 11: 1, 12: 2}
        segs = split_way(way, count)
        assert len(segs) == 1

    def test_segment_index_increments(self):
        way = _make_way(1, [1, 2, 3, 4, 5])
        count = {1: 1, 2: 2, 3: 1, 4: 2, 5: 1}
        segs = split_way(way, count)
        for i, seg in enumerate(segs):
            assert seg["segment_index"] == i

    def test_coords_length_matches_nodes(self):
        way = _make_way(1, [1, 2, 3, 4])
        count = {1: 1, 2: 2, 3: 1, 4: 1}
        segs = split_way(way, count)
        # Segment 0: nodes 1–2 → 2 coords
        assert len(segs[0]["coords"]) == 2
        # Segment 1: nodes 2–3–4 → 3 coords
        assert len(segs[1]["coords"]) == 3

    def test_tags_inherited(self):
        tags = {"highway": "primary", "maxspeed": "80"}
        way = _make_way(1, [1, 2, 3], tags=tags)
        count = {1: 1, 2: 2, 3: 1}
        segs = split_way(way, count)
        for seg in segs:
            assert seg["tags"] == tags

    def test_way_too_short_returns_empty(self):
        way = {"type": "way", "id": 1, "nodes": [1], "geometry": [{"lon": 0, "lat": 0}], "tags": {}}
        count = {1: 1}
        assert split_way(way, count) == []


# ---------------------------------------------------------------------------
# split_all_ways
# ---------------------------------------------------------------------------


class TestSplitAllWays:
    def test_ignores_node_elements(self):
        elements = [
            {"type": "node", "id": 99, "lat": 52.0, "lon": 6.0},
            _make_way(1, [10, 11, 12]),
        ]
        segs = split_all_ways(elements)
        assert all(s["way_id"] == 1 for s in segs)

    def test_two_ways_sharing_node(self):
        """Two ways sharing node 11 → each splits at 11."""
        elements = [
            _make_way(1, [10, 11, 12]),
            _make_way(2, [11, 13, 14]),
        ]
        segs = split_all_ways(elements)
        # Way 1: node 11 is intermediate and shared → splits into [10,11] and [11,12]
        way1_segs = [s for s in segs if s["way_id"] == 1]
        assert len(way1_segs) == 2

    def test_empty_elements(self):
        assert split_all_ways([]) == []
