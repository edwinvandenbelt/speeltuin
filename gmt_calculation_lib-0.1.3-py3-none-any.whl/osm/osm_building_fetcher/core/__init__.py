# src/osm_building_fetcher/core/__init__.py
