"""OSM Building Fetcher core — fetches, classifies and links buildings.

Downloads buildings and streets from the Overpass API for a bounding box,
classifies each building (school / house / hospital / recreational /
shopping / work / parking / other) and links it to a street by name-match
or nearest centroid.  Parking elements (surface lots, P+R) that carry no
``building`` tag are included via :func:`is_parking_element`.  Work/office
elements that carry only an ``office=`` tag are included via
:func:`is_work_element`.

For generic buildings (``building=yes``, ``building=house``, etc.) the
classification is refined using spatial containment: standalone POI nodes
(amenity / shop / tourism / leisure nodes without a ``building=`` tag) that
lie inside the building polygon are discovered and their use tags may
override the default residential classification.

Mixed-use buildings
-------------------
When a generic building contains a non-residential POI (e.g. a restaurant
node inside a ``building=house`` polygon), the building is split into two
GeoJSON features representing the different floor uses:

* 1 floor  → the non-residential use (POI type)
* remaining floors → ``house`` (residential)

The number of floors is read from the OSM ``building:levels`` tag; when
absent a default of **2** is assumed.  For single-floor buildings (``building:
levels=1``) only the POI type is emitted — no residential feature.

Each split feature carries a ``floorFraction`` property (``0 < f ≤ 1``) so
that downstream consumers (e.g. ``assign_buildings_to_links``) can scale the
footprint m² to the correct usable floor area per use type.

Output is a GeoJSON FeatureCollection ready for serialisation as GeoParquet.

Public API
----------
build_buildings(bbox, *, overpass_url, timeout) -> tuple[dict, dict]
    Fetch, classify, and link buildings.
    Returns (feature_collection, stats).
    stats: {"total": int, "buildings": int, "streets": int, "by_type": dict}
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

from shared.overpass import DEFAULT_OVERPASS_URL, fetch_overpass_tiled  # noqa: E402

from osm.osm_building_fetcher.domain.classifier import (
    classify_building_with_pois,
    is_parking_element,
    is_poi_node,
    is_work_element,
)
from osm.osm_building_fetcher.domain.containment import find_pois_in_building
from osm.osm_building_fetcher.domain.geometry import element_to_feature
from osm.osm_building_fetcher.domain.overpass import (
    DEFAULT_TIMEOUT,
    build_buildings_and_streets_query,
)
from osm.osm_building_fetcher.domain.street_linker import link_buildings_to_streets

_DEFAULT_OVERPASS_URL = DEFAULT_OVERPASS_URL

# building= tags for which POI containment analysis is performed.
# These are "generic" structural tags that do not specify the actual use.
_GENERIC_BUILDING_TAGS: frozenset[str] = frozenset(
    {
        "yes",
        "house",
        "residential",
        "apartments",
        "detached",
        "terrace",
        "semi_detached",
        "bungalow",
        "dormitory",
        "block_of_flats",
        "static_caravan",
        "cabin",
        "farm",
    }
)

# Default number of floors assumed when ``building:levels`` tag is absent.
_DEFAULT_BUILDING_LEVELS: int = 2

# Default NxN Overpass tile grid.  Large areas are split into tiles so that no
# single Overpass request has to return the whole area at once (which risks
# server-side timeouts / rate-limiting).  All tiles are merged (deduplicated by
# element id) into a single FeatureCollection.
OVERPASS_GRID: int = 5


def _building_levels(tags: dict[str, str]) -> int:
    """Return the number of floors from ``building:levels``, defaulting to 2."""
    raw = tags.get("building:levels", "").strip()
    if not raw:
        return _DEFAULT_BUILDING_LEVELS
    try:
        return max(1, int(float(raw)))
    except ValueError, TypeError:
        return _DEFAULT_BUILDING_LEVELS


def _make_mixed_use_features(
    element: dict,
    poi_type: str,
    street_name: str | None,
    street_id: str | None,
) -> list[dict]:
    """Build split GeoJSON features for a mixed-use generic building.

    Splits the building into a non-residential (POI) feature and, when the
    building has more than one floor, a residential (house) feature.

    Floor fractions
    ---------------
    * POI use  : ``1 / levels``
    * House    : ``(levels - 1) / levels``

    ``building:levels`` is read from the element's tags; defaults to 2.

    Parameters
    ----------
    element:
        Overpass building element (way or node).
    poi_type:
        Non-residential building type determined from contained POIs
        (e.g. ``'recreational'``, ``'shopping'``, ``'work'``).
    street_name, street_id:
        Street association for both split features.

    Returns
    -------
    list[dict]
        One feature (single-floor) or two features (multi-floor).
    """
    tags: dict[str, str] = element.get("tags") or {}
    levels = _building_levels(tags)

    poi_fraction = 1.0 / levels
    house_fraction = (levels - 1) / levels

    poi_feature = element_to_feature(
        element,
        poi_type,
        street_name,
        street_id,
        floor_fraction=poi_fraction,
        id_suffix=f"_{poi_type}",
    )

    if levels == 1:
        # Single-floor: entirely the non-residential use
        return [poi_feature]

    house_feature = element_to_feature(
        element,
        "house",
        street_name,
        street_id,
        floor_fraction=house_fraction,
        id_suffix="_house",
    )
    return [poi_feature, house_feature]


def build_buildings(
    bbox: list[float],
    *,
    overpass_url: str = _DEFAULT_OVERPASS_URL,
    timeout: int = DEFAULT_TIMEOUT,
    tiles: int = OVERPASS_GRID,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> tuple[dict, dict]:
    """Fetch buildings and streets from Overpass, classify and link.

    Parameters
    ----------
    bbox:
        Bounding box ``[minLon, minLat, maxLon, maxLat]``.
    overpass_url:
        Overpass API endpoint URL.
    timeout:
        Overpass query timeout in seconds.
    tiles:
        NxN Overpass tile grid.  The bbox is split into ``tiles x tiles``
        sub-bboxes that are fetched separately and merged (deduplicated by
        element id) so that large areas do not overload the Overpass server.
        ``tiles=1`` performs a single, untiled query.

    Returns
    -------
    fc:
        GeoJSON FeatureCollection where each Feature represents one OSM
        building use type.  Mixed-use buildings (generic residential +
        POI inside) produce two features from the same element.
        Properties include ``buildingId``, ``buildingType``,
        ``floorFraction``, ``streetName``, ``streetId``, and all original
        OSM tags prefixed with ``tag_``.
    stats:
        ``{"total": int, "buildings": int, "streets": int, "tiles": int,
        "by_type": dict}``
    """
    logger.info(
        "Fetching buildings + streets via Overpass  bbox=%s  url=%s  tiles=%dx%d",
        bbox,
        overpass_url,
        tiles,
        tiles,
    )
    data = fetch_overpass_tiled(
        lambda b: build_buildings_and_streets_query(b, timeout=timeout),
        bbox,
        tiles=(tiles, tiles),
        url=overpass_url,
        timeout=timeout,
        osm_path=osm_path, osm_workers=osm_workers,
    )
    elements: list[dict] = data.get("elements") or []

    # ── Split raw elements ───────────────────────────────────────────────────
    buildings: list[dict] = []
    poi_nodes: list[dict] = []
    streets: list[dict] = []

    for e in elements:
        tags: dict[str, str] = e.get("tags") or {}
        etype: str = e.get("type", "")

        if etype == "way" and "highway" in tags:
            streets.append(e)
            continue

        if "building" in tags or is_parking_element(tags) or is_work_element(tags):
            buildings.append(e)
            continue

        if etype == "node" and is_poi_node(tags):
            poi_nodes.append(e)

    logger.info(
        "Overpass returned %d elements (%d buildings, %d poi_nodes, %d streets)",
        len(elements),
        len(buildings),
        len(poi_nodes),
        len(streets),
    )

    # ── Link each building to a street ──────────────────────────────────────
    links = link_buildings_to_streets(buildings, streets)

    # ── Build GeoJSON features ───────────────────────────────────────────────
    features: list[dict] = []
    type_counts: dict[str, int] = {}

    for building, (street_name, street_id) in zip(buildings, links):
        b_tags: dict[str, str] = building.get("tags") or {}
        b_val = b_tags.get("building", "").strip().lower()

        is_generic_way = building.get("type") == "way" and b_val in _GENERIC_BUILDING_TAGS

        # For generic building polygons: spatial POI containment analysis
        contained_pois: list[dict[str, str]] = []
        if is_generic_way and poi_nodes:
            contained_pois = find_pois_in_building(building, poi_nodes)

        poi_type = classify_building_with_pois(b_tags, contained_pois)

        # Mixed-use: generic building + non-residential POI inside
        if is_generic_way and contained_pois and poi_type != "house" and poi_type != "other":
            new_features = _make_mixed_use_features(building, poi_type, street_name, street_id)
            for feat in new_features:
                btype = feat["properties"]["buildingType"]
                type_counts[btype] = type_counts.get(btype, 0) + 1
                features.append(feat)
        else:
            feature = element_to_feature(building, poi_type, street_name, street_id)
            type_counts[poi_type] = type_counts.get(poi_type, 0) + 1
            features.append(feature)

    fc: dict = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "bbox": bbox,
            "overpassUrl": overpass_url,
        },
    }
    stats: dict = {
        "total": len(features),
        "buildings": len(buildings),
        "streets": len(streets),
        "tiles": tiles * tiles,
        "by_type": type_counts,
    }
    logger.info("Built %d building features — %s", len(features), type_counts)
    return fc, stats
