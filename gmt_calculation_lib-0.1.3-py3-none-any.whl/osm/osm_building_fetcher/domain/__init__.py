# src/osm_building_fetcher/domain/__init__.py
