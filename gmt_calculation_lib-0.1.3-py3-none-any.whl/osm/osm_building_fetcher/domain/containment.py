"""Spatial containment helpers for building/POI analysis.

Finds POI nodes that lie inside a building polygon so that generic buildings
(``building=yes``, ``building=house``, etc.) can be reclassified based on their
actual use rather than their structural tag.

Algorithm
---------
Point-in-polygon uses the ray-casting (even-odd rule) method — pure stdlib,
no external dependencies.  A bounding-box pre-filter avoids testing nodes that
are clearly outside a building polygon.

Public API
----------
find_pois_in_building(building_element, poi_nodes) -> list[dict[str, str]]
    Return the tag dicts of all POI nodes spatially inside a building polygon.
"""

from __future__ import annotations


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------


def _building_ring(building_element: dict) -> list[tuple[float, float]] | None:
    """Extract the outer ring of a building way as ``[(lon, lat), …]``.

    Returns ``None`` for node elements or ways with no geometry.
    """
    if building_element.get("type") != "way":
        return None
    geom: list[dict] = building_element.get("geometry") or []
    if len(geom) < 3:
        return None
    return [(float(p["lon"]), float(p["lat"])) for p in geom]


def _ring_bbox(ring: list[tuple[float, float]]) -> tuple[float, float, float, float]:
    """Return ``(min_lon, min_lat, max_lon, max_lat)`` for a ring."""
    lons = [p[0] for p in ring]
    lats = [p[1] for p in ring]
    return min(lons), min(lats), max(lons), max(lats)


def _point_in_polygon(lon: float, lat: float, ring: list[tuple[float, float]]) -> bool:
    """Ray-casting point-in-polygon test (even-odd rule).

    Parameters
    ----------
    lon, lat:
        The point to test.
    ring:
        Polygon ring as ``[(lon, lat), …]``.  Need not be explicitly closed.

    Returns
    -------
    bool
        ``True`` if the point is inside the polygon.
    """
    n = len(ring)
    inside = False
    j = n - 1
    for i in range(n):
        xi, yi = ring[i]
        xj, yj = ring[j]
        if ((yi > lat) != (yj > lat)) and (lon < (xj - xi) * (lat - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def find_pois_in_building(
    building_element: dict,
    poi_nodes: list[dict],
) -> list[dict[str, str]]:
    """Return the OSM tags of all POI nodes spatially inside a building polygon.

    Only ``way`` elements (building polygons) are analysed; for ``node``
    elements an empty list is always returned.

    A two-step approach is used for efficiency:
    1. Bounding-box pre-filter: discard nodes clearly outside the polygon bbox.
    2. Ray-casting point-in-polygon test for the remaining candidates.

    Parameters
    ----------
    building_element:
        Overpass element dict for the building (``type``, ``geometry``).
    poi_nodes:
        List of Overpass node elements that carry use tags (amenity / shop /
        tourism / office / leisure) but no ``building=`` tag.

    Returns
    -------
    list[dict[str, str]]
        Tag dicts of POI nodes inside the polygon, in the same order as
        ``poi_nodes``.  Empty when the building has no geometry or when no
        POIs fall inside.
    """
    ring = _building_ring(building_element)
    if ring is None or not poi_nodes:
        return []

    min_lon, min_lat, max_lon, max_lat = _ring_bbox(ring)

    result: list[dict[str, str]] = []
    for node in poi_nodes:
        lon = node.get("lon")
        lat = node.get("lat")
        if lon is None or lat is None:
            continue
        flon = float(lon)
        flat = float(lat)

        # Bounding-box pre-filter
        if flon < min_lon or flon > max_lon or flat < min_lat or flat > max_lat:
            continue

        if _point_in_polygon(flon, flat, ring):
            result.append(node.get("tags") or {})

    return result
