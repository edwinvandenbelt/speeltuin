"""Overpass QL query builders for the OSM building fetcher.

Public API
----------
build_buildings_and_streets_query(bbox, timeout) -> str
    Returns an Overpass QL query that fetches buildings (ways + nodes),
    parking / P+R facilities (ways + nodes), office / work elements
    (ways + nodes with an ``office=`` tag), and streets (ways with a
    highway tag) for the given bounding box.
"""

from __future__ import annotations

DEFAULT_TIMEOUT = 90


def build_buildings_and_streets_query(
    bbox: list[float],
    timeout: int = DEFAULT_TIMEOUT,
) -> str:
    """Build an Overpass QL query for buildings, parking, work, and streets.

    In addition to the standard ``building=*`` elements, the query also
    fetches:

    * ``amenity=parking`` — all parking lots and garages (includes station
      parking, underground garages, surface lots, etc.)
    * ``park_ride=*`` — explicit Park-and-Ride facilities
    * ``office=*`` — office and work elements that may carry no
      ``building`` tag (e.g. ground-floor offices mapped as nodes)
    * ``node["amenity"][!"building"]`` — standalone amenity POI nodes (e.g.
      ``fast_food``, ``restaurant``, ``school``) used for containment analysis
      inside generic ``building=yes`` / ``building=house`` polygons.
    * ``node["shop"][!"building"]`` — standalone shop nodes.
    * ``node["tourism"][!"building"]`` — standalone tourism nodes (hotels etc.).
    * ``node["leisure"][!"building"]`` — standalone leisure nodes.

    POI nodes (the last four sets) are separated from building elements in the
    core and used only for spatial containment analysis; they are not output as
    building features themselves.

    Parameters
    ----------
    bbox:
        [minLon, minLat, maxLon, maxLat]
    timeout:
        Overpass query timeout in seconds.

    Returns
    -------
    str
        Complete Overpass QL query string.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    bb = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    return (
        f"[out:json][timeout:{timeout}];\n"
        f"(\n"
        f'  way["building"]({bb});\n'
        f'  node["building"]({bb});\n'
        f'  way["amenity"="parking"]({bb});\n'
        f'  node["amenity"="parking"]({bb});\n'
        f'  way["park_ride"]({bb});\n'
        f'  node["park_ride"]({bb});\n'
        f'  way["office"]({bb});\n'
        f'  node["office"]({bb});\n'
        # POI nodes for containment analysis (nodes without their own building= tag)
        f'  node["amenity"][!"building"]({bb});\n'
        f'  node["shop"][!"building"]({bb});\n'
        f'  node["tourism"][!"building"]({bb});\n'
        f'  node["leisure"][!"building"]({bb});\n'
        f'  way["highway"]({bb});\n'
        f");\n"
        f"out geom;\n"
    )
