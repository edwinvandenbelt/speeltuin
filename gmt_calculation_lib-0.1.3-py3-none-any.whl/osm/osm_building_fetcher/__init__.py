# src/osm_building_fetcher/__init__.py
