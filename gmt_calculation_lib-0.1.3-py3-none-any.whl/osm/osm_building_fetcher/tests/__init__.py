# src/osm_building_fetcher/tests/__init__.py
