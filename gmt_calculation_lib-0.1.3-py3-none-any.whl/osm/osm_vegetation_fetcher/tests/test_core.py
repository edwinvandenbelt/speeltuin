"""Unit tests for osm_vegetation_fetcher — pure helpers + build_vegetation.

The Overpass HTTP layer is mocked at the point of use
(``osm_vegetation_fetcher.core.osm_vegetation_fetcher_core.fetch_overpass_tiled``)
so no network access occurs.
"""

from __future__ import annotations

from unittest.mock import patch

from osm_vegetation_fetcher.core.osm_vegetation_fetcher_core import (
    DEFAULT_MAX_POINTS,
    OVERPASS_GRID,
    _thin_points,
    build_vegetation,
)
from osm_vegetation_fetcher.domain.geometry import (
    element_to_feature,
    normalise_veg_type,
)
from osm_vegetation_fetcher.domain.overpass import build_vegetation_query

_CORE = "osm_vegetation_fetcher.core.osm_vegetation_fetcher_core.fetch_overpass_tiled"


# ---------------------------------------------------------------------------
# element factories
# ---------------------------------------------------------------------------


def _tree_node(eid: int, lon: float, lat: float, tags: dict | None = None) -> dict:
    base = {"natural": "tree"}
    base.update(tags or {})
    return {"type": "node", "id": eid, "lon": lon, "lat": lat, "tags": base}


def _way(eid: int, tags: dict, coords: list[tuple[float, float]]) -> dict:
    return {
        "type": "way",
        "id": eid,
        "tags": tags,
        "geometry": [{"lon": lon, "lat": lat} for lon, lat in coords],
    }


def _square(eid: int, tags: dict, x0: float = 0.0, y0: float = 0.0) -> dict:
    return _way(
        eid,
        tags,
        [(x0, y0), (x0 + 1, y0), (x0 + 1, y0 + 1), (x0, y0 + 1)],
    )


# ---------------------------------------------------------------------------
# normalise_veg_type
# ---------------------------------------------------------------------------


class TestNormaliseVegType:
    def test_tree(self):
        assert normalise_veg_type({"tags": {"natural": "tree"}}) == "tree"

    def test_tree_row(self):
        assert normalise_veg_type({"tags": {"natural": "tree_row"}}) == "tree_row"

    def test_shrub(self):
        assert normalise_veg_type({"tags": {"natural": "shrub"}}) == "shrub"

    def test_scrub(self):
        assert normalise_veg_type({"tags": {"natural": "scrub"}}) == "scrub"

    def test_wood(self):
        assert normalise_veg_type({"tags": {"natural": "wood"}}) == "wood"

    def test_grass(self):
        assert normalise_veg_type({"tags": {"landuse": "grass"}}) == "grass"

    def test_forest(self):
        assert normalise_veg_type({"tags": {"landuse": "forest"}}) == "forest"

    def test_natural_takes_priority_over_landuse(self):
        assert normalise_veg_type({"tags": {"natural": "wood", "landuse": "grass"}}) == "wood"

    def test_unrecognised_returns_none(self):
        assert normalise_veg_type({"tags": {"building": "yes"}}) is None

    def test_no_tags_returns_none(self):
        assert normalise_veg_type({}) is None


# ---------------------------------------------------------------------------
# element_to_feature — geometry + properties
# ---------------------------------------------------------------------------


class TestElementToFeature:
    def test_tree_node_becomes_point(self):
        feat = element_to_feature(_tree_node(1, 6.1, 52.2), "tree")
        assert feat is not None
        assert feat["geometry"]["type"] == "Point"
        assert feat["geometry"]["coordinates"] == [6.1, 52.2]
        assert feat["properties"]["vegType"] == "tree"
        assert feat["properties"]["osmId"] == "node/1"

    def test_tree_row_becomes_linestring(self):
        el = _way(2, {"natural": "tree_row"}, [(0, 0), (1, 1), (2, 2)])
        feat = element_to_feature(el, "tree_row")
        assert feat is not None
        assert feat["geometry"]["type"] == "LineString"
        assert len(feat["geometry"]["coordinates"]) == 3

    def test_wood_way_becomes_closed_polygon(self):
        feat = element_to_feature(_square(3, {"natural": "wood"}), "wood")
        assert feat is not None
        assert feat["geometry"]["type"] == "Polygon"
        ring = feat["geometry"]["coordinates"][0]
        assert ring[0] == ring[-1]  # closed
        assert len(ring) == 5

    def test_height_parsed_from_height_tag(self):
        feat = element_to_feature(_tree_node(4, 0, 0, {"height": "12.5 m"}), "tree")
        assert feat["properties"]["height"] == 12.5

    def test_height_falls_back_to_est_height(self):
        feat = element_to_feature(_tree_node(5, 0, 0, {"est_height": "8"}), "tree")
        assert feat["properties"]["height"] == 8.0

    def test_height_absent_is_none(self):
        feat = element_to_feature(_tree_node(6, 0, 0), "tree")
        assert feat["properties"]["height"] is None

    def test_crown_parsed(self):
        feat = element_to_feature(_tree_node(7, 0, 0, {"diameter_crown": "4"}), "tree")
        assert feat["properties"]["crown"] == 4.0

    def test_species_from_species_tag(self):
        feat = element_to_feature(_tree_node(8, 0, 0, {"species": "Quercus robur"}), "tree")
        assert feat["properties"]["species"] == "Quercus robur"

    def test_species_falls_back_to_genus(self):
        feat = element_to_feature(_tree_node(9, 0, 0, {"genus": "Quercus"}), "tree")
        assert feat["properties"]["species"] == "Quercus"

    def test_leaf_type_broadleaved(self):
        feat = element_to_feature(_tree_node(10, 0, 0, {"leaf_type": "broadleaved"}), "tree")
        assert feat["properties"]["leafType"] == "broadleaved"

    def test_leaf_type_invalid_is_none(self):
        feat = element_to_feature(_tree_node(11, 0, 0, {"leaf_type": "mixed"}), "tree")
        assert feat["properties"]["leafType"] is None

    def test_degenerate_polygon_returns_none(self):
        el = _way(12, {"natural": "wood"}, [(0, 0), (1, 1)])
        assert element_to_feature(el, "wood") is None

    def test_relation_becomes_multipolygon(self):
        relation = {
            "type": "relation",
            "id": 99,
            "tags": {"natural": "wood"},
            "members": [
                {
                    "type": "way",
                    "role": "outer",
                    "geometry": [
                        {"lon": 0, "lat": 0},
                        {"lon": 2, "lat": 0},
                        {"lon": 2, "lat": 2},
                        {"lon": 0, "lat": 2},
                    ],
                },
                {
                    "type": "way",
                    "role": "inner",
                    "geometry": [
                        {"lon": 0.5, "lat": 0.5},
                        {"lon": 1.5, "lat": 0.5},
                        {"lon": 1.5, "lat": 1.5},
                        {"lon": 0.5, "lat": 1.5},
                    ],
                },
            ],
        }
        feat = element_to_feature(relation, "wood")
        assert feat is not None
        assert feat["geometry"]["type"] == "MultiPolygon"
        polygons = feat["geometry"]["coordinates"]
        assert len(polygons) == 1
        # outer + one inner hole assigned to it
        assert len(polygons[0]) == 2

    def test_relation_without_outer_returns_none(self):
        relation = {"type": "relation", "id": 100, "tags": {"natural": "wood"}, "members": []}
        assert element_to_feature(relation, "wood") is None


# ---------------------------------------------------------------------------
# build_vegetation_query
# ---------------------------------------------------------------------------


class TestBuildVegetationQuery:
    def test_contains_all_selectors(self):
        q = build_vegetation_query([6.1, 52.2, 6.2, 52.3])
        assert '["natural"="tree"]' in q
        assert '["natural"="tree_row"]' in q
        assert '["natural"="shrub"]' in q
        assert '["natural"="scrub"]' in q
        assert '["landuse"="grass"]' in q
        assert '["natural"="wood"]' in q
        assert '["landuse"="forest"]' in q
        assert "relation" in q
        assert "out geom;" in q

    def test_bbox_reordered_to_overpass_order(self):
        q = build_vegetation_query([6.1, 52.2, 6.2, 52.3])
        # south,west,north,east
        assert "52.2,6.1,52.3,6.2" in q

    def test_timeout_embedded(self):
        assert "[timeout:45]" in build_vegetation_query([0, 0, 1, 1], timeout=45)


# ---------------------------------------------------------------------------
# _thin_points
# ---------------------------------------------------------------------------


class TestThinPoints:
    def test_no_thinning_below_cap(self):
        pts = [{"id": i} for i in range(10)]
        out, capped = _thin_points(pts, 20)
        assert out == pts
        assert capped is False

    def test_thins_above_cap(self):
        pts = [{"id": i} for i in range(100)]
        out, capped = _thin_points(pts, 20)
        assert capped is True
        assert len(out) <= 100
        assert len(out) >= 20

    def test_deterministic(self):
        pts = [{"id": i} for i in range(100)]
        out1, _ = _thin_points(pts, 25)
        out2, _ = _thin_points(pts, 25)
        assert out1 == out2

    def test_zero_disables_cap(self):
        pts = [{"id": i} for i in range(1000)]
        out, capped = _thin_points(pts, 0)
        assert out == pts
        assert capped is False


# ---------------------------------------------------------------------------
# build_vegetation (mocked Overpass)
# ---------------------------------------------------------------------------


class TestBuildVegetation:
    _ELEMENTS = [  # noqa: RUF012 — static test fixture, never mutated.
        _tree_node(1, 6.11, 52.21, {"height": "10", "leaf_type": "broadleaved"}),
        _tree_node(2, 6.12, 52.22),
        {"type": "node", "id": 3, "lon": 6.13, "lat": 52.23, "tags": {"natural": "shrub"}},
        _way(4, {"natural": "tree_row"}, [(6.1, 52.2), (6.15, 52.25)]),
        _square(5, {"natural": "wood"}, x0=6.1, y0=52.2),
        _square(6, {"landuse": "forest"}, x0=6.2, y0=52.3),
        {"type": "way", "id": 7, "tags": {"building": "yes"}, "geometry": []},  # ignored
    ]

    def _run(self, elements, **kwargs):
        with patch(_CORE) as mock_fp:
            mock_fp.return_value = {"elements": elements}
            return build_vegetation([6.1, 52.2, 6.3, 52.4], **kwargs), mock_fp

    def test_builds_expected_feature_count(self):
        (fc, stats), _ = self._run(self._ELEMENTS)
        # 2 trees + 1 shrub + 1 tree_row + 1 wood + 1 forest = 6 (building ignored)
        assert stats["total"] == 6
        assert len(fc["features"]) == 6

    def test_stats_split_by_geometry_class(self):
        (_, stats), _ = self._run(self._ELEMENTS)
        assert stats["points"] == 3  # 2 trees + 1 shrub
        assert stats["lines"] == 1
        assert stats["areas"] == 2

    def test_by_type_counts(self):
        (_, stats), _ = self._run(self._ELEMENTS)
        assert stats["by_type"]["tree"] == 2
        assert stats["by_type"]["shrub"] == 1
        assert stats["by_type"]["tree_row"] == 1
        assert stats["by_type"]["wood"] == 1
        assert stats["by_type"]["forest"] == 1

    def test_fc_has_bbox_property(self):
        (fc, _), _ = self._run(self._ELEMENTS)
        assert fc["type"] == "FeatureCollection"
        assert fc["properties"]["bbox"] == [6.1, 52.2, 6.3, 52.4]

    def test_empty_response_returns_empty_fc(self):
        (fc, stats), _ = self._run([])
        assert fc["features"] == []
        assert stats["total"] == 0

    def test_default_tiles_grid(self):
        (_, stats), mock_fp = self._run(self._ELEMENTS)
        _, kwargs = mock_fp.call_args
        assert kwargs["tiles"] == (OVERPASS_GRID, OVERPASS_GRID)
        assert stats["tiles"] == OVERPASS_GRID * OVERPASS_GRID

    def test_point_cap_thins_but_keeps_areas(self):
        many_trees = [_tree_node(1000 + i, 6.1, 52.2) for i in range(50)]
        elements = [*many_trees, _square(9000, {"natural": "wood"})]
        (fc, stats), _ = self._run(elements, max_points=10)
        assert stats["capped"] is True
        assert stats["points"] <= 50
        assert stats["areas"] == 1  # area always kept
        assert any(f["properties"]["vegType"] == "wood" for f in fc["features"])

    def test_default_max_points_constant(self):
        assert DEFAULT_MAX_POINTS == 20_000
