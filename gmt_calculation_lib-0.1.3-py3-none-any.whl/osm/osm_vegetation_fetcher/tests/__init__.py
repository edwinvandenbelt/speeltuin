# src/osm/osm_vegetation_fetcher/tests/__init__.py
