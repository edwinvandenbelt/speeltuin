"""OSM Vegetation Fetcher core — fetches public green / tree data from Overpass.

Downloads vegetation features (trees, tree rows, shrubs, scrub, grass, wood and
forest) from the Overpass API for a bounding box, normalises each element into a
GeoJSON Feature with a small, stable property schema, and returns a
FeatureCollection ready for serialisation as GeoParquet (EPSG:4326).

Output schema (one row per feature)
-----------------------------------
* ``geometry`` — Point (tree/shrub), LineString (tree_row) or Polygon /
  MultiPolygon (scrub/grass/wood/forest).
* ``vegType``  — normalised label: one of ``tree``, ``tree_row``, ``shrub``,
  ``scrub``, ``wood``, ``forest``, ``grass``.
* ``height``   — float metres from OSM ``height`` / ``est_height``, else ``None``.
* ``crown``    — float crown diameter (m) from ``diameter_crown``, else ``None``.
* ``species``  — from ``species`` / ``genus``, else ``None``.
* ``leafType`` — ``broadleaved`` / ``needleleaved`` / ``None`` (from ``leaf_type``).
* ``osmId``    — source id (``"{type}/{id}"``) for debugging.

Resource cap
------------
Vegetation is a "nice to have"; the number of point features (trees + shrubs) is
capped (default 20 000) via **deterministic** thinning (every n-th point) so the
output is reproducible.  Area features (scrub / grass / wood / forest) are always
kept in full — they are few in number but cover a lot of ground.

Public API
----------
build_vegetation(bbox, *, overpass_url, timeout, tiles, max_points)
    -> tuple[dict, dict]
    Returns (feature_collection, stats).
    stats: {"total", "points", "areas", "lines", "capped", "tiles", "by_type"}
"""

from __future__ import annotations

import logging

from osm.osm_vegetation_fetcher.domain.geometry import (
    LINE_VEG_TYPES,
    POINT_VEG_TYPES,
    element_to_feature,
    normalise_veg_type,
)
from osm.osm_vegetation_fetcher.domain.overpass import (
    DEFAULT_TIMEOUT,
    build_vegetation_query,
)
from shared.overpass import DEFAULT_OVERPASS_URL, fetch_overpass_tiled

logger = logging.getLogger(__name__)

_DEFAULT_OVERPASS_URL = DEFAULT_OVERPASS_URL

# Default NxN Overpass tile grid.  Large areas are split into tiles so that no
# single Overpass request has to return the whole area at once (which risks
# server-side timeouts / rate-limiting).  All tiles are merged (deduplicated by
# element id) into a single FeatureCollection.
OVERPASS_GRID: int = 5

# Default cap on the number of point features (trees + shrubs) per area.  When
# exceeded, points are deterministically thinned (every n-th point kept).
DEFAULT_MAX_POINTS: int = 20_000


def _thin_points(features: list[dict], max_points: int) -> tuple[list[dict], bool]:
    """Deterministically thin *features* down to at most *max_points*.

    Keeps every ``n``-th feature (``n = ceil(len / max_points)``) so the result
    is evenly distributed and fully reproducible across runs.  Returns the
    (possibly reduced) list and a boolean indicating whether thinning occurred.
    """
    total = len(features)
    if max_points <= 0 or total <= max_points:
        return features, False
    step = (total + max_points - 1) // max_points  # ceil division
    thinned = features[::step]
    return thinned, True


def build_vegetation(
    bbox: list[float],
    *,
    overpass_url: str = _DEFAULT_OVERPASS_URL,
    timeout: int = DEFAULT_TIMEOUT,
    tiles: int = OVERPASS_GRID,
    max_points: int = DEFAULT_MAX_POINTS,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> tuple[dict, dict]:
    """Fetch and normalise OSM vegetation features for a bounding box.

    Parameters
    ----------
    bbox:
        Bounding box ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    overpass_url:
        Overpass API endpoint URL.
    timeout:
        Overpass query timeout in seconds.
    tiles:
        NxN Overpass tile grid.  The bbox is split into ``tiles x tiles``
        sub-bboxes that are fetched separately and merged (deduplicated by
        element id).  ``tiles=1`` performs a single, untiled query.
    max_points:
        Maximum number of point features (trees + shrubs) to keep.  When
        exceeded, points are deterministically thinned.  ``0`` disables the cap.

    Returns
    -------
    fc:
        GeoJSON FeatureCollection (EPSG:4326).  Each Feature carries
        ``vegType``, ``height``, ``crown``, ``species``, ``leafType`` and
        ``osmId`` properties.
    stats:
        ``{"total", "points", "areas", "lines", "capped", "tiles", "by_type"}``.
    """
    logger.info(
        "Fetching vegetation via Overpass  bbox=%s  url=%s  tiles=%dx%d",
        bbox,
        overpass_url,
        tiles,
        tiles,
    )
    data = fetch_overpass_tiled(
        lambda b: build_vegetation_query(b, timeout=timeout),
        bbox,
        tiles=(tiles, tiles),
        url=overpass_url,
        timeout=timeout,
        osm_path=osm_path, osm_workers=osm_workers,
    )
    elements: list[dict] = data.get("elements") or []

    point_features: list[dict] = []
    line_features: list[dict] = []
    area_features: list[dict] = []

    for element in elements:
        veg_type = normalise_veg_type(element)
        if veg_type is None:
            continue
        feature = element_to_feature(element, veg_type)
        if feature is None:
            continue
        if veg_type in POINT_VEG_TYPES:
            point_features.append(feature)
        elif veg_type in LINE_VEG_TYPES:
            line_features.append(feature)
        else:
            area_features.append(feature)

    # Cap point features (trees / shrubs) deterministically; areas are kept fully.
    point_features, capped = _thin_points(point_features, max_points)

    features = point_features + line_features + area_features

    type_counts: dict[str, int] = {}
    for feature in features:
        vtype = feature["properties"]["vegType"]
        type_counts[vtype] = type_counts.get(vtype, 0) + 1

    fc: dict = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "bbox": bbox,
            "overpassUrl": overpass_url,
        },
    }
    stats: dict = {
        "total": len(features),
        "points": len(point_features),
        "areas": len(area_features),
        "lines": len(line_features),
        "capped": capped,
        "tiles": tiles * tiles,
        "by_type": type_counts,
    }
    logger.info("Built %d vegetation features — %s (capped=%s)", len(features), type_counts, capped)
    return fc, stats
