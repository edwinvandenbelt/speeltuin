# src/osm/osm_vegetation_fetcher/core/__init__.py
