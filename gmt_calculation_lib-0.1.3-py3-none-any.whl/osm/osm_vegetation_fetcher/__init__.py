# src/osm/osm_vegetation_fetcher/__init__.py
