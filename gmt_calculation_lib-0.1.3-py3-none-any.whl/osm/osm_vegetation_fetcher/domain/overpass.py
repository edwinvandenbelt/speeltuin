"""Overpass QL query builder for the OSM vegetation fetcher.

Public API
----------
build_vegetation_query(bbox, timeout) -> str
    Returns an Overpass QL query that fetches public green / tree data for the
    given bounding box:

    * tree points          — ``node["natural"="tree"]``
    * tree rows            — ``way["natural"="tree_row"]``
    * shrubs               — ``node["natural"="shrub"]``
    * scrub                — ``way["natural"="scrub"]``
    * grass                — ``way["landuse"="grass"]``
    * wood                 — ``way["natural"="wood"]`` (+ relations)
    * forest               — ``way["landuse"="forest"]`` (+ relations)
"""

from __future__ import annotations

DEFAULT_TIMEOUT = 90


def build_vegetation_query(
    bbox: list[float],
    timeout: int = DEFAULT_TIMEOUT,
) -> str:
    """Build an Overpass QL query for OSM vegetation features.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    timeout:
        Overpass query timeout in seconds.

    Returns
    -------
    str
        Complete Overpass QL query string.  ``out geom;`` is used so that ways
        and relations come back with full geometry (needed to build polygons
        and line strings without a second lookup).
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    bb = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    return (
        f"[out:json][timeout:{timeout}];\n"
        f"(\n"
        # tree points + tree rows
        f'  node["natural"="tree"]({bb});\n'
        f'  way["natural"="tree_row"]({bb});\n'
        # shrubs / scrub / grass
        f'  node["natural"="shrub"]({bb});\n'
        f'  way["natural"="scrub"]({bb});\n'
        f'  way["landuse"="grass"]({bb});\n'
        # wood / forest polygons (ways + relations)
        f'  way["natural"="wood"]({bb});\n'
        f'  relation["natural"="wood"]({bb});\n'
        f'  way["landuse"="forest"]({bb});\n'
        f'  relation["landuse"="forest"]({bb});\n'
        f");\n"
        f"out geom;\n"
    )
