# src/osm/osm_vegetation_fetcher/domain/__init__.py
