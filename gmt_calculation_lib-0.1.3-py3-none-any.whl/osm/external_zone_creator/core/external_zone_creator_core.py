"""external_zone_creator_core.py — Pure-Python core for external zone creation.

Finds "cut links" in a directed network (links with one node inside and one
node outside the bounding box) and creates synthetic external zones for each
unique outside node.  External zones receive production and attraction
proportional to the combined link capacity at that boundary crossing, scaled
to a user-configurable fraction of total internal population.

Feedlinks connecting each external zone to its boundary node are also created
and appended to the existing feedlinks collection.

Zone naming
-----------
Each zone gets an intuitive ``zoneName`` derived from the highest-class cut
link attached to its outside node, using one of three tiers:

  Tier 1 — motorway / trunk  : "towards {ref} ({compass})"
                                e.g. "towards A1 (NE)"
  Tier 2 — provincial road   : reverse-geocoded municipality name
            (primary / secondary / tertiary with speed > 50 km/h)
                                e.g. "towards Zwolle (N)"
  Tier 3 — local road        : OSM road name if available
            (residential / service / unclassified or speed ≤ 50 km/h)
                                e.g. "towards Dorpsstraat (SW)"

When the required label is absent (no ref, no name, geocode failed) the zone
falls back to "boundary ({compass})".  Duplicate names within a single run
are disambiguated by appending " 2", " 3", etc.

Public API
----------
create_external_zones(network_fc, zones_fc, feedlinks_fc, bbox, *, external_share,
                      gisco_url, gisco_timeout)
    -> tuple[dict, dict, dict]
    Returns (updated_zones_fc, updated_feedlinks_fc, stats).
"""

from __future__ import annotations

import logging
from collections import defaultdict

from shared.geo_utils import _bearing_deg, _compass_8_label_en

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_EXTERNAL_SHARE: float = 0.40

_DEFAULT_GISCO_URL = "https://gisco-services.ec.europa.eu"
_DEFAULT_GISCO_TIMEOUT = 10

# Multiplier applied on top of link capacity to give extra weight to cut links
# on high-class roads.  A motorway crossing pulls in much more through-traffic
# than a residential-street crossing even when their capacities are similar.
_HIGHWAY_WEIGHTS: dict[str, float] = {
    "motorway": 8.0,
    "motorway_link": 8.0,
    "trunk": 8.0,
    "trunk_link": 8.0,
    "primary": 4.0,
    "primary_link": 4.0,
    "secondary": 4.0,
    "secondary_link": 4.0,
    "tertiary": 2.0,
    "tertiary_link": 2.0,
    "unclassified": 2.0,
}

# Road class rank used to determine which cut link is "most prominent" at a
# boundary node when multiple cut links converge there.  Lower value = higher
# class.
_HIGHWAY_RANK: dict[str, int] = {
    "motorway": 1,
    "motorway_link": 1,
    "trunk": 1,
    "trunk_link": 1,
    "primary": 2,
    "primary_link": 2,
    "secondary": 2,
    "secondary_link": 2,
    "tertiary": 2,
    "tertiary_link": 2,
}

# Motorway / trunk highway types that use the road ref for naming (tier 1).
_TIER1_HIGHWAYS: frozenset[str] = frozenset(
    {
        "motorway",
        "motorway_link",
        "trunk",
        "trunk_link",
    }
)

# Provincial / inter-urban highway types where we geocode the destination
# municipality (tier 2).  Only applied when link speed > 50 km/h.
_TIER2_HIGHWAYS: frozenset[str] = frozenset(
    {
        "primary",
        "primary_link",
        "secondary",
        "secondary_link",
        "tertiary",
        "tertiary_link",
    }
)

EXTERNAL_ZONE_PROPERTIES: tuple[str, ...] = (
    "zoneId",
    "zoneClass",
    "zoneName",
    "centroidLon",
    "centroidLat",
    "production",
    "attraction",
    "nBuildings",
)

EXTERNAL_FEEDLINK_PROPERTIES: tuple[str, ...] = (
    "zoneId",
    "fromNode",
    "toNode",
    "length",
    "capacity",
    "flow",
)

__all__ = [
    "EXTERNAL_ZONE_PROPERTIES",
    "EXTERNAL_FEEDLINK_PROPERTIES",
    "DEFAULT_EXTERNAL_SHARE",
    "create_external_zones",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _highway_weight(props: dict) -> float:
    """Return a road-class multiplier for ``props`` based on the ``highway`` tag.

    Higher-class roads attract more through-traffic, so their external zones
    should receive proportionally more production/attraction.
    Falls back to 1.0 for unrecognised or absent tags.
    """
    hw = (props.get("highway") or "").strip().lower()
    return _HIGHWAY_WEIGHTS.get(hw, 1.0)


def _node_coords(network_fc: dict) -> dict[str, tuple[float, float]]:
    """Extract a nodeId → (lon, lat) mapping from network geometry."""
    coords: dict[str, tuple[float, float]] = {}
    for feat in network_fc.get("features") or []:
        geom = feat.get("geometry") or {}
        pts: list = geom.get("coordinates") or []
        if not pts:
            continue
        p = feat.get("properties") or {}
        fn = str(p.get("fromNode") or "")
        tn = str(p.get("toNode") or "")
        if fn and pts:
            coords[fn] = (float(pts[0][0]), float(pts[0][1]))
        if tn and pts:
            coords[tn] = (float(pts[-1][0]), float(pts[-1][1]))
    return coords


def _inside_bbox(lon: float, lat: float, bbox: list[float]) -> bool:
    min_lon, min_lat, max_lon, max_lat = bbox
    return min_lon <= lon <= max_lon and min_lat <= lat <= max_lat


def _total_population(zones_fc: dict) -> float:
    total = 0.0
    for feat in zones_fc.get("features") or []:
        total += float((feat.get("properties") or {}).get("production") or 0.0)
    return total


def _compass(lon: float, lat: float, bbox: list[float]) -> str:
    """Return 8-point English compass label from the bbox centre to (lon, lat)."""
    centre_lon = (bbox[0] + bbox[2]) / 2.0
    centre_lat = (bbox[1] + bbox[3]) / 2.0
    bearing = _bearing_deg(centre_lon, centre_lat, lon, lat)
    return _compass_8_label_en(bearing)


def _zone_name(
    lon: float,
    lat: float,
    bbox: list[float],
    highway: str,
    speed: float,
    ref: str,
    road_name: str,
    gisco_url: str,
    gisco_timeout: int,
) -> str:
    """Return an intuitive display name for an external zone.

    Three tiers, based on the most prominent cut link at the boundary node:

    Tier 1 (motorway/trunk): "towards {ref} ({compass})"
    Tier 2 (provincial, speed > 50): "towards {municipality} ({compass})"
    Tier 3 (local road, speed ≤ 50):  "towards {name} ({compass})"

    Falls back to "boundary ({compass})" when labels are unavailable.
    """
    compass = _compass(lon, lat, bbox)
    hw = (highway or "").strip().lower()

    if hw in _TIER1_HIGHWAYS:
        label = (ref or "").strip() or "Motorway"
        return f"towards {label} ({compass})"

    if hw in _TIER2_HIGHWAYS and speed > 50.0:
        # Geocode the outside-node location to find the neighbouring municipality.
        try:
            from osm.zone_population_estimator.domain.gisco import (  # noqa: PLC0415
                reverse_geocode,
            )

            place_info = reverse_geocode(lon, lat, base_url=gisco_url, timeout=gisco_timeout)
            municipality = (place_info.get("name") or "").strip()
        except Exception:
            municipality = ""
        if municipality:
            return f"towards {municipality} ({compass})"
        return f"boundary ({compass})"

    # Tier 3 — local road: use the road name tag if present.
    name = (road_name or "").strip()
    if name:
        return f"towards {name} ({compass})"
    return f"boundary ({compass})"


def _deduplicate_names(names: list[str]) -> list[str]:
    """Add numeric suffixes to duplicate names so every entry is unique.

    The first occurrence keeps its original name; subsequent duplicates get
    " 2", " 3", etc.  Only applies when there actually are duplicates.
    """
    seen: dict[str, int] = {}
    result: list[str] = []
    for name in names:
        count = seen.get(name, 0) + 1
        seen[name] = count
        result.append(name if count == 1 else f"{name} {count}")
    return result


# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------


def create_external_zones(
    network_fc: dict,
    zones_fc: dict,
    feedlinks_fc: dict,
    bbox: list[float],
    *,
    external_share: float = DEFAULT_EXTERNAL_SHARE,
    gisco_url: str = _DEFAULT_GISCO_URL,
    gisco_timeout: int = _DEFAULT_GISCO_TIMEOUT,
) -> tuple[dict, dict, dict]:
    """Create external zones for boundary-crossing links and append to existing FCs.

    An external zone is created for each unique network node that lies outside
    the bounding box but is connected to at least one node that lies inside the
    bounding box (a "cut link").

    The production of each external zone is:

        production_i = external_share × total_population
                       × (capacity_i / total_cut_capacity)

    where ``capacity_i`` is the sum of capacities of all cut links incident on
    outside node *i*.

    Parameters
    ----------
    network_fc:
        Directed network FeatureCollection.  Each feature must have
        ``fromNode``, ``toNode``, ``capacity``, ``highway``, ``ref``, ``name``,
        and ``speed`` properties and a LineString geometry whose first coordinate
        corresponds to ``fromNode`` and last coordinate to ``toNode``.
    zones_fc:
        Existing zones FeatureCollection.  The ``production`` field is used to
        derive total population.  External zones are appended to a copy.
    feedlinks_fc:
        Existing feedlinks FeatureCollection.  External feedlinks are appended
        to a copy.
    bbox:
        ``[min_lon, min_lat, max_lon, max_lat]`` — the study area bounding box.
    external_share:
        Fraction of total internal population to assign as external
        production/attraction.  Default: 0.40 (40%).
    gisco_url:
        Base URL of the GISCO services endpoint used for reverse geocoding
        provincial road zones.  Default: ``https://gisco-services.ec.europa.eu``.
    gisco_timeout:
        HTTP timeout in seconds for GISCO reverse-geocode requests.  Default: 10.

    Returns
    -------
    updated_zones_fc:
        Copy of *zones_fc* with external zone features appended.
    updated_feedlinks_fc:
        Copy of *feedlinks_fc* with external feedlinks appended (one entry and
        one exit feedlink per external zone).
    stats:
        ``{"externalZones": int, "externalFeedlinks": int,
           "totalCutLinks": int,
           "totalExternalProduction": float, "totalExternalAttraction": float}``
    """
    node_coords = _node_coords(network_fc)

    # Determine which nodes are inside the bbox.
    inside_nodes: set[str] = {
        nid for nid, (lon, lat) in node_coords.items() if _inside_bbox(lon, lat, bbox)
    }

    # Find cut links (one endpoint inside, one outside) and split by direction:
    #
    #   outside → inside  ("incoming"):  the outside node is a trip *origin*
    #                                    → contributes to zone production
    #   inside  → outside ("outgoing"):  the outside node is a trip *destination*
    #                                    → contributes to zone attraction
    #
    # Per outside node we track:
    #   node_in_weight   — Σ (capacity × highway_weight) for incoming links
    #   node_out_weight  — Σ (capacity × highway_weight) for outgoing links
    #   node_in_cap      — Σ capacity for incoming links  (feedlink capacity)
    #   node_out_cap     — Σ capacity for outgoing links  (feedlink capacity)
    #   node_highway/ref/road_name/speed — most prominent link across all directions
    node_in_weight: dict[str, float] = defaultdict(float)
    node_out_weight: dict[str, float] = defaultdict(float)
    node_in_cap: dict[str, float] = defaultdict(float)
    node_out_cap: dict[str, float] = defaultdict(float)
    node_highway: dict[str, str] = {}
    node_ref: dict[str, str] = {}
    node_road_name: dict[str, str] = {}
    node_speed: dict[str, float] = {}
    cut_count = 0

    for feat in network_fc.get("features") or []:
        p = feat.get("properties") or {}
        fn = str(p.get("fromNode") or "")
        tn = str(p.get("toNode") or "")
        fn_inside = fn in inside_nodes
        tn_inside = tn in inside_nodes
        if fn_inside == tn_inside:
            continue  # both inside or both outside — not a cut link
        cut_count += 1
        cap = float(p.get("capacity") or 0.0)
        hw_w = _highway_weight(p)

        if fn_inside:
            # inside → outside: outgoing link → contributes to attraction
            outside_node = tn
            node_out_weight[outside_node] += cap * hw_w
            node_out_cap[outside_node] += cap
        else:
            # outside → inside: incoming link → contributes to production
            outside_node = fn
            node_in_weight[outside_node] += cap * hw_w
            node_in_cap[outside_node] += cap

        # Track the most prominent highway class for naming purposes
        # (considering links from both directions).
        hw = (p.get("highway") or "").strip().lower()
        spd = float(p.get("speed") or 0.0)
        cur_rank = _HIGHWAY_RANK.get(node_highway.get(outside_node, ""), 99)
        new_rank = _HIGHWAY_RANK.get(hw, 3)
        if new_rank < cur_rank:
            node_highway[outside_node] = hw
            node_ref[outside_node] = (p.get("ref") or "").strip()
            node_road_name[outside_node] = (p.get("name") or "").strip()
            node_speed[outside_node] = spd
        elif new_rank == cur_rank and spd > node_speed.get(outside_node, 0.0):
            node_ref[outside_node] = (p.get("ref") or "").strip()
            node_road_name[outside_node] = (p.get("name") or "").strip()
            node_speed[outside_node] = spd

    # Union of all outside nodes that appear in either direction.
    all_outside_nodes: set[str] = set(node_in_weight) | set(node_out_weight)

    if not all_outside_nodes:
        logger.warning("No cut links found for bbox=%s; no external zones created.", bbox)
        return (
            dict(zones_fc),
            dict(feedlinks_fc),
            {
                "externalZones": 0,
                "externalFeedlinks": 0,
                "totalCutLinks": 0,
                "totalExternalProduction": 0.0,
                "totalExternalAttraction": 0.0,
            },
        )

    total_in_weight = sum(node_in_weight.values())
    total_out_weight = sum(node_out_weight.values())
    total_population = _total_population(zones_fc)
    # Both budgets equal external_share × total_population (symmetric).
    production_budget = external_share * total_population
    attraction_budget = external_share * total_population

    logger.info(
        "external_zone_creator: %d cut links, %d outside nodes, "
        "total_population=%.0f, production_budget=%.0f, attraction_budget=%.0f",
        cut_count,
        len(all_outside_nodes),
        total_population,
        production_budget,
        attraction_budget,
    )

    # Compute raw zone names (before deduplication).
    sorted_nodes = sorted(all_outside_nodes)
    raw_names: list[str] = [
        _zone_name(
            lon=node_coords.get(n, (0.0, 0.0))[0],
            lat=node_coords.get(n, (0.0, 0.0))[1],
            bbox=bbox,
            highway=node_highway.get(n, ""),
            speed=node_speed.get(n, 0.0),
            ref=node_ref.get(n, ""),
            road_name=node_road_name.get(n, ""),
            gisco_url=gisco_url,
            gisco_timeout=gisco_timeout,
        )
        for n in sorted_nodes
    ]
    zone_names = _deduplicate_names(raw_names)

    # Build external zone and feedlink features.
    new_zone_feats: list[dict] = []
    new_feedlink_feats: list[dict] = []

    for outside_node, zone_name in zip(sorted_nodes, zone_names):
        lon, lat = node_coords.get(outside_node, (0.0, 0.0))
        zone_id = f"ext_{outside_node}"
        zone_node = f"ZONE_{zone_id}"

        in_w = node_in_weight.get(outside_node, 0.0)
        out_w = node_out_weight.get(outside_node, 0.0)
        in_cap = node_in_cap.get(outside_node, 0.0)
        out_cap = node_out_cap.get(outside_node, 0.0)

        production = (
            round(production_budget * (in_w / total_in_weight), 2) if total_in_weight > 0.0 else 0.0
        )
        attraction = (
            round(attraction_budget * (out_w / total_out_weight), 2)
            if total_out_weight > 0.0
            else 0.0
        )

        # Zone feature (Point geometry at the outside node's location).
        new_zone_feats.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [lon, lat]},
                "properties": {
                    "zoneId": zone_id,
                    "zoneClass": "EXTERNAL",
                    "zoneName": zone_name,
                    "centroidLon": lon,
                    "centroidLat": lat,
                    "production": production,
                    "attraction": attraction,
                    "nBuildings": 0,
                },
            }
        )

        # Entry feedlink: zone_node → outside_node (traffic entering the network).
        # Capacity based on incoming cut links; 0 when there are none.
        new_feedlink_feats.append(
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[lon, lat], [lon, lat]]},
                "properties": {
                    "zoneId": zone_id,
                    "fromNode": zone_node,
                    "toNode": outside_node,
                    "length": 1.0,
                    "capacity": in_cap,
                    "flow": 0.0,
                },
            }
        )

        # Exit feedlink: outside_node → zone_node (traffic leaving the network).
        # Capacity based on outgoing cut links; 0 when there are none.
        new_feedlink_feats.append(
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[lon, lat], [lon, lat]]},
                "properties": {
                    "zoneId": zone_id,
                    "fromNode": outside_node,
                    "toNode": zone_node,
                    "length": 1.0,
                    "capacity": out_cap,
                    "flow": 0.0,
                },
            }
        )

    # Build updated FCs (shallow copies with extended feature lists).
    updated_zones = {
        **zones_fc,
        "features": list(zones_fc.get("features") or []) + new_zone_feats,
    }
    updated_feedlinks = {
        **feedlinks_fc,
        "features": list(feedlinks_fc.get("features") or []) + new_feedlink_feats,
    }

    n_zones = len(new_zone_feats)
    n_feedlinks = len(new_feedlink_feats)
    stats: dict = {
        "externalZones": n_zones,
        "externalFeedlinks": n_feedlinks,
        "totalCutLinks": cut_count,
        "totalExternalProduction": round(production_budget, 2),
        "totalExternalAttraction": round(attraction_budget, 2),
    }
    logger.info(
        "external_zone_creator: created %d external zones, %d feedlinks",
        n_zones,
        n_feedlinks,
    )
    return updated_zones, updated_feedlinks, stats
