"""Tests for external_zone_creator_core."""

from __future__ import annotations

from unittest.mock import patch

import pytest

from osm.external_zone_creator.core.external_zone_creator_core import (
    DEFAULT_EXTERNAL_SHARE,
    EXTERNAL_FEEDLINK_PROPERTIES,
    EXTERNAL_ZONE_PROPERTIES,
    _HIGHWAY_WEIGHTS,
    create_external_zones,
)


# ---------------------------------------------------------------------------
# Fixtures / helpers
# ---------------------------------------------------------------------------


def _link(
    from_node: str,
    to_node: str,
    capacity: float,
    coords=None,
    highway: str = "",
    ref: str = "",
    name: str = "",
    speed: float = 50.0,
) -> dict:
    if coords is None:
        coords = [[0.0, 0.0], [1.0, 0.0]]
    props: dict = {
        "fromNode": from_node,
        "toNode": to_node,
        "capacity": capacity,
        "speed": speed,
        "flow": 0.0,
        "length": 1000.0,
        "ref": ref,
        "name": name,
    }
    if highway:
        props["highway"] = highway
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": props,
    }


def _zone(zone_id: str, production: float) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [0.5, 0.5]},
        "properties": {
            "zoneId": zone_id,
            "centroidLon": 0.5,
            "centroidLat": 0.5,
            "production": production,
        },
    }


def _fc(features: list) -> dict:
    return {"type": "FeatureCollection", "features": features}


# Inside the bbox [0.0, 0.0, 1.0, 1.0]:
#   node A = (0.2, 0.2) — inside
#   node B = (0.8, 0.8) — inside
#   node X = (2.0, 2.0) — outside

BBOX = [0.0, 0.0, 1.0, 1.0]

# inside → outside: outgoing link → external zone X gets ATTRACTION only
CUT_LINK_AX = _link("A", "X", 1800.0, coords=[[0.2, 0.2], [2.0, 2.0]])
# outside → inside: incoming link → external zone X gets PRODUCTION only
CUT_LINK_XB = _link("X", "B", 1500.0, coords=[[2.0, 2.0], [0.8, 0.8]])
# An internal link: A → B (both inside)
INTERNAL_LINK_AB = _link("A", "B", 1700.0, coords=[[0.2, 0.2], [0.8, 0.8]])

ZONES_FC = _fc([_zone("z0", 1000.0), _zone("z1", 500.0)])
EMPTY_FEEDLINKS = _fc([])


# ===========================================================================
# TestBasicBehavior
# ===========================================================================


class TestBasicBehavior:
    def test_returns_three_items(self) -> None:
        net = _fc([CUT_LINK_AX])
        result = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        assert len(result) == 3

    def test_creates_external_zone_for_cut_link(self) -> None:
        net = _fc([CUT_LINK_AX])
        zones_out, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        zone_ids = [f["properties"]["zoneId"] for f in zones_out["features"]]
        assert "ext_X" in zone_ids

    def test_no_duplicate_zones_for_shared_outside_node(self) -> None:
        # Two cut links sharing the same outside node X.
        net = _fc([CUT_LINK_AX, CUT_LINK_XB])
        zones_out, _, _ = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        ext_zone_ids = [
            f["properties"]["zoneId"]
            for f in zones_out["features"]
            if f["properties"].get("zoneClass") == "EXTERNAL"
        ]
        assert ext_zone_ids.count("ext_X") == 1

    def test_internal_links_not_counted(self) -> None:
        # Only the cut link should produce an external zone.
        net = _fc([INTERNAL_LINK_AB, CUT_LINK_AX])
        zones_out, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        ext_zones = [
            f for f in zones_out["features"] if f["properties"].get("zoneClass") == "EXTERNAL"
        ]
        assert len(ext_zones) == 1

    def test_existing_zones_preserved(self) -> None:
        net = _fc([CUT_LINK_AX])
        zones_out, _, _ = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        original_ids = {f["properties"]["zoneId"] for f in ZONES_FC["features"]}
        result_ids = {f["properties"]["zoneId"] for f in zones_out["features"]}
        assert original_ids.issubset(result_ids)

    def test_existing_feedlinks_preserved(self) -> None:
        existing_fl = _fc(
            [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[0.5, 0.5], [0.2, 0.2]]},
                    "properties": {
                        "zoneId": "z0",
                        "fromNode": "ZONE_z0",
                        "toNode": "A",
                        "length": 500.0,
                        "capacity": 9999.0,
                        "flow": 0.0,
                    },
                }
            ]
        )
        net = _fc([CUT_LINK_AX])
        _, feedlinks_out, _ = create_external_zones(net, ZONES_FC, existing_fl, BBOX)
        assert any(f["properties"]["zoneId"] == "z0" for f in feedlinks_out["features"])


# ===========================================================================
# TestZoneProperties
# ===========================================================================


class TestZoneProperties:
    def _get_ext_zone(self, net_features=None) -> dict:
        net = _fc(net_features or [CUT_LINK_AX])
        zones_out, _, _ = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        return next(
            f for f in zones_out["features"] if f["properties"].get("zoneClass") == "EXTERNAL"
        )

    def test_zone_class_is_external(self) -> None:
        ext = self._get_ext_zone()
        assert ext["properties"]["zoneClass"] == "EXTERNAL"

    def test_zone_id_format(self) -> None:
        ext = self._get_ext_zone()
        assert ext["properties"]["zoneId"] == "ext_X"

    def test_centroid_lon_lat_match_outside_node_coords(self) -> None:
        ext = self._get_ext_zone()
        assert ext["properties"]["centroidLon"] == pytest.approx(2.0)
        assert ext["properties"]["centroidLat"] == pytest.approx(2.0)

    def test_zone_has_geometry_point(self) -> None:
        ext = self._get_ext_zone()
        assert ext["geometry"]["type"] == "Point"

    def test_n_buildings_is_zero(self) -> None:
        ext = self._get_ext_zone()
        assert ext["properties"]["nBuildings"] == 0

    def test_all_expected_properties_present(self) -> None:
        ext = self._get_ext_zone()
        for key in EXTERNAL_ZONE_PROPERTIES:
            assert key in ext["properties"], f"Missing property: {key}"


# ===========================================================================
# TestProduction
# ===========================================================================


class TestProduction:
    def test_production_proportional_to_capacity(self) -> None:
        # Two outside nodes with different capacities, both incoming (outside→inside).
        link_ya = _link("Y", "A", 1000.0, coords=[[3.0, 3.0], [0.2, 0.2]])
        link_za = _link("Z", "A", 3000.0, coords=[[4.0, 4.0], [0.2, 0.2]])
        net = _fc([link_ya, link_za])
        zones_fc = _fc([_zone("z0", 1000.0)])
        zones_out, _, stats = create_external_zones(net, zones_fc, EMPTY_FEEDLINKS, BBOX)

        ext_zones = {
            f["properties"]["zoneId"]: f["properties"]["production"]
            for f in zones_out["features"]
            if f["properties"].get("zoneClass") == "EXTERNAL"
        }
        # Z has 3× capacity of Y → 3× production.
        assert ext_zones["ext_Y"] == pytest.approx(ext_zones["ext_Z"] / 3, rel=1e-3)

    def test_total_external_production_equals_share_times_population(self) -> None:
        # CUT_LINK_XB is outside→inside (incoming) → contributes to production.
        net = _fc([CUT_LINK_XB])
        total_pop = sum(f["properties"]["production"] for f in ZONES_FC["features"])
        zones_out, _, stats = create_external_zones(
            net, ZONES_FC, EMPTY_FEEDLINKS, BBOX, external_share=0.40
        )
        ext_total = sum(
            f["properties"]["production"]
            for f in zones_out["features"]
            if f["properties"].get("zoneClass") == "EXTERNAL"
        )
        assert ext_total == pytest.approx(0.40 * total_pop, rel=1e-3)

    def test_custom_external_share(self) -> None:
        net = _fc([CUT_LINK_XB])
        total_pop = sum(f["properties"]["production"] for f in ZONES_FC["features"])
        zones_out, _, _ = create_external_zones(
            net, ZONES_FC, EMPTY_FEEDLINKS, BBOX, external_share=0.20
        )
        ext_total = sum(
            f["properties"]["production"]
            for f in zones_out["features"]
            if f["properties"].get("zoneClass") == "EXTERNAL"
        )
        assert ext_total == pytest.approx(0.20 * total_pop, rel=1e-3)

    def test_two_cut_links_same_node_production_comes_from_incoming(self) -> None:
        # AX is outgoing (attr only), XB is incoming (prod only).
        # X's production = all of the production budget (only one production node).
        net = _fc([CUT_LINK_AX, CUT_LINK_XB])
        total_pop = 1000.0
        zones_fc = _fc([_zone("z0", total_pop)])
        zones_out, _, stats = create_external_zones(
            net, zones_fc, EMPTY_FEEDLINKS, BBOX, external_share=1.0
        )
        ext = next(
            f for f in zones_out["features"] if f["properties"].get("zoneClass") == "EXTERNAL"
        )
        # Only XB contributes to production; X gets 100% of the production budget.
        assert ext["properties"]["production"] == pytest.approx(total_pop, rel=1e-3)


# ===========================================================================
# TestFeedlinks
# ===========================================================================


class TestFeedlinks:
    def _get_ext_feedlinks(self, net_features=None) -> list[dict]:
        net = _fc(net_features or [CUT_LINK_AX])
        _, feedlinks_out, _ = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        return [
            f for f in feedlinks_out["features"] if f["properties"]["zoneId"].startswith("ext_")
        ]

    def test_two_feedlinks_per_external_zone(self) -> None:
        fls = self._get_ext_feedlinks()
        assert len(fls) == 2

    def test_entry_feedlink_from_zone_node_to_outside_node(self) -> None:
        fls = self._get_ext_feedlinks()
        entry = next(f for f in fls if f["properties"]["fromNode"].startswith("ZONE_"))
        assert entry["properties"]["fromNode"] == "ZONE_ext_X"
        assert entry["properties"]["toNode"] == "X"

    def test_exit_feedlink_from_outside_node_to_zone_node(self) -> None:
        fls = self._get_ext_feedlinks()
        exit_fl = next(f for f in fls if not f["properties"]["fromNode"].startswith("ZONE_"))
        assert exit_fl["properties"]["fromNode"] == "X"
        assert exit_fl["properties"]["toNode"] == "ZONE_ext_X"

    def test_entry_feedlink_capacity_equals_incoming_cut_link_capacity(self) -> None:
        # CUT_LINK_XB is outside→inside → contributes to entry feedlink capacity.
        fls = self._get_ext_feedlinks([CUT_LINK_XB])
        entry = next(f for f in fls if f["properties"]["fromNode"].startswith("ZONE_"))
        assert entry["properties"]["capacity"] == pytest.approx(1500.0)

    def test_exit_feedlink_capacity_equals_outgoing_cut_link_capacity(self) -> None:
        # CUT_LINK_AX is inside→outside → contributes to exit feedlink capacity.
        fls = self._get_ext_feedlinks([CUT_LINK_AX])
        exit_fl = next(f for f in fls if not f["properties"]["fromNode"].startswith("ZONE_"))
        assert exit_fl["properties"]["capacity"] == pytest.approx(1800.0)

    def test_entry_feedlink_capacity_zero_when_no_incoming_links(self) -> None:
        # CUT_LINK_AX is outgoing only → no incoming capacity → entry feedlink capacity = 0.
        fls = self._get_ext_feedlinks([CUT_LINK_AX])
        entry = next(f for f in fls if f["properties"]["fromNode"].startswith("ZONE_"))
        assert entry["properties"]["capacity"] == pytest.approx(0.0)

    def test_exit_feedlink_capacity_zero_when_no_outgoing_links(self) -> None:
        # CUT_LINK_XB is incoming only → no outgoing capacity → exit feedlink capacity = 0.
        fls = self._get_ext_feedlinks([CUT_LINK_XB])
        exit_fl = next(f for f in fls if not f["properties"]["fromNode"].startswith("ZONE_"))
        assert exit_fl["properties"]["capacity"] == pytest.approx(0.0)

    def test_feedlink_capacities_split_by_direction_for_bidirectional_node(self) -> None:
        # AX (outgoing, 1800) and XB (incoming, 1500) both touch node X.
        # Entry feedlink capacity = 1500, exit feedlink capacity = 1800.
        net = _fc([CUT_LINK_AX, CUT_LINK_XB])
        _, feedlinks_out, _ = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        ext_fls = [f for f in feedlinks_out["features"] if f["properties"]["zoneId"] == "ext_X"]
        entry = next(f for f in ext_fls if f["properties"]["fromNode"].startswith("ZONE_"))
        exit_fl = next(f for f in ext_fls if not f["properties"]["fromNode"].startswith("ZONE_"))
        assert entry["properties"]["capacity"] == pytest.approx(1500.0)
        assert exit_fl["properties"]["capacity"] == pytest.approx(1800.0)

    def test_feedlink_length_is_one_metre(self) -> None:
        fls = self._get_ext_feedlinks()
        for fl in fls:
            assert fl["properties"]["length"] == pytest.approx(1.0)

    def test_feedlink_flow_is_zero(self) -> None:
        fls = self._get_ext_feedlinks()
        for fl in fls:
            assert fl["properties"]["flow"] == pytest.approx(0.0)

    def test_all_feedlink_properties_present(self) -> None:
        fls = self._get_ext_feedlinks()
        for fl in fls:
            for key in EXTERNAL_FEEDLINK_PROPERTIES:
                assert key in fl["properties"], f"Missing feedlink property: {key}"


# ===========================================================================
# TestStats
# ===========================================================================


class TestStats:
    def test_stats_keys_present(self) -> None:
        net = _fc([CUT_LINK_AX])
        _, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        assert "externalZones" in stats
        assert "externalFeedlinks" in stats
        assert "totalCutLinks" in stats
        assert "totalExternalProduction" in stats
        assert "totalExternalAttraction" in stats

    def test_stats_external_zones_count(self) -> None:
        net = _fc([CUT_LINK_AX])
        _, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        assert stats["externalZones"] == 1

    def test_stats_external_feedlinks_count(self) -> None:
        net = _fc([CUT_LINK_AX])
        _, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        assert stats["externalFeedlinks"] == 2

    def test_stats_total_cut_links(self) -> None:
        net = _fc([CUT_LINK_AX, CUT_LINK_XB, INTERNAL_LINK_AB])
        _, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        assert stats["totalCutLinks"] == 2

    def test_stats_total_external_production(self) -> None:
        total_pop = sum(f["properties"]["production"] for f in ZONES_FC["features"])
        net = _fc([CUT_LINK_XB])  # incoming → produces production budget
        _, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        assert stats["totalExternalProduction"] == pytest.approx(
            DEFAULT_EXTERNAL_SHARE * total_pop, rel=1e-3
        )

    def test_stats_total_external_attraction(self) -> None:
        total_pop = sum(f["properties"]["production"] for f in ZONES_FC["features"])
        net = _fc([CUT_LINK_AX])  # outgoing → produces attraction budget
        _, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        assert stats["totalExternalAttraction"] == pytest.approx(
            DEFAULT_EXTERNAL_SHARE * total_pop, rel=1e-3
        )

    def test_stats_budgets_equal_when_both_directions_present(self) -> None:
        # Both budgets are always external_share × total_pop (symmetric), regardless of
        # how many links exist in each direction.
        total_pop = sum(f["properties"]["production"] for f in ZONES_FC["features"])
        net = _fc([CUT_LINK_AX, CUT_LINK_XB])
        _, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        expected = pytest.approx(DEFAULT_EXTERNAL_SHARE * total_pop, rel=1e-3)
        assert stats["totalExternalProduction"] == expected
        assert stats["totalExternalAttraction"] == expected


# ===========================================================================
# TestEdgeCases
# ===========================================================================


class TestEdgeCases:
    def test_no_cut_links_returns_unchanged_fcs(self) -> None:
        net = _fc([INTERNAL_LINK_AB])
        zones_out, feedlinks_out, stats = create_external_zones(
            net, ZONES_FC, EMPTY_FEEDLINKS, BBOX
        )
        assert len(zones_out["features"]) == len(ZONES_FC["features"])
        assert len(feedlinks_out["features"]) == 0
        assert stats["externalZones"] == 0

    def test_empty_network_returns_unchanged_fcs(self) -> None:
        zones_out, feedlinks_out, stats = create_external_zones(
            _fc([]), ZONES_FC, EMPTY_FEEDLINKS, BBOX
        )
        assert stats["externalZones"] == 0

    def test_zero_population_zones_gives_zero_production(self) -> None:
        # CUT_LINK_XB is incoming (production path).  With zero population the
        # production budget is 0, so the external zone's production must be 0.
        zones_fc = _fc([_zone("z0", 0.0)])
        net = _fc([CUT_LINK_XB])
        zones_out, _, stats = create_external_zones(net, zones_fc, EMPTY_FEEDLINKS, BBOX)
        ext = next(
            f for f in zones_out["features"] if f["properties"].get("zoneClass") == "EXTERNAL"
        )
        assert ext["properties"]["production"] == pytest.approx(0.0)

    def test_node_on_bbox_edge_treated_as_inside(self) -> None:
        # A node exactly on the bbox boundary is inside (<=).
        link_boundary = _link("A", "EDGE", 1000.0, coords=[[0.2, 0.2], [1.0, 0.5]])
        net = _fc([link_boundary])
        _, _, stats = create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        # EDGE node is at (1.0, 0.5) which is on the bbox edge → inside → not a cut link.
        assert stats["externalZones"] == 0

    def test_original_fcs_not_mutated(self) -> None:
        net = _fc([CUT_LINK_AX])
        original_zone_count = len(ZONES_FC["features"])
        original_fl_count = len(EMPTY_FEEDLINKS["features"])
        create_external_zones(net, ZONES_FC, EMPTY_FEEDLINKS, BBOX)
        assert len(ZONES_FC["features"]) == original_zone_count
        assert len(EMPTY_FEEDLINKS["features"]) == original_fl_count


# ===========================================================================
# TestHighwayWeighting
# ===========================================================================


class TestHighwayWeighting:
    """Production should be proportional to capacity × highway_weight, so that
    zones on high-class roads (motorway, primary, …) attract more through-traffic
    than zones on local streets with the same raw capacity.

    All links here are outside→inside (incoming) so they contribute to production.
    """

    def _ext_productions(self, net_features: list, total_pop: float = 1000.0) -> dict[str, float]:
        zones_fc = _fc([_zone("z0", total_pop)])
        zones_out, _, _ = create_external_zones(
            _fc(net_features), zones_fc, EMPTY_FEEDLINKS, BBOX, external_share=1.0
        )
        return {
            f["properties"]["zoneId"]: f["properties"]["production"]
            for f in zones_out["features"]
            if f["properties"].get("zoneClass") == "EXTERNAL"
        }

    def test_motorway_node_gets_more_production_than_residential_same_capacity(self) -> None:
        # Same capacity (1000), different highway class → motorway gets 8× weight.
        link_mw = _link("MW", "A", 1000.0, coords=[[2.0, 2.0], [0.2, 0.2]], highway="motorway")
        link_res = _link("RES", "A", 1000.0, coords=[[3.0, 3.0], [0.2, 0.2]], highway="residential")
        prods = self._ext_productions([link_mw, link_res])
        # motorway weight=8, residential weight=1 → ratio 8:1
        assert prods["ext_MW"] == pytest.approx(prods["ext_RES"] * 8, rel=1e-3)

    def test_primary_node_gets_more_production_than_residential(self) -> None:
        link_pri = _link("PRI", "A", 1000.0, coords=[[2.0, 2.0], [0.2, 0.2]], highway="primary")
        link_res = _link("RES", "A", 1000.0, coords=[[3.0, 3.0], [0.2, 0.2]], highway="residential")
        prods = self._ext_productions([link_pri, link_res])
        # primary weight=4, residential weight=1 → ratio 4:1
        assert prods["ext_PRI"] == pytest.approx(prods["ext_RES"] * 4, rel=1e-3)

    def test_tertiary_node_gets_more_production_than_residential(self) -> None:
        link_ter = _link("TER", "A", 1000.0, coords=[[2.0, 2.0], [0.2, 0.2]], highway="tertiary")
        link_res = _link("RES", "A", 1000.0, coords=[[3.0, 3.0], [0.2, 0.2]], highway="residential")
        prods = self._ext_productions([link_ter, link_res])
        # tertiary weight=2, residential weight=1 → ratio 2:1
        assert prods["ext_TER"] == pytest.approx(prods["ext_RES"] * 2, rel=1e-3)

    def test_unknown_highway_tag_falls_back_to_weight_one(self) -> None:
        link_unk = _link("UNK", "A", 1000.0, coords=[[2.0, 2.0], [0.2, 0.2]], highway="farm_track")
        link_res = _link("RES", "A", 1000.0, coords=[[3.0, 3.0], [0.2, 0.2]], highway="residential")
        prods = self._ext_productions([link_unk, link_res])
        # both weight=1 → equal production
        assert prods["ext_UNK"] == pytest.approx(prods["ext_RES"], rel=1e-3)

    def test_no_highway_tag_falls_back_to_weight_one(self) -> None:
        link_no_tag = _link("NT", "A", 1000.0, coords=[[2.0, 2.0], [0.2, 0.2]])
        link_res = _link("RES", "A", 1000.0, coords=[[3.0, 3.0], [0.2, 0.2]], highway="residential")
        prods = self._ext_productions([link_no_tag, link_res])
        assert prods["ext_NT"] == pytest.approx(prods["ext_RES"], rel=1e-3)

    def test_total_production_unchanged_by_highway_weighting(self) -> None:
        # Total production must still equal external_share × total_population.
        link_mw = _link("MW", "A", 1000.0, coords=[[2.0, 2.0], [0.2, 0.2]], highway="motorway")
        link_res = _link("RES", "A", 1000.0, coords=[[3.0, 3.0], [0.2, 0.2]], highway="residential")
        total_pop = 1000.0
        prods = self._ext_productions([link_mw, link_res], total_pop)
        assert sum(prods.values()) == pytest.approx(total_pop, rel=1e-3)

    def test_highway_weights_dict_contains_expected_classes(self) -> None:
        assert _HIGHWAY_WEIGHTS["motorway"] == 8.0
        assert _HIGHWAY_WEIGHTS["trunk"] == 8.0
        assert _HIGHWAY_WEIGHTS["primary"] == 4.0
        assert _HIGHWAY_WEIGHTS["secondary"] == 4.0
        assert _HIGHWAY_WEIGHTS["tertiary"] == 2.0
        assert _HIGHWAY_WEIGHTS["unclassified"] == 2.0

    def test_multiple_incoming_links_same_node_weighted_capacity_summed(self) -> None:
        # Node X receives a motorway link (cap=1000, w=8) and a residential link
        # (cap=1000, w=1), both outside→inside.  Weighted sum = 9000.
        # Node Y receives a residential link (cap=1000, w=1).  X should get 9× Y's production.
        link_xmw = _link("X", "A", 1000.0, coords=[[2.0, 2.0], [0.2, 0.2]], highway="motorway")
        link_xres = _link("X", "B", 1000.0, coords=[[2.0, 2.0], [0.8, 0.8]], highway="residential")
        link_yres = _link("Y", "A", 1000.0, coords=[[3.0, 3.0], [0.2, 0.2]], highway="residential")
        prods = self._ext_productions([link_xmw, link_xres, link_yres])
        # X weighted sum = 1000*8 + 1000*1 = 9000; Y weighted sum = 1000*1 = 1000
        assert prods["ext_X"] == pytest.approx(prods["ext_Y"] * 9, rel=1e-3)


# ===========================================================================
# TestDirectionality
# ===========================================================================


class TestDirectionality:
    """Verify that production and attraction are assigned according to cut-link
    direction: outside→inside contributes to production, inside→outside to attraction."""

    def _ext_zone(self, net_features: list) -> dict:
        zones_fc = _fc([_zone("z0", 1000.0)])
        zones_out, _, _ = create_external_zones(
            _fc(net_features), zones_fc, EMPTY_FEEDLINKS, BBOX, external_share=1.0
        )
        return next(
            f for f in zones_out["features"] if f["properties"].get("zoneClass") == "EXTERNAL"
        )

    def test_incoming_only_link_gives_production_no_attraction(self) -> None:
        # X→B: outside→inside → production only
        zone = self._ext_zone([CUT_LINK_XB])
        assert zone["properties"]["production"] > 0.0
        assert zone["properties"]["attraction"] == pytest.approx(0.0)

    def test_outgoing_only_link_gives_attraction_no_production(self) -> None:
        # A→X: inside→outside → attraction only
        zone = self._ext_zone([CUT_LINK_AX])
        assert zone["properties"]["attraction"] > 0.0
        assert zone["properties"]["production"] == pytest.approx(0.0)

    def test_bidirectional_node_has_both_production_and_attraction(self) -> None:
        # AX (outgoing) + XB (incoming): both production and attraction for X.
        zone = self._ext_zone([CUT_LINK_AX, CUT_LINK_XB])
        assert zone["properties"]["production"] > 0.0
        assert zone["properties"]["attraction"] > 0.0

    def test_attraction_proportional_to_outgoing_capacity(self) -> None:
        # Two outside nodes, each with only outgoing (inside→outside) links.
        link_ay = _link("A", "Y", 1000.0, coords=[[0.2, 0.2], [3.0, 3.0]])
        link_az = _link("A", "Z", 3000.0, coords=[[0.2, 0.2], [4.0, 4.0]])
        zones_fc = _fc([_zone("z0", 1000.0)])
        zones_out, _, _ = create_external_zones(
            _fc([link_ay, link_az]), zones_fc, EMPTY_FEEDLINKS, BBOX, external_share=1.0
        )
        attrs = {
            f["properties"]["zoneId"]: f["properties"]["attraction"]
            for f in zones_out["features"]
            if f["properties"].get("zoneClass") == "EXTERNAL"
        }
        # Z has 3× capacity of Y → 3× attraction.
        assert attrs["ext_Z"] == pytest.approx(attrs["ext_Y"] * 3, rel=1e-3)

    def test_total_attraction_equals_budget(self) -> None:
        # Total attraction across all external zones = external_share × total_pop.
        link_ay = _link("A", "Y", 1000.0, coords=[[0.2, 0.2], [3.0, 3.0]])
        link_az = _link("A", "Z", 2000.0, coords=[[0.2, 0.2], [4.0, 4.0]])
        total_pop = 1000.0
        zones_fc = _fc([_zone("z0", total_pop)])
        zones_out, _, _ = create_external_zones(
            _fc([link_ay, link_az]), zones_fc, EMPTY_FEEDLINKS, BBOX, external_share=0.40
        )
        ext_attr = sum(
            f["properties"]["attraction"]
            for f in zones_out["features"]
            if f["properties"].get("zoneClass") == "EXTERNAL"
        )
        assert ext_attr == pytest.approx(0.40 * total_pop, rel=1e-3)

    def test_attraction_in_external_zone_properties_constant(self) -> None:
        assert "attraction" in EXTERNAL_ZONE_PROPERTIES


# ===========================================================================
# TestZoneName
# ===========================================================================


class TestZoneName:
    """Tests for the zone display-name logic (3-tier naming + deduplication)."""

    _BBOX = [0.0, 0.0, 1.0, 1.0]  # centre (0.5, 0.5)

    def _call(self, net_features: list, *, gisco_url: str = "https://example.test") -> list[dict]:
        """Run create_external_zones and return the list of external zone features."""
        net = _fc(net_features)
        zones_fc = _fc([_zone("z0", 1000.0)])
        zones_out, _, _ = create_external_zones(
            net, zones_fc, EMPTY_FEEDLINKS, self._BBOX, gisco_url=gisco_url
        )
        return [f for f in zones_out["features"] if f["properties"].get("zoneClass") == "EXTERNAL"]

    # --- Tier 1: motorway/trunk uses ref --------------------------------

    def test_tier1_motorway_uses_ref(self) -> None:
        link = _link(
            "A",
            "X",
            1800.0,
            coords=[[0.2, 0.2], [2.0, 2.0]],
            highway="motorway",
            ref="A1",
            speed=120.0,
        )
        zones = self._call([link])
        assert zones[0]["properties"]["zoneName"].startswith("towards A1")

    def test_tier1_trunk_uses_ref(self) -> None:
        link = _link(
            "A",
            "X",
            1800.0,
            coords=[[0.2, 0.2], [0.5, 2.0]],  # north of bbox centre
            highway="trunk",
            ref="N50",
            speed=100.0,
        )
        zones = self._call([link])
        assert "N50" in zones[0]["properties"]["zoneName"]

    def test_tier1_no_ref_falls_back_to_motorway_label(self) -> None:
        link = _link(
            "A",
            "X",
            1800.0,
            coords=[[0.2, 0.2], [2.0, 2.0]],
            highway="motorway",
            ref="",
            speed=120.0,
        )
        zones = self._call([link])
        assert zones[0]["properties"]["zoneName"].startswith("towards Motorway")

    # --- Tier 2: provincial road + speed > 50 reverse-geocodes ----------

    def test_tier2_geocodes_municipality(self) -> None:
        link = _link(
            "A",
            "X",
            1800.0,
            coords=[[0.2, 0.2], [2.0, 2.0]],
            highway="primary",
            speed=80.0,
        )
        mock_result = {"name": "Zwolle", "display_name": "Zwolle, Netherlands"}
        with patch(
            "osm.external_zone_creator.core.external_zone_creator_core._zone_name",
            wraps=None,
        ):
            pass  # verify indirectly via reverse_geocode mock below

        with patch(
            "osm.zone_population_estimator.domain.gisco.reverse_geocode",
            return_value=mock_result,
        ):
            zones = self._call([link])
        assert "Zwolle" in zones[0]["properties"]["zoneName"]

    def test_tier2_geocode_failure_falls_back_to_boundary(self) -> None:
        link = _link(
            "A",
            "X",
            1800.0,
            coords=[[0.2, 0.2], [2.0, 2.0]],
            highway="secondary",
            speed=70.0,
        )
        with patch(
            "osm.zone_population_estimator.domain.gisco.reverse_geocode",
            side_effect=OSError("timeout"),
        ):
            zones = self._call([link])
        assert zones[0]["properties"]["zoneName"].startswith("boundary (")

    # --- Tier 3: local road uses road name tag --------------------------

    def test_tier3_residential_uses_name_tag(self) -> None:
        link = _link(
            "A",
            "X",
            1000.0,
            coords=[[0.2, 0.2], [2.0, 2.0]],
            highway="residential",
            name="Dorpsstraat",
            speed=30.0,
        )
        zones = self._call([link])
        assert "Dorpsstraat" in zones[0]["properties"]["zoneName"]

    def test_tier3_no_name_tag_falls_back_to_boundary(self) -> None:
        link = _link(
            "A",
            "X",
            1000.0,
            coords=[[0.2, 0.2], [2.0, 2.0]],
            highway="residential",
            name="",
            speed=30.0,
        )
        zones = self._call([link])
        assert zones[0]["properties"]["zoneName"].startswith("boundary (")

    # --- Compass label included in name ---------------------------------

    def test_zone_name_contains_compass_label(self) -> None:
        # Node at (2.0, 2.0) is NE of bbox centre (0.5, 0.5)
        link = _link(
            "A", "X", 1800.0, coords=[[0.2, 0.2], [2.0, 2.0]], highway="motorway", ref="A2"
        )
        zones = self._call([link])
        name = zones[0]["properties"]["zoneName"]
        assert "(NE)" in name

    # --- zoneName present on every zone ---------------------------------

    def test_zone_name_present_on_every_external_zone(self) -> None:
        link_a = _link("A", "X", 1000.0, coords=[[0.2, 0.2], [2.0, 2.0]])
        link_b = _link("A", "Y", 1000.0, coords=[[0.2, 0.2], [3.0, 3.0]])
        zones = self._call([link_a, link_b])
        for z in zones:
            assert "zoneName" in z["properties"]
            assert z["properties"]["zoneName"] != ""

    def test_zone_name_in_external_zone_properties_constant(self) -> None:
        assert "zoneName" in EXTERNAL_ZONE_PROPERTIES

    # --- Deduplication --------------------------------------------------

    def test_duplicate_names_get_numeric_suffix(self) -> None:
        # Two motorway nodes with the same ref and similar direction → same raw name.
        # Place both to the NE of the bbox centre.
        link_a = _link(
            "A",
            "X",
            1800.0,
            coords=[[0.2, 0.2], [2.0, 2.0]],
            highway="motorway",
            ref="A1",
            speed=120.0,
        )
        link_b = _link(
            "A",
            "Y",
            1800.0,
            coords=[[0.2, 0.2], [2.1, 2.1]],  # also NE → same compass
            highway="motorway",
            ref="A1",
            speed=120.0,
        )
        zones = self._call([link_a, link_b])
        names = [z["properties"]["zoneName"] for z in zones]
        # Both raw names are "towards A1 (NE)" → second should get suffix
        assert len(set(names)) == len(names), f"Duplicate zone names found: {names}"
        assert any(name.endswith(" 2") for name in names)
