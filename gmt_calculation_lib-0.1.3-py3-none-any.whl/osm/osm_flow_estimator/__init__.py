"""osm_flow_estimator — synthetic 24-hour flow estimation for OSM directed networks."""
