"""Spatial index — pure stdlib, 0.005° grid cells (~350 m at mid-latitudes).

Public API
----------
GridIndex
    Bucket-based spatial index for point lookups.
    add(item_id, lon, lat) -> None
    within_radius(lon, lat, radius_m) -> list[item_id]
    centroid(geometry) -> tuple[float, float]
"""

from __future__ import annotations

import math
from collections import defaultdict

# Cell size in degrees — ~350 m at 52° N
_CELL_DEG: float = 0.005

# Approximate metres per degree of latitude
_M_PER_DEG_LAT: float = 111_320.0


def _cell(lon: float, lat: float) -> tuple[int, int]:
    return int(math.floor(lon / _CELL_DEG)), int(math.floor(lat / _CELL_DEG))


def centroid(geometry: dict) -> tuple[float, float] | None:
    """Return (lon, lat) centroid of a GeoJSON geometry.

    Supports Point, LineString, Polygon (outer ring only).
    Returns None when the geometry type is unsupported or coordinates are empty.
    """
    gtype = (geometry or {}).get("type", "")
    coords = (geometry or {}).get("coordinates")
    if not coords:
        return None

    if gtype == "Point":
        return float(coords[0]), float(coords[1])

    if gtype == "LineString":
        lons = [c[0] for c in coords]
        lats = [c[1] for c in coords]
        return sum(lons) / len(lons), sum(lats) / len(lats)

    if gtype == "Polygon":
        ring = coords[0]
        if not ring:
            return None
        # Exclude closing point if it duplicates the first
        pts = ring[:-1] if len(ring) > 1 and ring[0] == ring[-1] else ring
        if not pts:
            return None
        lons = [c[0] for c in pts]
        lats = [c[1] for c in pts]
        return sum(lons) / len(lons), sum(lats) / len(lats)

    if gtype in ("MultiPolygon", "MultiLineString"):
        # Use centroid of all coordinates flattened
        all_coords: list = []
        for part in coords:
            if gtype == "MultiPolygon":
                for ring in part:
                    all_coords.extend(ring)
            else:
                all_coords.extend(part)
        if not all_coords:
            return None
        lons = [c[0] for c in all_coords]
        lats = [c[1] for c in all_coords]
        return sum(lons) / len(lons), sum(lats) / len(lats)

    return None


class GridIndex:
    """Bucket-based spatial index backed by a dict of grid cells.

    All coordinates are in decimal degrees (WGS-84).

    Parameters
    ----------
    cell_deg:
        Cell size in degrees.  Default: 0.005° (~350 m).
    """

    def __init__(self, cell_deg: float = _CELL_DEG) -> None:
        self._cell_deg = cell_deg
        # cell → list of (item_id, lon, lat)
        self._buckets: dict[tuple[int, int], list[tuple]] = defaultdict(list)

    def add(self, item_id: object, lon: float, lat: float) -> None:
        """Add *item_id* at position (*lon*, *lat*)."""
        cx = int(math.floor(lon / self._cell_deg))
        cy = int(math.floor(lat / self._cell_deg))
        self._buckets[(cx, cy)].append((item_id, lon, lat))

    def within_radius(self, lon: float, lat: float, radius_m: float) -> list:
        """Return list of item_ids within *radius_m* metres of (*lon*, *lat*).

        Uses a bounding-box pre-filter followed by an exact great-circle check.
        """
        # Convert radius to degrees
        lat_rad = math.radians(lat)
        d_lat = radius_m / _M_PER_DEG_LAT
        # Longitude degrees per metre vary with latitude
        cos_lat = math.cos(lat_rad)
        d_lon = (radius_m / _M_PER_DEG_LAT / cos_lat) if cos_lat > 1e-9 else d_lat

        # Cell range to scan
        cmin_x = int(math.floor((lon - d_lon) / self._cell_deg))
        cmax_x = int(math.floor((lon + d_lon) / self._cell_deg))
        cmin_y = int(math.floor((lat - d_lat) / self._cell_deg))
        cmax_y = int(math.floor((lat + d_lat) / self._cell_deg))

        result = []
        radius_m2 = radius_m * radius_m
        for cx in range(cmin_x, cmax_x + 1):
            for cy in range(cmin_y, cmax_y + 1):
                for item_id, ilon, ilat in self._buckets.get((cx, cy), []):
                    dist2 = _dist_m2(lon, lat, ilon, ilat)
                    if dist2 <= radius_m2:
                        result.append(item_id)
        return result


def _dist_m2(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """Squared approximate planar distance in m² (good enough for ≤ 5 km)."""
    dlat = (lat2 - lat1) * _M_PER_DEG_LAT
    cos_lat = math.cos(math.radians((lat1 + lat2) / 2))
    dlon = (lon2 - lon1) * _M_PER_DEG_LAT * cos_lat
    return dlat * dlat + dlon * dlon
