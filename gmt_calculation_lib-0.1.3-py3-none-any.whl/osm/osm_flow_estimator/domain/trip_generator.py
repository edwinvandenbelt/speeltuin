"""Trip generator — estimates daily person-trips produced / attracted by a zone.

Public API
----------
zone_trips(zone_props, trip_rate_per_person) -> tuple[float, float]
    Return ``(residential_trips, attraction_trips)`` for a zone.
"""

from __future__ import annotations

# Default trip generation rate: trips per resident per day
DEFAULT_TRIP_RATE_PER_PERSON: float = 3.5


def zone_trips(
    zone_props: dict,
    trip_rate_per_person: float = DEFAULT_TRIP_RATE_PER_PERSON,
) -> tuple[float, float]:
    """Estimate daily trips produced and attracted by *zone_props*.

    Parameters
    ----------
    zone_props:
        Feature properties from a zone FeatureCollection.  Expected keys:
        ``production`` (float, residents), ``attraction`` (float, daily trips).
    trip_rate_per_person:
        Trip generation rate — trips per resident per day.

    Returns
    -------
    (residential_trips, attraction_trips)
        Both values are non-negative floats.
    """
    try:
        production = float(zone_props.get("production") or 0.0)
    except TypeError, ValueError:
        production = 0.0

    try:
        attraction = float(zone_props.get("attraction") or 0.0)
    except TypeError, ValueError:
        attraction = 0.0

    residential_trips = max(0.0, production * trip_rate_per_person)
    attraction_trips = max(0.0, attraction)
    return residential_trips, attraction_trips
