"""Road classifier — maps OSM highway tag (and speed fallback) to road class.

Road classes
------------
"local"      residential / living_street / service  (speed ≤ 30 km/h)
"collector"  tertiary / tertiary_link / unclassified  (speed 31–50 km/h)
"arterial"   secondary / primary / secondary_link / primary_link  (speed 51–80 km/h)
"highway"    motorway / trunk / motorway_link / trunk_link  (speed > 80 km/h)

Classification uses the ``highway`` tag as primary source; speed is the fallback
when the highway tag is absent or unrecognised.

Public API
----------
classify_link(props) -> str
    Return one of the four road-class strings.
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Tag → class lookup
# ---------------------------------------------------------------------------

_HIGHWAY_CLASS: dict[str, str] = {
    "motorway": "highway",
    "motorway_link": "highway",
    "trunk": "highway",
    "trunk_link": "highway",
    "primary": "arterial",
    "primary_link": "arterial",
    "secondary": "arterial",
    "secondary_link": "arterial",
    "tertiary": "collector",
    "tertiary_link": "collector",
    "unclassified": "collector",
    "residential": "local",
    "living_street": "local",
    "service": "local",
    "road": "local",
}


def classify_link(props: dict) -> str:
    """Return the road class for a directed or undirected link.

    Parameters
    ----------
    props:
        Feature properties dict.  Keys consulted: ``highway``, ``speed``
        (directed links), and ``max_snelheid_heen`` (undirected links).

    Returns
    -------
    One of ``"local"``, ``"collector"``, ``"arterial"``, ``"highway"``.
    """
    hw = (props.get("highway") or "").strip().lower()
    if hw in _HIGHWAY_CLASS:
        return _HIGHWAY_CLASS[hw]

    # Speed fallback — directed links use "speed", undirected use "max_snelheid_heen"
    speed = props.get("speed") if props.get("speed") is not None else props.get("max_snelheid_heen")
    try:
        spd = float(speed)  # type: ignore[arg-type]
    except TypeError, ValueError:
        return "local"

    if spd <= 30:  # noqa: PLR2004
        return "local"
    if spd <= 50:  # noqa: PLR2004
        return "collector"
    if spd <= 80:  # noqa: PLR2004
        return "arterial"
    return "highway"
