"""Flow assigner — distributes zone trips to directed road links.

Algorithm: bottom-up hierarchical spatial aggregation.

For each road class (local → collector → arterial → highway):
  1. Per zone: find all directed links of that class within search radius.
  2. Distribute the zone's daily trips proportionally by weight = capacity × length.
  3. Higher-class links without direct zone assignment inherit flow from nearby
     lower-class links (propagation), reduced by absorption_factor.

Public API
----------
assign_flows(
    network_features, zone_features,
    *,
    trip_rate_per_person, local_radius_m, collector_radius_m,
    arterial_radius_m, highway_radius_m, absorption_factor,
) -> dict[str, float]
    Return mapping {linkId: daily_flow}.
"""

from __future__ import annotations

import logging

from osm.osm_flow_estimator.domain.road_classifier import classify_link
from osm.osm_flow_estimator.domain.spatial_index import GridIndex, centroid
from osm.osm_flow_estimator.domain.trip_generator import (
    DEFAULT_TRIP_RATE_PER_PERSON,
    zone_trips,
)

logger = logging.getLogger(__name__)

_CLASSES: list[str] = ["local", "collector", "arterial", "highway"]

_DEFAULT_RADII: dict[str, float] = {
    "local": 75.0,
    "collector": 200.0,
    "arterial": 500.0,
    "highway": 1500.0,
}

DEFAULT_ABSORPTION_FACTOR: float = 0.6


def _link_weight(props: dict) -> float:
    """Return proportional assignment weight = capacity × length.

    Supports both directed links (``capacity``) and undirected links
    (``cap_heen`` fallback).
    """
    cap = props.get("capacity")
    if cap is None:
        cap = props.get("cap_heen")
    length = props.get("length") or 0.0
    try:
        c = float(cap) if cap is not None else 1500.0
    except TypeError, ValueError:
        c = 1500.0
    try:
        ln = float(length)
    except TypeError, ValueError:
        ln = 0.0
    return max(0.0, c * ln)


def assign_flows(
    network_features: list[dict],
    zone_features: list[dict],
    *,
    trip_rate_per_person: float = DEFAULT_TRIP_RATE_PER_PERSON,
    local_radius_m: float = _DEFAULT_RADII["local"],
    collector_radius_m: float = _DEFAULT_RADII["collector"],
    arterial_radius_m: float = _DEFAULT_RADII["arterial"],
    highway_radius_m: float = _DEFAULT_RADII["highway"],
    absorption_factor: float = DEFAULT_ABSORPTION_FACTOR,
) -> tuple[dict[str, float], dict]:
    """Distribute zone trips across directed links.

    Parameters
    ----------
    network_features:
        Directed GeoJSON Feature list (output of bidirectional_splitter).
    zone_features:
        Zone GeoJSON Feature list (output of zone_population_estimator).
    trip_rate_per_person:
        Residential trips per person per day.
    local_radius_m / collector_radius_m / arterial_radius_m / highway_radius_m:
        Assignment search radius per road class (metres).
    absorption_factor:
        Fraction of lower-class flow inherited by higher-class links in the
        propagation step.

    Returns
    -------
    (flows, stats)
        flows: dict mapping linkId → daily_flow (float)
        stats: dict with diagnostic counters
    """
    radii: dict[str, float] = {
        "local": local_radius_m,
        "collector": collector_radius_m,
        "arterial": arterial_radius_m,
        "highway": highway_radius_m,
    }

    # ------------------------------------------------------------------
    # 1. Index links by road class
    # ------------------------------------------------------------------
    class_indices: dict[str, GridIndex] = {cls: GridIndex() for cls in _CLASSES}
    # Store link centroids for propagation step
    link_by_id: dict[str, dict] = {}
    link_centroids: dict[str, tuple[float, float]] = {}

    for feat in network_features:
        props = feat.get("properties") or {}
        lid = props.get("linkId")
        if not lid:
            continue
        lid = str(lid)
        link_by_id[lid] = props
        geom = feat.get("geometry") or {}
        c = centroid(geom)
        if c is None:
            continue
        link_centroids[lid] = c
        cls = classify_link(props)
        class_indices[cls].add(lid, c[0], c[1])

    # ------------------------------------------------------------------
    # 2. Direct zone → link assignment
    # ------------------------------------------------------------------
    flows: dict[str, float] = {lid: 0.0 for lid in link_by_id}

    for zone_feat in zone_features:
        zprops = zone_feat.get("properties") or {}
        geom = zone_feat.get("geometry") or {}
        zc = centroid(geom)
        if zc is None:
            continue
        res_trips, att_trips = zone_trips(zprops, trip_rate_per_person)
        total_trips = res_trips + att_trips
        if total_trips <= 0.0:
            continue

        for cls in _CLASSES:
            radius = radii[cls]
            candidates = class_indices[cls].within_radius(zc[0], zc[1], radius)
            if not candidates:
                continue
            weights = {lid: _link_weight(link_by_id[lid]) for lid in candidates}
            total_w = sum(weights.values())
            if total_w <= 0.0:
                # Equal distribution fallback
                share = total_trips / len(candidates)
                for lid in candidates:
                    flows[lid] += share
            else:
                for lid, w in weights.items():
                    flows[lid] += total_trips * (w / total_w)

    # ------------------------------------------------------------------
    # 3. Propagation: lower → higher class
    # ------------------------------------------------------------------
    # For each higher-class link with zero flow, inherit from nearby lower
    for i, higher_cls in enumerate(_CLASSES[1:], start=1):
        lower_cls = _CLASSES[i - 1]
        lower_index = class_indices[lower_cls]

        for lid, props in link_by_id.items():
            if classify_link(props) != higher_cls:
                continue
            if flows[lid] > 0.0:
                continue
            c = link_centroids.get(lid)
            if c is None:
                continue
            nearby_lower = lower_index.within_radius(c[0], c[1], radii[higher_cls])
            if not nearby_lower:
                continue
            inherited = sum(flows.get(nl, 0.0) for nl in nearby_lower) * absorption_factor
            if inherited > 0.0:
                flows[lid] = inherited
                # Reduce source links proportionally (optional absorption)
                n = len(nearby_lower)
                for nl in nearby_lower:
                    flows[nl] = max(0.0, flows.get(nl, 0.0) * (1.0 - absorption_factor / n))

    # ------------------------------------------------------------------
    # 4. Minimum flow fallback
    # ------------------------------------------------------------------
    links_zero_before = sum(1 for v in flows.values() if v <= 0.0)
    for lid in flows:
        if flows[lid] <= 0.0:
            flows[lid] = 1.0

    stats = {
        "links_total": len(flows),
        "links_assigned": sum(1 for v in flows.values() if v > 1.0),
        "links_zero": links_zero_before,
        "total_daily_trips": sum(flows.values()),
    }
    logger.debug(
        "assign_flows: %d links assigned, %d zero-flow (fallback applied)",
        stats["links_assigned"],
        stats["links_zero"],
    )
    return flows, stats
