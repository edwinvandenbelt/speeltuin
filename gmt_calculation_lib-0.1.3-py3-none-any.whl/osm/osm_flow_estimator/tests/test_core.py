"""Tests for osm_flow_estimator — core, domain modules."""

from __future__ import annotations

import math
import sys
from pathlib import Path

# Ensure src/ is on the path when running tests directly
_SRC = Path(__file__).resolve().parents[4]
if str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))

import pytest

# ---------------------------------------------------------------------------
# road_classifier
# ---------------------------------------------------------------------------


class TestRoadClassifier:
    def test_classify_by_highway_tag(self):
        from osm.osm_flow_estimator.domain.road_classifier import classify_link

        assert classify_link({"highway": "motorway"}) == "highway"
        assert classify_link({"highway": "trunk_link"}) == "highway"
        assert classify_link({"highway": "primary"}) == "arterial"
        assert classify_link({"highway": "secondary_link"}) == "arterial"
        assert classify_link({"highway": "tertiary"}) == "collector"
        assert classify_link({"highway": "unclassified"}) == "collector"
        assert classify_link({"highway": "residential"}) == "local"
        assert classify_link({"highway": "living_street"}) == "local"
        assert classify_link({"highway": "service"}) == "local"

    def test_classify_by_speed_fallback(self):
        from osm.osm_flow_estimator.domain.road_classifier import classify_link

        assert classify_link({"speed": 130}) == "highway"
        assert classify_link({"speed": 80}) == "arterial"
        assert classify_link({"speed": 50}) == "collector"
        assert classify_link({"speed": 30}) == "local"

    def test_unknown_tag_and_no_speed_falls_back_to_local(self):
        from osm.osm_flow_estimator.domain.road_classifier import classify_link

        assert classify_link({}) == "local"
        assert classify_link({"highway": "unknown_tag_xyz"}) == "local"

    def test_highway_tag_takes_precedence_over_speed(self):
        from osm.osm_flow_estimator.domain.road_classifier import classify_link

        # highway=motorway but speed says local — tag wins
        assert classify_link({"highway": "motorway", "speed": 20}) == "highway"


# ---------------------------------------------------------------------------
# trip_generator
# ---------------------------------------------------------------------------


class TestTripGenerator:
    def test_basic(self):
        from osm.osm_flow_estimator.domain.trip_generator import zone_trips

        res, att = zone_trips({"production": 100.0, "attraction": 50.0})
        assert res == pytest.approx(350.0)
        assert att == pytest.approx(50.0)

    def test_zero_production(self):
        from osm.osm_flow_estimator.domain.trip_generator import zone_trips

        res, att = zone_trips({"production": 0.0, "attraction": 200.0})
        assert res == pytest.approx(0.0)
        assert att == pytest.approx(200.0)

    def test_missing_keys(self):
        from osm.osm_flow_estimator.domain.trip_generator import zone_trips

        res, att = zone_trips({})
        assert res == 0.0
        assert att == 0.0

    def test_custom_trip_rate(self):
        from osm.osm_flow_estimator.domain.trip_generator import zone_trips

        res, _ = zone_trips({"production": 10.0}, trip_rate_per_person=2.0)
        assert res == pytest.approx(20.0)

    def test_negative_values_clamped(self):
        from osm.osm_flow_estimator.domain.trip_generator import zone_trips

        res, att = zone_trips({"production": -5.0, "attraction": -10.0})
        assert res == 0.0
        assert att == 0.0


# ---------------------------------------------------------------------------
# spatial_index
# ---------------------------------------------------------------------------


class TestGridIndex:
    def test_add_and_find_nearby(self):
        from osm.osm_flow_estimator.domain.spatial_index import GridIndex

        idx = GridIndex()
        idx.add("link-1", 6.0, 52.0)
        idx.add("link-2", 6.001, 52.001)  # ~120 m away
        idx.add("link-far", 6.1, 52.1)  # ~10 km away

        hits = idx.within_radius(6.0, 52.0, 200.0)
        assert "link-1" in hits
        assert "link-2" in hits
        assert "link-far" not in hits

    def test_empty_index(self):
        from osm.osm_flow_estimator.domain.spatial_index import GridIndex

        idx = GridIndex()
        assert idx.within_radius(6.0, 52.0, 500.0) == []

    def test_exact_distance_boundary(self):
        from osm.osm_flow_estimator.domain.spatial_index import GridIndex

        idx = GridIndex()
        # Add a point ~100m north (use 105m query to avoid floating-point edge effects)
        delta_lat = 100.0 / 111320.0
        idx.add("edge", 6.0, 52.0 + delta_lat)
        hits_in = idx.within_radius(6.0, 52.0, 105.0)
        hits_out = idx.within_radius(6.0, 52.0, 50.0)
        assert "edge" in hits_in
        assert "edge" not in hits_out


class TestCentroid:
    def test_point(self):
        from osm.osm_flow_estimator.domain.spatial_index import centroid

        c = centroid({"type": "Point", "coordinates": [5.0, 52.0]})
        assert c == (5.0, 52.0)

    def test_linestring(self):
        from osm.osm_flow_estimator.domain.spatial_index import centroid

        c = centroid({"type": "LineString", "coordinates": [[4.0, 51.0], [6.0, 53.0]]})
        assert c == pytest.approx((5.0, 52.0))

    def test_polygon(self):
        from osm.osm_flow_estimator.domain.spatial_index import centroid

        ring = [[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0], [0.0, 0.0]]
        c = centroid({"type": "Polygon", "coordinates": [ring]})
        assert c == pytest.approx((1.0, 1.0))

    def test_none_on_unsupported(self):
        from osm.osm_flow_estimator.domain.spatial_index import centroid

        assert centroid({}) is None
        assert centroid({"type": "GeometryCollection", "geometries": []}) is None


# ---------------------------------------------------------------------------
# temporal_splitter
# ---------------------------------------------------------------------------


class TestTemporalSplitter:
    def test_split_sum_makes_sense(self):
        from osm.osm_flow_estimator.domain.temporal_splitter import split_flow

        dp = split_flow(1000.0, residential_fraction=0.5)
        # mrh + erh + rest*22 should equal daily flow
        total_reconstituted = dp["mrh"] * 1 + dp["erh"] * 1 + dp["rest"] * 22
        assert total_reconstituted == pytest.approx(1000.0, rel=1e-3)

    def test_zero_flow(self):
        from osm.osm_flow_estimator.domain.temporal_splitter import split_flow

        dp = split_flow(0.0)
        assert dp == {"mrh": 0.0, "erh": 0.0, "rest": 0.0}

    def test_purely_residential(self):
        from osm.osm_flow_estimator.domain.temporal_splitter import split_flow

        dp = split_flow(1000.0, residential_fraction=1.0)
        # mrh/erh each get 25% → 250 / 1h = 250 veh/hr
        assert dp["mrh"] == pytest.approx(250.0)
        assert dp["erh"] == pytest.approx(250.0)
        # rest gets 50% → 500 / 22h ≈ 22.73 veh/hr
        assert dp["rest"] == pytest.approx(500.0 / 22.0, rel=1e-3)

    def test_clamps_fraction(self):
        from osm.osm_flow_estimator.domain.temporal_splitter import split_flow

        dp_over = split_flow(100.0, residential_fraction=2.0)
        dp_under = split_flow(100.0, residential_fraction=-1.0)
        # Should not raise, values should be finite
        assert all(math.isfinite(v) for v in dp_over.values())
        assert all(math.isfinite(v) for v in dp_under.values())


# ---------------------------------------------------------------------------
# estimate_flow (core integration)
# ---------------------------------------------------------------------------


def _make_link(link_id: str, lon: float, lat: float, highway: str = "residential") -> dict:
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [[lon, lat], [lon + 0.001, lat]],
        },
        "properties": {
            "linkId": link_id,
            "capacity": 1500.0,
            "lanes": 1,
            "speed": 30.0,
            "length": 80.0,
            "mode": "CAR",
            "highway": highway,
            "flow": 0,
            "flow24hrs": 0,
            "flowsPerMotive": {},
            "flowsPerDaypart": {"mrh": 0, "erh": 0, "rest": 0},
            "remainingCap": 1500.0,
        },
    }


def _make_zone(zone_id: str, lon: float, lat: float, production: float, attraction: float) -> dict:
    d = 0.002
    return {
        "type": "Feature",
        "geometry": {
            "type": "Polygon",
            "coordinates": [
                [
                    [lon - d, lat - d],
                    [lon + d, lat - d],
                    [lon + d, lat + d],
                    [lon - d, lat + d],
                    [lon - d, lat - d],
                ]
            ],
        },
        "properties": {
            "zoneId": zone_id,
            "production": production,
            "attraction": attraction,
        },
    }


class TestEstimateFlow:
    def _network_fc(self):
        return {
            "type": "FeatureCollection",
            "features": [
                _make_link("link-1", 6.0, 52.0),
                _make_link("link-2", 6.01, 52.0, highway="primary"),
            ],
        }

    def _zones_fc(self):
        return {
            "type": "FeatureCollection",
            "features": [
                _make_zone("z1", 6.0, 52.0, production=50.0, attraction=20.0),
            ],
        }

    def test_returns_same_number_of_features(self):
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow

        updated, _ = estimate_flow(self._network_fc(), self._zones_fc())
        assert len(updated["features"]) == 2

    def test_flow_fields_populated(self):
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow

        updated, _ = estimate_flow(self._network_fc(), self._zones_fc())
        for feat in updated["features"]:
            p = feat["properties"]
            assert "flow" in p
            assert "flow24hrs" in p
            assert "flowsPerMotive" in p
            assert "flowsPerDaypart" in p
            assert "remainingCap" in p
            assert p["flow"] >= 0.0
            assert p["flow24hrs"] >= 1.0  # minimum floor

    def test_flows_per_motive_sum_to_daily(self):
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow

        updated, _ = estimate_flow(self._network_fc(), self._zones_fc())
        for feat in updated["features"]:
            p = feat["properties"]
            motive_sum = sum(p["flowsPerMotive"].values())
            assert motive_sum == pytest.approx(p["flow24hrs"], rel=1e-3)

    def test_daypart_reconstitutes_daily(self):
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow

        updated, _ = estimate_flow(self._network_fc(), self._zones_fc())
        for feat in updated["features"]:
            p = feat["properties"]
            dp = p["flowsPerDaypart"]
            daily_from_dp = dp["mrh"] * 1 + dp["erh"] * 1 + dp["rest"] * 22
            # Allow 15% tolerance: rounding on dp values causes small drift,
            # especially on minimum-floor flows (1.0 vehicle/day).
            assert daily_from_dp == pytest.approx(p["flow24hrs"], rel=0.15)

    def test_empty_zones_still_applies_minimum(self):
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow

        zones_empty = {"type": "FeatureCollection", "features": []}
        updated, stats = estimate_flow(self._network_fc(), zones_empty)
        for feat in updated["features"]:
            assert feat["properties"]["flow24hrs"] >= 1.0

    def test_input_network_not_mutated(self):
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow

        nfc = self._network_fc()
        original_flow = nfc["features"][0]["properties"]["flow"]
        estimate_flow(nfc, self._zones_fc())
        assert nfc["features"][0]["properties"]["flow"] == original_flow

    def test_stats_returned(self):
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow

        _, stats = estimate_flow(self._network_fc(), self._zones_fc())
        assert "links_total" in stats
        assert "links_assigned" in stats
        assert "links_zero" in stats
        assert "zonesUsed" in stats
        assert stats["links_total"] == 2
        assert stats["zonesUsed"] == 1


# ---------------------------------------------------------------------------
# estimate_flow_from_routes
# ---------------------------------------------------------------------------


class TestEstimateFlowFromRoutes:
    """Tests for the route-to-link all-or-nothing flow assignment.

    ``build_matrix`` uses unit production (1.0) per zone, so each
    ``route.trips`` value is a *fraction* distributed over destinations.
    The real vehicles/day on a link = ``route.trips * originProduction``.
    Tests model this with ``originProduction`` on the OD feature and
    a ``route_fraction`` (0–1) for each sub-route.
    """

    def _directed_link(self, link_id: str, capacity: float = 1800.0) -> dict:
        return {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [1.0, 0.0]]},
            "properties": {
                "spectrumId": link_id,
                "linkId": link_id,
                "fromNode": "A",
                "toNode": "B",
                "capacity": capacity,
                "speed": 50.0,
                "flow": 0.0,
                "length": 1000.0,
            },
        }

    def _route_feature(
        self,
        link_path: list,
        route_fraction: float,
        production: float = 1000.0,
    ) -> dict:
        """Build a minimal routes-fc OD feature.

        Parameters
        ----------
        route_fraction:
            Unit-production fraction for the sub-route (as produced by
            ``build_matrix`` / ``route_explorer``).  Actual trips on the
            link = ``route_fraction * production``.
        production:
            Origin-zone production (vehicles/day).  Written to
            ``originProduction`` so that ``estimate_flow_from_routes``
            can convert fractions to absolute flows.
        """
        return {
            "type": "Feature",
            "geometry": None,
            "properties": {
                "fromZoneId": "z_0",
                "toZoneId": "z_1",
                "originProduction": production,
                "tripFraction": round(route_fraction, 4),
                "routes": [{"trips": route_fraction, "linkPath": link_path, "nodePath": []}],
            },
        }

    def _fc(self, features: list) -> dict:
        return {"type": "FeatureCollection", "features": features}

    def test_returns_two_items(self) -> None:
        result = self._fc([self._directed_link("L1")])
        # fraction=0.1, production=1000 → expected flow = 100
        routes = self._fc([self._route_feature(["L1"], 0.1, 1000.0)])
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        out, stats = estimate_flow_from_routes(result, routes)
        assert isinstance(out, dict)
        assert isinstance(stats, dict)

    def test_trips_assigned_to_correct_link(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1"), self._directed_link("L2")])
        # fraction=0.2, production=1000 → L1 gets 200 vehicles/day, L2 gets 0
        routes = self._fc([self._route_feature(["L1"], 0.2, 1000.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        props = {f["properties"]["linkId"]: f["properties"] for f in out["features"]}
        assert props["L1"]["flow"] == pytest.approx(200.0)
        assert props["L2"]["flow"] == pytest.approx(0.0)

    def test_multiple_routes_summed_onto_shared_link(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1")])
        # Two OD pairs both using L1: 100 + 150 = 250 vehicles/day
        routes = self._fc(
            [
                self._route_feature(["L1"], 0.1, 1000.0),  # 100 vehicles
                self._route_feature(["L1"], 0.15, 1000.0),  # 150 vehicles
            ]
        )
        out, _ = estimate_flow_from_routes(net, routes)
        assert out["features"][0]["properties"]["flow"] == pytest.approx(250.0)

    def test_flow24hrs_equals_flow(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1")])
        routes = self._fc([self._route_feature(["L1"], 0.3, 1000.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        p = out["features"][0]["properties"]
        assert p["flow24hrs"] == pytest.approx(p["flow"])

    def test_flows_per_motive_is_unknown(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1")])
        # fraction=0.1, production=1000 → flow = 100
        routes = self._fc([self._route_feature(["L1"], 0.1, 1000.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        p = out["features"][0]["properties"]
        assert p["flowsPerMotive"] == {"unknown": pytest.approx(100.0)}

    def test_flows_per_daypart_ratio_is_1_1_half(self) -> None:
        """flowsPerDaypart are hourly intensities: ratio OS:AS:RD = 1:1:(10.4/20)."""
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1")])
        routes = self._fc([self._route_feature(["L1"], 1.0, 1000.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        dp = out["features"][0]["properties"]["flowsPerDaypart"]
        assert dp["mrh"] == pytest.approx(dp["erh"])
        assert dp["rest"] == pytest.approx(dp["mrh"] * (10.4 / 20.0), rel=1e-3)
        # rest must be strictly less than the peaks
        assert dp["rest"] < dp["mrh"]

    def test_remaining_cap_reduced_by_peak_flow(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1", capacity=1800.0)])
        # fraction=1.0, production=1000 → daily flow = 1000
        routes = self._fc([self._route_feature(["L1"], 1.0, 1000.0)])
        out, _ = estimate_flow_from_routes(net, routes, peak_hour_fraction=0.10)
        p = out["features"][0]["properties"]
        expected_remaining = 1800.0 - 1000.0 * 0.10
        assert p["remainingCap"] == pytest.approx(expected_remaining)

    def test_remaining_cap_floored_at_zero(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1", capacity=100.0)])
        # fraction=2.0, production=10000 → daily flow = 20000 >> capacity
        routes = self._fc([self._route_feature(["L1"], 2.0, 10000.0)])
        out, _ = estimate_flow_from_routes(net, routes, peak_hour_fraction=0.10)
        p = out["features"][0]["properties"]
        assert p["remainingCap"] == pytest.approx(0.0)

    def test_link_not_on_any_route_gets_zero_flow(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1"), self._directed_link("L2")])
        routes = self._fc([self._route_feature(["L1"], 0.5, 1000.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        props_L2 = next(
            f["properties"] for f in out["features"] if f["properties"]["linkId"] == "L2"
        )
        assert props_L2["flow"] == pytest.approx(0.0)

    def test_unknown_link_ids_in_routes_are_ignored(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1")])
        routes = self._fc([self._route_feature(["NONEXISTENT"], 0.5, 1000.0)])
        out, stats = estimate_flow_from_routes(net, routes)
        assert out["features"][0]["properties"]["flow"] == pytest.approx(0.0)

    def test_empty_routes_leaves_all_flows_zero(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1")])
        out, stats = estimate_flow_from_routes(net, self._fc([]))
        assert out["features"][0]["properties"]["flow"] == pytest.approx(0.0)
        assert stats["links_with_flow"] == 0

    def test_stats_keys(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1")])
        routes = self._fc([self._route_feature(["L1"], 0.1, 1000.0)])
        _, stats = estimate_flow_from_routes(net, routes)
        assert "links_total" in stats
        assert "links_with_flow" in stats
        assert "total_trips_assigned" in stats

    def test_stats_total_trips_assigned(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        # fraction=0.1, production=1000 → 100 real trips on this route.
        # total_trips_assigned is counted once per route (not per link).
        net = self._fc([self._directed_link("L1"), self._directed_link("L2")])
        routes = self._fc([self._route_feature(["L1", "L2"], 0.1, 1000.0)])
        _, stats = estimate_flow_from_routes(net, routes)
        assert stats["total_trips_assigned"] == pytest.approx(100.0)

    def test_link_on_route_with_zero_production_gets_minimum_one(self) -> None:
        """Even with originProduction=0, a link that appears on a route gets at least 1 vtg/24h."""
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1")])
        # route_fraction=0.5, production=0 → computed daily=0 → floor to 1
        routes = self._fc([self._route_feature(["L1"], 0.5, 0.0)])
        out, stats = estimate_flow_from_routes(net, routes)
        assert out["features"][0]["properties"]["flow"] == pytest.approx(1.0)
        assert stats["links_with_flow"] == 1

    def test_link_not_on_any_route_stays_zero(self) -> None:
        """A link that is not part of any route must remain at flow=0 (no floor applied)."""
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1"), self._directed_link("L2")])
        routes = self._fc([self._route_feature(["L1"], 0.5, 0.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        props_L2 = next(
            f["properties"] for f in out["features"] if f["properties"]["linkId"] == "L2"
        )
        assert props_L2["flow"] == pytest.approx(0.0)

    def test_original_network_not_mutated(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._directed_link("L1")])
        original_flow = net["features"][0]["properties"]["flow"]
        routes = self._fc([self._route_feature(["L1"], 0.5, 1000.0)])
        estimate_flow_from_routes(net, routes)
        assert net["features"][0]["properties"]["flow"] == original_flow


# ---------------------------------------------------------------------------
# estimate_flow_from_routes — buildingMotifRatio integration
# ---------------------------------------------------------------------------


class TestEstimateFlowBuildingMotifRatio:
    """Tests that buildingMotifRatio on a link feeds flowsPerMotive correctly."""

    def _link(self, link_id: str, building_ratio: dict | None = None) -> dict:
        props: dict = {
            "spectrumId": link_id,
            "linkId": link_id,
            "fromNode": "A",
            "toNode": "B",
            "capacity": 1800.0,
            "speed": 50.0,
            "flow": 0.0,
            "length": 1000.0,
        }
        if building_ratio is not None:
            props["buildingMotifRatio"] = building_ratio
        return {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [1.0, 0.0]]},
            "properties": props,
        }

    def _route(self, link_path: list, fraction: float, production: float = 1000.0) -> dict:
        return {
            "type": "Feature",
            "geometry": None,
            "properties": {
                "fromZoneId": "z0",
                "toZoneId": "z1",
                "originProduction": production,
                "tripFraction": fraction,
                "routes": [{"trips": fraction, "linkPath": link_path, "nodePath": []}],
            },
        }

    def _fc(self, features: list) -> dict:
        return {"type": "FeatureCollection", "features": features}

    def test_building_ratio_fills_flows_per_motive(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        ratio = {"work": 0.6, "shopping": 0.4}
        net = self._fc([self._link("L1", building_ratio=ratio)])
        routes = self._fc([self._route(["L1"], 0.1, 1000.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        fpm = out["features"][0]["properties"]["flowsPerMotive"]
        assert fpm == {
            "work": pytest.approx(60.0, abs=0.01),
            "shopping": pytest.approx(40.0, abs=0.01),
        }
        assert "unknown" not in fpm

    def test_no_building_ratio_falls_back_to_unknown(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        net = self._fc([self._link("L1", building_ratio=None)])
        routes = self._fc([self._route(["L1"], 0.1, 1000.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        fpm = out["features"][0]["properties"]["flowsPerMotive"]
        assert fpm == {"unknown": pytest.approx(100.0)}

    def test_zero_daily_flow_falls_back_to_unknown(self) -> None:
        """Even when buildingMotifRatio is present, daily=0 → {"unknown": 0}."""
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        ratio = {"work": 1.0}
        net = self._fc([self._link("L1", building_ratio=ratio)])
        # Link not on any route → daily = 0
        routes = self._fc([self._route(["L_other"], 0.1, 1000.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        fpm = out["features"][0]["properties"]["flowsPerMotive"]
        assert fpm == {"unknown": pytest.approx(0.0)}

    def test_motif_values_sum_to_daily_flow(self) -> None:
        from osm.osm_flow_estimator.core.osm_flow_estimator_core import estimate_flow_from_routes

        ratio = {"work": 0.5, "other": 0.3, "shopping": 0.2}
        net = self._fc([self._link("L1", building_ratio=ratio)])
        routes = self._fc([self._route(["L1"], 1.0, 500.0)])
        out, _ = estimate_flow_from_routes(net, routes)
        p = out["features"][0]["properties"]
        fpm = p["flowsPerMotive"]
        assert sum(fpm.values()) == pytest.approx(p["flow24hrs"], abs=0.1)


# ---------------------------------------------------------------------------
# assign_buildings_to_links
# ---------------------------------------------------------------------------


class TestAssignBuildingsToLinks:
    """Tests for street_linker.assign_buildings_to_links."""

    def _link_feature(
        self, link_id: str, lon0: float, lat0: float, lon1: float, lat1: float
    ) -> dict:
        return {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[lon0, lat0], [lon1, lat1]]},
            "properties": {"linkId": link_id, "spectrumId": link_id},
        }

    def _building(self, lon: float, lat: float, btype: str, size: float = 1.0) -> dict:
        """Return a small square polygon building near (lon, lat)."""
        d = size * 0.0001  # ~10 m offset
        coords = [
            [lon - d, lat - d],
            [lon + d, lat - d],
            [lon + d, lat + d],
            [lon - d, lat + d],
            [lon - d, lat - d],
        ]
        return {
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [coords]},
            "properties": {"buildingType": btype},
        }

    def _fc(self, features: list) -> dict:
        return {"type": "FeatureCollection", "features": features}

    def test_nearest_link_assigned(self) -> None:
        from osm.osm_building_fetcher.domain.street_linker import assign_buildings_to_links

        # Two links far apart; building is near L1
        links = self._fc(
            [
                self._link_feature("L1", 4.0, 52.0, 4.01, 52.0),
                self._link_feature("L2", 5.0, 52.0, 5.01, 52.0),
            ]
        )
        buildings = self._fc([self._building(4.005, 52.0, "work")])
        result = assign_buildings_to_links(buildings, links)
        assert "L1" in result
        assert "L2" not in result
        assert result["L1"] == {"work": pytest.approx(1.0)}

    def test_house_buildings_excluded(self) -> None:
        from osm.osm_building_fetcher.domain.street_linker import assign_buildings_to_links

        links = self._fc([self._link_feature("L1", 4.0, 52.0, 4.01, 52.0)])
        buildings = self._fc([self._building(4.005, 52.0, "house")])
        result = assign_buildings_to_links(buildings, links)
        assert result == {}

    def test_mixed_types_normalised_to_1(self) -> None:
        from osm.osm_building_fetcher.domain.street_linker import assign_buildings_to_links

        links = self._fc([self._link_feature("L1", 4.0, 52.0, 4.01, 52.0)])
        # Two buildings of different types near same link
        buildings = self._fc(
            [
                self._building(4.005, 52.0, "work", size=2.0),
                self._building(4.006, 52.0, "shopping", size=2.0),
            ]
        )
        result = assign_buildings_to_links(buildings, links)
        assert "L1" in result
        total = sum(result["L1"].values())
        assert total == pytest.approx(1.0, abs=1e-4)

    def test_empty_inputs_return_empty(self) -> None:
        from osm.osm_building_fetcher.domain.street_linker import assign_buildings_to_links

        assert assign_buildings_to_links(self._fc([]), self._fc([])) == {}
        assert (
            assign_buildings_to_links(self._fc([self._building(4.0, 52.0, "work")]), self._fc([]))
            == {}
        )

    def test_buildings_split_across_links(self) -> None:
        from osm.osm_building_fetcher.domain.street_linker import assign_buildings_to_links

        # L1 at lon≈4.005, L2 at lon≈5.005 — each gets the nearby building
        links = self._fc(
            [
                self._link_feature("L1", 4.0, 52.0, 4.01, 52.0),
                self._link_feature("L2", 5.0, 52.0, 5.01, 52.0),
            ]
        )
        buildings = self._fc(
            [
                self._building(4.005, 52.0, "work"),
                self._building(5.005, 52.0, "shopping"),
            ]
        )
        result = assign_buildings_to_links(buildings, links)
        assert "L1" in result
        assert "L2" in result
        assert result["L1"] == {"work": pytest.approx(1.0)}
        assert result["L2"] == {"shopping": pytest.approx(1.0)}
