"""Population distribution over zones.

Distributes a total population count over a set of zones in proportion to
the ``house`` building-type footprint (m²) of each zone.

Zones with zero house m² receive zero production.  If *all* zones have zero
house m², the population is divided equally so that no persons are lost.

Public API
----------
distribute_population(zones_fc, total_population) -> dict[str, float]
    Return ``{zoneId: population_share}`` for every zone in the FC.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def distribute_population(
    zones_fc: dict,
    total_population: float,
) -> dict[str, float]:
    """Distribute population over zones proportional to house m².

    Parameters
    ----------
    zones_fc:
        GeoJSON FeatureCollection produced by ``building_zone_creator``.
        Each feature's ``properties`` must contain:
        - ``zoneId`` (str)
        - ``buildingByType`` (dict mapping type label → m² float)
    total_population:
        Total population to distribute (e.g. NUTS3 region population).

    Returns
    -------
    dict[str, float]
        ``{zoneId: production}`` — one entry per zone.  Values sum to
        ``total_population`` (within floating-point rounding).
    """
    features: list[dict] = zones_fc.get("features") or []

    if not features:
        logger.warning("distribute_population called on empty FeatureCollection")
        return {}

    if total_population <= 0:
        return {
            (feat.get("properties") or {}).get("zoneId", str(i)): 0.0
            for i, feat in enumerate(features)
        }

    # Collect house m² per zone
    house_m2: dict[str, float] = {}
    for feat in features:
        props = feat.get("properties") or {}
        zone_id: str = props.get("zoneId") or str(id(feat))
        bt: dict = props.get("buildingByType") or {}
        house_m2[zone_id] = float(bt.get("house", 0.0))

    total_house = sum(house_m2.values())

    if total_house <= 0.0:
        # Fallback: equal distribution when no house m² is available
        logger.warning(
            "No house m² found in any zone — distributing population equally across %d zones",
            len(features),
        )
        equal_share = total_population / len(features)
        return {zone_id: equal_share for zone_id in house_m2}

    return {
        zone_id: round(total_population * (m2 / total_house), 2) for zone_id, m2 in house_m2.items()
    }
