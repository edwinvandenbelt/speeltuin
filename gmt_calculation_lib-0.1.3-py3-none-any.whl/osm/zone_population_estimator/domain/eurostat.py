"""Eurostat SDMX API helper for regional population data.

Fetches the total population (``JAN`` indicator — population on 1 January)
for a NUTS3 region from the Eurostat ``DEMO_R_GIND3`` dataset via the public
Eurostat Statistics API (JSON format, v1.0).

Also fetches the land area (km²) of a NUTS region from ``REG_AREA3``,
used for area-weighted population scaling when only NUTS-level data is
available.

Endpoint pattern (population)::

    {base_url}/statistics/1.0/data/DEMO_R_GIND3
        ?geo={nuts_code}&indic_de=JAN&format=JSON&lang=EN

Endpoint pattern (area)::

    {base_url}/statistics/1.0/data/REG_AREA3
        ?geo={nuts_code}&landuse=LAND&unit=KM2&format=JSON&lang=EN

Public API
----------
fetch_population(nuts_code, *, base_url, timeout) -> dict
    Return ``{"population": float, "year": int, "nuts_code": str}``.
fetch_nuts_area_km2(nuts_code, *, base_url, timeout) -> float | None
    Return land area in km², or ``None`` when unavailable.
"""

from __future__ import annotations

import json
import logging
import os
import ssl
import urllib.parse
import urllib.request

logger = logging.getLogger(__name__)

_DEFAULT_EUROSTAT_URL = "https://ec.europa.eu/eurostat/api/dissemination"
_DEFAULT_TIMEOUT = 30
_DATASET = "DEMO_R_GIND3"
_AREA_DATASET = "REG_AREA3"


def _ssl_context() -> ssl.SSLContext | None:
    """Return an unverified SSL context when SSL_VERIFY=false, else None (default verification)."""
    if os.environ.get("SSL_VERIFY", "true").strip().lower() == "false":
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        return ctx
    return None


def fetch_population(
    nuts_code: str,
    *,
    base_url: str = _DEFAULT_EUROSTAT_URL,
    timeout: int = _DEFAULT_TIMEOUT,
) -> dict:
    """Return the most recent total population for a NUTS region.

    Falls back to the next higher NUTS level (truncating the code by one
    character) when no data is found for the given code.

    Parameters
    ----------
    nuts_code:
        Eurostat NUTS code, e.g. ``"NL212"`` (NUTS3) or ``"NL21"`` (NUTS2).
    base_url:
        Eurostat API base URL (override in tests).
    timeout:
        HTTP timeout in seconds.

    Returns
    -------
    dict
        ``{"population": float, "year": int, "nuts_code": str}``

    Raises
    ------
    ValueError
        When no population data can be found even after NUTS level fallback.
    """
    code = nuts_code
    while len(code) >= 2:
        try:
            result = _query(code, base_url=base_url, timeout=timeout)
            if result is not None:
                logger.info(
                    "Population for %s → %s (year %d, queried as %s)",
                    nuts_code,
                    result["population"],
                    result["year"],
                    code,
                )
                return result
        except Exception as exc:  # noqa: BLE001
            logger.warning("Eurostat query failed for %s: %s", code, exc)
        code = code[:-1]

    raise ValueError(f"No population data found for NUTS code '{nuts_code}' or its ancestors.")


# ---------------------------------------------------------------------------
# Internal
# ---------------------------------------------------------------------------


def _query(nuts_code: str, *, base_url: str, timeout: int) -> dict | None:
    """Query Eurostat for a single NUTS code.  Returns None when no data."""
    params = urllib.parse.urlencode(
        {
            "geo": nuts_code,
            "indic_de": "JAN",
            "format": "JSON",
            "lang": "EN",
        }
    )
    url = f"{base_url.rstrip('/')}/statistics/1.0/data/{_DATASET}?{params}"
    logger.debug("Eurostat query: %s", url)

    with urllib.request.urlopen(url, timeout=timeout, context=_ssl_context()) as resp:  # noqa: S310
        raw = resp.read().decode()

    data: dict = json.loads(raw)

    values: dict[str, float] = {k: float(v) for k, v in (data.get("value") or {}).items()}
    if not values:
        return None

    # Build reverse index: position_index → year string
    time_cat = data["dimension"]["time"]["category"]
    index_to_year: dict[int, int] = {v: int(k) for k, v in time_cat["index"].items()}

    # Pick the most recent position that has a value
    best_pos: int | None = None
    best_year = -1
    for pos_str, _val in values.items():
        pos = int(pos_str)
        year = index_to_year.get(pos, -1)
        if year > best_year:
            best_year = year
            best_pos = pos

    if best_pos is None:
        return None

    return {
        "population": values[str(best_pos)],
        "year": best_year,
        "nuts_code": nuts_code,
    }


# ---------------------------------------------------------------------------
# Area lookup
# ---------------------------------------------------------------------------


def fetch_nuts_area_km2(
    nuts_code: str,
    *,
    base_url: str = _DEFAULT_EUROSTAT_URL,
    timeout: int = _DEFAULT_TIMEOUT,
) -> float | None:
    """Return the land area (km²) of a NUTS region from Eurostat REG_AREA3.

    Used for area-weighted population scaling.  Returns ``None`` (not raising)
    when no data is available so the caller can fall back gracefully.

    Parameters
    ----------
    nuts_code:
        Eurostat NUTS code, e.g. ``"DEA34"`` or ``"NL212"``.
    base_url:
        Eurostat API base URL.
    timeout:
        HTTP timeout in seconds.
    """
    params = urllib.parse.urlencode(
        {
            "geo": nuts_code,
            "landuse": "LAND",
            "unit": "KM2",
            "format": "JSON",
            "lang": "EN",
        }
    )
    url = f"{base_url.rstrip('/')}/statistics/1.0/data/{_AREA_DATASET}?{params}"
    logger.debug("Eurostat area query: %s", url)
    try:
        with urllib.request.urlopen(url, timeout=timeout, context=_ssl_context()) as resp:  # noqa: S310
            data: dict = json.loads(resp.read().decode())
    except Exception as exc:  # noqa: BLE001
        logger.debug("Eurostat REG_AREA3 query failed for %s: %s", nuts_code, exc)
        return None

    values: dict[str, float] = {k: float(v) for k, v in (data.get("value") or {}).items()}
    if not values:
        logger.debug("No REG_AREA3 data for %s", nuts_code)
        return None

    # Pick the most recent year with a value.
    try:
        time_cat = data["dimension"]["time"]["category"]
        index_to_year: dict[int, int] = {v: int(k) for k, v in time_cat["index"].items()}
        best_pos_str = max(values.keys(), key=lambda p: index_to_year.get(int(p), -1))
        area = values[best_pos_str]
    except KeyError, ValueError:
        area = next(iter(values.values()))

    logger.debug("NUTS land area for %s → %.0f km²", nuts_code, area)
    return area
