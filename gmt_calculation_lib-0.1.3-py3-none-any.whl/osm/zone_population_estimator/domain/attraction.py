"""Attraction computation from building type m² footprints.

Converts the ``buildingTypes`` dict (m² per type, as produced by
``building_zone_creator``) into an attraction score (person-movements per day)
using configurable conversion factors.

Default factors (person-movements per m² per day) are based on trip-generation
planning literature and are intentionally conservative starting values to be
calibrated per project:

+------------------+--------+----------------------------------------------+
| Building type    | Factor | Rationale                                    |
+==================+========+==============================================+
| ``school``       | 0.070  | ±7 persons/100 m² (students + staff)         |
+------------------+--------+----------------------------------------------+
| ``shopping``     | 0.100  | High visitor density for retail              |
+------------------+--------+----------------------------------------------+
| ``hospital``     | 0.040  | Patients + staff + visitors                  |
+------------------+--------+----------------------------------------------+
| ``recreational`` | 0.030  | Sports hall, theatre, etc.                   |
+------------------+--------+----------------------------------------------+
| ``work``         | 0.035  | Offices + industrial: workers + deliveries   |
+------------------+--------+----------------------------------------------+
| ``other``        | 0.010  | Mixed-use, unknown                           |
+------------------+--------+----------------------------------------------+
| ``house``        | 0.000  | Residential generates *production*, not      |
|                  |        | attraction                                   |
+------------------+--------+----------------------------------------------+

Public API
----------
DEFAULT_ATTRACTION_FACTORS : dict[str, float]
    The default factor table.  Import and override selectively.

compute_attraction(building_types_m2, factors) -> tuple[float, dict[str, float]]
    Return ``(total_attraction, attraction_by_type)``.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

DEFAULT_ATTRACTION_FACTORS: dict[str, float] = {
    "school": 0.070,
    "shopping": 0.100,
    "hospital": 0.040,
    "recreational": 0.030,
    "work": 0.035,
    "other": 0.010,
    "house": 0.000,
}

_FALLBACK_FACTOR = DEFAULT_ATTRACTION_FACTORS["other"]


def compute_attraction(
    building_types_m2: dict[str, float],
    factors: dict[str, float] | None = None,
) -> tuple[float, dict[str, float]]:
    """Compute attraction from building-type footprint areas.

    Parameters
    ----------
    building_types_m2:
        ``{building_type: m2}`` as stored in a zone's ``buildingTypes``
        property (output of ``building_zone_creator``).
    factors:
        Conversion factors ``{building_type: trips_per_m2_per_day}``.
        Defaults to ``DEFAULT_ATTRACTION_FACTORS``.
        Unknown building types fall back to the ``"other"`` factor.

    Returns
    -------
    total_attraction : float
        Sum of all type-specific attractions (person-movements/day).
    attraction_by_type : dict[str, float]
        Per-type breakdown ``{building_type: trips/day}``, rounded to 2 dp.
    """
    effective_factors = DEFAULT_ATTRACTION_FACTORS.copy()
    if factors:
        effective_factors.update(factors)

    attraction_by_type: dict[str, float] = {}
    for btype, m2 in building_types_m2.items():
        factor = effective_factors.get(btype, _FALLBACK_FACTOR)
        trips = round(float(m2) * factor, 2)
        if trips != 0.0:
            attraction_by_type[btype] = trips

    total = round(sum(attraction_by_type.values()), 2)
    return total, attraction_by_type
