"""Unit tests for bgt_fetcher core (pure functions + stubbed OGC client)."""

from __future__ import annotations

from bgt_fetcher.core.bgt_fetcher_core import (
    ASSET_TYPE_SPEED_BUMP,
    BGT_QUERY_VER,
    COLLECTION_WEGDEEL,
    fetch_bgt_assets,
    filter_speed_bumps,
)

# NL bbox (Lochem-ish) and a non-NL bbox (Paris).
_NL_BBOX = [6.39, 52.14, 6.43, 52.17]
_PARIS_BBOX = [2.2, 48.8, 2.4, 48.9]


def _polygon(offset: float = 0.0) -> dict:
    return {
        "type": "Polygon",
        "coordinates": [
            [
                [6.40 + offset, 52.15],
                [6.41 + offset, 52.15],
                [6.41 + offset, 52.16],
                [6.40 + offset, 52.15],
            ]
        ],
    }


# ---------------------------------------------------------------------------
# filter_speed_bumps
# ---------------------------------------------------------------------------


def test_filter_speed_bumps_keeps_only_verkeersdrempel() -> None:
    features = [
        {
            "type": "Feature",
            "geometry": _polygon(),
            "properties": {"functie": "rijbaan lokale weg", "plus_functie": "verkeersdrempel"},
        },
        {
            "type": "Feature",
            "geometry": _polygon(0.02),
            "properties": {"functie": "rijbaan lokale weg", "plus_functie": None},
        },
    ]
    out = filter_speed_bumps(features)
    assert len(out) == 1
    assert out[0]["properties"]["assetType"] == ASSET_TYPE_SPEED_BUMP
    # Original polygon geometry is preserved.
    assert out[0]["geometry"]["type"] == "Polygon"


def test_filter_speed_bumps_ignores_functie_field() -> None:
    # "verkeersdrempel" must be in plus_functie, not functie.
    features = [
        {"type": "Feature", "geometry": _polygon(), "properties": {"functie": "verkeersdrempel"}},
    ]
    assert filter_speed_bumps(features) == []


# ---------------------------------------------------------------------------
# fetch_bgt_assets — NL path with stubbed OGC client
# ---------------------------------------------------------------------------


def test_fetch_bgt_assets_skips_outside_nl() -> None:
    fc, stats = fetch_bgt_assets(_PARIS_BBOX)
    assert stats["source"] == "skipped"
    assert stats["total"] == 0
    assert fc["features"] == []


def test_fetch_bgt_assets_returns_speed_bumps(monkeypatch) -> None:
    def _fake_fetch(collection: str, _bbox: list[float], **_kwargs) -> list[dict]:
        assert collection == COLLECTION_WEGDEEL
        return [
            {
                "type": "Feature",
                "geometry": _polygon(),
                "properties": {"plus_functie": "verkeersdrempel"},
            },
            {
                "type": "Feature",
                "geometry": _polygon(0.02),
                "properties": {"functie": "rijbaan lokale weg"},
            },
        ]

    monkeypatch.setattr("shared.ogc_features.fetch_collection_items", _fake_fetch, raising=True)

    fc, stats = fetch_bgt_assets(_NL_BBOX)
    assert stats["source"] == "BGT"
    assert stats["speedBump"] == 1
    assert stats["total"] == 1
    assert fc["properties"]["_qv"] == BGT_QUERY_VER
    assert fc["features"][0]["properties"]["assetType"] == ASSET_TYPE_SPEED_BUMP
