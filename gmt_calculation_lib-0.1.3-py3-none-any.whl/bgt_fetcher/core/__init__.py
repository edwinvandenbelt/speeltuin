# src/bgt_fetcher/core/__init__.py
