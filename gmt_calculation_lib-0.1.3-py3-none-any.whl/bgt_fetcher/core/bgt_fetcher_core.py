"""Pure-Python bgt_fetcher core — fetches BGT speed bumps (verkeersdrempels).

Fetches speed-bump polygons for a bounding box from the Dutch BGT
(Basisregistratie Grootschalige Topografie) via the PDOK OGC API Features
service:

* **verkeersdrempels** (speed bumps) — ``wegdeel`` features whose
  ``plus_functie`` equals ``"verkeersdrempel"``; tagged
  ``assetType = "speedBump"``.

The original BGT polygon geometry is preserved.  Results are returned as a
GeoJSON ``FeatureCollection`` so they can be merged into the combined
``{area_id}-TRAFFIC-ASSETS.parquet`` produced by the prepare pipeline.

BGT does *not* register pedestrian crossings / road markings as a usable theme
(the ``weginrichtingselement`` collections only contain roosters,
geleideconstructies, etc.), so crossings are fetched from OSM by the separate
``osm_asset_fetcher`` module instead.

The service serves GeoJSON in CRS84 (WGS-84 lon/lat), so no reprojection is
needed.  BGT only covers the Netherlands: outside NL an empty collection is
returned.

Public API
----------
filter_speed_bumps(features) -> list[dict]
    Keep wegdeel features with plus_functie == "verkeersdrempel", tag speedBump.
fetch_bgt_assets(bbox, *, url, timeout) -> tuple[dict, dict]
    High-level entry: fetch + filter + tag, return (fc, stats).
"""

from __future__ import annotations

import logging

from shared.geo import is_netherlands

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached BGT output.
BGT_QUERY_VER: int = 1

#: Asset-type tag written on produced features.
ASSET_TYPE_SPEED_BUMP: str = "speedBump"

#: BGT collection id on the PDOK OGC API Features service.
COLLECTION_WEGDEEL: str = "wegdeel"

#: BGT wegdeel field + value identifying a speed bump.  In BGT the
#: "verkeersdrempel" classification lives in the ``plus_functie`` attribute
#: (the ``functie`` attribute only holds coarse road-part types like
#: "rijbaan lokale weg" / "voetpad").
PLUS_FUNCTIE_FIELD: str = "plus_functie"
FUNCTIE_VERKEERSDREMPEL: str = "verkeersdrempel"


# ---------------------------------------------------------------------------
# Filtering / tagging
# ---------------------------------------------------------------------------


def filter_speed_bumps(features: list[dict]) -> list[dict]:
    """Return BGT ``wegdeel`` features that are speed bumps, tagged accordingly.

    Keeps features whose ``properties.plus_functie`` equals
    ``"verkeersdrempel"``.  (In BGT the coarse ``functie`` attribute only holds
    road-part types such as ``"rijbaan lokale weg"``; the speed-bump
    classification lives in the ``plus_functie`` attribute.)  The original
    polygon geometry is preserved; every kept feature is tagged
    ``properties.assetType = "speedBump"``.
    """
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        if props.get(PLUS_FUNCTIE_FIELD) != FUNCTIE_VERKEERSDREMPEL:
            continue
        new_props = {**props, "assetType": ASSET_TYPE_SPEED_BUMP}
        result.append({**feat, "properties": new_props})
    return result


# ---------------------------------------------------------------------------
# High-level entry point
# ---------------------------------------------------------------------------


def fetch_bgt_assets(
    bbox: list[float],
    *,
    url: str | None = None,
    timeout: int = 60,
) -> tuple[dict, dict]:
    """Fetch BGT speed-bump polygons for *bbox* from the PDOK OGC API.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    url:
        OGC API Features base URL.  Defaults to the shared client default
        (``PDOK_BGT_URL`` env var or the public PDOK BGT endpoint).
    timeout:
        HTTP request timeout in seconds (per page).

    Returns
    -------
    fc:
        A GeoJSON ``FeatureCollection`` of BGT speed-bump polygon features, each
        tagged ``properties.assetType == "speedBump"``.
    stats:
        ``{"speedBump": int, "total": int, "source": str}``.  ``source`` is
        ``"BGT"`` or ``"skipped"`` when the bbox lies outside the Netherlands.
    """
    if not is_netherlands(bbox):
        logger.info("bbox centroid outside NL — skipping BGT fetch.")
        return (
            {
                "type": "FeatureCollection",
                "features": [],
                "properties": {"_qv": BGT_QUERY_VER, "source": "skipped"},
            },
            {"speedBump": 0, "total": 0, "source": "skipped"},
        )

    from shared.ogc_features import DEFAULT_BGT_URL, fetch_collection_items  # noqa: PLC0415

    base_url = url if url is not None else DEFAULT_BGT_URL

    raw = fetch_collection_items(COLLECTION_WEGDEEL, bbox, url=base_url, timeout=timeout)
    bumps = filter_speed_bumps(raw)
    logger.info("BGT speed bumps: %d (from %d wegdeel features)", len(bumps), len(raw))

    fc = {
        "type": "FeatureCollection",
        "features": bumps,
        "properties": {"_qv": BGT_QUERY_VER, "source": "BGT"},
    }
    stats = {"speedBump": len(bumps), "total": len(bumps), "source": "BGT"}
    return fc, stats
