"""Backward-compatibility shim — gap detection has moved to gap_detector.gap_detector_core.

Import from there directly:

    from gap_detector.gap_detector_core import detect_gaps
"""

from __future__ import annotations

from gap_detector.gap_detector_core import detect_gaps  # noqa: F401

__all__ = ["detect_gaps"]
