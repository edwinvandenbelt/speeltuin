"""Request models for the network_cleaner Lambda."""

from __future__ import annotations

from pydantic import BaseModel, Field


class HandlerInput(BaseModel):
    """Validated input for the network_cleaner handler."""

    input_network_files: list[str] = Field(..., min_length=1, description="S3 URIs of network files to clean.")
    output_folder: str = Field(..., description="S3 URI or local path of the output folder.")
