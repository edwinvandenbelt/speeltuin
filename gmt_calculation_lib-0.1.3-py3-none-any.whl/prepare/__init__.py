"""prepare — GMT preparation pipeline orchestrator."""
