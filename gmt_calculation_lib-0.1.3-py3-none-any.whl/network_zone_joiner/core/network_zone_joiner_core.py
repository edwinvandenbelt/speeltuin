"""Pure-Python network_zone_joiner core — no I/O, no boto3, no external deps.

Clips a network GeoJSON FeatureCollection to each zone polygon in a zones
FeatureCollection, producing per-zone network, zone, and feedlinks output files.

Public API
----------
join_zones_to_network(zones_fc, network_fc, zone_classes, feedlinks_fc)
    Returns a list of (zone_feature, clipped_network_fc, zone_fc, feedlinks_fc) tuples.

extend_feedlinks_for_zone(feedlinks_fc, clipped_network_fc, zone_feature, mode)
    Filters existing feedlinks and adds synthetic boundary-node feedlinks.

build_zone_output_path(output_folder, area_id, zone_id, artifact_type, mode)
    Constructs the output filename: {areaId}[{zoneId}]-{artifact_type}-{mode}.geojson
"""

from __future__ import annotations

from network_zone_joiner.domain.geometry import (  # noqa: F401
    point_in_polygon,
    clip_linestring_to_polygon,
)
from network_zone_joiner.domain.joiner import (  # noqa: F401
    join_zones_to_network,
    extend_feedlinks_for_zone,
    build_zone_output_path,
    FEEDLINK_PROPERTIES,
    _adjust_internal_zone_demands,
)
