"""Pure-Python geometry helpers for network_zone_joiner — no I/O, no boto3.

Provides point-in-polygon and polyline clipping against a polygon ring.
All coordinates are [longitude, latitude] in WGS-84 decimal degrees.
"""

from __future__ import annotations

import math


def point_in_polygon(px: float, py: float, ring: list) -> bool:
    """Ray-casting point-in-polygon test.

    Parameters
    ----------
    px, py:
        Point coordinates (longitude, latitude).
    ring:
        Polygon exterior ring as a list of ``[lon, lat]`` coordinate pairs.
        The ring may be closed (first == last) or open.

    Returns
    -------
    bool
        True if the point is strictly inside the polygon.
    """
    inside = False
    n = len(ring)
    j = n - 1
    for i in range(n):
        xi, yi = ring[i][0], ring[i][1]
        xj, yj = ring[j][0], ring[j][1]
        if (yi > py) != (yj > py):
            if px < (xj - xi) * (py - yi) / (yj - yi) + xi:
                inside = not inside
        j = i
    return inside


def _segment_intersect_t(
    ax: float, ay: float, bx: float, by: float,
    cx: float, cy: float, dx: float, dy: float,
) -> float | None:
    """Return parametric *t* of the intersection of segment A→B with segment C→D.

    Both t (on A→B) and u (on C→D) must be in [0, 1] for a valid intersection.
    Returns the t value (position along A→B) or None if no intersection.
    """
    denom = (bx - ax) * (dy - cy) - (by - ay) * (dx - cx)
    if abs(denom) < 1e-15:
        return None
    t = ((cx - ax) * (dy - cy) - (cy - ay) * (dx - cx)) / denom
    u = ((cx - ax) * (by - ay) - (cy - ay) * (bx - ax)) / denom
    if 0.0 <= t <= 1.0 and 0.0 <= u <= 1.0:
        return t
    return None


def _intersections_with_ring(
    ax: float, ay: float, bx: float, by: float, ring: list,
) -> list[tuple[float, float, float]]:
    """Return all ``(t, ix, iy)`` intersections of segment A→B with a polygon ring.

    Results are sorted by *t* (0 = A endpoint, 1 = B endpoint).
    Duplicate intersections (same *t*) are deduplicated to avoid double-toggling
    when the segment passes through a polygon vertex.
    """
    hits: list[tuple[float, float, float]] = []
    n = len(ring)
    for k in range(n - 1):
        cx, cy = ring[k][0], ring[k][1]
        dx, dy = ring[k + 1][0], ring[k + 1][1]
        t = _segment_intersect_t(ax, ay, bx, by, cx, cy, dx, dy)
        if t is not None:
            ix = ax + t * (bx - ax)
            iy = ay + t * (by - ay)
            hits.append((t, ix, iy))

    # Sort and deduplicate on t (tolerance 1e-10)
    hits.sort(key=lambda h: h[0])
    deduped: list[tuple[float, float, float]] = []
    for hit in hits:
        if deduped and abs(hit[0] - deduped[-1][0]) < 1e-10:
            continue
        deduped.append(hit)
    return deduped


def clip_linestring_to_polygon(
    coords: list,
    ring: list,
) -> list[list[list[float]]]:
    """Clip a LineString to a polygon ring, returning one or more sub-polylines.

    Implements a single-pass inside-tracking algorithm:

    * The inside/outside state is initialised from the first coordinate.
    * For each segment of the LineString, all intersections with the polygon
      ring are found and sorted by their parametric position along the segment.
    * At each intersection the state toggles; the appropriate start or end
      point is appended to the current (or a new) sub-polyline.

    Parameters
    ----------
    coords:
        LineString coordinates as a list of ``[lon, lat[, z]]`` items.
    ring:
        Exterior ring of a GeoJSON Polygon as a list of ``[lon, lat]`` pairs.
        Should be closed (first point == last point).

    Returns
    -------
    list of coordinate lists
        Each entry is a list of ``[lon, lat]`` coordinates forming one
        continuous inside portion of the original LineString.
        Returns an empty list if the LineString is entirely outside the polygon.
    """
    n_segs = len(coords) - 1
    if n_segs < 1:
        return []

    result_segments: list[list[list[float]]] = []
    current: list[list[float]] = []

    cur_inside = point_in_polygon(coords[0][0], coords[0][1], ring)
    if cur_inside:
        current = [[coords[0][0], coords[0][1]]]

    for seg_i in range(n_segs):
        ax, ay = coords[seg_i][0], coords[seg_i][1]
        bx, by = coords[seg_i + 1][0], coords[seg_i + 1][1]

        hits = _intersections_with_ring(ax, ay, bx, by, ring)

        for _t, ix, iy in hits:
            if cur_inside:
                # Exiting — close the current segment at the boundary
                current.append([ix, iy])
                if len(current) >= 2:
                    result_segments.append(current)
                current = []
            else:
                # Entering — start a new segment at the boundary
                current = [[ix, iy]]
            cur_inside = not cur_inside

        if cur_inside:
            current.append([bx, by])

    # Flush any open segment (happens when the LineString ends inside the polygon)
    if cur_inside and len(current) >= 2:
        result_segments.append(current)

    return result_segments


# ---------------------------------------------------------------------------
# Polygon buffering
# ---------------------------------------------------------------------------

# WGS-84 scale factors at ~52 °N (typical Netherlands latitude).
_M_PER_DEG_LAT_GEO = 111_320.0
_M_PER_DEG_LON_GEO = 111_320.0 * math.cos(math.radians(52.0))


def _ring_signed_area(ring: list) -> float:
    """Compute the signed area of a ring using the shoelace formula.

    A positive value means counter-clockwise (CCW); negative means clockwise
    (CW).  The ring may be open or closed (first == last).
    """
    n = len(ring)
    area = 0.0
    j = n - 1
    for i in range(n):
        area += (ring[j][0] + ring[i][0]) * (ring[j][1] - ring[i][1])
        j = i
    return area / 2.0


def _buffer_ring(ring: list, buffer_m: float) -> list:
    """Return a new polygon ring offset outward by *buffer_m* metres.

    Uses a simple parallel-edge offset: each edge of the polygon is moved
    perpendicularly outward by *buffer_m*, then adjacent offset edges are
    intersected to form the new vertices.

    The winding direction of the input ring is preserved.  For GeoJSON exterior
    rings (CCW by spec, though many files use CW), "outward" means away from
    the polygon interior.

    Parameters
    ----------
    ring:
        Closed polygon ring as a list of ``[lon, lat]`` pairs (first == last).
        Must have at least 4 points (3 unique + closing).
    buffer_m:
        Outward offset in metres.  A positive value expands the polygon; a
        negative value shrinks it.

    Returns
    -------
    list
        New closed ring (first == last) with the same number of unique vertices
        as the input.  Coordinates are in WGS-84 decimal degrees.

    Notes
    -----
    * Uses flat-earth approximation at 52 °N.  Accurate to ~0.1 % for small
      offsets (< 1 km) in the Netherlands.
    * For highly concave polygons the offset edges may self-intersect, creating
      small artefacts.  This is acceptable for typical GMT zone polygons.
    """
    pts = ring[:-1]  # drop the duplicate closing point
    n = len(pts)
    if n < 3:
        return list(ring)

    # Determine winding: positive signed area → CCW → outward normal is to the
    # left of each edge direction.  CW rings need the normal on the right.
    signed_area = _ring_signed_area(ring)
    sign = 1.0 if signed_area >= 0.0 else -1.0  # +1 → CCW (left = outward)

    # --- Convert each vertex to local metres ---
    def to_m(p: list) -> tuple[float, float]:
        return p[0] * _M_PER_DEG_LON_GEO, p[1] * _M_PER_DEG_LAT_GEO

    def from_m(x: float, y: float) -> list[float]:
        return [x / _M_PER_DEG_LON_GEO, y / _M_PER_DEG_LAT_GEO]

    pts_m = [to_m(p) for p in pts]

    # --- Build offset edges ---
    offset_edges: list[tuple[float, float, float, float]] = []
    for i in range(n):
        ax, ay = pts_m[i]
        bx, by = pts_m[(i + 1) % n]
        dx, dy = bx - ax, by - ay
        length = math.sqrt(dx * dx + dy * dy)
        if length < 1e-9:
            # Degenerate edge — keep without offset
            offset_edges.append((ax, ay, bx, by))
            continue
        # Outward perpendicular (left of direction for CCW, right for CW)
        nx = -dy / length * buffer_m * sign
        ny = dx / length * buffer_m * sign
        offset_edges.append((ax + nx, ay + ny, bx + nx, by + ny))

    # --- Intersect consecutive offset edges to get new vertices ---
    # Vertex i of the buffered polygon lies at the intersection of the offset
    # of the edge ARRIVING at vertex i (edge i-1) and the edge LEAVING vertex i
    # (edge i).  This preserves the vertex-to-index correspondence of the input.
    new_pts: list[list[float]] = []
    m = len(offset_edges)
    for i in range(m):
        ax, ay, bx, by = offset_edges[(i - 1) % m]   # edge arriving at vertex i
        cx, cy, dx2, dy2 = offset_edges[i]             # edge leaving vertex i
        # Solve: (ax,ay) + t*(bx-ax, by-ay) = (cx,cy) + s*(dx2-cx, dy2-cy)
        det = (bx - ax) * (dy2 - cy) - (by - ay) * (dx2 - cx)
        if abs(det) < 1e-12:
            # Parallel edges — use the midpoint of the shared endpoints
            new_pts.append(from_m((bx + cx) / 2.0, (by + cy) / 2.0))
        else:
            t = ((cx - ax) * (dy2 - cy) - (cy - ay) * (dx2 - cx)) / det
            new_pts.append(from_m(ax + t * (bx - ax), ay + t * (by - ay)))

    new_pts.append(new_pts[0])  # close the ring
    return new_pts


def _acute_angle_deg(dx1: float, dy1: float, dx2: float, dy2: float) -> float:
    """Return the acute angle in degrees between two 2-D direction vectors.

    The result is in the range [0, 90].  A value of 0 means the directions are
    parallel (or anti-parallel); 90 means they are perpendicular.

    Parameters
    ----------
    dx1, dy1:
        Components of the first direction vector.
    dx2, dy2:
        Components of the second direction vector.

    Returns
    -------
    float
        Acute angle in degrees, or 0.0 if either vector is zero-length.
    """
    cross = abs(dx1 * dy2 - dy1 * dx2)  # |sin θ| · |v1| · |v2|
    dot = abs(dx1 * dx2 + dy1 * dy2)    # |cos θ| · |v1| · |v2|
    if cross == 0.0 and dot == 0.0:
        return 0.0
    return math.degrees(math.atan2(cross, dot))


def _intersections_with_ring_extended(
    ax: float, ay: float, bx: float, by: float, ring: list,
) -> list[tuple[float, float, float, float, float, float, float]]:
    """Like ``_intersections_with_ring`` but also returns the boundary edge.

    Each entry is a 7-tuple ``(t, ix, iy, ex0, ey0, ex1, ey1)`` where:

    * ``t``  — parametric position along segment A→B (0 = A, 1 = B).
    * ``ix, iy`` — intersection coordinates.
    * ``ex0, ey0, ex1, ey1`` — start and end of the boundary edge that was
      crossed (from the ring).

    Results are sorted by *t* and deduplicated (same tolerance as
    ``_intersections_with_ring``).
    """
    hits: list[tuple[float, float, float, float, float, float, float]] = []
    n = len(ring)
    for k in range(n - 1):
        cx, cy = ring[k][0], ring[k][1]
        dx, dy = ring[k + 1][0], ring[k + 1][1]
        t = _segment_intersect_t(ax, ay, bx, by, cx, cy, dx, dy)
        if t is not None:
            ix = ax + t * (bx - ax)
            iy = ay + t * (by - ay)
            hits.append((t, ix, iy, cx, cy, dx, dy))

    hits.sort(key=lambda h: h[0])
    deduped: list[tuple[float, float, float, float, float, float, float]] = []
    for hit in hits:
        if deduped and abs(hit[0] - deduped[-1][0]) < 1e-10:
            continue
        deduped.append(hit)
    return deduped


def clip_linestring_to_polygon_angled(
    coords: list,
    ring: list,
    min_angle_deg: float = 2.0,
) -> list[list[list[float]]]:
    """Clip a LineString to a polygon ring, ignoring near-parallel crossings.

    Behaves like ``clip_linestring_to_polygon`` but skips any intersection
    where the acute angle between the link segment and the boundary edge is
    *less than or equal to* ``min_angle_deg``.  A near-parallel crossing is
    treated as if the segment continues through the boundary without toggling
    the inside/outside state.

    Parameters
    ----------
    coords:
        LineString coordinates as a list of ``[lon, lat[, z]]`` items.
    ring:
        Exterior ring of a GeoJSON Polygon as a list of ``[lon, lat]`` pairs.
    min_angle_deg:
        Minimum acute crossing angle (degrees) required to trigger clipping.
        Crossings with angle ≤ this value are silently ignored.

    Returns
    -------
    list of coordinate lists
        Each entry is a continuous inside portion of the original LineString.
    """
    n_segs = len(coords) - 1
    if n_segs < 1:
        return []

    result_segments: list[list[list[float]]] = []
    current: list[list[float]] = []

    cur_inside = point_in_polygon(coords[0][0], coords[0][1], ring)
    if cur_inside:
        current = [[coords[0][0], coords[0][1]]]

    for seg_i in range(n_segs):
        ax, ay = coords[seg_i][0], coords[seg_i][1]
        bx, by = coords[seg_i + 1][0], coords[seg_i + 1][1]

        hits = _intersections_with_ring_extended(ax, ay, bx, by, ring)

        for _t, ix, iy, ex0, ey0, ex1, ey1 in hits:
            angle = _acute_angle_deg(bx - ax, by - ay, ex1 - ex0, ey1 - ey0)
            if angle <= min_angle_deg:
                # Near-parallel to boundary — skip this crossing
                continue

            if cur_inside:
                current.append([ix, iy])
                if len(current) >= 2:
                    result_segments.append(current)
                current = []
            else:
                current = [[ix, iy]]
            cur_inside = not cur_inside

        if cur_inside:
            current.append([bx, by])

    if cur_inside and len(current) >= 2:
        result_segments.append(current)

    return result_segments
