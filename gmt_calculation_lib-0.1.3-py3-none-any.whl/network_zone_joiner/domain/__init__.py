# src/network_zone_joiner/domain/__init__.py
