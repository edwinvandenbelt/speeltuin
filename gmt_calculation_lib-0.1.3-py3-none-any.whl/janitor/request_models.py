"""Pydantic input schema for the janitor Lambda handler."""

from __future__ import annotations

import logging
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

logger = logging.getLogger(__name__)


class FieldSpec(BaseModel):
    """Transform spec for a single output field.

    source_field_name
        Source property key to read from.  Defaults to the target key when absent.
    minimum
        Clamp the value to at least this number.
    maximum
        Clamp the value to at most this number.
    round
        Round to this many decimal places.  ``0`` produces an integer.
    """

    model_config = ConfigDict(extra="ignore")

    source_field_name: str | None = None
    minimum: float | None = None
    maximum: float | None = None
    round: int | None = None


class HandlerInput(BaseModel):
    """Validated event payload for the janitor Lambda handler.

    Required
    --------
    input_network_file
        S3 URL of the input GeoJSON FeatureCollection: ``s3://bucket/key``.
    output_network_file
        S3 URL where the cleaned GeoJSON FeatureCollection will be written.
    output_network_format
        Format of the output file.  Currently only ``"ogc-geojson"`` is supported.
    schema
        Field-mapping schema.  Keys are the output property names; values are
        either ``null`` (keep as-is) or a :class:`FieldSpec` dict (rename +
        transform).
    """

    model_config = ConfigDict(extra="ignore")

    input_network_file: str
    output_network_file: str
    output_network_format: Literal["ogc-geojson"]
    schema: dict[str, FieldSpec | None] = Field(
        ..., description="Field-mapping schema: target_key → null | FieldSpec."
    )

    @field_validator("schema", mode="before")
    @classmethod
    def _parse_schema(cls, v: object) -> dict:
        """Accept the schema as a plain dict (values may be None or raw dicts)."""
        if not isinstance(v, dict):
            raise ValueError(f"schema must be a JSON object, got {type(v).__name__}")
        if not v:
            raise ValueError("schema must not be empty")
        return v
