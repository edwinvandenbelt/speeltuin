"""Domain logic for janitor — field-level transforms and feature cleaning.

Public API
----------
evaluate_expression(expression, props) -> float | int | None
    Evaluate a simple arithmetic expression (e.g. ``"=flow/capacity"``)
    against a feature's properties dict.

clean_features(features, schema) -> list[dict]
    Return a new list of features with only schema-defined properties.
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Safe globals available inside expressions
# ---------------------------------------------------------------------------

_MATH_NAMES: dict[str, object] = {
    name: getattr(math, name)
    for name in dir(math)
    if not name.startswith("_")
}
# Expose round, min, max as plain builtins so users can write
# =round(flow/capacity, 2)  or  =max(flow/capacity, 0.0)
_SAFE_GLOBALS: dict[str, object] = {
    "__builtins__": {},
    "round": round,
    "min": min,
    "max": max,
    **_MATH_NAMES,
}


def evaluate_expression(expression: str, props: dict) -> float | None:
    """Evaluate a simple arithmetic expression against feature properties.

    Parameters
    ----------
    expression:
        A string starting with ``=`` followed by an arithmetic formula that
        references property names as variables, e.g. ``"=flow/capacity"``,
        ``"=round(flow/capacity, 2)"``, or ``"=max(flow/capacity, 0.0)"``.
        Available functions: all ``math.*`` names plus ``round``, ``min``,
        ``max``.  No other builtins are accessible.
    props:
        The feature's properties dict.  Property values are coerced to
        ``float`` where possible.

    Returns
    -------
    float | None
        The result of the expression, or ``None`` if any referenced property
        is absent / ``None``, if a math domain error occurs (e.g. ``sqrt(-1)``),
        or if the result is NaN / infinite.
    """
    if not expression.startswith("="):
        raise ValueError(f"Expression must start with '=', got: {expression!r}")
    formula = expression[1:].strip()
    if not formula:
        return None

    # Build a safe local namespace from the feature properties.
    local_ns: dict[str, object] = {}
    for key, val in props.items():
        if val is None:
            local_ns[key] = val
        else:
            try:
                local_ns[key] = float(val)
            except (TypeError, ValueError):
                local_ns[key] = val

    try:
        result = eval(formula, _SAFE_GLOBALS, local_ns)  # noqa: S307
    except Exception as exc:
        logger.debug("Expression %r failed: %s", expression, exc)
        return None

    if result is None:
        return None
    try:
        f = float(result)
    except (TypeError, ValueError):
        logger.debug("Expression %r returned non-numeric result: %r", expression, result)
        return None
    if math.isnan(f) or math.isinf(f):
        return None
    return f


def clean_features(features: list[dict], schema: dict) -> list[dict]:
    """Return a new feature list with only schema-defined properties.

    For every feature:
    * For each target key in *schema*:
        - If the spec is ``None``: copy ``properties[target_key]`` as-is;
          ``None`` if absent.
        - If the spec is a ``dict`` (evaluated in order):
            1. ``default_value`` present → use that value as-is for every feature.
            2. ``expression`` present → evaluate against the feature's properties.
            3. Otherwise → read ``properties[source_field_name]`` (defaults to
               ``target_key`` when ``source_field_name`` is absent).
    * All other properties are dropped.

    The feature ``geometry`` and ``type`` fields are preserved unchanged.

    Parameters
    ----------
    features:
        GeoJSON Feature dicts from a FeatureCollection.
    schema:
        Mapping of ``target_key -> None | spec_dict``.

    Returns
    -------
    list[dict]
        New Feature dicts with cleaned ``properties``.
    """
    cleaned: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        new_props: dict = {}
        for target_key, spec in schema.items():
            if spec is None:
                new_props[target_key] = props.get(target_key)
            else:
                if "default_value" in spec:
                    new_props[target_key] = spec["default_value"]
                elif spec.get("expression") is not None:
                    new_props[target_key] = evaluate_expression(spec["expression"], props)
                else:
                    source_key = spec.get("source_field_name", target_key)
                    new_props[target_key] = props.get(source_key)

        cleaned.append({
            "type": feat.get("type", "Feature"),
            "geometry": feat.get("geometry"),
            "properties": new_props,
        })
    return cleaned
