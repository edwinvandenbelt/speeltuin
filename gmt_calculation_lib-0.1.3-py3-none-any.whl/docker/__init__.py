"""GMT Calculation Server package."""
