"""OdSupportMatricesCreator Lambda handler — thin I/O wrapper around
od_support_matrices_creator_core.

Supports two modes of operation:

**Standalone mode** (no ``odUri``):
    Builds a full OD support matrix from network + feedlinks + zones.
    Writes GeoJSON and/or CSV output.

**Enrichment mode** (``odUri`` provided):
    Enriches an existing OD GeoJSON with ``remainingCap`` values.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
Standalone:
{
    "inputs": {
        "networkUri":   "s3://bucket/key or local path",  // required
        "feedlinksUri": "s3://bucket/key or local path",  // required
        "zonesUri":     "s3://bucket/key or local path",  // required in standalone
        "outputUri":    "s3://bucket/key or local path",  // optional
        "outputCsvUri": "s3://bucket/key or local path"   // optional
    }
}

Enrichment:
{
    "inputs": {
        "networkUri":   "s3://bucket/key or local path",  // required
        "feedlinksUri": "s3://bucket/key or local path",  // required
        "odUri":        "s3://bucket/key or local path",  // triggers enrichment mode
        "outputUri":    "s3://bucket/key or local path",  // optional (default: overwrite odUri)
        "outputCsvUri": "s3://bucket/key or local path"   // optional
    }
}

Response (200)
--------------
{
    "statusCode": 200,
    "status":     "successful",
    "outputUri":  "..." or null,
    ...
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data, content_type)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        network_uri: str = inputs.get("networkUri", "")
        feedlinks_uri: str = inputs.get("feedlinksUri", "")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not feedlinks_uri:
            raise ValueError("inputs.feedlinksUri is required.")

        od_uri: str = inputs.get("odUri", "")
        output_uri: str = inputs.get("outputUri", "")
        output_csv_uri: str = inputs.get("outputCsvUri", "")

        logger.info("Reading network  : %s", network_uri)
        network_fc = from_geoparquet(_read_uri(network_uri))

        logger.info("Reading feedlinks: %s", feedlinks_uri)
        feedlinks_fc = from_geoparquet(_read_uri(feedlinks_uri))

        # ------------------------------------------------------------------
        # Enrichment mode
        # ------------------------------------------------------------------
        if od_uri:
            from od_support_matrices_creator.core.od_support_matrices_creator_core import (  # noqa: PLC0415
                enrich_od_geojson,
                enriched_od_to_csv,
            )

            logger.info("Reading OD       : %s", od_uri)
            od_fc = from_geoparquet(_read_uri(od_uri))
            enriched_fc = enrich_od_geojson(od_fc, network_fc, feedlinks_fc)

            out = output_uri or od_uri
            logger.info("Writing GeoJSON  : %s", out)
            _write_uri(out, to_geoparquet(enriched_fc), "application/geo+json")

            if output_csv_uri:
                csv_text = enriched_od_to_csv(enriched_fc)
                logger.info("Writing CSV      : %s", output_csv_uri)
                _write_uri(output_csv_uri, csv_text.encode("utf-8"), "text/csv")

            logger.info("Invocation complete [request_id=%s]", request_id)
            return {
                "statusCode": 200,
                "status": "successful",
                "mode": "enrichment",
                "outputUri": out,
                "outputCsvUri": output_csv_uri or None,
                "features": len(enriched_fc.get("features", [])),
            }

        # ------------------------------------------------------------------
        # Standalone mode
        # ------------------------------------------------------------------
        zones_uri: str = inputs.get("zonesUri", "")
        if not zones_uri:
            raise ValueError(
                "inputs.zonesUri is required in standalone mode "
                "(when inputs.odUri is not provided)."
            )

        from od_support_matrices_creator.core.od_support_matrices_creator_core import (  # noqa: PLC0415
            build_graph,
            compute_matrix,
            extract_zone_centroids,
            extract_zone_ids,
            records_to_csv,
            records_to_geojson,
        )

        logger.info("Reading zones    : %s", zones_uri)
        zones_fc = from_geoparquet(_read_uri(zones_uri))

        adj, zone_node_ids, zone_centroids = build_graph(network_fc, feedlinks_fc)
        zone_centroids.update(extract_zone_centroids(zones_fc))
        zone_ids = extract_zone_ids(zones_fc)

        records = compute_matrix(zone_ids, zone_node_ids, zone_centroids, adj)

        if output_uri:
            geojson_obj = records_to_geojson(records, zone_centroids)
            logger.info("Writing GeoJSON  : %s", output_uri)
            _write_uri(
                output_uri,
                json.dumps(geojson_obj, ensure_ascii=False).encode("utf-8"),
                "application/geo+json",
            )

        if output_csv_uri:
            csv_text = records_to_csv(records)
            logger.info("Writing CSV      : %s", output_csv_uri)
            _write_uri(output_csv_uri, csv_text.encode("utf-8"), "text/csv")

        n_reachable = sum(1 for r in records if r.get("travelTime") is not None)
        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "mode": "standalone",
            "outputUri": output_uri or None,
            "outputCsvUri": output_csv_uri or None,
            "pairs": len(records),
            "reachable": n_reachable,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
