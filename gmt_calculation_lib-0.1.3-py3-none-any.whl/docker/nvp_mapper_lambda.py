"""NvpMapper Lambda handler — thin I/O wrapper around nvp_mapper_core.

Reads a network GeoJSON, fetches NVP trip-segment data from Databricks, and
maps NVP trips onto Spectrum links.  Writes a CSV with columns:
``linkId``, ``nvpLinkIds``, ``nvpTripIds``.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)
DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "networkUri":       "s3://bucket/key or local path",     // required
        "nvpTable":         "nvp_experimental.silver.vw_segments",// required
        "mode":             "CAR",                               // required
        "nvpYear":          2025,                                // required
        "outputUri":        "s3://bucket/key/output.csv",        // required
        "maxlengthSublink": 5.0,   // optional (default: 5.0 m)
        "maxdist":          20.0,  // optional (default: 20.0 m)
        "maxalphaForward1": 15.0,  // optional (default: 15.0 deg)
        "maxalphaForward2": 45.0,  // optional (default: 45.0 deg)
        "maxalphaBackward": 30.0,  // optional (default: 30.0 deg)
        "fmatch12":         0.5,   // optional (default: 0.5)
        "nnb":              20     // optional (default: 20)
    }
}

Response (200)
--------------
{
    "statusCode":      200,
    "status":          "successful",
    "outputUri":       "...",
    "spectrumLinks":   int,
    "nvpLinks":        int,
    "matchedLinks":    int,
    "matchRows":       int
}
"""

from __future__ import annotations

import csv
import io
import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes, content_type: str = "text/csv") -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data, content_type)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def _polygon_from_network(fc: dict) -> str:
    """Return a GeoJSON Polygon geometry string derived from fc $.properties.bbox."""
    props = fc.get("properties") or {}
    bbox = props.get("bbox")
    if bbox is None:
        raise KeyError(
            "NETWORK GeoJSON has no 'bbox' in $.properties.  "
            "Ensure the file was produced by network_fetcher."
        )
    min_lon, min_lat, max_lon, max_lat = (float(v) for v in bbox)
    geom = {
        "type": "Polygon",
        "coordinates": [[
            [min_lon, min_lat], [max_lon, min_lat], [max_lon, max_lat],
            [min_lon, max_lat], [min_lon, min_lat],
        ]],
    }
    return json.dumps(geom)


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from nvp_mapper.core.nvp_mapper_core import map_nvp_trips  # noqa: PLC0415
        from nvp_mapper.domain.sql import fetch_nvp  # noqa: PLC0415
        from shared.databricks_sql import connect_from_env  # noqa: PLC0415
        from shared.geoparquet import from_geoparquet  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        network_uri: str = inputs.get("networkUri", "")
        nvp_table: str = inputs.get("nvpTable", "")
        mode_raw: str = inputs.get("mode", "")
        nvp_year_raw = inputs.get("nvpYear")
        output_uri: str = inputs.get("outputUri", "")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not nvp_table:
            raise ValueError("inputs.nvpTable is required.")
        if not mode_raw:
            raise ValueError("inputs.mode is required.")
        if nvp_year_raw is None:
            raise ValueError("inputs.nvpYear is required.")
        if not output_uri:
            raise ValueError("inputs.outputUri is required.")

        mode = mode_raw.upper()
        nvp_year = int(nvp_year_raw)
        maxlength_sublink: float = float(inputs.get("maxlengthSublink", 5.0))
        maxdist: float = float(inputs.get("maxdist", 20.0))
        maxalpha_forward1: float = float(inputs.get("maxalphaForward1", 15.0))
        maxalpha_forward2: float = float(inputs.get("maxalphaForward2", 45.0))
        maxalpha_backward: float = float(inputs.get("maxalphaBackward", 30.0))
        fmatch12: float = float(inputs.get("fmatch12", 0.5))
        nnb: int = int(inputs.get("nnb", 20))

        logger.info("Reading network : %s", network_uri)
        fc = from_geoparquet(_read_uri(network_uri))
        polygon_json = _polygon_from_network(fc)

        logger.info("Connecting to Databricks for NVP data ...")
        conn = connect_from_env()
        cursor = conn.cursor()
        nvp_links, nvp_vertlengths, nvp_vertxys, nvp_vertdxys, linktrips1 = fetch_nvp(
            cursor, nvp_table, polygon_json, mode, nvp_year
        )
        conn.close()
        logger.info("NVP links fetched: %d", len(nvp_links))

        stats, match_rows = map_nvp_trips(
            fc,
            nvp_links=nvp_links,
            nvp_vertlengths=nvp_vertlengths,
            nvp_vertxys=nvp_vertxys,
            nvp_vertdxys=nvp_vertdxys,
            linktrips1=linktrips1,
            maxlength_sublink=maxlength_sublink,
            maxdist=maxdist,
            maxalpha_forward1=maxalpha_forward1,
            maxalpha_forward2=maxalpha_forward2,
            maxalpha_backward=maxalpha_backward,
            fmatch12=fmatch12,
            nnb=nnb,
        )

        # Serialise match_rows to CSV
        buf = io.StringIO()
        writer = csv.writer(buf)
        writer.writerow(["linkId", "nvpLinkIds", "nvpTripIds"])
        for row in match_rows:
            writer.writerow([
                row["linkId"],
                "|".join(row["nvpLinkIds"]),
                "|".join(row["nvpTripIds"]),
            ])
        csv_bytes = buf.getvalue().encode("utf-8")

        logger.info("Writing CSV output: %s", output_uri)
        _write_uri(output_uri, csv_bytes, "text/csv")

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "outputUri": output_uri,
            "spectrumLinks": stats["spectrum_links"],
            "nvpLinks": stats["nvp_links"],
            "matchedLinks": stats["matched_links"],
            "matchRows": stats["match_rows"],
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
