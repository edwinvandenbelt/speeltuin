"""PurplePolarBearDownloader Lambda handler — thin I/O wrapper around
purple_polar_bear_downloader_core.

Downloads two ACoGo files, reads a network GeoJSON, and produces a JSON changes
file + GeoParquet Point features for visualisation.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "boundariesUrl": "https://example.com/boundaries.geojson",  // required
        "dataUrl":       "https://example.com/acogo-data.json",     // required
        "networkUri":    "s3://bucket/key or local path",           // required
        "zoneUri":       "s3://bucket/key or local path",           // optional
        "areaId":        "my-area",                                 // required
        "mode":          "CAR",                                     // required
        "outputFolder":  "s3://bucket/prefix/"                      // required
    }
}

Response (200)
--------------
{
    "statusCode":  200,
    "status":      "successful",
    "changesUri":  "...",
    "geojsonUri":  "...",
    ...stats
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback
import urllib.request

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    if uri.startswith(("https://", "http://")):
        with urllib.request.urlopen(uri, timeout=30) as resp:  # noqa: S310
            return resp.read()
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data, content_type)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def _to_delta_str(value: float) -> str:
    if value >= 0:
        return f"+{value}"
    return str(value)


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from purple_polar_bear_downloader.core.purple_polar_bear_downloader_core import (  # noqa: PLC0415
            build_changes,
        )
        from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        boundaries_url: str = inputs.get("boundariesUrl", "")
        data_url: str = inputs.get("dataUrl", "")
        network_uri: str = inputs.get("networkUri", "")
        area_id: str = inputs.get("areaId", "")
        mode_raw: str = inputs.get("mode", "")
        output_folder: str = inputs.get("outputFolder", "")
        if not boundaries_url:
            raise ValueError("inputs.boundariesUrl is required.")
        if not data_url:
            raise ValueError("inputs.dataUrl is required.")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not area_id:
            raise ValueError("inputs.areaId is required.")
        if not mode_raw:
            raise ValueError("inputs.mode is required.")
        if not output_folder:
            raise ValueError("inputs.outputFolder is required.")

        mode = mode_raw.upper()
        zone_uri: str = inputs.get("zoneUri", "")

        logger.info("Downloading boundaries: %s", boundaries_url)
        boundaries_fc: dict = json.loads(_read_uri(boundaries_url))

        logger.info("Downloading ACoGo data: %s", data_url)
        raw_data = json.loads(_read_uri(data_url))
        acogo_data: list[dict] = raw_data.get("data") or [] if isinstance(raw_data, dict) else raw_data

        logger.info("Reading network file: %s", network_uri)
        network_fc: dict = from_geoparquet(_read_uri(network_uri))

        zones_fc: dict | None = None
        if zone_uri:
            logger.info("Reading zone file: %s", zone_uri)
            zones_fc = from_geoparquet(_read_uri(zone_uri))

        changes, stats = build_changes(boundaries_fc, acogo_data, network_fc, zones_fc)

        out_folder = output_folder.rstrip("/")
        changes_uri = f"{out_folder}/{area_id}-CHANGES-{mode}.json"
        geojson_uri = f"{out_folder}/{area_id}-CHANGES-{mode}.parquet"

        # Write adjuster-format JSON (deltas as signed strings)
        adjuster_changes = [
            {
                "nodeId": c["nodeId"],
                "originalProduction": c["originalProduction"],
                "originalAttraction": c["originalAttraction"],
                "production": _to_delta_str(c["production"]),
                "attraction": _to_delta_str(c["attraction"]),
            }
            for c in changes
        ]
        logger.info("Writing JSON: %s", changes_uri)
        _write_uri(
            changes_uri,
            json.dumps(adjuster_changes, ensure_ascii=False, indent=2).encode("utf-8"),
            "application/json",
        )

        # Write GeoParquet of Point features for visualisation
        geojson_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Point", "coordinates": [c["lon"], c["lat"]]},
                    "properties": {
                        "nodeId": c["nodeId"],
                        "originalProduction": c["originalProduction"],
                        "originalAttraction": c["originalAttraction"],
                        "production": c["production"],
                        "attraction": c["attraction"],
                    },
                }
                for c in changes
            ],
        }
        logger.info("Writing GeoParquet: %s", geojson_uri)
        _write_uri(geojson_uri, to_geoparquet(geojson_fc))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "changesUri": changes_uri,
            "geojsonUri": geojson_uri,
            **stats,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
