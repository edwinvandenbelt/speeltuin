"""MelvinDownloader Lambda handler — thin I/O wrapper around melvin_downloader_core.

Downloads roadworks data from the NDW Melvin API for a bounding box and writes
a GeoParquet output file.

Environment variables
---------------------
LOG_LEVEL        – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)
MELVIN_USERNAME  – Melvin account username (required)
MELVIN_PASSWORD  – Melvin account password (required)
MELVIN_BASE_URL  – Melvin REST base URL (default: https://melvin.ndw.nu/melvinservice/rest)
MELVIN_AUTH_URL  – Melvin auth token URL
MELVIN_CLIENT_ID – OAuth2 client ID (default: melvin-frontend-prod)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "bbox":               [minLon, minLat, maxLon, maxLat],  // required
        "startPeriod":        "2025-10-01",                      // required (YYYY-MM-DD)
        "endPeriod":          "2025-10-31",                      // required (YYYY-MM-DD)
        "areasUri":           "s3://bucket/indices/melvin_areas.json",  // required
        "outputUri":          "s3://bucket/roadworks.parquet",   // required
        "activityTypes":      "WORK,EVENT",                      // optional
        "restrictionTypes":   "SPEED,COMPLETE",                  // optional
        "roadOperatorTypes":  "MUNICIPALITY",                    // optional (empty = all)
        "debug":              null                               // optional: int to limit areas
    }
}

Response (200)
--------------
{
    "statusCode":  200,
    "status":      "successful",
    "outputUri":   "...",
    "total":       int,
    "output":      int
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback
import urllib.parse
import urllib.request

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)

_DEFAULT_BASE_URL = "https://melvin.ndw.nu/melvinservice/rest"
_DEFAULT_AUTH_URL = (
    "https://iam.ndw.nu/auth/realms/ndw/protocol/openid-connect/token"
)
_DEFAULT_CLIENT_ID = "melvin-frontend-prod"


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def _authenticate(auth_url: str, client_id: str, username: str, password: str) -> str:
    payload = urllib.parse.urlencode({
        "username": username, "password": password,
        "grant_type": "password", "client_id": client_id,
    }).encode()
    req = urllib.request.Request(
        auth_url, data=payload,
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:  # noqa: S310
        body = json.loads(resp.read())
    token: str = body.get("access_token", "")
    if not token:
        raise ValueError("No access_token in Melvin auth response.")
    return token


def _export_geojson(
    base_url: str, token: str, start_period: str, end_period: str,
    area_id: int, activity_types: list[str], restriction_types: list[str],
) -> dict:
    url = f"{base_url}/export"
    body_data = {
        "startPeriod": f"{start_period}T00:00:00Z",
        "endPeriod": f"{end_period}T23:59:59Z",
        "sources": ["MELVIN", "SPIN", "LTC"],
        "areaIds": [area_id],
        "statuses": ["START", "INITIAL", "CONCEPT", "FINAL"],
        "activityTypes": activity_types,
        "restrictionTypes": restriction_types,
        "includeDetours": True,
    }
    payload = json.dumps(body_data).encode()
    req = urllib.request.Request(
        url, data=payload,
        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(req) as resp:  # noqa: S310
        return json.loads(resp.read())


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from melvin_downloader.core.melvin_downloader_core import (  # noqa: PLC0415
            find_area_ids,
            to_analytics_geojson,
        )
        from shared.geoparquet import to_geoparquet  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        bbox_raw = inputs.get("bbox")
        start_period: str = inputs.get("startPeriod", "")
        end_period: str = inputs.get("endPeriod", "")
        areas_uri: str = inputs.get("areasUri", "")
        output_uri: str = inputs.get("outputUri", "")
        if not bbox_raw:
            raise ValueError("inputs.bbox is required.")
        if not start_period:
            raise ValueError("inputs.startPeriod is required.")
        if not end_period:
            raise ValueError("inputs.endPeriod is required.")
        if not areas_uri:
            raise ValueError("inputs.areasUri is required.")
        if not output_uri:
            raise ValueError("inputs.outputUri is required.")

        bbox_parts = [float(v) for v in bbox_raw]
        activity_types = [
            t.strip() for t in inputs.get("activityTypes", "WORK,EVENT").split(",") if t.strip()
        ]
        restriction_types = [
            t.strip()
            for t in inputs.get("restrictionTypes", "SPEED,COMPLETE").split(",")
            if t.strip()
        ]
        road_operator_types_raw = inputs.get("roadOperatorTypes", "")
        road_operator_types = (
            [t.strip() for t in road_operator_types_raw.split(",") if t.strip()]
            if road_operator_types_raw else []
        )
        debug = inputs.get("debug")

        username = os.environ.get("MELVIN_USERNAME", "")
        password = os.environ.get("MELVIN_PASSWORD", "")
        if not username or not password:
            raise ValueError(
                "MELVIN_USERNAME and MELVIN_PASSWORD environment variables are required."
            )

        base_url = os.environ.get("MELVIN_BASE_URL", _DEFAULT_BASE_URL)
        auth_url = os.environ.get("MELVIN_AUTH_URL", _DEFAULT_AUTH_URL)
        client_id = os.environ.get("MELVIN_CLIENT_ID", _DEFAULT_CLIENT_ID)

        logger.info("Reading areas file: %s", areas_uri)
        areas: list = json.loads(_read_uri(areas_uri))
        if road_operator_types:
            areas = [a for a in areas if a.get("type") in road_operator_types]

        area_ids = find_area_ids(areas, bbox_parts)
        if debug is not None:
            area_ids = area_ids[: int(debug)]
        logger.info("Area IDs to download: %d", len(area_ids))

        logger.info("Authenticating with Melvin ...")
        token = _authenticate(auth_url, client_id, username, password)

        features_by_id: dict[str, dict] = {}
        for aid in area_ids:
            raw = _export_geojson(
                base_url, token, start_period, end_period,
                aid, activity_types, restriction_types,
            )
            for feat in raw.get("features", []):
                fid = str(feat.get("id") or id(feat))
                features_by_id[fid] = feat
        raw_geojson = {"type": "FeatureCollection", "features": list(features_by_id.values())}

        result_fc, stats = to_analytics_geojson(raw_geojson, bbox_parts)

        logger.info("Writing output: %s", output_uri)
        _write_uri(output_uri, to_geoparquet(result_fc))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "outputUri": output_uri,
            "total": stats["total"],
            "output": stats["output"],
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
