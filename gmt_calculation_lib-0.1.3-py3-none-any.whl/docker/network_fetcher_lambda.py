"""NetworkFetcher Lambda handler — thin I/O wrapper around network_fetcher_core.

Fetches raw network data from Databricks SQL for a bounding box or polygon and
writes per-mode GeoParquet files to S3 or a local folder.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)
DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "bbox":         [minLon, minLat, maxLon, maxLat],   // required (or polygon)
        "polygon":      "{\"type\":\"Polygon\",...}",        // optional (takes precedence over bbox)
        "modes":        ["CAR", "BIKE"],                    // required
        "outputFolder": "s3://bucket/prefix/",              // required
        "areaId":       "my-area",                          // optional (UUID generated)
        "name":         "Deventer centrum",                 // optional
        "catalog":      "spectrum",                         // optional (default: spectrum)
        "schema":       "2024_01",                          // optional (default: 2024_01)
        "regionsUri":   "s3://bucket/indices/holiday_regions.geojson"  // optional
    }
}

Response (200)
--------------
{
    "statusCode":    200,
    "status":        "successful",
    "areaId":        "...",
    "outputFolder":  "...",
    "modes":         ["CAR"],
    "outputUris":    {"CAR": "s3://..."}
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback
from uuid import uuid4

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from network_fetcher.core.network_fetcher_core import (  # noqa: PLC0415
            build_intersection_sql,
            get_pt_params,
            rows_to_feature_collection,
            VALID_MODES,
        )
        from shared.region import to_polygon_geojson, to_bbox, determine_region  # noqa: PLC0415
        from shared.geoparquet import to_geoparquet  # noqa: PLC0415
        import shared.databricks_sql as databricks_sql  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        modes_raw = inputs.get("modes")
        output_folder: str = inputs.get("outputFolder", "")
        if not modes_raw:
            raise ValueError("inputs.modes is required.")
        if not output_folder:
            raise ValueError("inputs.outputFolder is required.")

        modes = [m.upper() for m in modes_raw]
        area_id: str = inputs.get("areaId", "") or str(uuid4())
        name: str = inputs.get("name", "")
        catalog: str = inputs.get("catalog", "spectrum")
        schema: str = inputs.get("schema", "2024_01")
        regions_uri: str = inputs.get(
            "regionsUri", "s3://gmp-networks/indices/holiday_regions.geojson"
        )

        # Resolve polygon and bbox
        polygon_src: str = inputs.get("polygon", "")
        bbox_raw = inputs.get("bbox")
        if polygon_src:
            polygon_obj = json.loads(polygon_src) if isinstance(polygon_src, str) else polygon_src
            polygon_json = json.dumps(polygon_obj, ensure_ascii=False)
            coords = polygon_obj.get("coordinates", [])
            all_lons: list[float] = []
            all_lats: list[float] = []
            if polygon_obj.get("type") == "MultiPolygon":
                for poly in coords:
                    for ring in poly:
                        for c in ring:
                            all_lons.append(c[0])
                            all_lats.append(c[1])
            else:
                for ring in coords:
                    for c in ring:
                        if isinstance(c[0], (int, float)):
                            all_lons.append(c[0])
                            all_lats.append(c[1])
            normalised_bbox = (
                [min(all_lons), min(all_lats), max(all_lons), max(all_lats)]
                if all_lons else []
            )
        elif bbox_raw:
            polygon_json = to_polygon_geojson({"bbox": bbox_raw})
            normalised_bbox = to_bbox({"bbox": bbox_raw})
        else:
            raise ValueError("Either inputs.bbox or inputs.polygon is required.")

        # Resolve holiday region
        region: str | None = None
        if regions_uri:
            try:
                regions_raw = json.loads(_read_uri(regions_uri))
                region = determine_region(normalised_bbox, regions_raw.get("features", []))
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not load holiday regions: %s", exc)

        output_folder = output_folder.rstrip("/") + "/"
        output_uris: dict[str, str] = {}
        _PT_MODES = {"BUS", "TRAM", "METRO", "TRAIN"}

        with databricks_sql.connect_from_env() as conn:
            for mode in modes:
                if mode not in VALID_MODES:
                    logger.warning("Unknown mode %r — skipping.", mode)
                    continue
                sql = build_intersection_sql(mode, catalog, schema)
                with conn.cursor() as cur:
                    if mode in _PT_MODES:
                        link_mode, modaliteit = get_pt_params(mode)
                        cur.execute(sql, (link_mode, polygon_json, modaliteit, mode))
                    else:
                        cur.execute(sql, (polygon_json,))
                    col_names = [d[0] for d in cur.description]
                    rows = cur.fetchall()

                fc = rows_to_feature_collection(rows, col_names, mode)
                fc["properties"].update({
                    "bbox": normalised_bbox,
                    "region": region,
                    "area_id": area_id,
                    **({"name": name} if name else {}),
                })
                out_uri = f"{output_folder}{area_id}-NETWORK-RAW-{mode}.parquet"
                _write_uri(out_uri, to_geoparquet(fc))
                output_uris[mode] = out_uri
                logger.info("Written %s: %d features → %s", mode, len(fc["features"]), out_uri)

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "areaId": area_id,
            "outputFolder": output_folder,
            "modes": modes,
            "outputUris": output_uris,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
