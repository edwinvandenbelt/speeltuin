"""NetworkFuser Lambda handler — thin I/O wrapper around network_fuser_core.

Reads a directed network GeoJSON, merges near-duplicate links using lateral
distance and heading similarity, and writes the fused result.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "networkUri":         "s3://bucket/key or local path",  // required
        "outputUri":          "s3://bucket/key or local path",  // optional (default: overwrite)
        "maxLateralDistM":    5.0,   // optional (default: 5.0 m)
        "maxHeadingDiffDeg":  10.0   // optional (default: 10.0 deg)
    }
}

Response (200)
--------------
{
    "statusCode": 200,
    "status":     "successful",
    "outputUri":  "...",
    ...stats
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from network_fuser.core.network_fuser_core import fuse_networks  # noqa: PLC0415
        from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        network_uri: str = inputs.get("networkUri", "")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        output_uri: str = inputs.get("outputUri", "") or network_uri
        max_lateral_dist_m: float = float(inputs.get("maxLateralDistM", 5.0))
        max_heading_diff_deg: float = float(inputs.get("maxHeadingDiffDeg", 10.0))

        logger.info("Reading network : %s", network_uri)
        network_fc = from_geoparquet(_read_uri(network_uri))

        result_fc, _node_map, _link_pairs, stats = fuse_networks(
            network_fc,
            max_lateral_dist_m=max_lateral_dist_m,
            max_heading_diff_deg=max_heading_diff_deg,
        )

        logger.info("Writing output  : %s", output_uri)
        _write_uri(output_uri, to_geoparquet(result_fc))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "outputUri": output_uri,
            **stats,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
