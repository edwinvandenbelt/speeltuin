"""Process dispatcher — maps OGC process-id to (handler_fn, is_async).

All handlers are imported lazily on first call to avoid loading every module at
server startup.  This keeps cold-start time fast and prevents import errors for
modules whose optional dependencies (e.g. databricks-sql-connector) are not
installed in a lightweight deployment.
"""

from __future__ import annotations

import importlib
from typing import Any, Callable


def _lazy(module_path: str, fn_name: str = "handler") -> Callable[[dict, Any], dict]:
    """Return a wrapper that imports *module_path.fn_name* on first call."""
    _cache: list[Callable] = []

    def _wrapper(event: dict, context: Any) -> dict:
        if not _cache:
            mod = importlib.import_module(module_path)
            _cache.append(getattr(mod, fn_name))
        return _cache[0](event, context)

    return _wrapper


# ---------------------------------------------------------------------------
# Dispatch table
# process-id → {"handler": callable, "is_async": bool}
# ---------------------------------------------------------------------------

DISPATCH: dict[str, dict] = {
    # ── Async processes ────────────────────────────────────────────────────
    "prepare": {
        "handler": _lazy("docker.prepare_lambda"),
        "is_async": True,
    },
    "adjust": {
        "handler": _lazy("docker.adjust_lambda"),
        "is_async": True,
    },
    # ── Sync processes ─────────────────────────────────────────────────────
    "all-or-nothing-assign": {
        "handler": _lazy("docker.all_or_nothing_assigner_lambda"),
        "is_async": False,
    },
    "bidirectional-splitter": {
        "handler": _lazy("docker.bidirectional_splitter_lambda"),
        "is_async": False,
    },
    "compare-networks": {
        "handler": _lazy("docker.compare_networks_lambda"),
        "is_async": False,
    },
    "feedlink-fetcher": {
        "handler": _lazy("docker.feedlink_fetcher_lambda"),
        "is_async": False,
    },
    "flow-scaler": {
        "handler": _lazy("docker.flow_scaler_lambda"),
        "is_async": False,
    },
    "geojson-feature-modify": {
        "handler": _lazy("docker.geojson_feature_modifier_lambda"),
        "is_async": False,
    },
    "geojson-filter": {
        "handler": _lazy("docker.geojson_filter_lambda"),
        "is_async": False,
    },
    "janitor": {
        "handler": _lazy("docker.janitor_lambda"),
        "is_async": False,
    },
    "link-based-staq-assigner": {
        "handler": _lazy("docker.link_based_staq_assigner_lambda"),
        "is_async": False,
    },
    "matrix-builder": {
        "handler": _lazy("docker.matrix_builder_lambda"),
        "is_async": False,
    },
    "melvin-download": {
        "handler": _lazy("docker.melvin_downloader_lambda"),
        "is_async": False,
    },
    "network-cleaner": {
        "handler": _lazy("docker.network_cleaner_lambda"),
        "is_async": False,
    },
    "network-fetcher": {
        "handler": _lazy("docker.network_fetcher_lambda"),
        "is_async": False,
    },
    "network-fuser": {
        "handler": _lazy("docker.network_fuser_lambda"),
        "is_async": False,
    },
    "network-link-inserter": {
        "handler": _lazy("docker.network_link_inserter_lambda"),
        "is_async": False,
    },
    "network-simplifier": {
        "handler": _lazy("docker.network_simplifier_lambda"),
        "is_async": False,
    },
    "network-zone-joiner": {
        "handler": _lazy("docker.network_zone_joiner_lambda"),
        "is_async": False,
    },
    "nvp-map": {
        "handler": _lazy("docker.nvp_mapper_lambda"),
        "is_async": False,
    },
    "od-support-matrices-creator": {
        "handler": _lazy("docker.od_support_matrices_creator_lambda"),
        "is_async": False,
    },
    "parallel-link-finder": {
        "handler": _lazy("docker.parallel_link_finder_lambda"),
        "is_async": False,
    },
    "parquet-exporter": {
        "handler": _lazy("docker.parquet_exporter_lambda"),
        "is_async": False,
    },
    "ppb": {
        "handler": _lazy("docker.purple_polar_bear_downloader_lambda"),
        "is_async": False,
    },
    "route-applier": {
        "handler": _lazy("docker.route_applier_lambda"),
        "is_async": False,
    },
    "route-explorer": {
        "handler": _lazy("docker.route_explorer_lambda"),
        "is_async": False,
    },
    "selected-link": {
        "handler": _lazy("docker.selected_link_lambda"),
        "is_async": False,
    },
    "zone-fetcher": {
        "handler": _lazy("docker.zone_fetcher_lambda"),
        "is_async": False,
    },
    "zone-refiner": {
        "handler": _lazy("docker.zone_refiner_lambda"),
        "is_async": False,
    },
}
