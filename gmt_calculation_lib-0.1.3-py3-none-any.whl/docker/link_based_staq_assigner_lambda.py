"""LinkBasedStaqAssigner Lambda handler — thin I/O wrapper around
link_based_staq_assigner_core.

Reads network, feedlinks, and OD-matrix GeoJSON files, runs iterative STAQ
traffic assignment, and writes the assigned network GeoParquet.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "networkUri":              "s3://bucket/key or local path",  // required
        "feedlinksUri":            "s3://bucket/key or local path",  // required
        "odMatrixUri":             "s3://bucket/key or local path",  // required
        "outputFolder":            "s3://bucket/prefix/",            // required
        "areaId":                  "my-area",                        // optional
        "valueOfDistancePerKm":    0.10,   // required
        "valueOfTimePerHour":      10.0,   // required
        "durationHours":           1.0,    // required
        "fundamentalDiagramType":  "Newell",  // optional (default: Newell)
        "epsilon":                 0.001,  // optional
        "maxIterations":           100,    // optional
        "fixedPointEpsilon":       0.0001, // optional
        "fixedPointMaxIterations": 10      // optional
    }
}

Response (200)
--------------
{
    "statusCode":   200,
    "status":       "successful",
    "outputUri":    "...",
    "nLinks":       int,
    "nCentroids":   int,
    "iterations":   int,
    "rdg":          float
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from link_based_staq_assigner.core.link_based_staq_assigner_core import (  # noqa: PLC0415
            run_assignment,
        )
        from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415
        from shared.output_path import build_output_path  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        network_uri: str = inputs.get("networkUri", "")
        feedlinks_uri: str = inputs.get("feedlinksUri", "")
        od_matrix_uri: str = inputs.get("odMatrixUri", "")
        output_folder: str = inputs.get("outputFolder", "")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not feedlinks_uri:
            raise ValueError("inputs.feedlinksUri is required.")
        if not od_matrix_uri:
            raise ValueError("inputs.odMatrixUri is required.")
        if not output_folder:
            raise ValueError("inputs.outputFolder is required.")

        vod = inputs.get("valueOfDistancePerKm")
        vot = inputs.get("valueOfTimePerHour")
        dur = inputs.get("durationHours")
        if vod is None:
            raise ValueError("inputs.valueOfDistancePerKm is required.")
        if vot is None:
            raise ValueError("inputs.valueOfTimePerHour is required.")
        if dur is None:
            raise ValueError("inputs.durationHours is required.")

        value_of_distance_per_km: float = float(vod)
        value_of_time_per_hour: float = float(vot)
        duration_hours: float = float(dur)
        fundamental_diagram_type: str = inputs.get("fundamentalDiagramType", "Newell")
        epsilon: float = float(inputs.get("epsilon", 0.001))
        max_iterations: int = int(inputs.get("maxIterations", 100))
        fixed_point_epsilon: float = float(inputs.get("fixedPointEpsilon", 0.0001))
        fixed_point_max_iterations: int = int(inputs.get("fixedPointMaxIterations", 10))

        logger.info("Reading network       : %s", network_uri)
        network_geojson = from_geoparquet(_read_uri(network_uri))

        logger.info("Reading feedlinks     : %s", feedlinks_uri)
        feedlinks_geojson = from_geoparquet(_read_uri(feedlinks_uri))

        logger.info("Reading OD matrix     : %s", od_matrix_uri)
        od_matrix_geojson = from_geoparquet(_read_uri(od_matrix_uri))

        output_geojson, stats = run_assignment(
            network_geojson=network_geojson,
            feedlinks_geojson=feedlinks_geojson,
            od_matrix_geojson=od_matrix_geojson,
            value_of_distance_per_km=value_of_distance_per_km,
            value_of_time_per_hour=value_of_time_per_hour,
            duration_hours=duration_hours,
            fundamental_diagram_type=fundamental_diagram_type,
            epsilon=epsilon,
            max_iterations=max_iterations,
            fixed_point_epsilon=fixed_point_epsilon,
            fixed_point_max_iterations=fixed_point_max_iterations,
        )

        area_id: str = (
            inputs.get("areaId", "")
            or (network_geojson.get("properties") or {}).get("area_id")
            or "unknown"
        )
        output_uri = build_output_path(output_folder, area_id, "ASSIGNED-NETWORK")

        logger.info("Writing output        : %s", output_uri)
        _write_uri(output_uri, to_geoparquet(output_geojson))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "outputUri": output_uri,
            **stats,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
