"""NetworkZoneJoiner Lambda handler — thin I/O wrapper around
network_zone_joiner_core.

Reads zones, a network, and optionally feedlinks, clips the network to zone
polygons, and writes merged NETWORK, ZONE, and FEEDLINK output files.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "zonesUri":              "s3://bucket/key or local path",  // required
        "networkUri":            "s3://bucket/key or local path",  // required
        "feedlinksUri":          "s3://bucket/key or local path",  // optional
        "networkOutputUri":      "s3://bucket/key or local path",  // optional (default: overwrite networkUri)
        "zoneOutputUri":         "s3://bucket/key or local path",  // required
        "feedlinksOutputUri":    "s3://bucket/key or local path",  // optional (default: overwrite feedlinksUri)
        "zoneClasses":           ["AREA", "STUDY"],                // optional
        "adjustBoundaryDemands": true                              // optional (default: true)
    }
}

Response (200)
--------------
{
    "statusCode":    200,
    "status":        "successful",
    "networkUri":    "...",
    "zoneUri":       "...",
    "feedlinksUri":  "...",
    "zonesProcessed": int,
    "networkLinks":  int,
    "feedlinks":     int
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def _dedup_by_key(features: list[dict], key_fn) -> list[dict]:
    seen: set = set()
    result: list[dict] = []
    for feat in features:
        k = key_fn(feat)
        if k not in seen:
            seen.add(k)
            result.append(feat)
    return result


def handler(event: dict, context: object) -> dict:  # noqa: ARG001
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        from network_zone_joiner.core.network_zone_joiner_core import (  # noqa: PLC0415
            join_zones_to_network,
        )
        from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

        inputs: dict = event.get("inputs", {})

        zones_uri: str = inputs.get("zonesUri", "")
        network_uri: str = inputs.get("networkUri", "")
        zone_output_uri: str = inputs.get("zoneOutputUri", "")
        if not zones_uri:
            raise ValueError("inputs.zonesUri is required.")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not zone_output_uri:
            raise ValueError("inputs.zoneOutputUri is required.")

        feedlinks_uri: str = inputs.get("feedlinksUri", "")
        net_out_uri: str = inputs.get("networkOutputUri", "") or network_uri
        feedlinks_out_uri: str = inputs.get("feedlinksOutputUri", "") or feedlinks_uri
        zone_classes_raw = inputs.get("zoneClasses")
        zone_classes = set(zone_classes_raw) if zone_classes_raw else None
        adjust_boundary_demands: bool = bool(inputs.get("adjustBoundaryDemands", True))

        logger.info("Reading zones    : %s", zones_uri)
        zones_fc = from_geoparquet(_read_uri(zones_uri))

        logger.info("Reading network  : %s", network_uri)
        network_fc = from_geoparquet(_read_uri(network_uri))

        feedlinks_fc: dict | None = None
        if feedlinks_uri:
            logger.info("Reading feedlinks: %s", feedlinks_uri)
            feedlinks_fc = from_geoparquet(_read_uri(feedlinks_uri))

        results = join_zones_to_network(
            zones_fc,
            network_fc,
            zone_classes=zone_classes,
            feedlinks_fc=feedlinks_fc,
            adjust_boundary_demands=adjust_boundary_demands,
        )

        # Merge all zone results into single FeatureCollections.
        all_net: list[dict] = []
        all_zone: list[dict] = []
        all_feedlinks: list[dict] = []
        for _zone_feat, clipped_net_fc, zone_fc, ext_feedlinks_fc in results:
            all_net.extend(clipped_net_fc.get("features") or [])
            all_zone.extend(zone_fc.get("features") or [])
            all_feedlinks.extend(ext_feedlinks_fc.get("features") or [])

        # Deduplicate
        def _zone_key(f: dict) -> str:
            return str((f.get("properties") or {}).get("zoneId") or "")

        def _net_key(f: dict) -> tuple:
            p = f.get("properties") or {}
            return (
                str(p.get("linkId") or p.get("spectrumId") or ""),
                str(p.get("fromNode") or ""),
                str(p.get("toNode") or ""),
            )

        all_zone = _dedup_by_key(all_zone, _zone_key)
        all_net = _dedup_by_key(all_net, _net_key)

        merged_net_fc = {**network_fc, "features": all_net}
        merged_zone_fc = {
            "type": "FeatureCollection",
            "features": all_zone,
            "properties": {
                **(zones_fc.get("properties") or {}),
                "modes": (network_fc.get("properties") or {}).get("modes") or [],
            },
        }
        feedlinks_base = (feedlinks_fc.get("properties") or {}) if feedlinks_fc else {}
        merged_feedlinks_fc = {
            "type": "FeatureCollection",
            "features": all_feedlinks,
            "properties": {**feedlinks_base},
        }

        logger.info("Writing network  : %s", net_out_uri)
        _write_uri(net_out_uri, to_geoparquet(merged_net_fc))
        logger.info("Writing zones    : %s", zone_output_uri)
        _write_uri(zone_output_uri, to_geoparquet(merged_zone_fc))
        if feedlinks_out_uri:
            logger.info("Writing feedlinks: %s", feedlinks_out_uri)
            _write_uri(feedlinks_out_uri, to_geoparquet(merged_feedlinks_fc))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "networkUri": net_out_uri,
            "zoneUri": zone_output_uri,
            "feedlinksUri": feedlinks_out_uri or None,
            "zonesProcessed": len(results),
            "networkLinks": len(all_net),
            "feedlinks": len(all_feedlinks),
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
