# src/parking_area_fetcher/core/__init__.py
