"""Unit tests for parking_area_fetcher core."""
