"""
WGS84 (EPSG:4326) → RD New (EPSG:28992) coordinate projection.

Implements the Schreutelkamp & Strang van Hees (2001) polynomial approximation
for the Netherlands, accurate to ~0.01 m for ETRS89 / WGS84 input within the
Dutch boundary (roughly lon 3.2–7.3, lat 50.7–53.6).

Reference:
    G. Schreutelkamp & G. Strang van Hees (2001),
    "Benaderingsformules voor de transformatie tussen RD- en WGS84-
    coordinaten", Geodesia 43(5), pp. 184–190.

Usage::

    from rd_projection import wgs84_to_rd
    x, y = wgs84_to_rd(lon=5.387, lat=52.155)   # returns (x_rd, y_rd) in metres
"""

# ---------------------------------------------------------------------------
# Reference / origin point (Amersfoort tower, Bessel ellipsoid)
# ---------------------------------------------------------------------------
_LAT0 = 52.15517440  # degrees
_LON0 = 5.38720621  # degrees
_X0 = 155000.0  # metres (false easting of Amersfoort in RD New)
_Y0 = 463000.0  # metres (false northing of Amersfoort in RD New)

# ---------------------------------------------------------------------------
# Polynomial coefficients for X (easting) and Y (northing).
#
# Each entry is (p, q, coeff) meaning the term contributes:
#   coeff * dLat^p * dLon^q
# where
#   dLat = 0.36 * (lat - _LAT0)
#   dLon = 0.36 * (lon - _LON0)
#
# Source: Table 1 (X) and Table 2 (Y) of Schreutelkamp & Strang van Hees 2001.
# ---------------------------------------------------------------------------

_X_COEFFS: tuple[tuple[int, int, float], ...] = (
    (0, 1, 190094.945),
    (1, 1, -11832.228),
    (2, 1, -114.221),
    (0, 3, -32.391),
    (1, 0, -0.705),
    (3, 1, -2.340),
    (1, 3, -0.608),
    (0, 2, -0.008),
    (2, 3, 0.148),
)

_Y_COEFFS: tuple[tuple[int, int, float], ...] = (
    (1, 0, 309056.544),
    (0, 2, 3638.893),
    (2, 0, 73.077),
    (1, 2, -157.984),
    (3, 0, 59.788),
    (0, 1, 0.433),
    (2, 2, -6.439),
    (1, 1, -0.032),
    (0, 4, 0.092),
    (1, 4, -0.054),
)


def wgs84_to_rd(lon: float, lat: float) -> tuple[float, float]:
    """Convert WGS84 geographic coordinates to RD New (EPSG:28992) metres.

    Parameters
    ----------
    lon:
        Longitude in decimal degrees (EPSG:4326).
    lat:
        Latitude in decimal degrees (EPSG:4326).

    Returns
    -------
    tuple[float, float]
        ``(x, y)`` in RD New metres (EPSG:28992).

    Notes
    -----
    Valid within the Netherlands (approx. lon 3.2–7.3°, lat 50.7–53.6°).
    Outside this range the polynomial diverges and results are unreliable.
    Accuracy within the Netherlands: ~0.01 m for ETRS89 input.
    """
    d_lat = 0.36 * (lat - _LAT0)
    d_lon = 0.36 * (lon - _LON0)

    x = _X0 + sum(coeff * d_lat**p * d_lon**q for p, q, coeff in _X_COEFFS)
    y = _Y0 + sum(coeff * d_lat**p * d_lon**q for p, q, coeff in _Y_COEFFS)

    return x, y
