"""Round-trip tests for shared.geoparquet — to_geoparquet / from_geoparquet."""

from __future__ import annotations

import pytest

from shared.geoparquet import _coerce_mixed_columns, from_geoparquet, to_geoparquet


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _fc(features: list[dict], props: dict | None = None) -> dict:
    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": props or {},
    }


def _point_feat(lon: float, lat: float, **props) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": dict(props),
    }


def _line_feat(coords: list, **props) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": dict(props),
    }


# ---------------------------------------------------------------------------
# Empty FeatureCollection
# ---------------------------------------------------------------------------


class TestEmptyFeatureCollection:
    def test_roundtrip_empty(self):
        fc = _fc([])
        result = from_geoparquet(to_geoparquet(fc))
        assert result["type"] == "FeatureCollection"
        assert result["features"] == []

    def test_empty_fc_properties_preserved(self):
        fc = _fc([], props={"areaId": "test-123", "modes": ["CAR"]})
        result = from_geoparquet(to_geoparquet(fc))
        assert result["properties"]["areaId"] == "test-123"
        assert result["properties"]["modes"] == ["CAR"]

    def test_bytes_are_valid_parquet(self):
        import pyarrow.parquet as pq
        import io

        data = to_geoparquet(_fc([]))
        pf = pq.ParquetFile(io.BytesIO(data))
        assert pf.metadata.num_rows == 0


# ---------------------------------------------------------------------------
# Scalar-only features (network links, zone features)
# ---------------------------------------------------------------------------


class TestScalarProperties:
    def test_roundtrip_scalar_link(self):
        fc = _fc(
            [_line_feat(
                [[4.0, 52.0], [4.1, 52.1]],
                linkId="link-1",
                flow=123.45,
                speed=50.0,
                lanes=2,
                fromNode="n1",
                toNode="n2",
            )],
            props={"areaId": "a1", "modeLabel": "CAR"},
        )
        result = from_geoparquet(to_geoparquet(fc))
        assert len(result["features"]) == 1
        props = result["features"][0]["properties"]
        assert props["linkId"] == "link-1"
        assert abs(props["flow"] - 123.45) < 1e-9
        assert props["speed"] == 50.0
        assert props["lanes"] == 2
        assert props["fromNode"] == "n1"
        assert props["toNode"] == "n2"

    def test_roundtrip_zone_feature(self):
        fc = _fc(
            [_point_feat(4.5, 52.5, zoneId="z1", zoneClass="STUDY", production=400.0)],
        )
        result = from_geoparquet(to_geoparquet(fc))
        props = result["features"][0]["properties"]
        assert props["zoneId"] == "z1"
        assert props["zoneClass"] == "STUDY"
        assert abs(props["production"] - 400.0) < 1e-9

    def test_geometry_roundtrip(self):
        coords = [[4.0, 52.0], [4.05, 52.05], [4.1, 52.1]]
        fc = _fc([_line_feat(coords, linkId="geo-test")])
        result = from_geoparquet(to_geoparquet(fc))
        geom = result["features"][0]["geometry"]
        assert geom["type"] == "LineString"
        for i, (lon, lat) in enumerate(coords):
            assert abs(geom["coordinates"][i][0] - lon) < 1e-9
            assert abs(geom["coordinates"][i][1] - lat) < 1e-9

    def test_multiple_features(self):
        features = [
            _line_feat([[4.0, 52.0], [4.1, 52.1]], linkId=f"link-{i}", flow=float(i * 10))
            for i in range(10)
        ]
        fc = _fc(features)
        result = from_geoparquet(to_geoparquet(fc))
        assert len(result["features"]) == 10
        for i, feat in enumerate(result["features"]):
            assert feat["properties"]["linkId"] == f"link-{i}"

    def test_fc_properties_preserved(self):
        fc = _fc(
            [_point_feat(4.0, 52.0, zoneId="z1")],
            props={"areaId": "uuid-123", "modes": ["CAR", "BIKE"], "bbox": [4.0, 52.0, 5.0, 53.0]},
        )
        result = from_geoparquet(to_geoparquet(fc))
        p = result["properties"]
        assert p["areaId"] == "uuid-123"
        assert p["modes"] == ["CAR", "BIKE"]
        assert p["bbox"] == [4.0, 52.0, 5.0, 53.0]


# ---------------------------------------------------------------------------
# Complex (list/dict) columns — routes, parallelLinkIds, nodePath
# ---------------------------------------------------------------------------


class TestComplexColumns:
    def test_roundtrip_routes_column(self):
        routes = [
            {"linkPath": ["l1", "l2", "l3"], "nodePath": ["n1", "n2", "n4"], "trips": 0.35},
            {"linkPath": ["l4", "l5"],        "nodePath": ["n1", "n3", "n4"], "trips": 0.65},
        ]
        fc = _fc([{
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [4.0, 52.0]},
            "properties": {
                "fromZoneId": "z1",
                "toZoneId": "z2",
                "tripFraction": 0.015,
                "routes": routes,
            },
        }])
        result = from_geoparquet(to_geoparquet(fc))
        props = result["features"][0]["properties"]
        assert props["routes"] == routes

    def test_roundtrip_parallel_link_ids(self):
        fc = _fc([_line_feat(
            [[4.0, 52.0], [4.1, 52.0]],
            linkId="l1",
            parallelLinkIds=["l2", "l3"],
        )])
        result = from_geoparquet(to_geoparquet(fc))
        assert result["features"][0]["properties"]["parallelLinkIds"] == ["l2", "l3"]

    def test_roundtrip_nested_dict_column(self):
        flows_per_daypart = {"morning": 120.0, "afternoon": 80.0, "evening": 60.0}
        fc = _fc([_line_feat(
            [[4.0, 52.0], [4.1, 52.0]],
            linkId="l1",
            flowsPerDaypart=flows_per_daypart,
        )])
        result = from_geoparquet(to_geoparquet(fc))
        assert result["features"][0]["properties"]["flowsPerDaypart"] == flows_per_daypart

    def test_mixed_complex_and_scalar(self):
        fc = _fc([_line_feat(
            [[4.0, 52.0], [4.1, 52.0]],
            linkId="l1",
            flow=100.0,
            routes=[{"linkPath": ["l1"], "trips": 1.0}],
            parallelLinkIds=["l2"],
        )])
        result = from_geoparquet(to_geoparquet(fc))
        props = result["features"][0]["properties"]
        assert props["linkId"] == "l1"
        assert abs(props["flow"] - 100.0) < 1e-9
        assert props["routes"] == [{"linkPath": ["l1"], "trips": 1.0}]
        assert props["parallelLinkIds"] == ["l2"]

    def test_empty_list_column(self):
        fc = _fc([_line_feat(
            [[4.0, 52.0], [4.1, 52.0]],
            linkId="l1",
            parallelLinkIds=[],
        )])
        result = from_geoparquet(to_geoparquet(fc))
        assert result["features"][0]["properties"]["parallelLinkIds"] == []


# ---------------------------------------------------------------------------
# Footer metadata
# ---------------------------------------------------------------------------


class TestFooterMetadata:
    def test_empty_fc_props_default(self):
        fc = {"type": "FeatureCollection", "features": []}
        result = from_geoparquet(to_geoparquet(fc))
        assert result["properties"] == {}

    def test_complex_fc_props(self):
        fc = _fc(
            [],
            props={
                "areaId": "x",
                "bbox": [3.0, 51.0, 7.0, 54.0],
                "modes": ["CAR"],
                "modeLabel": "CAR",
                "name": "Test Area",
            },
        )
        result = from_geoparquet(to_geoparquet(fc))
        p = result["properties"]
        assert p["areaId"] == "x"
        assert p["bbox"] == [3.0, 51.0, 7.0, 54.0]
        assert p["modes"] == ["CAR"]
        assert p["name"] == "Test Area"

    def test_fc_type_preserved(self):
        fc = _fc([_point_feat(4.0, 52.0, zoneId="z1")])
        result = from_geoparquet(to_geoparquet(fc))
        assert result["type"] == "FeatureCollection"

    def test_returns_plain_dict(self):
        fc = _fc([_point_feat(4.0, 52.0, zoneId="z1")])
        result = from_geoparquet(to_geoparquet(fc))
        assert type(result) is dict  # not a subclass


# ---------------------------------------------------------------------------
# Import guard
# ---------------------------------------------------------------------------


class TestImportGuard:
    def test_raises_import_error_when_missing(self, monkeypatch):
        import shared.geoparquet as gq
        monkeypatch.setattr(gq, "_HAS_GEOPARQUET", False)
        with pytest.raises(ImportError, match="geopandas"):
            gq.to_geoparquet({"type": "FeatureCollection", "features": []})
        with pytest.raises(ImportError, match="geopandas"):
            gq.from_geoparquet(b"")


# ---------------------------------------------------------------------------
# Mixed-type scalar columns (_coerce_mixed_columns)
# ---------------------------------------------------------------------------


class TestMixedTypeCoercion:
    """Tests for _coerce_mixed_columns, exercised both directly and via round-trip."""

    # --- Direct unit tests for the helper ---

    def test_homogeneous_int_column_unchanged(self):
        rows = [{"fromNode": 1}, {"fromNode": 2}, {"fromNode": 3}]
        _coerce_mixed_columns(rows, skip=set())
        assert rows == [{"fromNode": 1}, {"fromNode": 2}, {"fromNode": 3}]

    def test_homogeneous_str_column_unchanged(self):
        rows = [{"linkId": "a"}, {"linkId": "b"}]
        _coerce_mixed_columns(rows, skip=set())
        assert rows == [{"linkId": "a"}, {"linkId": "b"}]

    def test_mixed_int_str_coerced_to_int(self):
        """The real-world case: fromNode stored as int in most rows, str in a few."""
        rows = [
            {"fromNode": 417346001},
            {"fromNode": "-600950219"},
            {"fromNode": 123456789},
        ]
        _coerce_mixed_columns(rows, skip=set())
        assert rows[0]["fromNode"] == 417346001
        assert rows[1]["fromNode"] == -600950219
        assert rows[2]["fromNode"] == 123456789
        assert all(type(r["fromNode"]) is int for r in rows)

    def test_mixed_int_float_coerced_to_int(self):
        """int and float mix: int coercion succeeds when float values are whole numbers."""
        rows = [{"speed": 50}, {"speed": 60.0}]
        _coerce_mixed_columns(rows, skip=set())
        # int(60.0) == 60 — coercion to int succeeds
        assert all(type(r["speed"]) is int for r in rows)

    def test_mixed_types_fall_back_to_str(self):
        """When neither int nor float coercion works, falls back to str."""
        rows = [{"col": 42}, {"col": "not-a-number"}]
        _coerce_mixed_columns(rows, skip=set())
        assert rows[0]["col"] == "42"
        assert rows[1]["col"] == "not-a-number"
        assert all(type(r["col"]) is str for r in rows)

    def test_none_values_preserved(self):
        """None values in a mixed column are left as None after coercion."""
        rows = [{"fromNode": 100}, {"fromNode": None}, {"fromNode": "200"}]
        _coerce_mixed_columns(rows, skip=set())
        assert rows[0]["fromNode"] == 100
        assert rows[1]["fromNode"] is None
        assert rows[2]["fromNode"] == 200

    def test_all_none_column_not_modified(self):
        """A column where every value is None should not raise."""
        rows = [{"fromNode": None}, {"fromNode": None}]
        _coerce_mixed_columns(rows, skip=set())
        assert rows[0]["fromNode"] is None
        assert rows[1]["fromNode"] is None

    def test_skipped_columns_not_coerced(self):
        """Columns in the skip set are not touched, even if they have mixed types."""
        rows = [{"routes": [1, 2]}, {"routes": "already-serialised"}]
        _coerce_mixed_columns(rows, skip={"routes"})
        assert rows[0]["routes"] == [1, 2]
        assert rows[1]["routes"] == "already-serialised"

    def test_empty_rows_is_noop(self):
        """Empty row list must not raise."""
        rows: list[dict] = []
        _coerce_mixed_columns(rows, skip=set())  # should not raise
        assert rows == []

    def test_multiple_mixed_columns_all_coerced(self):
        """Multiple mixed columns in the same dataset are all coerced."""
        rows = [
            {"fromNode": 1, "toNode": "2"},
            {"fromNode": "3", "toNode": 4},
        ]
        _coerce_mixed_columns(rows, skip=set())
        for row in rows:
            assert type(row["fromNode"]) is int
            assert type(row["toNode"]) is int

    # --- Round-trip integration tests ---

    def test_roundtrip_mixed_int_str_node_ids(self):
        """The exact production crash: fromNode with int and str values round-trips cleanly."""
        fc = _fc([
            _line_feat([[4.0, 52.0], [4.1, 52.1]], fromNode=417346001,    toNode=417346002),
            _line_feat([[4.1, 52.1], [4.2, 52.2]], fromNode="-600950219", toNode="-600950220"),
            _line_feat([[4.2, 52.2], [4.3, 52.3]], fromNode=123456789,    toNode=987654321),
        ])
        result = from_geoparquet(to_geoparquet(fc))
        assert len(result["features"]) == 3
        from_nodes = [f["properties"]["fromNode"] for f in result["features"]]
        assert from_nodes[0] == 417346001
        assert from_nodes[1] == -600950219
        assert from_nodes[2] == 123456789

    def test_roundtrip_mixed_does_not_raise(self):
        """to_geoparquet must not raise ArrowInvalid for mixed int/str columns."""
        fc = _fc([
            _line_feat([[4.0, 52.0], [4.1, 52.1]], nodeId=100),
            _line_feat([[4.1, 52.1], [4.2, 52.2]], nodeId="-999"),
        ])
        # Should not raise
        data = to_geoparquet(fc)
        assert isinstance(data, bytes)
        assert len(data) > 0
