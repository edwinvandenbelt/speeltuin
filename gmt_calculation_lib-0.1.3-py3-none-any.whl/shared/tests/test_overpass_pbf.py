"""Tests for the local-PBF dispatch in shared.overpass.

Covers :func:`_resolve_pbf_path` resolution rules and that the fetch helpers
route to the local backend when a ``.osm.pbf`` source is configured.
"""

from __future__ import annotations

from pathlib import Path

import pytest

import shared.overpass as ovp
from shared.overpass import _resolve_pbf_path, fetch_overpass, fetch_overpass_tiled


@pytest.fixture(autouse=True)
def _no_cache(monkeypatch: pytest.MonkeyPatch) -> None:
    # Disable the on-disk cache so routing is exercised directly.
    monkeypatch.setenv("OVERPASS_CACHE_DIR", "")
    monkeypatch.delenv("OSM_PBF_PATH", raising=False)


@pytest.fixture
def pbf_file(tmp_path: Path) -> Path:
    p = tmp_path / "extract.osm.pbf"
    p.write_bytes(b"\x00")  # content irrelevant; backend is monkeypatched
    return p


# ---------------------------------------------------------------------------
# _resolve_pbf_path
# ---------------------------------------------------------------------------


def test_resolve_none_when_unset() -> None:
    assert _resolve_pbf_path(None) is None
    assert _resolve_pbf_path("") is None
    assert _resolve_pbf_path("   ") is None


def test_resolve_explicit_arg(pbf_file: Path) -> None:
    assert _resolve_pbf_path(str(pbf_file)) == pbf_file


def test_resolve_env_fallback(pbf_file: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OSM_PBF_PATH", str(pbf_file))
    assert _resolve_pbf_path(None) == pbf_file


def test_explicit_arg_beats_env(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    a = tmp_path / "a.osm.pbf"
    a.write_bytes(b"\x00")
    b = tmp_path / "b.osm.pbf"
    b.write_bytes(b"\x00")
    monkeypatch.setenv("OSM_PBF_PATH", str(b))
    assert _resolve_pbf_path(str(a)) == a


def test_resolve_missing_file_raises(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="readable file"):
        _resolve_pbf_path(str(tmp_path / "nope.osm.pbf"))


def test_resolve_wrong_extension_raises(tmp_path: Path) -> None:
    txt = tmp_path / "data.txt"
    txt.write_text("x")
    with pytest.raises(ValueError, match=".pbf"):
        _resolve_pbf_path(str(txt))


# ---------------------------------------------------------------------------
# Routing
# ---------------------------------------------------------------------------


def test_fetch_overpass_routes_to_pbf(pbf_file: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[tuple[str, Path]] = []

    def fake_backend(query: str, path: Path, *, workers: int | None = None) -> dict:  # noqa: ARG001
        calls.append((query, Path(path)))
        return {"elements": [{"type": "node", "id": 1}]}

    monkeypatch.setattr("shared._osm_pbf.fetch_from_pbf", fake_backend)
    result = fetch_overpass("node[x](1,2,3,4);out body;", osm_path=str(pbf_file))
    assert result == {"elements": [{"type": "node", "id": 1}]}
    assert calls == [("node[x](1,2,3,4);out body;", pbf_file)]


def test_fetch_tiled_routes_to_pbf_single_pass(
    pbf_file: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    calls: list[str] = []

    def fake_backend(query: str, _path: Path, *, workers: int | None = None) -> dict:  # noqa: ARG001
        calls.append(query)
        return {"elements": []}

    monkeypatch.setattr("shared._osm_pbf.fetch_from_pbf", fake_backend)

    def query_fn(bbox: list[float]) -> str:
        return f"way[highway]({bbox[1]},{bbox[0]},{bbox[3]},{bbox[2]});out geom;"

    # Even with a 4x4 tile request, the PBF backend runs exactly one pass.
    fetch_overpass_tiled(query_fn, [6.0, 52.0, 6.2, 52.1], tiles=(4, 4), osm_path=str(pbf_file))
    assert len(calls) == 1


def test_no_pbf_configured_resolves_none(monkeypatch: pytest.MonkeyPatch) -> None:
    # No osm_path and no OSM_PBF_PATH -> the fetch helpers stay on the HTTP path.
    def boom(*_a: object, **_k: object) -> dict:
        raise AssertionError("PBF backend must not be called")

    monkeypatch.setattr("shared._osm_pbf.fetch_from_pbf", boom)
    assert _resolve_pbf_path(None) is None
    _ = ovp  # keep import referenced
