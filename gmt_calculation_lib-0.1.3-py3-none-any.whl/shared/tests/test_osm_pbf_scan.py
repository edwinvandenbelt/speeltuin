"""Tests for shared._osm_pbf_scan — serial vs process-parallel pass-1.

Reuses the tiny on-the-fly PBF fixture from :mod:`test_osm_pbf`.  The fixture is
far below the parallel size threshold, so the parallel path is forced here by
passing ``min_parallel_bytes=0`` and asserting it yields byte-for-byte the same
:class:`ScanResult` as the serial path.
"""

from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("esy.osm.pbf")

from shared import _osm_pbf_scan as scan  # noqa: E402
from shared._osm_ql import parse_overpass_ql  # noqa: E402
from shared.tests.test_osm_pbf import _ALL, _build_fixture  # noqa: E402


@pytest.fixture
def pbf(tmp_path: Path) -> Path:
    p = tmp_path / "fixture.osm.pbf"
    _build_fixture(p)
    return p


def _selectors(query: str) -> tuple[list, list, list]:
    sels = parse_overpass_ql(query)
    return (
        [s for s in sels if s.kind == "node"],
        [s for s in sels if s.kind == "way"],
        [s for s in sels if s.kind == "relation"],
    )


# ---------------------------------------------------------------------------
# resolve_workers
# ---------------------------------------------------------------------------


def test_resolve_workers_defaults_capped() -> None:
    # No env override -> min(cpu, cap).
    assert scan.resolve_workers(None, 4) == 4
    assert scan.resolve_workers(None, 32) == scan.DEFAULT_WORKER_CAP
    assert scan.resolve_workers("", 4) == 4


def test_resolve_workers_env_override() -> None:
    assert scan.resolve_workers("2", 8) == 2
    # Env cannot exceed available cpus.
    assert scan.resolve_workers("100", 4) == 4
    # Non-positive / garbage falls back to the default.
    assert scan.resolve_workers("0", 6) == 6
    assert scan.resolve_workers("abc", 6) == 6


def test_resolve_workers_handles_missing_cpu() -> None:
    assert scan.resolve_workers(None, None) == 1
    assert scan.resolve_workers("4", None) == 1


# ---------------------------------------------------------------------------
# _chunk
# ---------------------------------------------------------------------------


def test_chunk_splits_in_file_order() -> None:
    items = list(range(10))
    chunks = scan._chunk(items, 3)
    assert [c for chunk in chunks for c in chunk] == items  # order preserved
    assert len(chunks) <= 3
    assert scan._chunk(items, 1) == [items]
    assert scan._chunk([42], 4) == [[42]]


# ---------------------------------------------------------------------------
# scan(): serial == parallel
# ---------------------------------------------------------------------------

_QUERIES = [
    f'[out:json];\nnode["traffic_sign"]({_ALL});\nout body;',
    f'[out:json];\n(\n  way["amenity"="parking"]({_ALL});\n);\nout geom;',
    f'[out:json];\n(\n  relation["natural"="wood"]({_ALL});\n);\nout geom;',
]


@pytest.mark.parametrize("query", _QUERIES)
def test_serial_matches_parallel(pbf: Path, query: str) -> None:
    node_sels, way_sels, rel_sels = _selectors(query)
    serial = scan.scan(pbf, node_sels, way_sels, rel_sels, workers=1)
    # Force the process-parallel path despite the tiny fixture.
    parallel = scan.scan(pbf, node_sels, way_sels, rel_sels, workers=2, min_parallel_bytes=0)
    assert serial == parallel


def test_small_file_falls_back_to_serial(pbf: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    # With the default threshold the tiny fixture must never spawn a pool.
    def _boom(*_a, **_k):  # pragma: no cover - only fires on regression
        raise AssertionError("ProcessPoolExecutor used below size threshold")

    monkeypatch.setattr(scan, "ProcessPoolExecutor", _boom)
    node_sels, way_sels, rel_sels = _selectors(_QUERIES[0])
    result = scan.scan(pbf, node_sels, way_sels, rel_sels, workers=8)
    assert len(result.node_elements) == 1
    assert result.node_elements[0]["id"] == 5  # noqa: PLR2004
