"""Tests for shared._osm_pbf — the local ``.osm.pbf`` Overpass backend.

A tiny PBF fixture is generated on the fly (using the protobuf schema bundled
with ``esy-osm-pbf``) so the tests need no committed binary and no network.
"""

from __future__ import annotations

import struct
from pathlib import Path

import pytest

pytest.importorskip("esy.osm.pbf")

from esy.osm.pbf import fileformat_pb2 as ff  # noqa: E402
from esy.osm.pbf import osmformat_pb2 as osm  # noqa: E402

from shared._osm_pbf import fetch_from_pbf  # noqa: E402

# ---------------------------------------------------------------------------
# Fixture PBF builder
# ---------------------------------------------------------------------------

_STRINGS = [
    b"",
    b"amenity",
    b"parking",
    b"highway",
    b"residential",
    b"traffic_sign",
    b"stop",
    b"natural",
    b"wood",
    b"outer",
]
_COORD_SCALE = 1e7

# node id -> (lon, lat)
_NODES = {
    1: (6.00, 52.00),
    2: (6.01, 52.00),
    3: (6.01, 52.01),
    4: (6.00, 52.01),
    5: (6.05, 52.05),  # standalone traffic_sign=stop
    6: (6.10, 52.10),
    7: (6.11, 52.11),
}


def _si(s: str) -> int:
    return _STRINGS.index(s.encode())


def _blob(type_str: str, payload: bytes) -> bytes:
    blob = ff.Blob()
    blob.raw = payload
    blob.raw_size = len(payload)
    blob_bytes = blob.SerializeToString()
    header = ff.BlobHeader()
    header.type = type_str
    header.datasize = len(blob_bytes)
    header_bytes = header.SerializeToString()
    return struct.pack(">I", len(header_bytes)) + header_bytes + blob_bytes


def _build_fixture(path: Path) -> None:
    header = osm.HeaderBlock()
    header.required_features.append("OsmSchema-V0.6")
    header.required_features.append("DenseNodes")

    block = osm.PrimitiveBlock()
    block.stringtable.s.extend(_STRINGS)
    block.granularity = 100
    # esy-osm-pbf's Index classifies each primitivegroup by its first non-empty
    # entity kind, so nodes, ways and relations must live in separate groups
    # (as real Geofabrik extracts do).
    node_group = block.primitivegroup.add()
    way_group = block.primitivegroup.add()
    rel_group = block.primitivegroup.add()

    dense = node_group.dense
    prev_id = prev_lat = prev_lon = 0
    for nid in sorted(_NODES):
        lon, lat = _NODES[nid]
        ilat = round(lat * _COORD_SCALE)
        ilon = round(lon * _COORD_SCALE)
        dense.id.append(nid - prev_id)
        dense.lat.append(ilat - prev_lat)
        dense.lon.append(ilon - prev_lon)
        prev_id, prev_lat, prev_lon = nid, ilat, ilon
    for nid in sorted(_NODES):
        if nid == 5:  # noqa: PLR2004
            dense.keys_vals.append(_si("traffic_sign"))
            dense.keys_vals.append(_si("stop"))
        dense.keys_vals.append(0)

    # way 10: amenity=parking closed ring 1-2-3-4-1
    w1 = way_group.ways.add()
    w1.id = 10
    w1.keys.append(_si("amenity"))
    w1.vals.append(_si("parking"))
    prev = 0
    for ref in (1, 2, 3, 4, 1):
        w1.refs.append(ref - prev)
        prev = ref

    # way 11: highway=residential 6-7
    w2 = way_group.ways.add()
    w2.id = 11
    w2.keys.append(_si("highway"))
    w2.vals.append(_si("residential"))
    prev = 0
    for ref in (6, 7):
        w2.refs.append(ref - prev)
        prev = ref

    # relation 100: natural=wood, member way 11 role outer
    rel = rel_group.relations.add()
    rel.id = 100
    rel.keys.append(_si("natural"))
    rel.vals.append(_si("wood"))
    rel.memids.append(11)
    rel.types.append(osm.Relation.WAY)
    rel.roles_sid.append(_si("outer"))

    data = _blob("OSMHeader", header.SerializeToString())
    data += _blob("OSMData", block.SerializeToString())
    path.write_bytes(data)


@pytest.fixture
def pbf(tmp_path: Path) -> Path:
    p = tmp_path / "fixture.osm.pbf"
    _build_fixture(p)
    return p


# Bounding box covering everything: south,west,north,east
_ALL = "51.9,5.9,52.2,6.2"


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_missing_file_raises() -> None:
    with pytest.raises(FileNotFoundError):
        fetch_from_pbf(f'node["x"]({_ALL});out body;', "does_not_exist.osm.pbf")


def test_node_query(pbf: Path) -> None:
    q = f'[out:json];\nnode["traffic_sign"]({_ALL});\nout body;'
    result = fetch_from_pbf(q, pbf)
    nodes = [e for e in result["elements"] if e["type"] == "node"]
    assert len(nodes) == 1
    n = nodes[0]
    assert n["id"] == 5
    assert n["tags"] == {"traffic_sign": "stop"}
    assert n["lat"] == pytest.approx(52.05)
    assert n["lon"] == pytest.approx(6.05)


def test_node_bbox_excludes_outside(pbf: Path) -> None:
    # bbox around node 5 only
    q = '[out:json];\nnode["traffic_sign"](52.04,6.04,52.06,6.06);\nout body;'
    result = fetch_from_pbf(q, pbf)
    assert [e["id"] for e in result["elements"]] == [5]
    # bbox that excludes node 5
    q2 = '[out:json];\nnode["traffic_sign"](52.00,6.00,52.02,6.02);\nout body;'
    assert fetch_from_pbf(q2, pbf)["elements"] == []


def test_way_query_has_nodes_and_geometry(pbf: Path) -> None:
    q = f'[out:json];\n(\n  way["amenity"="parking"]({_ALL});\n);\nout geom;'
    result = fetch_from_pbf(q, pbf)
    ways = [e for e in result["elements"] if e["type"] == "way"]
    assert len(ways) == 1
    w = ways[0]
    assert w["id"] == 10
    assert w["tags"] == {"amenity": "parking"}
    # nodes id-list preserved (needed by the network splitter)
    assert w["nodes"] == [1, 2, 3, 4, 1]
    # geometry resolved to coordinates
    assert len(w["geometry"]) == 5
    assert w["geometry"][0] == {"lat": pytest.approx(52.0), "lon": pytest.approx(6.0)}


def test_way_regex_selector(pbf: Path) -> None:
    q = f'[out:json];\n(\n  way["highway"~"^(residential|primary)$"]({_ALL});\n);\nout geom;'
    result = fetch_from_pbf(q, pbf)
    ways = [e for e in result["elements"] if e["type"] == "way"]
    assert [w["id"] for w in ways] == [11]
    assert ways[0]["nodes"] == [6, 7]


def test_relation_member_geometry(pbf: Path) -> None:
    q = f'[out:json];\n(\n  relation["natural"="wood"]({_ALL});\n);\nout geom;'
    result = fetch_from_pbf(q, pbf)
    rels = [e for e in result["elements"] if e["type"] == "relation"]
    assert len(rels) == 1
    r = rels[0]
    assert r["id"] == 100
    assert r["tags"] == {"natural": "wood"}
    assert len(r["members"]) == 1
    m = r["members"][0]
    assert m["type"] == "way"
    assert m["ref"] == 11
    assert m["role"] == "outer"
    # member way 11's geometry resolved from its node refs
    assert [(pt["lon"], pt["lat"]) for pt in m["geometry"]] == [
        pytest.approx((6.10, 52.10)),
        pytest.approx((6.11, 52.11)),
    ]


def test_recurse_down_query_parses_and_returns_ways(pbf: Path) -> None:
    # osm_network_fetcher-style query with (._;>;) recurse — must be ignored.
    q = (
        "[out:json][timeout:60];\n"
        "(\n"
        f'  way["highway"~"^(residential)$"]({_ALL});\n'
        ");\n"
        "(._;>;);\n"
        "out geom;\n"
    )
    result = fetch_from_pbf(q, pbf)
    ways = [e for e in result["elements"] if e["type"] == "way"]
    assert [w["id"] for w in ways] == [11]
