"""Tests for shared._osm_session — the in-process + on-disk PBF session cache.

Reuses the tiny on-the-fly PBF fixture from :mod:`test_osm_pbf`.
"""

from __future__ import annotations

from pathlib import Path

import pytest

pytest.importorskip("esy.osm.pbf")

from shared import _osm_pbf_scan as scan  # noqa: E402
from shared import _osm_session as sess  # noqa: E402
from shared._osm_ql import parse_overpass_ql  # noqa: E402
from shared.tests.test_osm_pbf import _ALL, _build_fixture  # noqa: E402


@pytest.fixture
def pbf(tmp_path: Path) -> Path:
    p = tmp_path / "fixture.osm.pbf"
    _build_fixture(p)
    return p


def _selectors(query: str) -> tuple[list, list, list]:
    sels = parse_overpass_ql(query)
    return (
        [s for s in sels if s.kind == "node"],
        [s for s in sels if s.kind == "way"],
        [s for s in sels if s.kind == "relation"],
    )


# ---------------------------------------------------------------------------
# sessions_enabled
# ---------------------------------------------------------------------------


def test_sessions_enabled_default(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.delenv("OSM_SESSION", raising=False)
    assert sess.sessions_enabled() is True


@pytest.mark.parametrize("value", ["0", "false", "no", "off", "OFF", "False"])
def test_sessions_disabled_by_env(value: str, monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("OSM_SESSION", value)
    assert sess.sessions_enabled() is False


# ---------------------------------------------------------------------------
# get_session caching (E1 in-process)
# ---------------------------------------------------------------------------


def test_get_session_memoises_in_process(pbf: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    calls = {"n": 0}
    real = scan.scan_session

    def counting(path: Path, **kw: object):
        calls["n"] += 1
        return real(path, **kw)

    monkeypatch.setattr(scan, "scan_session", counting)
    first = sess.get_session(pbf, workers=1)
    second = sess.get_session(pbf, workers=1)
    assert first is second  # same cached object
    assert calls["n"] == 1  # scanned only once


# ---------------------------------------------------------------------------
# on-disk cache (E2)
# ---------------------------------------------------------------------------


def test_disk_cache_survives_memory_clear(pbf: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    built = sess.get_session(pbf, workers=1)  # builds + writes to disk
    assert sess._disk_path(built.key).is_file()

    sess._MEMORY.clear()

    def _boom(*_a: object, **_k: object):  # pragma: no cover - must not run
        raise AssertionError("scan_session called despite a warm disk cache")

    monkeypatch.setattr(scan, "scan_session", _boom)
    reloaded = sess.get_session(pbf, workers=1)
    assert reloaded.key == built.key
    assert reloaded.tagged_ways == built.tagged_ways


def test_disk_cache_invalidated_by_mtime(pbf: Path) -> None:
    first = sess.get_session(pbf, workers=1)
    sess._MEMORY.clear()
    # Rewrite the file so size/mtime change -> new key -> disk miss -> rebuild.
    _build_fixture(pbf)
    pbf.write_bytes(pbf.read_bytes() + b"")  # touch to bump mtime_ns
    second = sess.get_session(pbf, workers=1)
    # Keys differ (mtime/size), so a fresh session object is built.
    assert second.key != first.key or second is not first


# ---------------------------------------------------------------------------
# query_session parity with a direct targeted scan
# ---------------------------------------------------------------------------

_QUERIES = [
    f'[out:json];\nnode["traffic_sign"]({_ALL});\nout body;',
    f'[out:json];\n(\n  way["amenity"="parking"]({_ALL});\n);\nout geom;',
    f'[out:json];\n(\n  relation["natural"="wood"]({_ALL});\n);\nout geom;',
]


@pytest.mark.parametrize("query", _QUERIES)
def test_query_session_matches_scan(pbf: Path, query: str) -> None:
    node_sels, way_sels, rel_sels = _selectors(query)
    direct = scan.scan(pbf, node_sels, way_sels, rel_sels, workers=1)
    session = sess.get_session(pbf, workers=1)
    answered = sess.query_session(session, node_sels, way_sels, rel_sels)

    assert answered.node_elements == direct.node_elements
    assert answered.matched_ways == direct.matched_ways
    assert answered.matched_rels == direct.matched_rels
    assert answered.needed_nodes == direct.needed_nodes
    assert answered.needed_ways == direct.needed_ways
