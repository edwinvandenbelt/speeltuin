"""Shared GeoJSON / flat-earth geometry helpers — no I/O, no external deps.

Pulled from stalled.zone_intersector.domain.geometry and stalled.feedlink_creator.domain.geometry
to avoid duplication.  Both domain modules now re-export from here.

Public API
----------
_D_LAT                     — metres per degree latitude (≈ 111 320)
_d_lon(lat_deg)            — metres per degree longitude at given latitude
_flat_earth_dist_m(...)    — approximate distance in metres between two WGS-84 points
_is_inside_bbox(...)       — point-in-bbox test
_bearing_deg(...)          — compass bearing 0-360° between two WGS-84 points
_compass_8_label(bearing)  — bearing → one of 8 Dutch compass labels
_compass_8_label_en(bearing) — bearing → one of 8 English compass labels
_nudge_point(...)          — shift a point outward from a centre by offset_m metres
_circle_polygon(...)       — approximate circle as a closed GeoJSON coordinate ring
_iter_geojson_coords(geom) — yield every (lon, lat) from any GeoJSON geometry dict
_parse_wkt_geometry(wkt)   — parse WKT LINESTRING / MULTILINESTRING → GeoJSON dict
_straight_line(...)        — two-point GeoJSON LineString dict
"""

from __future__ import annotations

import math
import re

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

_COMPASS_8 = ["N", "NO", "O", "ZO", "Z", "ZW", "W", "NW"]
_COMPASS_8_EN = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"]

# Metres per degree latitude (approximately constant worldwide)
_D_LAT = 111_320.0


# ---------------------------------------------------------------------------
# Basic flat-earth helpers
# ---------------------------------------------------------------------------


def _d_lon(lat_deg: float) -> float:
    """Metres per degree of longitude at the given latitude."""
    return _D_LAT * math.cos(math.radians(lat_deg))


def _flat_earth_dist_m(lon0: float, lat0: float, lon1: float, lat1: float) -> float:
    """Approximate distance in metres between two WGS-84 points."""
    cos_lat = math.cos(math.radians((lat0 + lat1) / 2.0))
    dx = (lon1 - lon0) * cos_lat * _D_LAT
    dy = (lat1 - lat0) * _D_LAT
    return math.hypot(dx, dy)


# ---------------------------------------------------------------------------
# Bounding-box helpers
# ---------------------------------------------------------------------------


def _is_inside_bbox(lon: float, lat: float, bbox: list) -> bool:
    """Return True when (lon, lat) lies within [minLon, minLat, maxLon, maxLat]."""
    return bbox[0] <= lon <= bbox[2] and bbox[1] <= lat <= bbox[3]


# ---------------------------------------------------------------------------
# Bearing / compass helpers
# ---------------------------------------------------------------------------


def _bearing_deg(
    from_lon: float,
    from_lat: float,
    to_lon: float,
    to_lat: float,
) -> float:
    """Compass bearing 0-360° (0 = N, 90 = E) from point A to point B."""
    lat_mid = math.radians((from_lat + to_lat) / 2.0)
    dx = (to_lon - from_lon) * math.cos(lat_mid)
    dy = to_lat - from_lat
    return math.degrees(math.atan2(dx, dy)) % 360.0


def _compass_8_label(bearing: float) -> str:
    """Map a compass bearing (0-360°) to one of the 8 Dutch compass labels."""
    idx = int((bearing + 22.5) / 45.0) % 8
    return _COMPASS_8[idx]


def _compass_8_label_en(bearing: float) -> str:
    """Map a compass bearing (0-360°) to one of the 8 English compass labels."""
    idx = int((bearing + 22.5) / 45.0) % 8
    return _COMPASS_8_EN[idx]


# ---------------------------------------------------------------------------
# Point-shifting / polygon helpers
# ---------------------------------------------------------------------------


def _nudge_point(
    lon: float,
    lat: float,
    cx_lon: float,
    cx_lat: float,
    offset_m: float,
) -> tuple[float, float]:
    """Shift (lon, lat) outward from (cx_lon, cx_lat) by offset_m metres."""
    dlat = _D_LAT
    dlon = _d_lon((lat + cx_lat) / 2.0)
    dx = (lon - cx_lon) * dlon
    dy = (lat - cx_lat) * dlat
    dist = math.hypot(dx, dy)
    if dist < 1e-9:
        return lon, lat
    scale = (dist + offset_m) / dist
    new_lon = cx_lon + (lon - cx_lon) * scale
    new_lat = cx_lat + (lat - cx_lat) * scale
    return new_lon, new_lat


def _circle_polygon(lon: float, lat: float, radius_m: float, n: int = 16) -> list:
    """Return a closed GeoJSON coordinate ring (n+1 vertices) for a circle."""
    dlat = _D_LAT
    dlon = _d_lon(lat)
    coords = []
    for i in range(n):
        angle = 2.0 * math.pi * i / n
        c_lon = lon + (radius_m * math.sin(angle)) / dlon
        c_lat = lat + (radius_m * math.cos(angle)) / dlat
        coords.append([c_lon, c_lat])
    coords.append(coords[0])  # close ring
    return coords


# ---------------------------------------------------------------------------
# GeoJSON coordinate iteration
# ---------------------------------------------------------------------------


def _iter_geojson_coords(geom: dict):
    """Yield every (lon, lat) pair from any GeoJSON geometry dict."""
    if not geom:
        return
    gtype = geom.get("type", "")
    coords = geom.get("coordinates")
    if coords is None:
        return

    if gtype == "Point":
        yield coords[0], coords[1]
    elif gtype in ("LineString", "MultiPoint"):
        for c in coords:
            yield c[0], c[1]
    elif gtype in ("Polygon", "MultiLineString"):
        for ring in coords:
            for c in ring:
                yield c[0], c[1]
    elif gtype == "MultiPolygon":
        for poly in coords:
            for ring in poly:
                for c in ring:
                    yield c[0], c[1]
    elif gtype == "GeometryCollection":
        for sub in geom.get("geometries") or []:
            yield from _iter_geojson_coords(sub)


# ---------------------------------------------------------------------------
# WKT parsing
# ---------------------------------------------------------------------------

_WKT_NUM = r"-?\d+\.?\d*(?:[eE][+-]?\d+)?"
_WKT_PAIR_RE = re.compile(rf"({_WKT_NUM})\s+({_WKT_NUM})")


def _parse_wkt_geometry(wkt: str | None) -> dict | None:
    """Parse a WKT LINESTRING or MULTILINESTRING into a GeoJSON geometry dict."""
    if not wkt:
        return None
    wkt = wkt.strip()
    upper = wkt.upper()
    try:
        if upper.startswith("LINESTRING"):
            m = re.match(r"LINESTRING\s*\(([^)]+)\)", wkt, re.I)
            if not m:
                return None
            coords = [[float(x), float(y)] for x, y in _WKT_PAIR_RE.findall(m.group(1))]
            return {"type": "LineString", "coordinates": coords} if len(coords) >= 2 else None

        if upper.startswith("MULTILINESTRING"):
            ring_strs = re.findall(r"\(([^)]+)\)", wkt)
            lines = []
            for rs in ring_strs:
                coords = [[float(x), float(y)] for x, y in _WKT_PAIR_RE.findall(rs)]
                if len(coords) >= 2:
                    lines.append(coords)
            return {"type": "MultiLineString", "coordinates": lines} if lines else None
    except Exception:  # noqa: BLE001
        pass
    return None


# ---------------------------------------------------------------------------
# Convenience constructors
# ---------------------------------------------------------------------------


def _straight_line(lon0: float, lat0: float, lon1: float, lat1: float) -> dict:
    """Return a GeoJSON LineString dict connecting two WGS-84 points."""
    return {"type": "LineString", "coordinates": [[lon0, lat0], [lon1, lat1]]}
