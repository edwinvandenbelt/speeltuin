def build_output_path(
    folder: str,
    area_id: str,
    artifact_type: str,
    mode: str | None = None,
    extension: str = "parquet",
) -> str:
    """Build a full output URI: {folder}/{area_id}-{artifact_type}[-{mode}].{extension}"""
    filename = f"{area_id}-{artifact_type}"
    if mode:
        filename += f"-{mode}"
    filename += f".{extension}"
    return f"{folder.rstrip('/')}/{filename}"
