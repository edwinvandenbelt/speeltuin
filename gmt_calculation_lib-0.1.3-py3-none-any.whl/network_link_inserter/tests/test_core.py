"""Tests for network_link_inserter_core."""

from __future__ import annotations

import math

import pytest

from network_link_inserter.core.network_link_inserter_core import (
    _bearing,
    _haversine,
    _linestring_length,
    insert_links,
)

# ---------------------------------------------------------------------------
# Minimal two-node, two-link network fixture
# Node A at (5.0, 52.0), Node B at (5.01, 52.0) — roughly 695 m apart
# ---------------------------------------------------------------------------

_NETWORK = {
    "type": "FeatureCollection",
    "features": [
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
            "properties": {
                "linkId": 1,
                "fromNode": "A",
                "toNode": "B",
                "speed": 50.0,
                "capacity": 800.0,
                "lanes": 1,
                "flow": 100.0,
                "flow24hrs": 2400.0,
                "flowsPerDaypart": {"mrh": 30, "erh": 20, "rest": 50},
                "length": 695.0,
                "heading": 90.0,
                "reverseLinkIds": [2],
                "parallelLinkIds": [],
            },
        },
        {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[5.01, 52.0], [5.0, 52.0]]},
            "properties": {
                "linkId": 2,
                "fromNode": "B",
                "toNode": "A",
                "speed": 50.0,
                "capacity": 800.0,
                "lanes": 1,
                "flow": 80.0,
                "flow24hrs": 1920.0,
                "flowsPerDaypart": {"mrh": 25, "erh": 15, "rest": 40},
                "length": 695.0,
                "heading": 270.0,
                "reverseLinkIds": [1],
                "parallelLinkIds": [],
            },
        },
    ],
    "properties": {"bbox": [5.0, 52.0, 5.01, 52.0]},
}


# ---------------------------------------------------------------------------
# Geographic helper tests
# ---------------------------------------------------------------------------


def test_haversine_zero():
    assert _haversine(5.0, 52.0, 5.0, 52.0) == pytest.approx(0.0, abs=1e-6)


def test_haversine_known():
    # 1 degree of longitude at lat 52 is roughly 68_460 m (haversine)
    d = _haversine(5.0, 52.0, 6.0, 52.0)
    assert d == pytest.approx(68_460, rel=0.01)


def test_bearing_east():
    b = _bearing(5.0, 52.0, 6.0, 52.0)
    assert b == pytest.approx(90.0, abs=0.5)


def test_bearing_north():
    b = _bearing(5.0, 52.0, 5.0, 53.0)
    assert b == pytest.approx(0.0, abs=0.5)


def test_linestring_length_two_points():
    coords = [[5.0, 52.0], [5.01, 52.0]]
    length = _linestring_length(coords)
    expected = _haversine(5.0, 52.0, 5.01, 52.0)
    assert length == pytest.approx(expected, rel=1e-6)


# ---------------------------------------------------------------------------
# insert_links — validation
# ---------------------------------------------------------------------------


def test_skip_non_null_link_id():
    change = {
        "linkId": 999,  # must be null
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
        "speed": 50.0,
        "capacity": 800.0,
    }
    _, report = insert_links(_NETWORK, [change])
    assert report["skipped"] == 1
    assert report["inserted"] == 0
    assert report["changes"][0]["status"] == "skipped"


def test_skip_wrong_geometry_type():
    change = {
        "linkId": None,
        "geometry": {"type": "Point", "coordinates": [5.0, 52.0]},
        "speed": 50.0,
        "capacity": 800.0,
    }
    _, report = insert_links(_NETWORK, [change])
    assert report["skipped"] == 1


def test_skip_too_few_coords():
    change = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0]]},
        "speed": 50.0,
        "capacity": 800.0,
    }
    _, report = insert_links(_NETWORK, [change])
    assert report["skipped"] == 1


# ---------------------------------------------------------------------------
# insert_links — snap to existing nodes
# ---------------------------------------------------------------------------


def test_snap_to_node_both_direction():
    """New link from node A to node B, direction=both -> 2 new features."""
    change = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
        "speed": 60.0,
        "capacity": 1200.0,
        "lanes": 2,
        "direction": "both",
    }
    result_fc, report = insert_links(_NETWORK, [change], snap_tolerance_m=20.0)

    assert report["inserted"] == 1
    assert report["skipped"] == 0
    assert report["links_added"] == 2
    assert len(report["changes"][0]["links_created"]) == 2

    # Original 2 + 2 new = 4 features
    assert len(result_fc["features"]) == 4

    # Find the two new features by their linkId prefix
    new_feats = [
        f for f in result_fc["features"]
        if str(f["properties"]["linkId"]).startswith("new_link_")
    ]
    assert len(new_feats) == 2

    # They should reference each other in reverseLinkIds
    ids = {str(f["properties"]["linkId"]) for f in new_feats}
    for f in new_feats:
        rev_ids = set(f["properties"]["reverseLinkIds"])
        assert len(rev_ids) == 1
        assert rev_ids <= ids
        assert str(f["properties"]["linkId"]) not in rev_ids


def test_snap_to_node_forward_only():
    """direction=forward creates only one link."""
    change = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
        "speed": 30.0,
        "capacity": 400.0,
        "direction": "forward",
    }
    result_fc, report = insert_links(_NETWORK, [change], snap_tolerance_m=20.0)

    assert report["inserted"] == 1
    assert report["links_added"] == 1
    new_feats = [
        f for f in result_fc["features"]
        if str(f["properties"]["linkId"]).startswith("new_link_")
    ]
    assert len(new_feats) == 1
    props = new_feats[0]["properties"]
    assert props["fromNode"] == "A"
    assert props["toNode"] == "B"
    assert props["reverseLinkIds"] == []


def test_snap_to_node_backward_only():
    """direction=backward creates one reversed link."""
    change = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
        "speed": 30.0,
        "capacity": 400.0,
        "direction": "backward",
    }
    result_fc, report = insert_links(_NETWORK, [change], snap_tolerance_m=20.0)

    assert report["inserted"] == 1
    assert report["links_added"] == 1
    new_feats = [
        f for f in result_fc["features"]
        if str(f["properties"]["linkId"]).startswith("new_link_")
    ]
    assert len(new_feats) == 1
    props = new_feats[0]["properties"]
    # backward: from_node=to_node of geometry, to_node=from_node of geometry
    assert props["fromNode"] == "B"
    assert props["toNode"] == "A"


def test_new_link_properties():
    """New link has correct zero-flow properties and computed length/heading."""
    change = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
        "speed": 70.0,
        "capacity": 1600.0,
        "lanes": 3,
        "direction": "forward",
    }
    result_fc, _ = insert_links(_NETWORK, [change], snap_tolerance_m=20.0)
    new_feat = next(
        f for f in result_fc["features"]
        if str(f["properties"]["linkId"]).startswith("new_link_")
    )
    p = new_feat["properties"]
    assert p["speed"] == 70.0
    assert p["capacity"] == 1600.0
    assert p["lanes"] == 3
    assert p["flow"] == 0
    assert p["flow24hrs"] == 0
    assert p["flowsPerDaypart"] == {"mrh": 0, "erh": 0, "rest": 0}
    assert p["parallelLinkIds"] == []
    assert p["length"] == pytest.approx(_haversine(5.0, 52.0, 5.01, 52.0), rel=1e-3)
    assert p["heading"] == pytest.approx(90.0, abs=1.0)  # roughly east


# ---------------------------------------------------------------------------
# insert_links — too far from network
# ---------------------------------------------------------------------------


def test_skip_start_endpoint_too_far():
    """Start endpoint far from any node/link -> change is skipped."""
    change = {
        "linkId": None,
        "geometry": {
            "type": "LineString",
            "coordinates": [[4.0, 51.0], [5.01, 52.0]],  # start is far away
        },
        "speed": 50.0,
        "capacity": 800.0,
    }
    result_fc, report = insert_links(
        _NETWORK, [change], snap_tolerance_m=15.0, max_snap_distance_m=30.0
    )
    assert report["skipped"] == 1
    assert report["inserted"] == 0
    # Original 2 features untouched
    assert len(result_fc["features"]) == 2


def test_skip_end_endpoint_too_far():
    """End endpoint far from any node/link -> change is skipped."""
    change = {
        "linkId": None,
        "geometry": {
            "type": "LineString",
            "coordinates": [[5.0, 52.0], [4.0, 51.0]],  # end is far away
        },
        "speed": 50.0,
        "capacity": 800.0,
    }
    result_fc, report = insert_links(
        _NETWORK, [change], snap_tolerance_m=15.0, max_snap_distance_m=30.0
    )
    assert report["skipped"] == 1
    assert len(result_fc["features"]) == 2


# ---------------------------------------------------------------------------
# insert_links — snap to foot of perpendicular (link split)
# ---------------------------------------------------------------------------


def test_snap_splits_link():
    """Endpoint 10 m north of link midpoint -> splits link 1 and its reverse."""
    # Midpoint of A-B is at roughly (5.005, 52.0).
    # Shift 10 m north: 10 m / 111320 m/deg ~ 0.0000898 deg lat
    mid_lon = 5.005
    north_offset = 10.0 / 111_320.0
    near_lon, near_lat = mid_lon, 52.0 + north_offset

    change = {
        "linkId": None,
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [5.0, 52.0],       # start snaps to node A exactly
                [near_lon, near_lat],  # end is 10 m from link 1 midpoint
            ],
        },
        "speed": 40.0,
        "capacity": 600.0,
        "direction": "forward",
    }
    result_fc, report = insert_links(
        _NETWORK, [change], snap_tolerance_m=15.0, max_snap_distance_m=30.0
    )

    assert report["inserted"] == 1
    assert report["skipped"] == 0
    # Original 2 links split into 4 halves, plus 1 new link = 5 features
    assert len(result_fc["features"]) == 5

    # The new link should have fromNode=A and toNode=new_node_1
    new_links = [
        f for f in result_fc["features"]
        if str(f["properties"]["linkId"]).startswith("new_link_")
    ]
    # 4 halves from split + 1 inserted link = 5 new_link features
    assert len(new_links) == 5

    # Verify end outcome shows split
    assert report["changes"][0]["end_snapped"]["method"] == "split"
    new_node = report["changes"][0]["end_snapped"]["node"]
    assert new_node.startswith("new_node_")


def test_split_link_preserves_original_props():
    """Split half-links carry the original link's properties (speed, capacity, etc.)."""
    mid_lon = 5.005
    north_offset = 10.0 / 111_320.0
    near_lon, near_lat = mid_lon, 52.0 + north_offset

    change = {
        "linkId": None,
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [5.0, 52.0],
                [near_lon, near_lat],
            ],
        },
        "speed": 40.0,
        "capacity": 600.0,
        "direction": "forward",
    }
    result_fc, _ = insert_links(
        _NETWORK, [change], snap_tolerance_m=15.0, max_snap_distance_m=30.0
    )

    # Find a split half of original link 1 (fromNode=A, toNode=new_node_...)
    halves = [
        f for f in result_fc["features"]
        if str(f["properties"].get("fromNode", "")) == "A"
        and str(f["properties"]["linkId"]).startswith("new_link_")
    ]
    assert len(halves) >= 1
    half_props = halves[0]["properties"]
    # Original link 1 had speed=50, capacity=800
    assert half_props["speed"] == 50.0
    assert half_props["capacity"] == 800.0
    assert half_props["flow"] == 100.0  # flow copied as-is


# ---------------------------------------------------------------------------
# insert_links — multiple changes
# ---------------------------------------------------------------------------


def test_multiple_changes_independent():
    """Two inserts processed sequentially; IDs are unique."""
    change1 = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
        "speed": 50.0, "capacity": 800.0, "direction": "forward",
    }
    change2 = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.01, 52.0], [5.0, 52.0]]},
        "speed": 30.0, "capacity": 400.0, "direction": "forward",
    }
    result_fc, report = insert_links(_NETWORK, [change1, change2], snap_tolerance_m=20.0)

    assert report["inserted"] == 2
    assert report["links_added"] == 2
    assert report["skipped"] == 0

    new_ids = [
        str(f["properties"]["linkId"])
        for f in result_fc["features"]
        if str(f["properties"]["linkId"]).startswith("new_link_")
    ]
    assert len(set(new_ids)) == 2  # all IDs unique


def test_mix_of_valid_and_skipped():
    bad_change = {"linkId": 42, "geometry": None}
    good_change = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
        "speed": 50.0, "capacity": 800.0, "direction": "forward",
    }
    _, report = insert_links(_NETWORK, [bad_change, good_change], snap_tolerance_m=20.0)

    assert report["inserted"] == 1
    assert report["skipped"] == 1
    assert report["changes"][0]["status"] == "skipped"
    assert report["changes"][1]["status"] == "ok"


# ---------------------------------------------------------------------------
# insert_links — default direction
# ---------------------------------------------------------------------------


def test_default_direction_is_both():
    """Omitting direction defaults to 'both' (2 features created)."""
    change = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
        "speed": 50.0,
        "capacity": 800.0,
    }
    _, report = insert_links(_NETWORK, [change], snap_tolerance_m=20.0)
    assert report["links_added"] == 2


# ---------------------------------------------------------------------------
# insert_links — input network is not mutated
# ---------------------------------------------------------------------------


def test_original_network_not_mutated():
    change = {
        "linkId": None,
        "geometry": {"type": "LineString", "coordinates": [[5.0, 52.0], [5.01, 52.0]]},
        "speed": 50.0, "capacity": 800.0, "direction": "forward",
    }
    original_count = len(_NETWORK["features"])
    insert_links(_NETWORK, [change], snap_tolerance_m=20.0)
    assert len(_NETWORK["features"]) == original_count
