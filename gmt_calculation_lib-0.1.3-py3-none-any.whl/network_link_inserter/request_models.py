"""Request models for the network_link_inserter Lambda."""

from __future__ import annotations

from pydantic import BaseModel, Field


class LinkChange(BaseModel):
    """A single link-insert change object."""

    linkId: None = Field(None, description="Must be null for inserts.")
    geometry: dict = Field(..., description="GeoJSON LineString geometry for the new link.")
    speed: float = Field(..., description="Free-flow speed in km/h.")
    capacity: float = Field(..., description="Capacity in pae/hr.")
    lanes: int = Field(1, description="Number of lanes.")
    direction: str = Field("both", description="'both' | 'forward' | 'backward'.")


class HandlerInput(BaseModel):
    """Validated input for the network_link_inserter handler."""

    networkUri: str = Field(..., description="Full URI of the input network GeoJSON.")
    output_folder: str = Field(..., description="S3 URI or local path of the output folder.")
    changes: list[LinkChange] = Field(..., min_length=1, description="Link-insert changes.")
    snapTolerance: float = Field(15.0, description="Max snap distance to existing node (m).")
    maxSnapDistance: float = Field(30.0, description="Max snap distance via perpendicular (m).")
