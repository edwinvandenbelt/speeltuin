"""Local debug runner for route_explorer.

Calls route_explorer_core functions directly — no Lambda handler involved.

Usage
-----
python -m route_explorer.route_explorer_runner \\
    --network-file /tmp/deventer-centrum-NETWORK-CAR.parquet \\
    --feedlink-file /tmp/deventer-centrum-FEEDLINK-CAR.parquet \\
    --zone-file /tmp/deventer-centrum-ZONE-CAR.parquet \\
    --node-adjustments-file /tmp/node-adjustments.json \\
    --output-folder /tmp/output \\
    --area-id deventer-centrum \\
    --mode CAR

# S3 inputs / local output folder:
python -m route_explorer.route_explorer_runner \\
    --network-file s3://gmp-networks/network/deventer-centrum-NETWORK-CAR.parquet \\
    --feedlink-file s3://gmp-networks/network/deventer-centrum-FEEDLINK-CAR.parquet \\
    --zone-file s3://gmp-networks/network/deventer-centrum-ZONE-CAR.parquet \\
    --node-adjustments-file s3://gmp-networks/od/node-adjustments.json \\
    --output-folder /tmp/output \\
    --area-id deventer-centrum \\
    --mode CAR \\
    --max-routes 3

Output
------
{output_folder}/{area_id}-ROUTES-{mode}.parquet

Node adjustments file format (geojson_feature_modifier style)
-------------------------------------------------------------
[
    {"nodeId": "123", "production": "100", "attraction": "50"},
    {"nodeId": "456", "production": "+20"},
    {"nodeId": "789", "attraction": "75"}
]

Values may be absolute ("100") or deltas ("+20", "-5").

Prerequisites
-------------
* AWS credentials available in the environment or a .env file (only needed for
  s3:// URIs).
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes, content_type: str = "application/octet-stream") -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for route_explorer. Builds an OD trip matrix with "
            "k-shortest route alternatives from network + feedlinks + zones GeoJSON."
        )
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help=(
            "Full URI of the network GeoJSON file with 'flow' per link "
            "(e.g. output of link_based_staq_assigner). Accepts s3:// or local path."
        ),
    )
    parser.add_argument(
        "--feedlink-file",
        required=True,
        metavar="URI",
        help="Full URI of the feedlinks GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--zone-file",
        required=True,
        metavar="URI",
        help="Full URI of the zones GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--node-adjustments-file",
        required=True,
        metavar="URI",
        help=(
            "URI of a JSON file containing node-level production/attraction adjustments. "
            "Each entry must have 'nodeId' and may have 'production' and/or 'attraction'. "
            "Values may be absolute ('100') or deltas ('+50', '-20'). "
            "Accepts s3:// or local path."
        ),
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="DIR",
        help="Output directory (local path or s3:// prefix).  File is written as {area_id}-ROUTES-{mode}.parquet.",
    )
    parser.add_argument(
        "--area-id",
        required=True,
        metavar="ID",
        help="Area identifier used to name the output file.",
    )
    parser.add_argument(
        "--mode",
        required=True,
        metavar="MODE",
        help="Transport mode, e.g. CAR, BIKE, PEDESTRIAN.",
    )
    parser.add_argument(
        "--max-routes",
        type=int,
        default=3,
        metavar="K",
        help="Maximum number of alternative routes per OD pair (default: 3).",
    )
    parser.add_argument(
        "--min-endpoint-dist",
        type=float,
        default=100.0,
        metavar="M",
        help=(
            "Minimum straight-line distance in metres between the centroids of "
            "origin and destination for BOUNDARY zone → BOUNDARY zone pairs. "
            "Pairs closer than this threshold are skipped to suppress spurious "
            "U-turn routes at reverse boundary crossings. "
            "Set to 0 to disable (default: 100)."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from route_explorer.core.route_explorer_core import build_od_matrix  # noqa: PLC0415
    from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

    print(f"Reading network         : {args.network_file}")
    network_fc = from_geoparquet(_read_uri(args.network_file))

    print(f"Reading feedlinks       : {args.feedlink_file}")
    feedlinks_fc = from_geoparquet(_read_uri(args.feedlink_file))

    print(f"Reading zones           : {args.zone_file}")
    zones_fc = from_geoparquet(_read_uri(args.zone_file))

    print(f"Reading node adjustments: {args.node_adjustments_file}")
    import json  # noqa: PLC0415
    node_adjustments = json.loads(_read_uri(args.node_adjustments_file))

    n_zones = len(zones_fc.get("features", []))
    print(
        f"Building OD matrix: {n_zones} zones, "
        f"{len(node_adjustments)} adjustment entries, max_routes={args.max_routes} ..."
    )

    od_geojson = build_od_matrix(
        network_fc,
        feedlinks_fc,
        zones_fc,
        node_adjustments=node_adjustments,
        max_routes=args.max_routes,
        min_endpoint_dist_m=args.min_endpoint_dist,
    )

    n_features = len(od_geojson.get("features", []))

    from shared.output_path import build_output_path  # noqa: PLC0415

    output_uri = build_output_path(args.output_folder, args.area_id, "ROUTES", args.mode)
    print(f"Writing GeoParquet : {output_uri}")
    _write_uri(
        output_uri,
        to_geoparquet(od_geojson),
    )

    print()
    print(f"Done. {n_features} OD features written.")


if __name__ == "__main__":
    main()
