"""Pure-Python route_explorer core — no I/O, no boto3, no external deps.

Builds a partial OD matrix (rows and columns) from explicit node-level
production/attraction assignments to/from all zones, excluding each node's
own home zone.

Algorithm
---------
1. Build directed graph from network + feedlinks (reuses ``build_graph``).
2. Parse ``node_adjustments`` to get per-node production and attraction values.
3. Derive zone productions and attractions from the ``flow`` field on network
   links attached to each zone's feedlink anchor node.
4. For each node N with production > 0:
   a. Determine its home zones geometrically (point-in-polygon on all zones).
   b. For every non-home zone W that has feedlinks:
      - Route N → zone_virtual_node(W); trips = production[N] × attractions[W]
5. For each node N with attraction > 0:
   b. For every non-home zone W that has feedlinks:
      - Route zone_virtual_node(W) → N; trips = attraction[N] × productions[W]
6. Serialise results to GeoJSON (MultiLineString per pair).

Public API
----------
build_od_matrix(network_fc, feedlinks_fc, zones_fc, node_adjustments, max_routes=3)
    -> od_geojson dict
"""

from __future__ import annotations

import heapq
import logging
import math

from network_zone_joiner.domain.geometry import point_in_polygon
from od_support_matrices_creator.core.od_support_matrices_creator_core import (
    build_graph,
    compute_zone_headings,
    compute_zone_reverse_pairs,
    extract_zone_centroids,
)
from shared.geo_utils import _flat_earth_dist_m

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Output field definitions (authoritative — keep in sync with openapi.yaml)
# ---------------------------------------------------------------------------

OD_BUILDER_PROPERTIES: tuple[str, ...] = (
    "fromZoneId",
    "toZoneId",
    "fromType",
    "toType",
    "originProduction",
    "tripFraction",
    "motifRatio",
    "routes",
)

# ---------------------------------------------------------------------------
# Internal constants
# ---------------------------------------------------------------------------

_ZONE_PREFIX: str = "Z_"
_MAX_ROUTE_TIME_RATIO: float = 1.2  # discard alternative routes > 1.2× the shortest travel time

# Congestion-penalty calibration constants
# penalty(u) = 1 + _CAP_A * x^_CAP_B  where x = (u - _CAP_THRESHOLD) / (1 - u)
# Calibrated so that penalty(0.80) ≈ 3 and penalty(0.95) ≈ 30.
_CAP_THRESHOLD: float = 0.70
_CAP_B: float = math.log(14.5) / math.log(10)  # ≈ 1.161
_CAP_A: float = 2.0 / (0.5**_CAP_B)  # ≈ 4.444

# Motive-specific weight-function parameters (alpha, beta)
_MOTIVE_PARAMS: dict[str, tuple[float, float]] = {
    "work": (0.1, 10.0),
    "shopping": (0.3, 3.0),
}

# Type aliases
Adjacency = dict[str, list[tuple[str, float, float, float, float]]]
RouteEntry = tuple[
    float, float, float, float, list[str]
]  # (time_s, dist_m, remaining_cap, cap_total, nodes)
PairKey = tuple[str, str, str, str]  # (from_id, to_id, from_type, to_type)


# ---------------------------------------------------------------------------
# Small geometry helpers
# ---------------------------------------------------------------------------


def _heading_diff(h1: float, h2: float) -> float:
    """Absolute angular difference between two compass headings, in degrees [0, 180]."""
    diff = abs(h1 - h2) % 360.0
    return diff if diff <= 180.0 else 360.0 - diff


def _build_reverse_edge_map(
    network_fc: dict,
) -> dict[tuple[str, str], frozenset[tuple[str, str]]]:
    """Build a ``{(fromNode, toNode): frozenset_of_reverse_edges}`` lookup.

    Uses the ``linkId`` and ``reverseLinkIds`` properties set by
    ``bidirectional_splitter`` / ``parallel_link_finder`` to map every directed
    edge to the set of physically anti-parallel edges on the same or adjacent
    road.  The result is used in Yen's k-shortest spur step to prevent
    alternative routes from doubling back via a parallel reverse road.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection.  Links need ``fromNode``, ``toNode``,
        ``linkId`` (int), and optionally ``reverseLinkIds`` (list[int]).

    Returns
    -------
    dict mapping ``(fromNode, toNode)`` to a ``frozenset`` of
    ``(fromNode, toNode)`` tuples for the reverse-direction counterparts.
    Only edges that have at least one resolvable reverse link are present.
    """
    link_id_to_edge: dict[int, tuple[str, str]] = {}
    edge_to_rev_ids: dict[tuple[str, str], list[int]] = {}

    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        from_n = str(props.get("fromNode", ""))
        to_n = str(props.get("toNode", ""))
        link_id = props.get("linkId")
        if not from_n or not to_n:
            continue
        edge = (from_n, to_n)
        if link_id is not None:
            try:
                link_id_key = int(link_id)
            except (TypeError, ValueError):
                link_id_key = str(link_id)
            link_id_to_edge[link_id_key] = edge
        rev_ids_raw = props.get("reverseLinkIds") or []
        if rev_ids_raw:
            rev_ids = []
            for x in rev_ids_raw:
                try:
                    rev_ids.append(int(x))
                except (TypeError, ValueError):
                    rev_ids.append(str(x))
            edge_to_rev_ids[edge] = rev_ids

    reverse_edge_map: dict[tuple[str, str], frozenset[tuple[str, str]]] = {}
    for edge, rev_ids in edge_to_rev_ids.items():
        rev_edges = frozenset(
            rev_e for rid in rev_ids if (rev_e := link_id_to_edge.get(rid)) is not None
        )
        if rev_edges:
            reverse_edge_map[edge] = rev_edges

    return reverse_edge_map


# ---------------------------------------------------------------------------
# Dijkstra with path tracking
# ---------------------------------------------------------------------------


def _dijkstra_path(
    adj: Adjacency,
    source: str,
    target: str,
    forbidden_edges: set[tuple[str, str]] | None = None,
    forbidden_nodes: set[str] | None = None,
) -> RouteEntry | None:
    """Dijkstra from *source* to *target*, returning (time, dist, res, path) or None.

    Parameters
    ----------
    adj:
        Directed adjacency ``{node: [(neighbour, time_s, dist_m, cap), ...]}``.
    source:
        Start node.
    target:
        End node.
    forbidden_edges:
        Set of ``(from_node, to_node)`` edges to skip.
    forbidden_nodes:
        Set of node IDs to skip (source and target are never skipped).
    """
    _INF = float("inf")
    _forbidden_edges = forbidden_edges or set()
    _forbidden_nodes = forbidden_nodes or set()

    time_dict: dict[str, float] = {source: 0.0}
    dist_dict: dict[str, float] = {source: 0.0}
    res_dict: dict[str, float] = {source: _INF}
    cap_total_dict: dict[str, float] = {source: _INF}  # total_cap at bottleneck link
    pred: dict[str, str | None] = {source: None}

    heap: list[tuple[float, str]] = [(0.0, source)]

    while heap:
        t, node = heapq.heappop(heap)
        if t > time_dict.get(node, _INF):
            continue
        if node == target:
            break
        for nbr, time_w, dist_w, cap, total_cap in adj.get(node, []):
            if (node, nbr) in _forbidden_edges:
                continue
            if nbr != target and nbr in _forbidden_nodes:
                continue
            nt = t + time_w
            if nt < time_dict.get(nbr, _INF):
                time_dict[nbr] = nt
                dist_dict[nbr] = dist_dict[node] + dist_w
                new_res = min(res_dict[node], cap)
                res_dict[nbr] = new_res
                # Track which link is the bottleneck: whichever has min remaining cap
                if cap <= res_dict[node]:
                    cap_total_dict[nbr] = total_cap
                else:
                    cap_total_dict[nbr] = cap_total_dict[node]
                pred[nbr] = node
                heapq.heappush(heap, (nt, nbr))

    if target not in time_dict:
        return None

    # Reconstruct path by following predecessors back from target
    path: list[str] = []
    cur: str | None = target
    while cur is not None:
        path.append(cur)
        cur = pred.get(cur)
    path.reverse()

    if path[0] != source:
        return None

    t_val = time_dict[target]
    if t_val >= _INF:
        return None

    return t_val, dist_dict[target], res_dict[target], cap_total_dict.get(target, _INF), path


# ---------------------------------------------------------------------------
# Yen's k-shortest loopless paths
# ---------------------------------------------------------------------------


def _root_cost(
    adj: Adjacency,
    path_nodes: list[str],
) -> tuple[float, float, float, float]:
    """Compute (time, dist, remaining_cap, cap_total) for a prefix path."""
    t_total = 0.0
    d_total = 0.0
    r_total = float("inf")
    c_total = float("inf")  # total_cap at the bottleneck link
    for i in range(len(path_nodes) - 1):
        u = path_nodes[i]
        v = path_nodes[i + 1]
        found = False
        for nbr, tw, dw, cap, total_cap in adj.get(u, []):
            if nbr == v:
                t_total += tw
                d_total += dw
                if cap < r_total:
                    r_total = cap
                    c_total = total_cap
                found = True
                break
        if not found:
            return float("inf"), float("inf"), 0.0, 0.0
    return t_total, d_total, r_total, c_total


def _yen_k_shortest(
    adj: Adjacency,
    source: str,
    target: str,
    k: int,
    reverse_edge_map: dict[tuple[str, str], frozenset[tuple[str, str]]] | None = None,
) -> list[RouteEntry]:
    """Yen's k-shortest loopless paths from *source* to *target*.

    Returns up to *k* paths as ``(time_s, dist_m, remaining_cap, cap_total, nodes)`` tuples sorted
    by ascending travel time.  Returns an empty list if no path exists.

    Parameters
    ----------
    adj:
        Directed adjacency dict.
    source:
        Origin node.
    target:
        Destination node.
    k:
        Maximum number of alternative paths to return.
    reverse_edge_map:
        Optional ``{(fromNode, toNode): frozenset_of_reverse_edges}`` lookup
        produced by :func:`_build_reverse_edge_map`.  When provided, the spur
        step additionally forbids the physical reverse-direction counterparts of
        all root-path edges, preventing alternative routes from doubling back
        along the parallel reverse road.
    """
    first = _dijkstra_path(adj, source, target)
    if first is None:
        return []

    best_paths: list[RouteEntry] = [first]
    # candidates: list of (time, dist, remaining_cap, cap_total, path)
    candidates: list[RouteEntry] = []
    seen_paths: set[tuple[str, ...]] = {tuple(first[4])}

    for _ in range(k - 1):
        prev_path_nodes = best_paths[-1][4]

        for spur_idx in range(len(prev_path_nodes) - 1):
            spur_node = prev_path_nodes[spur_idx]
            root_nodes = prev_path_nodes[: spur_idx + 1]

            # Compute root path cost
            root_t, root_d, root_r, root_c = _root_cost(adj, root_nodes)

            # Forbid edges that are used by any known path sharing the same root
            forbidden_edges: set[tuple[str, str]] = set()
            for _, _, _, _, p_nodes in best_paths:
                if len(p_nodes) > spur_idx and list(p_nodes[: spur_idx + 1]) == root_nodes:
                    if spur_idx + 1 < len(p_nodes):
                        forbidden_edges.add((p_nodes[spur_idx], p_nodes[spur_idx + 1]))
            for _, _, _, _, p_nodes in candidates:
                if len(p_nodes) > spur_idx and list(p_nodes[: spur_idx + 1]) == root_nodes:
                    if spur_idx + 1 < len(p_nodes):
                        forbidden_edges.add((p_nodes[spur_idx], p_nodes[spur_idx + 1]))

            # Also forbid the physical reverse-direction counterparts of all
            # committed root-path edges.  This prevents spur paths from
            # doubling back along the parallel reverse road (e.g. using the
            # opposite carriageway of a dual road to rejoin the path), which
            # would produce routes that are unrealistic for real traffic.
            if reverse_edge_map:
                for i in range(spur_idx):
                    root_edge = (root_nodes[i], root_nodes[i + 1])
                    forbidden_edges.update(reverse_edge_map.get(root_edge, ()))

            # Forbid root nodes (except spur_node itself) to ensure loop-free paths
            forbidden_nodes: set[str] = set(root_nodes[:-1])

            spur_result = _dijkstra_path(adj, spur_node, target, forbidden_edges, forbidden_nodes)
            if spur_result is None:
                continue

            s_t, s_d, s_r, s_c, spur_nodes = spur_result
            full_path_nodes = root_nodes + spur_nodes[1:]

            # Skip duplicate paths
            path_key = tuple(full_path_nodes)
            if path_key in seen_paths:
                continue
            seen_paths.add(path_key)

            full_t = root_t + s_t
            full_d = root_d + s_d
            # Combine root and spur bottleneck: the side with lower remaining_cap wins
            if len(root_nodes) > 1:
                if root_r <= s_r:
                    full_r, full_c = root_r, root_c
                else:
                    full_r, full_c = s_r, s_c
            else:
                full_r, full_c = s_r, s_c

            candidates.append((full_t, full_d, full_r, full_c, full_path_nodes))

        if not candidates:
            break

        # Pick the candidate with minimum travel time, discarding any that
        # exceed _MAX_ROUTE_TIME_RATIO × the shortest (first) path travel time.
        candidates.sort(key=lambda x: x[0])
        best_t, best_d, best_r, best_c, best_nodes = candidates.pop(0)
        if best_t > best_paths[0][0] * _MAX_ROUTE_TIME_RATIO:
            break  # remaining candidates are at least as slow — stop early
        best_paths.append((best_t, best_d, best_r, best_c, best_nodes))

    return best_paths


# ---------------------------------------------------------------------------
# Home-zone detection
# ---------------------------------------------------------------------------


def _find_home_zones(
    node_lon_lat: list[float] | None,
    zone_features: list[dict],
) -> set[str]:
    """Return the set of zone IDs whose polygon contains the given coordinate.

    Uses point-in-polygon geometry to determine home zones.  BOUNDARY
    mini-zones are polygon features like all other zones and are tested the
    same way.

    Parameters
    ----------
    node_lon_lat:
        ``[lon, lat]`` of the anchor node, or ``None`` if unknown.
    zone_features:
        List of zone GeoJSON features (from ``zones_fc["features"]``).

    Returns
    -------
    set of zone IDs (strings) whose polygon geometry contains the point.
    """
    if not node_lon_lat:
        return set()
    lon, lat = float(node_lon_lat[0]), float(node_lon_lat[1])
    home: set[str] = set()
    for feat in zone_features:
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        if not zone_id:
            continue
        geom = feat.get("geometry") or {}
        geom_type = geom.get("type") or ""
        raw_coords = geom.get("coordinates") or []
        if geom_type == "Polygon":
            rings = [raw_coords[0]] if raw_coords and raw_coords[0] else []
        elif geom_type == "MultiPolygon":
            rings = [poly[0] for poly in raw_coords if poly and poly[0]]
        else:
            continue
        for ring in rings:
            if point_in_polygon(lon, lat, ring):
                home.add(zone_id)
                break
    return home


# ---------------------------------------------------------------------------
# Flow-based zone marginal estimation
# ---------------------------------------------------------------------------


def _extract_network_node_set(network_fc: dict) -> set[str]:
    """Return the set of all node IDs that appear in network link properties."""
    nodes: set[str] = set()
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        from_n = str(props.get("fromNode", ""))
        to_n = str(props.get("toNode", ""))
        if from_n:
            nodes.add(from_n)
        if to_n:
            nodes.add(to_n)
    return nodes


def _extract_node_flows(
    network_fc: dict,
) -> tuple[dict[str, float], dict[str, float]]:
    """Return ``(outflow, inflow)`` dicts keyed by network node ID.

    Uses the ``flow`` property on each network link feature.  Links with
    missing or zero ``flow`` contribute 0.
    """
    outflow: dict[str, float] = {}
    inflow: dict[str, float] = {}
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        from_n = str(props.get("fromNode", ""))
        to_n = str(props.get("toNode", ""))
        flow = float(props.get("flow") or 0.0)
        if from_n:
            outflow[from_n] = outflow.get(from_n, 0.0) + flow
        if to_n:
            inflow[to_n] = inflow.get(to_n, 0.0) + flow
    return outflow, inflow


def _zone_attachment_nodes(
    feedlinks_fc: dict,
    network_node_set: set[str],
) -> dict[str, dict[str, str]]:
    """Map each zone to its production/attraction network attachment nodes.

    Returns ``{zoneId: {"prod": node_id, "attr": node_id}}``.  A zone may have
    only one of the two keys if only one feedlink direction is present.
    """
    result: dict[str, dict[str, str]] = {}
    for feat in feedlinks_fc.get("features", []):
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "").strip()
        from_n = str(props.get("fromNode") or "").strip()
        to_n = str(props.get("toNode") or "").strip()
        if not zone_id:
            continue

        to_is_net = to_n in network_node_set
        from_is_net = from_n in network_node_set

        entry = result.setdefault(zone_id, {})
        if to_is_net and not from_is_net:
            # Production feedlink: zone centroid → network node
            entry["prod"] = to_n
        elif from_is_net and not to_is_net:
            # Attraction feedlink: network node → zone centroid
            entry["attr"] = from_n
        else:
            # Ambiguous — treat as both directions at the same node
            entry["prod"] = to_n
            entry["attr"] = from_n

    return result


def _estimate_zone_marginals(
    network_fc: dict,
    feedlinks_fc: dict,
    zone_ids: list[str],
    fallback: float = 1.0,
) -> tuple[dict[str, float], dict[str, float]]:
    """Estimate zone productions and attractions from network ``flow`` values.

    When a zone has no flow at its attachment node (e.g. feedlinks are present
    but the attached links carry zero flow), *fallback* is used instead so that
    trip calculations have non-zero weights for every zone.

    Returns ``(productions, attractions)`` dicts keyed by zone ID.
    """
    net_nodes = _extract_network_node_set(network_fc)
    outflow, inflow = _extract_node_flows(network_fc)
    attachment = _zone_attachment_nodes(feedlinks_fc, net_nodes)

    productions: dict[str, float] = {}
    attractions: dict[str, float] = {}
    for zone_id in zone_ids:
        nodes = attachment.get(zone_id, {})
        prod_node = nodes.get("prod") or nodes.get("attr")
        attr_node = nodes.get("attr") or nodes.get("prod")

        p = outflow.get(prod_node, 0.0) if prod_node else 0.0
        a = inflow.get(attr_node, 0.0) if attr_node else 0.0

        productions[zone_id] = p if p > 0.0 else fallback
        attractions[zone_id] = a if a > 0.0 else fallback

    return productions, attractions


# ---------------------------------------------------------------------------
# Node coordinate / edge geometry helpers
# ---------------------------------------------------------------------------


def _extract_node_coords(network_fc: dict) -> dict[str, list[float]]:
    """Build ``{nodeId: [lon, lat]}`` from network link endpoint coordinates."""
    coords: dict[str, list[float]] = {}
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        geom = feat.get("geometry") or {}
        from_n = str(props.get("fromNode", ""))
        to_n = str(props.get("toNode", ""))
        pts = geom.get("coordinates") or []
        if pts:
            if from_n and from_n not in coords:
                coords[from_n] = [float(pts[0][0]), float(pts[0][1])]
            if to_n and to_n not in coords:
                coords[to_n] = [float(pts[-1][0]), float(pts[-1][1])]
    return coords


def _build_link_coord_index(network_fc: dict) -> dict[tuple[str, str], list[list[float]]]:
    """Build ``{(fromNode, toNode): [[lon, lat], ...]}`` from network link geometries.

    Each value contains the full ordered coordinate sequence of the link's
    ``LineString`` geometry, including both endpoints.  Used by
    ``_path_to_linestring`` to reconstruct accurate route geometries.
    """
    index: dict[tuple[str, str], list[list[float]]] = {}
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        geom = feat.get("geometry") or {}
        from_n = str(props.get("fromNode", "")).strip()
        to_n = str(props.get("toNode", "")).strip()
        pts = geom.get("coordinates") or []
        if from_n and to_n and len(pts) >= 2:
            index[(from_n, to_n)] = [[float(c[0]), float(c[1])] for c in pts]
    return index


def _path_to_linestring(
    path_nodes: list[str],
    node_coords: dict[str, list[float]],
    zone_centroids: dict[str, tuple[float, float]],
    link_coord_index: dict[tuple[str, str], list[list[float]]] | None = None,
) -> list[list[float]]:
    """Convert a node path to a list of ``[lon, lat]`` coordinate pairs.

    When *link_coord_index* is provided each consecutive node pair ``(u, v)``
    is resolved to the full ``LineString`` coordinate sequence of that network
    link, producing an accurate curved geometry.  For edges that are absent
    from the index (feedlinks, virtual zone edges) only the endpoint coordinate
    is appended as a fallback.

    Virtual zone centroid nodes (``Z_<zoneId>``) are resolved via
    *zone_centroids*.  Nodes without known coordinates are skipped.
    """

    def _node_pt(node_id: str) -> list[float] | None:
        if node_id in node_coords:
            return node_coords[node_id]
        if node_id.startswith(_ZONE_PREFIX):
            c = zone_centroids.get(node_id[len(_ZONE_PREFIX) :])
            if c:
                return [c[0], c[1]]
        return None

    result: list[list[float]] = []

    if link_coord_index is not None and len(path_nodes) >= 2:
        # Seed with the first node's coordinate
        first_pt = _node_pt(path_nodes[0])
        if first_pt:
            result.append(first_pt)
        for i in range(len(path_nodes) - 1):
            u, v = path_nodes[i], path_nodes[i + 1]
            link_pts = link_coord_index.get((u, v))
            if link_pts:
                # Skip the first point of the link (already added as the previous endpoint)
                result.extend(link_pts[1:])
            else:
                # Fallback: append only the endpoint
                pt = _node_pt(v)
                if pt:
                    result.append(pt)
    else:
        # Legacy path: one point per node
        for node_id in path_nodes:
            pt = _node_pt(node_id)
            if pt:
                result.append(pt)

    # De-duplicate consecutive identical points
    deduped: list[list[float]] = []
    for pt in result:
        if not deduped or pt != deduped[-1]:
            deduped.append(pt)

    return deduped


def _resolve_coord(
    entity_id: str,
    entity_type: str,
    node_coords: dict[str, list[float]],
    zone_centroids: dict[str, tuple[float, float]],
) -> list[float] | None:
    """Resolve a coordinate for geometry fallback.

    Returns ``[lon, lat]`` for nodes or zone centroids, or ``None`` if unknown.
    """
    if entity_type == "node":
        return node_coords.get(entity_id)
    c = zone_centroids.get(entity_id)
    return [c[0], c[1]] if c else None


# ---------------------------------------------------------------------------
# Serialisation
# ---------------------------------------------------------------------------


def _congestion_penalty(utilization: float) -> float:
    """Return a travel-time penalty multiplier for road utilization above threshold.

    For ``utilization <= _CAP_THRESHOLD`` the multiplier is 1.0 (no penalty).
    Above the threshold the multiplier grows as a power law calibrated so that
    ``penalty(0.80) ≈ 3`` and ``penalty(0.95) ≈ 30``.
    """
    if utilization <= _CAP_THRESHOLD:
        return 1.0
    # Guard against division by zero (utilization == 1.0 exactly)
    denominator = max(1.0 - utilization, 1e-9)
    x = (utilization - _CAP_THRESHOLD) / denominator
    return 1.0 + _CAP_A * (x**_CAP_B)


def _build_link_index(network_fc: dict) -> dict[tuple[str, str], str]:
    """Return ``{(fromNode, toNode): linkId}`` for all network links."""
    index: dict[tuple[str, str], str] = {}
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        fn = str(props.get("fromNode", "")).strip()
        tn = str(props.get("toNode", "")).strip()
        link_id = props.get("linkId")
        if fn and tn and link_id is not None:
            index[(fn, tn)] = str(link_id)
    return index


def _build_link_speed_index(network_fc: dict) -> dict[tuple[str, str], float]:
    """Return ``{(fromNode, toNode): speed_kmh}`` for all network links."""
    index: dict[tuple[str, str], float] = {}
    for feat in network_fc.get("features", []):
        props = feat.get("properties") or {}
        fn = str(props.get("fromNode", "")).strip()
        tn = str(props.get("toNode", "")).strip()
        speed = props.get("speed")
        if fn and tn and speed is not None:
            try:
                index[(fn, tn)] = float(speed)
            except (TypeError, ValueError):
                pass
    return index


def _boundary_link_speed(
    path_nodes: list[str],
    from_type: str,
    to_type: str,
    speed_index: dict[tuple[str, str], float],
) -> float | None:
    """Return the speed (km/h) of the boundary network link for an external route.

    For ``zone → node`` routes the boundary link is the first real network
    edge after the zone feedlink (``path[1] → path[2]``).
    For ``node → zone`` routes it is the last real network edge before the
    zone feedlink (``path[-3] → path[-2]``).
    For ``zone → zone`` routes the entry boundary link is used.

    Returns ``None`` when the path is too short to contain a real network edge
    or when the link is absent from *speed_index*.
    """
    if from_type == "zone":
        # skip the feedlink edge Z_... → path[1]; first real edge is path[1]→path[2]
        if len(path_nodes) >= 3:
            return speed_index.get((path_nodes[1], path_nodes[2]))
    elif to_type == "zone":
        # skip the feedlink edge path[-2] → Z_...; last real edge is path[-3]→path[-2]
        if len(path_nodes) >= 3:
            return speed_index.get((path_nodes[-3], path_nodes[-2]))
    return None


def _apply_external_tt_correction(
    features: list[dict],
    target_avg_tt_s: float,
    speed_index: dict[tuple[str, str], float],
    ref_speed_kmh: float | None,
) -> None:
    """Add a travel-time correction to all external routes (in-place).

    The correction is calibrated so that the weighted average travel time of
    **internal** routes (both endpoints are nodes) equals *target_avg_tt_s*.
    External routes (at least one zone endpoint) receive the correction.

    When *ref_speed_kmh* is given the correction is scaled by the speed on the
    boundary network link:

    ``correction_i = correction_base × (speed_i / ref_speed_kmh)``

    If the boundary link speed cannot be determined, *correction_base* is used
    as a flat fallback.  The correction is always non-negative (only increases
    travel time).

    Parameters
    ----------
    features:
        List of GeoJSON feature dicts as produced by ``_build_od_geojson``.
        Each feature must have ``properties.fromType``, ``properties.toType``
        and ``properties.routes`` (list of route dicts with ``travelTime`` and
        ``trips``).
    target_avg_tt_s:
        Target average travel time in seconds.
    speed_index:
        ``{(fromNode, toNode): speed_kmh}`` from ``_build_link_speed_index``.
        Ignored when *ref_speed_kmh* is ``None``.
    ref_speed_kmh:
        Reference speed for scaling.  ``None`` disables speed-based scaling
        (flat correction for all external routes).
    """
    # ------------------------------------------------------------------
    # 1. Weighted average travel time of internal routes
    # ------------------------------------------------------------------
    total_tt_w = 0.0
    total_w = 0.0
    for feat in features:
        props = feat.get("properties") or {}
        if props.get("fromType") == "node" and props.get("toType") == "node":
            for route in props.get("routes") or []:
                trips = float(route.get("trips") or 0.0)
                tt = float(route.get("travelTime") or 0.0)
                total_tt_w += tt * trips
                total_w += trips

    avg_tt = total_tt_w / total_w if total_w > 0.0 else 0.0

    # ------------------------------------------------------------------
    # 2. Base correction (only increase, never decrease)
    # ------------------------------------------------------------------
    correction_base = max(0.0, target_avg_tt_s - avg_tt)
    if correction_base == 0.0:
        return

    # ------------------------------------------------------------------
    # 3. Apply to external routes
    # ------------------------------------------------------------------
    for feat in features:
        props = feat.get("properties") or {}
        from_type = props.get("fromType", "")
        to_type = props.get("toType", "")
        if from_type == "node" and to_type == "node":
            continue  # internal — skip

        for route in props.get("routes") or []:
            if ref_speed_kmh is not None:
                path_nodes: list[str] = route.get("nodePath") or []
                speed = _boundary_link_speed(path_nodes, from_type, to_type, speed_index)
                if speed is not None and ref_speed_kmh > 0.0:
                    corr = correction_base * speed / ref_speed_kmh
                else:
                    corr = correction_base  # fallback: flat
            else:
                corr = correction_base

            route["travelTime"] = round(route.get("travelTime", 0.0) + corr, 3)


def _node_path_to_link_path(
    node_path: list[str],
    link_index: dict[tuple[str, str], str],
) -> list[str]:
    """Convert a sequence of node IDs to the corresponding link IDs.

    Edges that have no matching entry in *link_index* (e.g. feedlink / virtual
    zone edges) are silently omitted.
    """
    links: list[str] = []
    for i in range(len(node_path) - 1):
        u = node_path[i]
        v = node_path[i + 1]
        link_id = link_index.get((u, v))
        if link_id is not None:
            links.append(link_id)
    return links


def _distribute_trips_over_routes(
    total_trips: float,
    routes_data: list[RouteEntry],
    motive: str = "other",
) -> list[float]:
    """Distribute *total_trips* across routes using a motive-aware weight function.

    Weight formula
    --------------
    For each route *i* with travel time ``tt`` and utilization
    ``u = (cap_total - remaining_cap) / cap_total``:

    1. Compute a congestion-adjusted travel time:
       ``tt_adj = tt * _congestion_penalty(u)``  (penalty > 1 when u > 0.70)
    2. Compute ``weight_i = f(tt_adj)`` where:
       ``f(tt) = 0.5 * exp(-α·tt) + 0.5 * exp(-α·max(tt, β)) / exp(-α·β)``
       with ``α`` and ``β`` taken from *_MOTIVE_PARAMS* based on *motive*.

    If all weights are zero (degenerate case), trips are split equally.

    Parameters
    ----------
    total_trips:
        Total number of trips to distribute.
    routes_data:
        List of ``(time_s, dist_m, remaining_cap, cap_total, nodes)`` tuples.
    motive:
        Trip purpose — one of ``"work"``, ``"shopping"``, or any other string
        (treated as ``"other"``).

    Returns
    -------
    list[float]
        Per-route trip counts, same length as *routes_data*, summing to
        *total_trips*.
    """
    if not routes_data:
        return []

    alpha, beta = _MOTIVE_PARAMS.get(motive, (0.2, 6.0))

    weights: list[float] = []
    for tt, _d, remaining_cap, cap_total, _nodes in routes_data:
        if cap_total > 0.0:
            utilization = (cap_total - remaining_cap) / cap_total
        else:
            utilization = 0.0
        tt_adj = tt * _congestion_penalty(utilization)
        # f(tt) = 0.5·exp(-α·tt) + 0.5·exp(-α·max(tt,β)) / exp(-α·β)
        term1 = 0.5 * math.exp(-alpha * tt_adj)
        term2 = 0.5 * math.exp(-alpha * max(tt_adj, beta)) / math.exp(-alpha * beta)
        weights.append(term1 + term2)

    total_weight = sum(weights)
    if total_weight <= 0.0:
        equal = total_trips / len(routes_data)
        return [equal] * len(routes_data)

    return [total_trips * w / total_weight for w in weights]


def _compute_motif_ratio(
    from_id: str,
    to_id: str,
    boundary_zone_ids: set[str],
    zone_building_by_type: dict[str, dict[str, float]] | None,
) -> dict[str, float]:
    """Derive normalised motive distribution for an OD pair.

    Uses ``buildingByType`` of the destination zone. If the destination is a
    BOUNDARY (external) zone, falls back to the origin zone.  If both are
    BOUNDARY zones, returns ``{"unclassified": 1.0}``.
    """
    bbt_lookup = zone_building_by_type or {}
    dest_bbt = bbt_lookup.get(to_id) if to_id not in boundary_zone_ids else None
    bbt = dest_bbt or (bbt_lookup.get(from_id) if from_id not in boundary_zone_ids else None)
    if not bbt:
        return {"unclassified": 1.0}
    total = sum(bbt.values())
    if total <= 0:
        return {"unclassified": 1.0}
    return {k: round(v / total, 6) for k, v in bbt.items() if v > 0}


def _build_od_geojson(
    od_trips: dict[PairKey, float],
    routes_per_pair: dict[PairKey, list[RouteEntry]],
    node_coords: dict[str, list[float]],
    zone_centroids: dict[str, tuple[float, float]],
    link_index: dict[tuple[str, str], str] | None = None,
    motive: str = "other",
    target_avg_tt_s: float = 1800.0,
    ref_speed_kmh: float | None = 70.0,
    link_speed_index: dict[tuple[str, str], float] | None = None,
    zone_productions: dict[str, float] | None = None,
    boundary_zone_ids: set[str] | None = None,
    zone_building_by_type: dict[str, dict[str, float]] | None = None,
) -> dict:
    """Build the OD GeoJSON FeatureCollection.

    Each feature has:
    - ``geometry``: always ``None``.  Pre-computed route geometry is omitted to
      keep file sizes small; consumers reconstruct geometry on demand from
      ``routes[i].linkPath`` joined with the network GeoJSON.
    - ``properties``: ``fromZoneId``, ``toZoneId``, ``fromType`` (``"node"`` or
      ``"zone"``), ``toType``, ``originProduction`` (production of the origin
      zone/node, for weighted visualisation), ``tripFraction``, and ``routes``
      array (each element has ``travelTime``, ``distance``, ``remainingCap``,
      ``trips``, ``nodePath``, ``linkPath``).  ``routes[i].trips`` is the share
      of the pair's total trips assigned to route *i*, distributed
      proportionally to ``remainingCap / travelTime``.
    """
    _link_index: dict[tuple[str, str], str] = link_index or {}
    _boundary_ids: set[str] = boundary_zone_ids or set()
    features: list[dict] = []

    for pair_key, routes_data in routes_per_pair.items():
        from_id, to_id, from_type, to_type = pair_key
        trips = od_trips.get(pair_key, 0.0)
        trips_rounded = round(trips, 4)

        if trips_rounded == 0.0:
            continue

        route_trips = _distribute_trips_over_routes(trips, routes_data, motive)

        # Round per-route trips such that their sum equals trips_rounded exactly.
        # The first n-1 routes are rounded independently; the last absorbs the remainder.
        rounded_route_trips: list[float] = []
        running = 0.0
        for i, rt in enumerate(route_trips):
            if i < len(route_trips) - 1:
                r_rt = round(rt, 4)
                rounded_route_trips.append(r_rt)
                running += r_rt
            else:
                rounded_route_trips.append(round(trips_rounded - running, 4))

        routes_props = [
            {
                "travelTime": round(t, 3),
                "distance": round(d, 3),
                "remainingCap": round(r, 3) if math.isfinite(r) else None,
                "trips": rt,
                "nodePath": path_nodes,
                "linkPath": _node_path_to_link_path(path_nodes, _link_index),
            }
            for (t, d, r, _c, path_nodes), rt in zip(routes_data, rounded_route_trips)
        ]

        # Geometry is omitted; consumers reconstruct from linkPath + network.
        geometry: dict | None = None

        features.append(
            {
                "type": "Feature",
                "geometry": geometry,
                "properties": {
                    "fromZoneId": from_id,
                    "toZoneId": to_id,
                    "fromType": from_type,
                    "toType": to_type,
                    "originProduction": round((zone_productions or {}).get(from_id, 0.0), 4),
                    "tripFraction": trips_rounded,
                    "motifRatio": _compute_motif_ratio(
                        from_id, to_id, _boundary_ids, zone_building_by_type
                    ),
                    "routes": routes_props,
                },
            }
        )

    logger.info("_build_od_geojson: %d features built", len(features))

    # Apply travel-time correction to external routes
    _apply_external_tt_correction(
        features,
        target_avg_tt_s,
        link_speed_index or {},
        ref_speed_kmh,
    )

    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "fields": list(OD_BUILDER_PROPERTIES),
        },
    }


# ---------------------------------------------------------------------------
# Node adjustment parsing
# ---------------------------------------------------------------------------


def _parse_value(value_str: str, current: float) -> float:
    """Parse a geojson_feature_modifier-style value string.

    Leading ``+`` or ``-`` indicates a delta applied to *current*; otherwise
    the string is treated as an absolute value.
    """
    s = str(value_str)
    if s and s[0] in ("+", "-"):
        return current + float(s)
    return float(s)


def _parse_adjustments(
    adjustments: list[dict],
) -> tuple[dict[str, float], dict[str, float], dict[str, float], dict[str, float]]:
    """Parse a list of adjustment objects into per-node and per-zone production/attraction dicts.

    Each adjustment object must have **either** a ``"nodeId"`` **or** a
    ``"zoneId"`` field (not both), and may have ``"production"`` and/or
    ``"attraction"`` fields.  Values follow the geojson_feature_modifier
    convention:

    - Leading ``"+"`` / ``"-"`` → numeric delta applied to the accumulated value
      (base starts at 0 when the ID has not been seen before).
    - Plain numeric string → absolute override of the accumulated value.

    Multiple entries for the same ID are applied in order.

    Returns
    -------
    (node_productions, node_attractions, zone_productions, zone_attractions)
        Four dicts keyed by node ID or zone ID (strings).  Non-zero values
        are production/attraction overrides.  Entries explicitly set to
        ``0.0`` are retained so that ``build_od_matrix`` can emit tombstone
        features that remove existing routes for that node/zone from the
        merged output.  Negative values reduce existing flows via the
        route-applier step.
    """
    node_productions: dict[str, float] = {}
    node_attractions: dict[str, float] = {}
    zone_productions: dict[str, float] = {}
    zone_attractions: dict[str, float] = {}

    for entry in adjustments:
        node_id = str(entry.get("nodeId") or "").strip()
        zone_id = str(entry.get("zoneId") or "").strip()

        if node_id and zone_id:
            raise ValueError(
                f"Adjustment entry has both 'nodeId' ({node_id!r}) and "
                f"'zoneId' ({zone_id!r}): only one may be set per entry."
            )
        if not node_id and not zone_id:
            continue

        if node_id:
            if "production" in entry:
                current = node_productions.get(node_id, 0.0)
                node_productions[node_id] = _parse_value(str(entry["production"]), current)
            if "attraction" in entry:
                current = node_attractions.get(node_id, 0.0)
                node_attractions[node_id] = _parse_value(str(entry["attraction"]), current)
        else:
            if "production" in entry:
                current = zone_productions.get(zone_id, 0.0)
                zone_productions[zone_id] = _parse_value(str(entry["production"]), current)
            if "attraction" in entry:
                current = zone_attractions.get(zone_id, 0.0)
                zone_attractions[zone_id] = _parse_value(str(entry["attraction"]), current)

    # Zero values are intentionally retained: build_od_matrix uses them to emit tombstone
    # features that suppress existing routes for that node/zone in the merged output.
    # Negative values reduce existing flows via the route-applier step.
    return node_productions, node_attractions, zone_productions, zone_attractions


# Back-compat alias used by existing tests.
def _parse_node_adjustments(
    adjustments: list[dict],
) -> tuple[dict[str, float], dict[str, float]]:
    node_prod, node_attr, _, _ = _parse_adjustments(adjustments)
    return node_prod, node_attr


# ---------------------------------------------------------------------------
# Main public API
# ---------------------------------------------------------------------------


def build_od_matrix(
    network_fc: dict,
    feedlinks_fc: dict,
    zones_fc: dict,
    node_adjustments: list[dict],
    max_routes: int = 3,
    motive: str = "other",
    target_avg_tt_s: float = 1800.0,
    ref_speed_kmh: float | None = 70.0,
    min_endpoint_dist_m: float = 100.0,
    max_heading_diff_deg: float = 120.0,
) -> dict:
    """Build a partial OD matrix from explicit node-level production/attraction values.

    For each node with production > 0, routes are computed from that node to
    every non-home zone with feedlinks.  For each node with attraction > 0,
    routes are computed from every non-home zone with feedlinks to that node.
    Home zones are determined geometrically (point-in-polygon).

    Trip weights:

    - ``trips(node → zone_W)`` = ``production[node]`` × ``attractions[zone_W]``
    - ``trips(zone_W → node)`` = ``attraction[node]`` × ``productions[zone_W]``

    where ``attractions[zone_W]`` and ``productions[zone_W]`` are flow-derived
    zone marginals from the network.

    Parameters
    ----------
    network_fc:
        Network GeoJSON FeatureCollection.  Must carry ``fromNode``,
        ``toNode``, ``speed``, ``length``, ``capacity``, and ``flow`` per link.
    feedlinks_fc:
        Feedlinks GeoJSON (output of ``feedlink_creator``).
    zones_fc:
        Zones GeoJSON.  Zone features must have Polygon or MultiPolygon geometry
        for home-zone detection.
    node_adjustments:
        List of adjustment objects.  Each entry must have **either** a
        ``"nodeId"`` **or** a ``"zoneId"`` field (not both), and may have
        ``"production"`` and/or ``"attraction"`` fields.  Values may be
        absolute (``"100"``) or deltas (``"+50"``, ``"-20"``).
    max_routes:
        Maximum number of alternative routes per pair.  Defaults to 3.
    min_endpoint_dist_m:
        Minimum straight-line distance in metres between the centroids of the
        origin and destination zone for BOUNDARY zone → BOUNDARY zone pairs.
        Pairs whose centroids are closer than this threshold are candidates for
        the U-turn heading filter below.  Set to 0 to disable both filters.
        Defaults to 100 m.
    max_heading_diff_deg:
        Maximum allowed compass-heading difference (in degrees) between the
        origin and destination BOUNDARY zones.  When two BOUNDARY zone centroids
        are closer than ``min_endpoint_dist_m`` *and* their road headings differ
        by more than this value the pair is skipped as an implausible U-turn.
        Defaults to 120°.  Set to 0 to apply only the distance filter.

    Returns
    -------
    dict
        GeoJSON FeatureCollection — one Feature per routable (node, zone) or
        (zone, node) pair.  Geometry is ``MultiLineString``; properties are
        ``fromId``, ``toId``, ``fromType``, ``toType``, ``trips``, ``routes``.
    """
    # ------------------------------------------------------------------
    # 1. Parse adjustments (node-based and zone-based)
    # ------------------------------------------------------------------
    node_productions, node_attractions, zone_productions_adj, zone_attractions_adj = (
        _parse_adjustments(node_adjustments)
    )
    all_node_ids = sorted(set(node_productions) | set(node_attractions))

    # ------------------------------------------------------------------
    # 2. Build Dijkstra graph
    # ------------------------------------------------------------------
    adj, zone_node_ids, zone_centroids_graph = build_graph(network_fc, feedlinks_fc)
    zone_centroids: dict[str, tuple[float, float]] = dict(zone_centroids_graph)
    zone_centroids.update(extract_zone_centroids(zones_fc))

    zone_features: list[dict] = zones_fc.get("features") or []
    zone_ids: list[str] = [
        str(f["properties"]["zoneId"])
        for f in zone_features
        if (f.get("properties") or {}).get("zoneId")
    ]

    # Set of BOUNDARY zone IDs — used for the minimum-distance filter below.
    boundary_zone_ids: set[str] = {
        str((f.get("properties") or {}).get("zoneId") or "")
        for f in zone_features
        if (f.get("properties") or {}).get("zoneClass") == "BOUNDARY"
    } - {""}

    # Per-zone compass headings — used for the U-turn heading filter.
    zone_headings: dict[str, float] = compute_zone_headings(network_fc, feedlinks_fc)

    # Zone pairs that are physically anti-parallel crossings (reverseLinkIds).
    # Routing between these is always a U-turn, regardless of distance/heading.
    zone_reverse_pairs: set[frozenset] = compute_zone_reverse_pairs(network_fc, feedlinks_fc)

    # Reverse-edge map for Yen's spur step: prevents alternative routes from
    # doubling back along a physically parallel reverse road.
    reverse_edge_map = _build_reverse_edge_map(network_fc)

    logger.info(
        "build_od_matrix: %d zones, %d nodes with production, %d with attraction, "
        "%d zones have feedlinks, %d zone-adjustments",
        len(zone_ids),
        len(node_productions),
        len(node_attractions),
        sum(1 for z in zone_ids if z in zone_node_ids),
        len(set(zone_productions_adj) | set(zone_attractions_adj)),
    )

    # ------------------------------------------------------------------
    # 3. Zone flow-based marginals (productions, attractions)
    # ------------------------------------------------------------------
    node_coords = _extract_node_coords(network_fc)
    zone_productions, zone_attractions = _estimate_zone_marginals(
        network_fc, feedlinks_fc, zone_ids
    )

    # ------------------------------------------------------------------
    # 4. Route each node to/from all non-home zones
    # ------------------------------------------------------------------
    od_trips: dict[PairKey, float] = {}
    routes_per_pair: dict[PairKey, list[RouteEntry]] = {}

    for node_id in all_node_ids:
        coords = node_coords.get(node_id)
        home_zones = _find_home_zones(coords, zone_features)

        if not home_zones:
            logger.warning(
                "Node %s is not inside any zone polygon — it will be routed "
                "to/from all zones (no zone excluded).",
                node_id,
            )

        target_zones = [z for z in zone_ids if z not in home_zones and z in zone_node_ids]

        prod_value = node_productions.get(node_id, 0.0)
        attr_value = node_attractions.get(node_id, 0.0)

        n_prod = 0
        n_attr = 0

        # First pass: route all pairs and collect raw zone weights for reachable pairs.
        # We store routes keyed by zone_id so we can normalise weights in a second pass.
        prod_routes_by_zone: dict[str, list[RouteEntry]] = {}
        attr_routes_by_zone: dict[str, list[RouteEntry]] = {}

        for zone_id in target_zones:
            vnode = zone_node_ids[zone_id]

            if prod_value != 0.0 and node_id in adj:
                routes = _yen_k_shortest(adj, node_id, vnode, max_routes, reverse_edge_map)
                if routes:
                    prod_routes_by_zone[zone_id] = routes

            if attr_value != 0.0:
                routes = _yen_k_shortest(adj, vnode, node_id, max_routes, reverse_edge_map)
                if routes:
                    attr_routes_by_zone[zone_id] = routes

        # Second pass: normalise weights so trips sum to prod_value / attr_value.
        # Weight = zone marginal (attraction for production direction, production for
        # attraction direction). Normalising by the total over reachable zones ensures
        # the full delta is distributed regardless of how many zones are unreachable.

        total_attr_weight = sum(zone_attractions.get(z, 0.0) for z in prod_routes_by_zone)
        total_prod_weight = sum(zone_productions.get(z, 0.0) for z in attr_routes_by_zone)

        for zone_id, routes in prod_routes_by_zone.items():
            prod_key: PairKey = (node_id, zone_id, "node", "zone")
            raw = zone_attractions.get(zone_id, 0.0)
            proportion = (raw / total_attr_weight) if total_attr_weight > 0.0 else 0.0
            routes_per_pair[prod_key] = routes
            od_trips[prod_key] = prod_value * proportion
            n_prod += 1

        for zone_id, routes in attr_routes_by_zone.items():
            attr_key: PairKey = (zone_id, node_id, "zone", "node")
            raw = zone_productions.get(zone_id, 0.0)
            proportion = (raw / total_prod_weight) if total_prod_weight > 0.0 else 0.0
            routes_per_pair[attr_key] = routes
            od_trips[attr_key] = attr_value * proportion
            n_attr += 1

        # Tombstones: when production/attraction was explicitly set to 0, emit empty
        # route features for all target zones so that merge_routes removes any existing
        # base routes for this node.
        if prod_value == 0.0 and node_id in node_productions:
            for zone_id in target_zones:
                tombstone_key: PairKey = (node_id, zone_id, "node", "zone")
                routes_per_pair[tombstone_key] = []
                od_trips[tombstone_key] = 0.0
            logger.info("Node %s: emitted %d production tombstones", node_id, len(target_zones))

        if attr_value == 0.0 and node_id in node_attractions:
            for zone_id in target_zones:
                tombstone_key = (zone_id, node_id, "zone", "node")
                routes_per_pair[tombstone_key] = []
                od_trips[tombstone_key] = 0.0
            logger.info("Node %s: emitted %d attraction tombstones", node_id, len(target_zones))

        logger.info(
            "Node %s (home=%s): %d production routes, %d attraction routes",
            node_id,
            sorted(home_zones),
            n_prod,
            n_attr,
        )

    # ------------------------------------------------------------------
    # 4b. Route each adjusted zone to/from all other non-home zones
    # ------------------------------------------------------------------
    all_adjusted_zone_ids = sorted(set(zone_productions_adj) | set(zone_attractions_adj))

    for adj_zone_id in all_adjusted_zone_ids:
        if adj_zone_id not in zone_node_ids:
            logger.warning("Adjusted zone %s has no feedlink virtual node — skipped.", adj_zone_id)
            continue

        vnode = zone_node_ids[adj_zone_id]
        # The adjusted zone is always its own home zone.
        target_zones = [z for z in zone_ids if z != adj_zone_id and z in zone_node_ids]

        prod_value = zone_productions_adj.get(adj_zone_id, 0.0)
        attr_value = zone_attractions_adj.get(adj_zone_id, 0.0)

        prod_routes_by_zone: dict[str, list[RouteEntry]] = {}
        attr_routes_by_zone: dict[str, list[RouteEntry]] = {}

        for target_zone_id in target_zones:
            # Skip BOUNDARY → BOUNDARY pairs where start and end are too close.
            # These represent U-turn routes at reverse boundary crossings of the
            # same road and carry no meaningful traffic demand.
            if adj_zone_id in boundary_zone_ids and target_zone_id in boundary_zone_ids:
                # Hard skip: these zones are each other's physically anti-parallel
                # crossings (reverseLinkIds) — always a U-turn.
                if frozenset({adj_zone_id, target_zone_id}) in zone_reverse_pairs:
                    logger.debug(
                        "Skipping BOUNDARY zone pair %s → %s: reverse link pair (U-turn)",
                        adj_zone_id,
                        target_zone_id,
                    )
                    continue

                # Soft skip: close together AND headings are nearly anti-parallel.
                if min_endpoint_dist_m > 0.0:
                    ac = zone_centroids.get(adj_zone_id)
                    tc = zone_centroids.get(target_zone_id)
                    if (
                        ac
                        and tc
                        and _flat_earth_dist_m(ac[0], ac[1], tc[0], tc[1]) < min_endpoint_dist_m
                    ):
                        h_orig = zone_headings.get(adj_zone_id)
                        h_dest = zone_headings.get(target_zone_id)
                        heading_diff = (
                            _heading_diff(h_orig, h_dest)
                            if h_orig is not None and h_dest is not None
                            else None
                        )
                        if heading_diff is None or heading_diff > max_heading_diff_deg:
                            logger.debug(
                                "Skipping BOUNDARY zone pair %s → %s: dist=%.1f m, "
                                "heading diff=%s° > %.1f°",
                                adj_zone_id,
                                target_zone_id,
                                _flat_earth_dist_m(ac[0], ac[1], tc[0], tc[1]),
                                f"{heading_diff:.1f}" if heading_diff is not None else "n/a",
                                max_heading_diff_deg,
                            )
                            continue

            tvnode = zone_node_ids[target_zone_id]

            if prod_value != 0.0:
                routes = _yen_k_shortest(adj, vnode, tvnode, max_routes, reverse_edge_map)
                if routes:
                    prod_routes_by_zone[target_zone_id] = routes

            if attr_value != 0.0:
                routes = _yen_k_shortest(adj, tvnode, vnode, max_routes, reverse_edge_map)
                if routes:
                    attr_routes_by_zone[target_zone_id] = routes

        total_attr_weight = sum(zone_attractions.get(z, 0.0) for z in prod_routes_by_zone)
        total_prod_weight = sum(zone_productions.get(z, 0.0) for z in attr_routes_by_zone)

        n_prod = 0
        n_attr = 0

        for target_zone_id, routes in prod_routes_by_zone.items():
            prod_key: PairKey = (adj_zone_id, target_zone_id, "zone", "zone")
            raw = zone_attractions.get(target_zone_id, 0.0)
            proportion = (raw / total_attr_weight) if total_attr_weight > 0.0 else 0.0
            routes_per_pair[prod_key] = routes
            od_trips[prod_key] = prod_value * proportion
            n_prod += 1

        for target_zone_id, routes in attr_routes_by_zone.items():
            attr_key: PairKey = (target_zone_id, adj_zone_id, "zone", "zone")
            raw = zone_productions.get(target_zone_id, 0.0)
            proportion = (raw / total_prod_weight) if total_prod_weight > 0.0 else 0.0
            routes_per_pair[attr_key] = routes
            od_trips[attr_key] = attr_value * proportion
            n_attr += 1

        # Tombstones for explicitly zeroed zone production/attraction.
        if prod_value == 0.0 and adj_zone_id in zone_productions_adj:
            for target_zone_id in target_zones:
                tombstone_key = (adj_zone_id, target_zone_id, "zone", "zone")
                routes_per_pair[tombstone_key] = []
                od_trips[tombstone_key] = 0.0
            logger.info("Zone %s: emitted %d production tombstones", adj_zone_id, len(target_zones))

        if attr_value == 0.0 and adj_zone_id in zone_attractions_adj:
            for target_zone_id in target_zones:
                tombstone_key = (target_zone_id, adj_zone_id, "zone", "zone")
                routes_per_pair[tombstone_key] = []
                od_trips[tombstone_key] = 0.0
            logger.info("Zone %s: emitted %d attraction tombstones", adj_zone_id, len(target_zones))

        logger.info(
            "Zone %s (adjusted): %d production routes, %d attraction routes",
            adj_zone_id,
            n_prod,
            n_attr,
        )

    # ------------------------------------------------------------------
    # 5. Serialise
    # ------------------------------------------------------------------
    link_index = _build_link_index(network_fc)
    link_speed_index = _build_link_speed_index(network_fc)
    od_geojson = _build_od_geojson(
        od_trips,
        routes_per_pair,
        node_coords,
        zone_centroids,
        link_index,
        motive,
        target_avg_tt_s,
        ref_speed_kmh,
        link_speed_index,
        zone_productions,
    )

    logger.info("build_od_matrix: %d pairs in output", len(routes_per_pair))
    return od_geojson


# ---------------------------------------------------------------------------
# Re-routing specific OD pairs (used by the adjust pipeline after link changes)
# ---------------------------------------------------------------------------


def recompute_routes_for_pairs(
    network_fc: dict,
    feedlinks_fc: dict,
    zones_fc: dict,
    pairs: list[dict],
    max_routes: int = 3,
    motive: str = "other",
    target_avg_tt_s: float = 1800.0,
    ref_speed_kmh: float | None = 70.0,
) -> dict:
    """Re-route a specific set of OD pairs on an (adjusted) network.

    This is used by the adjust pipeline after link property changes to refresh
    only the routes that pass through affected links, without rerunning the
    full matrix computation.

    Parameters
    ----------
    network_fc:
        Adjusted network GeoJSON FeatureCollection.
    feedlinks_fc:
        Feedlinks GeoJSON FeatureCollection.
    zones_fc:
        Zones GeoJSON FeatureCollection.
    pairs:
        List of pair dicts, each with keys:
        ``"fromId"``, ``"toId"``, ``"fromType"`` (``"node"`` or ``"zone"``),
        ``"toType"``, and ``"tripFraction"`` (original trip count to preserve).
    max_routes:
        Maximum number of alternative routes per pair.

    Returns
    -------
    dict
        GeoJSON FeatureCollection in the same format as ``build_od_matrix``,
        containing one Feature per successfully routed pair.  Unreachable pairs
        are omitted (the caller should keep the original feature in that case).
    """
    from od_support_matrices_creator.core.od_support_matrices_creator_core import (  # noqa: PLC0415
        build_graph,
        extract_zone_centroids,
    )

    adj, zone_node_ids, zone_centroids_graph = build_graph(network_fc, feedlinks_fc)
    zone_centroids: dict[str, tuple[float, float]] = dict(zone_centroids_graph)
    zone_centroids.update(extract_zone_centroids(zones_fc))

    reverse_edge_map = _build_reverse_edge_map(network_fc)
    node_coords = _extract_node_coords(network_fc)
    link_index = _build_link_index(network_fc)

    od_trips: dict[PairKey, float] = {}
    routes_per_pair: dict[PairKey, list[RouteEntry]] = {}

    for pair in pairs:
        from_id = str(pair.get("fromId") or "").strip()
        to_id = str(pair.get("toId") or "").strip()
        from_type = str(pair.get("fromType") or "zone").strip()
        to_type = str(pair.get("toType") or "zone").strip()
        trip_fraction = float(pair.get("tripFraction") or 0.0)

        if not from_id or not to_id:
            continue

        # Resolve graph nodes
        if from_type == "zone":
            from_node = zone_node_ids.get(from_id)
        else:
            from_node = from_id if from_id in adj else None

        if to_type == "zone":
            to_node = zone_node_ids.get(to_id)
        else:
            to_node = to_id

        if from_node is None or to_node is None:
            logger.warning(
                "recompute_routes_for_pairs: cannot resolve graph node for pair "
                "(%s/%s → %s/%s) — skipped.",
                from_id,
                from_type,
                to_id,
                to_type,
            )
            continue

        routes = _yen_k_shortest(adj, from_node, to_node, max_routes, reverse_edge_map)
        if not routes:
            logger.warning(
                "recompute_routes_for_pairs: no route found for pair (%s → %s) — skipped.",
                from_id,
                to_id,
            )
            continue

        pair_key: PairKey = (from_id, to_id, from_type, to_type)
        routes_per_pair[pair_key] = routes
        od_trips[pair_key] = trip_fraction

    od_geojson = _build_od_geojson(
        od_trips,
        routes_per_pair,
        node_coords,
        zone_centroids,
        link_index,
        motive,
        target_avg_tt_s,
        ref_speed_kmh,
        _build_link_speed_index(network_fc),
    )
    logger.info(
        "recompute_routes_for_pairs: %d/%d pairs recomputed", len(routes_per_pair), len(pairs)
    )
    return od_geojson
