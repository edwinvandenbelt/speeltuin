"""compare_networks_core — pure-Python network comparison and bandwidth geometry.

No I/O, no boto3, no external dependencies beyond the standard library.

Public API
----------
compare_networks(fc1, fc2, fields, as_bandwidths, bandwidth_scale)
    -> GeoJSON FeatureCollection
"""

from __future__ import annotations

from compare_networks.domain.comparison import _index_features, _match_props, _merge_fc_properties
from compare_networks.domain.geometry import _bandwidth_features, _single_band_features


def compare_networks(
    fc1: dict,
    fc2: dict,
    fields: list[str],
    as_bandwidths: bool = False,
    bandwidth_scale: float | list[float] = 1.0,
    exclude_unchanged: bool = False,
) -> dict:
    """Compare two GeoJSON FeatureCollections and return a diff FeatureCollection.

    *bandwidth_scale* may be a single float (applied to all fields) or a list
    with one value per entry in *fields*.
    """
    if fc1.get("type") != "FeatureCollection":
        raise ValueError("network1 must be a GeoJSON FeatureCollection.")
    if fc2.get("type") != "FeatureCollection":
        raise ValueError("network2 must be a GeoJSON FeatureCollection.")
    if not isinstance(fields, list) or not fields:
        raise ValueError("fields must be a non-empty list of strings.")

    # Normalise bandwidth_scale to a per-field list.
    if isinstance(bandwidth_scale, (int, float)):
        bandwidth_scales: list[float] = [float(bandwidth_scale)] * len(fields)
    else:
        bandwidth_scales = list(bandwidth_scale)
    if len(bandwidth_scales) != len(fields):
        raise ValueError(
            f"bandwidth_scale must be a single float or a list with one value per field "
            f"(expected {len(fields)}, got {len(bandwidth_scales)})."
        )

    idx1 = _index_features(fc1.get("features") or [])
    idx2 = _index_features(fc2.get("features") or [])

    keys1 = set(idx1)
    keys2 = set(idx2)

    output_features: list[dict] = []

    for key in sorted(keys1 & keys2):
        f1 = idx1[key]
        f2 = idx2[key]
        props = _match_props(f1, f2, fields)

        if exclude_unchanged and all(
            (props.get(f"{field}_delta_plus") or 0.0) == 0.0
            and (props.get(f"{field}_delta_min") or 0.0) == 0.0
            for field in fields
        ):
            continue

        if as_bandwidths:
            output_features.extend(_bandwidth_features(f1, props, fields, bandwidth_scales))
        else:
            output_features.append({
                "type": "Feature",
                "id": key,
                "geometry": f1.get("geometry"),
                "properties": props,
            })

    for key in sorted(keys1 - keys2):
        f = idx1[key]
        props = dict(f.get("properties") or {})
        props["matchType"] = "removed"
        if as_bandwidths:
            output_features.extend(
                _single_band_features(f, props, fields, bandwidth_scales, "reduction")
            )
        else:
            output_features.append({
                "type": "Feature",
                "id": key,
                "geometry": f.get("geometry"),
                "properties": props,
            })

    for key in sorted(keys2 - keys1):
        f = idx2[key]
        props = dict(f.get("properties") or {})
        props["matchType"] = "added"
        if as_bandwidths:
            output_features.extend(
                _single_band_features(f, props, fields, bandwidth_scales, "increase")
            )
        else:
            output_features.append({
                "type": "Feature",
                "id": key,
                "geometry": f.get("geometry"),
                "properties": props,
            })

    return {"type": "FeatureCollection", "features": output_features, "properties": _merge_fc_properties(fc1, fc2)}
