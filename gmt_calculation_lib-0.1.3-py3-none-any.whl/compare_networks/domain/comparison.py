"""Feature indexing and field-comparison helpers for compare_networks."""

from __future__ import annotations

from typing import Any


def _segment_id(feature: dict) -> str | None:
    """Return the link key for a feature, or None if not found."""
    props = feature.get("properties") or {}
    for key in ("linkId", "segmentId"):
        val = props.get(key)
        if val is not None:
            return str(val)
    fid = feature.get("id")
    if fid is not None:
        return str(fid)
    return None


def _index_features(features: list[dict]) -> dict[str, dict]:
    """Return a {linkId: feature} mapping, skipping features without an ID."""
    idx: dict[str, dict] = {}
    for f in features:
        key = _segment_id(f)
        if key is not None:
            idx[key] = f
    return idx


def _merge_fc_properties(fc1: dict, fc2: dict) -> dict:
    """Merge the root-level ``properties`` of two FeatureCollections.

    Attributes that are equal in both collections are hoisted to the top of the
    returned dict.  The two original ``properties`` objects are also included
    under the keys ``"network1"`` and ``"network2"``.

    Example output::

        {
            "sharedKey": "sharedValue",   # equal in both → hoisted
            "network1": {"sharedKey": "sharedValue", "onlyInN1": ...},
            "network2": {"sharedKey": "sharedValue", "onlyInN2": ...},
        }
    """
    p1: dict = fc1.get("properties") or {}
    p2: dict = fc2.get("properties") or {}

    shared = {k: v for k, v in p1.items() if k in p2 and p2[k] == v}

    return {
        **shared,
        "network1": dict(p1),
        "network2": dict(p2),
    }


def _match_props(f1: dict, f2: dict, fields: list[str]) -> dict:
    """Build the properties dict for a matched pair.

    For each numeric field in *fields* the following derived properties are added
    (only when the values differ):
      {field}_min        — unchanged floor: min(v1, v2)
      {field}_delta_plus — growth only:     max(0, v2 − v1)
      {field}_delta_min  — reduction only:  max(0, v1 − v2)
      {field}            — recalculated:    _min + _delta_plus

    When v1 == v2 for a field, no derived properties are emitted for it.

    All other properties that appear in either feature are also included,
    always taking the value from the first network.
    """
    p1 = f1.get("properties") or {}
    p2 = f2.get("properties") or {}
    field_set = set(fields)

    props: dict[str, Any] = {"matchType": "match"}

    # Non-compared properties: always take the value from the first network.
    for key in sorted(set(p1) | set(p2)):
        if key in field_set:
            continue  # handled below
        props[key] = p1.get(key)

    # Compared fields: compute deltas.
    for field in fields:
        v1 = p1.get(field)
        v2 = p2.get(field)
        if isinstance(v1, (int, float)) and isinstance(v2, (int, float)):
            if float(v1) == float(v2):
                # Values are identical — omit all derived properties for this field.
                pass
            else:
                f_min        = min(float(v1), float(v2))
                f_delta_plus = max(0.0, float(v2) - float(v1))
                f_delta_min  = max(0.0, float(v1) - float(v2))
                props[f"{field}_min"]        = f_min
                props[f"{field}_delta_plus"] = f_delta_plus
                props[f"{field}_delta_min"]  = f_delta_min
                props[field]                 = f_min + f_delta_plus
        else:
            props[f"{field}_min"]        = None
            props[f"{field}_delta_plus"] = None
            props[f"{field}_delta_min"]  = None

    return props
