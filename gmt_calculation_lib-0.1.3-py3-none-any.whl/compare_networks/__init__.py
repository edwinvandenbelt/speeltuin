"""compare_networks — diff two GeoJSON networks by linkId."""
