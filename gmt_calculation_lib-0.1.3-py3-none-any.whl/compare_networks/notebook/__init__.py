"""compare_networks notebook package."""
