"""Pure-Python parquet_exporter core — no I/O, no boto3, no external deps.

Converts an in-memory GeoJSON FeatureCollection dict to a UTF-8 string in
either GeoJSON or GeoJSONL format.

Public API
----------
export_to_geojson(fc) -> str
    Serialise a FeatureCollection to a single GeoJSON string.

export_to_geojsonl(fc, *, include_metadata) -> str
    Serialise a FeatureCollection to GeoJSONL (one Feature per line).
    When *include_metadata* is True a header line carrying the
    FeatureCollection-level ``properties`` dict is prepended.
"""

from __future__ import annotations

import json
import logging

logger = logging.getLogger(__name__)


def export_to_geojson(fc: dict) -> str:
    """Serialise *fc* to a GeoJSON FeatureCollection string.

    Parameters
    ----------
    fc:
        A plain-Python GeoJSON FeatureCollection dict.

    Returns
    -------
    str
        A UTF-8–safe JSON string representing the FeatureCollection.
    """
    return json.dumps(fc, ensure_ascii=False)


def export_to_geojsonl(fc: dict, *, include_metadata: bool = False) -> str:
    """Serialise *fc* to GeoJSONL (newline-delimited JSON).

    Each Feature is written as one JSON object on its own line.  When
    *include_metadata* is ``True`` a header line is prepended:

    .. code-block:: json

        {"type": "FeatureCollection", "properties": { ... }}

    This header carries the FeatureCollection-level ``properties`` dict so
    that downstream consumers can reconstruct the full context.

    Parameters
    ----------
    fc:
        A plain-Python GeoJSON FeatureCollection dict.
    include_metadata:
        When ``True``, prepend the FeatureCollection metadata header line.

    Returns
    -------
    str
        A newline-delimited string.  Empty string when *fc* has no features
        and *include_metadata* is ``False``.
    """
    lines: list[str] = []

    if include_metadata:
        header = {
            "type": "FeatureCollection",
            "properties": fc.get("properties") or {},
        }
        lines.append(json.dumps(header, ensure_ascii=False))

    for feature in fc.get("features") or []:
        lines.append(json.dumps(feature, ensure_ascii=False))

    return "\n".join(lines)
