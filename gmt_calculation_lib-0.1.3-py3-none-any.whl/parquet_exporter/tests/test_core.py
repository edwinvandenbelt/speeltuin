"""Tests for parquet_exporter_core — export_to_geojson and export_to_geojsonl."""

from __future__ import annotations

import json

import pytest

from parquet_exporter.core.parquet_exporter_core import export_to_geojson, export_to_geojsonl


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_fc(
    features: list[dict] | None = None,
    properties: dict | None = None,
) -> dict:
    fc: dict = {"type": "FeatureCollection", "features": features or []}
    if properties is not None:
        fc["properties"] = properties
    return fc


def _make_feature(props: dict, geom: dict | None = None) -> dict:
    return {
        "type": "Feature",
        "geometry": geom,
        "properties": props,
    }


# ---------------------------------------------------------------------------
# export_to_geojson
# ---------------------------------------------------------------------------

class TestExportToGeoJson:
    def test_returns_valid_json_string(self):
        fc = _make_fc([_make_feature({"speed": 80})])
        result = export_to_geojson(fc)
        assert isinstance(result, str)
        parsed = json.loads(result)
        assert parsed["type"] == "FeatureCollection"

    def test_round_trip_preserves_features(self):
        features = [
            _make_feature({"id": 1, "speed": 80}),
            _make_feature({"id": 2, "speed": 60}),
        ]
        fc = _make_fc(features)
        result = json.loads(export_to_geojson(fc))
        assert len(result["features"]) == 2
        assert result["features"][0]["properties"]["id"] == 1

    def test_preserves_fc_level_properties(self):
        fc = _make_fc(
            [_make_feature({"x": 1})],
            properties={"areaId": "abc-123", "mode": "CAR"},
        )
        result = json.loads(export_to_geojson(fc))
        assert result["properties"]["areaId"] == "abc-123"
        assert result["properties"]["mode"] == "CAR"

    def test_preserves_non_ascii_characters(self):
        fc = _make_fc([_make_feature({"name": "Björk Straat"})])
        result = export_to_geojson(fc)
        # ensure_ascii=False means the character is written literally
        assert "Björk Straat" in result
        assert "\\u00f6" not in result  # must NOT be escaped

    def test_empty_feature_collection(self):
        fc = _make_fc()
        result = json.loads(export_to_geojson(fc))
        assert result["features"] == []

    def test_preserves_geometry(self):
        geom = {"type": "LineString", "coordinates": [[4.9, 52.3], [4.91, 52.31]]}
        fc = _make_fc([_make_feature({"id": 1}, geom=geom)])
        result = json.loads(export_to_geojson(fc))
        assert result["features"][0]["geometry"] == geom

    def test_null_properties_remain_null(self):
        fc = _make_fc([_make_feature({"speed": None, "name": "A1"})])
        result = json.loads(export_to_geojson(fc))
        assert result["features"][0]["properties"]["speed"] is None


# ---------------------------------------------------------------------------
# export_to_geojsonl
# ---------------------------------------------------------------------------

class TestExportToGeoJsonL:
    def test_one_line_per_feature_no_metadata(self):
        fc = _make_fc([
            _make_feature({"id": 1}),
            _make_feature({"id": 2}),
            _make_feature({"id": 3}),
        ])
        result = export_to_geojsonl(fc)
        lines = result.splitlines()
        assert len(lines) == 3

    def test_each_line_is_valid_json(self):
        fc = _make_fc([_make_feature({"x": i}) for i in range(5)])
        result = export_to_geojsonl(fc)
        for line in result.splitlines():
            parsed = json.loads(line)
            assert parsed["type"] == "Feature"

    def test_with_metadata_prepends_header_line(self):
        fc = _make_fc(
            [_make_feature({"id": 1}), _make_feature({"id": 2})],
            properties={"areaId": "xyz"},
        )
        result = export_to_geojsonl(fc, include_metadata=True)
        lines = result.splitlines()
        # First line is the metadata header; 2 more lines for the features.
        assert len(lines) == 3
        header = json.loads(lines[0])
        assert header["type"] == "FeatureCollection"
        assert header["properties"]["areaId"] == "xyz"

    def test_with_metadata_features_remain_on_their_own_lines(self):
        fc = _make_fc(
            [_make_feature({"id": 1}), _make_feature({"id": 2})],
            properties={"mode": "CAR"},
        )
        result = export_to_geojsonl(fc, include_metadata=True)
        lines = result.splitlines()
        feature_lines = lines[1:]
        ids = [json.loads(ln)["properties"]["id"] for ln in feature_lines]
        assert ids == [1, 2]

    def test_empty_fc_no_metadata_returns_empty_string(self):
        fc = _make_fc()
        result = export_to_geojsonl(fc)
        assert result == ""

    def test_empty_fc_with_metadata_returns_header_only(self):
        fc = _make_fc(properties={"mode": "BIKE"})
        result = export_to_geojsonl(fc, include_metadata=True)
        lines = result.splitlines()
        assert len(lines) == 1
        header = json.loads(lines[0])
        assert header["type"] == "FeatureCollection"
        assert header["properties"]["mode"] == "BIKE"

    def test_metadata_missing_fc_properties_uses_empty_dict(self):
        # FC has no "properties" key at all.
        fc = {"type": "FeatureCollection", "features": [_make_feature({"x": 1})]}
        result = export_to_geojsonl(fc, include_metadata=True)
        header = json.loads(result.splitlines()[0])
        assert header["properties"] == {}

    def test_no_trailing_newline(self):
        fc = _make_fc([_make_feature({"id": 1})])
        result = export_to_geojsonl(fc)
        assert not result.endswith("\n")

    def test_preserves_non_ascii_in_properties(self):
        fc = _make_fc([_make_feature({"name": "Römerstraße"})])
        result = export_to_geojsonl(fc)
        assert "Römerstraße" in result

    def test_default_include_metadata_is_false(self):
        fc = _make_fc(
            [_make_feature({"id": 1})],
            properties={"mode": "CAR"},
        )
        result_default = export_to_geojsonl(fc)
        result_explicit = export_to_geojsonl(fc, include_metadata=False)
        assert result_default == result_explicit
        assert len(result_default.splitlines()) == 1


# ---------------------------------------------------------------------------
# _correct_extension — tested via the runner module (import directly)
# ---------------------------------------------------------------------------

class TestCorrectExtension:
    """Import the private helper directly to test edge cases."""

    @pytest.fixture(autouse=True)
    def _import(self):
        from parquet_exporter.parquet_exporter_runner import _correct_extension  # noqa: PLC0415
        self.fn = _correct_extension

    def test_matching_extension_unchanged(self):
        assert self.fn("output/file.geojson", "geojson") == "output/file.geojson"

    def test_matching_geojsonl_unchanged(self):
        assert self.fn("output/file.geojsonl", "geojsonl") == "output/file.geojsonl"

    def test_mismatched_extension_corrected(self, capsys):
        result = self.fn("output/file.parquet", "geojson")
        assert result == "output/file.geojson"
        captured = capsys.readouterr()
        assert "warn" in captured.err.lower()

    def test_s3_uri_extension_corrected(self, capsys):
        result = self.fn("s3://bucket/path/file.parquet", "geojsonl")
        assert result == "s3://bucket/path/file.geojsonl"
        captured = capsys.readouterr()
        assert "warn" in captured.err.lower()

    def test_case_insensitive_extension_check(self):
        # .GEOJSON (upper-case) should not trigger a rename for format=geojson
        result = self.fn("output/file.GEOJSON", "geojson")
        assert result == "output/file.GEOJSON"
