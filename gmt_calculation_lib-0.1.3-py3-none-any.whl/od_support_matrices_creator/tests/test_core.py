"""Unit tests for od_support_matrices_creator_core and graph_utils.dijkstra_od."""

from __future__ import annotations

import csv
import io
import json
import math
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from shared.graph_utils import dijkstra_od
from od_support_matrices_creator.core.od_support_matrices_creator_core import (
    MATRIX_PROPERTIES,
    build_graph,
    compute_matrix,
    enrich_od_geojson,
    extract_zone_centroids,
    extract_zone_ids,
    records_to_csv,
    records_to_geojson,
)

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _net_feature(from_node, to_node, speed, length, capacity, flows_per_daypart=None):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "fromNode": from_node,
            "toNode": to_node,
            "speed": speed,
            "length": length,
            "capacity": capacity,
            "flowsPerDaypart": flows_per_daypart or {},
        },
    }


def _feedlink_feature(zone_id, network_node_id, direction, length, capacity=1000.0):
    """Build a feedlink feature using the new schema (fromNode/toNode/length/capacity).

    direction: ``"production"``  -> fromNode = fake zone node (not in network),
                                     toNode  = network_node_id
               ``"attraction"``  -> fromNode = network_node_id,
                                     toNode  = fake zone node
               ``None``          -> treated as production
    """
    fake_zone_node = f"gid{zone_id}"  # not present in any network link
    network_node_id = str(network_node_id)
    if direction == "attraction":
        from_node, to_node = network_node_id, fake_zone_node
    else:
        from_node, to_node = fake_zone_node, network_node_id
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "feedlinkId": 1,
            "zoneId": zone_id,
            "fromNode": from_node,
            "toNode": to_node,
            "length": length,
            "capacity": capacity,
            "type": "feedlink",
        },
    }


def _zone_feature(zone_id, lon, lat):
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [lon, lat]},
        "properties": {
            "zoneId": zone_id,
            "centroidLon": lon,
            "centroidLat": lat,
        },
    }


# ---------------------------------------------------------------------------
# dijkstra_od — graph_utils
# ---------------------------------------------------------------------------


class TestDijkstraOd:
    def test_empty_graph(self):
        t, d, r = dijkstra_od({}, "A")
        assert t == {"A": 0.0}
        assert d == {"A": 0.0}
        assert r == {"A": float("inf")}

    def test_single_edge(self):
        adj = {"A": [("B", 10.0, 200.0, 500.0, 500.0)]}
        t, d, r = dijkstra_od(adj, "A")
        assert t["A"] == 0.0
        assert t["B"] == pytest.approx(10.0)
        assert d["B"] == pytest.approx(200.0)
        assert r["B"] == pytest.approx(500.0)

    def test_two_edges_sequential(self):
        adj = {
            "A": [("B", 5.0, 100.0, 800.0, 800.0)],
            "B": [("C", 3.0, 60.0, 300.0, 300.0)],
        }
        t, d, r = dijkstra_od(adj, "A")
        assert t["C"] == pytest.approx(8.0)
        assert d["C"] == pytest.approx(160.0)
        # resistance = min(800, 300) = 300
        assert r["C"] == pytest.approx(300.0)

    def test_shortest_path_chosen(self):
        # A->B direct (time=10) vs A->C->B (time=3+3=6)
        adj = {
            "A": [("B", 10.0, 500.0, 1000.0, 1000.0), ("C", 3.0, 100.0, 900.0, 900.0)],
            "C": [("B", 3.0, 100.0, 400.0, 400.0)],
        }
        t, d, r = dijkstra_od(adj, "A")
        assert t["B"] == pytest.approx(6.0)  # via C
        assert d["B"] == pytest.approx(200.0)  # via C
        assert r["B"] == pytest.approx(400.0)  # min(900, 400)

    def test_resistance_bottleneck(self):
        # Three-link path — resistance = min capacity
        adj = {
            "A": [("B", 1.0, 10.0, 600.0, 600.0)],
            "B": [("C", 1.0, 10.0, 200.0, 200.0)],
            "C": [("D", 1.0, 10.0, 800.0, 800.0)],
        }
        t, d, r = dijkstra_od(adj, "A")
        assert r["D"] == pytest.approx(200.0)

    def test_unreachable_node_absent(self):
        adj = {"A": [("B", 1.0, 10.0, 100.0, 100.0)]}
        t, d, r = dijkstra_od(adj, "A")
        assert "C" not in t
        assert "C" not in d
        assert "C" not in r

    def test_seed_has_zero_values(self):
        adj = {"A": [("B", 5.0, 50.0, 300.0, 300.0)]}
        t, d, r = dijkstra_od(adj, "A")
        assert t["A"] == 0.0
        assert d["A"] == 0.0
        assert r["A"] == float("inf")


# ---------------------------------------------------------------------------
# build_graph
# ---------------------------------------------------------------------------


class TestBuildGraph:
    def _make_fcs(self):
        network_fc = {
            "type": "FeatureCollection",
            "features": [
                # 1 -> 2, speed=60 km/h, length=600m, cap=1200, peak_flow=200
                _net_feature(1, 2, 60.0, 600.0, 1200.0, {"mrh": 200.0, "erh": 100.0}),
                # 2 -> 3, speed=30 km/h, length=300m, cap=600, no flow
                _net_feature(2, 3, 30.0, 300.0, 600.0),
            ],
        }
        feedlinks_fc = {
            "type": "FeatureCollection",
            "features": [
                # Zone A: production feedlink to node 1
                _feedlink_feature("A", 1, "production", 100.0, 900.0),
                # Zone B: attraction feedlink from node 3
                _feedlink_feature("B", 3, "attraction", 50.0, 500.0),
            ],
        }
        return network_fc, feedlinks_fc

    def test_network_edges_present(self):
        net, fl = self._make_fcs()
        adj, _, _ = build_graph(net, fl)
        assert "1" in adj
        neighbours = [n for n, *_ in adj["1"]]
        assert "2" in neighbours

    def test_travel_time_correct(self):
        net, fl = self._make_fcs()
        adj, _, _ = build_graph(net, fl)
        # 1->2: 600m at 60 km/h, peak=200, cap=1200 -> v/c=1/6
        # t0=36s, BPR = 1 + 0.15*(1/6)^4 = 1.0001157 -> t_bpr ≈ 36.004s
        t0 = 600.0 / (60.0 / 3.6)
        vc = 200.0 / 1200.0
        expected = t0 * (1.0 + 0.15 * vc**4)
        edge = next(e for e in adj["1"] if e[0] == "2")
        assert edge[1] == pytest.approx(expected)

    def test_remaining_capacity_correct(self):
        net, fl = self._make_fcs()
        adj, _, _ = build_graph(net, fl)
        # 1->2: capacity=1200, peak=200 -> remaining=1000
        edge = next(e for e in adj["1"] if e[0] == "2")
        assert edge[3] == pytest.approx(1000.0)

    def test_feedlink_production_edge(self):
        net, fl = self._make_fcs()
        adj, zone_nodes, _ = build_graph(net, fl)
        vnode_a = zone_nodes["A"]
        assert vnode_a in adj
        neighbours = [n for n, *_ in adj[vnode_a]]
        assert "1" in neighbours

    def test_feedlink_attraction_edge(self):
        net, fl = self._make_fcs()
        adj, zone_nodes, _ = build_graph(net, fl)
        vnode_b = zone_nodes["B"]
        # attraction: node 3 -> zone B
        assert "3" in adj
        neighbours = [n for n, *_ in adj["3"]]
        assert vnode_b in neighbours

    def test_feedlink_speed_from_network(self):
        """Feedlink speed must come from the max speed of connected network links."""
        net, fl = self._make_fcs()
        adj, zone_nodes, _ = build_graph(net, fl)
        vnode_a = zone_nodes["A"]
        edge = next(e for e in adj[vnode_a] if e[0] == "1")
        # Node 1 connects to link 1->2 with speed 60 km/h
        # time = 100m / (60/3.6) = 6s
        assert edge[1] == pytest.approx(6.0)

    def test_null_direction_bidirectional(self):
        """Two feedlinks (one production, one attraction) cover both directions."""
        net_fc = {
            "type": "FeatureCollection",
            "features": [
                _net_feature(10, 20, 50.0, 500.0, 1000.0),
            ],
        }
        fl_fc = {
            "type": "FeatureCollection",
            "features": [
                _feedlink_feature("Z", 10, "production", 80.0, 800.0),
                _feedlink_feature("Z", 10, "attraction", 80.0, 600.0),
            ],
        }
        adj, zone_nodes, _ = build_graph(net_fc, fl_fc)
        vz = zone_nodes["Z"]
        # production: Z -> 10
        assert any(e[0] == "10" for e in adj.get(vz, []))
        # attraction: 10 -> Z
        assert any(e[0] == vz for e in adj.get("10", []))

    def test_bpr_flow_increases_travel_time(self):
        """BPR: a link with peak flow > 0 must have higher travel time than free-flow."""

        # speed=36 km/h, length=360m -> t0 = 360 / (36/3.6) = 36s
        # capacity=200, peak_flow=100 -> v/c=0.5 -> t_bpr = 36 * (1 + 0.15*0.5^4) ≈ 36.3375s
        def _feature_with_peak(peak):
            return _net_feature(1, 2, 36.0, 360.0, 200.0, {"mrh": peak} if peak > 0 else {})

        fl_fc = {"type": "FeatureCollection", "features": []}
        adj_free, _, _ = build_graph(
            {"type": "FeatureCollection", "features": [_feature_with_peak(0.0)]}, fl_fc
        )
        adj_loaded, _, _ = build_graph(
            {"type": "FeatureCollection", "features": [_feature_with_peak(100.0)]}, fl_fc
        )
        t_free = next(e[1] for e in adj_free["1"] if e[0] == "2")
        t_loaded = next(e[1] for e in adj_loaded["1"] if e[0] == "2")
        expected = 36.0 * (1.0 + 0.15 * (100.0 / 200.0) ** 4)
        assert t_free == pytest.approx(36.0)
        assert t_loaded == pytest.approx(expected)
        assert t_loaded > t_free

    def test_saturated_link_gets_bpr_capped_cost(self):
        """A saturated link (flow >= capacity) must NOT be closed.

        All-or-nothing assignment concentrates flow on bottleneck links,
        easily pushing v/c >> 1.  Treating those links as impassable causes
        Dijkstra to route around the only available crossing (e.g. a bridge).
        Instead the v/c ratio is capped at _BPR_VC_CAP (2.0), giving a finite
        but expensive travel time: t0 × (1 + 0.15 × 2⁴) ≈ t0 × 3.4.
        """
        # capacity=100, peak_flow=100 → v/c=1.0 → t = t0 × 1.15
        net_fc = {
            "type": "FeatureCollection",
            "features": [
                _net_feature(1, 2, 60.0, 600.0, 100.0, {"mrh": 100.0}),
            ],
        }
        fl_fc = {"type": "FeatureCollection", "features": []}
        adj, _, _ = build_graph(net_fc, fl_fc)
        edge = next(e for e in adj["1"] if e[0] == "2")
        t0 = 600.0 / (60.0 / 3.6)  # 36 s
        assert edge[1] == pytest.approx(t0 * (1 + 0.15 * 1.0**4), rel=1e-6)
        assert edge[1] != float("inf")

    def test_over_saturated_link_capped_at_bpr_vc_cap(self):
        """A link with v/c >> 1 is capped at _BPR_VC_CAP (2.0)."""
        # capacity=100, peak_flow=500 → v/c=5 → capped at 2 → t = t0 × (1+0.15×16) = t0 × 3.4
        net_fc = {
            "type": "FeatureCollection",
            "features": [
                _net_feature(1, 2, 60.0, 600.0, 100.0, {"mrh": 500.0}),
            ],
        }
        fl_fc = {"type": "FeatureCollection", "features": []}
        adj, _, _ = build_graph(net_fc, fl_fc)
        edge = next(e for e in adj["1"] if e[0] == "2")
        t0 = 600.0 / (60.0 / 3.6)  # 36 s
        assert edge[1] == pytest.approx(t0 * (1 + 0.15 * 2.0**4), rel=1e-6)
        assert edge[1] != float("inf")

    def test_zero_capacity_link_uses_free_flow(self):
        """A link with capacity=0 is treated as impassable (time_s = inf)."""
        net_fc = {
            "type": "FeatureCollection",
            "features": [
                _net_feature(1, 2, 60.0, 600.0, 0.0),
            ],
        }
        fl_fc = {"type": "FeatureCollection", "features": []}
        adj, _, _ = build_graph(net_fc, fl_fc)
        edge = next(e for e in adj["1"] if e[0] == "2")
        assert edge[1] == float("inf")

    def test_signal_delay_added_for_traffic_signal_links(self):
        """Links with trafficSignal=True get a Webster delay on top of BPR time."""
        # capacity=200, no flow → v/c=0 → BPR = t0; signal_delay = 15 / (1-0) = 15s
        feat = _net_feature(1, 2, 60.0, 600.0, 200.0)
        feat["properties"]["trafficSignal"] = True
        net_fc = {"type": "FeatureCollection", "features": [feat]}
        fl_fc = {"type": "FeatureCollection", "features": []}
        adj_no_sig, _, _ = build_graph(net_fc, fl_fc, signal_base_delay_s=0.0)
        adj_sig, _, _ = build_graph(net_fc, fl_fc, signal_base_delay_s=15.0)
        t0 = 600.0 / (60.0 / 3.6)  # 36 s free-flow
        edge_no = next(e for e in adj_no_sig["1"] if e[0] == "2")
        edge_sig = next(e for e in adj_sig["1"] if e[0] == "2")
        assert edge_no[1] == pytest.approx(t0, rel=1e-6)
        assert edge_sig[1] == pytest.approx(t0 + 15.0, rel=1e-6)

    def test_signal_delay_not_added_when_traffic_signal_false(self):
        """Links with trafficSignal=False do not get a Webster delay."""
        feat = _net_feature(1, 2, 60.0, 600.0, 200.0)
        feat["properties"]["trafficSignal"] = False
        net_fc = {"type": "FeatureCollection", "features": [feat]}
        fl_fc = {"type": "FeatureCollection", "features": []}
        adj, _, _ = build_graph(net_fc, fl_fc, signal_base_delay_s=15.0)
        edge = next(e for e in adj["1"] if e[0] == "2")
        t0 = 600.0 / (60.0 / 3.6)
        assert edge[1] == pytest.approx(t0, rel=1e-6)

    def test_signal_delay_grows_with_congestion(self):
        """The Webster delay term grows as v/c approaches saturation."""
        # v/c = 0.5 → signal_delay = 15 / (1 - 0.5) = 30s
        feat = _net_feature(1, 2, 60.0, 600.0, 200.0, {"mrh": 100.0})  # 100/200 = 0.5
        feat["properties"]["trafficSignal"] = True
        net_fc = {"type": "FeatureCollection", "features": [feat]}
        fl_fc = {"type": "FeatureCollection", "features": []}
        adj, _, _ = build_graph(net_fc, fl_fc, signal_base_delay_s=15.0)
        edge = next(e for e in adj["1"] if e[0] == "2")
        t0 = 600.0 / (60.0 / 3.6)
        v_over_c = 0.5
        bpr_time = t0 * (1.0 + 0.15 * v_over_c**4)
        expected = bpr_time + 15.0 / (1.0 - 0.5)
        assert edge[1] == pytest.approx(expected, rel=1e-6)


# ---------------------------------------------------------------------------
# compute_matrix
# ---------------------------------------------------------------------------


class TestComputeMatrix:
    def _build(self):
        """3 zones: A, B, C in a chain: A->1->2->3<-B, C isolated."""
        net_fc = {
            "type": "FeatureCollection",
            "features": [
                _net_feature(1, 2, 36.0, 360.0, 720.0, {"mrh": 20.0}),  # 36s, 360m, cap=700
                _net_feature(2, 3, 36.0, 360.0, 720.0, {"mrh": 20.0}),  # 36s, 360m, cap=700
            ],
        }
        fl_fc = {
            "type": "FeatureCollection",
            "features": [
                _feedlink_feature("A", 1, "production", 36.0, 500.0),  # 3.6s
                _feedlink_feature("B", 3, "attraction", 36.0, 500.0),  # 3.6s
            ],
        }
        adj, zone_nodes, _ = build_graph(net_fc, fl_fc)
        centroids = {"A": (6.0, 52.0), "B": (6.1, 52.1)}
        return adj, zone_nodes, centroids

    def test_diagonal_zeros(self):
        adj, zone_nodes, centroids = self._build()
        records = compute_matrix(["A", "B", "C"], zone_nodes, centroids, adj)
        diag = [r for r in records if r["fromZoneId"] == r["toZoneId"]]
        assert len(diag) == 3
        for r in diag:
            assert r["travelTime"] == 0.0
            assert r["distance"] == 0.0
            assert r["remainingCap"] == 0.0

    def test_unreachable_null(self):
        adj, zone_nodes, centroids = self._build()
        # A->B: A has only production, B has only attraction -> reachable via network
        # C has no feedlink -> all C rows/cols null (except diagonal)
        records = compute_matrix(["A", "B", "C"], zone_nodes, centroids, adj)
        c_rows = [r for r in records if r["fromZoneId"] == "C" and r["toZoneId"] != "C"]
        assert all(r["travelTime"] is None for r in c_rows)

    def test_a_to_b_reachable(self):
        adj, zone_nodes, centroids = self._build()
        records = compute_matrix(["A", "B"], zone_nodes, centroids, adj)
        ab = next(r for r in records if r["fromZoneId"] == "A" and r["toZoneId"] == "B")
        # A->1 feedlink: 36m/(36km/h/3.6) = 3.6s; 1->2: 36s; 2->3: 36s; 3->B feedlink: 3.6s
        # Total time ~79.2s
        assert ab["travelTime"] is not None
        assert ab["travelTime"] == pytest.approx(79.2, rel=1e-3)
        assert ab["distance"] is not None
        # feedlink 36m + 360m + 360m + feedlink 36m = 792m
        assert ab["distance"] == pytest.approx(792.0, rel=1e-3)
        # resistance = min(500, 700, 700, 500) = 500
        assert ab["remainingCap"] == pytest.approx(500.0)
        adj, zone_nodes, centroids = self._build()
        records = compute_matrix(["A", "B", "C"], zone_nodes, centroids, adj)
        assert len(records) == 9  # 3x3


# ---------------------------------------------------------------------------
# records_to_csv
# ---------------------------------------------------------------------------


class TestRecordsToCsv:
    def _records(self):
        return [
            {
                "fromZoneId": "A",
                "toZoneId": "A",
                "travelTime": 0.0,
                "distance": 0.0,
                "remainingCap": 0.0,
            },
            {
                "fromZoneId": "A",
                "toZoneId": "B",
                "travelTime": 120.5,
                "distance": 1500.0,
                "remainingCap": 300.0,
            },
            {
                "fromZoneId": "A",
                "toZoneId": "C",
                "travelTime": None,
                "distance": None,
                "remainingCap": None,
            },
        ]

    def test_header(self):
        text = records_to_csv(self._records())
        reader = csv.reader(io.StringIO(text))
        header = next(reader)
        assert header == list(MATRIX_PROPERTIES)

    def test_null_rows_empty_cells(self):
        text = records_to_csv(self._records())
        rows = list(csv.reader(io.StringIO(text)))
        null_row = rows[3]  # A->C
        assert null_row[2] == ""
        assert null_row[3] == ""
        assert null_row[4] == ""

    def test_value_rows(self):
        text = records_to_csv(self._records())
        rows = list(csv.reader(io.StringIO(text)))
        ab_row = rows[2]
        assert ab_row[0] == "A"
        assert ab_row[1] == "B"
        assert float(ab_row[2]) == pytest.approx(120.5)


# ---------------------------------------------------------------------------
# records_to_geojson
# ---------------------------------------------------------------------------


class TestRecordsToGeojson:
    def _records(self):
        return [
            {
                "fromZoneId": "A",
                "toZoneId": "B",
                "travelTime": 60.0,
                "distance": 800.0,
                "remainingCap": 400.0,
            },
            {
                "fromZoneId": "A",
                "toZoneId": "C",
                "travelTime": None,
                "distance": None,
                "remainingCap": None,
            },
        ]

    def _centroids(self):
        return {"A": (6.0, 52.0), "B": (6.1, 52.1)}

    def test_feature_count(self):
        fc = records_to_geojson(self._records(), self._centroids())
        assert fc["type"] == "FeatureCollection"
        assert len(fc["features"]) == 2

    def test_geometry_linestring(self):
        fc = records_to_geojson(self._records(), self._centroids())
        ab = fc["features"][0]
        assert ab["geometry"]["type"] == "LineString"
        assert ab["geometry"]["coordinates"][0] == [6.0, 52.0]
        assert ab["geometry"]["coordinates"][1] == [6.1, 52.1]

    def test_unknown_centroid_null_geometry(self):
        fc = records_to_geojson(self._records(), self._centroids())
        ac = fc["features"][1]
        assert ac["geometry"] is None

    def test_properties_present(self):
        fc = records_to_geojson(self._records(), self._centroids())
        ab = fc["features"][0]
        assert ab["properties"]["travelTime"] == pytest.approx(60.0)
        assert ab["properties"]["distance"] == pytest.approx(800.0)
        assert ab["properties"]["remainingCap"] == pytest.approx(400.0)

    def test_null_properties_preserved(self):
        fc = records_to_geojson(self._records(), self._centroids())
        ac = fc["features"][1]
        assert ac["properties"]["travelTime"] is None
        assert ac["properties"]["remainingCap"] is None

    def test_fc_properties_link_properties(self):
        fc = records_to_geojson(self._records(), self._centroids())
        assert "fields" in fc["properties"]
        assert list(MATRIX_PROPERTIES) == fc["properties"]["fields"]


# ---------------------------------------------------------------------------
# extract_zone_centroids / extract_zone_ids
# ---------------------------------------------------------------------------


class TestExtractHelpers:
    def _zones_fc(self):
        return {
            "type": "FeatureCollection",
            "features": [
                _zone_feature("Z1", 6.0, 52.0),
                _zone_feature("Z2", 6.1, 52.1),
            ],
        }

    def test_extract_centroids(self):
        centroids = extract_zone_centroids(self._zones_fc())
        assert centroids["Z1"] == pytest.approx((6.0, 52.0))
        assert centroids["Z2"] == pytest.approx((6.1, 52.1))

    def test_extract_zone_ids_order(self):
        ids = extract_zone_ids(self._zones_fc())
        assert ids == ["Z1", "Z2"]

    def test_centroid_fallback_from_geometry(self):
        """When centroidLon/Lat are absent, fall back to geometry average."""
        fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "LineString", "coordinates": [[6.0, 52.0], [6.2, 52.2]]},
                    "properties": {"zoneId": "ZX"},
                }
            ],
        }
        centroids = extract_zone_centroids(fc)
        assert centroids["ZX"] == pytest.approx((6.1, 52.1))


# ---------------------------------------------------------------------------
# enrich_od_geojson
# ---------------------------------------------------------------------------


class TestEnrichOdGeojson:
    """Tests for the enrich_od_geojson enrichment function."""

    def _make_inputs(self):
        """Build a minimal OD GeoJSON and matching network+feedlinks."""
        # Network: 1 -> 2, speed=36 km/h, length=360m, capacity=720, no flows
        net_fc = {
            "type": "FeatureCollection",
            "features": [
                _net_feature(1, 2, 36.0, 360.0, 720.0, {}),
            ],
        }
        # Zone A: production feedlink -> node 1 (36m)
        # Zone B: attraction feedlink <- node 2 (36m)
        fl_fc = {
            "type": "FeatureCollection",
            "features": [
                _feedlink_feature("A", 1, "production", 36.0, 500.0),
                _feedlink_feature("B", 2, "attraction", 36.0, 500.0),
            ],
        }
        # OD with A->B and A->A (diagonal)
        od_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": None,
                    "properties": {
                        "fromZoneId": "A",
                        "toZoneId": "B",
                        "trips": 123.0,
                        "travelTime": 79.2,
                        "distance": 432.0,
                    },
                },
                {
                    "type": "Feature",
                    "geometry": None,
                    "properties": {
                        "fromZoneId": "A",
                        "toZoneId": "A",
                        "trips": 0.0,
                        "travelTime": 0.0,
                        "distance": 0.0,
                    },
                },
            ],
            "properties": {"fields": ["fromZoneId", "toZoneId", "trips", "travelTime", "distance"]},
        }
        return od_fc, net_fc, fl_fc

    def test_remaining_cap_added(self):
        od_fc, net_fc, fl_fc = self._make_inputs()
        enriched = enrich_od_geojson(od_fc, net_fc, fl_fc)
        features = {
            (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"]
            for f in enriched["features"]
        }
        # A->B: min(cap=500 feedlink A->1, cap=720 link 1->2, cap=500 feedlink 2->B) = 500
        assert features[("A", "B")]["remainingCap"] == pytest.approx(500.0)

    def test_diagonal_remaining_cap_zero(self):
        od_fc, net_fc, fl_fc = self._make_inputs()
        enriched = enrich_od_geojson(od_fc, net_fc, fl_fc)
        features = {
            (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"]
            for f in enriched["features"]
        }
        assert features[("A", "A")]["remainingCap"] == pytest.approx(0.0)

    def test_existing_properties_preserved(self):
        od_fc, net_fc, fl_fc = self._make_inputs()
        enriched = enrich_od_geojson(od_fc, net_fc, fl_fc)
        features = {
            (f["properties"]["fromZoneId"], f["properties"]["toZoneId"]): f["properties"]
            for f in enriched["features"]
        }
        assert features[("A", "B")]["trips"] == pytest.approx(123.0)
        assert features[("A", "B")]["travelTime"] == pytest.approx(79.2)

    def test_link_properties_updated(self):
        od_fc, net_fc, fl_fc = self._make_inputs()
        enriched = enrich_od_geojson(od_fc, net_fc, fl_fc)
        lp = enriched["properties"]["fields"]
        assert "remainingCap" in lp

    def test_unreachable_pair_gets_null(self):
        """When a zone has no feedlink, its OD pairs get remainingCap=null."""
        net_fc = {
            "type": "FeatureCollection",
            "features": [
                _net_feature(1, 2, 36.0, 360.0, 720.0, {}),
            ],
        }
        fl_fc = {
            "type": "FeatureCollection",
            "features": [
                _feedlink_feature("A", 1, "production", 36.0, 500.0),
                # Zone C has no feedlink
            ],
        }
        od_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": None,
                    "properties": {"fromZoneId": "A", "toZoneId": "C", "trips": 0.0},
                }
            ],
            "properties": {},
        }
        enriched = enrich_od_geojson(od_fc, net_fc, fl_fc)
        feat_props = enriched["features"][0]["properties"]
        assert feat_props["remainingCap"] is None
