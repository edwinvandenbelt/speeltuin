# Databricks notebook source
# ---------------------------------------------------------------------------
# purple_polar_bear_downloader_nb.py — Databricks notebook interface for
# purple_polar_bear_downloader.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Downloads the ACoGo boundaries GeoJSON and data JSON from their URLs.
#   3. Reads the zone GeoJSON from S3 (or a local path).
#   4. Calls pure core functions to distribute demand over nodes.
#   5. Writes the resulting changes JSON to S3 (or a local path).
#   6. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
import urllib.request
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("purple_polar_bear_downloader_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "boundaries_url", "",
    "URL of the ACoGo boundaries GeoJSON (https:// or s3://)",
)
dbutils.widgets.text(  # noqa: F821
    "data_url", "",
    "URL of the ACoGo socio-geographic JSON (https:// or s3://)",
)
dbutils.widgets.text(  # noqa: F821
    "zone_file", "",
    "Full URI of the zone GeoJSON file (s3://bucket/key or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "area_id", "",
    "Area identifier used in the output filename: {areaId}-CHANGES-{mode}.json",
)
dbutils.widgets.text(  # noqa: F821
    "mode", "CAR",
    "Transport mode (e.g. CAR, BIKE)",
)
dbutils.widgets.text(  # noqa: F821
    "output_folder", "",
    "Output folder URI (s3://bucket/prefix/ or local directory)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

_BOUNDARIES_URL = dbutils.widgets.get("boundaries_url").strip()  # noqa: F821
_DATA_URL        = dbutils.widgets.get("data_url").strip()        # noqa: F821
_ZONE_FILE       = dbutils.widgets.get("zone_file").strip()       # noqa: F821
_AREA_ID         = dbutils.widgets.get("area_id").strip()         # noqa: F821
_MODE            = dbutils.widgets.get("mode").strip()            # noqa: F821
_OUTPUT_FOLDER   = dbutils.widgets.get("output_folder").strip()   # noqa: F821

if not _BOUNDARIES_URL:
    raise ValueError("Widget 'boundaries_url' is empty.")
if not _DATA_URL:
    raise ValueError("Widget 'data_url' is empty.")
if not _ZONE_FILE:
    raise ValueError("Widget 'zone_file' is empty.")
if not _AREA_ID:
    raise ValueError("Widget 'area_id' is empty.")
if not _MODE:
    raise ValueError("Widget 'mode' is empty.")
if not _OUTPUT_FOLDER:
    raise ValueError("Widget 'output_folder' is empty.")

logger.info(
    "boundaries_url=%s  data_url=%s  zone_file=%s  area_id=%s  mode=%s",
    _BOUNDARIES_URL, _DATA_URL, _ZONE_FILE, _AREA_ID, _MODE,
)

# COMMAND ----------
# ── I/O helpers ────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        _, rest = uri.split("://", 1)
        bucket, key = rest.split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    if uri.startswith("https://") or uri.startswith("http://"):
        with urllib.request.urlopen(uri, timeout=30) as resp:  # noqa: S310
            data = resp.read()
        logger.info("Downloaded %s  (%d bytes)", uri, len(data))
        return data
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        _, rest = uri.split("://", 1)
        bucket, key = rest.split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket, Key=key, Body=data, ContentType="application/json",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
    else:
        import os as _os  # noqa: PLC0415
        _os.makedirs(_os.path.dirname(uri) or ".", exist_ok=True)
        with open(uri, "wb") as _fh:
            _fh.write(data)
        logger.info("Wrote %s  (%d bytes)", uri, len(data))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run PurplePolarBearDownloader
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from purple_polar_bear_downloader.core.purple_polar_bear_downloader_core import (  # noqa: E402, PLC0415
    build_changes,
)

_t_start = datetime.now(timezone.utc)
print(f"Starting  {_t_start.isoformat()}")
print(f"Area ID   : {_AREA_ID}")
print(f"Mode      : {_MODE}")
print()

# Download / read inputs
print(f"Downloading boundaries : {_BOUNDARIES_URL}")
_boundaries_fc: dict = json.loads(_read_uri(_BOUNDARIES_URL))

print(f"Downloading ACoGo data : {_DATA_URL}")
_raw_data = json.loads(_read_uri(_DATA_URL))
if isinstance(_raw_data, dict):
    _acogo_data: list = _raw_data.get("data") or []
else:
    _acogo_data = _raw_data
print(f"Loaded {len(_acogo_data):,} ACoGo records.")

print(f"Reading zone file      : {_ZONE_FILE}")
_zone_fc: dict = json.loads(_read_uri(_ZONE_FILE))
print(f"Loaded {len(_zone_fc.get('features') or []):,} zone features.")

# Call core
_changes, _stats = build_changes(_boundaries_fc, _acogo_data, _zone_fc)

# Write output
_out_folder = _OUTPUT_FOLDER.rstrip("/")
_output_uri = f"{_out_folder}/{_AREA_ID}-CHANGES-{_MODE}.json"
print(f"Writing output : {_output_uri}")
_payload = json.dumps(_changes, ensure_ascii=False, indent=2).encode("utf-8")
_write_uri(_output_uri, _payload)

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"PurplePolarBearDownloader complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Area ID              : {_AREA_ID}")
print(f"  Mode                 : {_MODE}")
print(f"  Areas matched        : {_stats['areas_matched']}")
print(f"  Areas unmatched      : {_stats['areas_unmatched']}")
print(f"  Zones contributing   : {_stats['zones_contributing']}")
print(f"  Nodes in output      : {_stats['nodes_total']}")
print(f"  Output URI           : {_output_uri}")
print(_SEP)
