"""Tests for purple_polar_bear_downloader_core."""

from __future__ import annotations

import pytest

from purple_polar_bear_downloader.core.purple_polar_bear_downloader_core import (
    _avg,
    _build_acogo_data_map,
    _build_area_boundary_map,
    _build_current_node_values_from_zones,
    _extract_nodes_from_network,
    _point_in_polygon,
    build_changes,
)
from purple_polar_bear_downloader.purple_polar_bear_downloader_runner import _to_delta_str

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _square_ring(x0: float, y0: float, x1: float, y1: float) -> list:
    """Return a closed GeoJSON ring for an axis-aligned rectangle."""
    return [[x0, y0], [x1, y0], [x1, y1], [x0, y1], [x0, y0]]


def _polygon_feature(ring: list, props: dict | None = None) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": props or {},
    }


def _feature_collection(features: list) -> dict:
    return {"type": "FeatureCollection", "features": features}


def _zone_feature(
    ring: list,
    zone_id: str,
    production: float,
    attraction: float,
    from_node_proportions: dict,
    to_node_proportions: dict,
) -> dict:
    """Build a minimal network_zone_joiner-style zone feature."""
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {
            "zoneId": zone_id,
            "production": production,
            "attraction": attraction,
            "fromNodeProportions": from_node_proportions,
            "toNodeProportions": to_node_proportions,
        },
    }


def _link(from_node: int, from_coord: list, to_node: int, to_coord: list) -> dict:
    """Build a minimal directed network LineString feature."""
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [from_coord, to_coord]},
        "properties": {"fromNode": from_node, "toNode": to_node},
    }


# ---------------------------------------------------------------------------
# _point_in_polygon
# ---------------------------------------------------------------------------


class TestPointInPolygon:
    _RING = _square_ring(0, 0, 4, 4)

    def test_interior(self):
        assert _point_in_polygon(2, 2, self._RING) is True

    def test_exterior(self):
        assert _point_in_polygon(5, 5, self._RING) is False

    def test_negative_coords(self):
        ring = _square_ring(-2, -2, 2, 2)
        assert _point_in_polygon(0, 0, ring) is True
        assert _point_in_polygon(3, 3, ring) is False

    def test_near_edge(self):
        assert _point_in_polygon(0.001, 0.001, self._RING) is True
        assert _point_in_polygon(-0.001, -0.001, self._RING) is False


# ---------------------------------------------------------------------------
# _extract_nodes_from_network
# ---------------------------------------------------------------------------


class TestExtractNodesFromNetwork:
    def test_basic(self):
        fc = _feature_collection([
            _link(1, [4.0, 52.0], 2, [4.1, 52.1]),
        ])
        nodes = _extract_nodes_from_network(fc)
        assert nodes == {"1": [4.0, 52.0], "2": [4.1, 52.1]}

    def test_deduplication_first_wins(self):
        """Same node appearing as toNode and later as fromNode keeps first coords."""
        fc = _feature_collection([
            _link(1, [4.0, 52.0], 2, [4.1, 52.1]),
            _link(2, [4.9, 52.9], 3, [4.2, 52.2]),  # node 2 reappears as fromNode
        ])
        nodes = _extract_nodes_from_network(fc)
        # Node 2 was first seen at [4.1, 52.1] (as toNode of link 1)
        assert nodes["2"] == [4.1, 52.1]

    def test_ids_converted_to_strings(self):
        fc = _feature_collection([_link(42, [0.0, 0.0], 99, [1.0, 1.0])])
        nodes = _extract_nodes_from_network(fc)
        assert "42" in nodes
        assert "99" in nodes

    def test_feature_without_coords_skipped(self):
        fc = _feature_collection([{
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[4.0, 52.0]]},  # only 1 point
            "properties": {"fromNode": 1, "toNode": 2},
        }])
        nodes = _extract_nodes_from_network(fc)
        assert nodes == {}

    def test_empty_network(self):
        assert _extract_nodes_from_network({"features": []}) == {}


# ---------------------------------------------------------------------------
# _build_area_boundary_map
# ---------------------------------------------------------------------------


class TestBuildAreaBoundaryMap:
    def test_normal(self):
        fc = _feature_collection([
            _polygon_feature(_square_ring(0, 0, 1, 1), {"area": "ZoneA"}),
            _polygon_feature(_square_ring(2, 2, 3, 3), {"area": "ZoneB"}),
        ])
        result = _build_area_boundary_map(fc)
        assert set(result) == {"ZoneA", "ZoneB"}

    def test_missing_area_skipped(self):
        fc = _feature_collection([_polygon_feature(_square_ring(0, 0, 1, 1), {})])
        assert _build_area_boundary_map(fc) == {}

    def test_multipolygon(self):
        fc = {
            "type": "FeatureCollection",
            "features": [{
                "type": "Feature",
                "geometry": {
                    "type": "MultiPolygon",
                    "coordinates": [
                        [_square_ring(0, 0, 1, 1)],
                        [_square_ring(2, 2, 3, 3)],
                    ],
                },
                "properties": {"area": "Multi"},
            }],
        }
        result = _build_area_boundary_map(fc)
        assert len(result["Multi"]) == 2


# ---------------------------------------------------------------------------
# _build_acogo_data_map
# ---------------------------------------------------------------------------


class TestBuildAcogoDataMap:
    def test_normal(self):
        data = [
            {"area": "A", "residents_forecast_min": 100, "residents_forecast_max": 200},
            {"area": "B", "residents_forecast_min": 50, "residents_forecast_max": 50},
        ]
        result = _build_acogo_data_map(data)
        assert set(result) == {"A", "B"}

    def test_missing_area_skipped(self):
        assert _build_acogo_data_map([{"residents_forecast_min": 100}]) == {}

    def test_duplicate_area_last_wins(self):
        data = [{"area": "X", "val": 1}, {"area": "X", "val": 2}]
        assert _build_acogo_data_map(data)["X"]["val"] == 2

    def test_empty(self):
        assert _build_acogo_data_map([]) == {}


# ---------------------------------------------------------------------------
# _to_delta_str  (runner helper)
# ---------------------------------------------------------------------------


class TestToDeltaStr:
    def test_positive_gets_plus_prefix(self):
        assert _to_delta_str(50.0) == "+50.0"

    def test_zero_gets_plus_prefix(self):
        assert _to_delta_str(0.0) == "+0.0"

    def test_negative_keeps_minus(self):
        assert _to_delta_str(-30.5) == "-30.5"

    def test_adjuster_parses_positive_as_delta(self):
        """The adjuster's _parse_value must interpret the string as a delta."""
        # Simulate: current=0, value="+50.0" → delta branch → 0 + 50 = 50
        s = _to_delta_str(50.0)
        assert s[0] == "+"
        assert float(s) == pytest.approx(50.0)

    def test_adjuster_parses_negative_as_delta(self):
        s = _to_delta_str(-30.5)
        assert s[0] == "-"
        assert float(s) == pytest.approx(-30.5)


# ---------------------------------------------------------------------------
# _avg
# ---------------------------------------------------------------------------


class TestAvg:
    def test_basic(self):
        assert _avg(2, 4) == pytest.approx(3.0)

    def test_none_treated_as_zero(self):
        assert _avg(None, 10) == pytest.approx(5.0)
        assert _avg(None, None) == pytest.approx(0.0)

    def test_equal(self):
        assert _avg(5, 5) == pytest.approx(5.0)


# ---------------------------------------------------------------------------
# _build_current_node_values_from_zones
# ---------------------------------------------------------------------------


class TestBuildCurrentNodeValuesFromZones:
    def test_single_zone_equal_proportions(self):
        """Two nodes with equal proportions each get half of production/attraction."""
        zones_fc = _feature_collection([
            _zone_feature(
                _square_ring(0, 0, 10, 10),
                zone_id="Z1",
                production=100.0,
                attraction=40.0,
                from_node_proportions={"1": 0.5, "2": 0.5},
                to_node_proportions={"1": 0.5, "2": 0.5},
            ),
        ])
        result = _build_current_node_values_from_zones(zones_fc)
        assert result["1"]["production"] == pytest.approx(50.0)
        assert result["2"]["production"] == pytest.approx(50.0)
        assert result["1"]["attraction"] == pytest.approx(20.0)
        assert result["2"]["attraction"] == pytest.approx(20.0)

    def test_asymmetric_proportions(self):
        """fromNodeProportions and toNodeProportions may differ per node."""
        zones_fc = _feature_collection([
            _zone_feature(
                _square_ring(0, 0, 10, 10),
                zone_id="Z1",
                production=120.0,
                attraction=60.0,
                from_node_proportions={"1": 0.75, "2": 0.25},
                to_node_proportions={"1": 0.4, "2": 0.6},
            ),
        ])
        result = _build_current_node_values_from_zones(zones_fc)
        assert result["1"]["production"] == pytest.approx(90.0)
        assert result["2"]["production"] == pytest.approx(30.0)
        assert result["1"]["attraction"] == pytest.approx(24.0)
        assert result["2"]["attraction"] == pytest.approx(36.0)

    def test_multiple_zones_accumulate(self):
        """A node appearing in two zones accumulates contributions from both."""
        zones_fc = _feature_collection([
            _zone_feature(
                _square_ring(0, 0, 5, 10),
                zone_id="West",
                production=100.0,
                attraction=0.0,
                from_node_proportions={"1": 1.0},
                to_node_proportions={},
            ),
            _zone_feature(
                _square_ring(5, 0, 10, 10),
                zone_id="East",
                production=200.0,
                attraction=50.0,
                from_node_proportions={"1": 0.5, "2": 0.5},
                to_node_proportions={"2": 1.0},
            ),
        ])
        result = _build_current_node_values_from_zones(zones_fc)
        # Node 1: 100 (from West) + 200*0.5 (from East) = 200 production; 0 attraction
        assert result["1"]["production"] == pytest.approx(200.0)
        assert result["1"]["attraction"] == pytest.approx(0.0)
        # Node 2: 200*0.5 production; 50 attraction
        assert result["2"]["production"] == pytest.approx(100.0)
        assert result["2"]["attraction"] == pytest.approx(50.0)

    def test_empty_proportions_skipped(self):
        """Zone with no proportion dicts contributes nothing."""
        zones_fc = _feature_collection([
            _zone_feature(
                _square_ring(0, 0, 10, 10),
                zone_id="Z1",
                production=999.0,
                attraction=999.0,
                from_node_proportions={},
                to_node_proportions={},
            ),
        ])
        assert _build_current_node_values_from_zones(zones_fc) == {}

    def test_empty_feature_collection(self):
        assert _build_current_node_values_from_zones({"features": []}) == {}


# ---------------------------------------------------------------------------
# build_changes — integration scenarios
# ---------------------------------------------------------------------------


def _network_with_nodes(node_map: dict[int, list[float]]) -> dict:
    """Build a minimal network FeatureCollection from {nodeId: [lon, lat]}."""
    node_ids = list(node_map)
    features = []
    for i in range(0, len(node_ids) - 1, 2):
        a, b = node_ids[i], node_ids[i + 1] if i + 1 < len(node_ids) else node_ids[i]
        features.append(_link(a, node_map[a], b, node_map[b]))
    if len(node_ids) % 2 == 1:
        # Lone last node: make a self-loop (degenerate, but enough to register it)
        last = node_ids[-1]
        features.append({
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [node_map[last], [0.0, 0.0]]},
            "properties": {"fromNode": last, "toNode": -1},
        })
    return _feature_collection(features)


class TestBuildChanges:
    def test_single_area_two_nodes_equal_split(self):
        boundaries_fc = _feature_collection([
            _polygon_feature(_square_ring(0, 0, 10, 10), {"area": "Alpha"}),
        ])
        acogo_data = [{
            "area": "Alpha",
            "residents_forecast_min": 100, "residents_forecast_max": 100,
            "jobs_forecast_min": 50, "jobs_forecast_max": 50,
        }]
        network_fc = _network_with_nodes({1: [2.0, 2.0], 2: [8.0, 8.0]})
        changes, stats = build_changes(boundaries_fc, acogo_data, network_fc)

        assert stats["areas_matched"] == 1
        assert stats["nodes_total"] == 2
        prod_values = {c["nodeId"]: c["production"] for c in changes}
        assert prod_values["1"] == pytest.approx(50.0)
        assert prod_values["2"] == pytest.approx(50.0)
        attr_values = {c["nodeId"]: c["attraction"] for c in changes}
        assert attr_values["1"] == pytest.approx(25.0)
        assert attr_values["2"] == pytest.approx(25.0)

    def test_lon_lat_in_output(self):
        boundaries_fc = _feature_collection([
            _polygon_feature(_square_ring(0, 0, 10, 10), {"area": "Beta"}),
        ])
        acogo_data = [{"area": "Beta",
                       "residents_forecast_min": 10, "residents_forecast_max": 10,
                       "jobs_forecast_min": 0, "jobs_forecast_max": 0}]
        network_fc = _network_with_nodes({1: [3.0, 3.0], 2: [7.0, 7.0]})
        changes, _ = build_changes(boundaries_fc, acogo_data, network_fc)

        for c in changes:
            assert "lon" in c
            assert "lat" in c
        coords = {c["nodeId"]: (c["lon"], c["lat"]) for c in changes}
        assert coords["1"] == pytest.approx((3.0, 3.0))
        assert coords["2"] == pytest.approx((7.0, 7.0))

    def test_nodes_outside_boundary_excluded(self):
        boundaries_fc = _feature_collection([
            _polygon_feature(_square_ring(0, 0, 5, 5), {"area": "Small"}),
        ])
        acogo_data = [{"area": "Small",
                       "residents_forecast_min": 100, "residents_forecast_max": 100,
                       "jobs_forecast_min": 0, "jobs_forecast_max": 0}]
        # Node 1 inside, node 2 outside
        network_fc = _network_with_nodes({1: [2.0, 2.0], 2: [8.0, 8.0]})
        changes, stats = build_changes(boundaries_fc, acogo_data, network_fc)

        assert stats["nodes_total"] == 1
        assert changes[0]["nodeId"] == "1"
        assert changes[0]["production"] == pytest.approx(100.0)

    def test_no_nodes_in_boundary_unmatched(self):
        boundaries_fc = _feature_collection([
            _polygon_feature(_square_ring(0, 0, 1, 1), {"area": "Tiny"}),
        ])
        acogo_data = [{"area": "Tiny",
                       "residents_forecast_min": 100, "residents_forecast_max": 100,
                       "jobs_forecast_min": 0, "jobs_forecast_max": 0}]
        network_fc = _network_with_nodes({1: [5.0, 5.0], 2: [9.0, 9.0]})
        changes, stats = build_changes(boundaries_fc, acogo_data, network_fc)

        assert stats["areas_unmatched"] == 1
        assert changes == []

    def test_area_not_in_boundaries(self):
        boundaries_fc = _feature_collection([])
        acogo_data = [{"area": "Ghost",
                       "residents_forecast_min": 10, "residents_forecast_max": 10,
                       "jobs_forecast_min": 0, "jobs_forecast_max": 0}]
        network_fc = _network_with_nodes({1: [1.0, 1.0], 2: [2.0, 2.0]})
        changes, stats = build_changes(boundaries_fc, acogo_data, network_fc)
        assert stats["areas_unmatched"] == 1
        assert changes == []

    def test_zero_demand_nodes_omitted(self):
        boundaries_fc = _feature_collection([
            _polygon_feature(_square_ring(0, 0, 10, 10), {"area": "Zero"}),
        ])
        acogo_data = [{"area": "Zero",
                       "residents_forecast_min": 0, "residents_forecast_max": 0,
                       "jobs_forecast_min": 0, "jobs_forecast_max": 0}]
        network_fc = _network_with_nodes({1: [2.0, 2.0], 2: [8.0, 8.0]})
        changes, stats = build_changes(boundaries_fc, acogo_data, network_fc)
        assert changes == []
        assert stats["nodes_total"] == 0

    def test_multiple_areas_accumulate(self):
        """Two non-overlapping areas should both contribute."""
        boundaries_fc = _feature_collection([
            _polygon_feature(_square_ring(0, 0, 5, 5), {"area": "West"}),
            _polygon_feature(_square_ring(5, 0, 10, 5), {"area": "East"}),
        ])
        acogo_data = [
            {"area": "West", "residents_forecast_min": 100, "residents_forecast_max": 100,
             "jobs_forecast_min": 0, "jobs_forecast_max": 0},
            {"area": "East", "residents_forecast_min": 200, "residents_forecast_max": 200,
             "jobs_forecast_min": 0, "jobs_forecast_max": 0},
        ]
        network_fc = _network_with_nodes({10: [2.0, 2.0], 20: [8.0, 2.0]})
        changes, stats = build_changes(boundaries_fc, acogo_data, network_fc)

        assert stats["areas_matched"] == 2
        prod = {c["nodeId"]: c["production"] for c in changes}
        assert prod["10"] == pytest.approx(100.0)
        assert prod["20"] == pytest.approx(200.0)

    def test_ten_nodes_equal_weight(self):
        """10 nodes in area → each gets exactly 1/10 of demand."""
        ring = _square_ring(0, 0, 20, 20)
        boundaries_fc = _feature_collection([_polygon_feature(ring, {"area": "Big"})])
        acogo_data = [{"area": "Big",
                       "residents_forecast_min": 1000, "residents_forecast_max": 1000,
                       "jobs_forecast_min": 500, "jobs_forecast_max": 500}]
        node_map = {i: [float(i), float(i)] for i in range(1, 11)}
        network_fc = _network_with_nodes(node_map)
        changes, stats = build_changes(boundaries_fc, acogo_data, network_fc)

        assert stats["nodes_total"] == 10
        for c in changes:
            assert c["production"] == pytest.approx(100.0, rel=1e-5)
            assert c["attraction"] == pytest.approx(50.0, rel=1e-5)


# ---------------------------------------------------------------------------
# build_changes — delta computation via zones_fc
# ---------------------------------------------------------------------------


class TestBuildChangesDeltaSemantics:
    """Tests for the absolute→delta conversion using the zone file."""

    def _simple_setup(self):
        boundaries_fc = _feature_collection([
            _polygon_feature(_square_ring(0, 0, 10, 10), {"area": "Alpha"}),
        ])
        network_fc = _network_with_nodes({1: [2.0, 2.0], 2: [8.0, 8.0]})
        return boundaries_fc, network_fc

    def test_absolute_no_zones_equals_target_divided_by_nodes(self):
        """No zone file → current baseline is zero → delta = target / n_nodes."""
        boundaries_fc, network_fc = self._simple_setup()
        acogo_data = [{"area": "Alpha",
                       "residents_forecast_min": 100, "residents_forecast_max": 100,
                       "jobs_forecast_min": 40, "jobs_forecast_max": 40}]
        changes, _ = build_changes(boundaries_fc, acogo_data, network_fc)
        prod = {c["nodeId"]: c["production"] for c in changes}
        attr = {c["nodeId"]: c["attraction"] for c in changes}
        assert prod["1"] == pytest.approx(50.0)
        assert prod["2"] == pytest.approx(50.0)
        assert attr["1"] == pytest.approx(20.0)
        assert attr["2"] == pytest.approx(20.0)

    def test_absolute_with_zones_subtracts_current(self):
        """Zone file provides current baseline → delta = target/n - current."""
        boundaries_fc, network_fc = self._simple_setup()
        acogo_data = [{"area": "Alpha",
                       "residents_forecast_min": 100, "residents_forecast_max": 100,
                       "jobs_forecast_min": 40, "jobs_forecast_max": 40}]
        # Node 1 currently has production=30 via zone, node 2 has no zone entry (0)
        zones_fc = _feature_collection([
            _zone_feature(
                _square_ring(0, 0, 10, 10),
                zone_id="Z1",
                production=30.0,
                attraction=10.0,
                from_node_proportions={"1": 1.0},
                to_node_proportions={"1": 1.0},
            ),
        ])
        changes, _ = build_changes(boundaries_fc, acogo_data, network_fc, zones_fc=zones_fc)
        by_node = {c["nodeId"]: c for c in changes}
        # Node 1: delta = 100/2 - 30 = 20 production; 40/2 - 10 = 10 attraction
        assert by_node["1"]["production"] == pytest.approx(20.0)
        assert by_node["1"]["originalProduction"] == pytest.approx(30.0)
        assert by_node["1"]["originalAttraction"] == pytest.approx(10.0)
        # Node 2: no zone entry → original = 0, delta = 50 production / 20 attraction
        assert by_node["2"]["production"] == pytest.approx(50.0)
        assert by_node["2"]["originalProduction"] == pytest.approx(0.0)
        assert by_node["1"]["attraction"] == pytest.approx(10.0)
        assert by_node["2"]["attraction"] == pytest.approx(20.0)

    def test_target_equal_to_current_produces_zero_omitted(self):
        """If absolute target equals summed current, delta is 0 → node omitted."""
        boundaries_fc, network_fc = self._simple_setup()
        acogo_data = [{"area": "Alpha",
                       "residents_forecast_min": 100, "residents_forecast_max": 100,
                       "jobs_forecast_min": 0, "jobs_forecast_max": 0}]
        # Each node already has exactly 50 production via zone proportions → delta = 0
        zones_fc = _feature_collection([
            _zone_feature(
                _square_ring(0, 0, 10, 10),
                zone_id="Z1",
                production=100.0,
                attraction=0.0,
                from_node_proportions={"1": 0.5, "2": 0.5},
                to_node_proportions={},
            ),
        ])
        changes, stats = build_changes(boundaries_fc, acogo_data, network_fc, zones_fc=zones_fc)
        assert changes == []
        assert stats["nodes_total"] == 0

    def test_target_below_current_produces_negative_delta(self):
        """ACoGo target lower than current → negative delta (demand reduction)."""
        boundaries_fc, network_fc = self._simple_setup()
        acogo_data = [{"area": "Alpha",
                       "residents_forecast_min": 60, "residents_forecast_max": 60,
                       "jobs_forecast_min": 0, "jobs_forecast_max": 0}]
        # Each node currently has production=50 via zone → target/2=30, delta=-20
        zones_fc = _feature_collection([
            _zone_feature(
                _square_ring(0, 0, 10, 10),
                zone_id="Z1",
                production=100.0,
                attraction=0.0,
                from_node_proportions={"1": 0.5, "2": 0.5},
                to_node_proportions={},
            ),
        ])
        changes, _ = build_changes(boundaries_fc, acogo_data, network_fc, zones_fc=zones_fc)
        prod = {c["nodeId"]: c["production"] for c in changes}
        assert prod["1"] == pytest.approx(-20.0)
        assert prod["2"] == pytest.approx(-20.0)
