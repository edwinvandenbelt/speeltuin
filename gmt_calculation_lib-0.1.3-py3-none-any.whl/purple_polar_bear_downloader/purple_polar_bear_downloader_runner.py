"""Local debug runner for purple_polar_bear_downloader.

Downloads two ACoGo files, reads the network file, calls build_changes() directly
— no Lambda handler involved.  Writes both output files:

* ``{areaId}-CHANGES-{mode}.json``     — plain JSON changes (adjuster format)
* ``{areaId}-CHANGES-{mode}.parquet``  — GeoParquet Point features for visualisation

Usage
-----
    python -m purple_polar_bear_downloader.purple_polar_bear_downloader_runner \\
        --boundaries-url https://example.com/boundaries.geojson \\
        --data-url       https://example.com/acogo-data.json \\
        --network-file   s3://bucket/uuid-NETWORK-CAR.parquet \\
        --zone-file      s3://bucket/uuid-ZONE-CAR.parquet \\
        --area-id        9917e7c4-820e-4da2-babd-74d73ba5b63c \\
        --mode           CAR \\
        --output-folder  /tmp/output/

    # Or with local files:
    python -m purple_polar_bear_downloader.purple_polar_bear_downloader_runner \\
        --boundaries-url file:///data/boundaries.geojson \\
        --data-url       file:///data/acogo-data.json \\
        --network-file   /data/uuid-NETWORK-CAR.parquet \\
        --zone-file      /data/uuid-ZONE-CAR.parquet \\
        --area-id        test-area \\
        --mode           CAR \\
        --output-folder  /tmp/output/

    # Without --zone-file: current baseline is all-zero (absolute ACoGo targets
    # become the delta directly — useful for first-run bootstrapping).

Prerequisites
-------------
* AWS credentials available in the environment or a tools/.env file (only needed
  for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    if uri.startswith("https://") or uri.startswith("http://"):
        with urllib.request.urlopen(uri, timeout=30) as resp:  # noqa: S310
            return resp.read()
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data, content_type="application/json")
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


def _to_delta_str(value: float) -> str:
    """Format a delta float as an explicit signed string (e.g. "+50.0", "-30.5").

    This matches the adjuster's intended input format: strings with a leading
    ``+`` or ``-`` are treated as deltas relative to the accumulated value for
    that node (which starts at zero, so the result is the same numerically).
    Using explicit sign prefixes makes the delta intent clear in the output file.
    """
    if value >= 0:
        return f"+{value}"
    return str(value)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for purple_polar_bear_downloader (calls core directly)."
    )
    parser.add_argument(
        "--boundaries-url",
        required=True,
        metavar="URL",
        help="URL or URI of the area boundaries GeoJSON file (https://, s3://, or local path).",
    )
    parser.add_argument(
        "--data-url",
        required=True,
        metavar="URL",
        help="URL or URI of the ACoGo socio-geographic JSON file (https://, s3://, or local path).",
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="Full URI of the network GeoParquet file (s3://bucket/key or local path).",
    )
    parser.add_argument(
        "--zone-file",
        default=None,
        metavar="URI",
        help=(
            "Full URI of the zone GeoParquet file produced by network_zone_joiner "
            "({areaId}-ZONE-{mode}.parquet).  Used to derive the current per-node "
            "production/attraction baseline for absolute ACoGo values.  "
            "When omitted the baseline is all-zero."
        ),
    )
    parser.add_argument(
        "--area-id",
        required=True,
        metavar="ID",
        help="Area identifier used in the output filenames: {areaId}-CHANGES-{mode}.json/.parquet",
    )
    parser.add_argument(
        "--mode",
        required=True,
        metavar="MODE",
        help="Transport mode (e.g. CAR).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder URI (s3://bucket/prefix/ or local directory).",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from purple_polar_bear_downloader.core.purple_polar_bear_downloader_core import build_changes  # noqa: PLC0415
    from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

    # Download / read inputs
    print(f"Downloading boundaries : {args.boundaries_url}")
    boundaries_fc: dict = json.loads(_read_uri(args.boundaries_url))

    print(f"Downloading ACoGo data : {args.data_url}")
    raw_data = json.loads(_read_uri(args.data_url))
    if isinstance(raw_data, dict):
        acogo_data: list[dict] = raw_data.get("data") or []
    else:
        acogo_data = raw_data

    print(f"Reading network file   : {args.network_file}")
    network_fc: dict = from_geoparquet(_read_uri(args.network_file))

    # Load zone file to derive current per-node baseline (optional)
    zones_fc: dict | None = None
    if args.zone_file:
        print(f"Reading zone file      : {args.zone_file}")
        zones_fc = from_geoparquet(_read_uri(args.zone_file))
    else:
        print("No --zone-file supplied — current baseline is all-zero.")

    out_folder = args.output_folder.rstrip("/")
    base = f"{out_folder}/{args.area_id}-CHANGES-{args.mode}"
    changes_uri = f"{base}.json"
    geojson_uri = f"{base}.parquet"

    # Call core
    changes, stats = build_changes(boundaries_fc, acogo_data, network_fc, zones_fc)
    print(f"Stats : {stats}")

    # Write plain JSON (adjuster format — no lon/lat, deltas as signed strings)
    adjuster_changes = [
        {
            "nodeId": c["nodeId"],
            "originalProduction": c["originalProduction"],
            "originalAttraction": c["originalAttraction"],
            "production": _to_delta_str(c["production"]),
            "attraction": _to_delta_str(c["attraction"]),
        }
        for c in changes
    ]
    print(f"Writing JSON   : {changes_uri}")
    _write_uri(
        changes_uri,
        json.dumps(adjuster_changes, ensure_ascii=False, indent=2).encode("utf-8"),
    )

    # Write GeoJSON
    geojson_fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [c["lon"], c["lat"]]},
                "properties": {
                    "nodeId": c["nodeId"],
                    "originalProduction": c["originalProduction"],
                    "originalAttraction": c["originalAttraction"],
                    "production": c["production"],
                    "attraction": c["attraction"],
                },
            }
            for c in changes
        ],
    }
    print(f"Writing GeoParquet : {geojson_uri}")
    _write_uri(
        geojson_uri,
        to_geoparquet(geojson_fc),
    )

    print("Done.")


if __name__ == "__main__":
    main()
