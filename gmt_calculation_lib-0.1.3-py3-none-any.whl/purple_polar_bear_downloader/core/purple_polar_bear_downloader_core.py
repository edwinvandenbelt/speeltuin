"""Pure-Python purple_polar_bear_downloader core — no I/O, no boto3, no external deps.

Downloads two ACoGo files, matches socio-geographic data records to area boundary
polygons, finds all network nodes that fall within each area boundary, and
distributes the area-level demand values (residents → production, jobs → attraction)
equally over those nodes.  The result is a ``changes`` list ready for the GMT
adjuster pipeline, plus the GeoJSON counterpart for visualisation.

Delta computation
-----------------
ACoGo forecast values (``residents_forecast_min/max``, ``jobs_forecast_min/max``)
are **always absolute** — they represent the desired total production or attraction
for the area after the scenario.  ``build_changes`` converts each absolute area
total to a per-node delta:

    delta_per_node = (area_total / n_nodes_in_area) − current_value_for_node

The current per-node value is derived from the zone file (output of
``network_zone_joiner``) via ``_build_current_node_values_from_zones``:
each node's share of the zone's production/attraction is given by
``fromNodeProportions`` (production) and ``toNodeProportions`` (attraction).

When no zone file is supplied, the current baseline is all-zero (useful for
first-run bootstrapping: the delta equals the absolute target directly).

Public API
----------
build_changes(boundaries_fc, acogo_data, network_fc, zones_fc=None)
    Returns (changes, stats) where ``changes`` is a list of
    ``{"nodeId": str, "production": float, "attraction": float,
       "lon": float, "lat": float}`` dicts — one per node that receives a
    non-zero delta contribution.  The caller may strip ``lon``/``lat`` for the
    plain JSON changes file and use them for the GeoJSON Point output.
    ``stats`` contains counters for logging / the runner response.

Helpers
-------
_build_current_node_values_from_zones(zones_fc)
    Derives ``{nodeId: {"production": float, "attraction": float}}`` from a
    ``network_zone_joiner`` output FeatureCollection.

_point_in_polygon
    Ray-casting point-in-polygon test used to find nodes inside an area boundary.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------


def _point_in_polygon(lon: float, lat: float, ring: list) -> bool:
    """Ray-casting point-in-polygon test for a closed GeoJSON-style ring.

    Parameters
    ----------
    lon, lat:
        The point to test (WGS-84 decimal degrees).
    ring:
        A closed list of ``[lon, lat]`` pairs (first == last).

    Returns
    -------
    bool
        ``True`` if the point is strictly inside the ring.
    """
    inside = False
    n = len(ring) - 1  # ignore the closing duplicate
    j = n - 1
    for i in range(n):
        xi, yi = float(ring[i][0]), float(ring[i][1])
        xj, yj = float(ring[j][0]), float(ring[j][1])
        if ((yi > lat) != (yj > lat)) and (lon < (xj - xi) * (lat - yi) / (yj - yi + 1e-15) + xi):
            inside = not inside
        j = i
    return inside


# ---------------------------------------------------------------------------
# Feature helpers
# ---------------------------------------------------------------------------


def _get_polygon_rings(feature: dict) -> list[list]:
    """Return a list of exterior rings from a GeoJSON Polygon or MultiPolygon feature.

    Each ring is a closed list of ``[lon, lat]`` pairs.  Returns an empty list
    if the geometry type is unsupported or the coordinates are missing.
    """
    geom = feature.get("geometry") or {}
    geom_type = geom.get("type") or ""
    coords = geom.get("coordinates") or []

    if geom_type == "Polygon":
        return [coords[0]] if coords and coords[0] else []
    if geom_type == "MultiPolygon":
        return [poly[0] for poly in coords if poly and poly[0]]
    return []


def _build_area_boundary_map(boundaries_fc: dict) -> dict[str, list[list]]:
    """Build ``{area_name: [exterior_ring, ...]}`` from the boundaries FeatureCollection.

    The join key is the ``area`` property on each feature.  Features without an
    ``area`` property are skipped with a warning.
    """
    result: dict[str, list[list]] = {}
    for feat in boundaries_fc.get("features") or []:
        props = feat.get("properties") or {}
        area_name = str(props.get("area") or "").strip()
        if not area_name:
            logger.warning("Boundary feature without 'area' property — skipped.")
            continue
        rings = _get_polygon_rings(feat)
        if not rings:
            logger.warning(
                "Boundary feature %r has no usable polygon geometry — skipped.", area_name
            )
            continue
        if area_name in result:
            result[area_name].extend(rings)
        else:
            result[area_name] = rings
    return result


def _build_acogo_data_map(acogo_data: list[dict]) -> dict[str, dict]:
    """Build ``{area_name: record}`` from the ACoGo data list.

    The join key is the ``area`` field of each record.  Duplicate area names
    are overwritten by the last occurrence (with a warning).
    """
    result: dict[str, dict] = {}
    for record in acogo_data:
        area_name = str(record.get("area") or "").strip()
        if not area_name:
            logger.warning("ACoGo record without 'area' field — skipped: %r", record)
            continue
        if area_name in result:
            logger.warning(
                "Duplicate ACoGo area %r — later record overwrites earlier one.", area_name
            )
        result[area_name] = record
    return result


def _avg(lo: float | int | None, hi: float | int | None) -> float:
    """Return the midpoint of *lo* and *hi*, treating None as 0."""
    lo = float(lo or 0)
    hi = float(hi or 0)
    return (lo + hi) / 2.0


def _build_current_node_values_from_zones(
    zones_fc: dict,
) -> dict[str, dict[str, float]]:
    """Derive current per-node production and attraction from a zone FeatureCollection.

    The zone file is the output of ``network_zone_joiner`` (``{areaId}-ZONE-{mode}.geojson``).
    Each zone feature carries:

    * ``production`` — total trip-origin demand for the zone.
    * ``attraction`` — total trip-destination demand for the zone.
    * ``fromNodeProportions`` — ``{nodeId: float}`` mapping each node's share of the
      zone's outgoing link length (values sum to 1.0).  Used to split production.
    * ``toNodeProportions``   — ``{nodeId: float}`` mapping each node's share of the
      zone's incoming link length (values sum to 1.0).  Used to split attraction.

    A node may appear in multiple zones; contributions are accumulated.

    Parameters
    ----------
    zones_fc:
        GeoJSON FeatureCollection as produced by ``network_zone_joiner``.

    Returns
    -------
    dict[str, dict[str, float]]
        ``{nodeId: {"production": float, "attraction": float}}`` for every node
        that appears in at least one zone with non-zero proportions.
    """
    result: dict[str, dict[str, float]] = {}

    for feat in zones_fc.get("features") or []:
        props = feat.get("properties") or {}
        production = float(props.get("production") or 0.0)
        attraction = float(props.get("attraction") or 0.0)
        from_props: dict = props.get("fromNodeProportions") or {}
        to_props: dict = props.get("toNodeProportions") or {}

        for node_id, proportion in from_props.items():
            nid = str(node_id)
            if nid not in result:
                result[nid] = {"production": 0.0, "attraction": 0.0}
            result[nid]["production"] += production * float(proportion)

        for node_id, proportion in to_props.items():
            nid = str(node_id)
            if nid not in result:
                result[nid] = {"production": 0.0, "attraction": 0.0}
            result[nid]["attraction"] += attraction * float(proportion)

    return result


def _extract_nodes_from_network(network_fc: dict) -> dict[str, list[float]]:
    """Extract ``{nodeId: [lon, lat]}`` from a network GeoJSON FeatureCollection.

    Each network feature is a directed LineString.  The ``fromNode`` property
    corresponds to ``coordinates[0]`` and ``toNode`` to ``coordinates[-1]``.
    Node IDs are stored as strings.  Duplicate node entries (same ID appearing
    as both a fromNode and a toNode in different links) are silently deduplicated
    — the first occurrence wins.
    """
    nodes: dict[str, list[float]] = {}
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is not None:
            nid = str(from_node)
            if nid not in nodes:
                nodes[nid] = [float(coords[0][0]), float(coords[0][1])]
        if to_node is not None:
            nid = str(to_node)
            if nid not in nodes:
                nodes[nid] = [float(coords[-1][0]), float(coords[-1][1])]
    return nodes


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def build_changes(
    boundaries_fc: dict,
    acogo_data: list[dict],
    network_fc: dict,
    zones_fc: dict | None = None,
) -> tuple[list[dict], dict]:
    """Distribute ACoGo demand values equally over in-boundary network nodes.

    For each area in *acogo_data* that has a matching polygon in *boundaries_fc*:

    1. Find all unique network nodes (from *network_fc*) whose coordinates fall
       inside the area boundary polygon.
    2. Parse demand values from the ACoGo record:
       * If the raw min/max strings carry a ``+`` or ``-`` prefix the value is
         already a delta — distribute it equally over the nodes as-is.
       * Otherwise the value is an absolute target.  The per-node delta is:
         ``(target_total / node_count) - current_value_for_node``, where
         the current per-node values are derived from *zones_fc* via
         ``_build_current_node_values_from_zones`` (defaults to 0 when *zones_fc*
         is ``None`` or a node is absent).
    3. Accumulate across all areas (a node covered by multiple areas receives
       the sum of all contributions).

    Parameters
    ----------
    boundaries_fc:
        GeoJSON FeatureCollection of area boundary polygons.  Each feature must
        carry an ``area`` property matching a record in *acogo_data*.
    acogo_data:
        List of socio-geographic records, each with an ``area`` field plus
        ``residents_forecast_min``, ``residents_forecast_max``,
        ``jobs_forecast_min``, and ``jobs_forecast_max`` fields.  All values are
        treated as **absolute** area totals; the per-node delta is computed by
        subtracting the current value derived from *zones_fc*.
    network_fc:
        GeoJSON FeatureCollection of directed network LineString features
        (output of ``network_intersector``).  Each feature must carry
        ``fromNode`` and ``toNode`` properties.
    zones_fc:
        Optional ``network_zone_joiner`` output GeoJSON
        (``{areaId}-ZONE-{mode}.geojson``).  Used to derive the current per-node
        production and attraction baseline.  Each zone feature must carry
        ``production``, ``attraction``, ``fromNodeProportions``, and
        ``toNodeProportions`` properties.  When ``None``, the current baseline
        is all-zero (delta = absolute target directly).

    Returns
    -------
    changes : list[dict]
        One entry per contributing node:
        ``{"nodeId": str, "production": float, "attraction": float,
           "lon": float, "lat": float}``.
        Nodes whose delta is zero for both production and attraction are omitted.
        The ``lon``/``lat`` fields are included for the GeoJSON output;
        strip them before writing the plain JSON changes file.
    stats : dict
        Counters: ``areas_matched``, ``areas_unmatched``, ``nodes_total``.
    """
    boundary_map = _build_area_boundary_map(boundaries_fc)
    data_map = _build_acogo_data_map(acogo_data)
    node_coords = _extract_nodes_from_network(network_fc)
    current = _build_current_node_values_from_zones(zones_fc) if zones_fc else {}

    logger.info(
        "Loaded %d boundary areas, %d ACoGo records, %d unique network nodes.",
        len(boundary_map), len(data_map), len(node_coords),
    )

    # Accumulated per-node demand deltas {nodeId: {"production": float, "attraction": float}}
    node_demands: dict[str, dict[str, float]] = {}

    areas_matched = 0
    areas_unmatched = 0

    for area_name, record in data_map.items():
        boundary_rings = boundary_map.get(area_name)
        if not boundary_rings:
            logger.warning("Area %r: no matching boundary polygon found — skipped.", area_name)
            areas_unmatched += 1
            continue

        residents = _avg(record.get("residents_forecast_min"), record.get("residents_forecast_max"))
        jobs = _avg(record.get("jobs_forecast_min"), record.get("jobs_forecast_max"))

        # Find nodes inside any of this area's boundary rings
        nodes_in_area: list[str] = []
        for node_id, (lon, lat) in node_coords.items():
            for ring in boundary_rings:
                if _point_in_polygon(lon, lat, ring):
                    nodes_in_area.append(node_id)
                    break  # node matched — no need to check other rings

        if not nodes_in_area:
            logger.warning("Area %r: no network nodes found inside boundary — skipped.", area_name)
            areas_unmatched += 1
            continue

        areas_matched += 1
        n = len(nodes_in_area)
        weight = 1.0 / n

        logger.info("Area %r: residents=%.1f  jobs=%.1f  nodes=%d", area_name, residents, jobs, n)

        for node_id in nodes_in_area:
            if node_id not in node_demands:
                node_demands[node_id] = {"production": 0.0, "attraction": 0.0}

            current_prod = current.get(node_id, {}).get("production", 0.0)
            current_attr = current.get(node_id, {}).get("attraction", 0.0)
            node_demands[node_id]["production"] += round(residents * weight - current_prod, 6)
            node_demands[node_id]["attraction"] += round(jobs * weight - current_attr, 6)

    changes: list[dict] = [
        {
            "nodeId": nid,
            "originalProduction": round(current.get(nid, {}).get("production", 0.0), 6),
            "originalAttraction": round(current.get(nid, {}).get("attraction", 0.0), 6),
            "production": round(vals["production"], 6),
            "attraction": round(vals["attraction"], 6),
            "lon": node_coords[nid][0],
            "lat": node_coords[nid][1],
        }
        for nid, vals in node_demands.items()
        if vals["production"] != 0.0 or vals["attraction"] != 0.0
    ]

    stats = {
        "areas_matched": areas_matched,
        "areas_unmatched": areas_unmatched,
        "nodes_total": len(changes),
    }
    logger.info("build_changes complete: %s", stats)
    return changes, stats
