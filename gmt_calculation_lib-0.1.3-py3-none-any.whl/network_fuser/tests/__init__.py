# src/network_fuser/tests/__init__.py
