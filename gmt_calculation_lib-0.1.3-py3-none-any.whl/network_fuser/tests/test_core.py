"""Tests for network_fuser_core.fuse_networks and helpers."""

from __future__ import annotations

import math

import numpy as np
import pytest

from network_fuser.core.network_fuser_core import (
    _EXCLUDED_WEGTYPES,
    _SPEED_LIMIT_MAX_KMH,
    _car_speed_ok,
    _sublinks_for_link,
    fuse_networks,
)
from shared.rd_projection import wgs84_to_rd

# ---------------------------------------------------------------------------
# Test-data helpers
# ---------------------------------------------------------------------------

# Base coordinates in the Netherlands (required for wgs84_to_rd accuracy).
# CAR link runs due east: from (5.0, 52.0) to (5.001, 52.0) — ≈ 68.7 m.
_CAR_LON_S, _CAR_LAT = 5.0, 52.0
_CAR_LON_E            = 5.001

# BIKE endpoints ≈ 5.6 m north of the CAR link, same longitude range.
# This lateral offset is well within the default 10 m buffer.
_OFFSET_LAT  = 0.00005          # ≈ 5.6 m north
_BIKE_LON_S  = _CAR_LON_S
_BIKE_LAT    = _CAR_LAT + _OFFSET_LAT
_BIKE_LON_E  = _CAR_LON_E


def _car(
    lon_s=_CAR_LON_S, lat_s=_CAR_LAT, lon_e=_CAR_LON_E, lat_e=_CAR_LAT,
    link_id="C1",
    speed: float = 30.0,
    from_node: str = "100",
    to_node:   str = "101",
    oneway: bool = False,
) -> dict:
    """Build a straight CAR feature with the correct pre-split property names.

    Parameters
    ----------
    oneway:
        When ``True`` sets ``rijrichting_terug=False`` (one-way road).  Default
        ``False`` sets both directions passable (two-way).
    """
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [[lon_s, lat_s], [lon_e, lat_e]],
        },
        "properties": {
            "mode": "CAR",
            "fromNode": from_node,
            "toNode":   to_node,
            "linkId":   link_id,
            "max_snelheid_heen":  speed,
            "max_snelheid_terug": speed,
            "rijrichting_heen":   True,
            "rijrichting_terug":  not oneway,
        },
    }


def _car_curved(link_id="C1", speed: float = 30.0) -> dict:
    """CAR feature with 3 coordinates (slight northward bulge at the midpoint)."""
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [_CAR_LON_S, _CAR_LAT],
                [(_CAR_LON_S + _CAR_LON_E) / 2, _CAR_LAT + 0.000005],  # ~0.6 m bulge
                [_CAR_LON_E, _CAR_LAT],
            ],
        },
        "properties": {
            "mode": "CAR",
            "fromNode": "100",
            "toNode":   "101",
            "linkId":   link_id,
            "max_snelheid_heen":  speed,
            "max_snelheid_terug": speed,
        },
    }


def _car_perpendicular(link_id="C_PERP") -> dict:
    """CAR running N–S (perpendicular to the E–W BIKE), passing through the BIKE path.

    Sub-links have direction ≈ (0, 1), so ``|dot(bike_dir, car_dir)|`` ≈ 0
    which is well below ``cos(30°)`` — direction check must reject all pairs.
    """
    mid_lon = (_CAR_LON_S + _CAR_LON_E) / 2
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [
                [mid_lon, _CAR_LAT - 0.0002],  # ≈ 22 m south
                [mid_lon, _CAR_LAT + 0.0002],  # ≈ 22 m north
            ],
        },
        "properties": {
            "mode": "CAR",
            "fromNode": "100",
            "toNode":   "101",
            "linkId":   link_id,
            "max_snelheid_heen":  30.0,
            "max_snelheid_terug": 30.0,
        },
    }


def _bike(
    lon_s=_BIKE_LON_S, lat_s=_BIKE_LAT, lon_e=_BIKE_LON_E, lat_e=_BIKE_LAT,
    link_id="B1",
    wegtype: str | None = None,
    from_node: str = "200",
    to_node:   str = "201",
) -> dict:
    """Build a 2-coordinate BIKE feature."""
    props: dict = {
        "mode": "BIKE",
        "fromNode": from_node,
        "toNode":   to_node,
        "linkId":   link_id,
    }
    if wegtype is not None:
        props["wegtype"] = wegtype
    return {
        "type": "Feature",
        "geometry": {
            "type": "LineString",
            "coordinates": [[lon_s, lat_s], [lon_e, lat_e]],
        },
        "properties": props,
    }


def _fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features), "properties": {}}


# ---------------------------------------------------------------------------
# _sublinks_for_link helper
# ---------------------------------------------------------------------------

class TestSublinksForLink:
    """Unit tests for the sub-link generation helper (operates in RD metres)."""

    def test_single_segment_sublink_count(self):
        """10 m segment with sublink_len=5 → int(10/5)+1 = 3 sub-links."""
        mids, dirs = _sublinks_for_link([(0.0, 0.0), (10.0, 0.0)], sublink_len=5.0)
        assert len(mids) == 3
        assert len(dirs) == 3

    def test_short_segment_yields_one_sublink(self):
        """A 3 m segment with sublink_len=5 → int(3/5)+1 = 1 sub-link."""
        mids, _ = _sublinks_for_link([(0.0, 0.0), (3.0, 0.0)], sublink_len=5.0)
        assert len(mids) == 1

    def test_directions_are_unit_vectors(self):
        """Every direction vector has magnitude 1."""
        mids, dirs = _sublinks_for_link([(0.0, 0.0), (10.0, 0.0)], sublink_len=3.0)
        norms = np.sqrt(dirs[:, 0] ** 2 + dirs[:, 1] ** 2)
        np.testing.assert_allclose(norms, 1.0, atol=1e-9)

    def test_direction_eastward_segment(self):
        """Eastward segment → direction (1, 0)."""
        _, dirs = _sublinks_for_link([(0.0, 0.0), (100.0, 0.0)], sublink_len=5.0)
        np.testing.assert_allclose(dirs[:, 0], 1.0, atol=1e-9)
        np.testing.assert_allclose(dirs[:, 1], 0.0, atol=1e-9)

    def test_midpoints_lie_on_segment(self):
        """All midpoints have y=0 for a horizontal segment."""
        mids, _ = _sublinks_for_link([(0.0, 0.0), (20.0, 0.0)], sublink_len=3.0)
        np.testing.assert_allclose(mids[:, 1], 0.0, atol=1e-9)

    def test_midpoints_within_segment_bounds(self):
        """All midpoints lie strictly within the [0, 20] x-range."""
        mids, _ = _sublinks_for_link([(0.0, 0.0), (20.0, 0.0)], sublink_len=3.0)
        assert np.all(mids[:, 0] > 0.0)
        assert np.all(mids[:, 0] < 20.0)

    def test_degenerate_zero_length_returns_empty(self):
        """Zero-length segment → empty (0, 2) arrays."""
        mids, dirs = _sublinks_for_link([(5.0, 5.0), (5.0, 5.0)], sublink_len=5.0)
        assert mids.shape == (0, 2)
        assert dirs.shape == (0, 2)

    def test_multi_segment_total_count(self):
        """Two 10 m segments → 2 × (int(10/5)+1) = 6 sub-links total."""
        mids, _ = _sublinks_for_link(
            [(0.0, 0.0), (10.0, 0.0), (20.0, 0.0)], sublink_len=5.0
        )
        assert len(mids) == 6


# ---------------------------------------------------------------------------
# _car_speed_ok helper
# ---------------------------------------------------------------------------

class TestCarSpeedOk:
    def test_below_threshold_ok(self):
        assert _car_speed_ok({"max_snelheid_heen": 50, "max_snelheid_terug": 50}) is True

    def test_at_threshold_not_ok(self):
        assert _car_speed_ok({"max_snelheid_heen": 60, "max_snelheid_terug": 60}) is False

    def test_above_threshold_not_ok(self):
        assert _car_speed_ok({"max_snelheid_heen": 80, "max_snelheid_terug": 80}) is False

    def test_missing_speed_treated_as_zero(self):
        assert _car_speed_ok({}) is True

    def test_one_direction_above_threshold(self):
        # heen = 30 OK, terug = 80 → overall NOT ok
        assert _car_speed_ok({"max_snelheid_heen": 30, "max_snelheid_terug": 80}) is False


# ---------------------------------------------------------------------------
# Single-mode / empty → no-op
# ---------------------------------------------------------------------------

class TestNoOp:
    def test_car_only(self):
        fc = _fc(_car())
        out_fc, node_map, link_pairs, stats = fuse_networks(fc)
        assert out_fc is fc
        assert node_map  == []
        assert link_pairs == []
        assert stats["link_pairs"] == 0
        assert stats["fused_bike"] == 0

    def test_bike_only(self):
        fc = _fc(_bike())
        _, _, link_pairs, _ = fuse_networks(fc)
        assert link_pairs == []

    def test_empty(self):
        fc = _fc()
        _, _, link_pairs, stats = fuse_networks(fc)
        assert link_pairs == []
        assert stats["car_links"] == stats["bike_links"] == 0

    def test_all_bike_excluded_wegtype(self):
        """When all BIKE links have an excluded wegtype the result is empty."""
        fc = _fc(_car(), _bike(wegtype="solitair_fietspad"))
        _, _, link_pairs, stats = fuse_networks(fc)
        assert link_pairs == []
        assert stats["bike_eligible"]   == 0
        assert stats["skipped_wegtype"] == 1


# ---------------------------------------------------------------------------
# Speed filter
# ---------------------------------------------------------------------------

class TestSpeedFilter:
    def test_car_below_60_matched(self):
        _, _, link_pairs, stats = fuse_networks(_fc(_car(speed=50.0), _bike()))
        assert len(link_pairs) == 1
        assert stats["skipped_speed"] == 0

    def test_car_at_60_excluded(self):
        _, _, link_pairs, stats = fuse_networks(_fc(_car(speed=60.0), _bike()))
        assert link_pairs == []
        assert stats["skipped_speed"] == 1

    def test_car_above_60_excluded(self):
        _, _, link_pairs, stats = fuse_networks(_fc(_car(speed=80.0), _bike()))
        assert link_pairs == []
        assert stats["skipped_speed"] == 1

    def test_car_no_speed_properties_matched(self):
        """A CAR feature without speed properties is treated as 0 km/h → matched."""
        car_no_speed = {
            "type": "Feature",
            "geometry": {"type": "LineString",
                         "coordinates": [[_CAR_LON_S, _CAR_LAT], [_CAR_LON_E, _CAR_LAT]]},
            "properties": {"mode": "CAR", "fromNode": "100", "toNode": "101", "linkId": "C1"},
        }
        _, _, link_pairs, _ = fuse_networks(_fc(car_no_speed, _bike()))
        assert len(link_pairs) == 1

    def test_one_direction_above_60_whole_link_excluded(self):
        """Even if only one direction is ≥ 60 km/h the whole link is excluded."""
        car_fast_one_dir = {
            "type": "Feature",
            "geometry": {"type": "LineString",
                         "coordinates": [[_CAR_LON_S, _CAR_LAT], [_CAR_LON_E, _CAR_LAT]]},
            "properties": {
                "mode": "CAR", "fromNode": "100", "toNode": "101", "linkId": "C1",
                "max_snelheid_heen": 30.0, "max_snelheid_terug": 70.0,
            },
        }
        _, _, link_pairs, _ = fuse_networks(_fc(car_fast_one_dir, _bike()))
        assert link_pairs == []


# ---------------------------------------------------------------------------
# Buffer + overlap matching
# ---------------------------------------------------------------------------

class TestOverlapMatching:
    """Core buffer + overlap geometry-based matching."""

    def test_parallel_bike_matched_forward(self):
        """BIKE 5.6 m north, same extent → 100% overlap → forward match."""
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), _bike()))
        assert len(link_pairs) == 1
        assert link_pairs[0]["isReverse"] is False

    def test_bike_far_laterally_not_matched(self):
        """BIKE ~200 m north → outside 10 m buffer for all sublinks → no match."""
        bike_far = _bike(lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002,
                         from_node="900", to_node="901")
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), bike_far))
        assert link_pairs == []

    def test_anti_parallel_bike_matched_as_reversed(self):
        """Westbound BIKE → anti-parallel direction (|dot|=1) → isReverse=True."""
        bike_rev = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                         lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), bike_rev))
        assert len(link_pairs) == 1
        assert link_pairs[0]["isReverse"] is True

    def test_perpendicular_direction_not_matched(self):
        """N–S bike alongside E–W car → |dot(bike_dir, car_dir)| ≈ 0 < cos(30°) → no match."""
        bike_perp = _bike(
            lon_s=(_CAR_LON_S + _CAR_LON_E) / 2, lat_s=_CAR_LAT - 0.0002,
            lon_e=(_CAR_LON_S + _CAR_LON_E) / 2, lat_e=_CAR_LAT + 0.0002,
        )
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), bike_perp))
        assert link_pairs == []

    def test_perpendicular_car_not_matched(self):
        """N–S CAR through the BIKE path → direction check rejects all sub-link pairs."""
        _, _, link_pairs, _ = fuse_networks(_fc(_car_perpendicular(), _bike()))
        assert link_pairs == []

    def test_narrow_buffer_excludes_nearby_link(self):
        """BIKE 5.6 m north; buffer 3 m → sublinks too far → no match."""
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike()), max_lateral_dist_m=3.0,
        )
        assert link_pairs == []

    def test_wide_buffer_matches(self):
        """Buffer 50 m comfortably captures the 5.6 m offset BIKE."""
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike()), max_lateral_dist_m=50.0,
        )
        assert len(link_pairs) == 1

    def test_link_pair_fields(self):
        """link_pairs entry has all expected keys."""
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), _bike()))
        lp = link_pairs[0]
        assert lp["carLinkId"]   == "C1"
        assert lp["bikeLinkId"]  == "B1"
        assert lp["isReverse"]   is False
        assert lp["chainLength"] == 1

    def test_stats_keys_present(self):
        _, _, _, stats = fuse_networks(_fc(_car(), _bike()))
        for key in ("car_links", "bike_links", "bike_eligible", "link_pairs",
                    "skipped_wegtype", "skipped_speed", "reverse_matches", "fused_bike"):
            assert key in stats, f"missing stats key: {key}"

    def test_reverse_matches_stat(self):
        bike_rev = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                         lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, _, stats = fuse_networks(_fc(_car(), bike_rev))
        assert stats["reverse_matches"] == 1

    def test_both_directions_matched_simultaneously(self):
        """One forward and one reversed BIKE alongside the same CAR → two pairs."""
        bike_fwd = _bike(link_id="B_FWD")
        bike_rev = _bike(link_id="B_REV",
                         lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                         lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT)
        _, _, link_pairs, stats = fuse_networks(_fc(_car(), bike_fwd, bike_rev))
        assert len(link_pairs) == 2
        assert stats["reverse_matches"] == 1


# ---------------------------------------------------------------------------
# Overlap fraction threshold
# ---------------------------------------------------------------------------

class TestOverlapFraction:
    """Tests that exercise ``min_overlap_fraction``."""

    def test_insufficient_overlap_not_matched(self):
        """BIKE shifted 41 m east → only ~40% of BIKE sub-links overlap → no match."""
        # The shifted bike partially overlaps the car in longitude but ≈ 40 % < 60 %.
        bike_east = _bike(
            lon_s=_CAR_LON_S + 0.0006, lon_e=_CAR_LON_E + 0.0006,
        )
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), bike_east))
        assert link_pairs == []

    def test_lower_threshold_allows_partial_overlap(self):
        """Same geometry but min_overlap_fraction=0.30 → match."""
        bike_east = _bike(
            lon_s=_CAR_LON_S + 0.0006, lon_e=_CAR_LON_E + 0.0006,
        )
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), bike_east),
            min_overlap_fraction=0.30,
        )
        assert len(link_pairs) == 1

    def test_direction_mismatch_prevents_match(self):
        """A zigzag CAR whose sub-links are nearly perpendicular is never matched."""
        # Zigzag: (5.0,52.0) → (5.0005,52.005) → (5.001,52.0).
        # Both segments run NE/SE — direction ≈ (0.06, ±1) — far from (1,0).
        car_zigzag = {
            "type": "Feature",
            "geometry": {
                "type": "LineString",
                "coordinates": [
                    [_CAR_LON_S, _CAR_LAT],
                    [(_CAR_LON_S + _CAR_LON_E) / 2, _CAR_LAT + 0.005],   # ≈ 556 m north
                    [_CAR_LON_E, _CAR_LAT],
                ],
            },
            "properties": {
                "mode": "CAR", "fromNode": "100", "toNode": "101", "linkId": "C_ZZ",
                "max_snelheid_heen":  30.0,
                "max_snelheid_terug": 30.0,
            },
        }
        _, _, link_pairs, _ = fuse_networks(_fc(car_zigzag, _bike()))
        assert link_pairs == []


# ---------------------------------------------------------------------------
# Excluded wegtype filter
# ---------------------------------------------------------------------------

class TestExcludedWegtype:
    @pytest.mark.parametrize("wegtype", sorted(_EXCLUDED_WEGTYPES))
    def test_excluded_wegtype_not_matched(self, wegtype: str):
        _, _, link_pairs, stats = fuse_networks(_fc(_car(), _bike(wegtype=wegtype)))
        assert link_pairs == []
        assert stats["skipped_wegtype"] == 1
        assert stats["bike_eligible"]   == 0

    def test_normal_wegtype_matched(self):
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), _bike(wegtype="rijbaan")))
        assert len(link_pairs) == 1

    def test_no_wegtype_property_matched(self):
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), _bike()))
        assert len(link_pairs) == 1

    def test_disable_filter_with_empty_frozenset(self):
        """excluded_wegtypes=frozenset() disables the filter entirely."""
        _, _, link_pairs, _ = fuse_networks(
            _fc(_car(), _bike(wegtype="solitair_fietspad")),
            excluded_wegtypes=frozenset(),
        )
        assert len(link_pairs) == 1


# ---------------------------------------------------------------------------
# Multiple BIKE links per CAR link
# ---------------------------------------------------------------------------

class TestMultipleBikePerCar:
    def test_two_bike_links_both_matched(self):
        """Two BIKE links alongside one CAR link — both are fused."""
        bike1 = _bike(link_id="B1", lat_s=_CAR_LAT + 0.00003, lat_e=_CAR_LAT + 0.00003)
        bike2 = _bike(link_id="B2", lat_s=_CAR_LAT + 0.00006, lat_e=_CAR_LAT + 0.00006,
                      from_node="300", to_node="301")
        _, _, link_pairs, stats = fuse_networks(_fc(_car(), bike1, bike2))
        bike_ids = {lp["bikeLinkId"] for lp in link_pairs}
        assert "B1" in bike_ids
        assert "B2" in bike_ids
        assert stats["link_pairs"] == 2
        assert stats["fused_bike"] == 2

    def test_one_bike_too_far_one_close(self):
        """Only the BIKE within the 10 m buffer should be matched."""
        bike_close = _bike(link_id="CLOSE",
                           lat_s=_CAR_LAT + 0.00005, lat_e=_CAR_LAT + 0.00005)
        bike_far   = _bike(link_id="FAR",
                           lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002,
                           from_node="400", to_node="401")
        _, _, link_pairs, _ = fuse_networks(_fc(_car(), bike_close, bike_far))
        assert len(link_pairs) == 1
        assert link_pairs[0]["bikeLinkId"] == "CLOSE"


# ---------------------------------------------------------------------------
# Geometry replacement
# ---------------------------------------------------------------------------

class TestGeometryReplacement:
    def _get_bike(self, fc: dict) -> dict:
        return next(f for f in fc["features"] if f["properties"]["mode"] == "BIKE")

    def test_bike_geometry_replaced_with_car_geometry(self):
        """After fusing, the BIKE coordinates match the CAR coordinates exactly."""
        fc = _fc(_car(), _bike())
        fuse_networks(fc)
        bike_coords = self._get_bike(fc)["geometry"]["coordinates"]
        car_coords  = _car()["geometry"]["coordinates"]
        assert len(bike_coords) == len(car_coords) == 2
        for i in range(2):
            assert abs(bike_coords[i][0] - car_coords[i][0]) < 1e-9
            assert abs(bike_coords[i][1] - car_coords[i][1]) < 1e-9

    def test_curved_car_geometry_fully_transferred(self):
        """A 3-coord curved CAR → the fused BIKE gets all 3 coordinates."""
        fc = _fc(_car_curved(), _bike())
        fuse_networks(fc)
        bike_coords = self._get_bike(fc)["geometry"]["coordinates"]
        car_coords  = _car_curved()["geometry"]["coordinates"]
        assert len(bike_coords) == 3
        for i in range(3):
            assert abs(bike_coords[i][0] - car_coords[i][0]) < 1e-9
            assert abs(bike_coords[i][1] - car_coords[i][1]) < 1e-9

    def test_reversed_bike_gets_reversed_car_geometry(self):
        """Westbound BIKE (isReverse=True) → geometry is the reversed CAR coords."""
        bike_rev = _bike(lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
                         lon_e=_BIKE_LON_S, lat_e=_BIKE_LAT, link_id="BREV")
        fc = _fc(_car(), bike_rev)
        fuse_networks(fc)
        bike_coords = self._get_bike(fc)["geometry"]["coordinates"]
        car_coords  = list(reversed(_car()["geometry"]["coordinates"]))
        assert len(bike_coords) == 2
        for i in range(2):
            assert abs(bike_coords[i][0] - car_coords[i][0]) < 1e-9
            assert abs(bike_coords[i][1] - car_coords[i][1]) < 1e-9

    def test_unmatched_bike_geometry_unchanged(self):
        """A BIKE outside the 10 m buffer keeps its original geometry."""
        bike_far = _bike(lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002, link_id="BFAR",
                         from_node="900", to_node="901")
        orig_coords = [list(c) for c in bike_far["geometry"]["coordinates"]]
        fc = _fc(_car(), bike_far)
        fuse_networks(fc)
        bike_feat = next(f for f in fc["features"] if f["properties"]["linkId"] == "BFAR")
        assert bike_feat["geometry"]["coordinates"] == orig_coords

    def test_fused_bike_stat_correct(self):
        _, _, _, stats = fuse_networks(_fc(_car(), _bike()))
        assert stats["fused_bike"] == 1

    def test_unfused_bike_stat_is_zero(self):
        bike_far = _bike(lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002,
                         from_node="900", to_node="901")
        _, _, _, stats = fuse_networks(_fc(_car(), bike_far))
        assert stats["fused_bike"] == 0

    def test_fc_is_same_object(self):
        fc = _fc(_car(), _bike())
        out_fc, *_ = fuse_networks(fc)
        assert out_fc is fc


# ---------------------------------------------------------------------------
# Node propagation
# ---------------------------------------------------------------------------

class TestNodePropagation:
    def test_adjacent_bike_start_updated(self):
        """When BIKE-A is fused its toNode moves; BIKE-B sharing that node is updated."""
        # BIKE-A: N1 → N2, running alongside CAR C1.
        bike_a = _bike(
            lon_s=_BIKE_LON_S, lat_s=_BIKE_LAT,
            lon_e=_BIKE_LON_E, lat_e=_BIKE_LAT,
            link_id="BA", from_node="N1", to_node="N2",
        )
        # BIKE-B: N2 → N3, no matching CAR (continues east past the CAR extent).
        bike_b = _bike(
            lon_s=_BIKE_LON_E, lat_s=_BIKE_LAT,
            lon_e=_BIKE_LON_E + 0.001, lat_e=_BIKE_LAT,
            link_id="BB", from_node="N2", to_node="N3",
        )
        fc = _fc(_car(), bike_a, bike_b)
        fuse_networks(fc)

        feat_a = next(f for f in fc["features"] if f["properties"]["linkId"] == "BA")
        feat_b = next(f for f in fc["features"] if f["properties"]["linkId"] == "BB")
        car_coords = _car()["geometry"]["coordinates"]

        # BIKE-A should be on the CAR latitude.
        assert abs(feat_a["geometry"]["coordinates"][0][1] - _CAR_LAT) < 1e-9
        assert abs(feat_a["geometry"]["coordinates"][-1][1] - _CAR_LAT) < 1e-9

        # BIKE-B's start (node N2) should have moved to the CAR end position.
        b_start = feat_b["geometry"]["coordinates"][0]
        assert abs(b_start[0] - car_coords[-1][0]) < 1e-9
        assert abs(b_start[1] - car_coords[-1][1]) < 1e-9

        # BIKE-B's end (node N3) should be unchanged.
        b_end = feat_b["geometry"]["coordinates"][-1]
        assert abs(b_end[0] - (_BIKE_LON_E + 0.001)) < 1e-9
        assert abs(b_end[1] - _BIKE_LAT) < 1e-9

    def test_adjacent_bike_end_updated(self):
        """When BIKE-A is fused its fromNode moves; BIKE-C whose toNode is same is updated."""
        # BIKE-A: N1 → N2 (fused).
        bike_a = _bike(
            lon_s=_BIKE_LON_S, lat_s=_BIKE_LAT,
            lon_e=_BIKE_LON_E, lat_e=_BIKE_LAT,
            link_id="BA", from_node="N1", to_node="N2",
        )
        # BIKE-C: N0 → N1, approaching from the west (no matching CAR).
        bike_c = _bike(
            lon_s=_BIKE_LON_S - 0.001, lat_s=_BIKE_LAT,
            lon_e=_BIKE_LON_S,          lat_e=_BIKE_LAT,
            link_id="BC", from_node="N0", to_node="N1",
        )
        fc = _fc(_car(), bike_a, bike_c)
        fuse_networks(fc)

        feat_c = next(f for f in fc["features"] if f["properties"]["linkId"] == "BC")
        car_coords = _car()["geometry"]["coordinates"]

        # BIKE-C's end (node N1) must now point to the CAR start position.
        c_end = feat_c["geometry"]["coordinates"][-1]
        assert abs(c_end[0] - car_coords[0][0]) < 1e-9
        assert abs(c_end[1] - car_coords[0][1]) < 1e-9

        # BIKE-C's start (node N0) must be unchanged.
        c_start = feat_c["geometry"]["coordinates"][0]
        assert abs(c_start[0] - (_BIKE_LON_S - 0.001)) < 1e-9
        assert abs(c_start[1] - _BIKE_LAT) < 1e-9


# ---------------------------------------------------------------------------
# Constant sanity checks
# ---------------------------------------------------------------------------

class TestConstants:
    def test_speed_limit_positive(self):
        assert _SPEED_LIMIT_MAX_KMH > 0

    def test_excluded_wegtypes_non_empty(self):
        assert len(_EXCLUDED_WEGTYPES) > 0


# ---------------------------------------------------------------------------
# carLinkIds property on BIKE features
# ---------------------------------------------------------------------------

class TestCarLinkIds:
    def _get_feature(self, fc: dict, link_id: str) -> dict:
        return next(f for f in fc["features"] if f["properties"].get("linkId") == link_id)

    def test_fused_bike_gets_car_link_ids(self):
        """A matched BIKE feature must carry carLinkIds = ['C1'] after fusing."""
        fc = _fc(_car(link_id="C1"), _bike(link_id="B1"))
        fuse_networks(fc)
        bike = self._get_feature(fc, "B1")
        assert bike["properties"].get("carLinkIds") == ["C1"]

    def test_unmatched_bike_has_no_car_link_ids(self):
        """A BIKE that was not fused must not have a carLinkIds property."""
        bike_far = _bike(link_id="BFAR",
                         lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002,
                         from_node="900", to_node="901")
        fc = _fc(_car(), bike_far)
        fuse_networks(fc)
        bike = self._get_feature(fc, "BFAR")
        assert "carLinkIds" not in bike["properties"]

    def test_car_link_ids_contains_correct_id(self):
        """carLinkIds on the fused BIKE must reference the exact CAR linkId."""
        fc = _fc(_car(link_id="MY_CAR"), _bike(link_id="MY_BIKE"))
        fuse_networks(fc)
        bike = self._get_feature(fc, "MY_BIKE")
        assert bike["properties"]["carLinkIds"] == ["MY_CAR"]

    def test_two_bikes_each_get_car_link_ids(self):
        """Both BIKE links get carLinkIds when fused onto the same CAR link."""
        bike1 = _bike(link_id="B1", lat_s=_CAR_LAT + 0.00003, lat_e=_CAR_LAT + 0.00003)
        bike2 = _bike(link_id="B2", lat_s=_CAR_LAT + 0.00006, lat_e=_CAR_LAT + 0.00006,
                      from_node="300", to_node="301")
        fc = _fc(_car(link_id="C1"), bike1, bike2)
        fuse_networks(fc)
        for lid in ("B1", "B2"):
            feat = self._get_feature(fc, lid)
            assert feat["properties"].get("carLinkIds") == ["C1"], f"{lid} missing carLinkIds"

    def test_fused_bike_on_twoway_car_has_car_oneway_false(self):
        """A BIKE snapped to a two-way CAR road must have carOneway=False."""
        fc = _fc(_car(link_id="C1", oneway=False), _bike(link_id="B1"))
        fuse_networks(fc)
        bike = self._get_feature(fc, "B1")
        assert bike["properties"].get("carOneway") is False

    def test_fused_bike_on_oneway_car_has_car_oneway_true(self):
        """A BIKE snapped to a one-way CAR road must have carOneway=True."""
        fc = _fc(_car(link_id="C1", oneway=True), _bike(link_id="B1"))
        fuse_networks(fc)
        bike = self._get_feature(fc, "B1")
        assert bike["properties"].get("carOneway") is True

    def test_unmatched_bike_has_no_car_oneway(self):
        """A BIKE that was not fused must not have a carOneway property."""
        bike_far = _bike(link_id="BFAR",
                         lat_s=_CAR_LAT + 0.002, lat_e=_CAR_LAT + 0.002,
                         from_node="900", to_node="901")
        fc = _fc(_car(), bike_far)
        fuse_networks(fc)
        bike = self._get_feature(fc, "BFAR")
        assert "carOneway" not in bike["properties"]

    def test_car_missing_rijrichting_defaults_to_twoway(self):
        """A CAR without rijrichting properties should be treated as two-way (carOneway=False)."""
        car_no_rr = {
            "type": "Feature",
            "geometry": {"type": "LineString",
                         "coordinates": [[_CAR_LON_S, _CAR_LAT], [_CAR_LON_E, _CAR_LAT]]},
            "properties": {"mode": "CAR", "fromNode": "100", "toNode": "101", "linkId": "C1",
                           "max_snelheid_heen": 30.0, "max_snelheid_terug": 30.0},
        }
        fc = _fc(car_no_rr, _bike(link_id="B1"))
        fuse_networks(fc)
        bike = self._get_feature(fc, "B1")
        assert bike["properties"].get("carOneway") is False
