"""Local debug runner for network_fuser.

Reads a merged multi-mode network GeoJSON, calls ``fuse_networks()`` directly,
writes the corrected network back and saves the NODE-MAP and LINK-PAIRS sidecar
files alongside it.

Usage
-----
    python -m network_fuser.network_fuser_runner \\
        --network /tmp/uuid-NETWORK-MIXED.parquet \\
        --output-folder /tmp/fused/

    # S3 input (corrected network written back in-place, sidecars next to it):
    python -m network_fuser.network_fuser_runner \\
        --network s3://gmp-networks/uuid-NETWORK-MIXED.parquet

Prerequisites
-------------
* AWS credentials available in the environment or a tools/.env file
  (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------

def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------

def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------

def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split  # noqa: PLC0415
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


def _s3_sibling(network_uri: str, filename: str) -> str:
    """Return an S3 URI in the same prefix as *network_uri* but with *filename*."""
    prefix = network_uri.rsplit("/", 1)[0]
    return f"{prefix}/{filename}"


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for network_fuser (calls fuse_networks() directly)."
    )
    parser.add_argument(
        "--network",
        required=True,
        metavar="URI",
        help="Full URI of the merged multi-mode network GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--output-folder",
        metavar="URI",
        default=None,
        help=(
            "Output folder for the corrected network and sidecar files.  "
            "Defaults to the same folder as --network.  "
            "For S3 inputs the corrected network is always written back in-place; "
            "use this flag to redirect sidecar files to a different prefix."
        ),
    )
    parser.add_argument(
        "--area-id",
        metavar="UUID",
        default=None,
        help="Area UUID; derived from the filename when omitted.",
    )
    parser.add_argument(
        "--mode-label",
        metavar="LABEL",
        default=None,
        help="Mode label used in sidecar filenames (e.g. MIXED).  Derived from network properties.",
    )
    parser.add_argument(
        "--max-lateral-dist",
        type=float,
        default=15.0,
        metavar="M",
        help=(
            "Maximum average perpendicular distance (metres) between a BIKE link "
            "and the infinite CAR line for them to be paired (default: 15.0)."
        ),
    )
    parser.add_argument(
        "--max-heading-diff",
        type=float,
        default=30.0,
        metavar="DEG",
        help=(
            "Maximum heading difference (degrees) between a CAR and BIKE link "
            "for them to be considered running in the same direction (default: 30.0)."
        ),
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file) if args.env_file
        else next(
            (p / "tools" / ".env" for p in Path(__file__).resolve().parents
             if (p / "tools" / ".env").exists()),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from network_fuser.core.network_fuser_core import fuse_networks  # noqa: PLC0415
    from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: PLC0415

    in_uri = args.network
    print(f"Reading  : {in_uri}")
    fc = from_geoparquet(_read_uri(in_uri))

    # Derive area_id and mode_label from filename / properties if not supplied.
    area_id = args.area_id
    if not area_id:
        area_id = (fc.get("properties") or {}).get("area_id")
        if not area_id:
            basename = os.path.basename(in_uri.rstrip("/"))
            area_id  = basename.split("-NETWORK")[0] or "unknown"

    mode_label = args.mode_label
    if not mode_label:
        mode_label = (fc.get("properties") or {}).get("modeLabel", "MIXED")

    # Call core
    corrected_fc, node_map, link_pairs, stats = fuse_networks(
        fc,
        max_lateral_dist_m   = args.max_lateral_dist,
        max_heading_diff_deg = args.max_heading_diff,
    )
    print(
        f"  car_links={stats['car_links']}  bike_links={stats['bike_links']}  "
        f"bike_eligible={stats['bike_eligible']}  link_pairs={stats['link_pairs']}  "
        f"skipped_wegtype={stats['skipped_wegtype']}"
    )

    # Determine output base URI
    if args.output_folder:
        out_base = args.output_folder.rstrip("/")
        net_out_uri = f"{out_base}/{os.path.basename(in_uri.rstrip('/'))}"
    else:
        # Write back to the same location.
        net_out_uri  = in_uri
        if in_uri.startswith("s3://"):
            out_base = in_uri.rsplit("/", 1)[0]
        else:
            out_base = str(Path(in_uri.removeprefix("file://")).parent)

    # Write outputs
    print(f"Writing  : {net_out_uri}")
    _write_uri(net_out_uri, to_geoparquet(corrected_fc))

    if mode_label != "MIXED":
        node_map_filename   = f"{area_id}-NODE-MAP-{mode_label}.json"
        link_pairs_filename = f"{area_id}-LINK-PAIRS-{mode_label}.json"

        if out_base.startswith("s3://"):
            node_map_uri   = f"{out_base}/{node_map_filename}"
            link_pairs_uri = f"{out_base}/{link_pairs_filename}"
        else:
            node_map_uri   = str(Path(out_base) / node_map_filename)
            link_pairs_uri = str(Path(out_base) / link_pairs_filename)

        print(f"Writing  : {node_map_uri}")
        _write_uri(node_map_uri, json.dumps(node_map, ensure_ascii=False).encode("utf-8"))

        print(f"Writing  : {link_pairs_uri}")
        _write_uri(link_pairs_uri, json.dumps(link_pairs, ensure_ascii=False).encode("utf-8"))
    else:
        print("Skipping NODE-MAP and LINK-PAIRS sidecars for MIXED mode label.")

    print("Done.")


if __name__ == "__main__":
    main()
