"""Unit tests for route_applier_core."""

from __future__ import annotations

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from route_applier.core.route_applier_core import add_od_flows


def _add(network_fc, od_fc, min_link_trips=0.0):
    """Unpack the (fc, report) tuple and return just the FeatureCollection."""
    fc, _ = add_od_flows(network_fc, od_fc, min_link_trips=min_link_trips)
    return fc


# ---------------------------------------------------------------------------
# Fixture helpers
# ---------------------------------------------------------------------------


def _net_feature(from_node, to_node, flow=0.0, coords=None):
    if coords is None:
        coords = [[0.0, 0.0], [1.0, 0.0]]
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "fromNode": from_node,
            "toNode": to_node,
            "speed": 50.0,
            "length": 100.0,
            "capacity": 500.0,
            "flow": flow,
        },
    }


def _route(node_path, trips, travel_time=10.0):
    """Build a single route entry with a nodePath and per-route trips."""
    return {
        "travelTime": travel_time,
        "distance": 100.0,
        "remainingCap": 400.0,
        "trips": trips,
        "nodePath": node_path,
        "linkPath": [],
    }


def _od_feature(from_id, to_id, total_trips, routes):
    """Build an OD feature with explicit per-route trip splits."""
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {
            "fromId": from_id,
            "toId": to_id,
            "fromZoneId": from_id,
            "toZoneId": to_id,
            "fromType": "node",
            "toType": "zone",
            "trips": total_trips,
            "routes": routes,
        },
    }


def _od_single(from_id, to_id, trips, node_path):
    """Convenience: OD feature with one route taking all trips."""
    return _od_feature(from_id, to_id, trips, [_route(node_path, trips)])


def _make_fc(features):
    return {"type": "FeatureCollection", "features": features}


# ---------------------------------------------------------------------------
# Tests: basic assignment
# ---------------------------------------------------------------------------


class TestAddOdFlows:
    def test_flow_added_to_traversed_link(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([_od_single("node1", "zone1", trips=100.0, node_path=["A", "B"])])
        result = _add(network_fc, od_fc)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(100.0)

    def test_flow_is_additive_on_existing_flow(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=50.0)])
        od_fc = _make_fc([_od_single("node1", "zone1", trips=100.0, node_path=["A", "B"])])
        result = _add(network_fc, od_fc)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(150.0)

    def test_untraversed_link_unchanged(self):
        network_fc = _make_fc([
            _net_feature("A", "B", flow=0.0),
            _net_feature("C", "D", flow=42.0),
        ])
        od_fc = _make_fc([_od_single("n", "z", trips=10.0, node_path=["A", "B"])])
        result = _add(network_fc, od_fc)
        assert result["features"][1]["properties"]["flow"] == pytest.approx(42.0)

    def test_multi_link_path(self):
        """Trips propagate to every link along the path."""
        network_fc = _make_fc([
            _net_feature("A", "B", flow=0.0),
            _net_feature("B", "C", flow=0.0),
        ])
        od_fc = _make_fc([_od_single("n", "z", trips=50.0, node_path=["A", "B", "C"])])
        result = _add(network_fc, od_fc)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(50.0)
        assert result["features"][1]["properties"]["flow"] == pytest.approx(50.0)

    def test_multiple_od_pairs_accumulate(self):
        """Two OD pairs traversing the same link → flows are summed."""
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([
            _od_single("n1", "z1", trips=30.0, node_path=["A", "B"]),
            _od_single("n2", "z2", trips=70.0, node_path=["A", "B"]),
        ])
        result = _add(network_fc, od_fc)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(100.0)

    def test_zero_trips_skipped(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=5.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=0.0, node_path=["A", "B"])])
        result = _add(network_fc, od_fc)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(5.0)

    def test_missing_node_path_skipped(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=5.0)])
        od_feature = {
            "type": "Feature",
            "geometry": None,
            "properties": {
                "fromId": "n", "toId": "z", "trips": 100.0,
                "routes": [{"travelTime": 1.0, "distance": 1.0, "remainingCap": 1.0,
                            "trips": 100.0}],
            },
        }
        od_fc = _make_fc([od_feature])
        result = _add(network_fc, od_fc)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(5.0)

    def test_virtual_zone_nodes_skipped(self):
        """Virtual zone nodes (Z_xxx) have no matching network link — ignored."""
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([
            _od_single("n", "z", trips=100.0, node_path=["Z_zone1", "A", "B", "Z_zone2"])
        ])
        result = _add(network_fc, od_fc)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(100.0)

    def test_original_network_not_mutated(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=99.0, node_path=["A", "B"])])
        _add(network_fc, od_fc)
        assert network_fc["features"][0]["properties"]["flow"] == 0.0

    def test_empty_od_returns_network_unchanged(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=10.0)])
        result = _add(network_fc, _make_fc([]))
        assert result["features"][0]["properties"]["flow"] == pytest.approx(10.0)

    def test_returns_feature_collection(self):
        network_fc = _make_fc([_net_feature("A", "B")])
        result = _add(network_fc, _make_fc([]))
        assert result["type"] == "FeatureCollection"


# ---------------------------------------------------------------------------
# Tests: multiple routes per OD pair
# ---------------------------------------------------------------------------


class TestMultipleRoutesPerPair:
    def test_all_routes_contribute_to_link(self):
        """Both routes of an OD pair use the same link — both trip shares are added."""
        network_fc = _make_fc([
            _net_feature("A", "B", flow=0.0),
            _net_feature("B", "C", flow=0.0),
        ])
        od_fc = _make_fc([
            _od_feature("n", "z", total_trips=100.0, routes=[
                _route(["A", "B"], trips=60.0),       # route 1 uses A→B
                _route(["A", "B", "C"], trips=40.0),  # route 2 uses A→B and B→C
            ])
        ])
        result = _add(network_fc, od_fc)
        # A→B: 60 + 40 = 100
        assert result["features"][0]["properties"]["flow"] == pytest.approx(100.0)
        # B→C: 40 only
        assert result["features"][1]["properties"]["flow"] == pytest.approx(40.0)

    def test_routes_from_different_pairs_accumulate_on_shared_link(self):
        """Multiple OD pairs, each with multiple routes, sum correctly on a shared link."""
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([
            _od_feature("n1", "z1", total_trips=100.0, routes=[
                _route(["A", "B"], trips=70.0),
                _route(["A", "B"], trips=30.0),
            ]),
            _od_feature("n2", "z2", total_trips=50.0, routes=[
                _route(["A", "B"], trips=50.0),
            ]),
        ])
        result = _add(network_fc, od_fc)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(150.0)


# ---------------------------------------------------------------------------
# Tests: addedFlow property
# ---------------------------------------------------------------------------


class TestAddedFlowProperty:
    def test_added_flow_set_on_updated_link(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=10.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=40.0, node_path=["A", "B"])])
        result = _add(network_fc, od_fc)
        props = result["features"][0]["properties"]
        assert props["addedFlow"] == pytest.approx(40.0)

    def test_added_flow_absent_on_untouched_link(self):
        network_fc = _make_fc([
            _net_feature("A", "B", flow=0.0),
            _net_feature("C", "D", flow=5.0),
        ])
        od_fc = _make_fc([_od_single("n", "z", trips=10.0, node_path=["A", "B"])])
        result = _add(network_fc, od_fc)
        assert "addedFlow" not in result["features"][1]["properties"]

    def test_added_flow_reflects_sum_of_all_route_contributions(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([
            _od_feature("n", "z", total_trips=100.0, routes=[
                _route(["A", "B"], trips=60.0),
                _route(["A", "B"], trips=40.0),
            ])
        ])
        result = _add(network_fc, od_fc)
        assert result["features"][0]["properties"]["addedFlow"] == pytest.approx(100.0)


# ---------------------------------------------------------------------------
# Tests: min_link_trips threshold
# ---------------------------------------------------------------------------


class TestMinLinkTrips:
    def test_link_above_threshold_is_updated(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=10.0, node_path=["A", "B"])])
        result = _add(network_fc, od_fc, min_link_trips=5.0)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(10.0)

    def test_link_below_threshold_is_not_updated(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=20.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=3.0, node_path=["A", "B"])])
        result = _add(network_fc, od_fc, min_link_trips=5.0)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(20.0)
        assert "addedFlow" not in result["features"][0]["properties"]

    def test_threshold_applied_after_summation(self):
        """Two routes each contribute 3 trips to the same link (total 6 >= threshold 5)."""
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([
            _od_feature("n", "z", total_trips=6.0, routes=[
                _route(["A", "B"], trips=3.0),
                _route(["A", "B"], trips=3.0),
            ])
        ])
        result = _add(network_fc, od_fc, min_link_trips=5.0)
        # sum 6 >= 5 → link is updated
        assert result["features"][0]["properties"]["flow"] == pytest.approx(6.0)

    def test_zero_threshold_updates_all_links(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=0.001, node_path=["A", "B"])])
        result = _add(network_fc, od_fc, min_link_trips=0.0)
        assert result["features"][0]["properties"]["flow"] == pytest.approx(0.001)


# ---------------------------------------------------------------------------
# Tests: report
# ---------------------------------------------------------------------------


class TestFlowReport:
    def test_report_returned_as_list(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=10.0, node_path=["A", "B"])])
        _, report = add_od_flows(network_fc, od_fc)
        assert isinstance(report, list)

    def test_report_has_one_entry_per_assigned_route(self):
        # One OD pair with two routes → two report entries
        network_fc = _make_fc([
            _net_feature("A", "B", flow=0.0),
            _net_feature("B", "C", flow=0.0),
        ])
        od_fc = _make_fc([
            _od_feature("n", "z", total_trips=100.0, routes=[
                _route(["A", "B"], trips=60.0),
                _route(["A", "B", "C"], trips=40.0),
            ])
        ])
        _, report = add_od_flows(network_fc, od_fc)
        assert len(report) == 2

    def test_report_entry_has_required_keys(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=5.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=10.0, node_path=["A", "B"])])
        _, report = add_od_flows(network_fc, od_fc)
        entry = report[0]
        for key in ("fromId", "toId", "trips", "travelTime", "distance", "linkPath", "nodePath"):
            assert key in entry

    def test_report_entry_values_correct(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=20.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=30.0, node_path=["A", "B"])])
        _, report = add_od_flows(network_fc, od_fc)
        entry = report[0]
        assert entry["fromId"] == "n"
        assert entry["toId"] == "z"
        assert entry["trips"] == pytest.approx(30.0)
        assert entry["nodePath"] == ["A", "B"]

    def test_report_sorted_descending_by_trips(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=0.0)])
        od_fc = _make_fc([
            _od_feature("n", "z", total_trips=100.0, routes=[
                _route(["A", "B"], trips=30.0),
                _route(["A", "B"], trips=70.0),
            ])
        ])
        _, report = add_od_flows(network_fc, od_fc)
        assert report[0]["trips"] >= report[1]["trips"]

    def test_report_empty_when_no_routes(self):
        network_fc = _make_fc([_net_feature("A", "B", flow=5.0)])
        _, report = add_od_flows(network_fc, _make_fc([]))
        assert report == []

    def test_report_still_returned_when_all_links_below_threshold(self):
        # Routes are reported even if their links fall below min_link_trips
        network_fc = _make_fc([_net_feature("A", "B", flow=5.0)])
        od_fc = _make_fc([_od_single("n", "z", trips=1.0, node_path=["A", "B"])])
        _, report = add_od_flows(network_fc, od_fc, min_link_trips=10.0)
        assert len(report) == 1
        assert report[0]["trips"] == pytest.approx(1.0)

