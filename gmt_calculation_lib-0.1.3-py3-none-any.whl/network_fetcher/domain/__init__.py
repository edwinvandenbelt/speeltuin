# src/network_fetcher/domain/__init__.py
