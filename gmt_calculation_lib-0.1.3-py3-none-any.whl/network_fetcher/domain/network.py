"""GeoJSON network assembly for network_fetcher — no I/O, no boto3.

Converts raw Databricks result rows into a GeoJSON FeatureCollection.

The output is a **bidirectional** NETWORK-RAW file.  Each Feature represents a
physical link with two potential travel directions (heen = forward, terug = return).
The downstream ``bidirectional_splitter`` converts these into directed NETWORK
features with glossary-compliant field names (capacity, lanes, speed, …).
"""

from __future__ import annotations

import json
import logging

from network_fetcher.domain.sql import _MOTIEF_KEYS, _DAYPART_KEYS

logger = logging.getLogger(__name__)

# Ordered list of property keys present on every Feature in the NETWORK-RAW output.
# These are intermediate fields; the bidirectional_splitter maps them to the
# glossary-compliant directed fields (capacity, lanes, speed, flow, …).
LINK_PROPERTIES: tuple[str, ...] = (
    "linkId",              # physical link ID (Spectrum segment ID)
    "mode",                # transport mode: CAR | BIKE | PEDESTRIAN | BUS | TRAM | METRO | TRAIN
    "fromNode",            # origin node ID (forward / heen direction)
    "toNode",              # destination node ID (forward / heen direction)
    "rijrichting_heen",    # forward direction passable (bool)
    "cap_heen",            # capacity in forward direction (pae/hr)
    "rijstroken_heen",     # number of lanes in forward direction
    "max_snelheid_heen",   # design speed in forward direction (km/h)
    "flow_heen",           # dict: {work, recreational, education, shopping, unknown} — daily forward flows
    "flow_dp_heen",        # dict: {mrh, erh, rest} — pae/hr per daypart, forward direction
    "rijrichting_terug",   # return direction passable (bool)
    "cap_terug",           # capacity in return direction (pae/hr)
    "rijstroken_terug",    # number of lanes in return direction
    "max_snelheid_terug",  # design speed in return direction (km/h)
    "flow_terug",          # dict: {work, recreational, education, shopping, unknown} — daily return flows
    "flow_dp_terug",       # dict: {mrh, erh, rest} — pae/hr per daypart, return direction
    "length",              # link length in metres
)


def rows_to_feature_collection(rows: list[tuple], col_names: list[str], mode: str) -> dict:
    """Build a GeoJSON FeatureCollection from raw Databricks result rows.

    Parameters
    ----------
    rows:
        Raw result rows from Databricks (list of tuples).
    col_names:
        Column names matching the row tuple positions.
    mode:
        Transport mode string (e.g. ``"CAR"``, ``"BIKE"``).

    Returns
    -------
    dict
        GeoJSON FeatureCollection with one Feature per row.
        Flat ``flow_heen_{motief}`` columns are folded into a ``flow_heen`` dict.
        Flat ``flow_dp_heen_{daypart}`` columns are folded into a ``flow_dp_heen`` dict.
    """
    features = []
    for row in rows:
        record    = dict(zip(col_names, row))
        geom_val  = record.pop("geom")
        geom      = json.loads(geom_val) if isinstance(geom_val, str) else geom_val
        record["flow_heen"]     = {k: record.pop(f"flow_heen_{k}",  0) for k in _MOTIEF_KEYS}
        record["flow_terug"]    = {k: record.pop(f"flow_terug_{k}", 0) for k in _MOTIEF_KEYS}
        record["flow_dp_heen"]  = {k: record.pop(f"flow_dp_heen_{k}",  0) for k in _DAYPART_KEYS}
        record["flow_dp_terug"] = {k: record.pop(f"flow_dp_terug_{k}", 0) for k in _DAYPART_KEYS}

        # BIKE: ensure every passable direction has a daily flow of at least 1 so
        # the bidirectional_splitter does not discard links that have no model
        # assignment.  The Spectrum assignment table (d181) often has no rows for
        # bike links; the LEFT JOIN in the SQL then produces all-zero flows.
        # rijrichting_heen/terug is the authoritative passability signal for BIKE.
        if mode == "BIKE":
            if bool(record.get("rijrichting_heen")) and sum(record["flow_heen"].values()) == 0:
                record["flow_heen"]["unknown"] = 1
            if bool(record.get("rijrichting_terug")) and sum(record["flow_terug"].values()) == 0:
                record["flow_terug"]["unknown"] = 1
        features.append({
            "type":       "Feature",
            "geometry":   geom,
            "properties": record,
        })
    fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "modes": [mode],
            "fields": list(LINK_PROPERTIES),
        },
    }
    logger.debug("Assembled FeatureCollection: %d features", len(features))
    return fc
