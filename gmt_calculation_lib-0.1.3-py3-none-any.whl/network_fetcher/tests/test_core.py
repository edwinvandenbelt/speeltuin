"""Unit tests for network_fetcher core — pure Python, no I/O."""

from __future__ import annotations

import json

import pytest

from network_fetcher.core.network_fetcher_core import (
    _DAYPART_KEYS,
    _MOTIEF_KEYS,
    _PT_PARAMS,
    VALID_MODES,
    build_intersection_sql,
    filter_network_fc,
    get_pt_params,
    rows_to_feature_collection,
)


# ---------------------------------------------------------------------------
# build_intersection_sql
# ---------------------------------------------------------------------------


class TestBuildIntersectionSql:
    def test_car_contains_db_prefix(self):
        sql = build_intersection_sql("CAR", "spectrum", "2024_01")
        assert "spectrum.`2024_01`.d110_toedeelbaar_autonetwerk" in sql

    def test_bike_contains_fiets_table(self):
        sql = build_intersection_sql("BIKE", "spectrum", "2023_01")
        assert "d120_toedeelbaar_fietsnetwerk" in sql

    def test_pedestrian_uses_catalog_dot_pedestrians(self):
        sql = build_intersection_sql("PEDESTRIAN", "spectrum", "2025_12")
        assert "loopstromenmodel.`2025_12`.intensiteiten_voetgangers_202512" in sql
        assert "ST_StartPoint" in sql
        assert "ST_EndPoint" in sql

    @pytest.mark.parametrize("mode", ["BUS", "TRAM", "METRO", "TRAIN"])
    def test_pt_modes_contain_ov_table(self, mode):
        sql = build_intersection_sql(mode, "spectrum", "2023_01")
        assert "d140_toedeelbaar_ov_netwerk_links" in sql

    def test_car_has_single_placeholder(self):
        sql = build_intersection_sql("CAR", "spectrum", "2023_01")
        assert sql.count("?") == 1

    def test_bike_has_single_placeholder(self):
        sql = build_intersection_sql("BIKE", "spectrum", "2023_01")
        assert sql.count("?") == 1

    def test_pedestrian_has_single_placeholder(self):
        sql = build_intersection_sql("PEDESTRIAN", "spectrum", "2023_01")
        assert sql.count("?") == 1

    @pytest.mark.parametrize("mode", ["BUS", "TRAM", "METRO", "TRAIN"])
    def test_pt_has_four_placeholders(self, mode):
        sql = build_intersection_sql(mode, "spectrum", "2023_01")
        assert sql.count("?") == 4

    def test_invalid_mode_raises(self):
        with pytest.raises(ValueError, match="Unsupported mode"):
            build_intersection_sql("HELICOPTER", "spectrum", "2023_01")

    def test_all_valid_modes_accepted(self):
        for mode in VALID_MODES:
            sql = build_intersection_sql(mode, "spectrum", "2023_01")
            assert "?" in sql

    def test_catalog_schema_in_sql_car(self):
        sql = build_intersection_sql("CAR", "mycatalog", "2025_01")
        assert "mycatalog.`2025_01`" in sql

    def test_default_weight_rest_is_20(self):
        for mode in ("CAR", "BIKE"):
            sql = build_intersection_sql(mode, "spectrum", "2023_01")
            assert "20.0" in sql, f"Default rest weight 20.0 not found in {mode} SQL"

    def test_default_weight_rest_pt(self):
        for mode in ("BUS", "TRAM", "METRO", "TRAIN"):
            sql = build_intersection_sql(mode, "spectrum", "2023_01")
            assert "20.0" in sql, f"Default rest weight 20.0 not found in {mode} SQL"

    # ------------------------------------------------------------------
    # Schema-specific geometry expressions
    # ------------------------------------------------------------------

    @pytest.mark.parametrize("mode", ["CAR", "BIKE"])
    def test_2024_01_uses_geom_28992_column(self, mode):
        """2024_01 uses geom_28992 (native geometry in RD), no ST_GeomFromEWKB."""
        sql = build_intersection_sql(mode, "spectrum", "2024_01")
        assert "geom_28992" in sql
        assert "ST_GeomFromEWKB" not in sql
        assert "ST_Transform(ST_GeomFromGeoJSON(?), 28992)" in sql

    @pytest.mark.parametrize("mode", ["CAR", "BIKE"])
    def test_2024_01_length_uses_geom_28992_directly(self, mode):
        """Length in 2024_01 uses geom_28992 directly (already in metres/RD)."""
        sql = build_intersection_sql(mode, "spectrum", "2024_01")
        assert "ST_Length(geom_28992)" in sql

    @pytest.mark.parametrize("mode", ["CAR", "BIKE"])
    def test_other_schema_uses_geometry_ewkb(self, mode):
        """Non-2024_01 schemas use the EWKB `geometry` column in RD."""
        sql = build_intersection_sql(mode, "spectrum", "2025_01")
        assert "ST_Transform(ST_GeomFromGeoJSON(?), 28992)" in sql
        assert "ST_Transform(geometry, 4326)" in sql
        assert "geom_4326" not in sql

    def test_custom_weights_in_sql(self):
        sql = build_intersection_sql(
            "CAR",
            "spectrum",
            "2023_01",
            weights={"mrh": 3.0, "erh": 1.5, "rest": 8.0},
        )
        assert "3.0" in sql
        assert "1.5" in sql
        assert "8.0" in sql
        assert "13.72" not in sql

    def test_custom_weights_do_not_affect_dp_columns(self):
        """Daypart-intensity columns (flow_dp_*) are raw pae/hr — unaffected by weights."""
        sql = build_intersection_sql(
            "CAR",
            "spectrum",
            "2023_01",
            weights={"mrh": 99.0, "erh": 99.0, "rest": 99.0},
        )
        assert "flow_dp_heen_mrh" in sql
        assert "flow_dp_heen_rest" in sql

    def test_flow_pivot_columns_present(self):
        sql = build_intersection_sql("CAR", "spectrum", "2023_01")
        for key in _MOTIEF_KEYS:
            assert f"flow_heen_{key}" in sql
            assert f"flow_terug_{key}" in sql

    def test_daypart_pivot_columns_present(self):
        for mode in ("CAR", "BIKE"):
            sql = build_intersection_sql(mode, "spectrum", "2023_01")
            for dp in _DAYPART_KEYS:
                assert f"flow_dp_heen_{dp}" in sql, f"Missing flow_dp_heen_{dp} in {mode} SQL"
                assert f"flow_dp_terug_{dp}" in sql, f"Missing flow_dp_terug_{dp} in {mode} SQL"

    def test_daypart_pivot_columns_present_pedestrian(self):
        sql = build_intersection_sql("PEDESTRIAN", "spectrum", "2023_01")
        for dp in _DAYPART_KEYS:
            assert f"flow_dp_heen_{dp}" in sql
            assert f"flow_dp_terug_{dp}" in sql

    @pytest.mark.parametrize("mode", ["BUS", "TRAM", "METRO", "TRAIN"])
    def test_daypart_pivot_columns_present_pt(self, mode):
        sql = build_intersection_sql(mode, "spectrum", "2023_01")
        for dp in _DAYPART_KEYS:
            assert f"flow_dp_heen_{dp}" in sql
            assert f"flow_dp_terug_{dp}" in sql


# ---------------------------------------------------------------------------
# get_pt_params
# ---------------------------------------------------------------------------


class TestGetPtParams:
    @pytest.mark.parametrize(
        "mode,link_mode,modaliteit",
        [
            ("BUS", "other", "bus"),
            ("TRAM", "other", "tram"),
            ("METRO", "other", "metro"),
            ("TRAIN", "train", "trein"),
        ],
    )
    def test_known_modes(self, mode, link_mode, modaliteit):
        lm, mod = get_pt_params(mode)
        assert lm == link_mode
        assert mod == modaliteit

    def test_unknown_raises_key_error(self):
        with pytest.raises(KeyError):
            get_pt_params("FERRY")


# ---------------------------------------------------------------------------
# rows_to_feature_collection
# ---------------------------------------------------------------------------


class TestRowsToFeatureCollection:
    def _make_rows(self):
        """Return (rows, col_names) for a minimal two-row result."""
        geom_str = json.dumps({"type": "LineString", "coordinates": [[0, 0], [1, 1]]})
        col_names = (
            [
                "segment_id",
                "geom",
                "mode",
                "from_node",
                "to_node",
                "rijrichting_heen",
                "cap_heen",
                "rijstroken_heen",
                "max_snelheid_heen",
            ]
            + [f"flow_heen_{k}" for k in _MOTIEF_KEYS]
            + ["rijrichting_terug", "cap_terug", "rijstroken_terug", "max_snelheid_terug"]
            + [f"flow_terug_{k}" for k in _MOTIEF_KEYS]
            + [f"flow_dp_heen_{k}" for k in _DAYPART_KEYS]
            + [f"flow_dp_terug_{k}" for k in _DAYPART_KEYS]
            + ["length"]
        )
        row = (
            1,
            geom_str,
            "CAR",
            10,
            20,
            True,
            2000,
            2,
            80,
            100.0,
            50.0,
            0.0,
            0.0,
            0.0,
            80.0,
            40.0,
            0.0,
            0.0,
            0.0,
            True,
            2000,
            2,
            80,
            # daypart heen: mrh, erh, rest
            60.0,
            50.0,
            30.0,
            # daypart terug: mrh, erh, rest
            45.0,
            40.0,
            25.0,
            150.0,
        )
        return [row, row], col_names

    def test_returns_feature_collection(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        assert fc["type"] == "FeatureCollection"
        assert len(fc["features"]) == 2

    def test_flow_pivot_folded(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert "flow_heen" in props
        assert "flow_terug" in props
        assert props["flow_heen"]["work"] == 100.0

    def test_daypart_pivot_folded(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert "flow_dp_heen" in props
        assert "flow_dp_terug" in props
        assert props["flow_dp_heen"]["mrh"] == 60.0
        assert props["flow_dp_terug"]["rest"] == 25.0

    def test_geom_is_parsed(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        geom = fc["features"][0]["geometry"]
        assert geom["type"] == "LineString"

    def test_geom_column_removed_from_props(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert "geom" not in props

    def test_empty_rows(self):
        fc = rows_to_feature_collection([], ["segment_id", "geom", "mode"], "CAR")
        assert fc["features"] == []

    def test_modes_in_properties(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "BIKE")
        assert fc["properties"]["modes"] == ["BIKE"]

    def test_link_properties_in_properties(self):
        rows, col_names = self._make_rows()
        fc = rows_to_feature_collection(rows, col_names, "CAR")
        assert "fields" in fc["properties"]
        assert isinstance(fc["properties"]["fields"], list)


# ---------------------------------------------------------------------------
# BIKE minimum-flow floor
# ---------------------------------------------------------------------------


class TestBikeFlowFloor:
    """rows_to_feature_collection must set flow >= 1 for every passable
    direction on BIKE links so the bidirectional_splitter does not discard them.
    """

    def _bike_row(self, *, heen: bool, terug: bool, flow_heen: float = 0, flow_terug: float = 0):
        """Build a single BIKE row with the given passability flags and flows."""
        geom_str = json.dumps({"type": "LineString", "coordinates": [[0, 0], [1, 1]]})
        col_names = (
            [
                "linkId",
                "geom",
                "mode",
                "fromNode",
                "toNode",
                "rijrichting_heen",
                "cap_heen",
                "rijstroken_heen",
                "max_snelheid_heen",
            ]
            + [f"flow_heen_{k}" for k in _MOTIEF_KEYS]
            + ["rijrichting_terug", "cap_terug", "rijstroken_terug", "max_snelheid_terug"]
            + [f"flow_terug_{k}" for k in _MOTIEF_KEYS]
            + [f"flow_dp_heen_{k}" for k in _DAYPART_KEYS]
            + [f"flow_dp_terug_{k}" for k in _DAYPART_KEYS]
            + ["length"]
        )
        # Distribute the requested flow into the "unknown" motive bucket.
        heen_flows = [flow_heen, 0, 0, 0, 0]  # work, recreational, education, shopping, unknown
        terug_flows = [flow_terug, 0, 0, 0, 0]
        row = (
            1,
            geom_str,
            "BIKE",
            10,
            20,
            heen,
            1000,
            1,
            15,
            *heen_flows,
            terug,
            1000,
            1,
            15,
            *terug_flows,
            0.0,
            0.0,
            0.0,  # dp heen
            0.0,
            0.0,
            0.0,  # dp terug
            50.0,
        )
        return [row], col_names

    def test_zero_flow_heen_gets_floor_of_1(self):
        rows, col_names = self._bike_row(heen=True, terug=False)
        fc = rows_to_feature_collection(rows, col_names, "BIKE")
        props = fc["features"][0]["properties"]
        assert sum(props["flow_heen"].values()) >= 1

    def test_zero_flow_terug_gets_floor_of_1(self):
        rows, col_names = self._bike_row(heen=False, terug=True)
        fc = rows_to_feature_collection(rows, col_names, "BIKE")
        props = fc["features"][0]["properties"]
        assert sum(props["flow_terug"].values()) >= 1

    def test_both_directions_get_floor(self):
        rows, col_names = self._bike_row(heen=True, terug=True)
        fc = rows_to_feature_collection(rows, col_names, "BIKE")
        props = fc["features"][0]["properties"]
        assert sum(props["flow_heen"].values()) >= 1
        assert sum(props["flow_terug"].values()) >= 1

    def test_non_passable_direction_not_floored(self):
        """rijrichting_terug=False → terug flow stays 0 (link would be dropped by splitter)."""
        rows, col_names = self._bike_row(heen=True, terug=False)
        fc = rows_to_feature_collection(rows, col_names, "BIKE")
        props = fc["features"][0]["properties"]
        assert sum(props["flow_terug"].values()) == 0

    def test_existing_flow_not_overwritten(self):
        """Links with actual flow data must not be modified."""
        rows, col_names = self._bike_row(heen=True, terug=True, flow_heen=42, flow_terug=7)
        fc = rows_to_feature_collection(rows, col_names, "BIKE")
        props = fc["features"][0]["properties"]
        assert props["flow_heen"]["work"] == 42
        assert props["flow_terug"]["work"] == 7

    def test_car_links_not_affected(self):
        """CAR links with zero flow must NOT be floored — the splitter should drop them."""
        geom_str = json.dumps({"type": "LineString", "coordinates": [[0, 0], [1, 1]]})
        col_names = (
            [
                "linkId",
                "geom",
                "mode",
                "fromNode",
                "toNode",
                "rijrichting_heen",
                "cap_heen",
                "rijstroken_heen",
                "max_snelheid_heen",
            ]
            + [f"flow_heen_{k}" for k in _MOTIEF_KEYS]
            + ["rijrichting_terug", "cap_terug", "rijstroken_terug", "max_snelheid_terug"]
            + [f"flow_terug_{k}" for k in _MOTIEF_KEYS]
            + [f"flow_dp_heen_{k}" for k in _DAYPART_KEYS]
            + [f"flow_dp_terug_{k}" for k in _DAYPART_KEYS]
            + ["length"]
        )
        row = (
            1,
            geom_str,
            "CAR",
            10,
            20,
            True,
            2000,
            2,
            80,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,  # all zero heen flows
            True,
            2000,
            2,
            80,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,  # all zero terug flows
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            0.0,
            100.0,
        )
        fc = rows_to_feature_collection([row], col_names, "CAR")
        props = fc["features"][0]["properties"]
        assert sum(props["flow_heen"].values()) == 0
        assert sum(props["flow_terug"].values()) == 0


# ---------------------------------------------------------------------------
# filter_network_fc
# ---------------------------------------------------------------------------


def _make_fc(*features: dict) -> dict:
    """Wrap a sequence of feature dicts into a FeatureCollection."""
    return {"type": "FeatureCollection", "features": list(features)}


def _make_link(
    link_id: int = 1,
    max_snelheid_heen: float = 50.0,
    max_snelheid_terug: float = 50.0,
    flow_heen: dict | None = None,
    flow_terug: dict | None = None,
) -> dict:
    """Minimal Feature dict with speed and flow properties."""
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
        "properties": {
            "linkId": link_id,
            "max_snelheid_heen": max_snelheid_heen,
            "max_snelheid_terug": max_snelheid_terug,
            "flow_heen": flow_heen if flow_heen is not None else {"work": 100.0},
            "flow_terug": flow_terug if flow_terug is not None else {"work": 100.0},
        },
    }


class TestFilterNetworkFc:
    def test_no_filters_returns_all(self):
        fc = _make_fc(_make_link(1), _make_link(2))
        out_fc, stats = filter_network_fc(fc)
        assert len(out_fc["features"]) == 2
        assert stats == {"input": 2, "removed_speed": 0, "removed_flow": 0, "kept": 2}

    def test_speed_filter_removes_fast_links(self):
        slow = _make_link(1, max_snelheid_heen=50.0, max_snelheid_terug=50.0)
        fast = _make_link(2, max_snelheid_heen=120.0, max_snelheid_terug=120.0)
        fc = _make_fc(slow, fast)
        out_fc, stats = filter_network_fc(fc, max_speed_kmh=90.0)
        assert len(out_fc["features"]) == 1
        assert out_fc["features"][0]["properties"]["linkId"] == 1
        assert stats["removed_speed"] == 1
        assert stats["removed_flow"] == 0
        assert stats["kept"] == 1

    def test_speed_filter_uses_max_of_both_directions(self):
        """A link where only one direction exceeds the threshold is still removed."""
        link = _make_link(1, max_snelheid_heen=50.0, max_snelheid_terug=100.0)
        fc = _make_fc(link)
        out_fc, stats = filter_network_fc(fc, max_speed_kmh=90.0)
        assert len(out_fc["features"]) == 0
        assert stats["removed_speed"] == 1

    def test_flow_filter_removes_high_flow_links(self):
        low_flow = _make_link(1, flow_heen={"work": 500.0}, flow_terug={"work": 500.0})
        high_flow = _make_link(2, flow_heen={"work": 1500.0}, flow_terug={"work": 1500.0})
        fc = _make_fc(low_flow, high_flow)
        out_fc, stats = filter_network_fc(fc, max_flow=2000.0)
        assert len(out_fc["features"]) == 1
        assert out_fc["features"][0]["properties"]["linkId"] == 1
        assert stats["removed_flow"] == 1
        assert stats["removed_speed"] == 0

    def test_combined_filters(self):
        ok = _make_link(1, max_snelheid_heen=50.0, flow_heen={"work": 100.0})
        too_fast = _make_link(2, max_snelheid_heen=120.0, flow_heen={"work": 100.0})
        too_much_flow = _make_link(3, max_snelheid_heen=50.0, flow_heen={"work": 5000.0})
        fc = _make_fc(ok, too_fast, too_much_flow)
        out_fc, stats = filter_network_fc(fc, max_speed_kmh=90.0, max_flow=2000.0)
        assert len(out_fc["features"]) == 1
        assert out_fc["features"][0]["properties"]["linkId"] == 1
        assert stats["removed_speed"] == 1
        assert stats["removed_flow"] == 1
        assert stats["kept"] == 1

    def test_stats_input_count_correct(self):
        fc = _make_fc(_make_link(1), _make_link(2), _make_link(3))
        _, stats = filter_network_fc(fc, max_speed_kmh=90.0)
        assert stats["input"] == 3

    def test_feature_collection_metadata_preserved(self):
        fc = {
            "type": "FeatureCollection",
            "properties": {"modes": ["CAR"]},
            "features": [_make_link(1)],
        }
        out_fc, _ = filter_network_fc(fc, max_speed_kmh=90.0)
        assert out_fc.get("properties") == {"modes": ["CAR"]}

    def test_empty_feature_collection(self):
        fc = _make_fc()
        out_fc, stats = filter_network_fc(fc, max_speed_kmh=90.0)
        assert out_fc["features"] == []
        assert stats == {"input": 0, "removed_speed": 0, "removed_flow": 0, "kept": 0}
