# src/network_fetcher/core/__init__.py
