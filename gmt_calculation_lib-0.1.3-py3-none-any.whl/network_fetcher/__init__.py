# src/network_fetcher/__init__.py
