"""Core for the flow-scaler Lambda.

Contains all pure-Python calculation logic: purpose-index loading, date
parsing, weather/temperature normalisation, bbox filtering, network pipeline
(filterNetwork / resolve_indexes_by_mode / applyIndices), and holiday-index loading.

Public API
----------
load_purpose_index(raw) -> dict[tuple, dict]
parse_date(raw) -> datetime.datetime | None
read_indexes(keys, purpose_index) -> dict[str, dict]
normalise_temperature(raw) -> str
normalise_weather(raw, dt, daylight_table) -> str
filterNetwork(network, bbox, offset, limit) -> FilteredNetwork
determineIndiceKeys(params, metadata) -> list[tuple]  (single-mode; kept for compat)
resolve_indexes_by_mode(params, filtered, purpose_index) -> dict[str, dict[str, dict]]
applyIndices(filtered_network, indexes_by_mode) -> dict
is_holiday_period(regio, mode, date, *, uri) -> bool

Pipeline
--------
    dt            = parse_date(date_str)
    temperature   = normalise_temperature(raw_temp)
    weather       = normalise_weather(raw_weather, dt, daylight_raw)
    purpose       = None if raw_purpose == "all" else raw_purpose.lower()
    purpose_index = load_purpose_index(purpose_index_raw)
    params        = Params(mode, dt, temperature, weather, regio, purpose)
    filtered      = filterNetwork(network_fc, bbox, offset, limit)
    filtered.params = params
    indexes_by_mode = resolve_indexes_by_mode(params, filtered, purpose_index)
    result          = applyIndices(filtered, indexes_by_mode)
"""

from __future__ import annotations

import copy
import csv
import datetime
import io
import logging
import os
from dataclasses import dataclass, field
from typing import Any
from zoneinfo import ZoneInfo

from janitor.core.janitor_core import clean_geojson as _clean_geojson

try:
    import boto3  # type: ignore
    _HAS_BOTO3 = True
except ImportError:  # pragma: no cover
    _HAS_BOTO3 = False

logger = logging.getLogger(__name__)

# The purpose index is keyed on local Dutch time (Europe/Amsterdam).
_TZ_AMSTERDAM = ZoneInfo("Europe/Amsterdam")

# ---------------------------------------------------------------------------
# Output schema
# ---------------------------------------------------------------------------

# Complete set of feature property keys present on every scaled-network feature
# after applyIndices runs.  Raw directional fields (cap_heen/terug, max_snelheid_heen/terug,
# rijstroken_heen/terug, rijrichting_heen/terug, from_node, to_node) are stripped by
# add_values; flow_heen / flow_terug / trip_lengths are stripped by FLOW_STRIP.
# Note: "mode" is intentionally NOT stripped by add_values so that per-link mode
# dispatch works correctly in mixed-modal networks.
SCALED_LINK_PROPERTIES: tuple[str, ...] = (
    "spectrumId",       # original Spectrum segment identifier
    "linkId",           # directed link identifier
    "mode",             # transport mode of this link (CAR / BIKE / PEDESTRIAN / …)
    "length",            # link length in metres
    "heading",           # compass heading (degrees)
    "reverseLinkIds",   # linkIds of anti-parallel / reverse-direction links
    "flow24hrs",        # raw 24-hour flow (pre-scaling)
    "capacity",          # combined heen+terug capacity (PAE/hr) — added by add_values
    "speed",            # max of heen/terug free-flow speeds — added by add_values
    "lanes",             # sum of heen+terug lanes — added by add_values
    "flow",              # scalar indexed flow (purpose-filtered or total) — added by _apply_flow
    "index",            # effective scaling factor applied to produce 'flow' — added by _apply_flow
    "kilometers",        # vehicle-kilometres (flow × length / 1000) — added by _apply_flow
    "flowTemporalUnit",  # hours represented by the flow value (1 when date supplied, 24 otherwise)
)

# Schema for the janitor step: retain only these two properties in the final output.
_JANITOR_SCHEMA: dict = {"flow": None, "linkId": None}

# ---------------------------------------------------------------------------
# Purpose index
# ---------------------------------------------------------------------------


def load_purpose_index(raw: list[dict]) -> dict[tuple, dict]:
    """Convert the raw S3/inline array to a lookup dict keyed by a parsed tuple.

    Input element::

        {"key": "work|CAR|2|8|Medium|Cloudy Light", "index": 1.23, "dist": [...]}

    Output::

        {("work", "CAR", 2, 8, "Medium", "Cloudy Light"): {"index": 1.23, "dist": [...]}}

    Elements whose ``key`` field does not have exactly 6 ``|``-separated parts,
    or whose day/hour fields are not integers, are silently skipped.
    """
    result: dict[tuple, dict] = {}
    for entry in raw:
        k = entry.get("key", "")
        parts = k.split("|")
        if len(parts) != 6:
            continue
        motiv, mode, day, hour, temp, weather = parts
        try:
            tuple_key = (motiv, mode, int(day), int(hour), temp, weather)
        except ValueError:
            continue
        v: dict = {"index": float(entry.get("index", 1.0))}
        if "dist" in entry:
            v["dist"] = [float(x) for x in entry["dist"]]
        result[tuple_key] = v
    return result


# ---------------------------------------------------------------------------
# Index lookup
# ---------------------------------------------------------------------------


def read_indexes(
    keys: list[tuple],
    purpose_index: dict[tuple, dict],
) -> dict[str, dict]:
    """Look up each key in *purpose_index* and return {motiv: entry}.

    Parameters
    ----------
    keys:
        As returned by ``determineIndiceKeys``.  Each tuple has the form
        ``(motiv, mode_key, java_day, hour, temperature, weather)``.
    purpose_index:
        As returned by ``load_purpose_index``.

    Returns
    -------
    dict mapping motiv name → index entry dict (with ``"index"`` and optional
    ``"dist"`` keys).  Missing keys fall back to ``{"index": 1.0}`` (identity).
    An empty dict is returned when *keys* is empty, signalling that no date
    was supplied; ``applyIndices`` then uses raw flow values.
    """
    if not keys:
        return {}
    result: dict[str, dict] = {}
    for key in keys:
        motiv = key[0]
        entry = purpose_index.get(key)
        if entry is not None:
            result[motiv] = entry
        else:
            result.setdefault(motiv, {"index": 1.0})
    return result


# ---------------------------------------------------------------------------
# Date parsing
# ---------------------------------------------------------------------------


def parse_date(
    raw: str | None,
    tz: ZoneInfo = _TZ_AMSTERDAM,
) -> datetime.datetime | None:
    """Parse an ISO-8601 datetime string and return it in the given local timezone.

    The purpose index is keyed on local time (hour, weekday), so any
    timezone-aware input (e.g. a ``Z``-suffix UTC timestamp) is converted to
    *tz* before being returned.  Naïve strings (no offset) are treated as
    already being in *tz* and are returned unchanged.

    Parameters
    ----------
    raw:
        ISO-8601 string, or None / empty string.
    tz:
        Target timezone for index key extraction.  Defaults to
        ``Europe/Amsterdam``.

    Accepted formats:
        - ``2025-06-21T05:00:00Z``       → converted from UTC to *tz*
        - ``2025-06-21T05:00:00+00:00``  → converted from UTC to *tz*
        - ``2025-06-21T09:00:00+02:00``  → converted to *tz*
        - ``2025-06-21T09:00:00``        → treated as *tz* local, returned as-is
        - ``2025-06-21``                 → midnight in *tz*

    Returns None when *raw* is absent or cannot be parsed.
    """
    if not raw:
        return None
    s = raw.strip()
    # Normalise Z → +00:00 so fromisoformat can parse it (Python < 3.11 does
    # not accept the Z suffix in fromisoformat).
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.datetime.fromisoformat(s)
    except ValueError:
        logger.warning("Could not parse date: %s", raw)
        return None
    # Convert any timezone-aware datetime to local time so that
    # .hour and .weekday() reflect the time used to key the index.
    if dt.tzinfo is not None:
        return dt.astimezone(tz)
    return dt


# ---------------------------------------------------------------------------
# Holiday / low-travel period detection
# ---------------------------------------------------------------------------

_DEFAULT_HOLIDAY_BUCKET = "gmp-networks"
_DEFAULT_HOLIDAY_KEY = "indices/holiday_indices.csv"
_TRIP_INDEX_THRESHOLD = 0.85

# Module-level CSV cache (one load per cold start / process lifetime)
_csv_cache: dict[tuple[str, str], list[dict[str, str]]] = {}


def _load_uri(uri: str) -> list[dict[str, str]]:
    """Return rows of a holiday-index CSV from a full URI string.

    Handles ``s3://bucket/key`` as well as plain local filesystem paths.
    Results are cached by URI for the lifetime of the process.
    """
    if uri.startswith("s3://"):
        without = uri[5:]
        bucket, _, key = without.partition("/")
        return _load_csv(bucket, key)
    cache_key = ("", uri)
    if cache_key in _csv_cache:
        return _csv_cache[cache_key]
    with open(uri, encoding="utf-8") as fh:
        raw: str = fh.read()
    logger.info("Loaded holiday_indices.csv from local path %s", uri)
    rows: list[dict[str, str]] = list(csv.DictReader(io.StringIO(raw)))
    _csv_cache[cache_key] = rows
    return rows


def _load_csv(bucket: str, key: str) -> list[dict[str, str]]:
    """Return rows of holiday_indices.csv as a list of dicts.

    Loads from S3 when boto3 is available; otherwise treats
    ``os.path.join(bucket, key)`` as a local filesystem path.
    Results are cached per *(bucket, key)* pair.
    """
    cache_key = (bucket, key)
    if cache_key in _csv_cache:
        return _csv_cache[cache_key]
    if not _HAS_BOTO3:
        path = os.path.join(bucket, key)
        with open(path, encoding="utf-8") as fh:
            raw = fh.read()
        logger.info("Loaded holiday_indices.csv from local path %s", path)
        rows: list[dict[str, str]] = list(csv.DictReader(io.StringIO(raw)))
        _csv_cache[cache_key] = rows
        return rows
    import boto3 as _boto3  # noqa: PLC0415
    obj = _boto3.client("s3").get_object(Bucket=bucket, Key=key)
    raw = obj["Body"].read().decode("utf-8")
    logger.info("Loaded holiday_indices.csv from s3://%s/%s", bucket, key)
    rows = list(csv.DictReader(io.StringIO(raw)))
    _csv_cache[cache_key] = rows
    return rows


def _clear_csv_cache() -> None:
    """Clear the module-level CSV cache.  Intended for use in tests."""
    _csv_cache.clear()


def _to_int(value: str) -> int | None:
    try:
        return int(value)
    except (ValueError, TypeError):
        return None


def _to_float(value: str) -> float | None:
    try:
        return float(value)
    except (ValueError, TypeError):
        return None


def is_holiday_period(regio: str, mode: str, date: datetime.date, *, uri: str = "") -> bool:
    """Return ``True`` when the region / mode / date falls in a holiday or low-travel period.

    The CSV row for the matching *(regio, trip_mode, weeknr)* combination is
    considered a holiday / low-travel period when **at least one** of the
    following conditions holds:

    * ``vakantie_am`` (the holiday name column) is non-empty, **or**
    * ``trip_index`` is strictly below 0.85.

    Parameters
    ----------
    regio:
        Region identifier, e.g. ``"midden"``, ``"noord"``, ``"zuid"``
        (case-insensitive).
    mode:
        Trip mode, e.g. ``"BIKE"``, ``"CAR"``, ``"FOOT"``, ``"OV"``
        (case-insensitive).
    date:
        Reference date; the ISO week number is derived via ``date.isocalendar()``.
    uri:
        Optional full URI (``s3://bucket/key`` or local path) for the holiday
        index CSV.  When supplied, overrides the ``INDICES_BUCKET`` /
        ``INDICES_KEY`` environment variables.
    """
    if uri:
        rows = _load_uri(uri)
    else:
        bucket = os.environ.get("INDICES_BUCKET", _DEFAULT_HOLIDAY_BUCKET)
        key = os.environ.get("INDICES_KEY", _DEFAULT_HOLIDAY_KEY)
        rows = _load_csv(bucket, key)

    week: int = date.isocalendar()[1]
    regio_norm = regio.lower()
    mode_norm = mode.upper()

    for row in rows:
        if (
            row.get("regio", "").lower() == regio_norm
            and row.get("trip_mode", "").upper() == mode_norm
            and _to_int(row.get("weeknr", "")) == week
        ):
            vakantie_naam = row.get("vakantie_am", "").strip()
            trip_index = _to_float(row.get("trip_index", ""))
            if vakantie_naam or (trip_index is not None and trip_index < _TRIP_INDEX_THRESHOLD):
                logger.debug(
                    "Holiday/low-travel: regio=%s mode=%s week=%d vakantie=%r trip_index=%s",
                    regio, mode, week, vakantie_naam, trip_index,
                )
                return True
            return False

    logger.warning("No CSV row found for regio=%r mode=%r week=%d", regio, mode, week)
    return False


# ---------------------------------------------------------------------------
# Weather and temperature normalisation
# Mirrors the Java PurposeBasedIndexApplier normalisation logic.
# ---------------------------------------------------------------------------

_TEMP_MAP: dict[str, str] = {
    "high": "High",
    "medium": "Medium",
    "low": "Low",
}


def normalise_temperature(raw: str | None) -> str:
    """Return a normalised temperature string; defaults to 'Medium'."""
    if raw is None:
        return "Medium"
    return _TEMP_MAP.get(raw.lower(), "Medium")


def is_daylight(dt: datetime.datetime, daylight_table: list[dict]) -> bool:
    """Return True if *dt* falls between sunrise and sunset for that month.

    *daylight_table* is a list of dicts::

        [{"month": 1, "sunrise_hour": 8, "sunset_hour": 17}, ...]

    If no matching month entry is found, assume daytime.
    """
    month = dt.month
    hour = dt.hour
    for entry in daylight_table:
        if entry.get("month") == month:
            return entry["sunrise_hour"] <= hour < entry["sunset_hour"]
    return True


def normalise_weather(
    raw: str | None,
    dt: datetime.datetime | None = None,
    daylight_table: list[dict] | None = None,
) -> str:
    """Return a normalised weather string.

    Mapping (case-insensitive input):
        sunny  -> "Sunny Light"
        cloudy -> "Cloudy Light"
        dry    -> "Dry Dark"
        rainy  -> "Rainy Light" or "Rainy Dark" (based on daylight)
        (default / missing) -> "Cloudy Light"
    """
    if raw is None:
        return "Cloudy Light"
    key = raw.lower().strip()
    if key == "sunny":
        return "Sunny Light"
    if key == "cloudy":
        return "Cloudy Light"
    if key == "dry":
        return "Dry Dark"
    if key == "rainy":
        if dt is not None and daylight_table:
            return "Rainy Light" if is_daylight(dt, daylight_table) else "Rainy Dark"
        return "Rainy Light"
    return "Cloudy Light"


# ---------------------------------------------------------------------------
# Bbox filter
# bbox = [minX, minY, maxX, maxY]  (WGS-84 lon/lat)
# A feature is included when ANY coordinate of its geometry falls inside bbox.
# ---------------------------------------------------------------------------

def _coords(geometry: dict) -> list[tuple[float, float]]:
    """Flatten all coordinates in a GeoJSON geometry to a list of (lon, lat)."""
    gtype = geometry.get("type", "")
    raw = geometry.get("coordinates", [])
    if gtype == "Point":
        return [tuple(raw[:2])]
    if gtype == "MultiPoint":
        return [tuple(c[:2]) for c in raw]
    if gtype == "LineString":
        return [tuple(c[:2]) for c in raw]
    if gtype == "MultiLineString":
        return [tuple(c[:2]) for seg in raw for c in seg]
    if gtype == "Polygon":
        return [tuple(c[:2]) for ring in raw for c in ring]
    if gtype == "MultiPolygon":
        return [tuple(c[:2]) for poly in raw for ring in poly for c in ring]
    if gtype == "GeometryCollection":
        result: list[tuple[float, float]] = []
        for geom in geometry.get("geometries", []):
            result.extend(_coords(geom))
        return result
    return []


def bbox_filter(features: list[dict], bbox: list[float] | None) -> list[dict]:
    """Return the subset of *features* whose geometry intersects *bbox*.

    If *bbox* is None or empty, all features are returned unchanged.
    """
    if not bbox:
        return features
    min_x, min_y, max_x, max_y = bbox[0], bbox[1], bbox[2], bbox[3]
    result: list[dict] = []
    for feature in features:
        geometry = feature.get("geometry")
        if geometry is None:
            continue
        for lon, lat in _coords(geometry):
            if min_x <= lon <= max_x and min_y <= lat <= max_y:
                result.append(feature)
                break
    return result


# ---------------------------------------------------------------------------
# Flow helpers
# ---------------------------------------------------------------------------

# Known motives (must match Java Purpose enum, lowercase)
KNOWN_MOTIVES: list[str] = ["work", "education", "shopping", "recreational", "unknown"]

# Output attribute names for the five known motives
MOTIVE_ATTR: dict[str, str] = {
    "work": "flowWork",
    "education": "flowEducation",
    "shopping": "flowShopping",
    "recreational": "flowRecreational",
    "unknown": "flowUnknown",
}

# Properties stripped by add_values
_ADD_VALUES_STRIP = {
    "cap_heen", "cap_terug",
    "max_snelheid_heen", "max_snelheid_terug",
    "rijstroken_heen", "rijstroken_terug",
    "rijrichting_heen", "rijrichting_terug",
    "fromNode", "toNode",
    # NOTE: "mode" is intentionally kept so that applyIndices can dispatch
    # per-link mode indices in mixed-modal networks.
}

# Properties stripped after flow calculation
FLOW_STRIP: frozenset[str] = frozenset({"flow_heen", "flow_terug", "trip_lengths"})

# Mode key mapping (mirrors Java constructKey)
_MODE_KEY_MAP: dict[str, str] = {
    "PEDESTRIAN": "FOOT",
    "BUS": "OV",
    "TRAIN": "OV",
    "TRAM": "OV",
    "METRO": "OV",
}


def mode_key(mode: str) -> str:
    """Map a transport mode string to the index key used in the purpose index."""
    return _MODE_KEY_MAP.get(mode.upper(), mode.upper())


def java_day(dt: datetime.datetime) -> int:
    """Convert Python datetime to Java day-of-week (0=Sun ... 6=Sat)."""
    return (dt.weekday() + 1) % 7


def check_holiday(day: int, holiday: bool) -> int:
    """Remap Mon-Fri (java_day 1-5) to Saturday (6) when holiday=True."""
    if holiday and 1 <= day <= 5:
        return 6
    return day


def _get_int(props: dict, key: str) -> int:
    """Return an integer property value, defaulting to 0 (mirrors Java getValue)."""
    val = props.get(key)
    if val is None:
        return 0
    if isinstance(val, (int, float)):
        return int(val)
    return 0


def add_values(features: list[dict]) -> None:
    """Mutate *features* in-place: compute capacity/max_speed/lanes, strip raw fields."""
    for feature in features:
        props: dict = feature.setdefault("properties", {})
        if "lane" in props:
            lane: int = int(props["lane"])
            if lane > 0:
                props["capacity"] = _get_int(props, "cap_heen")
                props["speed"] = _get_int(props, "max_snelheid_heen")
                props["lanes"] = _get_int(props, "rijstroken_heen")
            else:
                props["capacity"] = _get_int(props, "cap_terug")
                props["speed"] = _get_int(props, "max_snelheid_terug")
                props["lanes"] = _get_int(props, "rijstroken_terug")
        else:
            props["capacity"] = _get_int(props, "cap_heen") + _get_int(props, "cap_terug")
            props["speed"] = max(
                _get_int(props, "max_snelheid_heen"),
                _get_int(props, "max_snelheid_terug"),
            )
            props["lanes"] = _get_int(props, "rijstroken_heen") + _get_int(props, "rijstroken_terug")
        for key in _ADD_VALUES_STRIP:
            props.pop(key, None)


def _to_double(val: Any) -> float:
    """Safely convert a flow value to float (mirrors Java toDouble)."""
    if isinstance(val, (int, float)):
        return float(val)
    return 0.0


# ---------------------------------------------------------------------------
# Network pipeline dataclasses
# ---------------------------------------------------------------------------

@dataclass
class Params:
    """Per-request parameters that drive index key construction."""
    mode: str
    dt: datetime.datetime | None
    temperature: str
    weather: str
    regio: str
    purpose: str | None   # lowercase motive name, or None for ALL
    holiday_index: str = ""  # full URI for holiday_indices.csv; "" = use env vars


@dataclass
class NetworkMetadata:
    """Statistics about the filtered/paged network slice."""
    number_matched: int
    number_returned: int
    motives: frozenset[str]   # unique motives found in flow_heen/flow_terug on the page


@dataclass
class FilteredNetwork:
    """Result of filterNetwork(): a deep-copied page of features + metadata."""
    features: list[dict]
    metadata: NetworkMetadata
    params: Params | None = field(default=None)


# ---------------------------------------------------------------------------
# filterNetwork
# ---------------------------------------------------------------------------

def filterNetwork(
    network: dict,
    bbox: list[float] | None,
    offset: int,
    limit: int,
) -> FilteredNetwork:
    """Spatially filter, paginate, and deep-copy the network.

    Args:
        network: GeoJSON FeatureCollection dict.
        bbox:    [minX, minY, maxX, maxY] or None (no spatial filter).
        offset:  Page start index.
        limit:   Page size.

    Returns:
        FilteredNetwork with a deep-copied page of features and metadata.
    """
    raw_features: list[dict] = network.get("features", [])
    filtered = bbox_filter(raw_features, bbox)
    number_matched = len(filtered)
    page = filtered[offset: offset + limit]
    page_copy = [copy.deepcopy(f) for f in page]

    motives: set[str] = set()
    for feature in page_copy:
        props = feature.get("properties") or {}
        for direction in ("flow_heen", "flow_terug", "flowsPerMotive"):
            flow_map = props.get(direction)
            if isinstance(flow_map, dict):
                motives.update(flow_map.keys())

    metadata = NetworkMetadata(
        number_matched=number_matched,
        number_returned=len(page_copy),
        motives=frozenset(motives),
    )
    return FilteredNetwork(features=page_copy, metadata=metadata)


# ---------------------------------------------------------------------------
# determineIndiceKeys
# ---------------------------------------------------------------------------

def determineIndiceKeys(
    params: Params,
    metadata: NetworkMetadata,
) -> list[tuple]:
    """Build the list of index lookup keys for this request.

    Returns [] when params.dt is None (no index applicable).

    Each tuple has the form:
        (motiv, mode_key, java_day, hour, temperature, weather)
    """
    if params.dt is None:
        return []

    holiday = is_holiday_period(params.regio, params.mode, params.dt.date(), uri=params.holiday_index)
    day = check_holiday(java_day(params.dt), holiday)
    hour = params.dt.hour
    mode_k = mode_key(params.mode)

    motives_to_query: frozenset[str] | set[str]
    if params.purpose is not None:
        motives_to_query = {params.purpose}
    else:
        motives_to_query = metadata.motives

    return [
        (motiv, mode_k, day, hour, params.temperature, params.weather)
        for motiv in motives_to_query
    ]


# ---------------------------------------------------------------------------
# resolve_indexes_by_mode
# ---------------------------------------------------------------------------

def resolve_indexes_by_mode(
    params: Params,
    filtered: FilteredNetwork,
    purpose_index: dict[tuple, dict],
) -> dict[str, dict[str, dict]]:
    """Build per-mode index dicts for every link mode present in the network.

    For a single-mode network (all links share one mode) this is equivalent to
    calling ``determineIndiceKeys`` + ``read_indexes``.  For MIXED networks each
    distinct link mode gets its own scaled factors (CAR links → CAR indices,
    BIKE links → BIKE indices, etc.).

    Parameters
    ----------
    params:
        Per-request parameters.  When ``params.mode == "MIXED"``, ``"CAR"`` is
        used for the holiday-period lookup.
    filtered:
        FilteredNetwork as returned by ``filterNetwork`` (with ``.params`` set).
    purpose_index:
        As returned by ``load_purpose_index``.

    Returns
    -------
    ``dict[mode_key_str, {motiv: {"index": float, "dist"?: list}}]``.
    Returns ``{}`` when ``params.dt`` is None (no time-of-day scaling).
    """
    if params.dt is None:
        return {}

    # Holiday check: use CAR as representative mode for MIXED networks.
    holiday_mode = "CAR" if params.mode.upper() == "MIXED" else params.mode
    holiday = is_holiday_period(
        params.regio, holiday_mode, params.dt.date(), uri=params.holiday_index,
    )
    day  = check_holiday(java_day(params.dt), holiday)
    hour = params.dt.hour

    motives_to_query: frozenset[str] | set[str]
    if params.purpose is not None:
        motives_to_query = {params.purpose}
    else:
        motives_to_query = filtered.metadata.motives

    # Collect distinct mode keys from link properties.
    # Falls back to params.mode when no links carry a mode property.
    distinct_mode_keys: set[str] = set()
    for feature in filtered.features:
        m = (feature.get("properties") or {}).get("mode", "")
        if m:
            distinct_mode_keys.add(mode_key(m))
    if not distinct_mode_keys:
        distinct_mode_keys = {mode_key(params.mode)}

    result: dict[str, dict[str, dict]] = {}
    for mk in distinct_mode_keys:
        keys = [
            (motiv, mk, day, hour, params.temperature, params.weather)
            for motiv in motives_to_query
        ]
        result[mk] = read_indexes(keys, purpose_index)

    return result


# ---------------------------------------------------------------------------
# applyIndices
# ---------------------------------------------------------------------------

def applyIndices(
    filtered_network: FilteredNetwork,
    indexes_by_mode: dict[str, dict[str, dict]],
    *,
    run_cleaner: bool = True,
) -> dict:
    """Apply index factors to the filtered network and return a FeatureCollection.

    Args:
        filtered_network: Output of filterNetwork() with .params set.
        indexes_by_mode:  ``{mode_key: {motiv: {"index": float, "dist"?: list}}}``
                          as returned by ``resolve_indexes_by_mode``.
                          Pass ``{}`` when dt is None (raw flow, no scaling).
        run_cleaner:      When True (default), strip all feature properties
                          except ``flow`` and ``linkId`` via ``clean_geojson``.
                          Set to False to retain all computed properties on each
                          feature for debugging or downstream use.

    Returns:
        GeoJSON FeatureCollection dict with OGC numberMatched/numberReturned fields.
    """
    features = filtered_network.features
    metadata = filtered_network.metadata
    params = filtered_network.params

    purpose = params.purpose if params is not None else None
    dt = params.dt if params is not None else None

    # Convert raw index dicts to tuple form {mode_key: {motiv: (factor, dist)}}
    # for efficient access in _apply_flow.
    resolved_by_mode: dict[str, dict[str, tuple[float, list[float] | None]]] = {
        mk: {
            motiv: (float(v.get("index", 1.0)), v.get("dist"))
            for motiv, v in mode_indexes.items()
        }
        for mk, mode_indexes in indexes_by_mode.items()
    }

    # Fallback mode key for links that carry no mode property.
    fallback_mode_k: str
    if params is None:
        fallback_mode_k = "CAR"
    elif params.mode.upper() == "MIXED":
        fallback_mode_k = "CAR"
    else:
        fallback_mode_k = mode_key(params.mode)

    if features and "cap_heen" in (features[0].get("properties") or {}):
        add_values(features)

    _apply_flow(features, resolved_by_mode=resolved_by_mode, fallback_mode_k=fallback_mode_k,
                purpose=purpose, dt=dt)

    fc = {
        "type": "FeatureCollection",
        "crs": {
            "type": "name",
            "properties": {"name": "EPSG:4326"},
        },
        "number_matched": metadata.number_matched,
        "number_returned": metadata.number_returned,
        "features": features,
        "properties": {"fields": list(SCALED_LINK_PROPERTIES), "number_matched": metadata.number_matched},
    }

    if run_cleaner:
        fc, _ = _clean_geojson(fc, _JANITOR_SCHEMA)

    return fc


# ---------------------------------------------------------------------------
# Internal: _apply_flow / _sum_direction
# ---------------------------------------------------------------------------

def _apply_flow(
    features: list[dict],
    resolved_by_mode: dict[str, dict[str, tuple[float, list[float] | None]]],
    fallback_mode_k: str,
    purpose: str | None,
    dt: datetime.datetime | None,
) -> None:
    """Mutate *features* in-place: compute flow attributes, strip raw maps.

    For each feature the correct resolved-index dict is looked up from
    *resolved_by_mode* using the feature's own ``mode`` property.  When the
    feature has no ``mode`` property, *fallback_mode_k* is used instead.
    """
    for feature in features:
        props: dict = feature.setdefault("properties", {})

        # Per-link mode dispatch: pick the resolved dict matching this link's mode.
        feature_mk = mode_key(props.get("mode", "")) or fallback_mode_k
        resolved = resolved_by_mode.get(feature_mk) or resolved_by_mode.get(fallback_mode_k) or {}

        raw_heen: dict = props.get("flow_heen") or props.get("flowsPerMotive") or {}
        raw_terug: dict = props.get("flow_terug") or {}

        val_heen, motiv_heen = _sum_direction(props, "heen", resolved, purpose, dt is not None)
        val_terug, motiv_terug = _sum_direction(props, "terug", resolved, purpose, dt is not None)

        all_motives: dict[str, float] = {}
        for m, v in motiv_heen.items():
            all_motives[m] = all_motives.get(m, 0.0) + v
        for m, v in motiv_terug.items():
            all_motives[m] = all_motives.get(m, 0.0) + v

        # Write per-motive indexed flow attributes (all 5 known motives, 0.0 for absent)
        for motive, attr in MOTIVE_ATTR.items():
            props[attr] = all_motives.get(motive, 0.0)

        flow = val_heen + val_terug
        if flow == 0.0:
            flow = 1e-5  # mirrors Java

        props["flow"] = flow

        if dt is None:
            props["index"] = 1.0
        elif purpose is not None:
            entry = resolved.get(purpose)
            props["index"] = float(entry[0]) if entry is not None else 1.0
        else:
            # Flow-weighted average of per-motiv scalar factors
            weighted_sum = 0.0
            weight_total = 0.0
            for flow_map in (raw_heen, raw_terug):
                for motiv, raw_val in flow_map.items():
                    rv = _to_double(raw_val)
                    if rv == 0.0:
                        continue
                    entry = resolved.get(motiv)
                    factor = float(entry[0]) if entry is not None else 1.0
                    weighted_sum += factor * rv
                    weight_total += rv
            props["index"] = weighted_sum / weight_total if weight_total > 0.0 else 1.0

        length_raw = props.get("length")
        if length_raw is not None:
            try:
                props["kilometers"] = (float(length_raw) / 1000.0) * flow
            except (TypeError, ValueError):
                pass

        props["flowTemporalUnit"] = 24 if dt is None else 1

        for key in FLOW_STRIP:
            props.pop(key, None)


def _sum_direction(
    props: dict,
    label: str,
    resolved: dict[str, tuple[float, list[float] | None]],
    purpose: str | None,
    use_index: bool,
) -> tuple[float, dict[str, float]]:
    """Compute indexed flow for one direction ("heen" or "terug").

    Returns (total_for_direction, {motiv: indexed_flow}).
    """
    if "lane" in props:
        lane = int(props["lane"])
        if label == "heen" and lane < 0:
            return 0.0, {}
        if label == "terug" and lane > 0:
            return 0.0, {}
        lanes = int(props.get("lanes", 1))
    else:
        lanes = 1

    flow_map: dict | None = (
        props.get(f"flow_{label}") or
        (props.get("flowsPerMotive") if label == "heen" else None)
    )
    if flow_map is None:
        return 0.0, {}

    use_dist = "trip_lengths" in props
    trip_lengths: list[float] = props.get("trip_lengths", []) if use_dist else []

    totaal: float = 0.0
    per_motiv: dict[str, float] = {}

    for motiv, raw_flow in flow_map.items():
        if purpose is not None and purpose != motiv:
            continue

        flow_val = _to_double(raw_flow)

        if not use_index:
            totaal += flow_val
            per_motiv[motiv] = per_motiv.get(motiv, 0.0) + flow_val
            continue

        entry = resolved.get(motiv)
        if entry is None:
            indexed = flow_val
        else:
            factor, dist = entry
            if use_dist and dist is not None:
                f: float = 0.0
                for i, dcf in enumerate(dist):
                    if i < len(trip_lengths):
                        f += dcf * trip_lengths[i]
                    else:
                        f = factor
                        break
                indexed = f * flow_val
            else:
                indexed = factor * flow_val

        totaal += indexed
        per_motiv[motiv] = per_motiv.get(motiv, 0.0) + indexed

    divided = totaal / lanes
    per_motiv_divided = {m: v / lanes for m, v in per_motiv.items()}
    return divided, per_motiv_divided
