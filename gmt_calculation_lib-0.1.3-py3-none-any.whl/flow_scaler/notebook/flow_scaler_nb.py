# Databricks notebook source
# ---------------------------------------------------------------------------
# flow_scaler_nb.py — Databricks notebook interface for network scaling.
#
# This notebook:
#   1. Reads widget parameters (mode, date, temperature, weather, purpose, …).
#   2. Loads the network GeoJSON and scaling indices from S3 via boto3.
#   3. Calls pure functions from flow_scaler.flow_scaler_core and
#      flow_scaler.segments — no handler, no I/O inside the pipeline.
#   4. Writes the scaled FeatureCollection GeoJSON (and optionally GeoParquet)
#      to S3 or a local path.
#
# Requirements (Databricks cluster):
#   pip install boto3 geopandas pyarrow   (or attach via cluster library)
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
import os
import tempfile
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("flow_scaler_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3 geopandas pyarrow

# COMMAND ----------
# geopandas is optional — GeoParquet output is skipped when unavailable.
try:
    import geopandas as gpd
    from shapely.geometry import shape as _shapely_shape
    _HAS_GEOPANDAS = True
except ImportError:
    _HAS_GEOPANDAS = False
    logger.warning(
        "geopandas / pyarrow not installed — GeoParquet output will be skipped."
    )

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "mode", "",
    "Transport mode (CAR / BIKE / …) — leave empty to use first entry in network's 'modes' list",
)
dbutils.widgets.text(  # noqa: F821
    "date", "",
    "ISO-8601 datetime e.g. 2025-06-21T09:00:00Z — empty = no index scaling",
)
dbutils.widgets.text(  # noqa: F821
    "temperature", "medium",
    "Temperature class: high / medium / low",
)
dbutils.widgets.text(  # noqa: F821
    "weather", "cloudy",
    "Weather class: sunny / cloudy / dry / rainy",
)
dbutils.widgets.text(  # noqa: F821
    "purpose", "all",
    "Trip purpose: work / education / shopping / recreational / unknown / all",
)
dbutils.widgets.text(  # noqa: F821
    "bbox", "",
    "Bounding box — minX,minY,maxX,maxY in WGS-84 (empty = no spatial filter)",
)
dbutils.widgets.text(  # noqa: F821
    "limit", "1000",
    "Max features per response page (default 1000)",
)
dbutils.widgets.text(  # noqa: F821
    "offset", "0",
    "Page offset (default 0)",
)
dbutils.widgets.text(  # noqa: F821
    "network_uri", "",
    "Full URI for the network GeoJSON (s3://bucket/key  or  /dbfs/path)",
)
dbutils.widgets.text(  # noqa: F821
    "purpose_index_uri", "",
    "Full URI for purpose_index.json (s3://bucket/key  or  local path)",
)
dbutils.widgets.text(  # noqa: F821
    "daylight_uri", "",
    "Full URI for daylight.json (s3://bucket/key  or  local path)",
)
dbutils.widgets.text(  # noqa: F821
    "holiday_index_uri", "s3://gmp-networks/indices/holiday_indices.csv",
    "Full URI for holiday_indices.csv (s3://bucket/key  or  local path)",
)
dbutils.widgets.text(  # noqa: F821
    "output_folder", "",
    "Output folder: s3://bucket/prefix  or  /dbfs/path (required)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level: DEBUG / INFO / WARNING / ERROR",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from flow_scaler.core.flow_scaler_core import (  # noqa: E402
    load_purpose_index,
    parse_date,
    read_indexes,
    Params,
    applyIndices,
    determineIndiceKeys,
    filterNetwork,
    normalise_temperature,
    normalise_weather,
)

# COMMAND ----------
# ── Widget read + validation ──────────────────────────────────────────────────

_MODE_ARG      = dbutils.widgets.get("mode").strip().upper()                     # noqa: F821
DATE           = dbutils.widgets.get("date").strip() or ""                       # noqa: F821
TEMPERATURE    = dbutils.widgets.get("temperature").strip() or "medium"          # noqa: F821
WEATHER        = dbutils.widgets.get("weather").strip() or "cloudy"              # noqa: F821
PURPOSE        = dbutils.widgets.get("purpose").strip() or "all"                 # noqa: F821
LIMIT          = int(dbutils.widgets.get("limit").strip() or "1000")             # noqa: F821
OFFSET         = int(dbutils.widgets.get("offset").strip() or "0")               # noqa: F821
NETWORK_URI       = dbutils.widgets.get("network_uri").strip()        # noqa: F821
PURPOSE_INDEX_URI = dbutils.widgets.get("purpose_index_uri").strip()  # noqa: F821
DAYLIGHT_URI      = dbutils.widgets.get("daylight_uri").strip()       # noqa: F821
HOLIDAY_INDEX_URI = dbutils.widgets.get("holiday_index_uri").strip()  # noqa: F821
OUT_PATH          = dbutils.widgets.get("output_folder").strip()      # noqa: F821

if not OUT_PATH:
    raise ValueError("output_folder widget must not be empty.")
if not NETWORK_URI:
    raise ValueError("network_uri widget must not be empty.")
if not PURPOSE_INDEX_URI:
    raise ValueError("purpose_index_uri widget must not be empty.")
if not DAYLIGHT_URI:
    raise ValueError("daylight_uri widget must not be empty.")

BBOX: list[float] | None = None
_bbox_raw = dbutils.widgets.get("bbox").strip()  # noqa: F821
if _bbox_raw:
    try:
        BBOX = [float(x.strip()) for x in _bbox_raw.split(",")]
    except ValueError as _exc:
        raise ValueError(
            f"'bbox' must be four comma-separated numbers, got: {_bbox_raw!r}"
        ) from _exc
    if len(BBOX) != 4:
        raise ValueError(f"'bbox' must have exactly 4 values, got {len(BBOX)}.")

logger.info(
    "date=%s  temp=%s  weather=%s  purpose=%s",
    DATE or "(none)", TEMPERATURE, WEATHER, PURPOSE,
)
print(f"Date        : {DATE or '(none)'}")
print(f"Temperature : {TEMPERATURE}")
print(f"Weather     : {WEATHER}")
print(f"Purpose     : {PURPOSE}")
print(f"BBox        : {BBOX or '(none)'}")
print(f"Network     : {NETWORK_URI}")
print(f"Purpose Idx : {PURPOSE_INDEX_URI}")
print(f"Daylight    : {DAYLIGHT_URI}")

# COMMAND ----------
# ── I/O helpers ───────────────────────────────────────────────────────────────

def _s3_split(uri: str) -> tuple:
    without = uri[5:]
    bucket, _, prefix = without.partition("/")
    return bucket, prefix


def _put_s3(bucket: str, key: str, data: bytes, content_type: str) -> None:
    import boto3  # noqa: PLC0415
    boto3.client("s3").put_object(Bucket=bucket, Key=key, Body=data, ContentType=content_type)
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _output_dir() -> str:
    return OUT_PATH.rstrip("/")


def _write_geoparquet(fc: dict, out_dir: str, area_id: str, mode: str):
    if not _HAS_GEOPANDAS:
        logger.warning("geopandas not installed — skipping GeoParquet output.")
        return None
    filename = f"{area_id}-SCALED-NETWORK-{mode}.parquet"
    records = []
    for feat in fc["features"]:
        props = dict(feat["properties"])
        flow = props.pop("flow", {}) or {}
        if isinstance(flow, dict):
            for k, v in flow.items():
                props[f"flow_{k}"] = v
        try:
            props["geometry"] = _shapely_shape(feat["geometry"])
        except Exception as exc:
            logger.warning("Skipping feature with bad geometry: %s", exc)
            continue
        records.append(props)
    if not records:
        return None
    gdf = gpd.GeoDataFrame(records, crs="EPSG:4326")
    if out_dir.startswith("s3://"):
        with tempfile.NamedTemporaryFile(suffix=".parquet", delete=False) as tmp:
            tmp_path = tmp.name
        try:
            gdf.to_parquet(tmp_path)
            bucket, prefix = _s3_split(out_dir)
            key = f"{prefix}/{filename}".lstrip("/")
            with open(tmp_path, "rb") as fh:
                _put_s3(bucket, key, fh.read(), "application/octet-stream")
            return f"s3://{bucket}/{key}"
        finally:
            os.unlink(tmp_path)
    fp = os.path.join(out_dir, filename)
    gdf.to_parquet(fp)
    logger.info("Wrote %s  (%d features)", fp, len(gdf))
    return fp

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Network Scaling
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ────────────────────────────────────────────────────────────

import boto3  # noqa: E402

_t_start = datetime.now(timezone.utc)
logger.info("Starting network scaling at %s", _t_start.isoformat())


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        _bucket, _key = uri[5:].split("/", 1)
        return boto3.client("s3").get_object(Bucket=_bucket, Key=_key)["Body"].read()
    with open(uri, "rb") as _fh:
        return _fh.read()


# 1. Load network GeoJSON
logger.info("Reading network from %s", NETWORK_URI)
_net_raw = json.loads(_read_uri(NETWORK_URI))
_network = (
    _net_raw
    if isinstance(_net_raw, dict) and _net_raw.get("type") == "FeatureCollection"
    else {"type": "FeatureCollection", "features": _net_raw}
)

# Resolve MODE from widget or network's 'modes' list
_net_modes = (_network.get("properties") or {}).get("modes") or []
if _MODE_ARG:
    MODE = _MODE_ARG
    if _net_modes and MODE not in _net_modes:
        raise ValueError(f"mode {MODE!r} is not in the network's modes list: {_net_modes}")
else:
    if not _net_modes:
        raise ValueError(
            "Network has no 'modes' property and the mode widget was not supplied."
        )
    MODE = _net_modes[0]
    logger.info("Mode auto-selected from network: %s", MODE)
print(f"Mode        : {MODE}")

# Read AREA_ID from network properties
AREA_ID = (_network.get("properties") or {}).get("area_id") or ""
if not AREA_ID:
    from uuid import uuid4  # noqa: PLC0415
    AREA_ID = str(uuid4())
    logger.warning("Network has no 'area_id' property — using generated ID: %s", AREA_ID)
print(f"Area ID     : {AREA_ID}")

# 2. Load purpose index and daylight table
logger.info("Reading purpose index from %s", PURPOSE_INDEX_URI)
_purpose_index_raw = json.loads(_read_uri(PURPOSE_INDEX_URI))
logger.info("Reading daylight table from %s", DAYLIGHT_URI)
_daylight_raw = json.loads(_read_uri(DAYLIGHT_URI))

# 3. Pure pipeline — no I/O
_dt          = parse_date(DATE)
_temperature = normalise_temperature(TEMPERATURE)
_weather     = normalise_weather(WEATHER, _dt, _daylight_raw)
_purpose     = None if PURPOSE.lower() == "all" else PURPOSE.lower()

_purpose_index = load_purpose_index(_purpose_index_raw)

_params = Params(
    mode=MODE,
    dt=_dt,
    temperature=_temperature,
    weather=_weather,
    regio=(_network.get("properties") or {}).get("region") or "",
    purpose=_purpose,
    holiday_index=HOLIDAY_INDEX_URI,
)

_filtered        = filterNetwork(_network, BBOX, OFFSET, LIMIT)
_filtered.params = _params
_keys            = determineIndiceKeys(_params, _filtered.metadata)
_indexes         = read_indexes(_keys, _purpose_index)
_result          = applyIndices(_filtered, _indexes)

_result["properties"] = {
    "mode":        MODE,
    "date":        DATE or None,
    "temperature": _temperature,
    "weather":     _weather,
    "purpose":     PURPOSE,
    "limit":       LIMIT,
    "offset":      OFFSET,
    "vk":          sum(
        f["properties"].get("kilometers", 0.0) for f in _result["features"]
    ),
}

n_features = len(_result.get("features", []))
n_matched  = _result.get("number_matched", n_features)
logger.info("Pipeline returned %d features (number_matched=%d)", n_features, n_matched)

# 4. Write outputs
_out_dir = _output_dir()
_ensure_dir(_out_dir)
logger.info("Output directory: %s", _out_dir)

_geojson_payload = json.dumps(_result, ensure_ascii=False, indent=2).encode("utf-8")
_geojson_path    = _write_file(
    _out_dir, f"{AREA_ID}-SCALED-NETWORK-{MODE}.geojson", _geojson_payload, "application/geo+json",
)

_parquet_path = _write_geoparquet(_result, _out_dir, AREA_ID, MODE)

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("Network scaling complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ───────────────────────────────────────────────────────────

_SEP   = "─" * 60
_props = _result.get("properties", {})

print(_SEP)
print(f"Network Scaling complete — {_total_elapsed:.1f}s total")
print(_SEP)
print(f"  Area ID     : {AREA_ID}")
print(f"  Mode        : {MODE}")
print(f"  Date        : {DATE or '(none)'}")
print(f"  Temperature : {_props.get('temperature', TEMPERATURE)}")
print(f"  Weather     : {_props.get('weather', WEATHER)}")
print(f"  Purpose     : {PURPOSE}")
print(f"  Features    : {n_features} returned / {n_matched} matched")
print(f"  VK total    : {_props.get('vk', 0):.4f}")
print()
print(f"  GeoJSON     : {_geojson_path}")
print(f"  GeoParquet  : {_parquet_path or '(skipped — geopandas unavailable)'}")
print(_SEP)
