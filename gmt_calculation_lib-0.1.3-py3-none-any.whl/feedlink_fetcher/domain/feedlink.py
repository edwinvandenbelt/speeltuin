"""Feedlink-building logic for feedlink_fetcher.

Builds production + attraction feedlinks from voedingslinks rows and
zone_fetcher zone features.  Zones with ``zoneClass`` AREA are skipped
(they have no gid / voedingslinks entry in Databricks).

For zones that are not covered by any valid voedingslinks row (i.e. the
Databricks table has no entry for the zone, or the referenced node is absent
from the local network), a **fallback feedlink** is synthesised by connecting
the zone centroid to the nearest network node.  This guarantees that every
non-AREA zone with positive production or attraction is reachable in the
routed network regardless of whether Databricks has an up-to-date voedingslinks
entry.
"""

from __future__ import annotations

import logging

from shared.geo_utils import _flat_earth_dist_m, _parse_wkt_geometry, _straight_line

logger = logging.getLogger(__name__)

# Property keys on every feedlink feature.
FEEDLINK_PROPERTIES: tuple[str, ...] = (
    "feedlinkId",
    "reverseLinkIds",
    "zoneId",
    "fromNode",
    "toNode",
    "length",
    "capacity",
    "mode",
    "ringIndex",
    "ringLabel",
    "sectorIndex",
    "type",
    "source",
)


def _find_nearest_node(
    zone_lon: float,
    zone_lat: float,
    node_positions: dict,
) -> tuple[object, float]:
    """Return ``(node_id, distance_m)`` of the closest network node to the zone centroid.

    Parameters
    ----------
    zone_lon, zone_lat:
        WGS-84 coordinates of the zone centroid.
    node_positions:
        Mapping of ``node_id → (lon, lat)`` as returned by
        :func:`~feedlink_fetcher.domain.network.parse_network_geojson`.

    Returns
    -------
    tuple
        ``(node_id, distance_m)`` — or ``(None, inf)`` when *node_positions*
        is empty.
    """
    best_id = None
    best_dist = float("inf")
    for node_id, (nlon, nlat) in node_positions.items():
        d = _flat_earth_dist_m(zone_lon, zone_lat, nlon, nlat)
        if d < best_dist:
            best_dist = d
            best_id = node_id
    return best_id, best_dist


def build_feedlinks(
    zones_fc: dict,
    node_positions: dict,
    all_node_ids: set,
    vl_rows: list,
    mode: str,
) -> dict:
    """Build a feedlink FeatureCollection from zone_fetcher zones + voedingslinks rows.

    For every non-AREA zone that is **not** covered by a valid voedingslinks row
    (i.e. no row exists, or the row's node is absent from the network), a fallback
    feedlink is created using the nearest network node.

    Parameters
    ----------
    zones_fc:
        GeoJSON FeatureCollection from zone_fetcher.  Features with
        ``properties.zoneClass`` of ``"AREA"`` are skipped (no gid).
    node_positions:
        Mapping of ``node_id → (lon, lat)`` from the parsed network.
    all_node_ids:
        Set of all node IDs present in the network.
    vl_rows:
        Rows from the Databricks voedingslinks table
        (``van_centroid_gid``, ``naar_knoop_id``, ``wkt_geom_4326``, …).
    mode:
        Transport mode string, e.g. ``"CAR"``.

    Returns
    -------
    dict
        GeoJSON FeatureCollection with feedlink features.
    """
    # Index zone features by gid for quick lookup
    zone_by_gid: dict[int, dict] = {}
    for feat in zones_fc.get("features") or []:
        props = feat.get("properties") or {}
        if props.get("zoneClass") == "AREA":
            continue
        gid = props.get("gid")
        if gid is None:
            continue
        zone_by_gid[int(gid)] = props

    records: list[dict] = []
    fid = 1

    # Track which zones are successfully linked via voedingslinks rows.
    covered_gids: set[int] = set()

    for raw in vl_rows:
        gid     = raw.get("van_centroid_gid")
        node_id = raw.get("naar_knoop_id")

        if gid is None or node_id is None:
            continue
        gid = int(gid)
        zone = zone_by_gid.get(gid)
        if zone is None:
            logger.debug("VL row gid=%d: zone not found — skipped", gid)
            continue
        if node_id not in all_node_ids:
            logger.debug("VL row gid=%d: node %s not in network — skipped", gid, node_id)
            continue

        covered_gids.add(gid)

        zone_node_id = str(gid)
        node_lon, node_lat = node_positions[node_id]
        zone_lon = float(zone.get("centroidLon") or 0)
        zone_lat = float(zone.get("centroidLat") or 0)
        production = float(zone.get("production") or 0.0)
        attraction = float(zone.get("attraction") or 0.0)
        dist_m = _flat_earth_dist_m(zone_lon, zone_lat, node_lon, node_lat)

        geom_prod = _parse_wkt_geometry(raw.get("wkt_geom_4326"))
        if geom_prod is None:
            geom_prod = _straight_line(zone_lon, zone_lat, node_lon, node_lat)
        geom_attr = _straight_line(node_lon, node_lat, zone_lon, zone_lat)

        zone_id = str(zone.get("zoneId") or "")
        length  = round(dist_m, 1)
        prod_fid = fid
        attr_fid = fid + 1

        if production > 0.0:
            records.append({
                "type": "Feature",
                "geometry": geom_prod,
                "properties": {
                    "feedlinkId":     prod_fid,
                    "reverseLinkIds": [attr_fid],
                    "zoneId":         zone_id,
                    "fromNode":       zone_node_id,
                    "toNode":         node_id,
                    "length":         length,
                    "capacity":       production,
                    "mode":           mode,
                    "ringIndex":      -1,
                    "ringLabel":      "",
                    "sectorIndex":    -1,
                    "type":           "feedlink",
                    "source":         "databricks",
                },
            })
        if attraction > 0.0:
            records.append({
                "type": "Feature",
                "geometry": geom_attr,
                "properties": {
                    "feedlinkId":     attr_fid,
                    "reverseLinkIds": [prod_fid],
                    "zoneId":         zone_id,
                    "fromNode":       node_id,
                    "toNode":         zone_node_id,
                    "length":         length,
                    "capacity":       attraction,
                    "mode":           mode,
                    "ringIndex":      -1,
                    "ringLabel":      "",
                    "sectorIndex":    -1,
                    "type":           "feedlink",
                    "source":         "databricks",
                },
            })
        fid += 2

    # ------------------------------------------------------------------
    # Fallback: for zones not covered by a valid voedingslinks row,
    # synthesise a feedlink to the nearest network node.
    # ------------------------------------------------------------------
    uncovered = [
        (gid, zone)
        for gid, zone in zone_by_gid.items()
        if gid not in covered_gids
    ]

    if uncovered and not node_positions:
        logger.warning(
            "No network nodes available — cannot create fallback feedlinks for %d zone(s)",
            len(uncovered),
        )

    for gid, zone in uncovered:
        zone_lon = float(zone.get("centroidLon") or 0)
        zone_lat = float(zone.get("centroidLat") or 0)
        production = float(zone.get("production") or 0.0)
        attraction = float(zone.get("attraction") or 0.0)

        if production == 0.0 and attraction == 0.0:
            logger.debug("Fallback gid=%d: no production or attraction — skipped", gid)
            continue

        if not node_positions:
            continue

        node_id, dist_m = _find_nearest_node(zone_lon, zone_lat, node_positions)
        if node_id is None:
            continue

        node_lon, node_lat = node_positions[node_id]
        zone_node_id = str(gid)
        zone_id = str(zone.get("zoneId") or "")
        length = round(dist_m, 1)
        prod_fid = fid
        attr_fid = fid + 1

        geom_prod = _straight_line(zone_lon, zone_lat, node_lon, node_lat)
        geom_attr = _straight_line(node_lon, node_lat, zone_lon, zone_lat)

        if production > 0.0:
            records.append({
                "type": "Feature",
                "geometry": geom_prod,
                "properties": {
                    "feedlinkId":     prod_fid,
                    "reverseLinkIds": [attr_fid],
                    "zoneId":         zone_id,
                    "fromNode":       zone_node_id,
                    "toNode":         node_id,
                    "length":         length,
                    "capacity":       production,
                    "mode":           mode,
                    "ringIndex":      -1,
                    "ringLabel":      "",
                    "sectorIndex":    -1,
                    "type":           "feedlink",
                    "source":         "fallback",
                },
            })
        if attraction > 0.0:
            records.append({
                "type": "Feature",
                "geometry": geom_attr,
                "properties": {
                    "feedlinkId":     attr_fid,
                    "reverseLinkIds": [prod_fid],
                    "zoneId":         zone_id,
                    "fromNode":       node_id,
                    "toNode":         zone_node_id,
                    "length":         length,
                    "capacity":       attraction,
                    "mode":           mode,
                    "ringIndex":      -1,
                    "ringLabel":      "",
                    "sectorIndex":    -1,
                    "type":           "feedlink",
                    "source":         "fallback",
                },
            })

        logger.debug(
            "Fallback feedlink gid=%d → node %s (%.1f m)", gid, node_id, dist_m
        )
        fid += 2

    logger.info("Built %d feedlinks for mode %s", len(records), mode)
    return {
        "type": "FeatureCollection",
        "features": records,
        "properties": {"fields": list(FEEDLINK_PROPERTIES)},
    }
