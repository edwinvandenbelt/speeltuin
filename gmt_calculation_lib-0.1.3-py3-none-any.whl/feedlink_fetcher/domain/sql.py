"""SQL builder for feedlink_fetcher — identical mapping to feedlink_creator."""

from __future__ import annotations

# None → no Spectrum voedingslinks table for this mode
VOEDINGSLINKS_TABLE: dict[str, str | None] = {
    "CAR": "d110_voedingslinks",
    "BIKE": "d120_voedingslinks",
    "PEDESTRIAN": None,
    "BUS": "d140_voedingslinks",
    "TRAM": "d140_voedingslinks",
    "METRO": "d140_voedingslinks",
    "TRAIN": "d140_voedingslinks",
}


def build_voedingslinks_sql(
    catalog: str,
    schema: str,
    table: str,
    gids: list,
) -> str:
    """Return a SELECT statement for the given zone gids.

    Schema differences
    ------------------
    ``2024_01`` stores link geometries as ``geom_28992`` (native geometry in
    RD / EPSG:28992).  All other schemas use ``geom_4326`` (native geometry in
    WGS-84 / EPSG:4326).  The output WKT is always in 4326 so that downstream
    parsing in ``feedlink.py`` receives consistent WGS-84 coordinates.
    """
    where = (
        "WHERE FALSE"
        if not gids
        else "WHERE van_centroid_gid IN (" + ", ".join(str(int(g)) for g in gids) + ")"
    )
    if schema == "2024_01":
        geom_expr = "ST_AsText(ST_Transform(geom_28992, 4326))"
    else:
        geom_expr = "ST_AsText(geom_4326)"
    return (
        f"SELECT van_centroid_gid,\n"
        f"       naar_knoop_id,\n"
        f"       {geom_expr} AS wkt_geom_4326\n"
        f"FROM `{catalog}`.`{schema}`.{table}\n"
        f"{where}"
    )
