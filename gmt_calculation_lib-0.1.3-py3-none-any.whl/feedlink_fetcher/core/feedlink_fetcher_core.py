"""Core entry point for feedlink_fetcher — pure Python, no I/O, no boto3."""

from __future__ import annotations

from feedlink_fetcher.domain.sql import VOEDINGSLINKS_TABLE, build_voedingslinks_sql
from feedlink_fetcher.domain.network import parse_network_geojson
from feedlink_fetcher.domain.feedlink import FEEDLINK_PROPERTIES, build_feedlinks

__all__ = [
    "VOEDINGSLINKS_TABLE",
    "FEEDLINK_PROPERTIES",
    "build_voedingslinks_sql",
    "parse_network_geojson",
    "build_feedlinks",
]
