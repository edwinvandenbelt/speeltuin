"""Unit tests for all_or_nothing_assigner core.

All tests are pure — no boto3, no Databricks, no network calls.
"""

from __future__ import annotations

import math
import pytest

from all_or_nothing_assigner.core.all_or_nothing_assigner_core import (
    _build_adjacency,
    _dijkstra,
    _link_cost,
    _parse_zone_nodes,
    _reconstruct_path,
    assign_all_or_nothing,
)


# ---------------------------------------------------------------------------
# Helpers / factories
# ---------------------------------------------------------------------------

def _link(
    link_id: str,
    from_node: str,
    to_node: str,
    length_m: float = 1000.0,
    speed_kmh: float = 50.0,
    flow: float = 0.0,
    capacity: float = 1000.0,
    link_type: str = "road",
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "length": length_m,
            "speed": speed_kmh,
            "flow": flow,
            "capacity": capacity,
            "type": link_type,
        },
    }


def _feedlink(
    link_id: str,
    zone_id: str,
    from_node: str,
    to_node: str,
    ring_index: int = -1,
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "linkId": link_id,
            "zoneId": zone_id,
            "fromNode": from_node,
            "toNode": to_node,
            "ringIndex": ring_index,
            "type": "feedlink",
        },
    }


def _od(from_zone: str, to_zone: str, trips: float) -> dict:
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {
            "fromZoneId": from_zone,
            "toZoneId": to_zone,
            "trips": trips,
        },
    }


def _fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features}


# ---------------------------------------------------------------------------
# Unit: _link_cost
# ---------------------------------------------------------------------------

class TestLinkCost:
    def test_free_flow_no_congestion(self):
        # 1000 m at 50 km/h = 72 s; flow=0 so BPR term is zero
        cost = _link_cost(1000.0, 50.0, 0.0, 1000.0, 0.15, 4.0)
        assert abs(cost - 72.0) < 0.01

    def test_bpr_congestion(self):
        # flow == capacity -> cost = t0 * (1 + alpha)
        t0 = (1000.0 / 50.0) * 3600.0 / 1000.0  # 72 s
        expected = t0 * (1 + 0.15 * (1.0 ** 4.0))
        cost = _link_cost(1000.0, 50.0, 1000.0, 1000.0, 0.15, 4.0)
        assert abs(cost - expected) < 0.01

    def test_zero_capacity_returns_inf(self):
        """A link with capacity=0 is impassable — Dijkstra must not route through it."""
        assert _link_cost(1000.0, 50.0, 500.0, 0.0, 0.15, 4.0) == math.inf
        assert _link_cost(1000.0, 50.0, 0.0, 0.0, 0.15, 4.0) == math.inf

    def test_zero_speed_returns_inf(self):
        assert _link_cost(1000.0, 0.0, 0.0, 1000.0, 0.15, 4.0) == math.inf


# ---------------------------------------------------------------------------
# Unit: _parse_zone_nodes
# ---------------------------------------------------------------------------

class TestParseZoneNodes:
    def test_inner_feedlinks_only(self):
        feats = [
            _feedlink("f1", "zone_A", "C_A", "N1", ring_index=-1),
            _feedlink("f2", "zone_A", "C_A", "N2", ring_index=0),   # outer — skip
            _feedlink("f3", "zone_B", "C_B", "N3", ring_index=-1),
        ]
        origins, dests = _parse_zone_nodes(feats)
        assert origins == {"zone_A": "C_A", "zone_B": "C_B"}
        assert dests == {"zone_A": "N1", "zone_B": "N3"}

    def test_empty(self):
        origins, dests = _parse_zone_nodes([])
        assert origins == {}
        assert dests == {}

    def test_missing_zone_id_skipped(self):
        feat = {
            "type": "Feature",
            "geometry": None,
            "properties": {"fromNode": "C1", "toNode": "N1", "ringIndex": -1},
        }
        origins, dests = _parse_zone_nodes([feat])
        assert origins == {}
        assert dests == {}

    def test_attraction_feedlink_does_not_override_production(self):
        """feedlink_creator appends production then attraction for the same zone.

        The attraction feedlink has fromNode=network, toNode=centroid — the
        reverse of the production feedlink.  _parse_zone_nodes must use the
        production (first-seen) values and ignore the attraction feedlink.
        """
        production = _feedlink("fp", "zone_A", "C_A", "N1", ring_index=-1)
        # Attraction: fromNode=network, toNode=centroid (reversed)
        attraction = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[1, 0], [0, 0]]},
            "properties": {
                "linkId": "fa",
                "zoneId": "zone_A",
                "fromNode": "N1",   # network node
                "toNode": "C_A",    # centroid
                "ringIndex": -1,
                "type": "feedlink",
            },
        }
        origins, dests = _parse_zone_nodes([production, attraction])
        # Must use production feedlink values, not attraction
        assert origins["zone_A"] == "C_A"   # centroid
        assert dests["zone_A"] == "N1"       # network attachment


# ---------------------------------------------------------------------------
# Unit: _dijkstra
# ---------------------------------------------------------------------------

class TestDijkstra:
    def test_simple_path(self):
        adj = {
            "A": [("B", 1.0, "l1"), ("C", 5.0, "l2")],
            "B": [("C", 2.0, "l3")],
        }
        dist, prev = _dijkstra(adj, "A")
        assert dist["A"] == 0.0
        assert dist["B"] == 1.0
        assert dist["C"] == 3.0  # A->B->C
        assert prev["C"] == "B"

    def test_unreachable_node_not_in_dist(self):
        adj = {"A": [("B", 1.0, "l1")]}
        dist, prev = _dijkstra(adj, "A")
        assert "Z" not in dist

    def test_single_node(self):
        dist, prev = _dijkstra({}, "A")
        assert dist == {"A": 0.0}
        assert prev == {"A": None}


# ---------------------------------------------------------------------------
# Unit: _reconstruct_path
# ---------------------------------------------------------------------------

class TestReconstructPath:
    def test_two_node_path(self):
        prev = {"A": None, "B": "A"}
        assert _reconstruct_path(prev, "B") == ["A", "B"]

    def test_three_node_path(self):
        prev = {"A": None, "B": "A", "C": "B"}
        assert _reconstruct_path(prev, "C") == ["A", "B", "C"]

    def test_unreachable_returns_empty(self):
        prev = {"A": None, "B": "A"}
        assert _reconstruct_path(prev, "Z") == []


# ---------------------------------------------------------------------------
# Integration: assign_all_or_nothing
# ---------------------------------------------------------------------------

class TestAssignAllOrNothing:
    """End-to-end tests using minimal synthetic GeoJSON."""

    def _make_simple_network(self) -> tuple[dict, dict, dict]:
        """
        Two-zone network:
          Zone A centroid (CA) -> node 1 (via feedlink fa1)
          Zone B centroid (CB) -> node 3 (via feedlink fb1)
          Network: 1 -> 2 -> 3

        100 trips from A to B should load links L1 (1->2) and L2 (2->3).
        """
        network_fc = _fc([
            _link("L1", "1", "2", length_m=1000.0, speed_kmh=50.0),
            _link("L2", "2", "3", length_m=1000.0, speed_kmh=50.0),
        ])
        feedlinks_fc = _fc([
            _feedlink("FA", "zoneA", "CA", "1", ring_index=-1),
            _feedlink("FB", "zoneB", "CB", "3", ring_index=-1),
        ])
        od_fc = _fc([_od("zoneA", "zoneB", 100.0)])
        return network_fc, feedlinks_fc, od_fc

    def test_flow_loaded_on_path_links(self):
        network_fc, feedlinks_fc, od_fc = self._make_simple_network()
        out_fc, stats = assign_all_or_nothing(network_fc, feedlinks_fc, od_fc)
        flows = {
            f["properties"]["linkId"]: f["properties"]["flow"]
            for f in out_fc["features"]
        }
        assert flows["L1"] == 100.0
        assert flows["L2"] == 100.0

    def test_stats_total_trips(self):
        network_fc, feedlinks_fc, od_fc = self._make_simple_network()
        _, stats = assign_all_or_nothing(network_fc, feedlinks_fc, od_fc)
        assert stats["totalTrips"] == 100.0
        assert stats["assignedTrips"] == 100.0
        assert stats["unassignedTrips"] == 0.0
        assert stats["assignedPairs"] == 1
        assert stats["totalPairs"] == 1
        assert stats["links"] == 2

    def test_unassigned_when_origin_zone_has_no_node(self):
        network_fc = _fc([_link("L1", "1", "2")])
        feedlinks_fc = _fc([_feedlink("FB", "zoneB", "CB", "2", ring_index=-1)])
        od_fc = _fc([_od("zoneA", "zoneB", 50.0)])  # zoneA has no feedlink
        out_fc, stats = assign_all_or_nothing(network_fc, feedlinks_fc, od_fc)
        assert stats["assignedTrips"] == 0.0
        assert stats["totalTrips"] == 50.0
        # flow on L1 should remain 0
        assert out_fc["features"][0]["properties"]["flow"] == 0.0

    def test_unassigned_when_dest_zone_has_no_node(self):
        network_fc = _fc([_link("L1", "1", "2")])
        feedlinks_fc = _fc([_feedlink("FA", "zoneA", "CA", "1", ring_index=-1)])
        od_fc = _fc([_od("zoneA", "zoneB", 50.0)])  # zoneB has no feedlink
        _, stats = assign_all_or_nothing(network_fc, feedlinks_fc, od_fc)
        assert stats["assignedTrips"] == 0.0

    def test_zero_trips_od_pair_skipped(self):
        network_fc, feedlinks_fc, _ = self._make_simple_network()
        od_fc = _fc([_od("zoneA", "zoneB", 0.0)])
        _, stats = assign_all_or_nothing(network_fc, feedlinks_fc, od_fc)
        assert stats["totalTrips"] == 0.0
        assert stats["totalPairs"] == 0

    def test_multiple_od_pairs_accumulate(self):
        """Two origins each sending to same destination — flows should stack."""
        network_fc = _fc([
            _link("L1", "1", "3"),
            _link("L2", "2", "3"),
        ])
        feedlinks_fc = _fc([
            _feedlink("FA", "zA", "CA", "1", ring_index=-1),
            _feedlink("FB", "zB", "CB", "2", ring_index=-1),
            _feedlink("FC", "zC", "CC", "3", ring_index=-1),
        ])
        od_fc = _fc([
            _od("zA", "zC", 40.0),
            _od("zB", "zC", 60.0),
        ])
        out_fc, stats = assign_all_or_nothing(network_fc, feedlinks_fc, od_fc)
        flows = {
            f["properties"]["linkId"]: f["properties"]["flow"]
            for f in out_fc["features"]
        }
        assert flows["L1"] == 40.0
        assert flows["L2"] == 60.0
        assert stats["assignedTrips"] == 100.0

    def test_output_preserves_other_properties(self):
        """Non-flow properties on links must be unchanged in the output."""
        network_fc, feedlinks_fc, od_fc = self._make_simple_network()
        out_fc, _ = assign_all_or_nothing(network_fc, feedlinks_fc, od_fc)
        for feat in out_fc["features"]:
            props = feat["properties"]
            assert "linkId" in props
            assert "fromNode" in props
            assert "toNode" in props

    def test_output_fc_type(self):
        network_fc, feedlinks_fc, od_fc = self._make_simple_network()
        out_fc, _ = assign_all_or_nothing(network_fc, feedlinks_fc, od_fc)
        assert out_fc["type"] == "FeatureCollection"
        assert len(out_fc["features"]) == len(network_fc["features"])

    def test_empty_network(self):
        out_fc, stats = assign_all_or_nothing(_fc([]), _fc([]), _fc([]))
        assert out_fc["features"] == []
        assert stats["links"] == 0

    def test_existing_flow_is_reset(self):
        """Pre-existing flow on a link is discarded; only freshly assigned flow is kept."""
        network_fc = _fc([
            _link("L1", "1", "2", flow=200.0),
        ])
        feedlinks_fc = _fc([
            _feedlink("FA", "zA", "CA", "1", ring_index=-1),
            _feedlink("FB", "zB", "CB", "2", ring_index=-1),
        ])
        od_fc = _fc([_od("zA", "zB", 50.0)])
        out_fc, _ = assign_all_or_nothing(network_fc, feedlinks_fc, od_fc)
        assert out_fc["features"][0]["properties"]["flow"] == 50.0
