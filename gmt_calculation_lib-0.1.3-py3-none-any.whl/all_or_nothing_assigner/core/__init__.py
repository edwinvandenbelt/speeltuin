# src/all_or_nothing_assigner/core/__init__.py
