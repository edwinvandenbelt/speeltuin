# src/all_or_nothing_assigner/__init__.py
