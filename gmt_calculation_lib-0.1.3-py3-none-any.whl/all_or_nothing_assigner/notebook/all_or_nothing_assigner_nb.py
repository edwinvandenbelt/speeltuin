# Databricks notebook source
# ---------------------------------------------------------------------------
# all_or_nothing_assigner_nb.py — Databricks notebook interface for
# all_or_nothing_assigner.
#
# This notebook:
#   1. Reads widget parameters.
#   2. Reads network, feedlinks, and OD-matrix GeoJSON from S3.
#   3. Calls assign_all_or_nothing() — no Spark I/O.
#   4. Writes the assigned network back to S3.
#   5. Prints a summary.
# ---------------------------------------------------------------------------

# COMMAND ----------
import json
import logging
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("all_or_nothing_assigner_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uri", "",
    "Full URI of the network GeoJSON (s3://bucket/key)",
)
dbutils.widgets.text(  # noqa: F821
    "feedlinks_uri", "",
    "Full URI of the feedlinks GeoJSON (s3://bucket/key)",
)
dbutils.widgets.text(  # noqa: F821
    "od_uri", "",
    "Full URI of the OD-matrix GeoJSON (s3://bucket/key)",
)
dbutils.widgets.text(  # noqa: F821
    "output_uri", "",
    "Full URI for the assigned network output (s3://bucket/key; leave blank to overwrite network_uri)",
)
dbutils.widgets.text(  # noqa: F821
    "alpha", "0.15",
    "BPR alpha coefficient",
)
dbutils.widgets.text(  # noqa: F821
    "beta", "4.0",
    "BPR beta exponent",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL", "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from all_or_nothing_assigner.core.all_or_nothing_assigner_core import assign_all_or_nothing  # noqa: E402

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

NETWORK_URI  = dbutils.widgets.get("network_uri").strip()   # noqa: F821
FEEDLINKS_URI = dbutils.widgets.get("feedlinks_uri").strip()  # noqa: F821
OD_URI       = dbutils.widgets.get("od_uri").strip()        # noqa: F821
OUTPUT_URI   = dbutils.widgets.get("output_uri").strip()    # noqa: F821
ALPHA        = float(dbutils.widgets.get("alpha").strip() or "0.15")  # noqa: F821
BETA         = float(dbutils.widgets.get("beta").strip() or "4.0")    # noqa: F821

if not NETWORK_URI:
    raise ValueError("Widget 'network_uri' is empty.")
if not FEEDLINKS_URI:
    raise ValueError("Widget 'feedlinks_uri' is empty.")
if not OD_URI:
    raise ValueError("Widget 'od_uri' is empty.")

OUTPUT_URI = OUTPUT_URI or NETWORK_URI

logger.info(
    "network_uri=%s  feedlinks_uri=%s  od_uri=%s  output_uri=%s  alpha=%.3f  beta=%.1f",
    NETWORK_URI, FEEDLINKS_URI, OD_URI, OUTPUT_URI, ALPHA, BETA,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _get_s3(uri: str) -> bytes:
    bucket, key = uri[5:].split("/", 1)
    body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
    logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
    return body


def _put_s3(uri: str, data: bytes) -> None:
    bucket, key = uri[5:].split("/", 1)
    boto3.client("s3").put_object(
        Bucket=bucket, Key=key, Body=data, ContentType="application/geo+json",
    )
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))

# COMMAND ----------
# MAGIC %md
# MAGIC ## Run All-or-Nothing Assigner
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

_t_start = datetime.now(timezone.utc)

print(f"Starting  {_t_start.isoformat()}")
print(f"Network   : {NETWORK_URI}")
print(f"Feedlinks : {FEEDLINKS_URI}")
print(f"OD matrix : {OD_URI}")
print(f"Output    : {OUTPUT_URI}")
print(f"Alpha     : {ALPHA}   Beta: {BETA}")
print()

_network_fc  = json.loads(_get_s3(NETWORK_URI))
_feedlinks_fc = json.loads(_get_s3(FEEDLINKS_URI))
_od_fc       = json.loads(_get_s3(OD_URI))

_result_fc, _stats = assign_all_or_nothing(
    _network_fc, _feedlinks_fc, _od_fc, alpha=ALPHA, beta=BETA
)

_payload = json.dumps(_result_fc, ensure_ascii=False).encode("utf-8")
_put_s3(OUTPUT_URI, _payload)

_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60
print(_SEP)
print(f"All-or-Nothing Assigner complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  Network   : {NETWORK_URI}")
print(f"  Output    : {OUTPUT_URI}")
print(f"  Stats     : {_stats}")
print(_SEP)
