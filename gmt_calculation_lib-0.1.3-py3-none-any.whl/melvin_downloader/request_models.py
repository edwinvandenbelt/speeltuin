"""Request models for the melvin_downloader Lambda."""

from __future__ import annotations

from pydantic import BaseModel, Field


class HandlerInput(BaseModel):
    """Validated input for the melvin_downloader handler."""

    bbox: list[float] = Field(
        ...,
        min_length=4,
        max_length=4,
        description="Bounding box [min_lon, min_lat, max_lon, max_lat] in WGS-84.",
    )
    start_period: str = Field(
        ...,
        description="Start date of the reporting period (YYYY-MM-DD).",
    )
    end_period: str = Field(
        ...,
        description="End date of the reporting period (YYYY-MM-DD).",
    )
    output_file: str = Field(
        ...,
        description="Full URI where the analytics GeoJSON will be written (s3://bucket/key or local path).",
    )
    areas_file: str = Field(
        ...,
        description="Full URI of the Melvin areas JSON file (s3://bucket/key or local path).",
    )
    activity_types: list[str] = Field(
        default=["WORK", "EVENT"],
        description="Melvin activity types to include in the export request.",
    )
    restriction_types: list[str] = Field(
        default=["SPEED", "COMPLETE"],
        description="Melvin restriction types to filter on in the export request.",
    )
    road_operator_types: list[str] = Field(
        default=["MUNICIPALITY"],
        description=(
            "Filter areas by roadOperatorType before bbox lookup. "
            "Empty list means no filter (all operator types included)."
        ),
    )
