# src/melvin_downloader/core/__init__.py
