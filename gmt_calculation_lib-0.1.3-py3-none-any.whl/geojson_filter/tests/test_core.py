"""Tests for geojson_filter_core."""

from __future__ import annotations

import pytest

from geojson_filter.core.geojson_filter_core import filter_geojson


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_fc(features: list[dict]) -> dict:
    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"areaId": "test-area", "modes": ["CAR"]},
    }


def _make_feature(props: dict, geom_type: str = "Point") -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": geom_type, "coordinates": [5.0, 52.0]},
        "properties": props,
    }


# ===========================================================================
# Basic filtering
# ===========================================================================


class TestFilterGeojsonBasic:
    def test_all_features_pass_when_expression_always_true(self):
        fc = _make_fc([_make_feature({"speed": 60}), _make_feature({"speed": 30})])
        result, stats = filter_geojson(fc, "True")
        assert len(result["features"]) == 2
        assert stats["kept"] == 2
        assert stats["removed"] == 0

    def test_no_features_pass_when_expression_always_false(self):
        fc = _make_fc([_make_feature({"speed": 60}), _make_feature({"speed": 30})])
        result, stats = filter_geojson(fc, "False")
        assert result["features"] == []
        assert stats["kept"] == 0
        assert stats["removed"] == 2

    def test_speed_filter_keeps_fast_links(self):
        fc = _make_fc([
            _make_feature({"speed": 50}),
            _make_feature({"speed": 49}),
            _make_feature({"speed": 100}),
            _make_feature({"speed": 30}),
        ])
        result, stats = filter_geojson(fc, "p.get('speed', 0) >= 50")
        assert stats["kept"] == 2
        speeds = [f["properties"]["speed"] for f in result["features"]]
        assert all(s >= 50 for s in speeds)

    def test_empty_featurecollection_returns_empty(self):
        fc = _make_fc([])
        result, stats = filter_geojson(fc, "p.get('speed', 0) >= 50")
        assert result["features"] == []
        assert stats == {"total": 0, "kept": 0, "removed": 0}

    def test_stats_total_equals_input_count(self):
        features = [_make_feature({"speed": i * 10}) for i in range(10)]
        fc = _make_fc(features)
        _, stats = filter_geojson(fc, "p.get('speed', 0) >= 50")
        assert stats["total"] == 10
        assert stats["kept"] + stats["removed"] == 10


# ===========================================================================
# Variable bindings: f, p, g
# ===========================================================================


class TestFilterExpressionVariables:
    def test_f_variable_is_full_feature(self):
        fc = _make_fc([_make_feature({"keep": True}), _make_feature({"keep": False})])
        result, _ = filter_geojson(fc, "f['properties'].get('keep') is True")
        assert len(result["features"]) == 1

    def test_p_variable_is_properties(self):
        fc = _make_fc([_make_feature({"zoneClass": "STUDY"}),
                       _make_feature({"zoneClass": "INFLUENCE"})])
        result, _ = filter_geojson(fc, "p.get('zoneClass') == 'STUDY'")
        assert len(result["features"]) == 1
        assert result["features"][0]["properties"]["zoneClass"] == "STUDY"

    def test_g_variable_is_geometry(self):
        fc = _make_fc([
            _make_feature({}, geom_type="LineString"),
            _make_feature({}, geom_type="Point"),
        ])
        result, _ = filter_geojson(fc, "g['type'] == 'LineString'")
        assert len(result["features"]) == 1
        assert result["features"][0]["geometry"]["type"] == "LineString"

    def test_none_properties_handled_gracefully(self):
        # Feature with None properties should use empty dict for p
        fc = {
            "type": "FeatureCollection",
            "features": [{"type": "Feature", "geometry": None, "properties": None}],
        }
        result, stats = filter_geojson(fc, "True")
        assert stats["kept"] == 1


# ===========================================================================
# FeatureCollection properties are preserved
# ===========================================================================


class TestFeatureCollectionPropertiesPreserved:
    def test_top_level_properties_are_unchanged(self):
        fc = _make_fc([_make_feature({"speed": 60})])
        result, _ = filter_geojson(fc, "True")
        assert result["properties"]["areaId"] == "test-area"
        assert result["properties"]["modes"] == ["CAR"]

    def test_result_has_no_properties_key_when_input_has_none(self):
        fc = {"type": "FeatureCollection", "features": [_make_feature({"speed": 60})]}
        result, _ = filter_geojson(fc, "True")
        assert "properties" not in result

    def test_filtered_features_are_same_objects(self):
        feat = _make_feature({"speed": 80})
        fc = _make_fc([feat])
        result, _ = filter_geojson(fc, "True")
        assert result["features"][0] is feat


# ===========================================================================
# Error handling
# ===========================================================================


class TestFilterGeojsonErrors:
    def test_empty_filter_expr_raises_value_error(self):
        fc = _make_fc([])
        with pytest.raises(ValueError, match="non-empty"):
            filter_geojson(fc, "")

    def test_blank_filter_expr_raises_value_error(self):
        fc = _make_fc([])
        with pytest.raises(ValueError):
            filter_geojson(fc, "   ")

    def test_syntax_error_in_expr_raises(self):
        fc = _make_fc([])
        with pytest.raises(SyntaxError):
            filter_geojson(fc, "p.get('speed' >= 50")  # missing closing paren

    def test_runtime_error_in_expr_skips_feature(self):
        # Division by zero per feature → feature is skipped with a warning
        fc = _make_fc([_make_feature({"x": 0}), _make_feature({"x": 1})])
        result, stats = filter_geojson(fc, "1 / p['x'] > 0")
        # x=0 raises ZeroDivisionError → skipped; x=1 → 1.0 > 0 → kept
        assert stats["kept"] == 1

    def test_expression_with_no_builtins_cannot_call_open(self):
        # __builtins__ is set to {} so builtin functions are not available.
        # The resulting NameError is caught per-feature → feature is skipped.
        fc = _make_fc([_make_feature({})])
        result, stats = filter_geojson(fc, "open('/etc/passwd')")
        # Feature is skipped (not raised), so nothing is kept
        assert stats["kept"] == 0


# ===========================================================================
# Complex expressions
# ===========================================================================


class TestFilterComplexExpressions:
    def test_compound_condition(self):
        fc = _make_fc([
            _make_feature({"speed": 60, "zoneClass": "STUDY"}),
            _make_feature({"speed": 60, "zoneClass": "INFLUENCE"}),
            _make_feature({"speed": 30, "zoneClass": "STUDY"}),
        ])
        result, _ = filter_geojson(
            fc, "p.get('speed', 0) >= 50 and p.get('zoneClass') == 'STUDY'"
        )
        assert len(result["features"]) == 1

    def test_string_membership_expression(self):
        fc = _make_fc([
            _make_feature({"type": "motorway"}),
            _make_feature({"type": "residential"}),
            _make_feature({"type": "trunk"}),
        ])
        result, _ = filter_geojson(fc, "p.get('type') in ('motorway', 'trunk')")
        assert len(result["features"]) == 2

    def test_missing_property_with_default(self):
        fc = _make_fc([
            _make_feature({}),               # no speed key → default 0 < 50 → excluded
            _make_feature({"speed": 70}),    # speed 70 >= 50 → kept
        ])
        result, stats = filter_geojson(fc, "p.get('speed', 0) >= 50")
        assert stats["kept"] == 1
