"""adjust — GMT node-adjustment pipeline orchestrator."""
