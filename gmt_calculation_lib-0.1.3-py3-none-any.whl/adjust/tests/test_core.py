"""Unit tests for adjust.core.adjust_core — pure helper functions only."""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest

from adjust.core.adjust_core import (
    _apply_flow_delta,
    _apply_od_adjustments,
    _compute_link_flow_delta,
    _detect_mode,
    _discover_area_id,
    _find_pairs_using_links,
    _get_closed_link_ids,
    _load_changes,
    _normalize_od_fc_to_fractions,
    _redistribute_routes,
    _restore_origin_productions,
    _routes_mode_from_path,
    _split_changes,
    _validate_od_adjustments,
    apply_link_adjustments,
    apply_od_adjustments,
)
from shared.uri import mem_clear, mem_put


# ---------------------------------------------------------------------------
# _discover_area_id
# ---------------------------------------------------------------------------


class TestDiscoverAreaId:
    def test_discovers_from_clean_network(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "test-uuid-1234-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_area_id(folder) == "test-uuid-1234"

    def test_raises_when_no_network_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _discover_area_id(Path(tmp))

    def test_prefers_clean_over_raw(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "my-uuid-5678-NETWORK-RAW-CAR.parquet").write_bytes(b"")
            (folder / "my-uuid-5678-NETWORK-CAR.parquet").write_bytes(b"")
            assert _discover_area_id(folder) == "my-uuid-5678"

    def test_falls_back_to_raw_when_no_clean(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            (folder / "my-uuid-5678-NETWORK-RAW-CAR.parquet").write_bytes(b"")
            assert _discover_area_id(folder) == "my-uuid-5678"


# ---------------------------------------------------------------------------
# _detect_mode
# ---------------------------------------------------------------------------


class TestDetectMode:
    def test_detects_car(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-CAR.parquet").write_bytes(b"")
            assert _detect_mode(folder, area_id) == "CAR"

    def test_detects_bike(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-BIKE.parquet").write_bytes(b"")
            assert _detect_mode(folder, area_id) == "BIKE"

    def test_raises_when_no_network_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            with pytest.raises(FileNotFoundError):
                _detect_mode(Path(tmp), "missing-id")

    def test_ignores_non_mode_files(self):
        """Files like {id}-NETWORK-RAW-CAR.parquet must not be matched."""
        with tempfile.TemporaryDirectory() as tmp:
            folder = Path(tmp)
            area_id = "abc-123"
            (folder / f"{area_id}-NETWORK-RAW-CAR.parquet").write_bytes(b"")
            (folder / f"{area_id}-NETWORK-CAR.parquet").write_bytes(b"")
            assert _detect_mode(folder, area_id) == "CAR"


# ---------------------------------------------------------------------------
# _discover_area_id — mem:// store
# ---------------------------------------------------------------------------


class TestDiscoverAreaIdMem:
    def teardown_method(self):
        mem_clear()

    def test_discovers_from_clean_network(self):
        mem_put("mem://testfolder/my-uuid-1111-NETWORK-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder") == "my-uuid-1111"

    def test_raises_when_store_empty(self):
        with pytest.raises(FileNotFoundError):
            _discover_area_id("mem://empty")

    def test_prefers_clean_over_raw(self):
        mem_put("mem://testfolder/my-uuid-5678-NETWORK-RAW-CAR.parquet", b"")
        mem_put("mem://testfolder/my-uuid-5678-NETWORK-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder") == "my-uuid-5678"

    def test_falls_back_to_raw_when_no_clean(self):
        mem_put("mem://testfolder/my-uuid-5678-NETWORK-RAW-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder") == "my-uuid-5678"

    def test_trailing_slash_in_folder_ignored(self):
        mem_put("mem://testfolder/my-uuid-9999-NETWORK-CAR.parquet", b"")
        assert _discover_area_id("mem://testfolder/") == "my-uuid-9999"


# ---------------------------------------------------------------------------
# _detect_mode — mem:// store
# ---------------------------------------------------------------------------


class TestDetectModeMem:
    def teardown_method(self):
        mem_clear()

    def test_detects_car(self):
        mem_put("mem://testfolder/abc-123-NETWORK-CAR.parquet", b"")
        assert _detect_mode("mem://testfolder", "abc-123") == "CAR"

    def test_detects_bike(self):
        mem_put("mem://testfolder/abc-123-NETWORK-BIKE.parquet", b"")
        assert _detect_mode("mem://testfolder", "abc-123") == "BIKE"

    def test_raises_when_not_found(self):
        with pytest.raises(FileNotFoundError):
            _detect_mode("mem://testfolder", "missing-id")

    def test_ignores_raw_variants(self):
        mem_put("mem://testfolder/abc-123-NETWORK-RAW-CAR.parquet", b"")
        mem_put("mem://testfolder/abc-123-NETWORK-CAR.parquet", b"")
        assert _detect_mode("mem://testfolder", "abc-123") == "CAR"


# ---------------------------------------------------------------------------
# _routes_mode_from_path
# ---------------------------------------------------------------------------


class TestRoutesModeFromPath:
    def test_car_routes_returns_car(self):
        assert _routes_mode_from_path("abc-123-ROUTES-CAR.parquet", "MIXED") == "CAR"

    def test_bike_routes_returns_bike(self):
        assert _routes_mode_from_path("abc-123-ROUTES-BIKE.parquet", "MIXED") == "BIKE"

    def test_mixed_routes_returns_mixed(self):
        assert _routes_mode_from_path("abc-123-ROUTES-MIXED.parquet", "CAR") == "MIXED"

    def test_car_routes_in_mixed_network_uses_car(self):
        """Core bug scenario: CAR routes file + MIXED network → output mode must be CAR."""
        assert _routes_mode_from_path("uuid-ROUTES-CAR.parquet", fallback="MIXED") == "CAR"

    def test_unknown_filename_falls_back(self):
        assert _routes_mode_from_path("my_custom_routes.parquet", fallback="CAR") == "CAR"

    def test_path_object_accepted(self):
        from pathlib import Path

        assert _routes_mode_from_path(Path("abc-ROUTES-BIKE.parquet"), fallback="CAR") == "BIKE"

    def test_full_absolute_path_works(self):
        assert _routes_mode_from_path("/data/area/abc-ROUTES-CAR.parquet", "MIXED") == "CAR"


# ---------------------------------------------------------------------------
# _load_changes
# ---------------------------------------------------------------------------


class TestLoadChanges:
    def test_parses_inline_json(self):
        changes = '[{"nodeId": "123", "production": "+100"}]'
        result = _load_changes(changes)
        assert result == [{"nodeId": "123", "production": "+100"}]

    def test_reads_from_file(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "changes.json"
            data = [{"zoneId": "z1", "attraction": "200"}]
            path.write_text(json.dumps(data), encoding="utf-8")
            assert _load_changes(str(path)) == data

    def test_empty_array(self):
        assert _load_changes("[]") == []

    def test_raises_on_invalid_json(self):
        with pytest.raises(json.JSONDecodeError):
            _load_changes("{not valid json}")


# ---------------------------------------------------------------------------
# apply_link_adjustments
# ---------------------------------------------------------------------------


def _net_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _link(link_id, from_node, to_node, speed, capacity, lanes=1, flow=50.0):
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0]]},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "speed": speed,
            "capacity": capacity,
            "lanes": lanes,
            "flow": flow,
            "flow24hrs": flow,
            "flowsPerDaypart": {"mrh": flow * 0.2, "erh": flow * 0.1},
            "flowsPerMotive": {"work": flow * 0.8, "other": flow * 0.2},
        },
    }


class TestApplyLinkAdjustments:
    def test_capacity_zero_preserves_flow(self):
        """Closing a link (capacity=0) must NOT reset flow fields.

        Flow adjustment is handled by _apply_flow_delta in the pipeline;
        apply_link_adjustments only changes capacity/speed.
        """
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        adjusted_fc, affected = apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 0}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 0.0
        assert props["flow"] == pytest.approx(70.5)
        assert props["flow24hrs"] == pytest.approx(70.5)
        assert affected == [("1", "2")]

    def test_partial_capacity_preserves_flow(self):
        """Reducing capacity (but not to zero) must NOT reset flows."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        adjusted_fc, _ = apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 300}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 300.0
        assert props["flow"] == pytest.approx(70.5)

    def test_speed_zero_preserves_flow(self):
        """Setting speed=0 (results in capacity=0) must NOT reset flow fields."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=35.0))
        adjusted_fc, _ = apply_link_adjustments(fc, [{"linkId": "LK1", "speed": 0}])
        props = adjusted_fc["features"][0]["properties"]
        assert props["capacity"] == 0.0
        assert props["flow"] == pytest.approx(35.0)

    def test_original_network_not_mutated(self):
        """apply_link_adjustments must return a deep copy; original must be unchanged."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=70.5))
        apply_link_adjustments(fc, [{"linkId": "LK1", "capacity": 0}])
        assert fc["features"][0]["properties"]["flow"] == pytest.approx(70.5)
        assert fc["features"][0]["properties"]["capacity"] == 500.0


# ---------------------------------------------------------------------------
# _compute_link_flow_delta
# ---------------------------------------------------------------------------


def _routes_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _zones_fc(*features):
    return {"type": "FeatureCollection", "features": list(features)}


def _zone(zone_id, production):
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {"zoneId": zone_id, "production": production},
    }


def _od_feature(
    from_id, to_id, routes, *, from_type="zone", to_type="zone", origin_production=None
):
    """Minimal OD FeatureCollection feature.

    Pass *origin_production* to set ``originProduction`` on the feature
    (required for ``od_fc_new`` inputs that use the normalized fraction
    convention: actual trips = ``route.trips × originProduction``).
    """
    props = {
        "fromZoneId": from_id,
        "toZoneId": to_id,
        "fromType": from_type,
        "toType": to_type,
        "tripFraction": sum(r.get("trips", 0) for r in routes),
        "routes": routes,
    }
    if origin_production is not None:
        props["originProduction"] = origin_production
    return {"type": "Feature", "geometry": None, "properties": props}


def _route(trips, *link_ids):
    return {"trips": trips, "linkPath": list(link_ids)}


class TestComputeLinkFlowDelta:
    def test_re_routed_pair_scales_by_production(self):
        """route.trips is a fraction; actual flow = route.trips * origin production."""
        # Zone Z1 has production=100; route.trips=0.1 → 10 actual trips
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A", "B")]))
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "B", "C")]))
        od_new = _routes_fc()

        delta = _compute_link_flow_delta(old_routes, recomputed, od_new, zones)

        assert delta["A"] == pytest.approx((10.0, 0.0))  # removed from A
        assert delta["B"] == pytest.approx((10.0, 10.0))  # same share on B
        assert delta["C"] == pytest.approx((0.0, 10.0))  # added to C

    def test_new_zone_adjustment_pair_has_zero_before(self):
        """Newly added OD pairs have flow_before=0 for all their links.

        od_fc_new uses the normalized fraction convention after
        ``_normalize_od_fc_to_fractions``: route.trips is a fraction and
        originProduction holds the absolute value.
        """
        zones = _zones_fc(_zone("Z3", 200.0), _zone("Z4", 80.0))
        od_new = _routes_fc(
            _od_feature("Z3", "Z4", [_route(1.0, "X", "Y")], origin_production=10.0)
        )

        delta = _compute_link_flow_delta(_routes_fc(), _routes_fc(), od_new, zones)

        assert delta["X"] == pytest.approx((0.0, 10.0))
        assert delta["Y"] == pytest.approx((0.0, 10.0))

    def test_unaffected_pair_not_in_delta(self):
        """Pairs not in recomputed_fc must not contribute to the delta."""
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z3", 100.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")]),
            _od_feature("Z3", "Z4", [_route(0.1, "B")]),
        )
        # Only Z1→Z2 is re-routed
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "C")]))

        delta = _compute_link_flow_delta(old_routes, recomputed, _routes_fc(), zones)

        assert "A" in delta
        assert "B" not in delta

    def test_empty_inputs_return_empty_delta(self):
        empty = _routes_fc()
        delta = _compute_link_flow_delta(empty, empty, empty, _zones_fc())
        assert delta == {}

    def test_node_type_origin_uses_factor_one(self):
        """For node-type origins in od_fc_new, actual trips = route.trips × originProduction."""
        zones = _zones_fc()  # no zone data — node adjustments bypass zone lookup
        od_new = _routes_fc(
            _od_feature(
                "NODE_42", "Z1", [_route(1.0, "X")], from_type="node", origin_production=5.0
            )
        )

        delta = _compute_link_flow_delta(_routes_fc(), _routes_fc(), od_new, zones)

        assert delta["X"] == pytest.approx((0.0, 5.0))

    def test_od_replacement_subtracts_old_flows(self):
        """When od_fc_new replaces an existing base pair, old flows are flow_before.

        The old pair (from base ROUTES) uses the fraction convention: trips × production.
        The new od_fc_new pair uses the normalized fraction convention: route.trips ×
        originProduction — yielding the same 10 absolute trips.
        """
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A", "B")])  # fraction: 0.1 × 100 = 10 trips
        )
        # New routes for same pair — normalized fraction: route.trips=1.0 × originProduction=10.0.
        od_new = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "B", "C")], origin_production=10.0)
        )

        delta = _compute_link_flow_delta(old_routes, _routes_fc(), od_new, zones)

        assert delta["A"] == pytest.approx((10.0, 0.0))  # old link removed
        assert delta["B"] == pytest.approx((10.0, 10.0))  # same trips, no net change
        assert delta["C"] == pytest.approx((0.0, 10.0))  # new link added

    def test_tombstone_in_od_removes_old_flows(self):
        """A tombstone (routes=[]) replacing an existing pair zeroes out its links."""
        zones = _zones_fc(_zone("Z1", 100.0), _zone("Z2", 50.0))
        old_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "X", "Y")])  # 10 trips on X, Y
        )
        tombstone = _routes_fc(
            _od_feature("Z1", "Z2", [])  # trips=0, replaces old pair
        )

        delta = _compute_link_flow_delta(old_routes, _routes_fc(), tombstone, zones)

        assert delta["X"] == pytest.approx((10.0, 0.0))  # fully removed
        assert delta["Y"] == pytest.approx((10.0, 0.0))


# ---------------------------------------------------------------------------
# _apply_flow_delta
# ---------------------------------------------------------------------------


class TestApplyFlowDelta:
    def test_positive_delta_increases_flow(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        delta = {"LK1": (0.0, 10.0)}  # +10 new trips
        adj, report = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        assert props["flow"] == pytest.approx(110.0)
        assert props["flow24hrs"] == pytest.approx(110.0)
        assert len(report) == 1
        assert report[0]["flow_delta"] == pytest.approx(10.0)

    def test_negative_delta_decreases_flow(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        delta = {"LK1": (10.0, 0.0)}  # 10 trips removed
        adj, report = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        assert props["flow"] == pytest.approx(90.0)

    def test_flow_clamped_to_zero(self):
        """Flow must never go negative."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=5.0))
        delta = {"LK1": (20.0, 0.0)}  # remove 20 trips from a link with only 5
        adj, _ = _apply_flow_delta(fc, delta)

        assert adj["features"][0]["properties"]["flow"] == pytest.approx(0.0)

    def test_sub_dicts_scaled_proportionally(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=100.0))
        # flow 100 → 110 (+10%), all sub-values should scale by 1.1
        delta = {"LK1": (0.0, 10.0)}
        adj, _ = _apply_flow_delta(fc, delta)

        props = adj["features"][0]["properties"]
        # Original: mrh=20, erh=10, work=80, other=20
        assert props["flowsPerDaypart"]["mrh"] == pytest.approx(22.0)
        assert props["flowsPerDaypart"]["erh"] == pytest.approx(11.0)
        assert props["flowsPerMotive"]["work"] == pytest.approx(88.0)
        assert props["flowsPerMotive"]["other"] == pytest.approx(22.0)

    def test_zero_delta_link_not_in_report(self):
        """Links with flow_before == flow_after must not appear in the report."""
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=50.0))
        delta = {"LK1": (5.0, 5.0)}  # no change
        _, report = _apply_flow_delta(fc, delta)
        assert report == []

    def test_original_network_not_mutated(self):
        fc = _net_fc(_link("LK1", 1, 2, 50.0, 500.0, flow=50.0))
        delta = {"LK1": (0.0, 20.0)}
        _apply_flow_delta(fc, delta)
        assert fc["features"][0]["properties"]["flow"] == pytest.approx(50.0)


# ---------------------------------------------------------------------------
# _get_closed_link_ids
# ---------------------------------------------------------------------------


def _net_link(link_id: str, capacity: float) -> dict:
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {"linkId": link_id, "capacity": capacity},
    }


class TestGetClosedLinkIds:
    def test_returns_only_zero_capacity_links(self):
        fc = {
            "type": "FeatureCollection",
            "features": [
                _net_link("A", 0.0),
                _net_link("B", 100.0),
                _net_link("C", 0.0),
            ],
        }
        result = _get_closed_link_ids(fc, {"A", "B", "C"})
        assert result == {"A", "C"}

    def test_ignores_links_not_in_affected_set(self):
        fc = {
            "type": "FeatureCollection",
            "features": [
                _net_link("A", 0.0),
                _net_link("B", 0.0),
            ],
        }
        result = _get_closed_link_ids(fc, {"A"})
        assert result == {"A"}

    def test_empty_when_no_zero_capacity(self):
        fc = {"type": "FeatureCollection", "features": [_net_link("A", 50.0)]}
        assert _get_closed_link_ids(fc, {"A"}) == set()

    def test_empty_network(self):
        assert _get_closed_link_ids({"type": "FeatureCollection", "features": []}, {"A"}) == set()


# ---------------------------------------------------------------------------
# _redistribute_routes
# ---------------------------------------------------------------------------

_AFFECTED = {"LK_CLOSED"}
_CLOSED = {"LK_CLOSED"}


class TestRedistributeRoutes:
    # ------------------------------------------------------------------
    # N=2, B=1 → all flow to remaining route; trips sum == tripFraction
    # ------------------------------------------------------------------
    def test_n2_b1_all_to_remaining(self):
        # production=100, tripFraction=0.3+0.2=0.5 → total_trips=50 ≥ 2
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.3, "LK_CLOSED"),
                _route(0.2, "LK_OTHER"),
            ],
        )
        tf = feat["properties"]["tripFraction"]
        redist_fc, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert recompute == []
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert len(result_routes) == 1
        assert result_routes[0]["trips"] == pytest.approx(tf)

    # ------------------------------------------------------------------
    # N=3, B=1 → proportional redistribution to 2 remaining; sum preserved
    # ------------------------------------------------------------------
    def test_n3_b1_proportional(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_CLOSED"),
                _route(0.1, "LK_A"),
                _route(0.3, "LK_B"),
            ],
        )
        tf = feat["properties"]["tripFraction"]
        redist_fc, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert recompute == []
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert len(result_routes) == 2
        assert sum(r["trips"] for r in result_routes) == pytest.approx(tf)

    # ------------------------------------------------------------------
    # N=3, B=2 → only 1 remaining, N≠2 → re-route
    # ------------------------------------------------------------------
    def test_n3_b2_needs_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_CLOSED"),
                _route(0.1, "LK_OTHER"),
            ],
        )
        redist_fc, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert redist_fc["features"] == []
        assert len(recompute) == 1
        assert recompute[0]["fromId"] == "Z1"

    # ------------------------------------------------------------------
    # N=4, B=2 → 2 remaining ≥ 2 → local redistribution
    # ------------------------------------------------------------------
    def test_n4_b2_proportional(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_A"),
                _route(0.2, "LK_B"),
            ],
        )
        tf = feat["properties"]["tripFraction"]
        redist_fc, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert recompute == []
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert len(result_routes) == 2
        assert sum(r["trips"] for r in result_routes) == pytest.approx(tf)

    # ------------------------------------------------------------------
    # N=4, B=3 → only 1 remaining, N≠2 → re-route
    # ------------------------------------------------------------------
    def test_n4_b3_needs_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_CLOSED"),
                _route(0.2, "LK_OTHER"),
            ],
        )
        redist_fc, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert redist_fc["features"] == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # N=1, B=1 → 0 remaining → re-route
    # ------------------------------------------------------------------
    def test_n1_b1_needs_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.3, "LK_CLOSED"),
            ],
        )
        redist_fc, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert redist_fc["features"] == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # Evaporation: total trips below threshold → routes=[], not re-routed
    # ------------------------------------------------------------------
    def test_evaporated_below_min_trips(self):
        # production=10, tripFraction=0.1 → total_trips=1.0 < default 2.0
        zones = _zones_fc(_zone("Z1", 10.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.1, "LK_CLOSED"),
            ],
        )
        redist_fc, recompute = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        assert recompute == []
        assert len(redist_fc["features"]) == 1
        assert redist_fc["features"][0]["properties"]["routes"] == []

    # ------------------------------------------------------------------
    # Non-closed adjusted link → pair must go to recompute (speed tweak)
    # ------------------------------------------------------------------
    def test_non_closed_adjusted_link_to_recompute(self):
        zones = _zones_fc(_zone("Z1", 100.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.2, "LK_SPEED"),
                _route(0.2, "LK_OTHER"),
            ],
        )
        redist_fc, recompute = _redistribute_routes(_routes_fc(feat), {"LK_SPEED"}, set(), zones)
        assert redist_fc["features"] == []
        assert len(recompute) == 1

    # ------------------------------------------------------------------
    # tripFraction invariant: sum(new_trips) == tripFraction after redistribution
    # ------------------------------------------------------------------
    def test_tripfraction_preserved_after_redistribution(self):
        zones = _zones_fc(_zone("Z1", 200.0))
        feat = _od_feature(
            "Z1",
            "Z2",
            [
                _route(0.3, "LK_CLOSED"),
                _route(0.4, "LK_A"),
                _route(0.2, "LK_B"),
            ],
        )
        tf = feat["properties"]["tripFraction"]
        redist_fc, _ = _redistribute_routes(_routes_fc(feat), _AFFECTED, _CLOSED, zones)
        result_routes = redist_fc["features"][0]["properties"]["routes"]
        assert sum(r["trips"] for r in result_routes) == pytest.approx(tf)


# ---------------------------------------------------------------------------
# _normalize_od_fc_to_fractions
# ---------------------------------------------------------------------------


class TestNormalizeOdFcToFractions:
    def test_single_origin_single_route_sets_origin_production(self):
        """Single origin with one route: trips become 1.0, originProduction = total."""
        od = _routes_fc(_od_feature("Z1", "Z2", [_route(42.0, "A")]))
        result = _normalize_od_fc_to_fractions(od)
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(42.0)
        assert props["routes"][0]["trips"] == pytest.approx(1.0)
        assert props["tripFraction"] == pytest.approx(1.0)

    def test_single_origin_multiple_routes_splits_proportionally(self):
        """Two routes: trips normalized by total; Σ route.trips == 1.0."""
        od = _routes_fc(_od_feature("Z1", "Z2", [_route(30.0, "A"), _route(20.0, "B")]))
        result = _normalize_od_fc_to_fractions(od)
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(50.0)
        assert props["routes"][0]["trips"] == pytest.approx(0.6)
        assert props["routes"][1]["trips"] == pytest.approx(0.4)
        assert sum(r["trips"] for r in props["routes"]) == pytest.approx(1.0)

    def test_multiple_pairs_same_origin_normalized_together(self):
        """Two OD pairs from Z1: total=10, each pair's route.trips normalized by 10."""
        od = _routes_fc(
            _od_feature("Z1", "Z2", [_route(6.0, "A")]),
            _od_feature("Z1", "Z3", [_route(4.0, "B")]),
        )
        result = _normalize_od_fc_to_fractions(od)
        for feat in result["features"]:
            assert feat["properties"]["originProduction"] == pytest.approx(10.0)
        trips_sum = sum(
            r["trips"] for feat in result["features"] for r in feat["properties"]["routes"]
        )
        assert trips_sum == pytest.approx(1.0)

    def test_multiple_origins_normalized_independently(self):
        """Z1 (total=100) and Z2 (total=50) are each normalized to Σ=1.0."""
        od = _routes_fc(
            _od_feature("Z1", "Z2", [_route(100.0, "A")]),
            _od_feature("Z2", "Z3", [_route(50.0, "B")]),
        )
        result = _normalize_od_fc_to_fractions(od)
        feats = result["features"]
        assert feats[0]["properties"]["originProduction"] == pytest.approx(100.0)
        assert feats[0]["properties"]["routes"][0]["trips"] == pytest.approx(1.0)
        assert feats[1]["properties"]["originProduction"] == pytest.approx(50.0)
        assert feats[1]["properties"]["routes"][0]["trips"] == pytest.approx(1.0)

    def test_zero_total_trips_left_unchanged(self):
        """Feature with no routes (zero total) is left as-is without originProduction."""
        od = _routes_fc(_od_feature("Z1", "Z2", []))
        result = _normalize_od_fc_to_fractions(od)
        props = result["features"][0]["properties"]
        assert props.get("originProduction", 0.0) == pytest.approx(0.0)

    def test_trips_sum_to_one_per_origin_zone(self):
        """Invariant: Σ route.trips per origin zone ≈ 1.0 after normalization."""
        od = _routes_fc(
            _od_feature("Z1", "Z2", [_route(300.0, "A"), _route(200.0, "B")]),
            _od_feature("Z1", "Z3", [_route(100.0, "C")]),
            _od_feature("Z2", "Z4", [_route(75.0, "D")]),
        )
        result = _normalize_od_fc_to_fractions(od)
        origin_sums: dict[str, float] = {}
        for feat in result["features"]:
            props = feat["properties"]
            from_id = props["fromZoneId"]
            for route in props["routes"]:
                origin_sums[from_id] = origin_sums.get(from_id, 0.0) + route["trips"]
        for from_id, total in origin_sums.items():
            assert total == pytest.approx(1.0), f"Origin {from_id}: Σ route.trips = {total}"


# ---------------------------------------------------------------------------
# _restore_origin_productions
# ---------------------------------------------------------------------------


class TestRestoreOriginProductions:
    def test_restores_zero_origin_production_from_base(self):
        """A recomputed feature with originProduction=0 gets the base value."""
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0))
        base = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=500.0))
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"]["originProduction"] == pytest.approx(500.0)

    def test_does_not_overwrite_nonzero_origin_production(self):
        """A recomputed feature with originProduction > 0 is left unchanged."""
        recomputed = _routes_fc(
            _od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=200.0)
        )
        base = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=999.0))
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"]["originProduction"] == pytest.approx(200.0)

    def test_no_match_in_base_leaves_feature_unchanged(self):
        """A key not present in base leaves originProduction at 0.0."""
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0))
        base = _routes_fc(_od_feature("Z9", "Z8", [_route(0.1, "A")], origin_production=777.0))
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"].get("originProduction", 0.0) == pytest.approx(
            0.0
        )

    def test_base_with_zero_production_not_restored(self):
        """If base feature also has originProduction=0.0, recomputed stays at 0.0."""
        recomputed = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0))
        base = _routes_fc(_od_feature("Z1", "Z2", [_route(0.1, "A")], origin_production=0.0))
        result = _restore_origin_productions(recomputed, base)
        assert result["features"][0]["properties"].get("originProduction", 0.0) == pytest.approx(
            0.0
        )


# ---------------------------------------------------------------------------
# _split_changes — OD entries
# ---------------------------------------------------------------------------


class TestSplitChangesOd:
    def test_od_entry_goes_to_od_bucket(self):
        changes = [{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5}]
        node, link, od, flow = _split_changes(changes)
        assert od == changes
        assert node == []
        assert link == []

    def test_node_and_od_entries_split_correctly(self):
        node_entry = {"nodeId": "123", "production": "+100"}
        od_entry = {"fromZoneId": "Z1", "toZoneId": "Z2", "motifRatio": {"work": 1.0}}
        node, link, od, flow = _split_changes([node_entry, od_entry])
        assert node == [node_entry]
        assert od == [od_entry]
        assert link == []

    def test_od_entry_without_tripfraction_or_motif_raises(self):
        with pytest.raises(ValueError, match="motifRatio"):
            _split_changes([{"fromZoneId": "Z1", "toZoneId": "Z2"}])

    def test_link_entry_not_confused_with_od(self):
        link_entry = {"linkId": "L1", "capacity": 0}
        _, link, od, flow = _split_changes([link_entry])
        assert link == [link_entry]
        assert od == []


# ---------------------------------------------------------------------------
# _split_changes — flow entries
# ---------------------------------------------------------------------------


class TestSplitChangesFlow:
    def test_flow_entry_with_link_id_goes_to_flow_bucket(self):
        entry = {"linkId": "L1", "flow": "+500"}
        node, link, od, flow = _split_changes([entry])
        assert flow == [entry]
        assert link == []
        assert node == []

    def test_flow_entry_with_from_to_node_goes_to_flow_bucket(self):
        entry = {"fromNode": "A", "toNode": "B", "flow": "2000"}
        _, link, _, flow = _split_changes([entry])
        assert flow == [entry]
        assert link == []

    def test_flow_entry_not_confused_with_capacity_entry(self):
        cap_entry = {"linkId": "L1", "capacity": 1500}
        _, link, _, flow = _split_changes([cap_entry])
        assert link == [cap_entry]
        assert flow == []

    def test_mixed_flow_and_capacity_entries_split_correctly(self):
        flow_entry = {"linkId": "L1", "flow": "+200"}
        cap_entry = {"linkId": "L2", "capacity": 1000}
        _, link, _, flow = _split_changes([flow_entry, cap_entry])
        assert flow == [flow_entry]
        assert link == [cap_entry]

    def test_link_entry_without_capacity_speed_or_flow_raises(self):
        with pytest.raises(ValueError, match="'flow'"):
            _split_changes([{"linkId": "L1"}])


# ---------------------------------------------------------------------------
# _validate_od_adjustments
# ---------------------------------------------------------------------------


class TestValidateOdAdjustments:
    def test_valid_tripfraction_only(self):
        _validate_od_adjustments([{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5}])

    def test_valid_motif_only(self):
        _validate_od_adjustments(
            [
                {
                    "fromZoneId": "Z1",
                    "toZoneId": "Z2",
                    "motifRatio": {"work": 0.6, "shopping": 0.4},
                }
            ]
        )

    def test_valid_tripfraction_and_motif(self):
        _validate_od_adjustments(
            [
                {
                    "fromZoneId": "Z1",
                    "toZoneId": "Z2",
                    "tripFraction": 0.3,
                    "motifRatio": {"work": 1.0},
                }
            ]
        )

    def test_negative_tripfraction_raises(self):
        with pytest.raises(ValueError, match="tripFraction.*>= 0"):
            _validate_od_adjustments([{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": -1}])

    def test_motif_not_summing_to_one_raises(self):
        with pytest.raises(ValueError, match="sum to 1.0"):
            _validate_od_adjustments(
                [
                    {
                        "fromZoneId": "Z1",
                        "toZoneId": "Z2",
                        "motifRatio": {"work": 0.3, "shopping": 0.3},
                    }
                ]
            )

    def test_motif_sum_within_tolerance_ok(self):
        _validate_od_adjustments(
            [
                {
                    "fromZoneId": "Z1",
                    "toZoneId": "Z2",
                    "motifRatio": {"work": 0.995, "other": 0.005},
                }
            ]
        )

    def test_motif_negative_value_raises(self):
        with pytest.raises(ValueError, match=">= 0"):
            _validate_od_adjustments(
                [
                    {
                        "fromZoneId": "Z1",
                        "toZoneId": "Z2",
                        "motifRatio": {"work": 1.2, "other": -0.2},
                    }
                ]
            )

    def test_empty_from_zone_raises(self):
        with pytest.raises(ValueError, match="non-empty"):
            _validate_od_adjustments([{"fromZoneId": "", "toZoneId": "Z2", "tripFraction": 0.1}])


# ---------------------------------------------------------------------------
# _apply_od_adjustments  (legacy private function — old absolute-trips convention)
# ---------------------------------------------------------------------------


def _od_feature_with_motif(from_id, to_id, routes, *, origin_production=100.0, motif_ratio=None):
    props = {
        "fromZoneId": from_id,
        "toZoneId": to_id,
        "fromType": "zone",
        "toType": "zone",
        "tripFraction": sum(r.get("trips", 0) for r in routes),
        "originProduction": origin_production,
        "routes": routes,
    }
    if motif_ratio is not None:
        props["motifRatio"] = motif_ratio
    return {"type": "Feature", "geometry": None, "properties": props}


class TestApplyOdAdjustmentsLegacy:
    """Tests for the private _apply_od_adjustments (absolute-trips convention)."""

    def _base_routes(self):
        return _routes_fc(
            _od_feature_with_motif(
                "Z1",
                "Z2",
                [_route(0.7, "A", "B"), _route(0.3, "B", "C")],
                origin_production=200.0,
                motif_ratio={"work": 0.8, "other": 0.2},
            ),
            _od_feature_with_motif(
                "Z1",
                "Z3",
                [_route(1.0, "D", "E")],
                origin_production=80.0,
            ),
        )

    def test_trips_rescales_origin_production(self):
        result = _apply_od_adjustments(
            [{"origin": "Z1", "destination": "Z2", "trips": 50.0}],
            self._base_routes(),
        )
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(50.0)
        assert props["tripFraction"] == pytest.approx(1.0)

    def test_trips_preserves_relative_route_split(self):
        result = _apply_od_adjustments(
            [{"origin": "Z1", "destination": "Z2", "trips": 100.0}],
            self._base_routes(),
        )
        routes = result["features"][0]["properties"]["routes"]
        assert len(routes) == 2
        assert routes[0]["trips"] == pytest.approx(0.7, abs=1e-4)
        assert routes[1]["trips"] == pytest.approx(0.3, abs=1e-4)

    def test_trips_only_preserves_existing_motif_ratio(self):
        result = _apply_od_adjustments(
            [{"origin": "Z1", "destination": "Z2", "trips": 100.0}],
            self._base_routes(),
        )
        ratio = result["features"][0]["properties"].get("motifRatio")
        assert ratio == {"work": 0.8, "other": 0.2}

    def test_motif_ratio_only_leaves_volume_unchanged(self):
        result = _apply_od_adjustments(
            [{"origin": "Z1", "destination": "Z2", "motifRatio": {"shopping": 1.0}}],
            self._base_routes(),
        )
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(200.0)
        assert props["routes"][0]["trips"] == pytest.approx(0.7)
        assert props["routes"][1]["trips"] == pytest.approx(0.3)
        assert props["motifRatio"] == {"shopping": 1.0}

    def test_trips_and_motif_updates_both(self):
        result = _apply_od_adjustments(
            [
                {
                    "origin": "Z1",
                    "destination": "Z2",
                    "trips": 30.0,
                    "motifRatio": {"recreational": 0.5, "shopping": 0.5},
                }
            ],
            self._base_routes(),
        )
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(30.0)
        assert props["motifRatio"]["recreational"] == pytest.approx(0.5)
        assert props["motifRatio"]["shopping"] == pytest.approx(0.5)

    def test_nonexistent_pair_raises(self):
        with pytest.raises(ValueError, match="not found in the base ROUTES"):
            _apply_od_adjustments(
                [{"origin": "Z9", "destination": "Z8", "trips": 10}],
                self._base_routes(),
            )

    def test_multiple_entries_produce_multiple_features(self):
        result = _apply_od_adjustments(
            [
                {"origin": "Z1", "destination": "Z2", "trips": 50.0},
                {"origin": "Z1", "destination": "Z3", "trips": 20.0},
            ],
            self._base_routes(),
        )
        assert len(result["features"]) == 2
        prods = {
            f["properties"]["toZoneId"]: f["properties"]["originProduction"]
            for f in result["features"]
        }
        assert prods["Z2"] == pytest.approx(50.0)
        assert prods["Z3"] == pytest.approx(20.0)


# ---------------------------------------------------------------------------
# apply_od_adjustments  (public function — tripFraction convention)
# ---------------------------------------------------------------------------


class TestApplyOdAdjustments:
    """Tests for the public apply_od_adjustments (tripFraction convention)."""

    def _base_routes(self):
        # tripFraction = sum(route.trips) = 1.0 in fraction convention
        return _routes_fc(
            _od_feature_with_motif(
                "Z1",
                "Z2",
                [_route(0.7, "A", "B"), _route(0.3, "B", "C")],
                origin_production=200.0,
                motif_ratio={"work": 0.8, "other": 0.2},
            ),
            _od_feature_with_motif(
                "Z1",
                "Z3",
                [_route(1.0, "D", "E")],
                origin_production=80.0,
            ),
        )

    def test_tripfraction_scales_routes_proportionally(self):
        # old tripFraction = 1.0 (sum of route.trips), new = 0.5 → scale = 0.5
        result = apply_od_adjustments(
            self._base_routes(),
            [{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5}],
        )
        props = result["features"][0]["properties"]
        assert props["tripFraction"] == pytest.approx(0.5)
        assert props["originProduction"] == pytest.approx(200.0)  # preserved
        routes = props["routes"]
        assert routes[0]["trips"] == pytest.approx(0.35, abs=1e-4)
        assert routes[1]["trips"] == pytest.approx(0.15, abs=1e-4)

    def test_tripfraction_preserves_existing_motif_ratio(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5}],
        )
        ratio = result["features"][0]["properties"].get("motifRatio")
        assert ratio == {"work": 0.8, "other": 0.2}

    def test_motif_ratio_only_leaves_volume_unchanged(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [{"fromZoneId": "Z1", "toZoneId": "Z2", "motifRatio": {"shopping": 1.0}}],
        )
        props = result["features"][0]["properties"]
        assert props["originProduction"] == pytest.approx(200.0)
        assert props["tripFraction"] == pytest.approx(1.0)
        assert props["routes"][0]["trips"] == pytest.approx(0.7)
        assert props["routes"][1]["trips"] == pytest.approx(0.3)
        assert props["motifRatio"] == {"shopping": 1.0}

    def test_tripfraction_and_motif_updates_both(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [
                {
                    "fromZoneId": "Z1",
                    "toZoneId": "Z2",
                    "tripFraction": 0.4,
                    "motifRatio": {"recreational": 0.5, "shopping": 0.5},
                }
            ],
        )
        props = result["features"][0]["properties"]
        assert props["tripFraction"] == pytest.approx(0.4)
        assert props["originProduction"] == pytest.approx(200.0)
        assert props["motifRatio"]["recreational"] == pytest.approx(0.5)

    def test_nonexistent_pair_raises(self):
        with pytest.raises(ValueError, match="not found in the base ROUTES"):
            apply_od_adjustments(
                self._base_routes(),
                [{"fromZoneId": "Z9", "toZoneId": "Z8", "tripFraction": 0.1}],
            )

    def test_multiple_entries_produce_multiple_features(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [
                {"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.5},
                {"fromZoneId": "Z1", "toZoneId": "Z3", "tripFraction": 0.2},
            ],
        )
        assert len(result["features"]) == 2
        fracs = {
            f["properties"]["toZoneId"]: f["properties"]["tripFraction"] for f in result["features"]
        }
        assert fracs["Z2"] == pytest.approx(0.5)
        assert fracs["Z3"] == pytest.approx(0.2)

    def test_zero_tripfraction_zeroes_routes(self):
        result = apply_od_adjustments(
            self._base_routes(),
            [{"fromZoneId": "Z1", "toZoneId": "Z2", "tripFraction": 0.0}],
        )
        props = result["features"][0]["properties"]
        assert props["tripFraction"] == pytest.approx(0.0)
        # routes scaled by 0
        for r in props["routes"]:
            assert r["trips"] == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# _compute_link_flow_delta — OD adjustment path (extra_od_fcs)
# ---------------------------------------------------------------------------


class TestComputeLinkFlowDeltaOdAdjust:
    def test_od_adjust_increases_link_flow(self):
        zones = _zones_fc(_zone("Z1", 0.0), _zone("Z2", 0.0))
        base_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A", "B")], origin_production=100.0)
        )
        od_adjust_fc = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A", "B")], origin_production=200.0)
        )
        delta = _compute_link_flow_delta(
            base_routes, _routes_fc(), _routes_fc(), zones, od_adjust_fc
        )
        assert delta["A"] == pytest.approx((100.0, 200.0))
        assert delta["B"] == pytest.approx((100.0, 200.0))

    def test_od_adjust_motif_only_produces_zero_delta(self):
        zones = _zones_fc(_zone("Z1", 0.0), _zone("Z2", 0.0))
        base_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A")], origin_production=100.0)
        )
        od_adjust_fc = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A")], origin_production=100.0)
        )
        delta = _compute_link_flow_delta(
            base_routes, _routes_fc(), _routes_fc(), zones, od_adjust_fc
        )
        if "A" in delta:
            fb, fa = delta["A"]
            assert fa - fb == pytest.approx(0.0, abs=1e-6)

    def test_od_adjust_zero_trips_removes_flow(self):
        zones = _zones_fc(_zone("Z1", 0.0), _zone("Z2", 0.0))
        base_routes = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A", "B")], origin_production=150.0)
        )
        od_adjust_fc = _routes_fc(
            _od_feature("Z1", "Z2", [_route(1.0, "A", "B")], origin_production=0.0)
        )
        delta = _compute_link_flow_delta(
            base_routes, _routes_fc(), _routes_fc(), zones, od_adjust_fc
        )
        assert delta["A"] == pytest.approx((150.0, 0.0))


# ---------------------------------------------------------------------------
# _find_pairs_using_links — orphan link detection
# ---------------------------------------------------------------------------


class TestFindPairsUsingLinks:
    """_find_pairs_using_links underlies the orphan-link re-routing in step [3d/7]."""

    def _routes(self, *features):
        return {"type": "FeatureCollection", "features": list(features)}

    def _pair(self, from_id, to_id, *link_ids):
        return {
            "type": "Feature",
            "geometry": None,
            "properties": {
                "fromZoneId": from_id,
                "toZoneId": to_id,
                "fromType": "zone",
                "toType": "zone",
                "tripFraction": 0.5,
                "originProduction": 100.0,
                "routes": [{"trips": 0.5, "linkPath": list(link_ids)}],
            },
        }

    def test_finds_pair_using_orphan_link(self):
        routes_fc = self._routes(self._pair("Z1", "Z2", "old_link_1", "old_link_2"))
        result = _find_pairs_using_links(routes_fc, {"old_link_1"})
        assert len(result) == 1
        assert result[0]["fromId"] == "Z1"
        assert result[0]["toId"] == "Z2"

    def test_ignores_pair_not_using_orphan_link(self):
        routes_fc = self._routes(self._pair("Z1", "Z2", "live_link_A", "live_link_B"))
        result = _find_pairs_using_links(routes_fc, {"old_link_1"})
        assert result == []

    def test_finds_pair_when_only_one_route_uses_orphan(self):
        pair = {
            "type": "Feature",
            "geometry": None,
            "properties": {
                "fromZoneId": "Z1",
                "toZoneId": "Z2",
                "fromType": "zone",
                "toType": "zone",
                "tripFraction": 0.5,
                "originProduction": 100.0,
                "routes": [
                    {"trips": 0.3, "linkPath": ["old_link_1"]},
                    {"trips": 0.2, "linkPath": ["live_link_B"]},
                ],
            },
        }
        result = _find_pairs_using_links(self._routes(pair), {"old_link_1"})
        assert len(result) == 1

    def test_multiple_pairs_only_affected_returned(self):
        routes_fc = self._routes(
            self._pair("Z1", "Z2", "old_link_1"),
            self._pair("Z2", "Z3", "live_link_A"),
            self._pair("Z3", "Z4", "old_link_1", "live_link_B"),
        )
        result = _find_pairs_using_links(routes_fc, {"old_link_1"})
        assert len(result) == 2
        ids = {(r["fromId"], r["toId"]) for r in result}
        assert ("Z1", "Z2") in ids
        assert ("Z3", "Z4") in ids

    def test_empty_orphan_set_returns_nothing(self):
        routes_fc = self._routes(self._pair("Z1", "Z2", "link_X"))
        assert _find_pairs_using_links(routes_fc, set()) == []

    def test_empty_routes_fc_returns_nothing(self):
        assert (
            _find_pairs_using_links({"type": "FeatureCollection", "features": []}, {"old_link"})
            == []
        )
