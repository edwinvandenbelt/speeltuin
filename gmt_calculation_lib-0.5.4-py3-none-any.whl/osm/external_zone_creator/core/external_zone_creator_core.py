"""external_zone_creator_core.py — Pure-Python core for external zone creation.

Creates synthetic **external zones** on the *boundary nodes* of a road network:
the nodes that lie on the outer edge (convex or concave hull) of the network's
footprint.  Every boundary node with enough daily traffic receives an external
zone whose production and attraction are proportional to the combined link
capacity at that node, scaled to a user-configurable fraction of the total
internal population.

Boundary detection
------------------
Boundary nodes are the vertices of the network's hull.  By default a **concave
hull** (k-nearest-neighbours) is used so the boundary follows the true shape of
the network — nodes in "bays"/indentations are included — instead of the
rectangular bounding box.  A convex hull is available as a simpler alternative.

Movement filter
---------------
A boundary node only becomes an external zone when its daily traffic
(``flow24hrs``, vehicles/24h) reaches ``min_daily_movements`` on **at least one**
direction (incoming or outgoing).  Nodes where *both* the incoming and outgoing
daily totals stay below the threshold are dropped.  Set the threshold to ``0``
to keep every boundary node.

Feedlinks connecting each external zone to its boundary node are also created
and appended to the existing feedlinks collection.

Zone naming
-----------
Each zone gets an intuitive ``zoneName`` derived from the highest-class link
attached to its boundary node, using one of three tiers:

  Tier 1 — motorway / trunk  : "towards {ref} ({compass})"
  Tier 2 — provincial road   : reverse-geocoded municipality name
  Tier 3 — local road        : OSM road name if available

When the required label is absent the zone falls back to "boundary ({compass})".
Duplicate names within a single run are disambiguated by appending " 2", " 3".

Public API
----------
create_external_zones(network_fc, zones_fc, feedlinks_fc, bbox, *, external_share,
                      min_daily_movements, hull_type, hull_k,
                      gisco_url, gisco_timeout)
    -> tuple[dict, dict, dict]
    Returns (updated_zones_fc, updated_feedlinks_fc, stats).
"""

from __future__ import annotations

import logging
from collections import defaultdict

from gmt_shared.geo_utils import _bearing_deg, _compass_8_label_en

from osm.external_zone_creator.domain.hull import hull_vertices

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

DEFAULT_EXTERNAL_SHARE: float = 0.40

# Minimum daily traffic (flow24hrs, vehicles/24h) a boundary node needs on at
# least one direction to receive an external zone.
DEFAULT_MIN_DAILY_MOVEMENTS: float = 300.0

# Hull used to detect boundary nodes: "concave" (follows network shape) or
# "convex".  Concave uses the k-nearest-neighbours parameter below.
DEFAULT_HULL_TYPE: str = "concave"
DEFAULT_HULL_K: int = 3

_DEFAULT_GISCO_URL = "https://gisco-services.ec.europa.eu"
_DEFAULT_GISCO_TIMEOUT = 10

# Multiplier applied on top of link capacity to give extra weight to boundary
# nodes on high-class roads.  A motorway boundary pulls in much more
# through-traffic than a residential-street boundary even when their capacities
# are similar.
_HIGHWAY_WEIGHTS: dict[str, float] = {
    "motorway": 8.0,
    "motorway_link": 8.0,
    "trunk": 8.0,
    "trunk_link": 8.0,
    "primary": 4.0,
    "primary_link": 4.0,
    "secondary": 4.0,
    "secondary_link": 4.0,
    "tertiary": 2.0,
    "tertiary_link": 2.0,
    "unclassified": 2.0,
}

# Road class rank used to determine which link is "most prominent" at a boundary
# node when multiple links converge there.  Lower value = higher class.
_HIGHWAY_RANK: dict[str, int] = {
    "motorway": 1,
    "motorway_link": 1,
    "trunk": 1,
    "trunk_link": 1,
    "primary": 2,
    "primary_link": 2,
    "secondary": 2,
    "secondary_link": 2,
    "tertiary": 2,
    "tertiary_link": 2,
}

# Motorway / trunk highway types that use the road ref for naming (tier 1).
_TIER1_HIGHWAYS: frozenset[str] = frozenset(
    {
        "motorway",
        "motorway_link",
        "trunk",
        "trunk_link",
    }
)

# Provincial / inter-urban highway types where we geocode the destination
# municipality (tier 2).  Only applied when link speed > 50 km/h.
_TIER2_HIGHWAYS: frozenset[str] = frozenset(
    {
        "primary",
        "primary_link",
        "secondary",
        "secondary_link",
        "tertiary",
        "tertiary_link",
    }
)

EXTERNAL_ZONE_PROPERTIES: tuple[str, ...] = (
    "zoneId",
    "zoneClass",
    "zoneName",
    "centroidLon",
    "centroidLat",
    "production",
    "attraction",
    "nBuildings",
)

EXTERNAL_FEEDLINK_PROPERTIES: tuple[str, ...] = (
    "zoneId",
    "fromNode",
    "toNode",
    "length",
    "capacity",
    "flow",
)

__all__ = [
    "EXTERNAL_ZONE_PROPERTIES",
    "EXTERNAL_FEEDLINK_PROPERTIES",
    "DEFAULT_EXTERNAL_SHARE",
    "DEFAULT_MIN_DAILY_MOVEMENTS",
    "DEFAULT_HULL_TYPE",
    "DEFAULT_HULL_K",
    "create_external_zones",
]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _highway_weight(props: dict) -> float:
    """Return a road-class multiplier for ``props`` based on the ``highway`` tag.

    Higher-class roads attract more through-traffic, so their external zones
    should receive proportionally more production/attraction.
    Falls back to 1.0 for unrecognised or absent tags.
    """
    hw = (props.get("highway") or "").strip().lower()
    return _HIGHWAY_WEIGHTS.get(hw, 1.0)


def _node_coords(network_fc: dict) -> dict[str, tuple[float, float]]:
    """Extract a nodeId → (lon, lat) mapping from network geometry."""
    coords: dict[str, tuple[float, float]] = {}
    for feat in network_fc.get("features") or []:
        geom = feat.get("geometry") or {}
        pts: list = geom.get("coordinates") or []
        if not pts:
            continue
        p = feat.get("properties") or {}
        fn = str(p.get("fromNode") or "")
        tn = str(p.get("toNode") or "")
        if fn and pts:
            coords[fn] = (float(pts[0][0]), float(pts[0][1]))
        if tn and pts:
            coords[tn] = (float(pts[-1][0]), float(pts[-1][1]))
    return coords


def _total_population(zones_fc: dict) -> float:
    total = 0.0
    for feat in zones_fc.get("features") or []:
        total += float((feat.get("properties") or {}).get("production") or 0.0)
    return total


def _compass(lon: float, lat: float, bbox: list[float]) -> str:
    """Return 8-point English compass label from the bbox centre to (lon, lat)."""
    centre_lon = (bbox[0] + bbox[2]) / 2.0
    centre_lat = (bbox[1] + bbox[3]) / 2.0
    bearing = _bearing_deg(centre_lon, centre_lat, lon, lat)
    return _compass_8_label_en(bearing)


def _boundary_nodes(
    node_coords: dict[str, tuple[float, float]], hull_type: str, hull_k: int
) -> set[str]:
    """Return the set of node IDs that lie on the network's hull boundary."""
    coord_to_node: dict[tuple[float, float], str] = {}
    points: list[list[float]] = []
    for nid, (lon, lat) in node_coords.items():
        key = (lon, lat)
        if key not in coord_to_node:
            coord_to_node[key] = nid
            points.append([lon, lat])

    verts = hull_vertices(points, hull_type=hull_type, k=hull_k)
    boundary: set[str] = set()
    for v in verts:
        key = (float(v[0]), float(v[1]))
        nid = coord_to_node.get(key)
        if nid is not None:
            boundary.add(nid)
    return boundary


def _zone_name(
    lon: float,
    lat: float,
    bbox: list[float],
    highway: str,
    speed: float,
    ref: str,
    road_name: str,
    gisco_url: str,
    gisco_timeout: int,
) -> str:
    """Return an intuitive display name for an external zone.

    Three tiers, based on the most prominent link at the boundary node:

    Tier 1 (motorway/trunk): "towards {ref} ({compass})"
    Tier 2 (provincial, speed > 50): "towards {municipality} ({compass})"
    Tier 3 (local road, speed <= 50):  "towards {name} ({compass})"

    Falls back to "boundary ({compass})" when labels are unavailable.
    """
    compass = _compass(lon, lat, bbox)
    hw = (highway or "").strip().lower()

    if hw in _TIER1_HIGHWAYS:
        label = (ref or "").strip() or "Motorway"
        return f"towards {label} ({compass})"

    if hw in _TIER2_HIGHWAYS and speed > 50.0:
        # Geocode the boundary-node location to find the neighbouring municipality.
        try:
            from osm.zone_population_estimator.domain.gisco import (
                reverse_geocode,
            )

            place_info = reverse_geocode(lon, lat, base_url=gisco_url, timeout=gisco_timeout)
            municipality = (place_info.get("name") or "").strip()
        except Exception:
            municipality = ""
        if municipality:
            return f"towards {municipality} ({compass})"
        return f"boundary ({compass})"

    # Tier 3 — local road: use the road name tag if present.
    name = (road_name or "").strip()
    if name:
        return f"towards {name} ({compass})"
    return f"boundary ({compass})"


def _deduplicate_names(names: list[str]) -> list[str]:
    """Add numeric suffixes to duplicate names so every entry is unique.

    The first occurrence keeps its original name; subsequent duplicates get
    " 2", " 3", etc.  Only applies when there actually are duplicates.
    """
    seen: dict[str, int] = {}
    result: list[str] = []
    for name in names:
        count = seen.get(name, 0) + 1
        seen[name] = count
        result.append(name if count == 1 else f"{name} {count}")
    return result


# ---------------------------------------------------------------------------
# Core
# ---------------------------------------------------------------------------


def create_external_zones(
    network_fc: dict,
    zones_fc: dict,
    feedlinks_fc: dict,
    bbox: list[float],
    *,
    external_share: float = DEFAULT_EXTERNAL_SHARE,
    min_daily_movements: float = DEFAULT_MIN_DAILY_MOVEMENTS,
    hull_type: str = DEFAULT_HULL_TYPE,
    hull_k: int = DEFAULT_HULL_K,
    gisco_url: str = _DEFAULT_GISCO_URL,
    gisco_timeout: int = _DEFAULT_GISCO_TIMEOUT,
) -> tuple[dict, dict, dict]:
    """Create external zones on the network's boundary nodes and append them.

    An external zone is created for each network node that lies on the network's
    hull (convex or concave) and carries at least ``min_daily_movements`` daily
    vehicles on at least one direction.

    For a boundary node *i*:

      * links that **start** at *i* (``fromNode == i``) carry traffic entering
        the network — they contribute to *i*'s **production**;
      * links that **end** at *i* (``toNode == i``) carry traffic leaving the
        network — they contribute to *i*'s **attraction**.

    The production of each external zone is:

        production_i = external_share * total_population
                       * (weight_in_i / total_weight_in)

    where ``weight_in_i`` = sum(capacity * highway_weight) over links starting at
    *i* (attraction is the symmetric expression over links ending at *i*).

    Parameters
    ----------
    network_fc:
        Directed network FeatureCollection.  Each feature must have
        ``fromNode``, ``toNode``, ``capacity``, ``highway``, ``ref``, ``name``,
        ``speed`` and ``flow24hrs`` properties and a LineString geometry whose
        first coordinate corresponds to ``fromNode`` and last to ``toNode``.
    zones_fc:
        Existing zones FeatureCollection.  The ``production`` field is used to
        derive total population.  External zones are appended to a copy.
    feedlinks_fc:
        Existing feedlinks FeatureCollection.  External feedlinks are appended
        to a copy.
    bbox:
        ``[min_lon, min_lat, max_lon, max_lat]`` — used only to orient the
        compass labels in zone names (direction from the area centre).
    external_share:
        Fraction of total internal population to assign as external
        production/attraction.  Default: 0.40 (40%).
    min_daily_movements:
        Minimum daily traffic (``flow24hrs``) required on the incoming *or*
        outgoing direction of a boundary node for it to receive a zone.  Nodes
        below the threshold on both directions are skipped.  Default: 150.
    hull_type:
        ``"concave"`` (default) or ``"convex"`` — how the network boundary is
        determined.
    hull_k:
        Neighbour count for the concave hull (higher = smoother boundary).
        Default: 3.  Ignored for the convex hull.
    gisco_url:
        Base URL of the GISCO services endpoint used for reverse geocoding
        provincial road zones.  Default: ``https://gisco-services.ec.europa.eu``.
    gisco_timeout:
        HTTP timeout in seconds for GISCO reverse-geocode requests.  Default: 10.

    Returns
    -------
    updated_zones_fc:
        Copy of *zones_fc* with external zone features appended.
    updated_feedlinks_fc:
        Copy of *feedlinks_fc* with external feedlinks appended (one entry and
        one exit feedlink per external zone).
    stats:
        ``{"externalZones", "externalFeedlinks", "boundaryNodes",
           "filteredNodes", "hullType", "minDailyMovements",
           "totalExternalProduction", "totalExternalAttraction"}``
    """
    node_coords = _node_coords(network_fc)

    # Determine the boundary nodes (hull vertices) of the network.
    boundary_nodes = _boundary_nodes(node_coords, hull_type, hull_k)

    if not boundary_nodes:
        logger.warning("No boundary nodes found; no external zones created.")
        return (
            dict(zones_fc),
            dict(feedlinks_fc),
            {
                "externalZones": 0,
                "externalFeedlinks": 0,
                "boundaryNodes": 0,
                "filteredNodes": 0,
                "hullType": hull_type,
                "minDailyMovements": min_daily_movements,
                "totalExternalProduction": 0.0,
                "totalExternalAttraction": 0.0,
            },
        )

    # Accumulate per boundary node:
    #   node_in_*   — links starting at the node (fromNode == node) → production
    #   node_out_*  — links ending at the node   (toNode   == node) → attraction
    node_in_weight: dict[str, float] = defaultdict(float)
    node_out_weight: dict[str, float] = defaultdict(float)
    node_in_cap: dict[str, float] = defaultdict(float)
    node_out_cap: dict[str, float] = defaultdict(float)
    node_in_daily: dict[str, float] = defaultdict(float)
    node_out_daily: dict[str, float] = defaultdict(float)
    node_highway: dict[str, str] = {}
    node_ref: dict[str, str] = {}
    node_road_name: dict[str, str] = {}
    node_speed: dict[str, float] = {}

    def _update_prominence(node: str, props: dict, spd: float) -> None:
        hw = (props.get("highway") or "").strip().lower()
        cur_rank = _HIGHWAY_RANK.get(node_highway.get(node, ""), 99)
        new_rank = _HIGHWAY_RANK.get(hw, 3)
        if new_rank < cur_rank:
            node_highway[node] = hw
            node_ref[node] = (props.get("ref") or "").strip()
            node_road_name[node] = (props.get("name") or "").strip()
            node_speed[node] = spd
        elif new_rank == cur_rank and spd > node_speed.get(node, 0.0):
            node_ref[node] = (props.get("ref") or "").strip()
            node_road_name[node] = (props.get("name") or "").strip()
            node_speed[node] = spd

    for feat in network_fc.get("features") or []:
        p = feat.get("properties") or {}
        fn = str(p.get("fromNode") or "")
        tn = str(p.get("toNode") or "")
        fn_boundary = fn in boundary_nodes
        tn_boundary = tn in boundary_nodes
        if not fn_boundary and not tn_boundary:
            continue
        cap = float(p.get("capacity") or 0.0)
        hw_w = _highway_weight(p)
        daily = float(p.get("flow24hrs") or 0.0)
        spd = float(p.get("speed") or 0.0)

        if fn_boundary:
            # Link starts at the boundary node → traffic entering → production.
            node_in_weight[fn] += cap * hw_w
            node_in_cap[fn] += cap
            node_in_daily[fn] += daily
            _update_prominence(fn, p, spd)
        if tn_boundary:
            # Link ends at the boundary node → traffic leaving → attraction.
            node_out_weight[tn] += cap * hw_w
            node_out_cap[tn] += cap
            node_out_daily[tn] += daily
            _update_prominence(tn, p, spd)

    # Boundary nodes that actually have at least one incident link.
    candidate_nodes = set(node_in_weight) | set(node_out_weight)

    # Movement filter: keep a node when its incoming OR outgoing daily traffic
    # reaches the threshold.  Drop nodes below the threshold on both directions.
    kept_nodes = {
        n
        for n in candidate_nodes
        if node_in_daily.get(n, 0.0) >= min_daily_movements
        or node_out_daily.get(n, 0.0) >= min_daily_movements
    }
    filtered_count = len(candidate_nodes) - len(kept_nodes)

    if not kept_nodes:
        logger.warning(
            "external_zone_creator: %d boundary nodes, all below the "
            "min_daily_movements=%.0f threshold; no external zones created.",
            len(candidate_nodes),
            min_daily_movements,
        )
        return (
            dict(zones_fc),
            dict(feedlinks_fc),
            {
                "externalZones": 0,
                "externalFeedlinks": 0,
                "boundaryNodes": len(candidate_nodes),
                "filteredNodes": filtered_count,
                "hullType": hull_type,
                "minDailyMovements": min_daily_movements,
                "totalExternalProduction": 0.0,
                "totalExternalAttraction": 0.0,
            },
        )

    # Budgets are normalised over the kept nodes only.
    total_in_weight = sum(node_in_weight.get(n, 0.0) for n in kept_nodes)
    total_out_weight = sum(node_out_weight.get(n, 0.0) for n in kept_nodes)
    total_population = _total_population(zones_fc)
    production_budget = external_share * total_population
    attraction_budget = external_share * total_population

    logger.info(
        "external_zone_creator: %d boundary nodes, %d kept (>=%.0f daily), "
        "%d filtered, hull=%s, total_population=%.0f",
        len(candidate_nodes),
        len(kept_nodes),
        min_daily_movements,
        filtered_count,
        hull_type,
        total_population,
    )

    # Compute raw zone names (before deduplication), in a stable node order.
    sorted_nodes = sorted(kept_nodes)
    raw_names: list[str] = [
        _zone_name(
            lon=node_coords.get(n, (0.0, 0.0))[0],
            lat=node_coords.get(n, (0.0, 0.0))[1],
            bbox=bbox,
            highway=node_highway.get(n, ""),
            speed=node_speed.get(n, 0.0),
            ref=node_ref.get(n, ""),
            road_name=node_road_name.get(n, ""),
            gisco_url=gisco_url,
            gisco_timeout=gisco_timeout,
        )
        for n in sorted_nodes
    ]
    zone_names = _deduplicate_names(raw_names)

    # Build external zone and feedlink features.
    new_zone_feats: list[dict] = []
    new_feedlink_feats: list[dict] = []

    for boundary_node, zone_name in zip(sorted_nodes, zone_names, strict=True):
        lon, lat = node_coords.get(boundary_node, (0.0, 0.0))
        zone_id = f"ext_{boundary_node}"
        zone_node = f"ZONE_{zone_id}"

        in_w = node_in_weight.get(boundary_node, 0.0)
        out_w = node_out_weight.get(boundary_node, 0.0)
        in_cap = node_in_cap.get(boundary_node, 0.0)
        out_cap = node_out_cap.get(boundary_node, 0.0)

        production = (
            round(production_budget * (in_w / total_in_weight), 2) if total_in_weight > 0.0 else 0.0
        )
        attraction = (
            round(attraction_budget * (out_w / total_out_weight), 2)
            if total_out_weight > 0.0
            else 0.0
        )

        # Zone feature (Point geometry at the boundary node's location).
        new_zone_feats.append(
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [lon, lat]},
                "properties": {
                    "zoneId": zone_id,
                    "zoneClass": "EXTERNAL",
                    "zoneName": zone_name,
                    "centroidLon": lon,
                    "centroidLat": lat,
                    "production": production,
                    "attraction": attraction,
                    "nBuildings": 0,
                },
            }
        )

        # Entry feedlink: zone_node → boundary_node (traffic entering the network).
        # Capacity based on links starting at the node; 0 when there are none.
        new_feedlink_feats.append(
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[lon, lat], [lon, lat]]},
                "properties": {
                    "zoneId": zone_id,
                    "fromNode": zone_node,
                    "toNode": boundary_node,
                    "length": 1.0,
                    "capacity": in_cap,
                    "flow": 0.0,
                },
            }
        )

        # Exit feedlink: boundary_node → zone_node (traffic leaving the network).
        # Capacity based on links ending at the node; 0 when there are none.
        new_feedlink_feats.append(
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [[lon, lat], [lon, lat]]},
                "properties": {
                    "zoneId": zone_id,
                    "fromNode": boundary_node,
                    "toNode": zone_node,
                    "length": 1.0,
                    "capacity": out_cap,
                    "flow": 0.0,
                },
            }
        )

    # Build updated FCs (shallow copies with extended feature lists).
    updated_zones = {
        **zones_fc,
        "features": list(zones_fc.get("features") or []) + new_zone_feats,
    }
    updated_feedlinks = {
        **feedlinks_fc,
        "features": list(feedlinks_fc.get("features") or []) + new_feedlink_feats,
    }

    n_zones = len(new_zone_feats)
    n_feedlinks = len(new_feedlink_feats)
    stats: dict = {
        "externalZones": n_zones,
        "externalFeedlinks": n_feedlinks,
        "boundaryNodes": len(candidate_nodes),
        "filteredNodes": filtered_count,
        "hullType": hull_type,
        "minDailyMovements": min_daily_movements,
        "totalExternalProduction": round(production_budget, 2),
        "totalExternalAttraction": round(attraction_budget, 2),
    }
    logger.info(
        "external_zone_creator: created %d external zones, %d feedlinks",
        n_zones,
        n_feedlinks,
    )
    return updated_zones, updated_feedlinks, stats
