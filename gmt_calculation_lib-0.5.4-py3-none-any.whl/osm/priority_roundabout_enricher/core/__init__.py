"""Core logic for priority road and roundabout enrichment."""

from __future__ import annotations

from osm.priority_roundabout_enricher.core.priority_roundabout_enricher_core import (
    enrich_network_with_priority_and_roundabouts,
)

__all__ = ["enrich_network_with_priority_and_roundabouts"]
