"""Pure-Python enrichment for roundabout and priority-road detection.

Adds per-link columns:

| Column | Type | Meaning |
|---|---|---|
| ``isRoundabout`` | bool | ``True`` when the link is part of a roundabout ring. |
| ``roundaboutType`` | str | ``"roundabout"``, ``"mini_roundabout"`` or ``"none"``. |
| ``priorityRoad`` | bool | ``True`` when the link is on a priority road. |
| ``priorityRoadSource`` | str | Source of the priority classification. |

Rotundabout detection is primarily tag-based.  For the OSM pipeline the raw
Overpass elements are inspected directly.  For the Dutch ``prepare`` pipeline
the NWB/Spectrum network has no OSM tags, so we use the fetched OSM road
elements and snap roundabout ways to the network by proximity.

Priority-road detection uses two sources:

* In the Netherlands: NDW traffic-sign features with ``rvvCode == "B1"``
  (voorrangsweg) are snapped to the nearest network link.
* Any country: OSM tags ``priority_road=designated`` or ``priority=yes`` on a
  road way.  Like roundabouts, OSM ways are snapped to the network when the
  network itself does not carry OSM tags.

The module has no I/O dependencies beyond the stdlib and the repo's shared
``geo`` helper; all geometry operations use the Shapely 2.x API.
"""

from __future__ import annotations

import logging
import math
from collections import defaultdict
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Iterable

logger = logging.getLogger(__name__)

#: Overpass tags that identify a roundabout link.
_ROUNABOUT_TAGS: dict[str, tuple[str, ...]] = {
    "junction": ("roundabout",),
    "highway": ("mini_roundabout",),
}

#: OSM tags that identify a priority road.  Directional suffixes (:forward/
#: :backward) are ignored because priority applies in both directions.
_PRIORITY_TAGS: dict[str, tuple[str, ...]] = {
    "priority_road": ("designated", "yes"),
    "priority": ("yes",),
}

#: Dutch NDW RVV codes that start/end a priority-road section.
_PRIORITY_SIGN_CODES: set[str] = {"B1"}
_END_PRIORITY_SIGN_CODES: set[str] = {"B3"}

#: Dutch NDW RVV code for a roundabout (verplichte rijrichting) sign.
_ROUNDABOUT_SIGN_CODES: set[str] = {"D1"}

#: OSM tag that identifies a roundabout way (used as D1 equivalent).
_ROUNDABOUT_SIGN_TAG: tuple[str, str] = ("junction", "roundabout")

#: Default snap distance in metres for OSM ways / signs to network links.
_DEFAULT_SNAP_M: float = 30.0


def _link_id(feature: dict) -> str | int | None:
    return (feature.get("properties") or {}).get("linkId")


def _to_node(feature: dict) -> str | int | None:
    return (feature.get("properties") or {}).get("toNode")


def _from_node(feature: dict) -> str | int | None:
    return (feature.get("properties") or {}).get("fromNode")


def _coords(feature: dict) -> list[list[float]]:
    geom = feature.get("geometry") or {}
    if geom.get("type") == "LineString":
        return geom.get("coordinates") or []
    return []


def _to_linestring(feature: dict):
    """Return a shapely LineString from a GeoJSON feature, or None."""
    try:
        from shapely.geometry import LineString

        coords = _coords(feature)
        if len(coords) >= 2:
            return LineString(coords)
    except Exception:
        pass
    return None


def _linestring_midpoint(ls) -> tuple[float, float]:
    p = ls.interpolate(0.5, normalized=True)
    return (p.x, p.y)


def _extract_osm_way_tags(elements: Iterable[dict]) -> dict[str | int, dict[str, str]]:
    """Return ``{way_id: tags}`` for all way elements."""
    result: dict[str | int, dict[str, str]] = {}
    for elem in elements:
        if elem.get("type") != "way":
            continue
        tags = elem.get("tags") or {}
        if tags:
            result[elem.get("id")] = tags
    return result


def _osm_way_geometry(elements: Iterable[dict]) -> dict[str | int, list[list[float]]]:
    """Return ``{way_id: [(lon, lat), ...]}`` for all way elements."""
    result: dict[str | int, list[list[float]]] = {}
    for elem in elements:
        if elem.get("type") != "way":
            continue
        geom = elem.get("geometry") or []
        pts = [[float(p["lon"]), float(p["lat"])] for p in geom if "lon" in p and "lat" in p]
        if pts:
            result[elem.get("id")] = pts
    return result


def _find_osm_roundabout_ways(elements: Iterable[dict]) -> list[tuple[str | int, str]]:
    """Return list of (way_id, roundabout_type) for OSM roundabout ways."""
    result: list[tuple[str | int, str]] = []
    for elem in elements:
        if elem.get("type") != "way":
            continue
        tags = elem.get("tags") or {}
        if tags.get("junction") in _ROUNABOUT_TAGS["junction"]:
            result.append((elem.get("id"), "roundabout"))
        elif tags.get("highway") in _ROUNABOUT_TAGS["highway"]:
            result.append((elem.get("id"), "mini_roundabout"))
    return result


def _find_osm_priority_ways(elements: Iterable[dict]) -> list[str | int]:
    """Return list of OSM way ids that are tagged as priority roads."""
    result: list[str | int] = []
    for elem in elements:
        if elem.get("type") != "way":
            continue
        tags = elem.get("tags") or {}
        for key, values in _PRIORITY_TAGS.items():
            base_key = key.split(":")[0]
            for k in tags:
                if (k == base_key or k.startswith(f"{base_key}:")) and tags[k] in values:
                    result.append(elem.get("id"))
                    break
    return result


def _prepare_link_index(feature: dict):
    """Pre-compute shapely geometry and midpoint for a network link."""
    from shapely.geometry import LineString

    coords = _coords(feature)
    if len(coords) < 2:
        return None
    ls = LineString(coords)
    return {
        "feature": feature,
        "line": ls,
        "mid": ls.interpolate(0.5, normalized=True),
        "length": ls.length,
    }


def _snap_point_to_link_index(point, prepared: list[dict], max_m: float):
    """Return the prepared link closest to *point* within *max_m*.

    Uses a cheap flat-earth distance in degrees, scaled by latitude.
    """
    from math import cos, radians

    best = None
    best_dist_m = float("inf")
    lat0 = point.y
    scale = cos(radians(lat0)) * 111_000.0 if lat0 is not None else 111_000.0
    for prep in prepared:
        dist_deg = prep["line"].distance(point)
        dist_m = dist_deg * scale
        if dist_m <= max_m and dist_m < best_dist_m:
            best = prep
            best_dist_m = dist_m
    return best


def _snap_way_to_network(
    way_coords: list[list[float]],
    prepared: list[dict],
    max_m: float,
) -> dict | None:
    """Snap a way to the network link whose midpoint is closest to the way."""
    from shapely.geometry import LineString

    if len(way_coords) < 2:
        return None
    way_ls = LineString(way_coords)
    best = None
    best_dist_m = float("inf")
    for prep in prepared:
        dist_deg = way_ls.distance(prep["mid"])
        lat = prep["mid"].y
        scale = 111_000.0
        try:
            from math import cos, radians

            scale = cos(radians(lat)) * 111_000.0
        except Exception:
            pass
        dist_m = dist_deg * scale
        if dist_m <= max_m and dist_m < best_dist_m:
            best = prep
            best_dist_m = dist_m
    return best


def _wvk_id_link_index(
    network_fc: dict,
) -> tuple[dict[str | int, list[dict]], dict[str | int, list[dict]]]:
    """Build indices ``wvk_id -> [link_feature, ...]`` split by driving direction.

    NDW signs carry ``drivingDirection`` (``H`` = heen, ``T`` = terug).  On the
    directed network the forward directed link follows the ``fromNode`` ->
    ``toNode`` ordering of the underlying NWB road section, so it maps to
    direction ``H``.  The reverse directed link maps to direction ``T``.  For
    links that are not part of a bidirectional pair we use the properties as-is
    and assume heen maps to the sign's ``H``.
    """
    heen_by_wvk: dict[str | int, list[dict]] = defaultdict(list)
    terug_by_wvk: dict[str | int, list[dict]] = defaultdict(list)
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        wvk_ids = props.get("wvkIds")
        if not wvk_ids:
            continue
        rev = props.get("reverseLinkIds") or []
        # A positive linkId with reverseLinkIds indicates the heen half of a
        # bidirectional pair.  A negative linkId (or string starting with '-') is
        # the terug half.  One-way links (no reverseLinkIds) are treated as heen.
        link_id = props.get("linkId")
        try:
            is_terug = bool(rev) and int(link_id) < 0
        except TypeError, ValueError:
            is_terug = bool(rev) and isinstance(link_id, str) and link_id.startswith("-")
        target = terug_by_wvk if is_terug else heen_by_wvk
        for wvk_id in wvk_ids:
            if wvk_id is None or wvk_id == "":
                continue
            target[wvk_id].append(feat)
    return heen_by_wvk, terug_by_wvk


def _match_sign_to_link(
    sign: dict,
    heen_by_wvk: dict[str | int, list[dict]],
    terug_by_wvk: dict[str | int, list[dict]],
    prepared: list[dict],
    max_m: float,
) -> dict | None:
    """Return the best network link for a single sign feature.

    Prefer exact matching by ``roadSectionId`` + ``drivingDirection``.
    Fall back to nearest-distance snapping when the id is missing or unmatched.
    """
    from shapely.geometry import Point

    props = sign.get("properties") or {}
    road_section_id = props.get("roadSectionId")
    direction = props.get("drivingDirection")

    if road_section_id not in (None, ""):
        candidates: list[dict] = []
        if isinstance(road_section_id, str):
            for raw_id in road_section_id.split(","):
                raw_id = raw_id.strip()
                if raw_id:
                    candidates.extend(heen_by_wvk.get(raw_id, []))
                    candidates.extend(terug_by_wvk.get(raw_id, []))
        else:
            candidates.extend(heen_by_wvk.get(road_section_id, []))
            candidates.extend(terug_by_wvk.get(road_section_id, []))

        if direction == "H":
            directed = [f for f in candidates if f in heen_by_wvk.get(road_section_id, [])]
            if directed:
                candidates = directed
            elif len(candidates) > 1:
                # If direction did not pick a heen link (e.g. roadSectionId is a
                # comma list not resolved above), keep direction-asymmetric finds.
                pass
        elif direction == "T":
            directed = [f for f in candidates if f in terug_by_wvk.get(road_section_id, [])]
            if directed:
                candidates = directed

        if candidates:
            # When several links share the same wvk_id, choose the one whose
            # midpoint is closest to the sign point.
            geom = sign.get("geometry") or {}
            coords = geom.get("coordinates") or []
            if len(coords) >= 2:
                point = Point(coords[0], coords[1])
                preps = {id(p["feature"]): p for p in prepared}
                best = None
                best_dist_m = float("inf")
                for feat in candidates:
                    prep = preps.get(id(feat))
                    if prep is None:
                        continue
                    lat = point.y
                    from math import cos, radians

                    scale = cos(radians(lat)) * 111_000.0 if lat is not None else 111_000.0
                    dist_m = prep["line"].distance(point) * scale
                    if dist_m < best_dist_m:
                        best = prep
                        best_dist_m = dist_m
                return best
            return _prepare_link_index(candidates[0])

    # Fallback: distance-based snapping.
    geom = sign.get("geometry") or {}
    if geom.get("type") == "Point":
        coords = geom.get("coordinates") or []
        if len(coords) >= 2:
            return _snap_point_to_link_index(Point(coords[0], coords[1]), prepared, max_m)
    return None


def _mark_priority_from_signs(
    network_fc: dict,
    sign_features: Iterable[dict],
    max_m: float = _DEFAULT_SNAP_M,
) -> set[str | int]:
    """Snap B1/B3 signs to network links and mark priority sections.

    Returns the set of directed ``linkId`` values that carry a B3 sign.  These
    links are still priority roads, but they are explicitly ending priority and
    therefore may need a give-way marker at their end node.
    """
    prepared = [_prepare_link_index(f) for f in network_fc.get("features") or []]
    prepared = [p for p in prepared if p is not None]
    if not prepared:
        return set()

    heen_by_wvk, terug_by_wvk = _wvk_id_link_index(network_fc)

    starts: list[tuple[dict, dict]] = []
    ends: list[tuple[dict, dict]] = []
    for sign in sign_features:
        props = sign.get("properties") or {}
        code = props.get("rvvCode") or ""
        if code not in _PRIORITY_SIGN_CODES | _END_PRIORITY_SIGN_CODES:
            continue
        link = _match_sign_to_link(sign, heen_by_wvk, terug_by_wvk, prepared, max_m)
        if link is None:
            continue
        if code in _PRIORITY_SIGN_CODES:
            starts.append((link, sign))
        else:
            ends.append((link, sign))

    # Each B1 sign marks its snapped link as priority.  We intentionally keep
    # this local because linking sequential B1/B3 signs into continuous sections
    # would require route-graph traversal.  For our use-case a per-link flag is
    # sufficient; downstream models can propagate if needed.
    for link, _sign in starts:
        props = link["feature"].get("properties") or {}
        props["priorityRoad"] = True
        props["priorityRoadSource"] = "ndw_b1"

    # A B3 sign (einde voorrangsweg) is still located on the priority road
    # itself, so the snapped link remains a priority road.  We do NOT clear
    # priority here because the link that carries the sign is still part of the
    # priority section.
    b3_link_ids: set[str | int] = set()
    for link, _sign in ends:
        props = link["feature"].get("properties") or {}
        link_id = props.get("linkId")
        if link_id is not None:
            b3_link_ids.add(link_id)
        if not props.get("priorityRoad"):
            props["priorityRoad"] = True
            props["priorityRoadSource"] = "ndw_b3"
    return b3_link_ids


def _mark_roundabouts_from_osm(
    network_fc: dict,
    osm_elements: Iterable[dict],
    sign_features: Iterable[dict] | None = None,
    max_m: float = _DEFAULT_SNAP_M,
) -> None:
    """Mark roundabout links based on OSM roundabout way geometries.

    A ring candidate is only accepted when a D1 sign (NDW rvvCode D1) is
    present within *max_m* of the snapped link.  Roundabout links are also
    marked as priority roads.
    """
    features = network_fc.get("features") or []
    prepared = [_prepare_link_index(f) for f in features]
    prepared = [p for p in prepared if p is not None]
    if not prepared:
        return

    # Collect D1 sign points that are close enough to the network.
    d1_points = {
        (lon, lat)
        for lon, lat in _collect_roundabout_sign_points(sign_features, None, prepared, max_m)
    }
    if not d1_points:
        return

    way_geom = _osm_way_geometry(osm_elements)
    for way_id, rtype in _find_osm_roundabout_ways(osm_elements):
        coords = way_geom.get(way_id)
        if not coords:
            continue
        link = _snap_way_to_network(coords, prepared, max_m)
        if link is None:
            continue
        # Require a D1 sign near the snapped link.
        link_mid = link["mid"]
        lat = link_mid.y
        from math import cos, radians

        scale = cos(radians(lat)) * 111_000.0 if lat is not None else 111_000.0
        if not any(
            math.hypot((lon - link_mid.x) * scale, (lat_pt - link_mid.y) * 111_000.0) <= max_m
            for lon, lat_pt in d1_points
        ):
            continue
        props = link["feature"].get("properties") or {}
        props["isRoundabout"] = True
        props["roundaboutType"] = rtype
        props["priorityRoad"] = True
        props["priorityRoadSource"] = "osm_roundabout"


def _mark_priority_from_osm(
    network_fc: dict,
    osm_elements: Iterable[dict],
    max_m: float = _DEFAULT_SNAP_M,
) -> None:
    """Mark priority links based on OSM priority-road tag geometries."""
    prepared = [_prepare_link_index(f) for f in network_fc.get("features") or []]
    prepared = [p for p in prepared if p is not None]
    if not prepared:
        return

    way_geom = _osm_way_geometry(osm_elements)
    for way_id in _find_osm_priority_ways(osm_elements):
        coords = way_geom.get(way_id)
        if not coords:
            continue
        link = _snap_way_to_network(coords, prepared, max_m)
        if link is None:
            continue
        props = link["feature"].get("properties") or {}
        # Do not overwrite roundabout flag; but a priority flag is secondary.
        if not props.get("isRoundabout"):
            props["priorityRoad"] = True
            props["priorityRoadSource"] = "osm_priority_road"


def _is_car_oneway(feature: dict) -> bool:
    """Return True when the directed link is a real one-way CAR link.

    A true one-way link has a positive linkId and no reverseLinkIds after the
    bidirectional split.
    """
    props = feature.get("properties") or {}
    if props.get("mode") != "CAR":
        return False
    link_id = props.get("linkId")
    if link_id is None:
        return False
    try:
        if int(link_id) <= 0:
            return False
    except TypeError, ValueError:
        return False
    rev = props.get("reverseLinkIds")
    return not rev


def _link_ring_indices(features: list[dict], *, tolerance_m: float = 15.0) -> list[set[int]]:
    """Group one-way CAR links that form closed rings.

    Two links are connected when the end point of one is within *tolerance_m*
    of the start point of the other.  A connected component is considered a
    candidate ring when it contains at least three links.
    """
    starts: list[tuple[float, float]] = []
    ends: list[tuple[float, float]] = []
    oneway_idx: list[int] = []
    for i, feat in enumerate(features):
        if not _is_car_oneway(feat):
            continue
        coords = _coords(feat)
        if len(coords) < 2:
            continue
        starts.append((coords[0][0], coords[0][1]))
        ends.append((coords[-1][0], coords[-1][1]))
        oneway_idx.append(i)

    if not starts:
        return []

    # Build adjacency: directed edge from link i to link j when end_i ≈ start_j.
    # Use a flat-earth tolerance expressed in degrees.
    lats = [lat for _, lat in starts]
    avg_lat = sum(lats) / len(lats)
    scale_lon = 111_000.0 * math.cos(math.radians(avg_lat))
    scale_lat = 111_000.0

    n = len(oneway_idx)
    adj: dict[int, list[int]] = defaultdict(list)
    for i in range(n):
        ex, ey = ends[i]
        for j in range(n):
            if i == j:
                continue
            sx, sy = starts[j]
            dx = abs(ex - sx) * scale_lon
            dy = abs(ey - sy) * scale_lat
            if dx <= tolerance_m and dy <= tolerance_m and math.hypot(dx, dy) <= tolerance_m:
                adj[i].append(j)

    # Find directed cycles via DFS.  We only look for simple cycles that stay
    # inside a connected component.
    visited = [False] * n
    rings: list[set[int]] = []

    def _dfs(start: int, path: list[int], seen: set[int]) -> None:
        # Limit search depth to small rings.
        if len(path) > 12:
            return
        node = path[-1]
        for nxt in adj[node]:
            if nxt == start and len(path) >= 3:
                rings.append(set(path))
                return
            if nxt not in seen:
                _dfs(start, [*path, nxt], {*seen, nxt})

    for i in range(n):
        if visited[i]:
            continue
        _dfs(i, [i], {i})
        visited[i] = True

    # Deduplicate overlapping rings (keep the largest one per component).
    merged: list[set[int]] = []
    for ring in sorted(rings, key=len, reverse=True):
        if any(ring & existing == ring for existing in merged):
            continue
        merged.append(ring)

    return [{oneway_idx[k] for k in ring} for ring in merged]


def _ring_is_circular(
    features: list[dict],
    indices: set[int],
    *,
    radius_tolerance: float = 0.35,
) -> bool:
    """Check whether the polyline formed by a set of links resembles a circle.

    The ring's coordinates are collected, their centroid is computed, and the
    coefficient of variation of distances from the centroid is compared with
    *radius_tolerance*.  Rechte hoeken en ovondes worden zo ook geaccepteerd.
    """
    from shapely.geometry import MultiPoint

    points: list[tuple[float, float]] = []
    for i in indices:
        for lon, lat in _coords(features[i]):
            points.append((lon, lat))
    if len(points) < 3:
        return False
    mp = MultiPoint(points)
    centroid = mp.centroid
    cx, cy = centroid.x, centroid.y

    radii: list[float] = []
    for lon, lat in points:
        dx = (lon - cx) * 111_000.0 * math.cos(math.radians(cy))
        dy = (lat - cy) * 111_000.0
        radii.append(math.hypot(dx, dy))

    if not radii:
        return False
    mean_r = sum(radii) / len(radii)
    if mean_r < 1.0:
        # Mini-roundabout that's too small to judge geometry; accept it.
        return True
    std_r = math.sqrt(sum((r - mean_r) ** 2 for r in radii) / len(radii))
    return std_r / mean_r <= radius_tolerance


def _collect_roundabout_sign_points(
    sign_features: Iterable[dict] | None,
    osm_elements: Iterable[dict] | None,
    prepared: list[dict],
    max_m: float,
) -> set[tuple[float, float]]:
    """Collect points that prove a roundabout (NDW D1 or OSM roundabout way).

    Returns a set of (lon, lat) points snapped to the network link that carries
    the sign/tag.  Only points within *max_m* of a network link are kept.
    """
    from shapely.geometry import Point

    points: set[tuple[float, float]] = set()

    # NDW D1 signs.
    for sign in sign_features or []:
        props = sign.get("properties") or {}
        if (props.get("rvvCode") or "") not in _ROUNDABOUT_SIGN_CODES:
            continue
        geom = sign.get("geometry") or {}
        if geom.get("type") != "Point":
            continue
        coords = geom.get("coordinates") or []
        if len(coords) < 2:
            continue
        point = Point(coords[0], coords[1])
        link = _snap_point_to_link_index(point, prepared, max_m)
        if link is not None:
            points.add((coords[0], coords[1]))

    # OSM roundabout ways: the midpoint of every OSM junction=roundabout way is
    # treated as a roundabout sign point.
    if osm_elements is not None:
        way_geom = _osm_way_geometry(osm_elements)
        for way_id, _rtype in _find_osm_roundabout_ways(osm_elements):
            coords = way_geom.get(way_id)
            if not coords or len(coords) < 2:
                continue
            way_ls = _to_linestring({"geometry": {"type": "LineString", "coordinates": coords}})
            if way_ls is None:
                continue
            mid = way_ls.interpolate(0.5, normalized=True)
            point = Point(mid.x, mid.y)
            link = _snap_point_to_link_index(point, prepared, max_m)
            if link is not None:
                points.add((mid.x, mid.y))

    return points


def _ring_contains_roundabout_sign(
    features: list[dict],
    indices: set[int],
    sign_points: set[tuple[float, float]],
    *,
    buffer_m: float = 30.0,
) -> bool:
    """Return True when a ring contains or is within *buffer_m* of a D1 point."""
    from shapely.geometry import LineString, Point

    if not sign_points:
        return False

    # Order ring links into a single continuous loop so the polygon is valid.
    ordered: list[tuple[float, float]] = []
    remaining = set(indices)
    if not remaining:
        return False
    first = next(iter(remaining))
    remaining.remove(first)
    ordered.extend((lon, lat) for lon, lat in _coords(features[first]))
    while remaining:
        end = ordered[-1]
        found = None
        for i in remaining:
            coords = _coords(features[i])
            if not coords:
                continue
            start = (coords[0][0], coords[0][1])
            finish = (coords[-1][0], coords[-1][1])
            if start == end:
                found = i
                ordered.extend((lon, lat) for lon, lat in coords[1:])
                break
            if finish == end:
                found = i
                ordered.extend((lon, lat) for lon, lat in reversed(coords[:-1]))
                break
        if found is None:
            # Ring is not a simple loop (should not happen); fall back to raw coords.
            ordered = []
            for idx in indices:
                ordered.extend((lon, lat) for lon, lat in _coords(features[idx]))
            break
        remaining.remove(found)

    if len(ordered) < 3:
        return False

    lats = [lat for _, lat in ordered]
    avg_lat = sum(lats) / len(lats)
    scale_lon = 111_000.0 * math.cos(math.radians(avg_lat))
    buf_lon = buffer_m / scale_lon

    try:
        ring_ls = LineString([*ordered, ordered[0]])
        buffered = ring_ls.buffer(buf_lon)
        for lon, lat in sign_points:
            if buffered.intersects(Point(lon, lat)):
                return True
    except Exception:
        return False
    return False


def _mark_roundabouts_from_geometry(
    network_fc: dict,
    *,
    sign_features: Iterable[dict] | None = None,
    osm_elements: Iterable[dict] | None = None,
    connect_tolerance_m: float = 15.0,
    radius_tolerance: float = 0.35,
    min_links: int = 3,
    sign_buffer_m: float = 30.0,
) -> None:
    """Mark roundabout links based on the geometry of one-way CAR links.

    A detected ring is only accepted as a roundabout when at least one D1 sign
    (NDW rvvCode D1) is present inside the ring or within *sign_buffer_m* of it.
    Roundabout links are also marked as priority roads.
    """
    features = network_fc.get("features") or []
    rings = _link_ring_indices(features, tolerance_m=connect_tolerance_m)
    if not rings:
        return

    prepared = [_prepare_link_index(f) for f in features]
    prepared = [p for p in prepared if p is not None]
    sign_points = _collect_roundabout_sign_points(
        sign_features, osm_elements, prepared, sign_buffer_m
    )

    for ring in rings:
        if len(ring) < min_links:
            continue
        if not _ring_is_circular(features, ring, radius_tolerance=radius_tolerance):
            continue
        if not _ring_contains_roundabout_sign(features, ring, sign_points, buffer_m=sign_buffer_m):
            continue
        for i in ring:
            props = features[i].get("properties") or {}
            props["isRoundabout"] = True
            props["roundaboutType"] = "roundabout"
            props["priorityRoad"] = True
            props["priorityRoadSource"] = "geometry_roundabout"


def _link_id_to_opposite(link_id: str | int) -> str | int | None:
    """Return the opposite directed link id for a bidirectional pair.

    After bidirectional_splitter the heen half has the original (positive) id
    and the terug half has the negated id.  Strings prefixed with '-' are also
    handled.
    """
    try:
        num = int(link_id)
        return -num
    except TypeError, ValueError:
        if isinstance(link_id, str) and link_id.startswith("-"):
            return link_id[1:]
        if isinstance(link_id, str):
            return f"-{link_id}"
    return None


def _fill_num_give_ways(network_fc: dict, *, b3_link_ids: set[str | int]) -> None:
    """Set ``numGiveWays`` on every CAR link based on priority topology.

    Rules
    -----
    1. A non-priority link whose ``toNode`` is shared with a priority link
       receives ``numGiveWays = 1`` when the junction also has a priority link
       arriving at the same node.  In other words: the non-priority link ends
       at a node where a priority road BOTH arrives and departs.
    2. A priority link that carries a B3 sign (``linkId`` in *b3_link_ids*)
       receives ``numGiveWays = 1`` at its end, because the priority road ends
       there and through traffic must give way.
    3. Priority links without a B3 sign and roundabout links get ``0`` give-way
       markers.
    4. Non-priority links that do not end at such a double-priority junction
       get ``0``.
    """
    features = network_fc.get("features") or []
    out_links_by_node: dict[str | int, list[dict]] = defaultdict(list)
    in_links_by_node: dict[str | int, list[dict]] = defaultdict(list)

    for feat in features:
        props = feat.get("properties") or {}
        if props.get("mode") != "CAR":
            continue
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is not None:
            out_links_by_node[from_node].append(feat)
        if to_node is not None:
            in_links_by_node[to_node].append(feat)

    for feat in features:
        props = feat.get("properties") or {}
        if props.get("mode") != "CAR":
            continue
        props.setdefault("numGiveWays", 0)
        link_id = props.get("linkId")
        to_node = props.get("toNode")
        priority_road = bool(props.get("priorityRoad"))
        roundabout = bool(props.get("isRoundabout"))

        if priority_road and not roundabout and link_id in b3_link_ids:
            # Priority road ends here (B3 sign) -> give way for continuing traffic.
            props["numGiveWays"] = 1
            continue

        if priority_road or roundabout:
            continue

        if to_node is None:
            continue

        has_priority_in = any(
            (f.get("properties") or {}).get("priorityRoad")
            and not (f.get("properties") or {}).get("isRoundabout")
            for f in in_links_by_node.get(to_node, [])
        )
        has_priority_out = any(
            (f.get("properties") or {}).get("priorityRoad")
            and not (f.get("properties") or {}).get("isRoundabout")
            for f in out_links_by_node.get(to_node, [])
        )
        if has_priority_in and has_priority_out:
            props["numGiveWays"] = 1


def _propagate_priority_to_opposite_links(network_fc: dict) -> None:
    """Mirror priorityRoad to the opposite directed link of the same road.

    A priority classification found on one directed link is mirrored to its
    opposite link id (``reverseLinkIds`` or negated linkId).  The original
    source is kept but suffixed with ``_opposite`` so provenance remains clear.
    """
    features = network_fc.get("features") or []
    feature_by_id: dict[str | int, dict] = {}
    for feat in features:
        props = feat.get("properties") or {}
        link_id = props.get("linkId")
        if link_id is not None:
            feature_by_id[link_id] = feat

    for feat in features:
        props = feat.get("properties") or {}
        if not props.get("priorityRoad"):
            continue
        source = props.get("priorityRoadSource") or "none"
        if source in ("ndw_b3_end",):
            # B3 ends priority; do not mirror the "off" state.
            continue

        opposite_ids: set[str | int] = set()
        for rev_id in props.get("reverseLinkIds") or []:
            opposite_ids.add(rev_id)
        opp_from_link_id = _link_id_to_opposite(props.get("linkId"))
        if opp_from_link_id is not None:
            opposite_ids.add(opp_from_link_id)

        for opp_id in opposite_ids:
            opp_feat = feature_by_id.get(opp_id)
            if opp_feat is None:
                continue
            opp_props = opp_feat.get("properties") or {}
            if opp_props.get("priorityRoad"):
                continue
            opp_props["priorityRoad"] = True
            opp_props["priorityRoadSource"] = (
                f"{source}_opposite" if source != "none" else "opposite"
            )


def _derive_give_way_features(
    network_fc: dict,
    *,
    marker_length_m: float = 5.0,
) -> list[dict]:
    """Generate ``giveWay`` asset features for non-priority links at junctions.

    A non-priority CAR link whose ``toNode`` is also the ``fromNode`` of a
    priority CAR link gets a short ``LineString`` marker perpendicular to the
    non-priority link at the junction.  The matching perpendicular uses the
    *local* direction of the last segment of the link, so it is correct on
    curved roads as well.

    Returns
    -------
    list[dict]
        GeoJSON ``Feature`` dicts with ``assetType == "giveWay"``.
    """
    features_by_id = dict(enumerate(network_fc.get("features") or []))

    # Index nodes -> links.
    out_links_by_node: dict[str | int, list[dict]] = defaultdict(list)
    in_links_by_node: dict[str | int, list[dict]] = defaultdict(list)
    for feat in features_by_id.values():
        props = feat.get("properties") or {}
        if props.get("mode") != "CAR":
            continue
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is not None:
            out_links_by_node[from_node].append(feat)
        if to_node is not None:
            in_links_by_node[to_node].append(feat)

    markers: list[dict] = []
    for feat in features_by_id.values():
        props = feat.get("properties") or {}
        if props.get("mode") != "CAR":
            continue
        if props.get("priorityRoad"):
            continue
        if props.get("isRoundabout"):
            continue
        to_node = props.get("toNode")
        if to_node is None:
            continue
        priority_out = [
            f
            for f in out_links_by_node.get(to_node, [])
            if (f.get("properties") or {}).get("priorityRoad")
            and not (f.get("properties") or {}).get("isRoundabout")
        ]
        if not priority_out:
            continue

        coords = _coords(feat)
        if len(coords) < 2:
            continue

        # Use the heading of the last segment for the local road direction.
        lon0, lat0 = coords[-2]
        lon1, lat1 = coords[-1]
        # Heading of the last segment ( compass bearing, 0 = N ).
        lat_mid_r = math.radians((lat0 + lat1) / 2)
        dx = (lon1 - lon0) * math.cos(lat_mid_r)
        dy = lat1 - lat0
        road_heading = math.degrees(math.atan2(dx, dy)) % 360

        # Perpendicular heading.
        perp_heading = (road_heading + 90) % 360
        perp_rad = math.radians(perp_heading)
        half_len_m = marker_length_m / 2.0
        half_len_deg_lat = half_len_m / 111_000.0
        half_len_deg_lon = half_len_m / (111_000.0 * math.cos(math.radians(lat1)))

        dlon = half_len_deg_lon * math.sin(perp_rad)
        dlat = half_len_deg_lat * math.cos(perp_rad)

        markers.append(
            {
                "type": "Feature",
                "geometry": {
                    "type": "LineString",
                    "coordinates": [
                        [lon1 - dlon, lat1 - dlat],
                        [lon1 + dlon, lat1 + dlat],
                    ],
                },
                "properties": {
                    "assetType": "giveWay",
                    "linkId": props.get("linkId"),
                    "nodeId": to_node,
                    "source": "derived_from_priority_road",
                },
            }
        )

    return markers


def enrich_network_with_priority_and_roundabouts(
    network_fc: dict,
    *,
    osm_elements: Iterable[dict] | None = None,
    traffic_sign_features: Iterable[dict] | None = None,
    snap_m: float = _DEFAULT_SNAP_M,
) -> tuple[dict, list[dict]]:
    """Add roundabout and priority-road columns to every link in *network_fc*.

    Parameters
    ----------
    network_fc:
        GeoJSON FeatureCollection of directed network links.
    osm_elements:
        Optional raw Overpass elements (ways, nodes, relations).
    traffic_sign_features:
        Optional traffic-sign point features with ``rvvCode`` property.
    snap_m:
        Maximum snap distance from an OSM way / sign to a network link.

    Returns
    -------
    tuple[dict, list[dict]]
        The enriched *network_fc* plus a list of derived ``giveWay`` asset
        features ready to be included in the traffic-assets collection.
    """
    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}
        props.setdefault("isRoundabout", False)
        props.setdefault("roundaboutType", "none")
        props.setdefault("priorityRoad", False)
        props.setdefault("priorityRoadSource", "none")

    # Order matters: signs (local, precise) override OSM priority tags, but a
    # roundabout classification always wins because roundabouts are never
    # priority roads.
    b3_link_ids: set[str | int] = set()
    if traffic_sign_features:
        b3_link_ids = _mark_priority_from_signs(network_fc, traffic_sign_features, snap_m)

    if osm_elements:
        _mark_priority_from_osm(network_fc, osm_elements, snap_m)
        _mark_roundabouts_from_osm(network_fc, osm_elements, traffic_sign_features, snap_m)

    # Geometry-based detection runs last so it wins over any OSM-tag based
    # classification.  It now requires a D1 roundabout sign (NDW or OSM) before
    # a circular ring is accepted as a roundabout.
    _mark_roundabouts_from_geometry(
        network_fc,
        sign_features=traffic_sign_features,
        osm_elements=osm_elements,
    )

    _propagate_priority_to_opposite_links(network_fc)

    _fill_num_give_ways(network_fc, b3_link_ids=b3_link_ids)

    give_way_features = _derive_give_way_features(network_fc)

    return network_fc, give_way_features
