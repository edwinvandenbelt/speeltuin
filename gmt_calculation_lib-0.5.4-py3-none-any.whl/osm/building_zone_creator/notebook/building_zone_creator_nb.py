# Databricks notebook source
# ---------------------------------------------------------------------------
# building_zone_creator_nb.py — Databricks notebook for building_zone_creator.
#
# This notebook:
#   1. Reads widget parameters (buildings_uri, bbox, output_folder, …).
#   2. Loads the buildings GeoParquet from S3 (or local path).
#   3. Calls create_zones() — fetches streets via Overpass, builds blocks,
#      merges into zones.
#   4. Serialises the result as GeoParquet and writes it to S3 (or local).
#   5. Prints a summary table.
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
from datetime import UTC, datetime

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("building_zone_creator_nb")

# COMMAND ----------
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "buildings_uri",
    "",
    "Full URI of the input buildings GeoParquet (s3://bucket/key or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "bbox",
    "6.143,52.248,6.184,52.272",
    "Bounding box: minLon,minLat,maxLon,maxLat (comma-separated)",
)
dbutils.widgets.text(  # noqa: F821
    "output_folder",
    "",
    "Output folder: s3://bucket/prefix/ or local path",
)
dbutils.widgets.text(  # noqa: F821
    "area_id",
    "zones",
    "Area identifier — used in output filename ({area_id}-BUILDING-ZONES.parquet)",
)
dbutils.widgets.text(  # noqa: F821
    "target_footprint_m2",
    "5000",
    "Target total building footprint per zone in m²",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_url",
    "https://overpass-api.de/api/interpreter",
    "Overpass API endpoint URL",
)
dbutils.widgets.text(  # noqa: F821
    "overpass_timeout",
    "90",
    "Overpass query timeout in seconds",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

BUILDINGS_URI = dbutils.widgets.get("buildings_uri").strip()  # noqa: F821
if not BUILDINGS_URI:
    raise ValueError("Widget 'buildings_uri' is empty.")

_raw_bbox = dbutils.widgets.get("bbox").strip()  # noqa: F821
if not _raw_bbox:
    raise ValueError("Widget 'bbox' is empty.")
try:
    BBOX: list[float] = [float(v.strip()) for v in _raw_bbox.split(",")]
    if len(BBOX) != 4:
        raise ValueError(f"Expected 4 values, got {len(BBOX)}")
except ValueError as _exc:
    raise ValueError(f"Widget 'bbox' must be 'minLon,minLat,maxLon,maxLat': {_exc}") from _exc

OUTPUT_FOLDER = dbutils.widgets.get("output_folder").strip()  # noqa: F821
if not OUTPUT_FOLDER:
    raise ValueError("Widget 'output_folder' is empty.")

AREA_ID = dbutils.widgets.get("area_id").strip() or "zones"  # noqa: F821

try:
    TARGET_FOOTPRINT_M2 = float(dbutils.widgets.get("target_footprint_m2").strip())  # noqa: F821
except ValueError, TypeError:
    TARGET_FOOTPRINT_M2 = 5000.0

OVERPASS_URL = dbutils.widgets.get("overpass_url").strip()  # noqa: F821
if not OVERPASS_URL:
    OVERPASS_URL = "https://overpass-api.de/api/interpreter"

try:
    OVERPASS_TIMEOUT = int(dbutils.widgets.get("overpass_timeout").strip())  # noqa: F821
except ValueError, TypeError:
    OVERPASS_TIMEOUT = 90

logger.info(
    "buildings_uri=%s  bbox=%s  area_id=%s  output_folder=%s  target_m2=%s",
    BUILDINGS_URI,
    BBOX,
    AREA_ID,
    OUTPUT_FOLDER,
    TARGET_FOOTPRINT_M2,
)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402


def _get_s3(bucket: str, key: str) -> bytes:
    body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
    logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
    return body


def _put_s3(bucket: str, key: str, data: bytes) -> None:
    boto3.client("s3").put_object(
        Bucket=bucket,
        Key=key,
        Body=data,
        ContentType="application/octet-stream",
    )
    logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        parts = uri[5:].split("/", 1)
        bucket, key = parts[0], parts[1] if len(parts) > 1 else ""
        return _get_s3(bucket, key)
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    import os

    if uri.startswith("s3://"):
        parts = uri[5:].split("/", 1)
        bucket, key = parts[0], parts[1] if len(parts) > 1 else ""
        _put_s3(bucket, key, data)
    else:
        os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
        with open(uri, "wb") as _fh:
            _fh.write(data)
        logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run Building Zone Creator
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from gmt_shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402

from osm.building_zone_creator.core.building_zone_creator_core import (
    create_zones,
)

_t_start = datetime.now(UTC)
print(f"Starting  {_t_start.isoformat()}")
print(f"buildings_uri    : {BUILDINGS_URI}")
print(f"bbox             : {BBOX}")
print(f"area_id          : {AREA_ID}")
print(f"output_folder    : {OUTPUT_FOLDER}")
print(f"target_footprint : {TARGET_FOOTPRINT_M2} m²")
print()

_buildings_bytes = _read_uri(BUILDINGS_URI)
_buildings_fc = from_geoparquet(_buildings_bytes)
_n_buildings = len(_buildings_fc.get("features") or [])
print(f"{_n_buildings} building features loaded")

_fc, _stats = create_zones(
    _buildings_fc,
    BBOX,
    area_id=AREA_ID,
    overpass_url=OVERPASS_URL,
    overpass_timeout=OVERPASS_TIMEOUT,
    target_footprint_m2=TARGET_FOOTPRINT_M2,
)

_parquet_bytes = to_geoparquet(_fc)
_out_uri = f"{OUTPUT_FOLDER.rstrip('/')}/{AREA_ID}-BUILDING-ZONES.parquet"
_write_uri(_out_uri, _parquet_bytes)

_elapsed = (datetime.now(UTC) - _t_start).total_seconds()

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 64
print(_SEP)
print(f"Building Zone Creator complete — {_elapsed:.1f}s")
print(_SEP)
print(f"  area_id            : {AREA_ID}")
print(f"  bbox               : {BBOX}")
print(f"  output             : {_out_uri}")
print(f"  input buildings    : {_n_buildings}")
print(f"  blocks identified  : {_stats['blocks']}")
print(f"  zones created      : {_stats['zones']}")
print(f"  assigned buildings : {_stats['assigned_buildings']}")
print(_SEP)
