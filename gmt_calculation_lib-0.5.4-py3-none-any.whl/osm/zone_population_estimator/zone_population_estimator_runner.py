"""Local debug runner for zone_population_estimator.

Reads a zones GeoParquet (output of building_zone_creator), resolves the
NUTS3 region via GISCO, fetches population from Eurostat, computes production
and attraction per zone, and writes the enriched GeoParquet.

Usage
-----
    python -m zone_population_estimator.zone_population_estimator_runner \\
        --zones-uri s3://my-bucket/deventer-centrum-BUILDING-ZONES.parquet \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder ./out/ \\
        --area-id deventer-centrum

    python src/zone_population_estimator/zone_population_estimator_runner.py \\
        --zones-uri ./deventer-centrum-BUILDING-ZONES.parquet \\
        --bbox 6.143 52.248 6.184 52.272 \\
        --output-folder s3://my-bucket/zones/ \\
        --attraction-factors '{"shopping": 0.15, "school": 0.08}'
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        print(f"Written {len(data):,} bytes → s3://{bucket}/{key}")
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes → {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description=(
            "Local runner for zone_population_estimator — enriches building zones "
            "with production and attraction estimates."
        )
    )
    parser.add_argument(
        "--zones-uri",
        required=True,
        metavar="URI",
        help="Full URI of the input zones GeoParquet (s3:// or local path).",
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        required=True,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box: minLon minLat maxLon maxLat",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder (s3://bucket/prefix/ or local directory).",
    )
    parser.add_argument(
        "--area-id",
        default=None,
        help="Area identifier used in the output filename (default: 'zones-population').",
    )
    parser.add_argument(
        "--attraction-factors",
        default=None,
        metavar="JSON",
        help=(
            "JSON object overriding attraction factors, e.g. "
            '\'{"shopping": 0.15, "school": 0.08}\'.'
        ),
    )
    parser.add_argument(
        "--gisco-url",
        default="https://gisco-services.ec.europa.eu",
        help="GISCO REST API base URL.",
    )
    parser.add_argument(
        "--eurostat-url",
        default="https://ec.europa.eu/eurostat/api/dissemination",
        help="Eurostat API base URL.",
    )
    parser.add_argument(
        "--gisco-timeout",
        type=int,
        default=30,
        help="HTTP timeout for GISCO calls in seconds (default: 30).",
    )
    parser.add_argument(
        "--eurostat-timeout",
        type=int,
        default=30,
        help="HTTP timeout for Eurostat calls in seconds (default: 30).",
    )
    parser.add_argument(
        "--parking-trips-factor",
        type=float,
        default=1.5,
        help="Trips per parking space per day (added to both production and attraction). Default: 1.5.",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for AWS credentials.",
    )
    args = parser.parse_args()

    # Load .env
    env_file_path: Path
    if args.env_file:
        env_file_path = Path(args.env_file)
    else:
        env_file_path = Path(__file__).resolve().parent.parent.parent / "tools" / ".env"
    for k, v in _read_env_file(env_file_path).items():
        os.environ.setdefault(k, v)

    logging.basicConfig(
        format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
        level=logging.INFO,
    )

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from osm.zone_population_estimator.core.zone_population_estimator_core import (
        estimate_zone_population,
    )

    attraction_factors: dict | None = None
    if args.attraction_factors:
        try:
            attraction_factors = json.loads(args.attraction_factors)
        except json.JSONDecodeError as exc:
            print(f"[error] --attraction-factors is not valid JSON: {exc}", file=sys.stderr)
            sys.exit(1)

    bbox: list[float] = args.bbox
    area_id: str = args.area_id or "zones-population"
    output_folder: str = args.output_folder.rstrip("/")

    print(f"Reading zones : {args.zones_uri}")
    zones_fc = from_geoparquet(_read_uri(args.zones_uri))
    n_zones = len(zones_fc.get("features") or [])
    print(f"  {n_zones} zone features loaded")

    print(f"Estimating population  bbox={bbox}")
    fc, stats = estimate_zone_population(
        zones_fc,
        bbox,
        gisco_url=args.gisco_url,
        eurostat_url=args.eurostat_url,
        gisco_timeout=args.gisco_timeout,
        eurostat_timeout=args.eurostat_timeout,
        attraction_factors=attraction_factors,
        parking_trips_factor=args.parking_trips_factor,
    )
    print(
        f"Stats : municipality={stats['municipalityName']}  "
        f"nuts={stats['nutsCode']}  pop={stats['totalPopulation']:.0f}  "
        f"year={stats['year']}"
    )

    parquet_bytes = to_geoparquet(fc)
    out_uri = f"{output_folder}/{area_id}-ZONES-POPULATION.parquet"
    _write_uri(out_uri, parquet_bytes)
    print("Done.")


if __name__ == "__main__":
    main()
