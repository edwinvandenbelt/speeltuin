"""Link buildings to streets using street-name matching or nearest-street lookup.

Strategy per building
---------------------
1. If the building has an ``addr:street`` tag and a street with that name
   exists in the street list → use that street (exact, case-insensitive match).
2. Otherwise → find the nearest street centroid using ``shared.kd_tree.KDTree2D``
   (or a linear search when numpy is unavailable).

Public API
----------
link_buildings_to_streets(buildings, streets) -> list[tuple[str | None, str | None]]
    Return ``(street_name, street_id)`` for every building (same order).
"""

from __future__ import annotations

import logging
import math

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _street_midpoints(
    streets: list[dict],
) -> list[tuple[float, float, str, str]]:
    """Return ``(lon, lat, name, street_id)`` for the mid-point of each street way."""
    result: list[tuple[float, float, str, str]] = []
    for el in streets:
        geom: list[dict] = el.get("geometry") or []
        if not geom:
            continue
        mid = geom[len(geom) // 2]
        name: str = (el.get("tags") or {}).get("name", "")
        result.append((float(mid["lon"]), float(mid["lat"]), name, f"osm_{el['id']}"))
    return result


def _building_centroid(element: dict) -> tuple[float, float] | None:
    """Return ``(lon, lat)`` centroid of a building element."""
    if element.get("type") == "node":
        lon = element.get("lon")
        lat = element.get("lat")
        if lon is None or lat is None:
            return None
        return float(lon), float(lat)
    geom: list[dict] = element.get("geometry") or []
    if not geom:
        return None
    lons = [float(p["lon"]) for p in geom]
    lats = [float(p["lat"]) for p in geom]
    return sum(lons) / len(lons), sum(lats) / len(lats)


def _nearest_linear(
    blon: float,
    blat: float,
    midpoints: list[tuple[float, float, str, str]],
) -> tuple[str | None, str | None]:
    """Return ``(name, street_id)`` of the nearest street using linear scan."""
    best_dist = math.inf
    best: tuple[str | None, str | None] = (None, None)
    for slon, slat, sname, sid in midpoints:
        dist = (slon - blon) ** 2 + (slat - blat) ** 2
        if dist < best_dist:
            best_dist = dist
            best = (sname or None, sid)
    return best


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def link_buildings_to_streets(
    buildings: list[dict],
    streets: list[dict],
) -> list[tuple[str | None, str | None]]:
    """Link each building to a street; return ``(street_name, street_id)`` per building.

    Parameters
    ----------
    buildings:
        List of Overpass building elements (``way`` or ``node``).
    streets:
        List of Overpass street elements (``way`` with ``highway`` tag).

    Returns
    -------
    list[tuple[str | None, str | None]]
        One entry per building in the same order.  Each entry is
        ``(street_name, street_id)`` where ``street_id`` is ``"osm_{way_id}"``.
        Both values are ``None`` when no streets are available.
    """
    if not streets or not buildings:
        return [(None, None)] * len(buildings)

    # Build name → (display_name, street_id) lookup (case-insensitive key)
    name_lookup: dict[str, tuple[str, str]] = {}
    for el in streets:
        name: str = (el.get("tags") or {}).get("name", "").strip()
        if name:
            name_lookup[name.lower()] = (name, f"osm_{el['id']}")

    midpoints = _street_midpoints(streets)

    # Try to build a KD-tree for fast nearest-street lookup
    _tree = None
    try:
        import numpy as np
        from gmt_shared.kd_tree import KDTree2D

        if midpoints:
            pts = np.array([[m[0], m[1]] for m in midpoints], dtype=float)
            _tree = KDTree2D(pts)
    except Exception:
        logger.debug("KDTree2D unavailable — falling back to linear nearest-street search")

    results: list[tuple[str | None, str | None]] = []

    for building in buildings:
        tags: dict[str, str] = building.get("tags") or {}
        addr_street = tags.get("addr:street", "").strip()

        # 1. Street-name match
        if addr_street and addr_street.lower() in name_lookup:
            display_name, sid = name_lookup[addr_street.lower()]
            results.append((display_name, sid))
            continue

        # 2. Nearest street
        centroid = _building_centroid(building)
        if centroid is None:
            results.append((addr_street or None, None))
            continue

        blon, blat = centroid

        if _tree is not None and midpoints:
            try:
                import numpy as np

                dists, idxs = _tree.query(np.array([blon, blat]), k=1)
                idx = int(idxs[0] if hasattr(idxs, "__len__") else idxs)
                _, _, sname, sid = midpoints[idx]
                results.append((sname or addr_street or None, sid))
                continue
            except Exception:
                pass  # fall through to linear

        results.append(_nearest_linear(blon, blat, midpoints))

    return results


# ---------------------------------------------------------------------------
# Per-link building motive ratios
# ---------------------------------------------------------------------------


def _geojson_feature_centroid(feature: dict) -> tuple[float, float] | None:
    """Return ``(lon, lat)`` centroid of a GeoJSON Feature."""
    geom: dict = feature.get("geometry") or {}
    gtype = geom.get("type", "")
    if gtype == "Point":
        coords = geom.get("coordinates") or []
        if len(coords) >= 2:
            return float(coords[0]), float(coords[1])
        return None
    if gtype == "Polygon":
        rings = geom.get("coordinates") or []
        if not rings:
            return None
        ring = rings[0]
        if not ring:
            return None
        lons = [float(c[0]) for c in ring]
        lats = [float(c[1]) for c in ring]
        return sum(lons) / len(lons), sum(lats) / len(lats)
    return None


def _link_midpoint(feature: dict) -> tuple[float, float] | None:
    """Return ``(lon, lat)`` midpoint of a LineString link feature."""
    geom: dict = feature.get("geometry") or {}
    if geom.get("type") != "LineString":
        return None
    coords = geom.get("coordinates") or []
    if not coords:
        return None
    mid = coords[len(coords) // 2]
    return float(mid[0]), float(mid[1])


def assign_buildings_to_links(
    buildings_fc: dict,
    network_fc: dict,
) -> dict[str, dict[str, float]]:
    """Return ``{linkId: buildingMotifRatio}`` based on nearest-link spatial join.

    For each building the centroid is computed, the nearest link midpoint is
    found, and the building's footprint m² is accumulated per ``buildingType``
    per link.  The per-link totals are then normalised so each ratio dict sums
    to 1.0.

    ``house``-type buildings are excluded because they represent residential
    production (trip origins) rather than attraction destinations.  Including
    them would bias the motive ratio toward ``work``/``shopping`` erroneously.

    Parameters
    ----------
    buildings_fc:
        GeoJSON FeatureCollection of buildings (from ``osm_building_fetcher``).
    network_fc:
        GeoJSON FeatureCollection of directed network links.

    Returns
    -------
    dict[str, dict[str, float]]
        ``{linkId: {buildingType: ratio}}`` for every link that has at least
        one building assigned.  Links without buildings are not present in the
        returned dict; callers should fall back to ``{"unknown": flow}``.
    """
    from osm.building_zone_creator.domain.footprint import building_footprint_m2

    building_features: list[dict] = buildings_fc.get("features") or []
    link_features: list[dict] = network_fc.get("features") or []

    if not building_features or not link_features:
        return {}

    # Build link midpoints list: (lon, lat, linkId)
    link_mids: list[tuple[float, float, str]] = []
    for feat in link_features:
        mid = _link_midpoint(feat)
        if mid is None:
            continue
        lid = str((feat.get("properties") or {}).get("linkId", ""))
        if lid:
            link_mids.append((mid[0], mid[1], lid))

    if not link_mids:
        return {}

    # Compute reference latitude for footprint calculation
    ref_lat = sum(m[1] for m in link_mids) / len(link_mids)

    # Try to build a KD-tree for fast nearest-link lookup
    _tree = None
    try:
        import numpy as np
        from gmt_shared.kd_tree import KDTree2D

        pts = np.array([[m[0], m[1]] for m in link_mids], dtype=float)
        _tree = KDTree2D(pts)
    except Exception:
        logger.debug("KDTree2D unavailable — falling back to linear nearest-link search")

    # Accumulate footprint m² per (linkId, buildingType)
    link_type_m2: dict[str, dict[str, float]] = {}

    for building in building_features:
        props: dict = building.get("properties") or {}
        btype: str = props.get("buildingType", "other")
        if btype == "house":
            continue  # residential = production, not attraction

        centroid = _geojson_feature_centroid(building)
        if centroid is None:
            continue
        blon, blat = centroid

        # Find nearest link
        lid: str | None = None
        if _tree is not None:
            try:
                import numpy as np

                _, idxs = _tree.query(np.array([blon, blat]), k=1)
                idx = int(idxs[0] if hasattr(idxs, "__len__") else idxs)
                lid = link_mids[idx][2]
            except Exception:
                pass

        if lid is None:
            # Linear fallback
            best_dist = math.inf
            for slon, slat, slid in link_mids:
                dist = (slon - blon) ** 2 + (slat - blat) ** 2
                if dist < best_dist:
                    best_dist = dist
                    lid = slid

        if lid is None:
            continue

        footprint = building_footprint_m2(building, ref_lat)
        floor_fraction = float(props.get("floorFraction", 1.0))
        bucket = link_type_m2.setdefault(lid, {})
        bucket[btype] = bucket.get(btype, 0.0) + footprint * floor_fraction

    # Normalise to ratios
    result: dict[str, dict[str, float]] = {}
    for lid, type_m2 in link_type_m2.items():
        total = sum(type_m2.values())
        if total <= 0.0:
            continue
        result[lid] = {k: round(v / total, 6) for k, v in type_m2.items()}

    return result
