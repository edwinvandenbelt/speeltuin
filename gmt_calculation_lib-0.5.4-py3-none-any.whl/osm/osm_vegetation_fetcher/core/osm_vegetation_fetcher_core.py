"""OSM + BGT Vegetation Fetcher core — fetches public green / tree data.

Downloads vegetation features (trees, tree rows, shrubs, scrub, grass, wood and
forest) from the Overpass API for a bounding box and, within the Netherlands,
additionally from the Dutch BGT (``begroeidterreindeel`` polygons via the PDOK
OGC API Features service).  Both sources are normalised into the same GeoJSON
schema and merged into a single FeatureCollection ready for serialisation as
GeoParquet (EPSG:4326).

Output schema (one row per feature)
-----------------------------------
* ``geometry`` — Point (tree/shrub), LineString (tree_row) or Polygon /
  MultiPolygon (scrub/grass/wood/forest).
* ``vegType``  — normalised label: one of ``tree``, ``tree_row``, ``shrub``,
  ``scrub``, ``wood``, ``forest``, ``grass``.
* ``height``   — float metres from OSM ``height`` / ``est_height``, else ``None``.
* ``crown``    — float crown diameter (m) from ``diameter_crown``, else ``None``.
* ``species``  — from ``species`` / ``genus``, else ``None``.
* ``leafType`` — ``broadleaved`` / ``needleleaved`` / ``None``.
* ``osmId``    — source id (``"{type}/{id}"`` for OSM, ``"bgt/{lokaalid}"`` for
  BGT) for debugging.
* ``source``   — provenance: ``"osm"`` or ``"bgt"``.

Resource cap
------------
Vegetation is a "nice to have"; the number of point features (trees + shrubs) is
capped (default 20 000) via **deterministic** thinning (every n-th point) so the
output is reproducible.  Area features (scrub / grass / wood / forest), incl.
all BGT polygons, are always kept in full — they are few in number but cover a
lot of ground.

Public API
----------
build_vegetation(bbox, *, overpass_url, timeout, tiles, max_points, bgt, bgt_url)
    -> tuple[dict, dict]
    Returns (feature_collection, stats).
    stats: {"total", "points", "areas", "lines", "capped", "tiles", "by_type",
    "by_source"}
"""

from __future__ import annotations

import logging

from gmt_shared.geo import is_netherlands
from gmt_shared.overpass import DEFAULT_OVERPASS_URL, fetch_overpass_tiled

from osm.osm_vegetation_fetcher.domain.geometry import (
    LINE_VEG_TYPES,
    POINT_VEG_TYPES,
    element_to_feature,
    normalise_veg_type,
)
from osm.osm_vegetation_fetcher.domain.overpass import (
    DEFAULT_TIMEOUT,
    build_vegetation_query,
)

logger = logging.getLogger(__name__)

_DEFAULT_OVERPASS_URL = DEFAULT_OVERPASS_URL

# Default NxN Overpass tile grid.  Large areas are split into tiles so that no
# single Overpass request has to return the whole area at once (which risks
# server-side timeouts / rate-limiting).  All tiles are merged (deduplicated by
# element id) into a single FeatureCollection.
OVERPASS_GRID: int = 5

# Default cap on the number of point features (trees + shrubs) per area.  When
# exceeded, points are deterministically thinned (every n-th point kept).
DEFAULT_MAX_POINTS: int = 20_000


def _thin_points(features: list[dict], max_points: int) -> tuple[list[dict], bool]:
    """Deterministically thin *features* down to at most *max_points*.

    Keeps every ``n``-th feature (``n = ceil(len / max_points)``) so the result
    is evenly distributed and fully reproducible across runs.  Returns the
    (possibly reduced) list and a boolean indicating whether thinning occurred.
    """
    total = len(features)
    if max_points <= 0 or total <= max_points:
        return features, False
    step = (total + max_points - 1) // max_points  # ceil division
    thinned = features[::step]
    return thinned, True


def _fetch_bgt_vegetation(
    bbox: list[float],
    *,
    url: str | None = None,
    timeout: int = DEFAULT_TIMEOUT,
) -> list[dict]:
    """Fetch BGT ``begroeidterreindeel`` polygons, normalised to vegetation.

    Returns a list of GeoJSON Features carrying the standard vegetation schema
    (``source = "bgt"``).  BGT only covers the Netherlands, so an empty list is
    returned for bboxes whose centroid lies outside NL.  All errors are the
    caller's responsibility to handle (BGT is a best-effort secondary source).
    """
    if not is_netherlands(bbox):
        logger.info("bbox centroid outside NL — skipping BGT vegetation fetch.")
        return []

    # Imported lazily so the pure-OSM path never pulls in the OGC/urllib client.
    from gmt_shared.ogc_features import DEFAULT_BGT_URL, fetch_collection_items

    from osm.osm_vegetation_fetcher.domain.bgt import (
        BGT_VEG_COLLECTION,
        bgt_feature_to_veg,
    )

    base_url = url if url is not None else DEFAULT_BGT_URL
    raw = fetch_collection_items(BGT_VEG_COLLECTION, bbox, url=base_url, timeout=timeout)

    features: list[dict] = []
    for item in raw:
        feature = bgt_feature_to_veg(item)
        if feature is not None:
            features.append(feature)
    logger.info(
        "BGT vegetation: %d features (from %d begroeidterreindeel polygons)",
        len(features),
        len(raw),
    )
    return features


def build_vegetation(
    bbox: list[float],
    *,
    overpass_url: str = _DEFAULT_OVERPASS_URL,
    timeout: int = DEFAULT_TIMEOUT,
    tiles: int = OVERPASS_GRID,
    max_points: int = DEFAULT_MAX_POINTS,
    bgt: bool = True,
    bgt_url: str | None = None,
    osm_path: str | None = None,
    osm_workers: int | None = None,
) -> tuple[dict, dict]:
    """Fetch and normalise OSM vegetation features for a bounding box.

    Parameters
    ----------
    bbox:
        Bounding box ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    overpass_url:
        Overpass API endpoint URL.
    timeout:
        Overpass query timeout in seconds.
    tiles:
        NxN Overpass tile grid.  The bbox is split into ``tiles x tiles``
        sub-bboxes that are fetched separately and merged (deduplicated by
        element id).  ``tiles=1`` performs a single, untiled query.
    max_points:
        Maximum number of point features (trees + shrubs) to keep.  When
        exceeded, points are deterministically thinned.  ``0`` disables the cap.
    bgt:
        When ``True`` (default), additionally fetch vegetated terrain from the
        Dutch BGT (``begroeidterreindeel`` polygons) via the PDOK OGC API
        Features service and merge it in as area features.  BGT only covers the
        Netherlands, so it is skipped for bboxes outside NL.  BGT failures are
        swallowed (best-effort) so the OSM result is always returned.
    bgt_url:
        BGT OGC API Features base URL.  Defaults to the shared client default
        (``PDOK_BGT_URL`` env var or the public PDOK BGT endpoint).

    Returns
    -------
    fc:
        GeoJSON FeatureCollection (EPSG:4326).  Each Feature carries
        ``vegType``, ``height``, ``crown``, ``species``, ``leafType``,
        ``osmId`` and ``source`` (``"osm"`` or ``"bgt"``) properties.
    stats:
        ``{"total", "points", "areas", "lines", "capped", "tiles", "by_type",
        "by_source"}``.
    """
    logger.info(
        "Fetching vegetation via Overpass  bbox=%s  url=%s  tiles=%dx%d",
        bbox,
        overpass_url,
        tiles,
        tiles,
    )
    data = fetch_overpass_tiled(
        lambda b: build_vegetation_query(b, timeout=timeout),
        bbox,
        tiles=(tiles, tiles),
        url=overpass_url,
        timeout=timeout,
        osm_path=osm_path,
        osm_workers=osm_workers,
    )
    elements: list[dict] = data.get("elements") or []

    point_features: list[dict] = []
    line_features: list[dict] = []
    area_features: list[dict] = []

    for element in elements:
        veg_type = normalise_veg_type(element)
        if veg_type is None:
            continue
        feature = element_to_feature(element, veg_type)
        if feature is None:
            continue
        if veg_type in POINT_VEG_TYPES:
            point_features.append(feature)
        elif veg_type in LINE_VEG_TYPES:
            line_features.append(feature)
        else:
            area_features.append(feature)

    # Cap point features (trees / shrubs) deterministically; areas are kept fully.
    point_features, capped = _thin_points(point_features, max_points)

    # Merge in BGT vegetation (NL-only, best-effort).  All BGT features are
    # polygons, so they join the area bucket.  BGT failures never abort the run.
    bgt_features: list[dict] = []
    if bgt:
        try:
            bgt_features = _fetch_bgt_vegetation(bbox, url=bgt_url, timeout=timeout)
        except Exception as exc:
            logger.warning("BGT vegetation fetch failed (%s); continuing with OSM only.", exc)
    area_features.extend(bgt_features)

    features = point_features + line_features + area_features

    type_counts: dict[str, int] = {}
    source_counts: dict[str, int] = {}
    for feature in features:
        props = feature["properties"]
        vtype = props["vegType"]
        type_counts[vtype] = type_counts.get(vtype, 0) + 1
        src = props.get("source", "osm")
        source_counts[src] = source_counts.get(src, 0) + 1

    fc: dict = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {
            "bbox": bbox,
            "overpassUrl": overpass_url,
        },
    }
    stats: dict = {
        "total": len(features),
        "points": len(point_features),
        "areas": len(area_features),
        "lines": len(line_features),
        "capped": capped,
        "tiles": tiles * tiles,
        "by_type": type_counts,
        "by_source": source_counts,
    }
    logger.info(
        "Built %d vegetation features — %s  sources=%s (capped=%s)",
        len(features),
        type_counts,
        source_counts,
        capped,
    )
    # Release the raw Overpass payload and intermediate lists now that the
    # GeoJSON features have been built (keeps the prepare peak down).
    del data, elements, point_features, line_features, area_features, bgt_features
    return fc, stats
