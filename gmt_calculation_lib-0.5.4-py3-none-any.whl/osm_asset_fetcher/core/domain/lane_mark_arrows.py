"""Extract lane mark arrows as longitudinal road-surface markings.

Lane mark arrows are short (2 m) LineString features drawn along the matched
network link's centerline, 5 m to 3 m before its toNode.  They represent the
turn-lane configuration at the end of the road segment and are meant to be
visualised as arrow symbols by the frontend.

Processing rules
----------------
* ``turn:lanes`` and ``turn:lanes:forward`` are both treated as the forward
  direction of the source OSM way and stored with ``direction="forward"``.
* ``turn:lanes:backward`` is treated as the opposite direction.  The matched
  network geometry is reversed so the resulting feature still looks
  "from 5 m before the toNode towards the toNode" in the stored geometry, but
  is tagged with ``direction="backward"``.
* The raw turn lane value is always stored in the attribute ``turn:lanes``,
  regardless of which OSM tag it came from.
* Each tag variant produces exactly one LineString feature.

When a matching network link cannot be found within the tolerance, the arrow
falls back to the original OSM-way geometry so a feature is still emitted.
"""

from __future__ import annotations

import itertools
import logging
import math

logger = logging.getLogger(__name__)


def parse_turn_lanes_tag(value: str | None) -> list[str]:
    """Parse a pipe-separated turn lane value into individual turn directions."""
    if not value:
        return []
    directions = [d.strip() for d in value.split("|")]
    return [d for d in directions if d]


def _haversine_meters(
    lon1: float,
    lat1: float,
    lon2: float,
    lat2: float,
) -> float:
    """Haversine distance between two WGS-84 points in meters."""
    earth_radius_m = 6371000.0
    phi1 = math.radians(lat1)
    phi2 = math.radians(lat2)
    delta_phi = math.radians(lat2 - lat1)
    delta_lambda = math.radians(lon2 - lon1)
    a = (
        math.sin(delta_phi / 2) ** 2
        + math.cos(phi1) * math.cos(phi2) * math.sin(delta_lambda / 2) ** 2
    )
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1 - a))
    return earth_radius_m * c


def _segment_length_meters(coords: list[list[float]]) -> float:
    """Return total length of a coordinate sequence in meters."""
    total = 0.0
    for (lon1, lat1), (lon2, lat2) in itertools.pairwise(coords):
        total += _haversine_meters(lon1, lat1, lon2, lat2)
    return total


def _point_at_distance_from_end(
    coords: list[list[float]],
    distance_from_end_m: float,
) -> list[float] | None:
    """Return the point *distance_from_end_m* meters before the last vertex.

    Walks backwards from the end of the coordinate sequence and interpolates
    along the segment that contains the target distance.  Returns ``None`` when
    the line is empty or a zero-length segment is encountered.
    """
    if len(coords) < 2:
        return None

    remaining = distance_from_end_m
    for i in range(len(coords) - 1, 0, -1):
        lon_end, lat_end = coords[i]
        lon_start, lat_start = coords[i - 1]
        seg_len = _haversine_meters(lon_start, lat_start, lon_end, lat_end)
        if seg_len <= 0:
            continue
        if remaining <= seg_len:
            fraction = remaining / seg_len
            lon = lon_end + fraction * (lon_start - lon_end)
            lat = lat_end + fraction * (lat_start - lat_end)
            return [lon, lat]
        remaining -= seg_len
    return [coords[0][0], coords[0][1]]


def _reverse_coords(coords: list[list[float]]) -> list[list[float]]:
    """Return a reversed copy of a coordinate sequence."""
    return [c[:] for c in reversed(coords)]


def _way_linestring(geometry: list[dict]) -> list[list[float]] | None:
    """Extract ``[[lon, lat], ...]`` from an Overpass ``out geom`` way."""
    pts = [[float(p["lon"]), float(p["lat"])] for p in geometry if "lat" in p and "lon" in p]
    if len(pts) < 2:
        return None
    return pts


def _link_coords(link: dict) -> list[list[float]] | None:
    """Extract ``[[lon, lat], ...]`` from a network link Feature."""
    geom = link.get("geometry") or {}
    if geom.get("type") != "LineString":
        return None
    pts = [[float(c[0]), float(c[1])] for c in (geom.get("coordinates") or []) if len(c) >= 2]
    if len(pts) < 2:
        return None
    return pts


def _direction_aligned(way_coords: list[list[float]], link_coords: list[list[float]]) -> bool:
    """Return True when the link runs in the same direction as the way.

    Compares the bearing of the first/last segment of both geometries.
    """
    if len(way_coords) < 2 or len(link_coords) < 2:
        return True

    def _bearing_delta(a: list[list[float]], b: list[list[float]]) -> float:
        lon1, lat1 = a[0]
        lon2, lat2 = a[-1]
        lon3, lat3 = b[0]
        lon4, lat4 = b[-1]
        # Average endpoint-to-endpoint bearing for each line.
        bear1 = math.degrees(
            math.atan2(
                math.sin(math.radians(lon2 - lon1)) * math.cos(math.radians(lat2)),
                math.cos(math.radians(lat1)) * math.sin(math.radians(lat2))
                - math.sin(math.radians(lat1))
                * math.cos(math.radians(lat2))
                * math.cos(math.radians(lon2 - lon1)),
            )
        )
        bear2 = math.degrees(
            math.atan2(
                math.sin(math.radians(lon4 - lon3)) * math.cos(math.radians(lat4)),
                math.cos(math.radians(lat3)) * math.sin(math.radians(lat4))
                - math.sin(math.radians(lat3))
                * math.cos(math.radians(lat4))
                * math.cos(math.radians(lon4 - lon3)),
            )
        )
        delta = (bear1 - bear2 + 180) % 360 - 180
        return abs(delta)

    return _bearing_delta(way_coords, link_coords) <= 90


def _find_best_matching_link(
    way_coords: list[list[float]],
    network_fc: dict,
    max_distance_m: float = 20.0,
) -> tuple[dict, list[list[float]]] | None:
    """Find the network link best aligned with *way_coords*.

    Scoring uses geometric overlap: the link with the smallest mean distance
    between its vertices and the source way wins.  Only links within
    *max_distance_m* of the way are considered.  Returns the link and its
    (possibly reversed) coordinates so the matched geometry points in the same
    direction as the source way, or ``None`` when no suitable link exists.
    """
    try:
        from shapely.geometry import LineString, Point
    except ImportError:
        logger.warning("shapely not available; cannot match arrows to network links")
        return None

    if len(way_coords) < 2:
        return None

    way_line = LineString(way_coords)
    max_deg = max_distance_m / 111000.0
    candidates: list[tuple[dict, list[list[float]], float]] = []

    for link in network_fc.get("features") or []:
        link_coords = _link_coords(link)
        if link_coords is None:
            continue
        link_line = LineString(link_coords)
        if way_line.distance(link_line) > max_deg:
            continue

        # Mean vertex-to-way distance, using link vertices.
        score = sum(way_line.distance(Point(lon, lat)) for lon, lat in link_coords) / len(
            link_coords
        )

        candidates.append((link, link_coords, score))

    if not candidates:
        return None

    best_link, best_coords, _ = min(candidates, key=lambda x: x[2])
    if not _direction_aligned(way_coords, best_coords):
        best_coords = _reverse_coords(best_coords)
    return best_link, best_coords


def lane_mark_arrow_features_from_way(
    way_element: dict,
    network_fc: dict | None = None,
    max_distance_m: float = 20.0,
) -> list[dict]:
    """Generate lane mark arrow LineString features from a single OSM way.

    Generates one 2 m longitudinal LineString per ``turn:lanes*`` tag present on
    the way.  The feature follows the *matched network link's* centerline from
    5 m to 3 m before the toNode in the relevant direction.  If no matching link
    is found within *max_distance_m*, the original OSM-way geometry is used.

    Parameters
    ----------
    way_element:
        Overpass way element containing ``geometry`` and ``tags``.
    network_fc:
        Optional network FeatureCollection used to locate the proper link.
    max_distance_m:
        Maximum search distance for matching a network link.

    Returns
    -------
    list[dict]
        GeoJSON LineString features with ``assetType="laneMarkArrow"``.
    """
    features: list[dict] = []
    tags = way_element.get("tags") or {}
    osm_id = way_element.get("id")
    coords = _way_linestring(way_element.get("geometry") or [])
    if coords is None:
        return features

    matched: tuple[dict, list[list[float]]] | None = None
    if network_fc is not None:
        matched = _find_best_matching_link(coords, network_fc, max_distance_m=max_distance_m)

    variants = [
        ("turn:lanes", "forward"),
        ("turn:lanes:forward", "forward"),
        ("turn:lanes:backward", "backward"),
    ]

    for tag_key, direction in variants:
        value = tags.get(tag_key)
        if not value:
            continue
        if not parse_turn_lanes_tag(value):
            continue

        if matched is not None:
            link_props, link_coords = matched
            link_id = link_props.get("linkId")
            node_id = link_props.get("toNode")
            if direction == "backward":
                interpolated_coords = _reverse_coords(link_coords)
                node_id = link_props.get("fromNode")
            else:
                interpolated_coords = link_coords
        else:
            # Fallback to OSM-way geometry.
            link_id = None
            node_id = None
            interpolated_coords = _reverse_coords(coords) if direction == "backward" else coords

        start_pt = _point_at_distance_from_end(interpolated_coords, 5.0)
        end_pt = _point_at_distance_from_end(interpolated_coords, 3.0)

        if start_pt is None or end_pt is None:
            logger.warning("Could not interpolate lane mark on way %s", osm_id)
            continue

        props = {
            "osm_id": osm_id,
            "assetType": "laneMarkArrow",
            "turn:lanes": value,
            "direction": direction,
            "position_from_end_m": 5,
            "length_m": 2,
            "linkId": link_id,
            "nodeId": node_id,
            **tags,
        }
        features.append(
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": [start_pt, end_pt]},
                "properties": props,
            }
        )

    return features


def lane_mark_arrows_to_features(
    elements: list[dict],
    network_fc: dict | None = None,
    max_distance_m: float = 20.0,
) -> list[dict]:
    """Convert OSM way elements with ``turn:lanes*`` tags to lane mark arrows.

    Parameters
    ----------
    elements:
        Overpass elements.
    network_fc:
        Optional network FeatureCollection used to place arrows on the network.
    max_distance_m:
        Maximum search distance for matching a network link.

    Returns
    -------
    list[dict]
        Lane mark arrow LineString features.
    """
    features: list[dict] = []
    for elem in elements:
        if elem.get("type") != "way":
            continue
        tags = elem.get("tags") or {}
        if not any(k in tags for k in ("turn:lanes", "turn:lanes:forward", "turn:lanes:backward")):
            continue
        features.extend(
            lane_mark_arrow_features_from_way(
                elem, network_fc=network_fc, max_distance_m=max_distance_m
            )
        )

    logger.info("Generated %d lane mark arrow features from OSM.", len(features))

    if network_fc is not None:
        from osm_asset_fetcher.core.domain.geometry_matching import (
            match_features_to_network,
        )

        features = match_features_to_network(features, network_fc)

    return features


def match_lane_mark_arrows_to_network(
    features: list[dict],
    network_fc: dict,
    max_distance_m: float = 20.0,
) -> list[dict]:
    """Attach ``linkId`` and ``nodeId`` to lane mark arrow features.

    Convenience wrapper around :func:`match_features_to_network` using the
    midpoint of each 2 m arrow marking.
    """
    from osm_asset_fetcher.core.domain.geometry_matching import (
        match_features_to_network,
    )

    return match_features_to_network(features, network_fc, max_distance_m=max_distance_m)
