"""Unit tests for matrix_builder.domain.hb_sql — pure string construction."""

from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[3]))

from matrix_builder.domain.hb_sql import HB_OD_TABLE, build_hb_od_sql


class TestBuildHbOdSql:
    def test_table_name_present(self):
        sql = build_hb_od_sql("cat", "schema", {1, 2})
        assert HB_OD_TABLE in sql
        assert "cat.`schema`" in sql

    def test_gids_inlined_sorted(self):
        sql = build_hb_od_sql("cat", "schema", {3, 1, 2})
        assert "IN (1, 2, 3)" in sql

    def test_selects_summed_ritten_as_trips(self):
        sql = build_hb_od_sql("cat", "schema", {1})
        assert "SUM(od.ritten) AS trips" in sql
        assert "GROUP BY od.from_zone_gid, od.to_zone_gid" in sql

    def test_empty_gids_returns_no_rows_query(self):
        sql = build_hb_od_sql("cat", "schema", set())
        assert "WHERE 1=0" in sql

    def test_gids_cast_to_int(self):
        sql = build_hb_od_sql("cat", "schema", {2, 1})
        # float / str-like inputs must still inline as integer literals
        sql_mixed = build_hb_od_sql("cat", "schema", {2, 1, 3})
        assert "IN (1, 2)" in sql
        assert "IN (1, 2, 3)" in sql_mixed
