"""Elevation annotator core — adds terrain elevation to network links.

A small, source-independent post-processing step that runs *after* either
network fetcher (the Databricks ``network_fetcher`` or the OSM
``osm_network_fetcher``) once the network has been split into **directed**
links by ``bidirectional_splitter``.  For every link it looks up the terrain
elevation of its two geometry endpoints from the Open-Meteo elevation API and
writes them as:

* ``elevationFrom`` — metres above sea level at the link's ``fromNode`` endpoint
  (``geometry.coordinates[0]``).
* ``elevationTo``   — metres above sea level at the link's ``toNode`` endpoint
  (``geometry.coordinates[-1]``).

Because the annotator operates on directed links, the elevations are already
direction-correct: the return link of a pair has its geometry reversed, so its
``elevationFrom`` / ``elevationTo`` are naturally swapped relative to the
forward link.  Endpoints are deduplicated across the whole network so each
unique node's elevation is fetched only once.

The step is best-effort: when the elevation API cannot resolve a node the
corresponding field is left as ``None``.

Public API
----------
add_elevation(fc, *, elevation_url, batch_size, timeout) -> tuple[dict, dict]
    Annotate every LineString feature with ``elevationFrom`` / ``elevationTo``.
    Returns ``(fc, stats)`` with
    ``stats = {"links", "nodes", "resolved", "updated"}``.
"""

from __future__ import annotations

import logging

from shared.elevation import fetch_elevations

logger = logging.getLogger(__name__)

__all__ = ["add_elevation"]


def _coord_key(lon: float, lat: float) -> tuple[float, float]:
    """Round a ``(lon, lat)`` to a stable dedupe key (6 decimals ~= 0.1 m)."""
    return (round(lon, 6), round(lat, 6))


def add_elevation(
    fc: dict,
    *,
    elevation_url: str | None = None,
    batch_size: int = 100,
    timeout: int = 30,
    retries: int = 8,
    pause: float = 2.0,
) -> tuple[dict, dict]:
    """Add ``elevationFrom`` / ``elevationTo`` to every directed network link.

    Collects every unique link endpoint (network node) across the FeatureCollection,
    fetches its terrain elevation from Open-Meteo in batches, then writes the
    per-link endpoint elevations back onto each feature's properties.

    Parameters
    ----------
    fc:
        A network GeoJSON FeatureCollection of directed ``LineString`` links.
    elevation_url:
        Override for the Open-Meteo elevation endpoint (defaults to the
        ``ELEVATION_URL`` env var or the public Open-Meteo instance).
    batch_size:
        Coordinates per Open-Meteo request (capped at 100 by the client).
    timeout:
        HTTP request timeout in seconds per batch.
    retries:
        Maximum retry attempts per batch on transient HTTP errors such as 429.
    pause:
        Seconds to wait between successive batch requests (throttle).

    Returns
    -------
    fc:
        The same FeatureCollection (features mutated in place) with each link
        carrying ``elevationFrom`` / ``elevationTo`` (metres, or ``None`` where
        the API could not resolve the node).
    stats:
        ``{"links", "nodes", "resolved", "updated"}``.
    """
    features: list[dict] = fc.get("features") or []
    if not features:
        logger.warning("add_elevation called on empty FeatureCollection — nothing to do.")
        return fc, {"links": 0, "nodes": 0, "resolved": 0, "updated": 0}

    # 1. Collect unique endpoint coordinates (the graph nodes).
    order: list[tuple[float, float]] = []
    index: dict[tuple[float, float], int] = {}
    for feat in features:
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        for lon, lat in (coords[0], coords[-1]):
            key = _coord_key(lon, lat)
            if key not in index:
                index[key] = len(order)
                order.append((lat, lon))  # Open-Meteo wants (lat, lon)

    elev_by_key: dict[tuple[float, float], float | None] = {}
    resolved = 0
    if order:
        logger.info("Fetching elevation for %d unique network nodes", len(order))
        elevations = fetch_elevations(
            order,
            url=elevation_url,
            batch_size=batch_size,
            timeout=timeout,
            retries=retries,
            pause=pause,
        )
        elev_by_key = {_coord_key(lon, lat): elevations[i] for i, (lat, lon) in enumerate(order)}
        resolved = sum(1 for v in elevations if v is not None)
    else:
        logger.warning("add_elevation: no usable LineString endpoints found.")

    # 2. Write per-link endpoint elevations (direction-correct on directed links).
    updated = 0
    for feat in features:
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        props = feat.setdefault("properties", {})
        if len(coords) < 2:
            props.setdefault("elevationFrom", None)
            props.setdefault("elevationTo", None)
            continue
        elev_from = elev_by_key.get(_coord_key(coords[0][0], coords[0][1]))
        elev_to = elev_by_key.get(_coord_key(coords[-1][0], coords[-1][1]))
        props["elevationFrom"] = elev_from
        props["elevationTo"] = elev_to
        if elev_from is not None or elev_to is not None:
            updated += 1

    logger.info(
        "Elevation set on %d/%d links (%d/%d nodes resolved)",
        updated,
        len(features),
        resolved,
        len(order),
    )
    stats = {
        "links": len(features),
        "nodes": len(order),
        "resolved": resolved,
        "updated": updated,
    }
    return fc, stats
