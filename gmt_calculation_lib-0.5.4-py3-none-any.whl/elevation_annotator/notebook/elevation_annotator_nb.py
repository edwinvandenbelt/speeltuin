# Databricks notebook source
# ---------------------------------------------------------------------------
# elevation_annotator_nb.py — Databricks notebook interface.
#
# This notebook:
#   1. Reads widget parameters (network_uris — full URIs, comma-separated).
#   2. For each URI, reads the directed network GeoParquet (s3:// or local).
#   3. Calls the pure core function (add_elevation) — no Spark I/O.
#   4. Looks up terrain elevation for every unique link endpoint via Open-Meteo
#      and writes elevationFrom / elevationTo back onto each link.
#   5. Writes the enriched parquet back to the same URI (in-place update).
#   6. Prints a summary per URI.
#
# Requirements (Databricks cluster):
#   pip install boto3   (only needed for S3 paths)
# ---------------------------------------------------------------------------

# COMMAND ----------
import logging
import os
from datetime import datetime, timezone

logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger("elevation_annotator_nb")

# COMMAND ----------
# MAGIC %pip install --no-cache-dir --verbose gmt-calculation-lib
# MAGIC %pip install boto3

# COMMAND ----------
# Widget declarations — run "Run All" once to register, then re-run from
# the execution cell to pick up any widget changes.
try:
    dbutils.widgets.removeAll()  # noqa: F821
except Exception:
    pass

dbutils.widgets.text(  # noqa: F821
    "network_uris",
    "",
    "Comma-separated full URIs of directed network GeoParquet files (s3:// or local path)",
)
dbutils.widgets.text(  # noqa: F821
    "elevation_url",
    "",
    "Optional Open-Meteo elevation endpoint override (blank = public instance)",
)
dbutils.widgets.text(  # noqa: F821
    "LOG_LEVEL",
    "INFO",
    "Log level (DEBUG / INFO / WARNING / ERROR)",
)

# COMMAND ----------
_ll_str = dbutils.widgets.get("LOG_LEVEL").strip().upper()  # noqa: F821
_ll = getattr(logging, _ll_str, logging.INFO)
logger.setLevel(_ll)
logging.getLogger().setLevel(_ll)

# COMMAND ----------
from elevation_annotator.core.elevation_annotator_core import (  # noqa: E402, PLC0415
    add_elevation,
)

# COMMAND ----------
# ── Widget read + validation ───────────────────────────────────────────────────

_uris_raw = dbutils.widgets.get("network_uris").strip()  # noqa: F821
NETWORK_URIS = [u.strip() for u in _uris_raw.split(",") if u.strip()]
if not NETWORK_URIS:
    raise ValueError("Widget 'network_uris' is empty — provide at least one full network URI.")

ELEVATION_URL = dbutils.widgets.get("elevation_url").strip() or None  # noqa: F821

logger.info("network_uris=%s  elevation_url=%s", NETWORK_URIS, ELEVATION_URL)

# COMMAND ----------
# ── S3 helpers ─────────────────────────────────────────────────────────────────

import boto3  # noqa: E402, PLC0415


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        body = boto3.client("s3").get_object(Bucket=bucket, Key=key)["Body"].read()
        logger.info("Read s3://%s/%s  (%d bytes)", bucket, key, len(body))
        return body
    logger.info("Reading local file %s", uri)
    with open(uri, "rb") as _fh:
        return _fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        bucket, key = uri[5:].split("/", 1)
        boto3.client("s3").put_object(
            Bucket=bucket,
            Key=key,
            Body=data,
            ContentType="application/octet-stream",
        )
        logger.info("Wrote s3://%s/%s  (%d bytes)", bucket, key, len(data))
        return
    os.makedirs(os.path.dirname(uri) or ".", exist_ok=True)
    with open(uri, "wb") as _fh:
        _fh.write(data)
    logger.info("Wrote %s  (%d bytes)", uri, len(data))


# COMMAND ----------
# MAGIC %md
# MAGIC ## Run ElevationAnnotator
# MAGIC
# MAGIC Adjust widget values above, then **re-run from this cell** to reprocess
# MAGIC without re-registering widgets or reloading libraries.

# COMMAND ----------
# ── Main execution ─────────────────────────────────────────────────────────────

from shared.geoparquet import from_geoparquet, to_geoparquet  # noqa: E402, PLC0415

_t_start = datetime.now(timezone.utc)
print(f"Starting  {_t_start.isoformat()}")
print(f"URIs     : {len(NETWORK_URIS)}")
print()

_results: dict = {}

for _uri in NETWORK_URIS:
    logger.info("─── Annotating: %s ───", _uri)
    _t_uri = datetime.now(timezone.utc)
    try:
        _fc = from_geoparquet(_read_uri(_uri))

        _annotated_fc, _stats = add_elevation(_fc, elevation_url=ELEVATION_URL)

        _write_uri(_uri, to_geoparquet(_annotated_fc))

        _elapsed = (datetime.now(timezone.utc) - _t_uri).total_seconds()
        logger.info(
            "%s done: links=%d nodes=%d resolved=%d updated=%d  %.2fs",
            _uri,
            _stats["links"],
            _stats["nodes"],
            _stats["resolved"],
            _stats["updated"],
            _elapsed,
        )
        _results[_uri] = _stats

    except Exception as _exc:
        import traceback  # noqa: PLC0415

        logger.error("%s FAILED: %s\n%s", _uri, _exc, traceback.format_exc())
        _results[_uri] = {"error": str(_exc)}

_total_elapsed = (datetime.now(timezone.utc) - _t_start).total_seconds()
logger.info("All URIs complete in %.2fs", _total_elapsed)

# COMMAND ----------
# ── Results summary ────────────────────────────────────────────────────────────

_SEP = "─" * 60

print(_SEP)
print(f"Elevation annotator complete — {_total_elapsed:.1f}s total")
print(_SEP)
print()

for _uri in NETWORK_URIS:
    _stats = _results.get(_uri, {})
    if "error" in _stats:
        print(f"  [FAILED] {_uri}")
        print(f"           {_stats['error']}")
    else:
        print(
            f"  [OK] {_uri}  —  "
            f"{_stats.get('updated', '?')} links updated, "
            f"{_stats.get('resolved', '?')}/{_stats.get('nodes', '?')} nodes resolved"
        )
    print()

print(_SEP)
