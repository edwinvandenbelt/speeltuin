"""Unit tests for bidirectional_splitter core — pure Python, no I/O."""

from __future__ import annotations

import math as _math

import pytest

from bidirectional_splitter.core.bidirectional_splitter_core import (
    _estimate_capacity,
    _estimate_road_width,
    post_process_features,
)
from shared.displacer import (
    _MEDIAN_HALF_M,
    _OFFSET_M_BIKE_EXTRA,
    _OFFSET_M_BIKE_ONEWAY_SNAPPED,
    _OFFSET_M_BIKE_STANDALONE,
    _OFFSET_M_CAR,
    _OFFSET_M_FOOT_EXTRA,
)

# ---------------------------------------------------------------------------
# _estimate_capacity
# ---------------------------------------------------------------------------


class TestEstimateRoadWidth:
    def test_uses_wkd_width_when_present(self):
        width, min_w, max_w = _estimate_road_width(7.0, 6.0, 8.0, None, 2, False)
        assert width == 7.0
        assert min_w == 6.0
        assert max_w == 8.0

    def test_falls_back_to_osm_width(self):
        width, min_w, max_w = _estimate_road_width(None, None, None, 6.0, 2, False)
        assert width == 6.0
        assert min_w is None
        assert max_w is None

    def test_falls_back_to_lanes_times_three(self):
        width, min_w, max_w = _estimate_road_width(None, None, None, None, 2, False)
        assert width == 6.0
        assert min_w is None
        assert max_w is None

    def test_returns_none_when_no_width_and_no_lanes(self):
        width, min_w, max_w = _estimate_road_width(None, None, None, None, None, False)
        assert width is None
        assert min_w is None
        assert max_w is None

    def test_halves_width_for_bidirectional_split(self):
        width, min_w, max_w = _estimate_road_width(6.0, 5.0, 7.0, None, 2, True)
        assert width == 3.0
        assert min_w == 5.0
        assert max_w == 7.0


class TestEstimateCapacity:
    def test_returns_none_when_speed_is_none(self):
        assert _estimate_capacity(None, 2) is None

    def test_uses_one_lane_when_lanes_none(self):
        result = _estimate_capacity(80, None)
        assert result == 1800.0

    def test_speed_30_gives_1500_per_lane(self):
        assert _estimate_capacity(30, 1) == 1500.0

    def test_speed_50_gives_1700_per_lane(self):
        assert _estimate_capacity(50, 1) == 1700.0

    def test_speed_80_gives_1800_per_lane(self):
        assert _estimate_capacity(80, 1) == 1800.0

    def test_speed_130_gives_2200_per_lane(self):
        assert _estimate_capacity(130, 1) == 2200.0

    def test_two_lanes_doubles_result(self):
        single = _estimate_capacity(80, 1)
        assert single is not None
        double = _estimate_capacity(80, 2)
        assert double == pytest.approx(single * 2)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_raw_feature(
    seg_id: int,
    coords: list,
    *,
    heen: bool = True,
    terug: bool = True,
    flow_heen: float = 100.0,
    flow_terug: float = 80.0,
    mode: str = "CAR",
    car_link_ids: list | None = None,
    car_oneway: bool = False,
    elevation_from: float | None = None,
    elevation_to: float | None = None,
) -> dict:
    """Construct a raw feature as returned by rows_to_feature_collection."""
    props: dict = {
        "linkId": seg_id,
        "mode": mode,
        "fromNode": 1,
        "toNode": 2,
        "rijrichting_heen": heen,
        "cap_heen": 2000,
        "rijstroken_heen": 2,
        "max_snelheid_heen": 80,
        "rijrichting_terug": terug,
        "cap_terug": 2000,
        "rijstroken_terug": 2,
        "max_snelheid_terug": 80,
        "length": 100.0,
        "flow_heen": {
            "work": flow_heen,
            "recreational": 0,
            "education": 0,
            "shopping": 0,
            "unknown": 0,
        },
        "flow_terug": {
            "work": flow_terug,
            "recreational": 0,
            "education": 0,
            "shopping": 0,
            "unknown": 0,
        },
        "flow_dp_heen": {"mrh": 60.0, "erh": 50.0, "rest": 30.0},
        "flow_dp_terug": {"mrh": 45.0, "erh": 40.0, "rest": 25.0},
        "elevationFrom": elevation_from,
        "elevationTo": elevation_to,
    }
    if car_link_ids is not None:
        props["carLinkIds"] = car_link_ids
        props["carOneway"] = car_oneway
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": props,
    }


_COORDS_NS = [[4.0, 52.0], [4.0, 52.1]]
_COORDS_EW = [[4.0, 52.0], [4.1, 52.0]]


# ---------------------------------------------------------------------------
# post_process_features
# ---------------------------------------------------------------------------


class TestPostProcessFeatures:
    def test_bidir_produces_two_features(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        assert len(result) == 2

    def test_heen_only_produces_one_feature(self):
        features = [_make_raw_feature(1, _COORDS_NS, terug=False)]
        result = post_process_features(features)
        assert len(result) == 1

    def test_terug_only_produces_one_feature(self):
        features = [_make_raw_feature(1, _COORDS_NS, heen=False)]
        result = post_process_features(features)
        assert len(result) == 1

    def test_neither_direction_omitted(self):
        features = [_make_raw_feature(1, _COORDS_NS, flow_heen=0.0, flow_terug=0.0)]
        result = post_process_features(features)
        assert len(result) == 0

    def test_bidir_opposite_ids_set(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        ids = {r["properties"]["spectrumId"] for r in result}
        assert 1 in ids
        assert -1 in ids
        for r in result:
            assert r["properties"]["reverseLinkIds"] is not None

    def test_heading_present(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            h = r["properties"]["heading"]
            assert 0.0 <= h < 360.0

    def test_flow24hrs_computed(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            assert r["properties"]["flow24hrs"] > 0
            assert r["properties"]["flow"] > 0
            assert isinstance(r["properties"]["flowsPerMotive"], dict)

    def test_flow_temporal_unit_is_24(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            assert r["properties"]["flowTemporalUnit"] == 24

    def test_speed_limit_mirrors_speed(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            assert r["properties"]["speedLimit"] == 80
            assert r["properties"]["speedLimit"] == r["properties"]["speed"]

    def test_aadt_sums_both_directions(self):
        # flow_heen work=100, flow_terug work=80 -> aadt = 180 * factor(1.0).
        features = [_make_raw_feature(1, _COORDS_NS, flow_heen=100.0, flow_terug=80.0)]
        result = post_process_features(features)
        for r in result:
            assert r["properties"]["aadt"] == pytest.approx(180.0)

    def test_elevation_fields_propagated_and_swapped(self):
        # Elevation is added *before* the split on the undirected link; the
        # splitter propagates it to the heen link and swaps it on the terug
        # link (whose geometry is reversed).
        features = [_make_raw_feature(1, _COORDS_NS, elevation_from=10.0, elevation_to=25.0)]
        result = post_process_features(features)
        heen = next(r for r in result if r["properties"]["spectrumId"] == 1)
        terug = next(r for r in result if r["properties"]["spectrumId"] == -1)
        assert heen["properties"]["elevationFrom"] == 10.0
        assert heen["properties"]["elevationTo"] == 25.0
        assert terug["properties"]["elevationFrom"] == 25.0
        assert terug["properties"]["elevationTo"] == 10.0

    def test_elevation_fields_default_none(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            assert r["properties"]["elevationFrom"] is None
            assert r["properties"]["elevationTo"] is None

    def test_flows_per_daypart_present(self):
        features = [_make_raw_feature(1, _COORDS_NS)]
        result = post_process_features(features)
        for r in result:
            dp = r["properties"]["flowsPerDaypart"]
            assert isinstance(dp, dict)
            assert set(dp.keys()) == {"mrh", "erh", "rest"}

    def test_terug_only_geometry_reversed(self):
        features = [_make_raw_feature(1, _COORDS_NS, heen=False)]
        result = post_process_features(features)
        coords = result[0]["geometry"]["coordinates"]
        assert coords[0] == pytest.approx(_COORDS_NS[-1], abs=1e-9)

    def test_empty_input(self):
        assert post_process_features([]) == []

    def test_multiple_features_processed(self):
        features = [
            _make_raw_feature(1, _COORDS_NS),
            _make_raw_feature(2, _COORDS_EW),
        ]
        result = post_process_features(features)
        assert len(result) == 4  # 2 bidir x 2 directions


# ---------------------------------------------------------------------------
# Offset distance per mode
# ---------------------------------------------------------------------------

# A 300 m north-going link gives enough length for interior vertices to be
# fully offset (clear of the near-node taper zone).
_LAT_PER_M = 1.0 / 111_320.0
_COORDS_300M_N = [[4.0, 52.0], [4.0, 52.0 + 300 * _LAT_PER_M]]

_D_LON = 111_320.0 * _math.cos(_math.radians(52.0))


def _mid_lon_offset(features: list, direction: str) -> float:
    """Return the longitude offset of the midpoint of the *direction* feature
    relative to the original centreline (lon 4.0)."""
    feat = next(f for f in features if f["properties"].get("heading", 0) < 180)
    if direction == "terug":
        feat = next(f for f in features if f["properties"].get("heading", 0) >= 180)
    coords = feat["geometry"]["coordinates"]
    mid = coords[len(coords) // 2]
    return (mid[0] - 4.0) * _D_LON  # convert lon-degrees → metres


class TestBikeOffset:
    def test_bike_bidir_snapped_uses_car_road_offset(self):
        """BIKE snapped to a car road (carLinkIds set) → offset outside car lanes (3.75 m)."""
        features = [_make_raw_feature(1, _COORDS_300M_N, mode="BIKE", car_link_ids=["C1"])]
        result = post_process_features(features)
        assert len(result) == 2
        off = _mid_lon_offset(result, "heen")
        assert off == pytest.approx(_OFFSET_M_CAR + _MEDIAN_HALF_M + _OFFSET_M_BIKE_EXTRA, abs=0.05)

    def test_bike_bidir_standalone_uses_standalone_offset(self):
        """BIKE NOT on a car road (no carLinkIds) → small standalone offset (0.5 m)."""
        features = [_make_raw_feature(1, _COORDS_300M_N, mode="BIKE")]
        result = post_process_features(features)
        assert len(result) == 2
        off = _mid_lon_offset(result, "heen")
        assert off == pytest.approx(_OFFSET_M_BIKE_STANDALONE, abs=0.05)

    def test_bike_bidir_standalone_total_gap_is_1m(self):
        """Both directed lines of a standalone BIKE are 1 m apart (0.5 m each side)."""
        features = [_make_raw_feature(1, _COORDS_300M_N, mode="BIKE")]
        result = post_process_features(features)
        off_heen = _mid_lon_offset(result, "heen")
        off_terug = abs(_mid_lon_offset(result, "terug"))
        assert (off_heen + off_terug) == pytest.approx(2 * _OFFSET_M_BIKE_STANDALONE, abs=0.1)

    def test_car_bidir_still_uses_car_offset(self):
        """CAR bidirectional links are offset by car half-width plus half median."""
        features = [_make_raw_feature(1, _COORDS_300M_N, mode="CAR")]
        result = post_process_features(features)
        assert len(result) == 2
        off = _mid_lon_offset(result, "heen")
        assert off == pytest.approx(_OFFSET_M_CAR + _MEDIAN_HALF_M, abs=0.05)

    def test_bike_offset_larger_than_car_offset(self):
        """Sanity: snapped BIKE offset is larger than CAR offset."""
        bike_off = _OFFSET_M_CAR + _MEDIAN_HALF_M + _OFFSET_M_BIKE_EXTRA
        car_off = _OFFSET_M_CAR + _MEDIAN_HALF_M
        assert bike_off > car_off

    def test_standalone_bike_offset_positive(self):
        """Sanity: solitair fietspad has a positive offset (not zero)."""
        assert _OFFSET_M_BIKE_STANDALONE > 0.0

    def test_pedestrian_bidir_uses_foot_offset(self):
        """PEDESTRIAN bidirectional links are offset beyond the bike lane (outside fietspad)."""
        features = [_make_raw_feature(1, _COORDS_300M_N, mode="PEDESTRIAN")]
        result = post_process_features(features)
        assert len(result) == 2
        off = _mid_lon_offset(result, "heen")
        expected = _OFFSET_M_CAR + _MEDIAN_HALF_M + _OFFSET_M_BIKE_EXTRA + _OFFSET_M_FOOT_EXTRA
        assert off == pytest.approx(expected, abs=0.05)

    def test_foot_offset_larger_than_bike_offset(self):
        """Sanity: PEDESTRIAN offset is larger than BIKE offset — voetpad lies outside fietspad."""
        foot_off = _OFFSET_M_CAR + _MEDIAN_HALF_M + _OFFSET_M_BIKE_EXTRA + _OFFSET_M_FOOT_EXTRA
        bike_off = _OFFSET_M_CAR + _MEDIAN_HALF_M + _OFFSET_M_BIKE_EXTRA
        assert foot_off > bike_off

    def test_pedestrian_heen_only_not_offset(self):
        """One-directional PEDESTRIAN links are not offset (gesplitst wegvak)."""
        features = [_make_raw_feature(1, _COORDS_300M_N, terug=False, mode="PEDESTRIAN")]
        result = post_process_features(features)
        assert len(result) == 1
        coords = result[0]["geometry"]["coordinates"]
        mid = coords[len(coords) // 2]
        assert mid[0] == pytest.approx(4.0, abs=1e-9)

    def test_bike_heen_only_not_offset(self):
        """One-directional BIKE links are not offset (same as CAR)."""
        features = [_make_raw_feature(1, _COORDS_300M_N, terug=False, mode="BIKE")]
        result = post_process_features(features)
        assert len(result) == 1
        coords = result[0]["geometry"]["coordinates"]
        mid = coords[len(coords) // 2]
        assert mid[0] == pytest.approx(4.0, abs=1e-9)

    def test_bike_bidir_snapped_oneway_uses_oneway_offset(self):
        """BIKE snapped to a one-way car road → 2.5 m offset (5 m total gap = 1 car lane)."""
        features = [
            _make_raw_feature(1, _COORDS_300M_N, mode="BIKE", car_link_ids=["C1"], car_oneway=True)
        ]
        result = post_process_features(features)
        assert len(result) == 2
        off = _mid_lon_offset(result, "heen")
        assert off == pytest.approx(_OFFSET_M_BIKE_ONEWAY_SNAPPED, abs=0.05)

    def test_bike_bidir_snapped_oneway_total_gap_is_5m(self):
        """Both directed lines of an one-way-snapped BIKE are 5.0 m apart (2.5 m each side)."""
        features = [
            _make_raw_feature(1, _COORDS_300M_N, mode="BIKE", car_link_ids=["C1"], car_oneway=True)
        ]
        result = post_process_features(features)
        off_heen = _mid_lon_offset(result, "heen")
        off_terug = abs(_mid_lon_offset(result, "terug"))
        assert (off_heen + off_terug) == pytest.approx(2 * _OFFSET_M_BIKE_ONEWAY_SNAPPED, abs=0.1)

    def test_oneway_snapped_offset_larger_than_car_half_offset(self):
        """Sanity: one-way snapped bike offset exceeds the car half-offset."""
        assert _OFFSET_M_BIKE_ONEWAY_SNAPPED > _OFFSET_M_CAR + _MEDIAN_HALF_M

    def test_oneway_snapped_offset_larger_than_standalone(self):
        """Sanity: one-way snapped offset > standalone offset (snapped is always wider)."""
        assert _OFFSET_M_BIKE_ONEWAY_SNAPPED > _OFFSET_M_BIKE_STANDALONE

    def test_car_oneway_affects_offset_only(self):
        """carOneway on the raw BIKE feature only influences the offset, not the output schema."""
        features = [
            _make_raw_feature(1, _COORDS_300M_N, mode="BIKE", car_link_ids=["C1"], car_oneway=True)
        ]
        result = post_process_features(features)
        assert len(result) == 2
        off = _mid_lon_offset(result, "heen")
        assert off == pytest.approx(_OFFSET_M_BIKE_ONEWAY_SNAPPED, abs=0.05)
