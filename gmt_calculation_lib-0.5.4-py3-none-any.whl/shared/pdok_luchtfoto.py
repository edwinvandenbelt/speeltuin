"""PDOK Luchtfoto (aerial imagery) WMS client — pure stdlib (urllib), no extra deps.

Used by ``turn_lane_analyzer`` to fetch a high-resolution aerial-photo crop
centred on a network intersection, so the turn-lane markings (opstelstroken)
around the junction can be analysed with classical computer vision.

The source is the Dutch PDOK "Luchtfoto Actueel HR" (8 cm RGB orthophoto) WMS::

    GET https://service.pdok.nl/hwh/luchtfotorgb/wms/v1_0
        ?SERVICE=WMS&VERSION=1.3.0&REQUEST=GetMap
        &LAYERS=Actueel_orthoHR&CRS=EPSG:28992
        &BBOX=<minX,minY,maxX,maxY>&WIDTH=512&HEIGHT=512&FORMAT=image/jpeg

Because the WMS speaks RD New (EPSG:28992) metres, a WGS-84 intersection node is
first projected with :func:`shared.rd_projection.wgs84_to_rd`, then a square
bounding box of ``±radius_m`` metres is built around it.  The returned bytes are
a raw JPEG that the CV layer decodes with ``cv2.imdecode`` (no Pillow needed).

Public API
----------
resolve_luchtfoto_url(url) -> str
    Resolve the effective WMS endpoint (arg > ``LUCHTFOTO_WMS_URL`` env > default).
rd_bbox(x, y, radius_m) -> tuple[float, float, float, float]
    Build a square RD-New bbox ``(minX, minY, maxX, maxY)`` around a centre.
build_getmap_url(node_lonlat, *, radius_m, image_px, layer, base_url) -> str
    Build a WMS GetMap URL for the aerial crop around a WGS-84 node.
fetch_aerial_crop(node_lonlat, *, radius_m, image_px, ...) -> bytes
    Fetch the JPEG crop bytes for a WGS-84 node, with retries + throttle.
"""

from __future__ import annotations

import logging
import os
import random
import time
import urllib.error
import urllib.parse
import urllib.request

from shared.rd_projection import wgs84_to_rd

logger = logging.getLogger(__name__)

#: Default PDOK Luchtfoto HR (8 cm RGB orthophoto) WMS endpoint.
_LUCHTFOTO_URL_FALLBACK = "https://service.pdok.nl/hwh/luchtfotorgb/wms/v1_0"

#: Default WMS layer — the most recent high-resolution orthophoto.
DEFAULT_LAYER = "Actueel_orthoHR"

#: Default half-size (metres) of the square crop fetched per intersection.
DEFAULT_RADIUS_M = 40.0

#: Default output image size in pixels (square).  At radius 40 m this yields a
#: 512 px crop ≈ 0.156 m/px, comfortably above the 8 cm source resolution.
DEFAULT_IMAGE_PX = 512

#: Default seconds to wait between successive GetMap requests (throttle to stay
#: friendly to the public PDOK service).  Overridable per call.
DEFAULT_REQUEST_PAUSE = 0.2

#: Cap for a single exponential-backoff wait (seconds) on transient errors.
_MAX_BACKOFF = 60.0


def resolve_luchtfoto_url(url: str | None = None) -> str:
    """Resolve the effective PDOK Luchtfoto WMS endpoint at call time.

    Resolution order: an explicit non-empty *url*, then the ``LUCHTFOTO_WMS_URL``
    environment variable, then the public PDOK instance.  Resolving lazily means
    a ``.env`` file loaded after import is still honoured.
    """
    if url and url.strip():
        return url.strip()
    env_url = os.environ.get("LUCHTFOTO_WMS_URL", "").strip()
    return env_url or _LUCHTFOTO_URL_FALLBACK


def rd_bbox(x: float, y: float, radius_m: float) -> tuple[float, float, float, float]:
    """Build a square RD-New bbox ``(minX, minY, maxX, maxY)`` around ``(x, y)``.

    Parameters
    ----------
    x, y:
        Centre point in RD New metres (EPSG:28992).
    radius_m:
        Half-size of the square in metres; the bbox spans ``2 * radius_m``.
    """
    return (x - radius_m, y - radius_m, x + radius_m, y + radius_m)


def build_getmap_url(
    node_lonlat: tuple[float, float],
    *,
    radius_m: float = DEFAULT_RADIUS_M,
    image_px: int = DEFAULT_IMAGE_PX,
    layer: str = DEFAULT_LAYER,
    base_url: str | None = None,
) -> str:
    """Build a WMS 1.3.0 GetMap URL for the aerial crop around a WGS-84 node.

    Parameters
    ----------
    node_lonlat:
        The intersection node as ``(lon, lat)`` in WGS-84.
    radius_m:
        Half-size of the square crop in metres.
    image_px:
        Output image width and height in pixels (square).
    layer:
        WMS layer name; defaults to :data:`DEFAULT_LAYER`.
    base_url:
        Endpoint URL; defaults to the resolved PDOK instance.

    Returns
    -------
    A fully-formed WMS GetMap URL string requesting an ``image/jpeg`` crop.
    """
    lon, lat = node_lonlat
    x, y = wgs84_to_rd(lon=lon, lat=lat)
    min_x, min_y, max_x, max_y = rd_bbox(x, y, radius_m)
    # WMS 1.3.0 with EPSG:28992 expects BBOX in (minX, minY, maxX, maxY) —
    # RD New is an easting/northing CRS so axis order is x,y.
    bbox_str = f"{min_x:.3f},{min_y:.3f},{max_x:.3f},{max_y:.3f}"
    params = {
        "SERVICE": "WMS",
        "VERSION": "1.3.0",
        "REQUEST": "GetMap",
        "LAYERS": layer,
        "STYLES": "",
        "CRS": "EPSG:28992",
        "BBOX": bbox_str,
        "WIDTH": str(image_px),
        "HEIGHT": str(image_px),
        "FORMAT": "image/jpeg",
    }
    url = resolve_luchtfoto_url(base_url)
    return f"{url}?{urllib.parse.urlencode(params)}"


def fetch_aerial_crop(
    node_lonlat: tuple[float, float],
    *,
    radius_m: float = DEFAULT_RADIUS_M,
    image_px: int = DEFAULT_IMAGE_PX,
    layer: str = DEFAULT_LAYER,
    base_url: str | None = None,
    timeout: int = 30,
    retries: int = 5,
    pause: float = DEFAULT_REQUEST_PAUSE,
) -> bytes:
    """Fetch the aerial-photo JPEG crop for a WGS-84 intersection node.

    The bounding box is derived by projecting the node to RD New and squaring
    off ``±radius_m`` metres around it.  Transient errors (429/5xx, network
    failures) are retried with exponential backoff; a short *pause* is applied
    before the request to throttle bulk calls.

    Parameters
    ----------
    node_lonlat:
        The intersection node as ``(lon, lat)`` in WGS-84.
    radius_m:
        Half-size of the square crop in metres.
    image_px:
        Output image width and height in pixels (square).
    layer:
        WMS layer name.
    base_url:
        Endpoint URL; defaults to the resolved PDOK instance.
    timeout:
        HTTP request timeout in seconds.
    retries:
        Maximum attempts on transient errors.
    pause:
        Seconds to wait before issuing the request (throttle).  Set ``0`` to
        disable.

    Returns
    -------
    Raw JPEG bytes of the aerial crop.
    """
    if pause > 0:
        time.sleep(pause)
    request_url = build_getmap_url(
        node_lonlat,
        radius_m=radius_m,
        image_px=image_px,
        layer=layer,
        base_url=base_url,
    )
    last_exc: Exception | None = None
    for attempt in range(retries):
        if attempt > 0:
            wait = min(_MAX_BACKOFF, 2**attempt) + random.uniform(0, 1)  # noqa: S311
            logger.warning(
                "Luchtfoto retry %d/%d after %.0fs (last error: %s)",
                attempt,
                retries - 1,
                wait,
                last_exc,
            )
            time.sleep(wait)
        try:
            req = urllib.request.Request(request_url, method="GET")  # noqa: S310
            req.add_header("User-Agent", "gmt-calculation-lib/1.0")
            req.add_header("Accept", "image/jpeg")
            with urllib.request.urlopen(req, timeout=timeout) as resp:  # noqa: S310
                if resp.status in (429, 500, 502, 503, 504):
                    raise urllib.error.HTTPError(
                        request_url, resp.status, resp.reason, resp.headers, None
                    )
                content_type = (resp.headers.get("Content-Type") or "").lower()
                body = resp.read()
            if "image" not in content_type:
                # PDOK returns a ServiceException as XML on bad requests.
                raise ValueError(
                    f"Luchtfoto WMS returned non-image response "
                    f"(Content-Type={content_type!r}): {body[:200]!r}"
                )
            return body
        except urllib.error.HTTPError as exc:
            if exc.code in (429, 500, 502, 503, 504):
                last_exc = exc
                continue
            raise
        except urllib.error.URLError as exc:
            last_exc = exc
            continue
    raise last_exc  # type: ignore[misc]
