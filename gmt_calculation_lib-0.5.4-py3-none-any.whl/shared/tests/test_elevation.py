"""Unit tests for shared.elevation — Open-Meteo client (stubbed HTTP)."""

from __future__ import annotations

import json
import urllib.error
import urllib.parse

import pytest

from shared.elevation import (
    MAX_BATCH_SIZE,
    build_elevation_url,
    fetch_elevations,
    resolve_elevation_url,
)

# ---------------------------------------------------------------------------
# resolve_elevation_url
# ---------------------------------------------------------------------------


def test_resolve_prefers_explicit_arg():
    assert resolve_elevation_url("https://example.test/elev") == "https://example.test/elev"


def test_resolve_uses_env(monkeypatch):
    monkeypatch.setenv("ELEVATION_URL", "https://env.test/v1/elevation")
    assert resolve_elevation_url() == "https://env.test/v1/elevation"


def test_resolve_falls_back_to_open_meteo(monkeypatch):
    monkeypatch.delenv("ELEVATION_URL", raising=False)
    assert resolve_elevation_url() == "https://api.open-meteo.com/v1/elevation"


def test_resolve_blank_env_falls_back(monkeypatch):
    monkeypatch.setenv("ELEVATION_URL", "   ")
    assert resolve_elevation_url() == "https://api.open-meteo.com/v1/elevation"


# ---------------------------------------------------------------------------
# build_elevation_url
# ---------------------------------------------------------------------------


def test_build_url_orders_lat_then_lon(monkeypatch):
    monkeypatch.delenv("ELEVATION_URL", raising=False)
    url = build_elevation_url([(52.0907, 5.1214), (52.0915, 5.1350)])
    assert url.startswith("https://api.open-meteo.com/v1/elevation?")
    assert "latitude=52.090700%2C52.091500" in url
    assert "longitude=5.121400%2C5.135000" in url


def test_build_url_empty_raises():
    with pytest.raises(ValueError):
        build_elevation_url([])


def test_build_url_over_batch_raises():
    coords = [(52.0, 5.0)] * (MAX_BATCH_SIZE + 1)
    with pytest.raises(ValueError):
        build_elevation_url(coords)


# ---------------------------------------------------------------------------
# fetch_elevations — stubbed urllib
# ---------------------------------------------------------------------------


class _FakeResponse:
    def __init__(self, payload: dict):
        self.status = 200
        self.reason = "OK"
        self.headers = {}
        self._body = json.dumps(payload).encode("utf-8")

    def read(self):
        return self._body

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        return False


def _install_fake_urlopen(monkeypatch, capture: list):
    from urllib.parse import parse_qs, urlparse

    def _fake_urlopen(req, timeout=None):  # noqa: ARG001
        capture.append(req.full_url)
        qs = parse_qs(urlparse(req.full_url).query)
        lats = qs["latitude"][0].split(",")
        # Echo back one elevation per requested coordinate.
        return _FakeResponse({"elevation": [float(i) for i in range(len(lats))]})

    monkeypatch.setattr("urllib.request.urlopen", _fake_urlopen, raising=True)


def test_fetch_empty_returns_empty():
    assert fetch_elevations([]) == []


def test_fetch_single_batch(monkeypatch):
    calls: list = []
    _install_fake_urlopen(monkeypatch, calls)
    coords = [(52.0, 5.0), (52.1, 5.1), (52.2, 5.2)]
    result = fetch_elevations(coords)
    assert result == [0.0, 1.0, 2.0]
    assert len(calls) == 1


def test_fetch_splits_into_batches(monkeypatch):
    calls: list = []
    _install_fake_urlopen(monkeypatch, calls)
    coords = [(52.0 + i * 0.001, 5.0) for i in range(250)]
    result = fetch_elevations(coords, batch_size=100)
    assert len(result) == 250
    # 250 coords / 100 per batch -> 3 requests.
    assert len(calls) == 3


def test_fetch_batch_size_capped_at_max(monkeypatch):
    calls: list = []
    _install_fake_urlopen(monkeypatch, calls)
    coords = [(52.0 + i * 0.001, 5.0) for i in range(150)]
    # Even if caller asks for 1000, batches never exceed MAX_BATCH_SIZE.
    fetch_elevations(coords, batch_size=1000)
    assert len(calls) == 2


def test_fetch_handles_null_elevation(monkeypatch):
    def _fake_urlopen(req, timeout=None):  # noqa: ARG001
        return _FakeResponse({"elevation": [7.0, None]})

    monkeypatch.setattr("urllib.request.urlopen", _fake_urlopen, raising=True)
    result = fetch_elevations([(52.0, 5.0), (52.1, 5.1)])
    assert result == [7.0, None]


def test_fetch_length_mismatch_raises(monkeypatch):
    def _fake_urlopen(req, timeout=None):  # noqa: ARG001
        return _FakeResponse({"elevation": [7.0]})

    monkeypatch.setattr("urllib.request.urlopen", _fake_urlopen, raising=True)
    with pytest.raises(RuntimeError):
        fetch_elevations([(52.0, 5.0), (52.1, 5.1)])


def test_fetch_invalid_json_raises(monkeypatch):
    class _BadResponse(_FakeResponse):
        def __init__(self):
            self.status = 200
            self.reason = "OK"
            self.headers = {}
            self._body = b"not json"

    monkeypatch.setattr(
        "urllib.request.urlopen",
        lambda req, timeout=None: _BadResponse(),  # noqa: ARG005
        raising=True,
    )
    with pytest.raises(ValueError):
        fetch_elevations([(52.0, 5.0)])


def test_fetch_best_effort_on_persistent_429(monkeypatch):
    """Persistent 429 for one batch returns None for that batch; other batches succeed."""

    call_count: dict[str, int] = {"ok": 0, "fail": 0}

    def _fake_urlopen(req, timeout=None):  # noqa: ARG001
        if "latitude=52.500000&longitude" in req.full_url:
            call_count["fail"] += 1
            raise urllib.error.HTTPError(
                req.full_url,
                429,
                "Too Many Requests",
                {"Retry-After": "0"},
                None,
            )
        call_count["ok"] += 1
        qs = urllib.parse.parse_qs(urllib.parse.urlparse(req.full_url).query)
        lats = qs["latitude"][0].split(",")
        return _FakeResponse({"elevation": [float(i) for i in range(len(lats))]})

    monkeypatch.setattr("urllib.request.urlopen", _fake_urlopen, raising=True)

    result = fetch_elevations(
        [(52.0, 5.0), (52.1, 5.1), (52.5, 5.5)],
        url="https://test/elevation",
        batch_size=2,
        retries=2,
        pause=0,
    )
    # Batch 1 (coords 0-1) succeeds, batch 2 (coord 2) fails persistently.
    assert len(result) == 3
    assert result[2] is None
    assert call_count["ok"] >= 1
    assert call_count["fail"] == 2
