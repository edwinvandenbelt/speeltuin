"""Unit tests for shared.pdok_luchtfoto — PDOK Luchtfoto WMS client (stubbed HTTP)."""

from __future__ import annotations

import urllib.parse

import pytest

from shared.pdok_luchtfoto import (
    DEFAULT_LAYER,
    build_getmap_url,
    fetch_aerial_crop,
    rd_bbox,
    resolve_luchtfoto_url,
)
from shared.rd_projection import wgs84_to_rd

# A node roughly in Deventer (WGS-84).
_NODE = (6.1552, 52.2551)


# ---------------------------------------------------------------------------
# resolve_luchtfoto_url
# ---------------------------------------------------------------------------


def test_resolve_prefers_explicit_arg():
    assert resolve_luchtfoto_url("https://example.test/wms") == "https://example.test/wms"


def test_resolve_uses_env(monkeypatch):
    monkeypatch.setenv("LUCHTFOTO_WMS_URL", "https://env.test/wms")
    assert resolve_luchtfoto_url() == "https://env.test/wms"


def test_resolve_falls_back_to_pdok(monkeypatch):
    monkeypatch.delenv("LUCHTFOTO_WMS_URL", raising=False)
    assert resolve_luchtfoto_url() == "https://service.pdok.nl/hwh/luchtfotorgb/wms/v1_0"


# ---------------------------------------------------------------------------
# rd_bbox
# ---------------------------------------------------------------------------


def test_rd_bbox_is_square_and_centred():
    min_x, min_y, max_x, max_y = rd_bbox(100_000.0, 400_000.0, 40.0)
    assert (min_x, min_y, max_x, max_y) == (99_960.0, 399_960.0, 100_040.0, 400_040.0)
    assert (max_x - min_x) == (max_y - min_y) == 80.0


# ---------------------------------------------------------------------------
# build_getmap_url
# ---------------------------------------------------------------------------


def test_build_getmap_url_has_wms_params(monkeypatch):
    monkeypatch.delenv("LUCHTFOTO_WMS_URL", raising=False)
    url = build_getmap_url(_NODE, radius_m=40.0, image_px=512)
    base, _, query = url.partition("?")
    assert base == "https://service.pdok.nl/hwh/luchtfotorgb/wms/v1_0"
    params = urllib.parse.parse_qs(query)
    assert params["REQUEST"] == ["GetMap"]
    assert params["SERVICE"] == ["WMS"]
    assert params["VERSION"] == ["1.3.0"]
    assert params["CRS"] == ["EPSG:28992"]
    assert params["LAYERS"] == [DEFAULT_LAYER]
    assert params["FORMAT"] == ["image/jpeg"]
    assert params["WIDTH"] == ["512"]
    assert params["HEIGHT"] == ["512"]


def test_build_getmap_url_bbox_matches_rd_projection():
    url = build_getmap_url(_NODE, radius_m=40.0, image_px=256)
    params = urllib.parse.parse_qs(url.partition("?")[2])
    x, y = wgs84_to_rd(lon=_NODE[0], lat=_NODE[1])
    expected = rd_bbox(x, y, 40.0)
    got = tuple(float(v) for v in params["BBOX"][0].split(","))
    assert got == pytest.approx(expected, abs=1e-3)


def test_build_getmap_url_honours_custom_layer_and_base():
    url = build_getmap_url(_NODE, layer="Actueel_ortho25", base_url="https://example.test/wms")
    assert url.startswith("https://example.test/wms?")
    assert "LAYERS=Actueel_ortho25" in url


# ---------------------------------------------------------------------------
# fetch_aerial_crop — stubbed HTTP
# ---------------------------------------------------------------------------


class _FakeResp:
    def __init__(self, body: bytes, status: int = 200, content_type: str = "image/jpeg"):
        self.body = body
        self.status = status
        self.reason = "OK"
        self.headers = {"Content-Type": content_type}

    def read(self) -> bytes:
        return self.body

    def __enter__(self):
        return self

    def __exit__(self, *_a):
        return False


def test_fetch_aerial_crop_returns_bytes(monkeypatch):
    jpeg = b"\xff\xd8\xff\xe0JFIFdata"

    def _fake_urlopen(_req, timeout=0):  # noqa: ARG001
        return _FakeResp(jpeg)

    monkeypatch.setattr("urllib.request.urlopen", _fake_urlopen)
    out = fetch_aerial_crop(_NODE, pause=0)
    assert out == jpeg


def test_fetch_aerial_crop_rejects_non_image(monkeypatch):
    def _fake_urlopen(_req, timeout=0):  # noqa: ARG001
        return _FakeResp(b"<ServiceException/>", content_type="text/xml")

    monkeypatch.setattr("urllib.request.urlopen", _fake_urlopen)
    with pytest.raises(ValueError, match="non-image"):
        fetch_aerial_crop(_NODE, pause=0, retries=1)
