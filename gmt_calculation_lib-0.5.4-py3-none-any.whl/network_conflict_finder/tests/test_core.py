"""Unit tests for network_conflict_finder_core.

All tests use synthetic GeoJSON FeatureCollections so they run without S3,
Databricks or external geometry libraries.
"""

from __future__ import annotations

import pytest

from network_conflict_finder.core.network_conflict_finder_core import (
    _bearing_deg,
    _bearing_difference,
    _find_conflicting_links,
    _link_bearing,
    _node_link_index,
    _outgoing_flows_by_node,
    _turn_ratios_at_node,
    enrich_network_with_conflicts,
)


def _link(link_id, from_node, to_node, coords, flow24hrs: float | None = 100.0) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "flow24hrs": flow24hrs,
        },
    }


def test_bearing_north_and_east() -> None:
    assert _bearing_deg(0.0, 0.0, 0.0, 1.0) == pytest.approx(0.0, abs=0.1)
    assert _bearing_deg(0.0, 0.0, 1.0, 0.0) == pytest.approx(90.0, abs=0.1)


def test_bearing_difference_wraps() -> None:
    assert _bearing_difference(10.0, 350.0) == pytest.approx(20.0, abs=0.1)
    assert _bearing_difference(350.0, 10.0) == pytest.approx(-20.0, abs=0.1)


def test_link_bearing() -> None:
    assert _link_bearing(_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.01]])) == pytest.approx(
        0.0, abs=0.1
    )
    assert _link_bearing(_link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]])) == pytest.approx(
        90.0, abs=0.1
    )


def test_node_link_index_counts_multiple_links_per_node() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.01]]),
            _link("L2", "B", "C", [[0.0, 0.01], [0.01, 0.01]]),
            _link("L3", "A", "B", [[0.0, 0.0], [0.0, 0.01]]),
        ],
    }
    idx = _node_link_index(fc)
    assert len(idx["A"]) == 2
    assert len(idx["B"]) == 3
    assert len(idx["C"]) == 1


def test_find_conflicting_links_at_crossroads() -> None:
    """Create a 4-way intersection at B.

    Subject L1 A->B eastbound (bearing 90°). Other links ending at B:
    * L2 C->B from the north (bearing 180°) → diff +90°  → fromLeft
    * L3 D->B from the south (bearing 0°)   → diff +270° → fromRight
    * L4 E->B from the west (bearing 270°)  → diff +180° → opposite
    """
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]]),
            _link("L2", "C", "B", [[0.01, 0.01], [0.01, 0.0]]),
            _link("L3", "D", "B", [[0.01, -0.01], [0.01, 0.0]]),
            _link("L4", "E", "B", [[0.02, 0.0], [0.01, 0.0]]),
        ],
    }
    idx = _node_link_index(fc)
    right, left, opposite = _find_conflicting_links(fc["features"][0], idx)
    assert right == "L3"
    assert left == "L2"
    assert opposite == "L4"


def test_find_conflicting_links_at_oblique_angle() -> None:
    """Oblique incoming links are still classified into the correct sector.

    Subject L1 A->B eastbound (bearing 90°). Other links ending at B:
    * L2 C->B from north-west at bearing ~147° → diff +57°  → fromLeft
    * L3 D->B from south-west at bearing ~33°  → diff +303° → fromRight
    * None from the exact opposite direction.
    """
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]]),
            _link("L2", "C", "B", [[0.005, 0.01], [0.01, 0.0]]),
            _link("L3", "D", "B", [[0.005, -0.01], [0.01, 0.0]]),
        ],
    }
    idx = _node_link_index(fc)
    right, left, opposite = _find_conflicting_links(fc["features"][0], idx)
    assert right == "L3"
    assert left == "L2"
    assert opposite is None


def test_find_conflicting_links_only_matches_links_ending_at_node() -> None:
    """A link that leaves the node should not be considered as approaching it."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]]),
            # This link starts at B, it does not approach B.
            _link("L2", "B", "C", [[0.01, 0.01], [0.01, 0.0]]),
        ],
    }
    idx = _node_link_index(fc)
    right, left, opposite = _find_conflicting_links(fc["features"][0], idx)
    assert right is None
    assert left is None
    assert opposite is None


def test_find_conflicting_links_excludes_self() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]]),
        ],
    }
    idx = _node_link_index(fc)
    right, left, opposite = _find_conflicting_links(fc["features"][0], idx)
    assert right is None
    assert left is None
    assert opposite is None


def test_enrich_network_adds_conflict_columns() -> None:
    """East-west pair: L1 A->B; L2 C->B approaches from opposite direction."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]], flow24hrs=100.0),
            _link("L2", "C", "B", [[0.02, 0.0], [0.01, 0.0]], flow24hrs=200.0),
        ],
    }
    result = enrich_network_with_conflicts(fc)
    props = result["features"][0]["properties"]
    assert "nodeControlFrom" not in props
    assert "nodeControlTo" not in props
    assert "fromRightFlow" not in props
    assert "fromLeftFlow" not in props
    assert "oppositeFlow" not in props
    assert props["oppositeLinkId"] == "L2"
    assert "fromRightLinkId" in props
    assert "fromLeftLinkId" in props
    assert "turnLeftRatio" in props
    assert "turnRightRatio" in props


def test_enrich_network_returns_same_object() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [_link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]])],
    }
    result = enrich_network_with_conflicts(fc)
    assert result is fc


def test_enrich_network_skips_malformed_links() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [0, 0]},
                "properties": {},
            },
            _link("L1", "A", "B", [[0.0, 0.0], [0.0, 0.001]]),
        ],
    }
    result = enrich_network_with_conflicts(fc)
    # Should not raise; the single valid link gets enriched.
    assert "fromRightLinkId" in result["features"][1]["properties"]


def test_outgoing_flows_by_node_sums_outgoing_flows() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]], flow24hrs=100.0),
            _link("L2", "B", "C", [[0.01, 0.0], [0.02, 0.0]], flow24hrs=200.0),
            _link("L3", "B", "D", [[0.01, 0.0], [0.01, 0.01]], flow24hrs=300.0),
        ],
    }
    out = _outgoing_flows_by_node(fc)
    assert out["A"]["total"] == 100.0
    assert out["B"]["total"] == 500.0
    assert out["C"]["total"] == 0.0


def test_turn_ratios_at_simple_crossroads() -> None:
    """Subject A->B eastbound; outgoing links straight, left, right from B."""
    fc = {
        "type": "FeatureCollection",
        "features": [
            # Subject A->B eastbound (bearing 90°)
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]], flow24hrs=1000.0),
            # Straight B->C eastbound
            _link("L2", "B", "C", [[0.01, 0.0], [0.02, 0.0]], flow24hrs=400.0),
            # Left B->D northbound
            _link("L3", "B", "D", [[0.01, 0.0], [0.01, 0.01]], flow24hrs=300.0),
            # Right B->E southbound
            _link("L4", "B", "E", [[0.01, 0.0], [0.01, -0.01]], flow24hrs=300.0),
        ],
    }
    node_links = _node_link_index(fc)
    outgoing_flows = _outgoing_flows_by_node(fc)
    left, right = _turn_ratios_at_node(fc["features"][0], node_links, outgoing_flows)
    assert left == pytest.approx(0.3, abs=0.05)
    assert right == pytest.approx(0.3, abs=0.05)


def test_turn_ratio_names_prefixed_with_turn() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]], flow24hrs=100.0),
        ],
    }
    result = enrich_network_with_conflicts(fc)
    props = result["features"][0]["properties"]
    assert "leftTurnRatio" not in props
    assert "rightTurnRatio" not in props
    assert "turnLeftRatio" in props
    assert "turnRightRatio" in props


def test_enrich_network_adds_turn_ratio_columns() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]], flow24hrs=1000.0),
            _link("L2", "B", "C", [[0.01, 0.0], [0.02, 0.0]], flow24hrs=400.0),
            _link("L3", "B", "D", [[0.01, 0.0], [0.01, 0.01]], flow24hrs=300.0),
            _link("L4", "B", "E", [[0.01, 0.0], [0.01, -0.01]], flow24hrs=300.0),
        ],
    }
    result = enrich_network_with_conflicts(fc)
    props = result["features"][0]["properties"]
    assert "turnLeftRatio" in props
    assert "turnRightRatio" in props
    assert props["turnLeftRatio"] == pytest.approx(0.3, abs=0.05)
    assert props["turnRightRatio"] == pytest.approx(0.3, abs=0.05)


def test_turn_ratios_zero_when_no_outgoing_flow() -> None:
    fc = {
        "type": "FeatureCollection",
        "features": [
            _link("L1", "A", "B", [[0.0, 0.0], [0.01, 0.0]], flow24hrs=100.0),
        ],
    }
    result = enrich_network_with_conflicts(fc)
    props = result["features"][0]["properties"]
    assert props["turnLeftRatio"] == 0.0
    assert props["turnRightRatio"] == 0.0
