"""Local debug runner for network_conflict_finder.

Calls ``enrich_network_with_conflicts`` directly — no Lambda handler involved.

Usage
-----
    python -m network_conflict_finder.network_conflict_finder_runner \
        --network-uri input/network.geojson \
        --output-uri output/network.geojson

Prerequisites
-------------
AWS credentials available in the environment or a .env file (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    return Path(uri).read_bytes()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = Path(uri)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    print(f"Wrote {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Local runner for network_conflict_finder (calls core directly)."
    )
    parser.add_argument(
        "--network-uri",
        required=True,
        help="Full URI of the input network GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--output-uri",
        required=True,
        help="Full URI for the output network GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--env-file",
        default=None,
        help="Path to .env file for credentials.",
    )
    args = parser.parse_args()

    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for key, value in _read_env_file(env_file).items():
            os.environ.setdefault(key, value)

    from network_conflict_finder.core.network_conflict_finder_core import (
        enrich_network_with_conflicts,
    )

    print(f"Reading  : {args.network_uri}")
    network_fc = json.loads(_read_uri(args.network_uri))

    result = enrich_network_with_conflicts(network_fc)

    print(f"Writing  : {args.output_uri}")
    _write_uri(args.output_uri, json.dumps(result, ensure_ascii=False).encode("utf-8"))
    print("Done.")


if __name__ == "__main__":
    main()
