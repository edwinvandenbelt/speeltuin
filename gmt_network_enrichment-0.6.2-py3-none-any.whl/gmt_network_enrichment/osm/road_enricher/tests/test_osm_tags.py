"""Unit tests for OSM tag interpretation."""

from __future__ import annotations

import pytest

from gmt_network_enrichment.osm.road_enricher.core.osm_tags import (
    carriageway_attributes,
    cycleway_sides,
    is_carriageway,
    is_oneway,
    parking_sides,
    parse_int,
    parse_maxspeed,
    parse_width_m,
    separate_way_kind,
    sidewalk_sides,
)


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("50", 50),
        ("30 mph", 48),
        ("NL:urban", 50),
        ("NL:rural", 80),
        ("walk", 6),
        ("none", None),
        ("signals", None),
        (None, None),
    ],
)
def test_parse_maxspeed(value, expected):
    assert parse_maxspeed(value) == expected


def test_parse_int_and_width():
    assert parse_int("2;3") == 2
    assert parse_int("x") is None
    assert parse_width_m("5,5 m") == 5.5
    assert parse_width_m("7") == 7.0
    assert parse_width_m("12'") is None


def test_maxspeed_falls_back_to_zone_type():
    attrs = carriageway_attributes({"highway": "unclassified", "maxspeed:type": "NL:rural"}, True)
    assert attrs["osmMaxspeed"] == 80


def test_is_oneway():
    assert is_oneway({"oneway": "yes"})
    assert is_oneway({"oneway": "-1"})
    assert is_oneway({"junction": "roundabout"})
    assert is_oneway({"highway": "motorway"})
    assert not is_oneway({"highway": "motorway", "oneway": "no"})
    assert not is_oneway({"highway": "residential"})


@pytest.mark.parametrize(
    ("tags", "expected"),
    [
        ({"sidewalk": "both"}, ("yes", "yes")),
        ({"sidewalk": "left"}, ("yes", "no")),
        ({"sidewalk": "none"}, ("no", "no")),
        ({"sidewalk": "separate"}, ("separate", "separate")),
        ({"sidewalk:both": "separate"}, ("separate", "separate")),
        ({"sidewalk": "both", "sidewalk:right": "no"}, ("yes", "no")),
        ({}, (None, None)),
    ],
)
def test_sidewalk_sides(tags, expected):
    assert sidewalk_sides(tags) == expected


@pytest.mark.parametrize(
    ("tags", "expected"),
    [
        ({"cycleway": "lane"}, ("lane", "lane")),
        ({"cycleway:both": "shared_lane"}, ("shared_lane", "shared_lane")),
        ({"cycleway:right": "track"}, (None, "track")),
        ({"cycleway": "opposite_lane"}, ("lane", None)),
        ({"cycleway:left": "separate"}, ("track", None)),
        ({"cycleway": "no", "cycleway:left": "lane"}, ("lane", "no")),
    ],
)
def test_cycleway_sides(tags, expected):
    assert cycleway_sides(tags) == expected


def test_parking_new_scheme_wins_over_deprecated():
    assert parking_sides({"parking:lane:both": "parallel"}) == ("lane", "lane")
    assert parking_sides({"parking:lane:right": "no_stopping"}) == (None, "no")
    assert parking_sides({"parking:both": "street_side", "parking:lane:both": "parallel"}) == (
        "street_side",
        "street_side",
    )


def test_way_classification():
    assert is_carriageway({"highway": "residential"})
    assert not is_carriageway({"highway": "cycleway"})
    assert not is_carriageway({})
    assert separate_way_kind({"highway": "cycleway"}) == "cycleway"
    assert separate_way_kind({"highway": "path", "bicycle": "designated"}) == "cycleway"
    assert separate_way_kind({"highway": "footway", "footway": "sidewalk"}) == "sidewalk"
    assert separate_way_kind({"highway": "footway", "footway": "crossing"}) is None
    assert separate_way_kind({"highway": "cycleway", "cycleway": "crossing"}) is None


def test_attributes_against_way_direction_swap_sides():
    tags = {"highway": "residential", "sidewalk": "left", "maxspeed:forward": "50"}
    same = carriageway_attributes(tags, True)
    against = carriageway_attributes(tags, False)
    assert (same["sidewalkLeft"], same["sidewalkRight"]) == ("yes", "no")
    assert (against["sidewalkLeft"], against["sidewalkRight"]) == ("no", "yes")
    assert same["osmMaxspeed"] == 50
    assert "osmMaxspeed" not in against
