"""Road attribute enricher: most likely OSM road properties per wegvak."""

from __future__ import annotations

from gmt_network_enrichment.osm.road_enricher.core.road_enricher_core import (
    OUTPUT_COLUMNS,
    enrich_network_with_road_attributes,
    fetch_osm_road_ways,
    network_bbox,
)

__all__ = [
    "OUTPUT_COLUMNS",
    "enrich_network_with_road_attributes",
    "fetch_osm_road_ways",
    "network_bbox",
]
