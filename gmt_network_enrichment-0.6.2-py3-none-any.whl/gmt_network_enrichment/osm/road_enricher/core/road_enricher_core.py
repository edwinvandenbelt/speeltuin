"""Enrich network links with the most likely OSM road attributes.

Adds per-link columns (``None`` when OSM has no information):

| Column | Type | Meaning |
|---|---|---|
| ``surface`` | str | Raw OSM ``surface`` (``asphalt``, ``paving_stones``, ...) |
| ``surfaceConfidence`` | float | Share (0-1) of the winning surface in the matched length |
| ``smoothness`` | str | Raw OSM ``smoothness`` |
| ``lit`` | str | Raw OSM ``lit`` (``yes`` / ``no`` / ...) |
| ``osmHighway`` / ``osmName`` / ``osmRef`` | str | OSM classification, name, road number |
| ``osmWidth`` | float | Carriageway width (m) |
| ``osmLanes`` | int | Total number of lanes |
| ``osmOneway`` | bool | One-way road (explicit or implied) |
| ``osmMaxspeed`` | int | Speed limit (km/h) in the link's driving direction |
| ``osmLanesInDirection`` | int | Lanes in the link's driving direction (when derivable) |
| ``busway`` | str | Bus lane for this driving direction (``lane`` / ``no`` / ...) |
| ``parkingLeft`` / ``parkingRight`` | str | On-street parking per side of the link |
| ``sidewalkLeft`` / ``sidewalkRight`` | str | ``yes`` / ``no`` / ``separate`` per side of the link |
| ``cyclewayLeft`` / ``cyclewayRight`` | str | ``lane`` / ``track`` / ``shared_lane`` / ``no`` / ... per side |
| ``osmMatchRatio`` | float | Matched OSM carriageway length / link length (0-1) |

Left / right are seen in the driving direction of the (directed) link.

Matching
--------
*Carriageways* (OSM ``highway`` ways for motor traffic) are compared against each
link in a local metric projection.  Only the part of a way inside a flat-capped
buffer of ``buffer_m`` around the link counts, and each clipped segment must run
roughly parallel to the link (``max_angle_deg``).  The surviving length is the
vote weight for every attribute that way carries.  Whether the way runs with or
against the link decides how ``:forward`` / ``:backward`` and ``:left`` /
``:right`` tags map onto the link.

*Separately mapped* sidewalks (``footway=sidewalk``) and cycle tracks
(``highway=cycleway``) within ``side_buffer_m`` are cut into short pieces; each
parallel piece is assigned to the nearest network link, on the side where it
lies, unless another OSM carriageway is clearly closer (then it belongs to that
road).  When such pieces cover at least ``separate_min_ratio`` of a side, that
side becomes ``separate`` (sidewalk) / ``track`` (cycleway).

Aggregation
-----------
Votes are summed per wegvak (``wvkIds``); direction-dependent attributes per
wegvak *and* direction (heen / terug).  The winner is written to every link of
the group.  Links without ``wvkIds`` use their own votes.

OSM data comes exclusively from local Geofabrik ``.osm.pbf`` extracts
(:mod:`gmt_shared.geofabrik`); there is no Overpass connection.  Only
:func:`fetch_osm_road_ways` does I/O.
"""

from __future__ import annotations

import logging
import math
from collections import defaultdict
from dataclasses import dataclass, field
from itertools import pairwise
from typing import TYPE_CHECKING, Any

from gmt_network_enrichment.osm.road_enricher.core.osm_tags import (
    ALL_ATTRS,
    DIRECTED_ATTRS,
    UNDIRECTED_ATTRS,
    carriageway_attributes,
    is_carriageway,
    separate_way_kind,
)

if TYPE_CHECKING:
    from collections.abc import Iterable

logger = logging.getLogger(__name__)

_DEFAULT_BUFFER_M = 10.0
_DEFAULT_SIDE_BUFFER_M = 25.0
_DEFAULT_MAX_ANGLE_DEG = 30.0
_DEFAULT_SEPARATE_MIN_RATIO = 0.3

#: Length (m) of the pieces separately mapped paths are cut into.
_PIECE_M = 10.0
#: A competing carriageway must be this much (m) closer to take a path piece.
_COMPETITOR_MARGIN_M = 3.0
#: Links within this distance (m) of the nearest one share a path piece
#: (the heen / terug twins of a two-way road have identical geometry).
_TWIN_TOLERANCE_M = 0.5

#: Mean earth metres per degree latitude (local equirectangular projection).
_M_PER_DEG = 111_320.0

#: Value written for a side covered by a separately mapped path.
_SEPARATE_VALUE: dict[str, str] = {"sidewalk": "separate", "cycleway": "track"}

_DIAGNOSTIC_COLUMNS: tuple[str, ...] = ("surfaceConfidence", "osmMatchRatio")
OUTPUT_COLUMNS: tuple[str, ...] = ALL_ATTRS + _DIAGNOSTIC_COLUMNS


# ---------------------------------------------------------------------------
# OSM source: local Geofabrik .osm.pbf extracts (no Overpass server)
# ---------------------------------------------------------------------------


def road_query_for_bbox(bbox: list[float]) -> str:
    """Build the QL selector for all ``highway`` ways in *bbox*.

    The local PBF backend (:mod:`gmt_shared._osm_pbf`) evaluates this Overpass
    QL subset; no Overpass server is contacted.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    """
    min_lon, min_lat, max_lon, max_lat = bbox
    # QL uses (south, west, north, east) coordinate order.
    coord_str = f"{min_lat},{min_lon},{max_lat},{max_lon}"
    return f'[out:json];(way["highway"]({coord_str}););out geom;'


def fetch_osm_road_ways(
    network_fc: dict,
    *,
    cache_dir: str | None = None,
    osm_workers: int | None = None,
) -> list[dict]:
    """Fetch all OSM ``highway`` ways for the area of *network_fc*.

    The smallest Geofabrik extracts that together cover all links are
    downloaded (or taken from the cache); when the network straddles two
    extracts, both are read.  Elements are merged and deduplicated by
    ``(type, id)``.

    Returns the elements in Overpass ``out geom`` format.
    """
    from gmt_shared import _osm_pbf
    from gmt_shared.geofabrik import resolve_pbf_paths

    bbox = network_bbox(network_fc)
    geometry = network_geometry(network_fc)
    if bbox is None or geometry is None:
        return []

    query = road_query_for_bbox(bbox)
    merged: dict[tuple[str, Any], dict] = {}
    for pbf_path in resolve_pbf_paths(geometry, cache_dir=cache_dir):
        print(f"  [PBF] scanning {pbf_path.name}")
        data = _osm_pbf.fetch_from_pbf(query, pbf_path, workers=osm_workers)
        for elem in data.get("elements") or []:
            merged.setdefault((elem.get("type", ""), elem.get("id")), elem)
    elements = list(merged.values())
    logger.info("Fetched %d OSM highway elements.", len(elements))
    return elements


def network_bbox(network_fc: dict) -> list[float] | None:
    """Return ``[minLon, minLat, maxLon, maxLat]`` of all link geometries."""
    xs: list[float] = []
    ys: list[float] = []
    for feat in network_fc.get("features") or []:
        for x, y in _iter_coords(feat.get("geometry") or {}):
            xs.append(x)
            ys.append(y)
    if not xs:
        return None
    return [min(xs), min(ys), max(xs), max(ys)]


def network_geometry(network_fc: dict):
    """Return all link geometries as one shapely MultiLineString (WGS-84)."""
    from shapely.geometry import MultiLineString

    lines: list[list[tuple[float, float]]] = []
    for feat in network_fc.get("features") or []:
        geom = feat.get("geometry") or {}
        coords = geom.get("coordinates") or []
        parts = [coords] if geom.get("type") == "LineString" else []
        if geom.get("type") == "MultiLineString":
            parts = coords
        for part in parts:
            pts = [(float(c[0]), float(c[1])) for c in part]
            if len(pts) >= 2:
                lines.append(pts)
    return MultiLineString(lines) if lines else None


# ---------------------------------------------------------------------------
# Geometry helpers
# ---------------------------------------------------------------------------


def _iter_coords(geom: dict) -> Iterable[tuple[float, float]]:
    gtype = geom.get("type")
    coords = geom.get("coordinates") or []
    if gtype == "LineString":
        for c in coords:
            yield float(c[0]), float(c[1])
    elif gtype == "MultiLineString":
        for part in coords:
            for c in part:
                yield float(c[0]), float(c[1])


class _LocalProjection:
    """Equirectangular projection to metres around a reference latitude."""

    def __init__(self, lat0: float) -> None:
        self._kx = _M_PER_DEG * math.cos(math.radians(lat0))
        self._ky = _M_PER_DEG

    def point(self, lon: float, lat: float) -> tuple[float, float]:
        return lon * self._kx, lat * self._ky


def _link_geometry(feature: dict, proj: _LocalProjection):
    from shapely.geometry import LineString, MultiLineString

    geom = feature.get("geometry") or {}
    coords = geom.get("coordinates") or []
    if geom.get("type") == "LineString":
        pts = [proj.point(float(c[0]), float(c[1])) for c in coords]
        line = LineString(pts) if len(pts) >= 2 else None
    elif geom.get("type") == "MultiLineString":
        parts = [[proj.point(float(c[0]), float(c[1])) for c in part] for part in coords]
        parts = [p for p in parts if len(p) >= 2]
        line = MultiLineString(parts) if parts else None
    else:
        line = None
    return line if line is not None and line.length > 0.0 else None


def _iter_segments(geom) -> Iterable[tuple[tuple[float, float], tuple[float, float]]]:
    """Yield 2-point segments of a (multi)line / geometry collection."""
    if geom.is_empty:
        return
    gtype = geom.geom_type
    if gtype == "LineString":
        coords = list(geom.coords)
        for a, b in pairwise(coords):
            yield (a[0], a[1]), (b[0], b[1])
    elif gtype in ("MultiLineString", "GeometryCollection"):
        for part in geom.geoms:
            yield from _iter_segments(part)


def _direction_at(line, point) -> tuple[float, float, float] | None:
    """``(distance_along, ux, uy)``: unit direction of *line* nearest to *point*."""
    d = line.project(point)
    p0 = line.interpolate(max(d - 1.0, 0.0))
    p1 = line.interpolate(min(d + 1.0, line.length))
    dx, dy = p1.x - p0.x, p1.y - p0.y
    norm = math.hypot(dx, dy)
    if norm == 0.0:
        return None
    return d, dx / norm, dy / norm


# ---------------------------------------------------------------------------
# OSM way preparation
# ---------------------------------------------------------------------------


@dataclass
class _Way:
    tags: dict
    line: Any
    _attrs: dict[bool, dict[str, Any]] = field(default_factory=dict)

    def attrs(self, same_dir: bool) -> dict[str, Any]:
        if same_dir not in self._attrs:
            self._attrs[same_dir] = carriageway_attributes(self.tags, same_dir)
        return self._attrs[same_dir]


def _prepare_ways(
    elements: Iterable[dict], proj: _LocalProjection
) -> tuple[list[_Way], list[tuple[str, Any]]]:
    """Split OSM elements into carriageways and separately mapped paths."""
    from shapely.geometry import LineString

    carriageways: list[_Way] = []
    separate: list[tuple[str, Any]] = []
    for elem in elements:
        if elem.get("type") != "way":
            continue
        tags = elem.get("tags") or {}
        pts = [
            proj.point(float(p["lon"]), float(p["lat"]))
            for p in elem.get("geometry") or []
            if "lon" in p and "lat" in p
        ]
        if len(pts) < 2:
            continue
        line = LineString(pts)
        if line.length <= 0.0:
            continue
        if is_carriageway(tags):
            carriageways.append(_Way(tags, line))
            continue
        kind = separate_way_kind(tags)
        if kind is not None:
            separate.append((kind, line))
    return carriageways, separate


# ---------------------------------------------------------------------------
# Matching
# ---------------------------------------------------------------------------


@dataclass
class _LinkEvidence:
    length: float = 0.0
    matched_m: float = 0.0
    votes: dict[str, dict[Any, float]] = field(
        default_factory=lambda: defaultdict(lambda: defaultdict(float))
    )
    #: ``(kind, side) -> metres`` of separately mapped paths.
    separate: dict[tuple[str, str], float] = field(default_factory=lambda: defaultdict(float))


def _match_carriageways(
    link, ways: list[_Way], tree, evidence: _LinkEvidence, buffer_m: float, min_cos: float
) -> None:
    from shapely.geometry import Point

    link_buffer = link.buffer(buffer_m, cap_style="flat")
    weights: dict[tuple[int, bool], float] = defaultdict(float)
    for idx in tree.query(link_buffer, predicate="intersects"):
        clipped = ways[int(idx)].line.intersection(link_buffer)
        for (x0, y0), (x1, y1) in _iter_segments(clipped):
            seg_len = math.hypot(x1 - x0, y1 - y0)
            if seg_len <= 0.0:
                continue
            direction = _direction_at(link, Point((x0 + x1) / 2.0, (y0 + y1) / 2.0))
            if direction is None:
                continue
            _, ux, uy = direction
            cos = ((x1 - x0) * ux + (y1 - y0) * uy) / seg_len
            if abs(cos) >= min_cos:
                weights[(int(idx), cos > 0.0)] += seg_len

    for (idx, same_dir), weight in weights.items():
        evidence.matched_m += weight
        for attr, value in ways[idx].attrs(same_dir).items():
            evidence.votes[attr][value] += weight


def _match_separate_paths(
    separate: list[tuple[str, Any]],
    links: list[Any],
    link_tree,
    carriageways: list[_Way],
    way_tree,
    evidences: list[_LinkEvidence],
    *,
    buffer_m: float,
    side_buffer_m: float,
    min_cos: float,
) -> None:
    """Assign pieces of separately mapped paths to the nearest link side."""
    import shapely
    from shapely.geometry import Point

    for kind, line in separate:
        pieces = shapely.segmentize(line, _PIECE_M)
        for (x0, y0), (x1, y1) in _iter_segments(pieces):
            piece_len = math.hypot(x1 - x0, y1 - y0)
            if piece_len <= 0.0:
                continue
            mid = Point((x0 + x1) / 2.0, (y0 + y1) / 2.0)
            px, py = (x1 - x0) / piece_len, (y1 - y0) / piece_len

            candidates: list[tuple[float, int, float, float, float]] = []
            for t_idx in link_tree.query(mid.buffer(side_buffer_m), predicate="intersects"):
                link_idx = int(t_idx)
                link = links[link_idx]
                dist = link.distance(mid)
                if dist > side_buffer_m:
                    continue
                direction = _direction_at(link, mid)
                if direction is None:
                    continue
                along, ux, uy = direction
                if along <= 0.0 or along >= link.length:
                    continue  # beside the link's end, not along it
                if abs(px * ux + py * uy) < min_cos:
                    continue
                candidates.append((dist, link_idx, along, ux, uy))
            if not candidates:
                continue

            d_min = min(c[0] for c in candidates)
            if _closer_competitor(
                mid,
                d_min,
                links[min(candidates)[1]],
                carriageways,
                way_tree,
                buffer_m=buffer_m,
                min_cos=min_cos,
                direction=(px, py),
            ):
                continue

            for dist, link_idx, along, ux, uy in candidates:
                if dist > d_min + _TWIN_TOLERANCE_M:
                    continue
                foot = links[link_idx].interpolate(along)
                cross = ux * (mid.y - foot.y) - uy * (mid.x - foot.x)
                side = "Left" if cross > 0.0 else "Right"
                evidences[link_idx].separate[(kind, side)] += piece_len


def _closer_competitor(
    mid,
    d_link: float,
    link,
    carriageways: list[_Way],
    way_tree,
    *,
    buffer_m: float,
    min_cos: float,
    direction: tuple[float, float],
) -> bool:
    """True when an OSM carriageway other than the link's own road is clearly closer."""
    reach = d_link - _COMPETITOR_MARGIN_M
    if reach <= 0.0:
        return False
    foot = link.interpolate(link.project(mid))
    for idx in way_tree.query(mid.buffer(reach), predicate="intersects"):
        way = carriageways[int(idx)].line
        if way.distance(mid) >= reach:
            continue
        if way.distance(foot) <= buffer_m:
            continue  # this is the link's own road
        way_dir = _direction_at(way, mid)
        if way_dir is None:
            continue
        if abs(direction[0] * way_dir[1] + direction[1] * way_dir[2]) >= min_cos:
            return True
    return False


# ---------------------------------------------------------------------------
# Aggregation
# ---------------------------------------------------------------------------


def _wvk_ids(props: dict) -> list:
    wvk_ids = props.get("wvkIds") or []
    if not isinstance(wvk_ids, (list, tuple)):
        wvk_ids = [wvk_ids]
    return [w for w in wvk_ids if w is not None and w != ""]


def _is_reverse(props: dict) -> bool:
    """True for the terug half of a bidirectional pair (negative ``linkId``)."""
    if not props.get("reverseLinkIds"):
        return False
    link_id = props.get("linkId")
    if isinstance(link_id, str):
        return link_id.strip().startswith("-")
    return isinstance(link_id, (int, float)) and link_id < 0


def _pick(votes: dict[Any, float]) -> tuple[Any, float | None]:
    """Return ``(winner, confidence)``; ties resolve on the string value."""
    total = sum(votes.values())
    if total <= 0.0:
        return None, None
    winner = min(votes, key=lambda v: (-votes[v], str(v)))
    return winner, round(votes[winner] / total, 3)


@dataclass
class _Group:
    length: float = 0.0
    matched_m: float = 0.0
    votes: dict[str, dict[Any, float]] = field(
        default_factory=lambda: defaultdict(lambda: defaultdict(float))
    )
    separate: dict[tuple[str, str], float] = field(default_factory=lambda: defaultdict(float))

    def add(self, ev: _LinkEvidence, attrs: Iterable[str]) -> None:
        self.length += ev.length
        self.matched_m += ev.matched_m
        for attr in attrs:
            for value, weight in ev.votes.get(attr, {}).items():
                self.votes[attr][value] += weight
        for key, metres in ev.separate.items():
            self.separate[key] += metres

    @staticmethod
    def merged(groups: list[_Group]) -> _Group:
        """Sum of *groups* (a link spanning several wegvakken)."""
        if len(groups) == 1:
            return groups[0]
        total = _Group()
        for group in groups:
            total.length += group.length
            total.matched_m += group.matched_m
            for attr, votes in group.votes.items():
                for value, weight in votes.items():
                    total.votes[attr][value] += weight
            for key, metres in group.separate.items():
                total.separate[key] += metres
        return total


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def enrich_network_with_road_attributes(
    network_fc: dict,
    *,
    osm_elements: Iterable[dict],
    buffer_m: float = _DEFAULT_BUFFER_M,
    side_buffer_m: float = _DEFAULT_SIDE_BUFFER_M,
    max_angle_deg: float = _DEFAULT_MAX_ANGLE_DEG,
    separate_min_ratio: float = _DEFAULT_SEPARATE_MIN_RATIO,
) -> tuple[dict, dict]:
    """Set the OSM road attribute columns on every link of *network_fc*.

    Parameters
    ----------
    network_fc:
        Directed network FeatureCollection (WGS-84).  Modified in place.
    osm_elements:
        Overpass ``out geom`` elements, e.g. from :func:`fetch_osm_road_ways`.
    buffer_m:
        Max lateral distance between link and OSM carriageway.
    side_buffer_m:
        Max lateral distance between link and a separately mapped sidewalk /
        cycle track.
    max_angle_deg:
        Max angle between link and OSM way segment to count as parallel.
    separate_min_ratio:
        Min share of a side's length covered by a separately mapped path to set
        that side to ``separate`` / ``track``.

    Returns
    -------
    network_fc, stats
        ``stats`` = ``{"links", "wegvakken", "matched", "filled": {column: n}}``.
    """
    from shapely import STRtree

    features = network_fc.get("features") or []
    for feat in features:
        props = feat.setdefault("properties", {})
        for col in OUTPUT_COLUMNS:
            props[col] = None

    stats: dict[str, Any] = {
        "links": len(features),
        "wegvakken": 0,
        "matched": 0,
        "filled": dict.fromkeys(OUTPUT_COLUMNS, 0),
    }
    bbox = network_bbox(network_fc)
    if bbox is None:
        return network_fc, stats

    proj = _LocalProjection((bbox[1] + bbox[3]) / 2.0)
    carriageways, separate = _prepare_ways(osm_elements, proj)
    min_cos = math.cos(math.radians(max_angle_deg))

    # 1. Evidence per link.
    links = [_link_geometry(feat, proj) for feat in features]
    evidences = [_LinkEvidence(length=line.length if line else 0.0) for line in links]
    way_tree = STRtree([w.line for w in carriageways]) if carriageways else None
    if way_tree is not None:
        for line, evidence in zip(links, evidences, strict=True):
            if line is not None:
                _match_carriageways(line, carriageways, way_tree, evidence, buffer_m, min_cos)

    valid = [i for i, line in enumerate(links) if line is not None]
    if separate and valid:
        link_tree = STRtree([links[i] for i in valid])
        valid_links = [links[i] for i in valid]
        valid_evidences = [evidences[i] for i in valid]
        _match_separate_paths(
            separate,
            valid_links,
            link_tree,
            carriageways,
            way_tree if way_tree is not None else STRtree([]),
            valid_evidences,
            buffer_m=buffer_m,
            side_buffer_m=side_buffer_m,
            min_cos=min_cos,
        )

    # 2. Aggregate per wegvak (undirected) and per wegvak + direction (directed).
    und_groups: dict[Any, _Group] = defaultdict(_Group)
    dir_groups: dict[Any, _Group] = defaultdict(_Group)
    keys: list[tuple[Any, Any]] = []
    for i, (feat, evidence) in enumerate(zip(features, evidences, strict=True)):
        props = feat["properties"]
        wvk_ids = _wvk_ids(props)
        reverse = _is_reverse(props)
        und_keys = [("wvk", w) for w in wvk_ids] or [("link", i)]
        for key in und_keys:
            und_groups[key].add(evidence, UNDIRECTED_ATTRS)
            dir_groups[(key, reverse)].add(evidence, DIRECTED_ATTRS)
        keys.append((und_keys, reverse))
    stats["wegvakken"] = sum(1 for k in und_groups if k[0] == "wvk")

    # 3. Write results.
    for feat, evidence, (und_keys, reverse) in zip(features, evidences, keys, strict=True):
        props = feat["properties"]
        # A link spanning several wegvakken (aggregated network) votes over all of them.
        und = _Group.merged([und_groups[k] for k in und_keys])
        drc = _Group.merged([dir_groups[(k, reverse)] for k in und_keys])

        for attr in UNDIRECTED_ATTRS:
            value, confidence = _pick(und.votes.get(attr, {}))
            props[attr] = value
            if attr == "surface":
                props["surfaceConfidence"] = confidence
        for attr in DIRECTED_ATTRS:
            props[attr] = _pick(drc.votes.get(attr, {}))[0]
        for kind, value in _SEPARATE_VALUE.items():
            for side in ("Left", "Right"):
                if drc.length > 0.0 and (
                    drc.separate.get((kind, side), 0.0) / drc.length >= separate_min_ratio
                ):
                    props[f"{kind}{side}"] = value

        if evidence.length > 0.0:
            props["osmMatchRatio"] = round(min(1.0, evidence.matched_m / evidence.length), 3)
        if evidence.matched_m > 0.0:
            stats["matched"] += 1
        for col in OUTPUT_COLUMNS:
            if props[col] is not None:
                stats["filled"][col] += 1

    logger.info(
        "Road attributes: %d/%d links matched (%d wegvakken, %d carriageways, %d paths).",
        stats["matched"],
        len(features),
        stats["wegvakken"],
        len(carriageways),
        len(separate),
    )
    return network_fc, stats
