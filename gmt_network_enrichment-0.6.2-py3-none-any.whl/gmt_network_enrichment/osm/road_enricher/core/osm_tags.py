"""Interpretation of OSM road tags into link attributes.

Pure functions, no geometry.  Side- and direction-dependent tags are expressed
relative to the OSM way; :func:`carriageway_attributes` translates them to the
driving direction of a network link via ``same_dir`` (link runs in the same
direction as the OSM way).

Output vocabularies follow OSM where possible:

* sidewalk: ``yes`` / ``no`` / ``separate``
* cycleway: ``lane`` / ``track`` (incl. separately mapped) / ``shared_lane`` /
  ``share_busway`` / ``no`` / other raw
* parking (new ``parking:<side>`` scheme): ``lane`` / ``street_side`` / ``on_kerb`` /
  ``half_on_kerb`` / ``shoulder`` / ``separate`` / ``no`` / other raw
* busway: ``lane`` / ``no`` / other raw
"""

from __future__ import annotations

import re
from typing import Any

#: OSM ``highway`` values that are not carriageways for motorised traffic.
NON_CARRIAGEWAY_HIGHWAYS: frozenset[str] = frozenset(
    {
        "footway",
        "cycleway",
        "path",
        "steps",
        "pedestrian",
        "bridleway",
        "corridor",
        "platform",
        "proposed",
        "construction",
        "abandoned",
        "razed",
        "elevator",
        "bus_stop",
        "services",
        "rest_area",
        "raceway",
    }
)

_YES = frozenset({"yes", "true", "1"})

#: Implicit speed limits (km/h) for ``<country>:<zone>`` maxspeed values.
_ZONE_MAXSPEED: dict[str, int] = {
    "NL:urban": 50,
    "NL:rural": 80,
    "NL:motorway": 130,
    "NL:trunk": 100,
    "NL:living_street": 15,
    "NL:zone30": 30,
    "BE:urban": 50,
    "BE-VLG:rural": 70,
    "BE-WAL:rural": 90,
    "BE:motorway": 120,
    "BE:living_street": 20,
    "BE:zone30": 30,
    "DE:urban": 50,
    "DE:rural": 100,
    "DE:living_street": 7,
    "DE:zone30": 30,
}

_NUMBER_RE = re.compile(r"^\s*(\d+(?:[.,]\d+)?)\s*(mph|km/h|kmh|kph|m|meter|metre)?\s*$")


# ---------------------------------------------------------------------------
# Scalar parsers
# ---------------------------------------------------------------------------


def parse_maxspeed(value: str | None) -> int | None:
    """Parse an OSM ``maxspeed`` value to km/h (``None`` when unknown)."""
    if not value:
        return None
    value = value.strip()
    if value in _ZONE_MAXSPEED:
        return _ZONE_MAXSPEED[value]
    if value == "walk":
        return 6
    match = _NUMBER_RE.match(value)
    if not match:
        return None
    speed = float(match.group(1).replace(",", "."))
    if match.group(2) == "mph":
        speed *= 1.609344
    return round(speed)


def parse_int(value: str | None) -> int | None:
    """Parse ``"2"`` / ``"2;3"`` to the first integer."""
    if not value:
        return None
    match = re.match(r"\s*(\d+)", value)
    return int(match.group(1)) if match else None


def parse_width_m(value: str | None) -> float | None:
    """Parse ``"5.5"`` / ``"5,5 m"`` to metres; other units give ``None``."""
    if not value:
        return None
    match = _NUMBER_RE.match(value)
    if not match or match.group(2) not in (None, "m", "meter", "metre"):
        return None
    return float(match.group(1).replace(",", "."))


def is_oneway(tags: dict) -> bool:
    """True when the way is one-way for motor traffic (explicit or implied)."""
    oneway = tags.get("oneway")
    if oneway in _YES or oneway == "-1":
        return True
    if oneway == "no":
        return False
    return tags.get("junction") in ("roundabout", "circular") or tags.get("highway") == "motorway"


# ---------------------------------------------------------------------------
# Side tags (relative to the OSM way)
# ---------------------------------------------------------------------------


def _apply_side_overrides(
    key: str, tags: dict, left: str | None, right: str | None, normalise
) -> tuple[str | None, str | None]:
    both = normalise(tags.get(f"{key}:both"))
    if both is not None:
        left = right = both
    side_left = normalise(tags.get(f"{key}:left"))
    side_right = normalise(tags.get(f"{key}:right"))
    return (side_left if side_left is not None else left), (
        side_right if side_right is not None else right
    )


def _norm_sidewalk(value: str | None) -> str | None:
    if not value:
        return None
    if value in ("no", "none"):
        return "no"
    if value in ("yes", "separate"):
        return value
    return None


def sidewalk_sides(tags: dict) -> tuple[str | None, str | None]:
    """``(left, right)`` sidewalk relative to the way: yes / no / separate."""
    base = tags.get("sidewalk")
    left = right = None
    if base in ("both", "yes"):
        left = right = "yes"
    elif base == "left":
        left, right = "yes", "no"
    elif base == "right":
        left, right = "no", "yes"
    elif base in ("no", "none"):
        left = right = "no"
    elif base == "separate":
        left = right = "separate"
    return _apply_side_overrides("sidewalk", tags, left, right, _norm_sidewalk)


def _norm_cycleway(value: str | None) -> str | None:
    if not value:
        return None
    if value == "none":
        return "no"
    if value == "opposite_lane":
        return "lane"
    if value == "opposite_track":
        return "track"
    if value == "opposite":
        return None
    if value == "separate":
        return "track"  # separately mapped cycle track
    return value


def cycleway_sides(tags: dict) -> tuple[str | None, str | None]:
    """``(left, right)`` cycle infrastructure relative to the way."""
    base = tags.get("cycleway")
    left = right = None
    if base in ("opposite_lane", "opposite_track"):
        # Contraflow infrastructure on a one-way street: on the left (RHT).
        left = _norm_cycleway(base)
    elif base:
        left = right = _norm_cycleway(base)
    return _apply_side_overrides("cycleway", tags, left, right, _norm_cycleway)


_OLD_PARKING_LANE: dict[str, str] = {
    "parallel": "lane",
    "diagonal": "lane",
    "perpendicular": "lane",
    "marked": "lane",
    "yes": "lane",
    "no": "no",
    "no_parking": "no",
    "no_stopping": "no",
    "fire_lane": "no",
    "separate": "separate",
}


def _norm_parking(value: str | None) -> str | None:
    return value or None


def _norm_old_parking(value: str | None) -> str | None:
    if not value:
        return None
    return _OLD_PARKING_LANE.get(value, value)


def parking_sides(tags: dict) -> tuple[str | None, str | None]:
    """``(left, right)`` on-street parking relative to the way.

    The current ``parking:<side>`` scheme wins over the deprecated
    ``parking:lane:<side>`` scheme, which is mapped onto the new vocabulary.
    """
    old_left, old_right = _apply_side_overrides("parking:lane", tags, None, None, _norm_old_parking)
    new_left, new_right = _apply_side_overrides("parking", tags, None, None, _norm_parking)
    return (new_left or old_left), (new_right or old_right)


def busway_sides(tags: dict) -> tuple[str | None, str | None]:
    """``(left, right)`` bus lanes relative to the way."""
    base = tags.get("busway")
    left = right = None
    if base == "opposite_lane":
        left = "lane"
    elif base:
        left = right = "no" if base == "none" else base
    return _apply_side_overrides(
        "busway", tags, left, right, lambda v: ("no" if v == "none" else v) or None
    )


# ---------------------------------------------------------------------------
# Separately mapped sidewalks / cycle tracks
# ---------------------------------------------------------------------------


def separate_way_kind(tags: dict) -> str | None:
    """``"sidewalk"`` / ``"cycleway"`` for separately mapped paths, else ``None``."""
    highway = tags.get("highway")
    if highway == "cycleway" or (highway == "path" and tags.get("bicycle") == "designated"):
        if tags.get("cycleway") in ("crossing", "traffic_island"):
            return None
        return "cycleway"
    if highway in ("footway", "path") and tags.get("footway") == "sidewalk":
        return "sidewalk"
    return None


def is_carriageway(tags: dict) -> bool:
    highway = tags.get("highway")
    return bool(highway) and highway not in NON_CARRIAGEWAY_HIGHWAYS


# ---------------------------------------------------------------------------
# Per-link attribute derivation
# ---------------------------------------------------------------------------

#: Attributes that do not depend on driving direction (voted per wegvak).
UNDIRECTED_ATTRS: tuple[str, ...] = (
    "surface",
    "smoothness",
    "lit",
    "osmHighway",
    "osmName",
    "osmRef",
    "osmWidth",
    "osmLanes",
    "osmOneway",
)

#: Attributes that depend on driving direction (voted per wegvak + direction).
DIRECTED_ATTRS: tuple[str, ...] = (
    "osmMaxspeed",
    "osmLanesInDirection",
    "busway",
    "parkingLeft",
    "parkingRight",
    "sidewalkLeft",
    "sidewalkRight",
    "cyclewayLeft",
    "cyclewayRight",
)

ALL_ATTRS: tuple[str, ...] = UNDIRECTED_ATTRS + DIRECTED_ATTRS


def _oriented(sides: tuple[Any, Any], same_dir: bool) -> tuple[Any, Any]:
    """Way ``(left, right)`` to link ``(left, right)``."""
    return sides if same_dir else (sides[1], sides[0])


def _lanes_in_direction(tags: dict, same_dir: bool) -> int | None:
    lanes = parse_int(tags.get("lanes:forward" if same_dir else "lanes:backward"))
    if lanes is not None:
        return lanes
    oneway = tags.get("oneway")
    if oneway == "-1":
        return None if same_dir else parse_int(tags.get("lanes"))
    if is_oneway(tags):
        return parse_int(tags.get("lanes")) if same_dir else None
    return None


def carriageway_attributes(tags: dict, same_dir: bool) -> dict[str, Any]:
    """All link attributes derivable from one carriageway way (``None`` omitted)."""
    maxspeed = parse_maxspeed(tags.get("maxspeed:forward" if same_dir else "maxspeed:backward"))
    if maxspeed is None:
        maxspeed = parse_maxspeed(tags.get("maxspeed"))
    if maxspeed is None:
        maxspeed = parse_maxspeed(tags.get("maxspeed:type") or tags.get("source:maxspeed"))

    sidewalk_left, sidewalk_right = _oriented(sidewalk_sides(tags), same_dir)
    cycle_left, cycle_right = _oriented(cycleway_sides(tags), same_dir)
    parking_left, parking_right = _oriented(parking_sides(tags), same_dir)
    _, bus_right = _oriented(busway_sides(tags), same_dir)

    attrs: dict[str, Any] = {
        "surface": tags.get("surface"),
        "smoothness": tags.get("smoothness"),
        "lit": tags.get("lit"),
        "osmHighway": tags.get("highway"),
        "osmName": tags.get("name"),
        "osmRef": tags.get("ref"),
        "osmWidth": parse_width_m(tags.get("width")),
        "osmLanes": parse_int(tags.get("lanes")),
        "osmOneway": is_oneway(tags),
        "osmMaxspeed": maxspeed,
        "osmLanesInDirection": _lanes_in_direction(tags, same_dir),
        # Right-hand traffic: the bus lane for this direction is on the right.
        "busway": bus_right,
        "parkingLeft": parking_left,
        "parkingRight": parking_right,
        "sidewalkLeft": sidewalk_left,
        "sidewalkRight": sidewalk_right,
        "cyclewayLeft": cycle_left,
        "cyclewayRight": cycle_right,
    }
    return {k: v for k, v in attrs.items() if v is not None and v != ""}
