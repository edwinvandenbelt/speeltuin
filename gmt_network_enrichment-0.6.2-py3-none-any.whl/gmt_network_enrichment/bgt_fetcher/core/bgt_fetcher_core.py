"""Pure-Python bgt_fetcher core — fetches BGT speed bumps and noise screens.

Fetches asset geometry for a bounding box from the Dutch BGT
(Basisregistratie Grootschalige Topografie) via the PDOK OGC API Features
service:

* **verkeersdrempels** (speed bumps) — ``wegdeel`` features whose
  ``plus_functie`` equals ``"verkeersdrempel"``; tagged
  ``assetType = "speedBump"``.
* **voetpaden** (sidewalks) — ``wegdeel`` features whose coarse ``functie``
  equals ``"voetpad"``; tagged ``assetType = "sidewalk"``.
* **fietspaden** (bike paths) — ``wegdeel`` features whose coarse ``functie``
  equals ``"fietspad"``; tagged ``assetType = "bikePath"``.
* **verkeerseilanden** (traffic islands) — ``wegdeel`` features whose coarse
  ``functie`` equals ``"verkeerseiland"``; tagged
  ``assetType = "trafficIsland"``.
* **geluidsschermen** (noise screens) — ``scheiding_lijn`` (LineString) and
  ``scheiding_vlak`` (Polygon) features whose ``plus_type`` equals
  ``"geluidsscherm"``; tagged ``assetType = "screen"``.
* **bruggen** (bridges) — every ``overbruggingsdeel`` feature (Polygon);
  tagged ``assetType = "bridge"``.
* **tunnels** — every ``tunneldeel`` feature (Polygon); tagged
  ``assetType = "tunnel"``.
* **bakken** (street-furniture containers: zand-/zoutbakken, plantenbakken,
  afvalbakken) — every ``bak`` feature (Point); tagged ``assetType = "bak"``.

Only current object versions are fetched: superseded (historical) versions
with an ``eind_registratie`` are filtered out server-side by the shared OGC
client.  The original BGT geometry is preserved.  Results are returned as a GeoJSON
``FeatureCollection`` so they can be merged into the combined
``{area_id}-TRAFFIC-ASSETS.parquet`` produced by the prepare pipeline.

BGT does *not* register pedestrian crossings / road markings as a usable theme
(the ``weginrichtingselement`` collections only contain roosters,
geleideconstructies, etc.), so crossings are fetched from OSM by the separate
``osm_asset_fetcher`` module instead.

The service serves GeoJSON in CRS84 (WGS-84 lon/lat), so no reprojection is
needed.  BGT only covers the Netherlands: outside NL an empty collection is
returned.

Public API
----------
filter_speed_bumps(features) -> list[dict]
    Keep wegdeel features with plus_functie == "verkeersdrempel", tag speedBump.
filter_sidewalks(features) -> list[dict]
    Keep wegdeel features with functie == "voetpad", tag sidewalk.
filter_bike_paths(features) -> list[dict]
    Keep wegdeel features with functie == "fietspad", tag bikePath.
filter_traffic_islands(features) -> list[dict]
    Keep wegdeel features with functie == "verkeerseiland", tag trafficIsland.
filter_screens(features) -> list[dict]
    Keep scheiding features with plus_type == "geluidsscherm", tag screen.
tag_all(features, asset_type) -> list[dict]
    Tag every feature with the given assetType (no filtering).
fetch_bgt_assets(bbox, *, url, timeout) -> tuple[dict, dict]
    High-level entry: fetch + filter + tag, return (fc, stats).
"""

from __future__ import annotations

import logging

from gmt_shared.geo import is_netherlands

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached BGT output.
BGT_QUERY_VER: int = 6

#: Asset-type tags written on produced features.
ASSET_TYPE_SPEED_BUMP: str = "speedBump"
ASSET_TYPE_SCREEN: str = "screen"
ASSET_TYPE_BRIDGE: str = "bridge"
ASSET_TYPE_TUNNEL: str = "tunnel"
ASSET_TYPE_BAK: str = "bak"
ASSET_TYPE_SIDEWALK: str = "sidewalk"
ASSET_TYPE_BIKE_PATH: str = "bikePath"
ASSET_TYPE_TRAFFIC_ISLAND: str = "trafficIsland"

#: BGT collection ids on the PDOK OGC API Features service.
COLLECTION_WEGDEEL: str = "wegdeel"
COLLECTION_SCHEIDING_LIJN: str = "scheiding_lijn"
COLLECTION_SCHEIDING_VLAK: str = "scheiding_vlak"
COLLECTION_OVERBRUGGINGSDEEL: str = "overbruggingsdeel"
COLLECTION_TUNNELDEEL: str = "tunneldeel"
COLLECTION_BAK: str = "bak"

#: BGT wegdeel field + value identifying a speed bump.  In BGT the
#: "verkeersdrempel" classification lives in the ``plus_functie`` attribute
#: (the ``functie`` attribute only holds coarse road-part types like
#: "rijbaan lokale weg" / "voetpad").
PLUS_FUNCTIE_FIELD: str = "plus_functie"
FUNCTIE_VERKEERSDREMPEL: str = "verkeersdrempel"

#: BGT wegdeel field + value identifying a sidewalk, bike path or traffic
#: island.  Unlike speed bumps, these classifications live in the coarse
#: ``functie`` attribute itself (not ``plus_functie``) — same pattern as
#: "parkeervlak" in parking_area_fetcher_core.py.
FUNCTIE_FIELD: str = "functie"
FUNCTIE_VOETPAD: str = "voetpad"
FUNCTIE_FIETSPAD: str = "fietspad"
FUNCTIE_VERKEERSEILAND: str = "verkeerseiland"

#: BGT scheiding field + value identifying a noise screen.  The
#: "geluidsscherm" classification lives in the ``plus_type`` attribute
#: (the coarse ``type`` attribute only holds values like "hek" / "muur" /
#: "damwand").
PLUS_TYPE_FIELD: str = "plus_type"
TYPE_GELUIDSSCHERM: str = "geluidsscherm"


# ---------------------------------------------------------------------------
# Filtering / tagging
# ---------------------------------------------------------------------------


def filter_speed_bumps(features: list[dict]) -> list[dict]:
    """Return BGT ``wegdeel`` features that are speed bumps, tagged accordingly.

    Keeps features whose ``properties.plus_functie`` equals
    ``"verkeersdrempel"``.  (In BGT the coarse ``functie`` attribute only holds
    road-part types such as ``"rijbaan lokale weg"``; the speed-bump
    classification lives in the ``plus_functie`` attribute.)  The original
    polygon geometry is preserved; every kept feature is tagged
    ``properties.assetType = "speedBump"``.
    """
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        if props.get(PLUS_FUNCTIE_FIELD) != FUNCTIE_VERKEERSDREMPEL:
            continue
        new_props = {**props, "assetType": ASSET_TYPE_SPEED_BUMP}
        result.append({**feat, "properties": new_props})
    return result


def filter_sidewalks(features: list[dict]) -> list[dict]:
    """Return BGT ``wegdeel`` features that are sidewalks, tagged accordingly.

    Keeps features whose ``properties.functie`` equals ``"voetpad"``.  The
    original polygon geometry is preserved; every kept feature is tagged
    ``properties.assetType = "sidewalk"``.
    """
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        if props.get(FUNCTIE_FIELD) != FUNCTIE_VOETPAD:
            continue
        new_props = {**props, "assetType": ASSET_TYPE_SIDEWALK}
        result.append({**feat, "properties": new_props})
    return result


def filter_bike_paths(features: list[dict]) -> list[dict]:
    """Return BGT ``wegdeel`` features that are bike paths, tagged accordingly.

    Keeps features whose ``properties.functie`` equals ``"fietspad"``.  The
    original polygon geometry is preserved; every kept feature is tagged
    ``properties.assetType = "bikePath"``.
    """
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        if props.get(FUNCTIE_FIELD) != FUNCTIE_FIETSPAD:
            continue
        new_props = {**props, "assetType": ASSET_TYPE_BIKE_PATH}
        result.append({**feat, "properties": new_props})
    return result


def filter_traffic_islands(features: list[dict]) -> list[dict]:
    """Return BGT ``wegdeel`` features that are traffic islands, tagged.

    Keeps features whose ``properties.functie`` equals ``"verkeerseiland"``.
    The original polygon geometry is preserved; every kept feature is tagged
    ``properties.assetType = "trafficIsland"``.
    """
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        if props.get(FUNCTIE_FIELD) != FUNCTIE_VERKEERSEILAND:
            continue
        new_props = {**props, "assetType": ASSET_TYPE_TRAFFIC_ISLAND}
        result.append({**feat, "properties": new_props})
    return result


def filter_screens(features: list[dict]) -> list[dict]:
    """Return BGT ``scheiding`` features that are noise screens, tagged.

    Keeps features whose ``properties.plus_type`` equals ``"geluidsscherm"``.
    (In BGT the coarse ``type`` attribute only holds separation types such as
    ``"hek"`` / ``"muur"`` / ``"damwand"``; the noise-screen classification
    lives in the ``plus_type`` attribute.)  The original geometry
    (``LineString`` from ``scheiding_lijn``, ``Polygon`` from
    ``scheiding_vlak``) is preserved; every kept feature is tagged
    ``properties.assetType = "screen"``.
    """
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        if props.get(PLUS_TYPE_FIELD) != TYPE_GELUIDSSCHERM:
            continue
        new_props = {**props, "assetType": ASSET_TYPE_SCREEN}
        result.append({**feat, "properties": new_props})
    return result


def tag_all(features: list[dict], asset_type: str) -> list[dict]:
    """Tag *every* feature with ``properties.assetType = asset_type``.

    Used for BGT collections that map wholesale onto a single asset type
    (``overbruggingsdeel`` -> ``"bridge"``, ``tunneldeel`` -> ``"tunnel"``,
    ``bak`` -> ``"bak"``).  The original geometry is preserved.
    """
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        new_props = {**props, "assetType": asset_type}
        result.append({**feat, "properties": new_props})
    return result


# ---------------------------------------------------------------------------
# High-level entry point
# ---------------------------------------------------------------------------


def fetch_bgt_assets(
    bbox: list[float],
    *,
    url: str | None = None,
    timeout: int = 60,
) -> tuple[dict, dict]:
    """Fetch BGT speed bumps, noise screens, bridges, tunnels and bakken.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    url:
        OGC API Features base URL.  Defaults to the shared client default
        (``PDOK_BGT_URL`` env var or the public PDOK BGT endpoint).
    timeout:
        HTTP request timeout in seconds (per page).

    Returns
    -------
    fc:
        A GeoJSON ``FeatureCollection`` of BGT features, each tagged with an
        ``properties.assetType``: ``"speedBump"`` (wegdeel verkeersdrempels),
        ``"sidewalk"`` (wegdeel voetpaden), ``"bikePath"`` (wegdeel
        fietspaden), ``"trafficIsland"`` (wegdeel verkeerseilanden),
        ``"screen"`` (scheiding geluidsschermen), ``"bridge"``
        (overbruggingsdeel), ``"tunnel"`` (tunneldeel) and ``"bak"`` (bak
        street furniture).
    stats:
        ``{"speedBump": int, "sidewalk": int, "bikePath": int,
        "trafficIsland": int, "screen": int, "bridge": int, "tunnel": int,
        "bak": int, "total": int, "source": str}``.  ``source`` is ``"BGT"``
        or ``"skipped"`` when the bbox lies outside the Netherlands.
    """
    if not is_netherlands(bbox):
        logger.info("bbox centroid outside NL — skipping BGT fetch.")
        return (
            {
                "type": "FeatureCollection",
                "features": [],
                "properties": {"_qv": BGT_QUERY_VER, "source": "skipped"},
            },
            {
                "speedBump": 0,
                "sidewalk": 0,
                "bikePath": 0,
                "trafficIsland": 0,
                "screen": 0,
                "bridge": 0,
                "tunnel": 0,
                "bak": 0,
                "total": 0,
                "source": "skipped",
            },
        )

    from gmt_shared.ogc_features import DEFAULT_BGT_URL, fetch_collection_items

    base_url = url if url is not None else DEFAULT_BGT_URL

    raw_wegdeel = fetch_collection_items(COLLECTION_WEGDEEL, bbox, url=base_url, timeout=timeout)
    bumps = filter_speed_bumps(raw_wegdeel)
    logger.info("BGT speed bumps: %d (from %d wegdeel features)", len(bumps), len(raw_wegdeel))
    sidewalks = filter_sidewalks(raw_wegdeel)
    logger.info("BGT sidewalks: %d (from %d wegdeel features)", len(sidewalks), len(raw_wegdeel))
    bike_paths = filter_bike_paths(raw_wegdeel)
    logger.info("BGT bike paths: %d (from %d wegdeel features)", len(bike_paths), len(raw_wegdeel))
    traffic_islands = filter_traffic_islands(raw_wegdeel)
    logger.info(
        "BGT traffic islands: %d (from %d wegdeel features)", len(traffic_islands), len(raw_wegdeel)
    )

    raw_screens: list[dict] = []
    for collection in (COLLECTION_SCHEIDING_LIJN, COLLECTION_SCHEIDING_VLAK):
        raw_screens.extend(fetch_collection_items(collection, bbox, url=base_url, timeout=timeout))
    screens = filter_screens(raw_screens)
    logger.info(
        "BGT noise screens: %d (from %d scheiding features)", len(screens), len(raw_screens)
    )

    bridges = tag_all(
        fetch_collection_items(COLLECTION_OVERBRUGGINGSDEEL, bbox, url=base_url, timeout=timeout),
        ASSET_TYPE_BRIDGE,
    )
    tunnels = tag_all(
        fetch_collection_items(COLLECTION_TUNNELDEEL, bbox, url=base_url, timeout=timeout),
        ASSET_TYPE_TUNNEL,
    )
    bakken = tag_all(
        fetch_collection_items(COLLECTION_BAK, bbox, url=base_url, timeout=timeout),
        ASSET_TYPE_BAK,
    )
    logger.info("BGT bridges: %d, tunnels: %d, bakken: %d", len(bridges), len(tunnels), len(bakken))

    features = bumps + sidewalks + bike_paths + traffic_islands + screens + bridges + tunnels + bakken
    fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"_qv": BGT_QUERY_VER, "source": "BGT"},
    }
    stats = {
        "speedBump": len(bumps),
        "sidewalk": len(sidewalks),
        "bikePath": len(bike_paths),
        "trafficIsland": len(traffic_islands),
        "screen": len(screens),
        "bridge": len(bridges),
        "tunnel": len(tunnels),
        "bak": len(bakken),
        "total": len(features),
        "source": "BGT",
    }
    return fc, stats
