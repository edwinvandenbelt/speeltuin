"""Unit tests for parking_area_fetcher core (pure functions + stubbed clients)."""

from __future__ import annotations

from gmt_network_enrichment.parking_area_fetcher.core.parking_area_fetcher_core import (
    ASSET_TYPE_PARKING,
    COLLECTION_WEGDEEL,
    OVERPASS_GRID,
    PARKING_QUERY_VER,
    build_parking_query,
    fetch_parking_areas,
    filter_parking_areas,
    osm_elements_to_features,
)

# NL bbox (Lochem-ish) and a non-NL bbox (Paris).
_NL_BBOX = [6.39, 52.14, 6.43, 52.17]
_PARIS_BBOX = [2.2, 48.8, 2.4, 48.9]


def _polygon(offset: float = 0.0) -> dict:
    return {
        "type": "Polygon",
        "coordinates": [
            [
                [6.40 + offset, 52.15],
                [6.41 + offset, 52.15],
                [6.41 + offset, 52.16],
                [6.40 + offset, 52.15],
            ]
        ],
    }


def _osm_way(way_id: int, *, capacity: str | None = None) -> dict:
    tags: dict[str, str] = {"amenity": "parking"}
    if capacity is not None:
        tags["capacity"] = capacity
    return {
        "type": "way",
        "id": way_id,
        "tags": tags,
        "geometry": [
            {"lon": 6.40, "lat": 52.15},
            {"lon": 6.41, "lat": 52.15},
            {"lon": 6.41, "lat": 52.16},
        ],
    }


# ---------------------------------------------------------------------------
# filter_parking_areas (BGT)
# ---------------------------------------------------------------------------


def test_filter_parking_areas_keeps_only_parkeervlak() -> None:
    features = [
        {
            "type": "Feature",
            "geometry": _polygon(),
            "properties": {"functie": "parkeervlak", "lokaal_id": "abc"},
        },
        {
            "type": "Feature",
            "geometry": _polygon(0.02),
            "properties": {"functie": "rijbaan lokale weg"},
        },
    ]
    out = filter_parking_areas(features)
    assert len(out) == 1
    assert out[0]["properties"]["assetType"] == ASSET_TYPE_PARKING
    assert out[0]["properties"]["source"] == "BGT"
    assert out[0]["properties"]["parkingId"] == "bgt_abc"
    assert out[0]["geometry"]["type"] == "Polygon"


def test_filter_parking_areas_ignores_plus_functie() -> None:
    # "parkeervlak" must be in functie, not plus_functie.
    features = [
        {"type": "Feature", "geometry": _polygon(), "properties": {"plus_functie": "parkeervlak"}},
    ]
    assert filter_parking_areas(features) == []


# ---------------------------------------------------------------------------
# build_parking_query + osm_elements_to_features (OSM)
# ---------------------------------------------------------------------------


def test_build_parking_query_contains_parking_and_geom() -> None:
    query = build_parking_query(_NL_BBOX, timeout=45)
    assert 'way["amenity"="parking"]' in query
    assert 'way["park_ride"]' in query
    assert "out geom;" in query
    assert "timeout:45" in query


def test_osm_elements_to_features_builds_closed_polygons() -> None:
    feats = osm_elements_to_features([_osm_way(1, capacity="30"), _osm_way(2)])
    assert len(feats) == 2
    f0 = feats[0]
    assert f0["geometry"]["type"] == "Polygon"
    ring = f0["geometry"]["coordinates"][0]
    assert ring[0] == ring[-1]  # closed
    assert f0["properties"]["assetType"] == ASSET_TYPE_PARKING
    assert f0["properties"]["source"] == "OSM"
    assert f0["properties"]["parkingId"] == "osm_1"
    assert f0["properties"]["parkingCapacity"] == 30
    # Missing capacity -> 0
    assert feats[1]["properties"]["parkingCapacity"] == 0


def test_osm_elements_to_features_skips_nodes_and_degenerate() -> None:
    elements = [
        {"type": "node", "id": 9, "lon": 6.4, "lat": 52.1, "tags": {"amenity": "parking"}},
        {"type": "way", "id": 10, "tags": {}, "geometry": [{"lon": 6.4, "lat": 52.1}]},
    ]
    assert osm_elements_to_features(elements) == []


# ---------------------------------------------------------------------------
# fetch_parking_areas — orchestration
# ---------------------------------------------------------------------------


def test_fetch_parking_areas_merges_bgt_and_osm(monkeypatch) -> None:
    def _fake_bgt(collection: str, _bbox: list[float], **_kwargs) -> list[dict]:
        assert collection == COLLECTION_WEGDEEL
        return [
            {"type": "Feature", "geometry": _polygon(), "properties": {"functie": "parkeervlak"}},
        ]

    def _fake_tiled(_query_fn, _bbox, **kwargs) -> dict:
        assert kwargs["tiles"] == (OVERPASS_GRID, OVERPASS_GRID)
        return {"elements": [_osm_way(1), _osm_way(2)]}

    monkeypatch.setattr("gmt_shared.ogc_features.fetch_collection_items", _fake_bgt, raising=True)
    monkeypatch.setattr("gmt_shared.overpass.fetch_overpass_tiled", _fake_tiled, raising=True)

    fc, stats = fetch_parking_areas(_NL_BBOX)
    assert stats["bgt"] == 1
    assert stats["osm"] == 2
    assert stats["total"] == 3
    assert stats["tiles"] == OVERPASS_GRID * OVERPASS_GRID
    assert stats["source"] == "BGT+OSM"
    assert fc["properties"]["_qv"] == PARKING_QUERY_VER
    assert len(fc["features"]) == 3


def test_fetch_parking_areas_skips_bgt_outside_nl(monkeypatch) -> None:
    def _fake_tiled(_query_fn, _bbox, **_kwargs) -> dict:
        return {"elements": [_osm_way(1)]}

    monkeypatch.setattr("gmt_shared.overpass.fetch_overpass_tiled", _fake_tiled, raising=True)

    _fc, stats = fetch_parking_areas(_PARIS_BBOX)
    assert stats["bgt"] == 0
    assert stats["osm"] == 1
    assert stats["source"] == "OSM"


def test_fetch_parking_areas_osm_is_failsafe(monkeypatch) -> None:
    """An Overpass error must not fail the fetch — it degrades to BGT-only."""

    def _fake_bgt(_collection: str, _bbox: list[float], **_kwargs) -> list[dict]:
        return [
            {"type": "Feature", "geometry": _polygon(), "properties": {"functie": "parkeervlak"}},
        ]

    def _boom(_query_fn, _bbox, **_kwargs) -> dict:
        raise RuntimeError("overpass exploded")

    monkeypatch.setattr("gmt_shared.ogc_features.fetch_collection_items", _fake_bgt, raising=True)
    monkeypatch.setattr("gmt_shared.overpass.fetch_overpass_tiled", _boom, raising=True)

    fc, stats = fetch_parking_areas(_NL_BBOX)
    assert stats["bgt"] == 1
    assert stats["osm"] == 0
    assert stats["total"] == 1
    assert stats["source"] == "BGT"
    assert len(fc["features"]) == 1


def test_fetch_parking_areas_bgt_is_failsafe(monkeypatch) -> None:
    """A BGT/PDOK error must not fail the fetch — it degrades to OSM-only.

    Regression: previously the BGT leg ran first without a guard, so a reset
    connection mid-pagination aborted the whole fetch and the OSM/local-PBF leg
    never ran.
    """

    def _boom(_collection: str, _bbox: list[float], **_kwargs) -> list[dict]:
        raise OSError("[WinError 10054] connection reset")

    def _fake_tiled(_query_fn, _bbox, **_kwargs) -> dict:
        return {"elements": [_osm_way(1)]}

    monkeypatch.setattr("gmt_shared.ogc_features.fetch_collection_items", _boom, raising=True)
    monkeypatch.setattr("gmt_shared.overpass.fetch_overpass_tiled", _fake_tiled, raising=True)

    fc, stats = fetch_parking_areas(_NL_BBOX)
    assert stats["bgt"] == 0
    assert stats["osm"] == 1
    assert stats["total"] == 1
    assert stats["source"] == "OSM"
    assert len(fc["features"]) == 1


def test_fetch_parking_areas_use_flags(monkeypatch) -> None:
    def _fake_bgt(_collection: str, _bbox: list[float], **_kwargs) -> list[dict]:
        return [
            {"type": "Feature", "geometry": _polygon(), "properties": {"functie": "parkeervlak"}},
        ]

    monkeypatch.setattr("gmt_shared.ogc_features.fetch_collection_items", _fake_bgt, raising=True)

    _fc, stats = fetch_parking_areas(_NL_BBOX, use_osm=False)
    assert stats["osm"] == 0
    assert stats["bgt"] == 1
    assert stats["source"] == "BGT"


def test_fetch_parking_areas_forwards_osm_path(monkeypatch) -> None:
    """An explicit osm_path must reach the shared Overpass client's tiled fetch."""
    seen: dict[str, object] = {}

    def _fake_tiled(_query_fn, _bbox, **kwargs) -> dict:
        seen["osm_path"] = kwargs.get("osm_path")
        return {"elements": [_osm_way(1)]}

    monkeypatch.setattr("gmt_shared.overpass.fetch_overpass_tiled", _fake_tiled, raising=True)

    _fc, stats = fetch_parking_areas(_PARIS_BBOX, osm_path="extract.osm.pbf")
    assert seen["osm_path"] == "extract.osm.pbf"
    assert stats["osm"] == 1


def test_fetch_parking_areas_filters_functie_server_side(monkeypatch) -> None:
    """The BGT leg asks PDOK for parkeervlakken only (and current versions by default)."""
    seen: dict[str, object] = {}

    def _fake_bgt(_collection: str, _bbox: list[float], **kwargs) -> list[dict]:
        seen.update(kwargs)
        return []

    monkeypatch.setattr("gmt_shared.ogc_features.fetch_collection_items", _fake_bgt, raising=True)

    fetch_parking_areas(_NL_BBOX, use_osm=False)
    assert seen["properties"] == {"functie": "parkeervlak"}
    assert "current_only" not in seen  # default True in gmt_shared
