"""Hybrid STUDY(real Spectrum)/INFLUENCE(aggregated) zone assembly — no I/O, no boto3.

Combines ``zone_fetcher``'s real, unaggregated Spectrum STUDY zone polygons
(identical selection to ``zone_source="spectrum"``, keeping their real
positive ``gid`` so they match real Databricks voedingslinks rows
downstream) with ``zone_fetcher_aggregated``'s MobiliteitsScan-style
outside-AOI aggregation for INFLUENCE zones.

Deliberately discarded:
  - the candidate-INFLUENCE rows returned by ``zone_fetcher``'s own query —
    superseded by the outside-AOI aggregation below;
  - the "inside AOI" centroids ``classify_inside_outside`` would otherwise
    feed to ``reduce_within_aoi`` — superseded by the real STUDY polygons,
    so ``reduce_within_aoi`` is never called here.

This module cross-imports private helpers from ``zone_fetcher.domain.zone``
(STUDY-row parsing, convex-hull AREA builder) and
``zone_fetcher_aggregated.domain.zone`` (aggregated-zone feature builder) —
a deliberate exception to this sibling-module family's "independently
deployable, no cross-imports" convention (see
``zone_fetcher_aggregated/domain/sql.py``'s ``CBS_COLS`` duplication
comment). Reimplementing zone-row parsing or the convex-hull algorithm a
second time would risk behavioural drift between the two zone
representations this module has to combine into one AREA feature.
"""

from __future__ import annotations

import logging

from shapely.geometry import Point, shape

from gmt_zone_core.zone_fetcher.domain.sql import ZONE_FETCH_PROPERTIES
from gmt_zone_core.zone_fetcher.domain.zone import _build_area_feature, _zone_row_to_feature
from gmt_zone_core.zone_fetcher_aggregated.domain.aggregate import (
    build_aggregated_zones,
    classify_inside_outside,
    reduce_outside_aoi,
)
from gmt_zone_core.zone_fetcher_aggregated.domain.zone import (
    ZONE_FETCHER_AGGREGATED_PROPERTIES,
    _aggregated_zone_to_feature,
)

logger = logging.getLogger(__name__)

HYBRID_PROPERTIES: tuple[str, ...] = tuple(
    sorted(set(ZONE_FETCH_PROPERTIES) | set(ZONE_FETCHER_AGGREGATED_PROPERTIES))
)


def build_hybrid_feature_collection(
    study_rows: list,
    study_col_names: list[str],
    centroid_rows: list,
    centroid_col_names: list[str],
    area_id: str,
    bbox: list[float],
    aoi_ring: list[list[float]],
    *,
    zones_total_target: int,
    exclude_zone_ids: set[str] | None = None,
) -> dict:
    """Convert zone_fetcher STUDY rows + zone_fetcher_aggregated centroid rows
    into one hybrid GeoJSON FeatureCollection.

    STUDY zones are the real, unaggregated Spectrum zone polygons — the same
    rows ``zone_fetcher.rows_to_feature_collection`` would classify as
    STUDY, keeping their real positive ``gid``. INFLUENCE zones are
    MobiliteitsScan-aggregated points built from CBS buurt centroids outside
    the AOI, exactly as ``zone_fetcher_aggregated.rows_to_feature_collection``
    produces them today (negative synthetic ``gid``).

    Parameters
    ----------
    study_rows, study_col_names:
        Raw rows (and column names) from
        ``zone_fetcher.domain.sql.build_fetch_zones_sql``. Only
        ``zoneClass == "STUDY"`` rows are kept — any ``"INFLUENCE"``
        candidate rows from this same query are discarded.
    centroid_rows, centroid_col_names:
        Raw rows (and column names) from
        ``zone_fetcher_aggregated.domain.sql.build_fetch_centroids_sql``.
    area_id, bbox:
        Same meaning as in both sibling modules.
    aoi_ring:
        Closed ``[lon, lat]`` ring (the study-area boundary) used to split
        centroid rows into inside/outside, as in
        ``zone_fetcher_aggregated.rows_to_feature_collection``.
    zones_total_target:
        Target total number of zones (STUDY + INFLUENCE). The INFLUENCE
        target is ``max(zones_total_target - len(study_features), 0)`` — a
        large real STUDY count can drive INFLUENCE down to 0.
    exclude_zone_ids:
        Optional set of ``zoneId`` strings to drop from the STUDY set before
        any further processing (same semantics as
        ``zone_fetcher.rows_to_feature_collection``'s *exclude_zone_ids*).

    Returns
    -------
    dict
        GeoJSON FeatureCollection with STUDY (Polygon, real gid), INFLUENCE
        (Point, negative gid) and AREA (convex hull) features.
    """
    # ------------------------------------------------------------------
    # STUDY: real Spectrum zone polygons (discard candidate-INFLUENCE rows)
    # ------------------------------------------------------------------
    study_features: list[dict] = []
    for row in study_rows:
        r = dict(zip(study_col_names, row, strict=True))
        if (r.get("zoneClass") or "") != "STUDY":
            continue
        study_features.append(_zone_row_to_feature(r))

    if exclude_zone_ids:
        before = len(study_features)
        study_features = [
            f
            for f in study_features
            if (f.get("properties") or {}).get("zoneId") not in exclude_zone_ids
        ]
        dropped = before - len(study_features)
        if dropped:
            logger.info("exclude_zone_ids: dropped %d STUDY zone(s)", dropped)

    study_zone_ids = {(f.get("properties") or {}).get("zoneId") for f in study_features}
    study_polygons = [shape(f["geometry"]) for f in study_features if f.get("geometry")]

    # ------------------------------------------------------------------
    # INFLUENCE: aggregate CBS centroids outside the AOI (unchanged
    # algorithm), after excluding duplicates of the real STUDY zones above.
    # ------------------------------------------------------------------
    raw_centroid_rows = [dict(zip(centroid_col_names, row, strict=True)) for row in centroid_rows]
    _inside, outside = classify_inside_outside(raw_centroid_rows, aoi_ring)
    # "inside" points are intentionally discarded here — superseded by the
    # real STUDY polygons above. reduce_within_aoi is never called.

    excluded_outside_count = 0
    outside_filtered = []
    for point in outside:
        if point.source_id in study_zone_ids:
            excluded_outside_count += 1
            continue
        if study_polygons and any(
            poly.covers(Point(point.lon, point.lat)) for poly in study_polygons
        ):
            excluded_outside_count += 1
            continue
        outside_filtered.append(point)

    influence_target = max(zones_total_target - len(study_features), 0)
    reduce_outside_aoi(outside_filtered, influence_target)
    influence_zones = build_aggregated_zones(outside_filtered, within_area_of_interest=False)

    influence_features: list[dict] = []
    gid = -1
    for zone in influence_zones:
        influence_features.append(_aggregated_zone_to_feature(zone, gid, area_id))
        gid -= 1

    # ------------------------------------------------------------------
    # AREA: convex hull over both STUDY polygon vertices and INFLUENCE points
    # ------------------------------------------------------------------
    area_feature = _build_area_feature(study_features + influence_features, area_id)

    return {
        "type": "FeatureCollection",
        "id": area_id,
        "features": study_features + influence_features + [area_feature],
        "properties": {
            "areaId": area_id,
            "producer": "zone_fetcher_aggregated.hybrid",
            "bbox": bbox,
            "studyCount": len(study_features),
            "influenceCount": len(influence_features),
            "zonesTotalTarget": zones_total_target,
            "excludedOutsideCount": excluded_outside_count,
            "fields": list(HYBRID_PROPERTIES),
        },
    }
