"""Unit tests for zone_fetcher_aggregated.domain.hybrid.

All tests are pure — no boto3, no Databricks, no network calls.
"""

from __future__ import annotations

import json

from gmt_zone_core.zone_fetcher.domain.sql import _CBS_COLS
from gmt_zone_core.zone_fetcher_aggregated.domain.hybrid import build_hybrid_feature_collection
from gmt_zone_core.zone_fetcher_aggregated.domain.sql import (
    CBS_COLS,
    CENTROID_FETCH_PROPERTIES,
    bbox_to_polygon_ring,
)

_BBOX = [6.00, 52.00, 6.10, 52.05]
_AREA_ID = "test-area-001"
_AOI_RING = bbox_to_polygon_ring(_BBOX)

_CENTROID_COL_NAMES = list(CENTROID_FETCH_PROPERTIES)

# A STUDY polygon roughly covering the AOI's south-west quadrant, so its
# vertices and centroid sit inside the bbox.
_STUDY_GEOM = json.dumps(
    {
        "type": "Polygon",
        "coordinates": [
            [[6.00, 52.00], [6.05, 52.00], [6.05, 52.025], [6.00, 52.025], [6.00, 52.00]]
        ],
    }
)

_STUDY_COL_NAMES = [
    "gid",
    "zoneId",
    "zoneName",
    "municipalityCode",
    "municipalityName",
    *_CBS_COLS,
    "geom_json",
    "centroidLon",
    "centroidLat",
    "zoneClass",
]


def _make_study_row(
    gid: int,
    zone_id: str,
    zone_class: str = "STUDY",
    geom: str | None = None,
    centroid_lon: float = 6.025,
    centroid_lat: float = 52.0125,
    **cbs_overrides: float,
) -> tuple:
    fixed = (gid, zone_id, f"Zone {zone_id}", "0150", "Testgemeente")
    cbs = tuple(float(cbs_overrides.get(c, 0.0) or 0.0) for c in _CBS_COLS)
    tail = (geom or _STUDY_GEOM, centroid_lon, centroid_lat, zone_class)
    return fixed + cbs + tail


def _make_centroid_row(
    gid: int,
    zone_id: str,
    lon: float,
    lat: float,
    municipality_code: str = "0150",
    **cbs_overrides: float,
) -> tuple:
    cbs = tuple(float(cbs_overrides.get(c, 0.0) or 0.0) for c in CBS_COLS)
    return (
        gid,
        zone_id,
        f"Zone {zone_id}",
        municipality_code,
        "Testgemeente",
        *cbs,
        lon,
        lat,
    )


def test_study_features_keep_real_gid_and_polygon_geometry() -> None:
    study_rows = [_make_study_row(101, "study-1", inwoners=100, arbeidsplaatsen=10)]
    fc = build_hybrid_feature_collection(
        study_rows,
        _STUDY_COL_NAMES,
        [],
        _CENTROID_COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_total_target=10,
    )
    study = [f for f in fc["features"] if f["properties"]["zoneClass"] == "STUDY"]
    assert len(study) == 1
    assert study[0]["properties"]["gid"] == 101
    assert study[0]["geometry"]["type"] == "Polygon"
    assert "sourceZoneIds" not in study[0]["properties"]


def test_study_rows_with_influence_class_are_discarded() -> None:
    study_rows = [
        _make_study_row(101, "study-1", zone_class="STUDY", inwoners=100),
        _make_study_row(102, "candidate-1", zone_class="INFLUENCE", centroid_lon=6.2, inwoners=50),
    ]
    fc = build_hybrid_feature_collection(
        study_rows,
        _STUDY_COL_NAMES,
        [],
        _CENTROID_COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_total_target=10,
    )
    assert fc["properties"]["studyCount"] == 1
    gids = {f["properties"].get("gid") for f in fc["features"]}
    assert 102 not in gids


def test_influence_features_get_negative_gid_and_point_geometry() -> None:
    centroid_rows = [_make_centroid_row(1, "out1", 6.50, 52.02, inwoners=50, arbeidsplaatsen=5)]
    fc = build_hybrid_feature_collection(
        [],
        _STUDY_COL_NAMES,
        centroid_rows,
        _CENTROID_COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_total_target=10,
    )
    influence = [f for f in fc["features"] if f["properties"]["zoneClass"] == "INFLUENCE"]
    assert len(influence) == 1
    assert influence[0]["properties"]["gid"] < 0
    assert influence[0]["geometry"]["type"] == "Point"
    assert "sourceZoneIds" in influence[0]["properties"]


def test_outside_centroid_matching_study_zone_id_is_excluded() -> None:
    study_rows = [_make_study_row(101, "dup-zone", inwoners=100, arbeidsplaatsen=10)]
    # Same zoneId as the STUDY row, positioned well outside the AOI so it would
    # otherwise be classified as an outside/INFLUENCE candidate.
    centroid_rows = [
        _make_centroid_row(101, "dup-zone", 7.00, 52.02, inwoners=100, arbeidsplaatsen=10),
        _make_centroid_row(2, "out1", 7.01, 52.02, inwoners=50, arbeidsplaatsen=5),
    ]
    fc = build_hybrid_feature_collection(
        study_rows,
        _STUDY_COL_NAMES,
        centroid_rows,
        _CENTROID_COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_total_target=10,
    )
    assert fc["properties"]["excludedOutsideCount"] == 1
    influence = [f for f in fc["features"] if f["properties"]["zoneClass"] == "INFLUENCE"]
    assert len(influence) == 1
    assert sorted(influence[0]["properties"]["sourceZoneIds"]) == ["out1"]


def test_outside_centroid_geometrically_inside_study_polygon_is_excluded() -> None:
    # A STUDY zone's own polygon can extend outside the AOI bbox (the SQL
    # STUDY rule only requires >= 80% area overlap, not full containment).
    # Here the polygon spans lon 6.05-6.15, sticking out past the bbox's
    # east edge (6.10), so a different zone's centroid can legitimately be
    # outside the AOI ring (classify_inside_outside's "outside" bucket) while
    # still falling inside this STUDY polygon.
    bulging_geom = json.dumps(
        {
            "type": "Polygon",
            "coordinates": [
                [[6.05, 52.00], [6.15, 52.00], [6.15, 52.03], [6.05, 52.03], [6.05, 52.00]]
            ],
        }
    )
    study_rows = [
        _make_study_row(
            101,
            "study-1",
            geom=bulging_geom,
            centroid_lon=6.07,
            centroid_lat=52.01,
            inwoners=100,
            arbeidsplaatsen=10,
        )
    ]
    # Different zoneId, but its coordinates (6.12, 52.01) fall inside the
    # STUDY polygon's eastward bulge, outside the AOI bbox.
    centroid_rows = [
        _make_centroid_row(202, "enclave", 6.12, 52.01, inwoners=20, arbeidsplaatsen=2),
        _make_centroid_row(2, "out1", 7.01, 52.02, inwoners=50, arbeidsplaatsen=5),
    ]
    fc = build_hybrid_feature_collection(
        study_rows,
        _STUDY_COL_NAMES,
        centroid_rows,
        _CENTROID_COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_total_target=10,
    )
    assert fc["properties"]["excludedOutsideCount"] == 1
    influence = [f for f in fc["features"] if f["properties"]["zoneClass"] == "INFLUENCE"]
    assert len(influence) == 1
    assert sorted(influence[0]["properties"]["sourceZoneIds"]) == ["out1"]


def test_influence_target_clamps_to_zero_when_study_count_meets_total() -> None:
    # zones_total_target(1) - studyCount(1) would be 0 (not negative); with
    # multiple outside points the reduction still merges everything down to
    # the fewest possible groups (1) rather than erroring or leaving the
    # target unclamped.
    study_rows = [_make_study_row(101, "study-1", inwoners=100, arbeidsplaatsen=10)]
    centroid_rows = [
        _make_centroid_row(2, "out1", 7.00, 52.02, inwoners=50, arbeidsplaatsen=5),
        _make_centroid_row(3, "out2", 7.01, 52.02, inwoners=30, arbeidsplaatsen=3),
        _make_centroid_row(4, "out3", 7.02, 52.02, inwoners=20, arbeidsplaatsen=2),
    ]
    fc = build_hybrid_feature_collection(
        study_rows,
        _STUDY_COL_NAMES,
        centroid_rows,
        _CENTROID_COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_total_target=1,
    )
    assert fc["properties"]["studyCount"] == 1
    assert fc["properties"]["influenceCount"] == 1


def test_exclude_zone_ids_drops_study_zone_but_leaves_other_outside_points() -> None:
    # exclude_zone_ids only affects the STUDY decision — it does not remove
    # a same-zoneId centroid from the outside/INFLUENCE universe, since the
    # identity-match dedup only compares against the (already-filtered)
    # STUDY set. A centroid sharing the excluded zoneId is therefore free to
    # become its own INFLUENCE zone, same as any other outside point.
    study_rows = [
        _make_study_row(101, "keep-me", inwoners=100, arbeidsplaatsen=10),
        _make_study_row(102, "drop-me", centroid_lon=6.03, inwoners=80, arbeidsplaatsen=8),
    ]
    centroid_rows = [
        _make_centroid_row(102, "drop-me", 7.00, 52.02, inwoners=80, arbeidsplaatsen=8),
    ]
    fc = build_hybrid_feature_collection(
        study_rows,
        _STUDY_COL_NAMES,
        centroid_rows,
        _CENTROID_COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_total_target=10,
        exclude_zone_ids={"drop-me"},
    )
    study = [f for f in fc["features"] if f["properties"]["zoneClass"] == "STUDY"]
    influence = [f for f in fc["features"] if f["properties"]["zoneClass"] == "INFLUENCE"]
    assert [f["properties"]["zoneId"] for f in study] == ["keep-me"]
    assert len(influence) == 1
    assert influence[0]["properties"]["sourceZoneIds"] == ["drop-me"]


def test_area_feature_is_convex_hull_of_study_and_influence_coords() -> None:
    study_rows = [_make_study_row(101, "study-1", inwoners=100, arbeidsplaatsen=10)]
    centroid_rows = [_make_centroid_row(2, "out1", 7.00, 52.02, inwoners=50, arbeidsplaatsen=5)]
    fc = build_hybrid_feature_collection(
        study_rows,
        _STUDY_COL_NAMES,
        centroid_rows,
        _CENTROID_COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_total_target=10,
    )
    area = next(f for f in fc["features"] if f["properties"]["zoneClass"] == "AREA")
    assert area["geometry"]["type"] == "Polygon"
    hull_lons = [p[0] for p in area["geometry"]["coordinates"][0]]
    # Hull must span from the STUDY polygon's west edge to the far-away
    # INFLUENCE point's longitude.
    assert min(hull_lons) <= 6.00
    assert max(hull_lons) >= 7.00


def test_properties_report_counts_and_producer() -> None:
    study_rows = [_make_study_row(101, "study-1", inwoners=100, arbeidsplaatsen=10)]
    centroid_rows = [_make_centroid_row(2, "out1", 7.00, 52.02, inwoners=50, arbeidsplaatsen=5)]
    fc = build_hybrid_feature_collection(
        study_rows,
        _STUDY_COL_NAMES,
        centroid_rows,
        _CENTROID_COL_NAMES,
        _AREA_ID,
        _BBOX,
        _AOI_RING,
        zones_total_target=10,
    )
    assert fc["properties"]["producer"] == "zone_fetcher_aggregated.hybrid"
    assert fc["properties"]["studyCount"] == 1
    assert fc["properties"]["influenceCount"] == 1
    assert fc["properties"]["zonesTotalTarget"] == 10
    assert fc["properties"]["excludedOutsideCount"] == 0
