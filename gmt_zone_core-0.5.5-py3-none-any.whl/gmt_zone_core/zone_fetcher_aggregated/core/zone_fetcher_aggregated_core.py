"""Pure-Python zone_fetcher_aggregated core — no I/O, no boto3, no Databricks connections.

Fetches every CBS buurt centroid within a search radius and greedily
aggregates them down to a target zone count (MobiliteitsScan's
``CreateBaseScenario`` algorithm), separately inside and outside an
area-of-interest polygon, producing output schema-compatible with
``zone_fetcher``.

Public API
----------
build_fetch_centroids_sql(catalog, schema) -> str
    Return the parameterised Databricks SQL string (2 ``?`` placeholders:
    bbox GeoJSON polygon, search radius in metres).
bbox_to_polygon_json(bbox) -> str
    Convert [lon_min, lat_min, lon_max, lat_max] to a GeoJSON Polygon string.
bbox_to_polygon_ring(bbox) -> list[list[float]]
    Convert [lon_min, lat_min, lon_max, lat_max] to a closed [lon, lat] ring.
rows_to_feature_collection(rows, col_names, area_id, bbox, aoi_ring, *,
                            zones_within_target, zones_total_target) -> dict
    Convert raw Databricks result rows into an aggregated GeoJSON FeatureCollection.
build_hybrid_feature_collection(study_rows, study_col_names, centroid_rows,
                                 centroid_col_names, area_id, bbox, aoi_ring, *,
                                 zones_total_target, exclude_zone_ids=None) -> dict
    Combine zone_fetcher's real Spectrum STUDY zones with aggregated
    INFLUENCE zones outside the study area into one FeatureCollection.
"""

from __future__ import annotations

from gmt_zone_core.zone_fetcher_aggregated.domain.hybrid import (  # noqa: F401
    HYBRID_PROPERTIES,
    build_hybrid_feature_collection,
)
from gmt_zone_core.zone_fetcher_aggregated.domain.sql import (  # noqa: F401
    CBS_COLS,
    CENTROID_FETCH_PROPERTIES,
    bbox_to_polygon_json,
    bbox_to_polygon_ring,
    build_fetch_centroids_sql,
)
from gmt_zone_core.zone_fetcher_aggregated.domain.zone import (  # noqa: F401
    ZONE_FETCHER_AGGREGATED_PROPERTIES,
    _calc_attraction,
    _calc_production,
    rows_to_feature_collection,
)
