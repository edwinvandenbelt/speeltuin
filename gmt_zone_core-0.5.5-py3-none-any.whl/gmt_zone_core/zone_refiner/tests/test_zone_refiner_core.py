"""Unit tests for zone_refiner_core.py."""

from __future__ import annotations

import math
import uuid

import pytest

from gmt_zone_core.zone_refiner.core.zone_refiner_core import (
    _clip_length_in_ring,
    _find_split_hits,
    _get_outer_ring,
    _intersections_with_ring_indexed,
    _point_in_polygon,
    _ring_bbox_size,
    _ring_centroid,
    _scale_properties,
    _seg_length_m,
    _split_ring_by_chord,
    refine_zones,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

# Unit square ring: (0,0) – (1,0) – (1,1) – (0,1) – closed
_SQUARE = [(0.0, 0.0), (1.0, 0.0), (1.0, 1.0), (0.0, 1.0), (0.0, 0.0)]

# ---------------------------------------------------------------------------
# _seg_length_m
# ---------------------------------------------------------------------------


class TestSegLengthM:
    def test_vertical_one_degree(self) -> None:
        # 1° latitude ≈ 111 320 m
        d = _seg_length_m(0.0, 0.0, 0.0, 1.0)
        assert abs(d - 111_320.0) < 10.0

    def test_horizontal_equator(self) -> None:
        # 1° longitude at the equator ≈ 111 320 m  (cos 0° = 1)
        d = _seg_length_m(0.0, 0.0, 1.0, 0.0)
        assert abs(d - 111_320.0) < 10.0

    def test_horizontal_netherlands(self) -> None:
        # 1° longitude at 52°N ≈ 111 320 × cos(52°) ≈ 68 555 m
        d = _seg_length_m(0.0, 52.0, 1.0, 52.0)
        expected = 111_320.0 * math.cos(math.radians(52.0))
        assert abs(d - expected) < 10.0

    def test_zero_length(self) -> None:
        assert _seg_length_m(1.0, 1.0, 1.0, 1.0) == pytest.approx(0.0)

    def test_symmetric(self) -> None:
        assert _seg_length_m(0.0, 0.0, 0.5, 0.5) == pytest.approx(
            _seg_length_m(0.5, 0.5, 0.0, 0.0), rel=1e-9
        )


# ---------------------------------------------------------------------------
# _ring_bbox_size
# ---------------------------------------------------------------------------


class TestRingBboxSize:
    def test_unit_square_returns_one(self) -> None:
        assert _ring_bbox_size(_SQUARE) == pytest.approx(1.0)

    def test_wide_ring(self) -> None:
        ring = [(0.0, 0.0), (3.0, 0.0), (3.0, 1.0), (0.0, 1.0), (0.0, 0.0)]
        assert _ring_bbox_size(ring) == pytest.approx(3.0)


# ---------------------------------------------------------------------------
# _point_in_polygon
# ---------------------------------------------------------------------------


class TestPointInPolygon:
    def test_centre_is_inside(self) -> None:
        assert _point_in_polygon(0.5, 0.5, _SQUARE) is True

    def test_outside_is_outside(self) -> None:
        assert _point_in_polygon(2.0, 2.0, _SQUARE) is False

    def test_bottom_left_corner(self) -> None:
        # Corner is on the boundary — result is consistent but implementation-defined.
        # Just ensure no exception is raised.
        _point_in_polygon(0.0, 0.0, _SQUARE)

    def test_negative_coords(self) -> None:
        assert _point_in_polygon(-1.0, 0.5, _SQUARE) is False


# ---------------------------------------------------------------------------
# _intersections_with_ring_indexed
# ---------------------------------------------------------------------------


class TestIntersectionsWithRingIndexed:
    def test_horizontal_line_through_square(self) -> None:
        # Line at y = 0.5, from x = −2 to x = 2.
        hits = _intersections_with_ring_indexed(-2.0, 0.5, 2.0, 0.5, _SQUARE)
        assert len(hits) == 2
        # Both intersection x-coords should be 0 and 1.
        xs = sorted(h[1] for h in hits)
        assert xs[0] == pytest.approx(0.0, abs=1e-9)
        assert xs[1] == pytest.approx(1.0, abs=1e-9)
        # Both intersection y-coords should be 0.5.
        for h in hits:
            assert h[2] == pytest.approx(0.5, abs=1e-9)

    def test_vertical_line_through_square(self) -> None:
        hits = _intersections_with_ring_indexed(0.5, -2.0, 0.5, 2.0, _SQUARE)
        assert len(hits) == 2
        ys = sorted(h[2] for h in hits)
        assert ys[0] == pytest.approx(0.0, abs=1e-9)
        assert ys[1] == pytest.approx(1.0, abs=1e-9)

    def test_missing_line_returns_empty(self) -> None:
        # Line entirely outside the square.
        hits = _intersections_with_ring_indexed(5.0, 0.0, 6.0, 1.0, _SQUARE)
        assert len(hits) == 0

    def test_sorted_by_t(self) -> None:
        hits = _intersections_with_ring_indexed(-2.0, 0.5, 2.0, 0.5, _SQUARE)
        ts = [h[0] for h in hits]
        assert ts == sorted(ts)

    def test_edge_index_is_valid(self) -> None:
        hits = _intersections_with_ring_indexed(-2.0, 0.5, 2.0, 0.5, _SQUARE)
        n = len(_SQUARE)
        for h in hits:
            assert 0 <= h[3] < n - 1


# ---------------------------------------------------------------------------
# _clip_length_in_ring
# ---------------------------------------------------------------------------


class TestClipLengthInRing:
    def test_entirely_inside(self) -> None:
        # Segment from (0.2, 0.2) to (0.8, 0.2) is fully inside the unit square.
        coords = [[0.2, 0.2], [0.8, 0.2]]
        total = _clip_length_in_ring(coords, _SQUARE)
        expected = _seg_length_m(0.2, 0.2, 0.8, 0.2)
        assert total == pytest.approx(expected, rel=1e-6)

    def test_entirely_outside(self) -> None:
        coords = [[2.0, 2.0], [3.0, 2.0]]
        assert _clip_length_in_ring(coords, _SQUARE) == pytest.approx(0.0, abs=1e-9)

    def test_crossing_segment_is_partial(self) -> None:
        # Segment from (−0.5, 0.5) to (0.5, 0.5): half inside, half outside.
        coords = [[-0.5, 0.5], [0.5, 0.5]]
        total = _clip_length_in_ring(coords, _SQUARE)
        expected = _seg_length_m(0.0, 0.5, 0.5, 0.5)
        assert total == pytest.approx(expected, rel=1e-4)

    def test_empty_coords_returns_zero(self) -> None:
        assert _clip_length_in_ring([], _SQUARE) == pytest.approx(0.0)
        assert _clip_length_in_ring([[0.5, 0.5]], _SQUARE) == pytest.approx(0.0)

    def test_multi_segment_path(self) -> None:
        # Path with two segments, both inside.
        coords = [[0.1, 0.1], [0.5, 0.1], [0.9, 0.9]]
        total = _clip_length_in_ring(coords, _SQUARE)
        expected = _seg_length_m(0.1, 0.1, 0.5, 0.1) + _seg_length_m(0.5, 0.1, 0.9, 0.9)
        assert total == pytest.approx(expected, rel=1e-6)


# ---------------------------------------------------------------------------
# _find_split_hits
# ---------------------------------------------------------------------------


class TestFindSplitHits:
    def test_vertical_road_through_square(self) -> None:
        # Road going vertically at x = 0.4.
        coords = [[0.4, 0.2], [0.4, 0.8]]
        result = _find_split_hits(_SQUARE, coords)
        assert result is not None
        hit1, hit2 = result
        # Both hits should have x ≈ 0.4.
        assert hit1[1] == pytest.approx(0.4, abs=1e-6)
        assert hit2[1] == pytest.approx(0.4, abs=1e-6)
        # y-coords should be 0 and 1 (ring top and bottom).
        ys = sorted([hit1[2], hit2[2]])
        assert ys[0] == pytest.approx(0.0, abs=1e-6)
        assert ys[1] == pytest.approx(1.0, abs=1e-6)

    def test_horizontal_road_through_square(self) -> None:
        coords = [[0.2, 0.5], [0.8, 0.5]]
        result = _find_split_hits(_SQUARE, coords)
        assert result is not None
        hit1, hit2 = result
        xs = sorted([hit1[1], hit2[1]])
        assert xs[0] == pytest.approx(0.0, abs=1e-6)
        assert xs[1] == pytest.approx(1.0, abs=1e-6)

    def test_zero_length_road_returns_none(self) -> None:
        assert _find_split_hits(_SQUARE, [[0.5, 0.5], [0.5, 0.5]]) is None

    def test_single_coord_returns_none(self) -> None:
        assert _find_split_hits(_SQUARE, [[0.5, 0.5]]) is None


# ---------------------------------------------------------------------------
# _split_ring_by_chord
# ---------------------------------------------------------------------------


class TestSplitRingByChord:
    def _hits_for_vertical_at_x(self, x: float) -> tuple[tuple, tuple]:
        """Return (hit1, hit2) for a vertical chord at *x* through the unit square."""
        coords = [[x, 0.2], [x, 0.8]]
        result = _find_split_hits(_SQUARE, coords)
        assert result is not None
        hits: tuple[tuple, tuple] = result
        return hits

    def test_produces_two_valid_rings(self) -> None:
        hit1, hit2 = self._hits_for_vertical_at_x(0.5)
        ring_a, ring_b = _split_ring_by_chord(_SQUARE, hit1, hit2)
        assert ring_a is not None
        assert ring_b is not None
        # Both rings must be closed (first == last).
        assert ring_a[0] == ring_a[-1]
        assert ring_b[0] == ring_b[-1]

    def test_minimum_vertex_count(self) -> None:
        hit1, hit2 = self._hits_for_vertical_at_x(0.5)
        ring_a, ring_b = _split_ring_by_chord(_SQUARE, hit1, hit2)
        assert ring_a is not None
        assert ring_b is not None
        # At least 4 entries = 3 unique vertices + closing point.
        assert len(ring_a) >= 4
        assert len(ring_b) >= 4

    def test_areas_sum_to_original(self) -> None:
        """Area(A) + Area(B) ≈ Area(original)."""

        def _shoelace_area(ring: list) -> float:
            s = 0.0
            for i in range(len(ring) - 1):
                s += ring[i][0] * ring[i + 1][1] - ring[i + 1][0] * ring[i][1]
            return abs(s) / 2.0

        hit1, hit2 = self._hits_for_vertical_at_x(0.3)
        ring_a, ring_b = _split_ring_by_chord(_SQUARE, hit1, hit2)
        assert ring_a is not None
        assert ring_b is not None
        orig_area = _shoelace_area(_SQUARE)
        assert _shoelace_area(ring_a) + _shoelace_area(ring_b) == pytest.approx(orig_area, rel=1e-9)

    def test_split_creates_expected_halves(self) -> None:
        """Vertical split at x = 0.5 should yield a left and right rectangle."""
        hit1, hit2 = self._hits_for_vertical_at_x(0.5)
        ring_a, ring_b = _split_ring_by_chord(_SQUARE, hit1, hit2)
        assert ring_a is not None
        assert ring_b is not None
        # Every x in ring_a should be ≥ 0.5 (right half) or ≥ 0.0 (covers boundary).
        # Every x in ring_b should be ≤ 0.5 (left half).
        xs_a = [p[0] for p in ring_a]
        xs_b = [p[0] for p in ring_b]
        assert all(x >= -1e-9 for x in xs_a)
        assert all(x <= 1.0 + 1e-9 for x in xs_b)


# ---------------------------------------------------------------------------
# _ring_centroid
# ---------------------------------------------------------------------------


class TestRingCentroid:
    def test_unit_square_centroid(self) -> None:
        cx, cy = _ring_centroid(_SQUARE)
        assert cx == pytest.approx(0.5, abs=1e-9)
        assert cy == pytest.approx(0.5, abs=1e-9)

    def test_right_half_centroid(self) -> None:
        # Right half of unit square: x from 0.5 to 1.
        ring = [(0.5, 0.0), (1.0, 0.0), (1.0, 1.0), (0.5, 1.0), (0.5, 0.0)]
        cx, cy = _ring_centroid(ring)
        assert cx == pytest.approx(0.75, abs=1e-9)
        assert cy == pytest.approx(0.5, abs=1e-9)

    def test_bottom_half_centroid(self) -> None:
        # Bottom half: y from 0 to 0.5.
        ring = [(0.0, 0.0), (1.0, 0.0), (1.0, 0.5), (0.0, 0.5), (0.0, 0.0)]
        cx, cy = _ring_centroid(ring)
        assert cx == pytest.approx(0.5, abs=1e-9)
        assert cy == pytest.approx(0.25, abs=1e-9)

    def test_known_right_triangle(self) -> None:
        # Right triangle (0,0)–(1,0)–(0,1): centroid at (1/3, 1/3).
        ring = [(0.0, 0.0), (1.0, 0.0), (0.0, 1.0), (0.0, 0.0)]
        cx, cy = _ring_centroid(ring)
        assert cx == pytest.approx(1 / 3, abs=1e-9)
        assert cy == pytest.approx(1 / 3, abs=1e-9)


# ---------------------------------------------------------------------------
# _get_outer_ring
# ---------------------------------------------------------------------------


class TestGetOuterRing:
    def test_polygon_feature(self) -> None:
        feat = {
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [_SQUARE, []]},
            "properties": {},
        }
        ring = _get_outer_ring(feat)
        assert ring == _SQUARE

    def test_multipolygon_returns_largest(self) -> None:
        small = [(0.0, 0.0), (0.1, 0.0), (0.1, 0.1), (0.0, 0.0)]
        large = _SQUARE
        feat = {
            "type": "Feature",
            "geometry": {"type": "MultiPolygon", "coordinates": [[small], [large]]},
            "properties": {},
        }
        ring = _get_outer_ring(feat)
        assert ring == large

    def test_point_feature_returns_none(self) -> None:
        feat = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0.5, 0.5]},
            "properties": {},
        }
        assert _get_outer_ring(feat) is None

    def test_missing_geometry_returns_none(self) -> None:
        assert _get_outer_ring({"type": "Feature", "properties": {}}) is None


# ---------------------------------------------------------------------------
# _scale_properties
# ---------------------------------------------------------------------------


class TestScaleProperties:
    _BASE = {
        "zoneId": "orig-id",
        "zoneClass": "STUDY",
        "zoneClassCode": 1,
        "zoneName": "Test Zone",
        "production": 100.0,
        "attraction": 80.0,
        "inwoners": 500,
        "centroidLon": 5.0,
        "centroidLat": 52.0,
        "fromNodeProportions": {"n1": 0.6, "n2": 0.4},
        "toNodeProportions": {"n1": 0.5, "n3": 0.5},
        "gid": 42,
        "flag": True,
    }

    def test_numeric_properties_are_scaled(self) -> None:
        out = _scale_properties(self._BASE, 0.4, "new-id", "orig-id")
        assert out["production"] == pytest.approx(40.0)
        assert out["attraction"] == pytest.approx(32.0)
        assert out["inwoners"] == pytest.approx(200.0)

    def test_zone_id_replaced(self) -> None:
        out = _scale_properties(self._BASE, 0.4, "new-id", "orig-id")
        assert out["zoneId"] == "new-id"

    def test_parent_zone_id_set(self) -> None:
        out = _scale_properties(self._BASE, 0.4, "new-id", "orig-id")
        assert out["parentZoneId"] == "orig-id"

    def test_string_properties_unchanged(self) -> None:
        out = _scale_properties(self._BASE, 0.4, "new-id", "orig-id")
        assert out["zoneClass"] == "STUDY"
        assert out["zoneName"] == "Test Zone"

    def test_bool_not_scaled(self) -> None:
        out = _scale_properties(self._BASE, 0.5, "new-id", "orig-id")
        assert out["flag"] is True

    def test_centroid_coords_passed_through(self) -> None:
        out = _scale_properties(self._BASE, 0.5, "new-id", "orig-id")
        assert out["centroidLon"] == pytest.approx(5.0)
        assert out["centroidLat"] == pytest.approx(52.0)

    def test_node_proportions_cleared(self) -> None:
        out = _scale_properties(self._BASE, 0.5, "new-id", "orig-id")
        assert out["fromNodeProportions"] == {}
        assert out["toNodeProportions"] == {}

    def test_gid_set_to_none(self) -> None:
        out = _scale_properties(self._BASE, 0.5, "new-id", "orig-id")
        assert out["gid"] is None

    def test_fraction_one_leaves_numerics_unchanged(self) -> None:
        out = _scale_properties(self._BASE, 1.0, "new-id", "orig-id")
        assert out["production"] == pytest.approx(100.0)
        assert out["attraction"] == pytest.approx(80.0)

    def test_fraction_zero_zeros_numerics(self) -> None:
        out = _scale_properties(self._BASE, 0.0, "new-id", "orig-id")
        assert out["production"] == pytest.approx(0.0)
        assert out["attraction"] == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# refine_zones — integration tests
# ---------------------------------------------------------------------------


def _make_zone_fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features, "properties": {"name": "test"}}


def _make_network_fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features}


def _zone_feature(zone_class: str, ring: list, extra_props: dict | None = None) -> dict:
    props: dict = {
        "zoneId": str(uuid.uuid4()),
        "zoneClass": zone_class,
        "zoneName": f"Zone-{zone_class}",
        "production": 200.0,
        "attraction": 150.0,
        "inwoners": 1000,
        "fromNodeProportions": {"n1": 1.0},
        "toNodeProportions": {"n1": 1.0},
        "gid": 1,
    }
    if extra_props:
        props.update(extra_props)
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": props,
    }


def _link_feature(coords: list) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {"linkId": 1, "length": 100.0, "mode": "BIKE"},
    }


class TestRefineZones:
    def test_study_zone_is_split_into_two(self) -> None:
        zone = _zone_feature("STUDY", _SQUARE)
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])  # vertical road at x=0.5
        zones_fc = _make_zone_fc([zone])
        network_fc = _make_network_fc([road])

        refined_fc, stats = refine_zones(zones_fc, network_fc)
        features = refined_fc["features"]

        assert stats["inputZones"] == 1
        assert stats["splitZones"] == 1
        assert stats["unsplitZones"] == 0
        assert stats["outputZones"] == 2
        assert len(features) == 2

    def test_influence_zone_is_split(self) -> None:
        zone = _zone_feature("INFLUENCE", _SQUARE)
        road = _link_feature([[0.3, 0.2], [0.3, 0.8]])
        zones_fc = _make_zone_fc([zone])
        network_fc = _make_network_fc([road])

        refined_fc, stats = refine_zones(zones_fc, network_fc)
        assert stats["splitZones"] == 1
        assert len(refined_fc["features"]) == 2

    def test_area_zone_passes_through_unchanged(self) -> None:
        area_zone = _zone_feature("AREA", _SQUARE)
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        zones_fc = _make_zone_fc([area_zone])
        network_fc = _make_network_fc([road])

        refined_fc, stats = refine_zones(zones_fc, network_fc)
        assert stats["splitZones"] == 0
        assert len(refined_fc["features"]) == 1
        assert (
            refined_fc["features"][0]["properties"]["zoneId"] == (area_zone["properties"]["zoneId"])
        )

    def test_boundary_zone_passes_through_unchanged(self) -> None:
        bnd_zone = _zone_feature("BOUNDARY", _SQUARE)
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, stats = refine_zones(_make_zone_fc([bnd_zone]), _make_network_fc([road]))
        assert stats["splitZones"] == 0

    def test_production_sums_to_original(self) -> None:
        original_prod = 300.0
        zone = _zone_feature("STUDY", _SQUARE, {"production": original_prod})
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, _ = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        total_prod = sum(f["properties"]["production"] for f in refined_fc["features"])
        assert total_prod == pytest.approx(original_prod, rel=1e-9)

    def test_attraction_sums_to_original(self) -> None:
        original_attr = 250.0
        zone = _zone_feature("STUDY", _SQUARE, {"attraction": original_attr})
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, _ = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        total = sum(f["properties"]["attraction"] for f in refined_fc["features"])
        assert total == pytest.approx(original_attr, rel=1e-9)

    def test_inwoners_sums_to_original(self) -> None:
        zone = _zone_feature("STUDY", _SQUARE, {"inwoners": 800})
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, _ = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        total = sum(f["properties"]["inwoners"] for f in refined_fc["features"])
        assert total == pytest.approx(800, rel=1e-9)

    def test_parent_zone_id_set(self) -> None:
        parent_id = "parent-123"
        zone = _zone_feature("STUDY", _SQUARE, {"zoneId": parent_id})
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, _ = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        for feat in refined_fc["features"]:
            assert feat["properties"]["parentZoneId"] == parent_id

    def test_new_zone_ids_are_unique_uuids(self) -> None:
        zone = _zone_feature("STUDY", _SQUARE)
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, _ = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        ids = [f["properties"]["zoneId"] for f in refined_fc["features"]]
        assert len(set(ids)) == 2
        for zone_id in ids:
            # Should be a valid UUID.
            uuid.UUID(zone_id)

    def test_new_zone_ids_differ_from_parent(self) -> None:
        parent_id = str(uuid.uuid4())
        zone = _zone_feature("STUDY", _SQUARE, {"zoneId": parent_id})
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, _ = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        for feat in refined_fc["features"]:
            assert feat["properties"]["zoneId"] != parent_id

    def test_node_proportions_cleared(self) -> None:
        zone = _zone_feature("STUDY", _SQUARE)
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, _ = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        for feat in refined_fc["features"]:
            assert feat["properties"]["fromNodeProportions"] == {}
            assert feat["properties"]["toNodeProportions"] == {}

    def test_zone_class_inherited(self) -> None:
        zone = _zone_feature("INFLUENCE", _SQUARE)
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, _ = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        for feat in refined_fc["features"]:
            assert feat["properties"]["zoneClass"] == "INFLUENCE"

    def test_centroid_inside_sub_zone(self) -> None:
        zone = _zone_feature("STUDY", _SQUARE)
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, _ = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        for feat in refined_fc["features"]:
            props = feat["properties"]
            ring = feat["geometry"]["coordinates"][0]
            lon = props["centroidLon"]
            lat = props["centroidLat"]
            # Centroid must lie inside its own ring.
            assert _point_in_polygon(lon, lat, ring), (
                f"Centroid ({lon}, {lat}) is not inside its ring"
            )

    def test_zone_with_no_roads_not_split(self) -> None:
        # Road outside the zone entirely.
        zone = _zone_feature("STUDY", _SQUARE)
        road = _link_feature([[5.0, 5.0], [6.0, 5.0]])  # far away
        refined_fc, stats = refine_zones(_make_zone_fc([zone]), _make_network_fc([road]))
        assert stats["splitZones"] == 0
        assert stats["unsplitZones"] == 1
        assert len(refined_fc["features"]) == 1

    def test_empty_network_leaves_zones_unsplit(self) -> None:
        zone = _zone_feature("STUDY", _SQUARE)
        refined_fc, stats = refine_zones(_make_zone_fc([zone]), _make_network_fc([]))
        assert stats["unsplitZones"] == 1
        assert len(refined_fc["features"]) == 1

    def test_mixed_zone_classes(self) -> None:
        study = _zone_feature("STUDY", _SQUARE)
        area = _zone_feature("AREA", _SQUARE)
        boundary = _zone_feature("BOUNDARY", _SQUARE)
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])

        refined_fc, stats = refine_zones(
            _make_zone_fc([study, area, boundary]),
            _make_network_fc([road]),
        )
        # 1 STUDY → 2 sub-zones; 1 AREA + 1 BOUNDARY pass through.
        assert stats["splitZones"] == 1
        assert len(refined_fc["features"]) == 4

    def test_feature_collection_properties_preserved(self) -> None:
        zone = _zone_feature("STUDY", _SQUARE)
        road = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        zones_fc = _make_zone_fc([zone])
        zones_fc["properties"]["name"] = "myarea"
        refined_fc, _ = refine_zones(zones_fc, _make_network_fc([road]))
        assert refined_fc.get("properties", {}).get("name") == "myarea"

    def test_non_linestring_network_features_ignored(self) -> None:
        zone = _zone_feature("STUDY", _SQUARE)
        point_feat = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0.5, 0.5]},
            "properties": {},
        }
        line_feat = _link_feature([[0.5, 0.1], [0.5, 0.9]])
        refined_fc, stats = refine_zones(
            _make_zone_fc([zone]),
            _make_network_fc([point_feat, line_feat]),
        )
        assert stats["splitZones"] == 1

    def test_proportional_distribution_asymmetric(self) -> None:
        """More road in right half → right sub-zone gets most production."""
        zone = _zone_feature("STUDY", _SQUARE, {"production": 100.0})
        # Split road at x=0.5 (used as split line, full height).
        # It lies exactly on the chord so it contributes 0 m to either sub-zone.
        split_road = _link_feature([[0.5, 0.05], [0.5, 0.95]])
        # Long road in the right half (x > 0.5).
        right_road = _link_feature([[0.7, 0.1], [0.7, 0.9]])
        # Short road in the left half (x < 0.5) — ensures both halves get some road.
        left_road = _link_feature([[0.3, 0.45], [0.3, 0.55]])

        refined_fc, _ = refine_zones(
            _make_zone_fc([zone]),
            _make_network_fc([split_road, right_road, left_road]),
        )
        features = refined_fc["features"]
        assert len(features) == 2
        prods = sorted(f["properties"]["production"] for f in features)
        # Both sub-zones get >0 production; the sub-zone with more road gets more.
        assert prods[0] > 0
        assert prods[1] > prods[0]
        # And they still sum to 100.
        assert prods[0] + prods[1] == pytest.approx(100.0, rel=1e-9)
