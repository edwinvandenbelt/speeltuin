"""Unit tests for the road-following splitter (split_zone_by_roads / domain.blocks)."""

from __future__ import annotations

import pytest
from shapely.geometry import LineString, shape
from shapely.ops import unary_union

from gmt_zone_core.zone_splitter.core.zone_splitter_core import split_zone_by_roads

# ~700 m x 1100 m square near Utrecht.
_X0, _Y0, _D = 5.0, 52.0, 0.01
_SQUARE = [
    [_X0, _Y0],
    [_X0 + _D, _Y0],
    [_X0 + _D, _Y0 + _D],
    [_X0, _Y0 + _D],
    [_X0, _Y0],
]


def _zone(coords: list, gtype: str = "Polygon") -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": gtype, "coordinates": coords},
        "properties": {"zoneId": "z1"},
    }


def _network(*lines: list) -> dict:
    return {
        "type": "FeatureCollection",
        "features": [
            {"type": "Feature", "geometry": {"type": "LineString", "coordinates": ln}}
            for ln in lines
        ],
    }


def _buildings(*points: tuple[float, float]) -> dict:
    return {
        "type": "FeatureCollection",
        "features": [
            {"type": "Feature", "geometry": {"type": "Point", "coordinates": list(p)}}
            for p in points
        ],
    }


def _x(f: float) -> float:
    return _X0 + f * _D


def _y(f: float) -> float:
    return _Y0 + f * _D


# A curved (zig-zag) road crossing the square from bottom to top.
_CURVED_ROAD = [[_x(0.5), _y(-0.2)], [_x(0.4), _y(0.3)], [_x(0.6), _y(0.7)], [_x(0.5), _y(1.2)]]
# A horizontal road across the full square.
_HORIZONTAL_ROAD = [[_x(-0.2), _y(0.5)], [_x(1.2), _y(0.5)]]


def _assert_partition(zone_geom: dict, geometries: list[dict]) -> None:
    zone = shape(zone_geom)
    pieces = [shape(g) for g in geometries]
    union = unary_union(pieces)
    assert union.symmetric_difference(zone).area < zone.area * 1e-6
    total = sum(p.area for p in pieces)
    assert total == pytest.approx(zone.area, rel=1e-6)  # no overlaps


class TestSplitZoneByRoads:
    def test_boundary_follows_curved_road(self) -> None:
        zone = _zone([_SQUARE])
        geoms, fractions, stats = split_zone_by_roads(zone, _network(_CURVED_ROAD), None, 2)
        assert geoms is not None
        assert len(geoms) == 2
        assert stats["producedPieces"] == 2
        _assert_partition(zone["geometry"], geoms)
        a, b = (shape(g) for g in geoms)
        shared = a.boundary.intersection(b.boundary)
        road_in_zone = LineString(_CURVED_ROAD).intersection(shape(zone["geometry"]))
        # The shared boundary is the road itself (all its vertices), not a chord.
        assert shared.length == pytest.approx(road_in_zone.length, rel=1e-6)
        assert shared.hausdorff_distance(road_in_zone) < 1e-9
        assert sum(fractions) == pytest.approx(1.0)

    def test_exact_n_with_buildings_balanced(self) -> None:
        zone = _zone([_SQUARE])
        # Four quadrant blocks; buildings heavily in the bottom-left quadrant.
        buildings = _buildings(
            *[(_x(0.1 + 0.02 * i), _y(0.1)) for i in range(6)],
            (_x(0.75), _y(0.25)),
            (_x(0.25), _y(0.75)),
            (_x(0.75), _y(0.75)),
        )
        straight = [[_x(0.5), _y(-0.2)], [_x(0.5), _y(1.2)]]
        geoms, fractions, _ = split_zone_by_roads(
            zone, _network(straight, _HORIZONTAL_ROAD), buildings, 3
        )
        assert geoms is not None
        assert len(geoms) == 3
        _assert_partition(zone["geometry"], geoms)
        # The heavy quadrant stays on its own; the three light ones are grouped.
        assert max(fractions) == pytest.approx(6 / 9)
        assert sum(fractions) == pytest.approx(1.0)
        for g in geoms:
            assert shape(g).geom_type == "Polygon"  # groups are contiguous

    def test_area_fractions_without_buildings(self) -> None:
        zone = _zone([_SQUARE])
        road = [[_x(0.25), _y(-0.2)], [_x(0.25), _y(1.2)]]
        geoms, fractions, _ = split_zone_by_roads(zone, _network(road), None, 2)
        assert geoms is not None
        assert sorted(fractions) == pytest.approx([0.25, 0.75], rel=1e-3)

    def test_roads_outside_zone_ignored_and_fallback_bisects(self) -> None:
        zone = _zone([_SQUARE])
        outside = [[_x(2.0), _y(0.0)], [_x(2.0), _y(1.0)]]
        geoms, _fractions, _ = split_zone_by_roads(zone, _network(outside), None, 2)
        assert geoms is not None
        assert len(geoms) == 2
        _assert_partition(zone["geometry"], geoms)

    def test_more_pieces_than_blocks_uses_fallback(self) -> None:
        zone = _zone([_SQUARE])
        geoms, _fractions, _ = split_zone_by_roads(zone, _network(_CURVED_ROAD), None, 4)
        assert geoms is not None
        assert len(geoms) == 4
        _assert_partition(zone["geometry"], geoms)

    def test_multipolygon_keeps_all_parts(self) -> None:
        second = [[[c[0] + 2 * _D, c[1]] for c in _SQUARE]]
        zone = _zone([[_SQUARE], second], "MultiPolygon")
        geoms, _fractions, _ = split_zone_by_roads(zone, _network(), None, 2)
        assert geoms is not None
        assert len(geoms) == 2
        _assert_partition(zone["geometry"], geoms)

    def test_road_dangling_into_zone_does_not_split(self) -> None:
        zone = _zone([_SQUARE])
        dead_end = [[_x(0.5), _y(-0.2)], [_x(0.5), _y(0.5)]]
        geoms, _fractions, _ = split_zone_by_roads(
            zone, _network(dead_end, _HORIZONTAL_ROAD), None, 2
        )
        assert geoms is not None
        assert len(geoms) == 2
        _assert_partition(zone["geometry"], geoms)
        # Only the through road forms a boundary: halves are top and bottom.
        ys = sorted(shape(g).centroid.y for g in geoms)
        assert ys[0] < _y(0.5) < ys[1]

    def test_invalid_geometry_raises(self) -> None:
        with pytest.raises(ValueError):
            split_zone_by_roads(
                {"type": "Feature", "geometry": {"type": "Point", "coordinates": [0, 0]}},
                _network(),
                None,
                2,
            )

    def test_buildings_outside_zone_ignored(self) -> None:
        zone = _zone([_SQUARE])
        buildings = _buildings((_x(0.25), _y(0.5)), (_x(5.0), _y(5.0)))
        _geoms, _fractions, stats = split_zone_by_roads(zone, _network(_CURVED_ROAD), buildings, 2)
        assert stats["buildingCount"] == 1
