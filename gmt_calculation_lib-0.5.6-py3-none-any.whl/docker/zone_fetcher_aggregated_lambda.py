"""ZoneFetcherAggregated Lambda handler — thin I/O wrapper around zone_fetcher_aggregated domain.

Fetches CBS buurt centroids from Databricks SQL within a search radius and
greedily aggregates them down to a target STUDY/INFLUENCE zone count
(MobiliteitsScan's centroid-aggregation algorithm) for a bounding box, writing
a GeoParquet file to S3 or a local folder. Output is schema-compatible with
``zone-fetcher``.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)
DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "bbox":              [minLon, minLat, maxLon, maxLat],  // required
        "outputFolder":      "s3://bucket/prefix/",             // required
        "areaId":            "my-area",                         // optional (UUID generated)
        "name":              "Deventer centrum",                // optional
        "zonesStudiegebied": 150,                                // optional (default: 150)
        "zonesTotaal":       250,                                // optional (default: 250)
        "searchRadiusM":     100000,                             // optional (default: 100000)
        "catalog":           "spectrum",                         // optional (default: spectrum)
        "schema":            "2024_01"                           // optional (default: 2024_01)
    }
}

Response (200)
--------------
{
    "statusCode":     200,
    "status":         "successful",
    "areaId":         "...",
    "outputUri":      "...",
    "studyCount":     int,
    "influenceCount": int,
    "totalFeatures":  int
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback
from uuid import uuid4

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        import gmt_shared.databricks_sql as databricks_sql
        from gmt_shared.geoparquet import to_geoparquet
        from gmt_zone_core.zone_fetcher_aggregated.domain.sql import (
            bbox_to_polygon_json,
            bbox_to_polygon_ring,
            build_fetch_centroids_sql,
        )
        from gmt_zone_core.zone_fetcher_aggregated.domain.zone import (
            rows_to_feature_collection,
        )

        inputs: dict = event.get("inputs", {})

        bbox_raw = inputs.get("bbox")
        output_folder: str = inputs.get("outputFolder", "")
        if not bbox_raw:
            raise ValueError("inputs.bbox is required.")
        if not output_folder:
            raise ValueError("inputs.outputFolder is required.")

        bbox = [float(v) for v in bbox_raw]
        area_id: str = inputs.get("areaId", "") or str(uuid4())
        name: str = inputs.get("name", "")
        catalog: str = inputs.get("catalog", "spectrum")
        schema: str = inputs.get("schema", "2024_01")
        zones_studiegebied: int = int(inputs.get("zonesStudiegebied", 150))
        zones_totaal: int = int(inputs.get("zonesTotaal", 250))
        search_radius_m: float = float(inputs.get("searchRadiusM", 100_000.0))

        polygon_json = bbox_to_polygon_json(bbox)
        aoi_ring = bbox_to_polygon_ring(bbox)
        sql = build_fetch_centroids_sql(catalog, schema)

        with databricks_sql.connect_from_env() as conn, conn.cursor() as cur:
            cur.execute(sql, (polygon_json, search_radius_m))
            col_names = [d[0] for d in cur.description]
            rows = cur.fetchall()

        fc = rows_to_feature_collection(
            rows,
            col_names,
            area_id,
            bbox,
            aoi_ring,
            zones_within_target=zones_studiegebied,
            zones_total_target=zones_totaal,
        )
        if name:
            fc["properties"]["name"] = name

        study_count = fc["properties"]["studyCount"]
        influence_count = fc["properties"]["influenceCount"]
        total = len(fc["features"])

        output_folder = output_folder.rstrip("/") + "/"
        out_uri = f"{output_folder}{area_id}-ZONES.parquet"
        _write_uri(out_uri, to_geoparquet(fc))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "areaId": area_id,
            "outputUri": out_uri,
            "studyCount": study_count,
            "influenceCount": influence_count,
            "totalFeatures": total,
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
