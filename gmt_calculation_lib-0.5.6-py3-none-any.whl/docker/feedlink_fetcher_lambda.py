"""FeedlinkFetcher Lambda handler — thin I/O wrapper around feedlink_fetcher_core.

Fetches voedingslinks from Databricks for the zones produced by zone_fetcher and
builds a feedlink GeoParquet from the directed network.

Environment variables
---------------------
LOG_LEVEL  – DEBUG / INFO / WARNING / ERROR  (default: DEBUG)
DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET

Event structure (HTTP POST or direct invocation)
-------------------------------------------------
{
    "inputs": {
        "zonesUri":     "s3://bucket/key or local path",  // required
        "networkUri":   "s3://bucket/key or local path",  // required
        "outputFolder": "s3://bucket/prefix/",            // required
        "mode":         "CAR",                            // required
        "areaId":       "my-area",                        // optional (derived from network)
        "catalog":      "spectrum",                       // optional (default: spectrum)
        "schema":       "2024_01",                        // optional (default: 2024_01)
        "majorRoadSpeedKph": 50                           // optional (default: 50) — see below
    }
}

A zone not covered by a Databricks voedingslinks row attaches via a fallback
feedlink to the nearest network node connected to a link faster than
``majorRoadSpeedKph`` (instead of literally the nearest node in space),
falling back to any node when no such major-road node exists nearby.

Response (200)
--------------
{
    "statusCode":  200,
    "status":      "successful",
    "outputUri":   "...",
    "feedlinks":   int
}
"""

from __future__ import annotations

import json
import logging
import os
import traceback
from uuid import uuid4

_LOG_LEVEL = getattr(logging, os.environ.get("LOG_LEVEL", "DEBUG").upper(), logging.DEBUG)
logging.basicConfig(format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s")
logger = logging.getLogger(__name__)
logger.setLevel(_LOG_LEVEL)


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    with open(uri, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split
        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    os.makedirs(os.path.dirname(os.path.abspath(uri)), exist_ok=True)
    with open(uri, "wb") as fh:
        fh.write(data)


def handler(event: dict, context: object) -> dict:
    """AWS Lambda entry point.  Supports API Gateway v1/v2 and direct invocation."""
    _is_apigw_v2 = event.get("version") == "2.0" and "requestContext" in event
    _is_apigw_v1 = "httpMethod" in event

    if _is_apigw_v2 or _is_apigw_v1:
        raw_body = event.get("body") or "{}"
        try:
            body_data: dict = json.loads(raw_body) if isinstance(raw_body, str) else raw_body
        except (json.JSONDecodeError, ValueError) as exc:
            return {
                "statusCode": 400,
                "headers": {"Content-Type": "application/json"},
                "body": json.dumps({"error": "Invalid JSON body", "message": str(exc)}),
            }
        internal = handler({"inputs": body_data.get("inputs", {})}, context)
        return {
            "statusCode": internal.get("statusCode", 500),
            "headers": {"Content-Type": "application/json"},
            "body": json.dumps(internal),
        }

    request_id = getattr(context, "aws_request_id", "local") if context else "local"
    logger.info("Invocation start [request_id=%s]", request_id)

    try:
        import gmt_shared.databricks_sql as databricks_sql
        from gmt_network_core.feedlink_fetcher.core.feedlink_fetcher_core import (
            VOEDINGSLINKS_TABLE,
            build_feedlinks,
            build_voedingslinks_sql,
            major_road_node_ids,
            parse_network_geojson,
        )
        from gmt_shared.geoparquet import from_geoparquet, to_geoparquet
        from gmt_shared.output_path import build_output_path

        inputs: dict = event.get("inputs", {})

        zones_uri: str = inputs.get("zonesUri", "")
        network_uri: str = inputs.get("networkUri", "")
        output_folder: str = inputs.get("outputFolder", "")
        mode_raw: str = inputs.get("mode", "")
        if not zones_uri:
            raise ValueError("inputs.zonesUri is required.")
        if not network_uri:
            raise ValueError("inputs.networkUri is required.")
        if not output_folder:
            raise ValueError("inputs.outputFolder is required.")
        if not mode_raw:
            raise ValueError("inputs.mode is required.")

        mode = mode_raw.upper()
        catalog: str = inputs.get("catalog", "spectrum")
        schema: str = inputs.get("schema", "2024_01")
        major_road_speed_kph: float = float(inputs.get("majorRoadSpeedKph", 50.0))

        logger.info("Reading zones   : %s", zones_uri)
        zones_fc = from_geoparquet(_read_uri(zones_uri))

        logger.info("Reading network : %s", network_uri)
        network_fc = from_geoparquet(_read_uri(network_uri))

        area_id: str = (
            inputs.get("areaId", "")
            or (network_fc.get("properties") or {}).get("area_id")
            or str(uuid4())
        )

        node_positions, all_node_ids = parse_network_geojson(network_fc)
        major_node_ids = major_road_node_ids(network_fc, min_speed_kph=major_road_speed_kph)

        # Query Databricks voedingslinks
        table_name = VOEDINGSLINKS_TABLE.get(mode)
        vl_rows: list = []
        if table_name:
            gids = [
                int(feat["properties"]["gid"])
                for feat in zones_fc.get("features") or []
                if (feat.get("properties") or {}).get("zoneClass") != "AREA"
                and (feat.get("properties") or {}).get("gid") is not None
            ]
            logger.info("Querying Databricks: table=%r  gids=%d", table_name, len(gids))
            sql = build_voedingslinks_sql(catalog, schema, table_name, gids)
            with databricks_sql.connect_from_env() as conn, conn.cursor() as cur:
                cur.execute(sql)
                col_names = [d[0] for d in cur.description]
                vl_rows = [dict(zip(col_names, row)) for row in cur.fetchall()]
            logger.info("Voedingslinks rows: %d", len(vl_rows))

        feedlinks_fc = build_feedlinks(
            zones_fc, node_positions, all_node_ids, vl_rows, mode, major_node_ids=major_node_ids
        )
        feedlinks_fc.setdefault("properties", {})["area_id"] = area_id

        out_uri = build_output_path(output_folder, area_id, "FEEDLINK", mode)
        _write_uri(out_uri, to_geoparquet(feedlinks_fc))

        logger.info("Invocation complete [request_id=%s]", request_id)
        return {
            "statusCode": 200,
            "status": "successful",
            "outputUri": out_uri,
            "feedlinks": len(feedlinks_fc["features"]),
        }

    except (KeyError, ValueError, TypeError) as exc:
        logger.warning("Bad request [request_id=%s]: %s", request_id, exc)
        return {"statusCode": 400, "error": "Bad request", "message": str(exc)}
    except Exception as exc:
        logger.error(
            "Internal error [request_id=%s]: %s\n%s",
            request_id, exc, traceback.format_exc(),
        )
        return {
            "statusCode": 500,
            "error": "Internal error",
            "message": str(exc),
            "detail": traceback.format_exc(),
        }
