"""Tests for feedlink_fetcher core domain logic."""

from __future__ import annotations

import pytest

from gmt_network_core.feedlink_fetcher.domain.feedlink import (
    FEEDLINK_PROPERTIES,
    _find_nearest_node,
    build_feedlinks,
)
from gmt_network_core.feedlink_fetcher.domain.network import (
    major_road_node_ids,
    parse_network_geojson,
)
from gmt_network_core.feedlink_fetcher.domain.sql import (
    VOEDINGSLINKS_TABLE,
    build_voedingslinks_sql,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_zone_feature(
    gid: int,
    zone_id: str,
    zone_class: str = "STUDY",
    production: float = 100.0,
    attraction: float = 80.0,
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [6.0, 52.0]},
        "properties": {
            "gid": gid,
            "zoneId": zone_id,
            "zoneClass": zone_class,
            "centroidLon": 6.0,
            "centroidLat": 52.0,
            "production": production,
            "attraction": attraction,
        },
    }


def _make_link_feature(
    from_node: str,
    to_node: str,
    from_coords: list,
    to_coords: list,
    speed: float | None = None,
) -> dict:
    props: dict[str, object] = {
        "linkId": f"{from_node}-{to_node}",
        "fromNode": from_node,
        "toNode": to_node,
    }
    if speed is not None:
        props["speed"] = speed
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [from_coords, to_coords]},
        "properties": props,
    }


def _zones_fc(*features) -> dict:
    return {"type": "FeatureCollection", "features": list(features)}


def _network_fc(*features) -> dict:
    return {"type": "FeatureCollection", "features": list(features)}


# ---------------------------------------------------------------------------
# parse_network_geojson
# ---------------------------------------------------------------------------


class TestParseNetworkGeojson:
    def test_basic_two_nodes(self):
        fc = _network_fc(
            _make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1]),
        )
        pos, ids = parse_network_geojson(fc)
        assert ids == {"A", "B"}
        assert pos["A"] == (6.0, 52.0)
        assert pos["B"] == (6.1, 52.1)

    def test_empty_network(self):
        pos, ids = parse_network_geojson({"type": "FeatureCollection", "features": []})
        assert ids == set()
        assert pos == {}

    def test_duplicate_nodes_keep_first_position(self):
        fc = _network_fc(
            _make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1]),
            _make_link_feature(
                "A", "C", [6.9, 52.9], [6.2, 52.2]
            ),  # A seen again, different coords
        )
        pos, ids = parse_network_geojson(fc)
        # First-seen position is retained
        assert pos["A"] == (6.0, 52.0)
        assert "C" in ids

    def test_feature_without_geometry_skipped(self):
        fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": None,
                    "properties": {"fromNode": "X", "toNode": "Y"},
                },
            ],
        }
        _pos, ids = parse_network_geojson(fc)
        assert ids == set()


# ---------------------------------------------------------------------------
# build_voedingslinks_sql
# ---------------------------------------------------------------------------


class TestBuildVoedingslinksSql:
    def test_single_gid(self):
        sql = build_voedingslinks_sql("cat", "sch", "d110_voedingslinks", [42])
        assert "van_centroid_gid IN (42)" in sql
        assert "`cat`.`sch`.d110_voedingslinks" in sql

    def test_multiple_gids(self):
        sql = build_voedingslinks_sql("cat", "sch", "d110_voedingslinks", [1, 2, 3])
        assert "1, 2, 3" in sql

    def test_empty_gids_gives_where_false(self):
        sql = build_voedingslinks_sql("cat", "sch", "d110_voedingslinks", [])
        assert "WHERE FALSE" in sql

    def test_required_columns_present(self):
        sql = build_voedingslinks_sql("cat", "sch", "tbl", [1])
        for col in ("van_centroid_gid", "naar_knoop_id", "wkt_geom_4326"):
            assert col in sql

    def test_other_schema_uses_geom_4326(self):
        """Non-2024_01 schemas select geom_4326 directly."""
        sql = build_voedingslinks_sql("cat", "2025_01", "tbl", [1])
        assert "ST_AsText(geom_4326)" in sql
        assert "ST_Transform" not in sql

    def test_2024_01_transforms_geom_28992_to_4326(self):
        """2024_01 transforms geom_28992 to WGS-84 for consistent output."""
        sql = build_voedingslinks_sql("cat", "2024_01", "tbl", [1])
        assert "ST_AsText(ST_Transform(geom_28992, 4326))" in sql
        assert "ST_AsText(geom_4326)" not in sql  # raw geom_4326 column not used


class TestVoedingslinksTable:
    def test_car_has_table(self):
        assert VOEDINGSLINKS_TABLE["CAR"] == "d110_voedingslinks"

    def test_bike_has_table(self):
        assert VOEDINGSLINKS_TABLE["BIKE"] == "d120_voedingslinks"

    def test_pedestrian_is_none(self):
        assert VOEDINGSLINKS_TABLE["PEDESTRIAN"] is None


# ---------------------------------------------------------------------------
# build_feedlinks
# ---------------------------------------------------------------------------


def _vl_row(gid: int, node_id: str) -> dict:
    return {
        "van_centroid_gid": gid,
        "naar_knoop_id": node_id,
        "wkt_geom_4326": None,
    }


class TestBuildFeedlinks:
    def _run(self, zones_fc, network_fc, vl_rows, mode="CAR"):
        pos, ids = parse_network_geojson(network_fc)
        return build_feedlinks(zones_fc, pos, ids, vl_rows, mode)

    def test_production_and_attraction_created(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=100.0, attraction=80.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        props = [f["properties"] for f in fc["features"]]
        assert any(p["fromNode"] == "1" and p["toNode"] == "N1" for p in props), (
            "production missing"
        )
        assert any(p["fromNode"] == "N1" and p["toNode"] == "1" for p in props), (
            "attraction missing"
        )

    def test_area_zone_skipped(self):
        zones = _zones_fc(
            _make_zone_feature(1, "Z1", zone_class="AREA", production=100.0),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        assert fc["features"] == []

    def test_node_not_in_network_triggers_fallback(self):
        """When the vl_row references a missing node, the zone gets a fallback feedlink
        to the nearest real network node instead of being silently dropped."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "NONEXISTENT")])
        # Fallback to N1 (nearest node)
        node_ids = {
            f["properties"]["toNode"] for f in fc["features"] if f["properties"]["fromNode"] == "1"
        }
        assert len(node_ids) == 1
        assert node_ids.pop() in {"N1", "N2"}

    def test_zero_production_suppressed(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=50.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        props = [f["properties"] for f in fc["features"]]
        assert all(p["fromNode"] != "1" for p in props), "production feedlink should be absent"
        assert any(p["toNode"] == "1" for p in props), "attraction feedlink should be present"

    def test_zero_attraction_suppressed(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=50.0, attraction=0.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        props = [f["properties"] for f in fc["features"]]
        assert any(p["fromNode"] == "1" for p in props), "production feedlink should be present"
        assert all(p["toNode"] != "1" for p in props), "attraction feedlink should be absent"

    def test_feedlink_properties_present(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        for feat in fc["features"]:
            for key in FEEDLINK_PROPERTIES:
                assert key in feat["properties"], f"Missing property {key!r}"

    def test_capacity_equals_production_or_attraction(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=123.0, attraction=456.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        caps = {f["properties"]["capacity"] for f in fc["features"]}
        assert 123.0 in caps
        assert 456.0 in caps

    def test_multiple_zones(self):
        zones = _zones_fc(
            _make_zone_feature(1, "Z1", production=10.0, attraction=10.0),
            _make_zone_feature(2, "Z2", production=20.0, attraction=20.0),
        )
        net = _network_fc(
            _make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]),
            _make_link_feature("N3", "N4", [6.2, 52.2], [6.3, 52.3]),
        )
        fc = self._run(zones, net, [_vl_row(1, "N1"), _vl_row(2, "N3")])
        zone_ids = {f["properties"]["zoneId"] for f in fc["features"]}
        assert "Z1" in zone_ids
        assert "Z2" in zone_ids

    def test_empty_vl_rows_triggers_fallback(self):
        """No voedingslinks rows → all zones are uncovered → fallback feedlinks created."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        assert len(fc["features"]) > 0

    def test_output_is_feature_collection(self):
        fc = self._run(_zones_fc(), _network_fc(), [])
        assert fc["type"] == "FeatureCollection"
        assert "features" in fc

    def test_mode_stored_on_feedlink(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")], mode="BIKE")
        for feat in fc["features"]:
            assert feat["properties"]["mode"] == "BIKE"

    def test_feedlink_ids_sequential(self):
        zones = _zones_fc(
            _make_zone_feature(1, "Z1"),
            _make_zone_feature(2, "Z2"),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1"), _vl_row(2, "N1")])
        ids = [f["properties"]["feedlinkId"] for f in fc["features"]]
        assert ids == sorted(ids)
        assert len(set(ids)) == len(ids), "feedlinkIds must be unique"

    def test_reverse_link_ids_cross_reference(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        feats = fc["features"]
        assert len(feats) == 2
        prod = next(f for f in feats if f["properties"]["fromNode"] == "1")
        attr = next(f for f in feats if f["properties"]["toNode"] == "1")
        assert prod["properties"]["reverseLinkIds"] == [attr["properties"]["feedlinkId"]]
        assert attr["properties"]["reverseLinkIds"] == [prod["properties"]["feedlinkId"]]

    def test_geometry_is_linestring(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        for feat in fc["features"]:
            assert feat["geometry"]["type"] == "LineString"

    def test_influence_zone_included(self):
        zones = _zones_fc(_make_zone_feature(3, "Z3", zone_class="INFLUENCE"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(3, "N1")])
        assert len(fc["features"]) > 0

    def test_covered_zero_production_and_attraction_gets_connectivity_feedlink(self):
        """A zone covered by a vl_row but with 0 production and 0 attraction
        still gets a zero-capacity connectivity feedlink."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=0.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 1
        assert z1_feats[0]["properties"]["capacity"] == 0.0
        assert z1_feats[0]["properties"]["source"] == "databricks-connectivity"

    def test_databricks_feedlinks_have_source_databricks(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        for feat in fc["features"]:
            assert feat["properties"]["source"] == "databricks"


# ---------------------------------------------------------------------------
# _find_nearest_node
# ---------------------------------------------------------------------------


class TestFindNearestNode:
    def test_single_node_is_nearest(self):
        node_id, dist = _find_nearest_node(6.0, 52.0, {"N1": (6.0, 52.0)})
        assert node_id == "N1"
        assert dist == pytest.approx(0.0, abs=1e-3)

    def test_nearest_of_two_nodes(self):
        nodes = {
            "NEAR": (6.001, 52.0),  # ~70 m away
            "FAR": (6.1, 52.0),  # ~7 km away
        }
        node_id, _ = _find_nearest_node(6.0, 52.0, nodes)
        assert node_id == "NEAR"

    def test_empty_nodes_returns_none(self):
        node_id, dist = _find_nearest_node(6.0, 52.0, {})
        assert node_id is None
        assert dist == float("inf")

    def test_major_node_ids_prefers_major_road_over_nearer_minor_node(self):
        """A farther node on a major road wins over a geometrically closer
        node that isn't connected to one."""
        nodes = {
            "MINOR_NEAR": (6.001, 52.0),  # ~70 m away, not a major-road node
            "MAJOR_FAR": (6.01, 52.0),  # ~700 m away, major-road node
        }
        node_id, _ = _find_nearest_node(6.0, 52.0, nodes, major_node_ids={"MAJOR_FAR"})
        assert node_id == "MAJOR_FAR"

    def test_major_node_ids_falls_back_to_all_nodes_when_none_match(self):
        """When no node intersects major_node_ids, the search degrades to the
        full node set instead of returning nothing."""
        nodes = {"NEAR": (6.001, 52.0), "FAR": (6.1, 52.0)}
        node_id, _ = _find_nearest_node(6.0, 52.0, nodes, major_node_ids={"NOT_PRESENT"})
        assert node_id == "NEAR"

    def test_empty_major_node_ids_behaves_like_none(self):
        nodes = {"NEAR": (6.001, 52.0), "FAR": (6.1, 52.0)}
        node_id, _ = _find_nearest_node(6.0, 52.0, nodes, major_node_ids=set())
        assert node_id == "NEAR"


# ---------------------------------------------------------------------------
# major_road_node_ids
# ---------------------------------------------------------------------------


class TestMajorRoadNodeIds:
    def test_only_fast_links_contribute_nodes(self):
        fc = _network_fc(
            _make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1], speed=80.0),
            _make_link_feature("C", "D", [6.2, 52.2], [6.3, 52.3], speed=30.0),
        )
        assert major_road_node_ids(fc) == {"A", "B"}

    def test_default_threshold_is_50_kph_exclusive(self):
        fc = _network_fc(_make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1], speed=50.0))
        assert major_road_node_ids(fc) == set()
        fc2 = _network_fc(_make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1], speed=50.1))
        assert major_road_node_ids(fc2) == {"A", "B"}

    def test_missing_speed_property_is_treated_as_zero(self):
        fc = _network_fc(_make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1]))
        assert major_road_node_ids(fc) == set()

    def test_custom_threshold(self):
        fc = _network_fc(_make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1], speed=40.0))
        assert major_road_node_ids(fc, min_speed_kph=30.0) == {"A", "B"}
        assert major_road_node_ids(fc, min_speed_kph=60.0) == set()

    def test_empty_network(self):
        assert major_road_node_ids(_network_fc()) == set()


# ---------------------------------------------------------------------------
# Fallback feedlink behaviour in build_feedlinks
# ---------------------------------------------------------------------------


class TestFallbackFeedlinks:
    def _run(self, zones_fc, network_fc, vl_rows, mode="CAR", major_node_ids=None):
        pos, ids = parse_network_geojson(network_fc)
        return build_feedlinks(zones_fc, pos, ids, vl_rows, mode, major_node_ids=major_node_ids)

    def test_uncovered_zone_gets_fallback_feedlink(self):
        """Zone with no vl_row at all must receive a fallback feedlink."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        zone_ids = {f["properties"]["zoneId"] for f in fc["features"]}
        assert "Z1" in zone_ids

    def test_covered_zone_does_not_get_extra_fallback(self):
        """A zone linked by a valid vl_row must NOT also appear as a fallback."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        # Should have exactly 2 feedlinks (production + attraction), not 4
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 2

    def test_fallback_uses_nearest_node(self):
        """Among multiple nodes the fallback picks the closest one."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        # Z1 centroid at (6.0, 52.0) — N_NEAR is much closer than N_FAR
        net = _network_fc(
            _make_link_feature("N_NEAR", "X1", [6.001, 52.0], [6.002, 52.0]),
            _make_link_feature("N_FAR", "X2", [6.5, 52.0], [6.6, 52.0]),
        )
        fc = self._run(zones, net, [])
        prod = next(f for f in fc["features"] if f["properties"]["fromNode"] == "1")
        assert prod["properties"]["toNode"] == "N_NEAR"

    def test_fallback_prefers_major_road_node_over_nearer_minor_node(self):
        """With major_node_ids given, the fallback must skip a nearer node
        that isn't on a major road in favour of a farther one that is."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(
            _make_link_feature("N_NEAR_MINOR", "X1", [6.001, 52.0], [6.002, 52.0], speed=30.0),
            _make_link_feature("N_FAR_MAJOR", "X2", [6.01, 52.0], [6.02, 52.0], speed=80.0),
        )
        major_ids = major_road_node_ids(net)
        assert major_ids == {"N_FAR_MAJOR", "X2"}
        fc = self._run(zones, net, [], major_node_ids=major_ids)
        prod = next(f for f in fc["features"] if f["properties"]["fromNode"] == "1")
        assert prod["properties"]["toNode"] == "N_FAR_MAJOR"

    def test_fallback_zero_production_and_attraction_gets_connectivity_feedlink(self):
        """Zone with 0 production and 0 attraction still gets a zero-capacity
        connectivity feedlink instead of being left out entirely."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=0.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 1
        assert z1_feats[0]["properties"]["capacity"] == 0.0
        assert z1_feats[0]["properties"]["source"] == "fallback-connectivity"

    def test_fallback_zero_production_and_attraction_no_network_gives_no_feedlink(self):
        """Without any network node, even the connectivity fallback can't be built."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=0.0))
        net = _network_fc()
        fc = self._run(zones, net, [])
        assert fc["features"] == []

    def test_fallback_empty_network_no_feedlinks(self):
        """If the network is empty no fallback feedlinks can be created."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc()
        fc = self._run(zones, net, [])
        assert fc["features"] == []

    def test_fallback_feedlink_properties_present(self):
        """All FEEDLINK_PROPERTIES must be present on fallback feedlinks."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        for feat in fc["features"]:
            for key in FEEDLINK_PROPERTIES:
                assert key in feat["properties"], f"Missing property {key!r}"

    def test_fallback_geometry_is_linestring(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        for feat in fc["features"]:
            assert feat["geometry"]["type"] == "LineString"

    def test_fallback_feedlink_ids_unique_across_vl_and_fallback(self):
        """IDs from the vl_rows loop and the fallback loop must not overlap."""
        zones = _zones_fc(
            _make_zone_feature(1, "Z1"),
            _make_zone_feature(2, "Z2"),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        # Z1 covered by vl_row, Z2 uncovered → gets fallback
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        ids = [f["properties"]["feedlinkId"] for f in fc["features"]]
        assert len(set(ids)) == len(ids), "feedlinkIds must be unique"

    def test_fallback_mode_stored_on_feedlink(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [], mode="PEDESTRIAN")
        for feat in fc["features"]:
            assert feat["properties"]["mode"] == "PEDESTRIAN"

    def test_fallback_feedlinks_have_source_fallback(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        for feat in fc["features"]:
            assert feat["properties"]["source"] == "fallback"

    def test_mixed_source_values_correct(self):
        """Z1 covered by Databricks, Z2 gets fallback — sources must differ."""
        zones = _zones_fc(
            _make_zone_feature(1, "Z1"),
            _make_zone_feature(2, "Z2"),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        z1_sources = {
            f["properties"]["source"] for f in fc["features"] if f["properties"]["zoneId"] == "Z1"
        }
        z2_sources = {
            f["properties"]["source"] for f in fc["features"] if f["properties"]["zoneId"] == "Z2"
        }
        assert z1_sources == {"databricks"}
        assert z2_sources == {"fallback"}

    def test_negative_gid_aggregated_zone_gets_fallback_alongside_covered_real_zone(self):
        """Integration contract with zone_fetcher_aggregated: a normal positive-gid
        zone covered by a vl_row keeps its databricks-sourced feedlinks unaffected,
        while a STUDY/INFLUENCE zone with a negative synthetic gid (never present in
        vl_rows, by construction) falls through to the fallback path — getting both
        a production (outbound) and attraction (inbound) feedlink attached to the
        nearest major-road node."""
        zones = _zones_fc(
            _make_zone_feature(1, "Z1", zone_class="STUDY", production=10.0, attraction=10.0),
            _make_zone_feature(-1, "AGG1", zone_class="INFLUENCE", production=5.0, attraction=5.0),
        )
        net = _network_fc(
            _make_link_feature("N1", "X1", [6.0, 52.0], [6.1, 52.1]),
            _make_link_feature("N_NEAR_MINOR", "X2", [6.001, 52.0], [6.002, 52.0], speed=30.0),
            _make_link_feature("N_FAR_MAJOR", "X3", [6.01, 52.0], [6.02, 52.0], speed=80.0),
        )
        major_ids = major_road_node_ids(net)
        fc = self._run(zones, net, [_vl_row(1, "N1")], major_node_ids=major_ids)

        # Real zone Z1: unaffected, still sourced from databricks.
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 2
        assert {f["properties"]["source"] for f in z1_feats} == {"databricks"}

        # Aggregated zone AGG1 (negative gid, no vl_row): fallback path, both
        # production (outbound) and attraction (inbound) feedlinks, attached to
        # the nearest major-road node rather than the nearer minor-road one.
        agg_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "AGG1"]
        assert len(agg_feats) == 2
        assert {f["properties"]["source"] for f in agg_feats} == {"fallback"}
        prod = next(f for f in agg_feats if f["properties"]["fromNode"] == "-1")
        attr = next(f for f in agg_feats if f["properties"]["toNode"] == "-1")
        assert prod["properties"]["toNode"] == "N_FAR_MAJOR"
        assert attr["properties"]["fromNode"] == "N_FAR_MAJOR"

    def test_pedestrian_mode_all_zones_get_fallback(self):
        """PEDESTRIAN has no Databricks table so all zones should be linked via fallback."""
        zones = _zones_fc(
            _make_zone_feature(1, "Z1"),
            _make_zone_feature(2, "Z2"),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        # Simulate PEDESTRIAN: vl_rows is always empty
        fc = self._run(zones, net, [], mode="PEDESTRIAN")
        zone_ids = {f["properties"]["zoneId"] for f in fc["features"]}
        assert "Z1" in zone_ids
        assert "Z2" in zone_ids
