"""Network GeoJSON parser for feedlink_fetcher — extracts node positions."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def parse_network_geojson(fc: dict) -> tuple[dict, set]:
    """Parse a network FeatureCollection into node lookup tables.

    Parameters
    ----------
    fc:
        GeoJSON FeatureCollection of directed network link features.

    Returns
    -------
    tuple[dict, set]
        ``(node_positions, all_node_ids)`` where *node_positions* maps
        ``node_id → (lon, lat)`` and *all_node_ids* is the complete set of
        node IDs seen in the network.
    """
    features = fc.get("features") or []
    node_positions: dict = {}

    for feat in features:
        props = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords:
            continue
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is not None:
            node_positions.setdefault(from_node, (coords[0][0], coords[0][1]))
        if to_node is not None:
            node_positions.setdefault(to_node, (coords[-1][0], coords[-1][1]))

    all_node_ids = set(node_positions.keys())
    logger.info("Parsed network: %d features, %d nodes", len(features), len(all_node_ids))
    return node_positions, all_node_ids


def major_road_node_ids(fc: dict, min_speed_kph: float = 50.0) -> set:
    """Return node ids that are an endpoint of at least one link faster than
    *min_speed_kph*.

    Used to bias feedlink attachment (see
    ``feedlink.build_feedlinks``/``feedlink._find_nearest_node``) toward nodes
    that actually sit on a significant road, instead of literally the nearest
    point in space — which could be the endpoint of a minor residential or
    service road that happens to be geometrically close to the zone centroid.

    Parameters
    ----------
    fc:
        GeoJSON FeatureCollection of directed network link features, each
        with a ``speed`` property (km/h) and ``fromNode``/``toNode`` properties.
    min_speed_kph:
        Speed threshold in km/h; a link's endpoints are included when its
        ``speed`` is strictly greater than this value. Default: ``50.0``.
    """
    features = fc.get("features") or []
    node_ids: set = set()
    for feat in features:
        props = feat.get("properties") or {}
        speed = float(props.get("speed") or 0.0)
        if speed <= min_speed_kph:
            continue
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is not None:
            node_ids.add(from_node)
        if to_node is not None:
            node_ids.add(to_node)
    logger.info(
        "Found %d major-road (>%.0f km/h) node(s) out of %d link features",
        len(node_ids),
        min_speed_kph,
        len(features),
    )
    return node_ids
