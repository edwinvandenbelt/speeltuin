"""Local debug runner for feedlink_fetcher.

Fetches voedingslinks from Databricks for the zones produced by zone_fetcher
and builds a feedlink GeoJSON from the directed network.

Usage
-----
    python -m feedlink_fetcher.feedlink_fetcher_runner \\
        --zones-file  output/{areaId}-ZONES.parquet \\
        --network-file output/{areaId}-NETWORK-CAR.parquet \\
        --output-folder output/ \\
        --area-id <uuid> --mode CAR

    # Output: output/{areaId}-FEEDLINK-CAR.parquet

Prerequisites
-------------
* Databricks credentials in tools/.env or environment variables:
  DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID and one of:
  - DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET  (OAuth M2M, preferred)
  - DATABRICKS_TOKEN  (personal access token, fallback)
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        return get_bytes_s3(bucket, key)
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Local runner for feedlink_fetcher (fetches voedingslinks from Databricks)."
    )
    parser.add_argument(
        "--zones-file",
        required=True,
        metavar="URI",
        help="Full URI of the zones GeoJSON produced by zone_fetcher (s3:// or local path).",
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="Full URI of the directed network GeoJSON (s3:// or local path).",
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help="Output folder URI (s3://bucket/prefix/ or local directory).",
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help="Area identifier.  Resolved from network properties when omitted.",
    )
    parser.add_argument("--mode", required=True, help="Transport mode, e.g. CAR")
    parser.add_argument("--catalog", default="spectrum", help="Databricks Unity Catalog name")
    parser.add_argument("--schema", default="2024_01", help="Databricks schema / dataset version")
    parser.add_argument(
        "--major-road-speed-kph",
        type=float,
        default=50.0,
        metavar="KPH",
        help=(
            "Speed threshold (km/h) above which a network link counts as a 'major road' for "
            "fallback feedlink attachment — a zone with no voedingslinks row attaches to the "
            "nearest node connected to such a road rather than literally the nearest node in "
            "space. Default: 50."
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    import gmt_shared.databricks_sql as databricks_sql
    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet
    from gmt_shared.output_path import build_output_path

    from gmt_network_core.feedlink_fetcher.core.feedlink_fetcher_core import (
        VOEDINGSLINKS_TABLE,
        build_feedlinks,
        build_voedingslinks_sql,
        major_road_node_ids,
        parse_network_geojson,
    )

    mode = args.mode.upper()

    # 1. Read input files
    print(f"Reading zones   : {args.zones_file}")
    zones_fc = from_geoparquet(_read_uri(args.zones_file))
    print(f"Reading network : {args.network_file}")
    network_fc = from_geoparquet(_read_uri(args.network_file))

    # Resolve area_id
    area_id = args.area_id or (network_fc.get("properties") or {}).get("area_id")
    if not area_id:
        from uuid import uuid4

        area_id = str(uuid4())
        print(f"area_id auto-generated: {area_id}")

    # 2. Parse network
    node_positions, all_node_ids = parse_network_geojson(network_fc)
    major_node_ids = major_road_node_ids(network_fc, min_speed_kph=args.major_road_speed_kph)
    print(f"Major-road (>{args.major_road_speed_kph:.0f} km/h) nodes : {len(major_node_ids)}")

    # 3. Query Databricks voedingslinks
    table_name = VOEDINGSLINKS_TABLE.get(mode)
    vl_rows: list = []
    if table_name:
        # Negative gids are synthetic zone_fetcher_aggregated zones (STUDY/INFLUENCE
        # aggregates) and can never have a voedingslinks row — exclude them from the
        # Databricks query so they flow through build_feedlinks' fallback path instead.
        gids = [
            int(gid)
            for feat in zones_fc.get("features") or []
            if (feat.get("properties") or {}).get("zoneClass") != "AREA"
            and (gid := (feat.get("properties") or {}).get("gid")) is not None
            and int(gid) >= 0
        ]
        print(f"Querying Databricks: table={table_name!r}  gids={len(gids)}")
        sql = build_voedingslinks_sql(args.catalog, args.schema, table_name, gids)
        with databricks_sql.connect_from_env() as conn, conn.cursor() as cur:
            cur.execute(sql)
            col_names = [d[0] for d in cur.description]
            vl_rows = [dict(zip(col_names, row, strict=False)) for row in cur.fetchall()]
        print(f"Voedingslinks rows : {len(vl_rows)}")
    else:
        print(f"No voedingslinks table for mode {mode!r} — skipping Databricks query.")

    # 4. Build feedlinks
    feedlinks_fc = build_feedlinks(
        zones_fc, node_positions, all_node_ids, vl_rows, mode, major_node_ids=major_node_ids
    )
    feedlinks_fc.setdefault("properties", {})["area_id"] = area_id
    print(f"Feedlinks produced : {len(feedlinks_fc['features'])}")

    # 5. Write output
    out_uri = build_output_path(args.output_folder, area_id, "FEEDLINK", mode)
    print(f"Writing feedlinks : {out_uri}")
    _write_uri(out_uri, to_geoparquet(feedlinks_fc))

    print("Done.")


if __name__ == "__main__":
    main()
