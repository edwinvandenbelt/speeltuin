"""Tests for network_simplifier_core.simplify_network."""

from __future__ import annotations

import pytest

from gmt_network_core.network_simplifier.core.network_simplifier_core import simplify_network

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _link(
    link_id: int,
    from_node: int,
    to_node: int,
    *,
    heen: bool = True,
    terug: bool = True,
    spd_heen: float = 100.0,
    spd_terug: float = 100.0,
    cap_heen: float = 2000.0,
    cap_terug: float = 2000.0,
    rij_heen: int = 2,
    rij_terug: int = 2,
    flow_h: float = 10.0,
    flow_t: float = 5.0,
    length: float = 100.0,
    street: str = "TestStreet",
) -> dict:
    coords = [[0.0, float(from_node)], [0.0, float(to_node)]]
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "mode": "CAR",
            "fromNode": from_node,
            "toNode": to_node,
            "rijrichting_heen": heen,
            "rijrichting_terug": terug,
            "max_snelheid_heen": spd_heen,
            "max_snelheid_terug": spd_terug,
            "cap_heen": cap_heen,
            "cap_terug": cap_terug,
            "rijstroken_heen": rij_heen,
            "rijstroken_terug": rij_terug,
            "flow_heen": {
                "work": flow_h,
                "recreational": 0.0,
                "education": 0.0,
                "shopping": 0.0,
                "unknown": 0.0,
            },
            "flow_terug": {
                "work": flow_t,
                "recreational": 0.0,
                "education": 0.0,
                "shopping": 0.0,
                "unknown": 0.0,
            },
            "flow_dp_heen": {"mrh": 0.0, "erh": 0.0, "rest": 0.0},
            "flow_dp_terug": {"mrh": 0.0, "erh": 0.0, "rest": 0.0},
            "length": length,
            "streetName": street,
        },
    }


def _fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features)}


# ---------------------------------------------------------------------------
# Basic simplification
# ---------------------------------------------------------------------------


class TestSimplifyNetwork:
    def test_empty_fc_returns_empty(self):
        result, stats = simplify_network(_fc())
        assert result["features"] == []
        assert stats["original_links"] == 0
        assert stats["removed_nodes"] == 0

    def test_single_link_unchanged(self):
        fc = _fc(_link(1, 1, 2))
        result, stats = simplify_network(fc)
        assert len(result["features"]) == 1
        assert stats["removed_nodes"] == 0
        assert stats["final_links"] == 1

    def test_two_links_no_shared_pass_through_node(self):
        """A—B and C—D share no nodes: nothing to simplify."""
        fc = _fc(_link(1, 1, 2), _link(2, 3, 4))
        result, stats = simplify_network(fc)
        assert len(result["features"]) == 2
        assert stats["removed_nodes"] == 0

    def test_simple_bidirectional_chain_a_b_c(self):
        """A—B—C where B has degree 2 and is fully bidirectional: merges to A—C."""
        fc = _fc(_link(1, 1, 2), _link(2, 2, 3))
        result, stats = simplify_network(fc)
        assert len(result["features"]) == 1
        assert stats["removed_nodes"] == 1
        assert stats["merged_links"] == 1
        p = result["features"][0]["properties"]
        assert p["fromNode"] == 1
        assert p["toNode"] == 3
        assert p["linkId"] == 1  # min(1, 2)
        assert p["length"] == pytest.approx(200.0)

    def test_merged_link_speed_is_minimum(self):
        """Merged link speed = min of both legs."""
        fc = _fc(_link(1, 1, 2, spd_heen=80.0), _link(2, 2, 3, spd_heen=50.0))
        result, _ = simplify_network(fc)
        p = result["features"][0]["properties"]
        assert p["max_snelheid_heen"] == pytest.approx(50.0)

    def test_merged_link_capacity_is_minimum(self):
        fc = _fc(_link(1, 1, 2, cap_heen=1800.0), _link(2, 2, 3, cap_heen=1200.0))
        result, _ = simplify_network(fc)
        p = result["features"][0]["properties"]
        assert p["cap_heen"] == pytest.approx(1200.0)

    def test_merged_link_id_is_minimum(self):
        fc = _fc(_link(5, 1, 2), _link(3, 2, 3))
        result, _ = simplify_network(fc)
        assert result["features"][0]["properties"]["linkId"] == 3

    def test_node_with_degree_3_not_removed(self):
        """B connects to A, C, D — degree 3 — must NOT be simplified."""
        fc = _fc(_link(1, 1, 2), _link(2, 2, 3), _link(3, 2, 4))
        result, stats = simplify_network(fc)
        assert len(result["features"]) == 3
        assert stats["removed_nodes"] == 0

    def test_no_traversal_possible_not_removed(self):
        """B sits between A and C but link directions prevent through-traversal."""
        # lk1: A→B (heen=True, terug=False)
        # lk2: C→B (from_node=3, to_node=2, heen=True → 3→2, terug=False)
        # Neither link allows leaving B → B not removable
        lk1 = _link(1, 1, 2, heen=True, terug=False)  # A→B
        lk2 = _link(2, 3, 2, heen=True, terug=False)  # C→B
        fc = _fc(lk1, lk2)
        result, stats = simplify_network(fc)
        assert len(result["features"]) == 2
        assert stats["removed_nodes"] == 0

    def test_same_neighbor_ids_not_removed(self):
        """Two links connecting the same pair A—B (parallel links): B has degree 2
        but both neighbours are the same node — must not be simplified."""
        lk1 = _link(1, 1, 2)
        lk2 = _link(2, 2, 1)
        fc = _fc(lk1, lk2)
        result, stats = simplify_network(fc)
        assert len(result["features"]) == 2
        assert stats["removed_nodes"] == 0

    def test_chain_of_three_pass_through_nodes(self):
        """A—B—C—D—E where B, C, D are all pass-through: merges to A—E."""
        fc = _fc(
            _link(1, 1, 2),
            _link(2, 2, 3),
            _link(3, 3, 4),
            _link(4, 4, 5),
        )
        result, stats = simplify_network(fc)
        assert len(result["features"]) == 1
        assert stats["removed_nodes"] == 3
        p = result["features"][0]["properties"]
        assert p["fromNode"] == 1
        assert p["toNode"] == 5
        assert p["length"] == pytest.approx(400.0)

    def test_flow_smallest_24hr_sum_chosen_for_heen(self):
        """Leg1 has flow_heen total=5, leg2 has flow_heen total=20.
        Merged flow_heen should use leg1's dict (smaller 24-hr total)."""
        fc = _fc(
            _link(1, 1, 2, flow_h=5.0),
            _link(2, 2, 3, flow_h=20.0),
        )
        result, _ = simplify_network(fc)
        p = result["features"][0]["properties"]
        assert isinstance(p["flow_heen"], dict)
        assert p["flow_heen"]["work"] == pytest.approx(5.0)

    def test_flow_smallest_24hr_sum_chosen_for_terug(self):
        """Leg1 has flow_terug total=3, leg2 has flow_terug total=30.
        Merged flow_terug should use leg1's dict (smaller 24-hr total)."""
        fc = _fc(
            _link(1, 1, 2, flow_t=3.0),
            _link(2, 2, 3, flow_t=30.0),
        )
        result, _ = simplify_network(fc)
        p = result["features"][0]["properties"]
        assert isinstance(p["flow_terug"], dict)
        assert p["flow_terug"]["work"] == pytest.approx(3.0)

    def test_flow_format_is_nested_dict(self):
        """Output flow_heen and flow_terug must be nested dicts, not flat fields."""
        fc = _fc(_link(1, 1, 2), _link(2, 2, 3))
        result, _ = simplify_network(fc)
        p = result["features"][0]["properties"]
        assert isinstance(p["flow_heen"], dict)
        assert isinstance(p["flow_terug"], dict)
        assert isinstance(p["flow_dp_heen"], dict)
        assert isinstance(p["flow_dp_terug"], dict)
        assert "work" in p["flow_heen"]
        assert "mrh" in p["flow_dp_heen"]

    def test_equal_attributes_preserved(self):
        """Attributes with the same value in both legs are copied to merged link."""
        fc = _fc(_link(1, 1, 2, street="Hoofdstraat"), _link(2, 2, 3, street="Hoofdstraat"))
        result, _ = simplify_network(fc)
        p = result["features"][0]["properties"]
        assert p.get("streetName") == "Hoofdstraat"

    def test_geometry_coordinates_merged(self):
        """Merged geometry should contain coordinates from both legs, midpoint removed."""
        lk1 = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 0], [2, 0]]},
            "properties": {
                "linkId": 1,
                "mode": "CAR",
                "fromNode": 1,
                "toNode": 2,
                "rijrichting_heen": True,
                "rijrichting_terug": True,
                "max_snelheid_heen": 80.0,
                "max_snelheid_terug": 80.0,
                "cap_heen": 2000.0,
                "cap_terug": 2000.0,
                "rijstroken_heen": 2,
                "rijstroken_terug": 2,
                "flow_heen": {
                    "work": 0.0,
                    "recreational": 0.0,
                    "education": 0.0,
                    "shopping": 0.0,
                    "unknown": 0.0,
                },
                "flow_terug": {
                    "work": 0.0,
                    "recreational": 0.0,
                    "education": 0.0,
                    "shopping": 0.0,
                    "unknown": 0.0,
                },
                "flow_dp_heen": {"mrh": 0.0, "erh": 0.0, "rest": 0.0},
                "flow_dp_terug": {"mrh": 0.0, "erh": 0.0, "rest": 0.0},
                "length": 100.0,
                "streetName": "A",
            },
        }
        lk2 = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[2, 0], [3, 0], [4, 0]]},
            "properties": {
                "linkId": 2,
                "mode": "CAR",
                "fromNode": 2,
                "toNode": 3,
                "rijrichting_heen": True,
                "rijrichting_terug": True,
                "max_snelheid_heen": 80.0,
                "max_snelheid_terug": 80.0,
                "cap_heen": 2000.0,
                "cap_terug": 2000.0,
                "rijstroken_heen": 2,
                "rijstroken_terug": 2,
                "flow_heen": {
                    "work": 0.0,
                    "recreational": 0.0,
                    "education": 0.0,
                    "shopping": 0.0,
                    "unknown": 0.0,
                },
                "flow_terug": {
                    "work": 0.0,
                    "recreational": 0.0,
                    "education": 0.0,
                    "shopping": 0.0,
                    "unknown": 0.0,
                },
                "flow_dp_heen": {"mrh": 0.0, "erh": 0.0, "rest": 0.0},
                "flow_dp_terug": {"mrh": 0.0, "erh": 0.0, "rest": 0.0},
                "length": 100.0,
                "streetName": "B",
            },
        }
        result, _ = simplify_network({"type": "FeatureCollection", "features": [lk1, lk2]})
        coords = result["features"][0]["geometry"]["coordinates"]
        assert len(coords) == 5
        assert coords[0] == [0, 0]
        assert coords[-1] == [4, 0]

    def test_stats_keys_present(self):
        fc = _fc(_link(1, 1, 2), _link(2, 2, 3))
        _, stats = simplify_network(fc)
        assert set(stats.keys()) == {
            "original_links",
            "removed_nodes",
            "merged_links",
            "final_links",
        }

    def test_rijrichting_heen_only_forward(self):
        """One-way chain A→B→C (heen only): merged link has rijrichting_heen=True, terug=False."""
        lk1 = _link(1, 1, 2, heen=True, terug=False)
        lk2 = _link(2, 2, 3, heen=True, terug=False)
        fc = _fc(lk1, lk2)
        result, stats = simplify_network(fc)
        assert stats["removed_nodes"] == 1
        p = result["features"][0]["properties"]
        assert p["rijrichting_heen"] is True
        assert p["rijrichting_terug"] is False

    def test_unrelated_links_not_touched(self):
        """A chain A—B—C plus an isolated link D—E: only B removed, D—E preserved."""
        fc = _fc(_link(1, 1, 2), _link(2, 2, 3), _link(3, 10, 11))
        result, stats = simplify_network(fc)
        assert len(result["features"]) == 2
        assert stats["removed_nodes"] == 1
        nodes = {
            (f["properties"]["fromNode"], f["properties"]["toNode"]) for f in result["features"]
        }
        assert (10, 11) in nodes
