"""Local debug runner for network_simplifier.

Reads a RAW network GeoJSON FeatureCollection, removes pass-through nodes, and
writes the simplified network back to the output URI (overwrites in-place when
--output-uri is the same as --network-file).

Usage
-----
    python -m network_simplifier.network_simplifier_runner \\
        --network-file /path/to/{areaId}-RAW-CAR.parquet \\
        --output-file  /path/to/{areaId}-RAW-CAR.parquet

    # Or with explicit output:
    python -m network_simplifier.network_simplifier_runner \\
        --network-file s3://bucket/key/RAW-CAR.parquet \\
        --output-file  s3://bucket/key/RAW-CAR.parquet
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        data: bytes = get_bytes_s3(bucket, key)
        return data
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Simplify a RAW network GeoJSON by removing pass-through nodes."
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="URI of the RAW network GeoParquet (s3:// or local path).",
    )
    parser.add_argument(
        "--output-file",
        required=True,
        metavar="URI",
        help="URI for the simplified network GeoParquet output (s3:// or local path). "
        "May be the same as --network-file to overwrite in-place.",
    )
    parser.add_argument(
        "--nodes-file",
        default=None,
        metavar="URI",
        help="URI for the removed-nodes GeoParquet output (s3:// or local path). "
        "When given, a Point FeatureCollection of all removed pass-through "
        "nodes is written to this URI.",
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_network_core.network_simplifier.core.network_simplifier_core import (
        simplify_network,
    )

    print(f"Reading  : {args.network_file}")
    fc: dict = from_geoparquet(_read_uri(args.network_file))
    n_links = len(fc.get("features") or [])
    print(f"Links    : {n_links:,}")

    simplified_fc, stats = simplify_network(fc, collect_nodes=bool(args.nodes_file))

    print()
    print(f"Original links  : {stats['original_links']:,}")
    print(f"Removed nodes   : {stats['removed_nodes']:,}")
    print(f"Merged links    : {stats['merged_links']:,}")
    print(f"Final links     : {stats['final_links']:,}")
    print(
        f"Reduction       : {stats['original_links'] - stats['final_links']:,} "
        f"({(stats['original_links'] - stats['final_links']) / max(stats['original_links'], 1) * 100:.1f}%)"
    )
    print()

    print(f"Writing  : {args.output_file}")
    _write_uri(
        args.output_file,
        to_geoparquet(simplified_fc),
    )

    if args.nodes_file:
        nodes_fc = stats["removed_nodes_fc"]
        n_nodes = len(nodes_fc["features"])
        print(f"Writing  : {args.nodes_file}  ({n_nodes:,} removed nodes)")
        _write_uri(
            args.nodes_file,
            to_geoparquet(nodes_fc),
        )

    print("Done.")


if __name__ == "__main__":
    main()
