"""Unit tests for graph_utils and network_cleaner.network_cleaner_core — pure Python, no I/O."""

from __future__ import annotations

import pytest
from gmt_shared.graph_utils import dijkstra, reachable_nodes

from gmt_network_core.network_cleaner.core.network_cleaner_core import (
    build_adjacency,
    clean_network,
    find_seed_node,
    node_positions,
)
from gmt_network_core.network_cleaner.domain.graph import build_reverse_adjacency

# ---------------------------------------------------------------------------
# graph_utils — reachable_nodes (BFS)
# ---------------------------------------------------------------------------


class TestReachableNodes:
    def test_single_node_no_edges(self):
        assert reachable_nodes({}, 1) == {1}

    def test_seed_not_in_adjacency(self):
        # Seed is still considered reached even without outgoing edges
        result = reachable_nodes({2: [3]}, 1)
        assert 1 in result
        assert 2 not in result

    def test_linear_chain(self):
        adj = {1: [2], 2: [3], 3: [4]}
        assert reachable_nodes(adj, 1) == {1, 2, 3, 4}

    def test_directed_not_reachable_backwards(self):
        # 1 → 2 → 3, but start from 3 — only 3 reachable
        adj = {1: [2], 2: [3]}
        assert reachable_nodes(adj, 3) == {3}

    def test_cycle_terminates(self):
        adj = {1: [2], 2: [3], 3: [1]}
        result = reachable_nodes(adj, 1)
        assert result == {1, 2, 3}

    def test_disconnected_component_excluded(self):
        adj = {1: [2], 3: [4]}
        result = reachable_nodes(adj, 1)
        assert result == {1, 2}
        assert 3 not in result
        assert 4 not in result

    def test_branching_graph(self):
        adj = {1: [2, 3], 2: [4], 3: [4]}
        assert reachable_nodes(adj, 1) == {1, 2, 3, 4}

    def test_self_loop(self):
        adj = {1: [1, 2]}
        result = reachable_nodes(adj, 1)
        assert result == {1, 2}


# ---------------------------------------------------------------------------
# graph_utils — dijkstra
# ---------------------------------------------------------------------------


class TestDijkstra:
    def test_seed_has_zero_distance(self):
        dist = dijkstra({}, 1)
        assert dist[1] == 0.0

    def test_linear_chain(self):
        adj = {1: [(2, 1.0)], 2: [(3, 2.0)]}
        dist = dijkstra(adj, 1)
        assert dist[1] == 0.0
        assert dist[2] == 1.0
        assert dist[3] == 3.0

    def test_shortest_path_chosen(self):
        # 1→2 costs 10; 1→3→2 costs 1+1=2
        adj = {1: [(2, 10.0), (3, 1.0)], 3: [(2, 1.0)]}
        dist = dijkstra(adj, 1)
        assert dist[2] == pytest.approx(2.0)

    def test_unreachable_node_absent(self):
        adj = {1: [(2, 1.0)], 3: [(4, 1.0)]}
        dist = dijkstra(adj, 1)
        assert 3 not in dist
        assert 4 not in dist

    def test_empty_graph(self):
        dist = dijkstra({}, 42)
        assert dist == {42: 0.0}

    def test_cycle_terminates(self):
        adj = {1: [(2, 1.0)], 2: [(3, 1.0)], 3: [(1, 1.0)]}
        dist = dijkstra(adj, 1)
        assert dist[1] == 0.0
        assert dist[2] == 1.0
        assert dist[3] == 2.0


# ---------------------------------------------------------------------------
# Fixtures — minimal GeoJSON features
# ---------------------------------------------------------------------------


def _make_feature(
    from_node: int,
    to_node: int,
    coords: list | None = None,
) -> dict:
    """Minimal directed link feature."""
    if coords is None:
        coords = [[float(from_node), 52.0], [float(to_node), 52.0 + 0.01]]
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {"fromNode": from_node, "toNode": to_node, "mode": "CAR"},
    }


def _make_fc(features: list[dict], bbox: list[float] | None = None) -> dict:
    """Wrap features in a minimal FeatureCollection."""
    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"bbox": bbox or [0.0, 51.9, 5.0, 52.2]},
    }


# ---------------------------------------------------------------------------
# build_adjacency
# ---------------------------------------------------------------------------


class TestBuildAdjacency:
    def test_basic(self):
        features = [_make_feature(1, 2), _make_feature(2, 3)]
        adj = build_adjacency(features)
        assert adj[1] == [2]
        assert adj[2] == [3]

    def test_zero_zero_skipped(self):
        # PEDESTRIAN-style feature with both nodes == 0
        feat = _make_feature(0, 0)
        adj = build_adjacency([feat])
        assert adj == {}

    def test_non_integer_nodes_skipped(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
            "properties": {"fromNode": "bad", "toNode": "bad"},
        }
        adj = build_adjacency([feat])
        assert adj == {}

    def test_missing_node_properties_skipped(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0, 0], [1, 1]]},
            "properties": {},
        }
        adj = build_adjacency([feat])
        assert adj == {}

    def test_multiple_edges_from_same_node(self):
        features = [_make_feature(1, 2), _make_feature(1, 3)]
        adj = build_adjacency(features)
        assert sorted(adj[1]) == [2, 3]

    def test_empty_feature_list(self):
        assert build_adjacency([]) == {}


# ---------------------------------------------------------------------------
# build_reverse_adjacency
# ---------------------------------------------------------------------------


class TestBuildReverseAdjacency:
    def test_basic(self):
        features = [_make_feature(1, 2), _make_feature(2, 3)]
        rev = build_reverse_adjacency(features)
        # edge 1→2 becomes 2→[1]; edge 2→3 becomes 3→[2]
        assert rev[2] == [1]
        assert rev[3] == [2]

    def test_bfs_on_reverse_finds_ancestors(self):
        """BFS on reverse adjacency from node 3 should reach nodes 1 and 2
        (all ancestors of 3 in the chain 1→2→3)."""
        features = [_make_feature(1, 2), _make_feature(2, 3)]
        rev = build_reverse_adjacency(features)
        ancestors = reachable_nodes(rev, 3)
        assert ancestors == {1, 2, 3}

    def test_zero_zero_skipped(self):
        feat = _make_feature(0, 0)
        assert build_reverse_adjacency([feat]) == {}

    def test_empty_feature_list(self):
        assert build_reverse_adjacency([]) == {}


# ---------------------------------------------------------------------------
# node_positions
# ---------------------------------------------------------------------------


class TestNodePositions:
    def test_fromnode_gets_first_coord(self):
        coords = [[4.5, 52.1], [4.6, 52.2]]
        feat = _make_feature(10, 20, coords)
        positions = node_positions([feat])
        assert positions[10] == pytest.approx((4.5, 52.1))

    def test_tonode_gets_last_coord(self):
        coords = [[4.5, 52.1], [4.6, 52.2]]
        feat = _make_feature(10, 20, coords)
        positions = node_positions([feat])
        assert positions[20] == pytest.approx((4.6, 52.2))

    def test_zero_zero_skipped(self):
        feat = _make_feature(0, 0)
        assert node_positions([feat]) == {}

    def test_empty_coords_skipped(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": []},
            "properties": {"fromNode": 1, "toNode": 2},
        }
        assert node_positions([feat]) == {}

    def test_multiple_features_accumulate(self):
        features = [
            _make_feature(1, 2, [[0.0, 52.0], [1.0, 52.0]]),
            _make_feature(2, 3, [[1.0, 52.0], [2.0, 52.0]]),
        ]
        positions = node_positions(features)
        assert 1 in positions
        assert 2 in positions
        assert 3 in positions


# ---------------------------------------------------------------------------
# find_seed_node
# ---------------------------------------------------------------------------


class TestFindSeedNode:
    def test_nearest_to_centroid(self):
        # Single feature [[0.0, 52.0], [2.5, 52.05]]
        # midpoint (len=2, index 1) → (2.5, 52.05)
        # centroid = (2.5, 52.05)
        # node 1 at (0.0, 52.0) — far from centroid
        # node 2 at (2.5, 52.05) — exactly at centroid → chosen as seed
        features = [
            _make_feature(1, 2, [[0.0, 52.0], [2.5, 52.05]]),
        ]
        seed = find_seed_node(features)
        assert seed == 2

    def test_no_valid_positions_raises(self):
        # Only zero-zero features
        features = [_make_feature(0, 0)]
        with pytest.raises(ValueError, match="No valid node positions"):
            find_seed_node(features)

    def test_single_node(self):
        features = [_make_feature(99, 100, [[1.0, 52.0], [1.01, 52.0]])]
        seed = find_seed_node(features)
        assert seed in (99, 100)

    def test_prefers_dense_cluster_over_isolated_node(self):
        # Main cluster: many short links around lon=4.42, lat=51.91
        # Isolated outlier: single link at lon=4.42, lat=51.88 (near bbox centre)
        # The feature centroid must pull towards the dense cluster, not the outlier.
        cluster = [
            _make_feature(i, i + 1, [[4.41 + i * 0.002, 51.91], [4.412 + i * 0.002, 51.91]])
            for i in range(10)
        ]
        outlier = [_make_feature(900, 901, [[4.42, 51.88], [4.421, 51.88]])]
        seed = find_seed_node(cluster + outlier)
        assert seed not in (900, 901), "Seed must not land in the isolated outlier component"


# ---------------------------------------------------------------------------
# clean_network
# ---------------------------------------------------------------------------


class TestCleanNetwork:
    def _linear_fc(self) -> dict:
        """A→B→C→D linear chain."""
        # Feature midpoints (index 1 of 2-coord lines): lon 1, 2, 3
        # Centroid ≈ lon 2.0 → seed is node 3 (lon=2) or node 4 (lon=3)
        # The flood-fill rescues the full chain because both ends are checked.
        features = [
            _make_feature(1, 2, [[0.0, 52.0], [1.0, 52.0]]),
            _make_feature(2, 3, [[1.0, 52.0], [2.0, 52.0]]),
            _make_feature(3, 4, [[2.0, 52.0], [3.0, 52.0]]),
        ]
        return _make_fc(features, bbox=[0.0, 52.0, 3.0, 52.0])

    def test_returns_feature_collection(self):
        fc = _make_fc([_make_feature(1, 2)])
        cleaned, _stats = clean_network(fc)
        assert cleaned["type"] == "FeatureCollection"

    def test_dead_link_removed(self):
        # Chain 5→6→7→8; feature centroid pulls the seed into the middle.
        # Since the flood-fill rescues on both fromNode and toNode, all
        # connected links in the chain are kept.
        features = [
            _make_feature(5, 6, [[0.0, 52.0], [1.0, 52.0]]),
            _make_feature(6, 7, [[1.0, 52.0], [2.0, 52.0]]),
            _make_feature(7, 8, [[2.0, 52.0], [3.0, 52.0]]),
        ]
        fc = _make_fc(features, bbox=[0.0, 52.0, 3.0, 52.0])
        _cleaned, stats = clean_network(fc)
        assert stats["total"] == 3
        assert stats["kept"] + stats["removed"] == 3

    def test_empty_fc_returns_unchanged(self):
        fc = _make_fc([])
        _cleaned, stats = clean_network(fc)
        assert stats["total"] == 0
        assert stats["kept"] == 0
        assert stats["removed"] == 0
        assert stats["seed_node"] is None

    def test_pedestrian_zero_nodes_always_kept(self):
        ped_feat = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0.0, 52.0], [1.0, 52.0]]},
            "properties": {"fromNode": 0, "toNode": 0, "mode": "PEDESTRIAN"},
        }
        normal_feat = _make_feature(1, 2, [[0.5, 52.0], [1.5, 52.0]])
        fc = _make_fc([ped_feat, normal_feat], bbox=[0.0, 52.0, 2.0, 52.0])
        cleaned, _stats = clean_network(fc)
        # PEDESTRIAN (0,0) feature must be in output
        node_pairs = [
            (f["properties"]["fromNode"], f["properties"]["toNode"]) for f in cleaned["features"]
        ]
        assert (0, 0) in node_pairs

    def test_stats_keys_present(self):
        fc = _make_fc([_make_feature(1, 2)])
        _, stats = clean_network(fc)
        assert "total" in stats
        assert "kept" in stats
        assert "removed" in stats
        assert "seed_node" in stats

    def test_fc_properties_preserved(self):
        features = [_make_feature(1, 2)]
        fc = {
            "type": "FeatureCollection",
            "features": features,
            "properties": {"bbox": [0.0, 52.0, 2.0, 52.1], "area_id": "test-area"},
        }
        cleaned, _ = clean_network(fc)
        assert cleaned["properties"]["area_id"] == "test-area"
        assert cleaned["properties"]["bbox"] == [0.0, 52.0, 2.0, 52.1]

    def test_incoming_link_not_removed(self):
        """A one-way link whose fromNode is outside the reachable set but whose
        toNode feeds into the main connected graph must NOT be removed.

        Topology:
            1 → 2 → 3 → 4 → 2  (cycle on 2-3-4, plus an incoming link 1→2)

        bbox [0,52,3,52], centre ≈ (1.5, 52.0).
        Nearest node to centre: node 2 (lon=1.0) or node 3 (lon=2.0) — either
        way the cycle {2,3,4} is fully reachable from the seed.

        Link 1→2: fromNode=1 is NOT reachable from the seed (no edge leads to 1),
        but toNode=2 CAN reach the seed via 2→3→... so it must be kept.
        """
        features = [
            _make_feature(1, 2, [[0.0, 52.0], [1.0, 52.0]]),  # incoming from outside
            _make_feature(2, 3, [[1.0, 52.0], [2.0, 52.0]]),
            _make_feature(3, 4, [[2.0, 52.0], [3.0, 52.0]]),
            _make_feature(4, 2, [[3.0, 52.0], [1.0, 52.0]]),  # cycle back
        ]
        fc = _make_fc(features, bbox=[0.0, 52.0, 3.0, 52.0])
        cleaned, stats = clean_network(fc)

        kept_from_nodes = {f["properties"]["fromNode"] for f in cleaned["features"]}
        assert 1 in kept_from_nodes, "Incoming link 1→2 should be kept (toNode feeds the network)"
        assert stats["removed"] == 0
        assert stats["kept"] == 4

    def test_truly_dead_link_still_removed(self):
        """A link whose toNode leads only further into an isolated dead-end
        component (cannot reach the seed) must still be removed.

        Topology:
            10 → 11 → 12   (dead component, disconnected from seed)
            2  → 3  → 4 → 2  (cycle, seed is in this component)

        bbox is kept tight around the cycle so the seed is always chosen from
        {2, 3, 4}.  Link 10→11: fromNode=10 not reachable from seed AND
        toNode=11 cannot reach the seed → must be removed.
        """
        features = [
            # Dead component (far outside bbox)
            _make_feature(10, 11, [[10.0, 52.0], [11.0, 52.0]]),
            _make_feature(11, 12, [[11.0, 52.0], [12.0, 52.0]]),
            # Live cycle near bbox centre (lon ≈ 2)
            _make_feature(2, 3, [[1.0, 52.0], [2.0, 52.0]]),
            _make_feature(3, 4, [[2.0, 52.0], [3.0, 52.0]]),
            _make_feature(4, 2, [[3.0, 52.0], [1.0, 52.0]]),
        ]
        # Tight bbox around the cycle: centre lon=2.0 → seed chosen from {2,3,4}
        fc = _make_fc(features, bbox=[0.0, 52.0, 4.0, 52.0])
        cleaned, stats = clean_network(fc)

        kept_from_nodes = {f["properties"]["fromNode"] for f in cleaned["features"]}
        assert 10 not in kept_from_nodes, "Dead-end link 10→11 must be removed"
        assert 11 not in kept_from_nodes, "Dead-end link 11→12 must be removed"
        assert stats["removed"] == 2
        assert stats["kept"] == 3

    def test_adjacent_to_kept_link_not_removed(self):
        """A link that shares a node with a kept link must NOT be removed,
        even if neither reachability condition (BFS) would save it.

        Topology:
            2 → 3 → 2  (cycle; seed chosen from {2, 3})
            2 → 99     (fromNode=2 is reachable → kept by existing rule)
            99 → 100   (fromNode=99 not reachable from seed; toNode=100 cannot
                        reach seed — BUT 99 is the toNode of kept link 2→99,
                        so this link must be rescued by the adjacency rule)

        Without the adjacency rule, 99→100 would be removed.
        """
        features = [
            _make_feature(2, 3, [[1.0, 52.0], [2.0, 52.0]]),
            _make_feature(3, 2, [[2.0, 52.0], [1.0, 52.0]]),
            _make_feature(2, 99, [[1.0, 52.0], [9.0, 52.0]]),  # kept: fromNode reachable
            _make_feature(99, 100, [[9.0, 52.0], [10.0, 52.0]]),  # rescued: shares node 99
        ]
        fc = _make_fc(features, bbox=[0.0, 52.0, 3.0, 52.0])
        cleaned, stats = clean_network(fc)

        kept_from_nodes = {f["properties"]["fromNode"] for f in cleaned["features"]}
        assert 99 in kept_from_nodes, (
            "Link 99→100 must be rescued because it shares node 99 with kept link 2→99"
        )
        assert stats["removed"] == 0
        assert stats["kept"] == 4

    def test_adjacency_rescue_propagates(self):
        """The adjacency rescue must propagate: if link A is rescued because it
        is adjacent to a kept link, link B adjacent to A must also be rescued.

        Topology:
            2 → 3 → 2   (cycle; seed in {2, 3})
            2 → 99      (kept: fromNode reachable)
            99 → 100    (rescued in round 1: shares node 99 with 2→99)
            100 → 101   (rescued in round 2: shares node 100 with rescued 99→100)
        """
        features = [
            _make_feature(2, 3, [[1.0, 52.0], [2.0, 52.0]]),
            _make_feature(3, 2, [[2.0, 52.0], [1.0, 52.0]]),
            _make_feature(2, 99, [[1.0, 52.0], [9.0, 52.0]]),
            _make_feature(99, 100, [[9.0, 52.0], [10.0, 52.0]]),
            _make_feature(100, 101, [[10.0, 52.0], [11.0, 52.0]]),
        ]
        fc = _make_fc(features, bbox=[0.0, 52.0, 3.0, 52.0])
        cleaned, stats = clean_network(fc)

        kept_from_nodes = {f["properties"]["fromNode"] for f in cleaned["features"]}
        assert 99 in kept_from_nodes, "Link 99→100 must be rescued (round 1)"
        assert 100 in kept_from_nodes, "Link 100→101 must be rescued (round 2)"
        assert stats["removed"] == 0
        assert stats["kept"] == 5

    def test_fully_connected_nothing_removed(self):
        # Seed is near bbox centre (1.5, 52.0); closest node is 2 (lon=1.5).
        # Graph: 2→3 only — fromNode 1 is NOT reachable from seed 2
        # in a directed graph (1→2, but BFS starts at 2).
        # Use a circular topology so all fromNodes are reachable: 2→3→2 (cycle).
        features = [
            _make_feature(2, 3, [[1.4, 52.0], [1.6, 52.0]]),
            _make_feature(3, 2, [[1.6, 52.0], [1.4, 52.0]]),
        ]
        fc = _make_fc(features, bbox=[1.3, 51.9, 1.7, 52.1])
        _cleaned, stats = clean_network(fc)
        # Seed is node 2 or 3 (both at centre distance); cycle → both reachable
        assert stats["removed"] == 0
        assert stats["kept"] == 2

    def test_missing_bbox_no_longer_raises(self):
        # bbox in properties is no longer needed for seed selection; clean_network
        # must succeed even when properties.bbox is absent.
        features = [
            _make_feature(1, 2, [[1.0, 52.0], [2.0, 52.0]]),
            _make_feature(2, 3, [[2.0, 52.0], [3.0, 52.0]]),
        ]
        fc = {
            "type": "FeatureCollection",
            "features": features,
            "properties": {},  # no bbox
        }
        _cleaned, stats = clean_network(fc)
        assert stats["total"] == 2

    def test_large_disconnected_graph(self):
        # Two components: 1→2→3 and 10→11→12 (far away)
        # Seed will be near centre of bbox (0–12 range) → near node 6/7 area
        # but closest existing node will be 3 (lon=2) or 10 (lon=10)
        features = [
            _make_feature(i, i + 1, [[float(i), 52.0], [float(i + 1), 52.0]]) for i in range(1, 3)
        ] + [
            _make_feature(i, i + 1, [[float(i), 52.0], [float(i + 1), 52.0]]) for i in range(10, 12)
        ]
        fc = _make_fc(features, bbox=[0.0, 52.0, 13.0, 52.0])
        _cleaned, stats = clean_network(fc)
        assert stats["total"] == 4
        # One component is reachable from seed; the other may be pruned
        assert stats["kept"] + stats["removed"] == 4
