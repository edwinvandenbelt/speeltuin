"""Graph construction and seed-node selection helpers for network_cleaner."""

from __future__ import annotations

import math


def build_adjacency(features: list[dict]) -> dict[int, list[int]]:
    """Build a directed adjacency map ``{from_node: [to_node, ...]}`` from *features*."""
    adj: dict[int, list[int]] = {}
    for feat in features:
        props = feat.get("properties") or {}
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is None or to_node is None:
            continue
        try:
            fn = int(from_node)
            tn = int(to_node)
        except (ValueError, TypeError):
            continue
        if fn == 0 and tn == 0:
            continue
        if fn not in adj:
            adj[fn] = []
        adj[fn].append(tn)
    return adj


def build_reverse_adjacency(features: list[dict]) -> dict[int, list[int]]:
    """Build a reversed directed adjacency map ``{to_node: [from_node, ...]}`` from *features*.

    BFS on this map from the seed node yields every node that has a directed
    path *to* the seed (i.e. nodes that can reach the seed).
    """
    adj: dict[int, list[int]] = {}
    for feat in features:
        props = feat.get("properties") or {}
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is None or to_node is None:
            continue
        try:
            fn = int(from_node)
            tn = int(to_node)
        except (ValueError, TypeError):
            continue
        if fn == 0 and tn == 0:
            continue
        if tn not in adj:
            adj[tn] = []
        adj[tn].append(fn)
    return adj


def node_positions(features: list[dict]) -> dict[int, tuple[float, float]]:
    """Return ``{node_id: (lon, lat)}`` approximated from feature endpoint coords."""
    positions: dict[int, tuple[float, float]] = {}
    for feat in features:
        props = feat.get("properties") or {}
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords or from_node is None or to_node is None:
            continue
        try:
            fn = int(from_node)
            tn = int(to_node)
        except (ValueError, TypeError):
            continue
        if fn == 0 and tn == 0:
            continue
        positions[fn] = (float(coords[0][0]), float(coords[0][1]))
        positions[tn] = (float(coords[-1][0]), float(coords[-1][1]))
    return positions


def find_seed_node(features: list[dict]) -> int:
    """Return the node ID whose position is nearest to the centroid of all feature midpoints.

    The centroid is computed as the average of the middle coordinate of each
    non-pedestrian LineString feature.  This is more robust than using the
    bounding-box centre, which can fall inside a small isolated component rather
    than the main connected network (e.g. when the queried bbox is asymmetric
    relative to where most road links actually lie).
    """
    positions = node_positions(features)
    if not positions:
        raise ValueError("No valid node positions found in features.")

    mid_lons: list[float] = []
    mid_lats: list[float] = []
    for feat in features:
        props = feat.get("properties") or {}
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords:
            continue
        try:
            fn = int(from_node)  # type: ignore[arg-type]
            tn = int(to_node)  # type: ignore[arg-type]
        except (ValueError, TypeError):
            continue
        if fn == 0 and tn == 0:
            continue
        mid = coords[len(coords) // 2]
        mid_lons.append(float(mid[0]))
        mid_lats.append(float(mid[1]))

    if not mid_lons:
        raise ValueError("No valid node positions found in features.")

    cx = sum(mid_lons) / len(mid_lons)
    cy = sum(mid_lats) / len(mid_lats)
    cos_lat = math.cos(math.radians(cy))

    best_node: int | None = None
    best_dist = float("inf")
    for node_id, (lon, lat) in positions.items():
        dx = (lon - cx) * cos_lat
        dy = lat - cy
        dist = dx * dx + dy * dy
        if dist < best_dist:
            best_dist = dist
            best_node = node_id

    if best_node is None:
        raise ValueError("Could not determine seed node.")
    return best_node
