"""Pure-Python network_link_inserter core — no I/O, no boto3, no external deps.

Inserts new directed links into a network GeoJSON FeatureCollection, snapping
link endpoints to existing network nodes or by splitting nearby links.

Snap algorithm (per endpoint)
------------------------------
1. Find the nearest existing node within *snap_tolerance_m* (default 15 m).
   If found, reuse that node's ID and exact coordinates.
2. Otherwise find the nearest foot-of-perpendicular on any link edge segment.
   - If the distance exceeds *max_snap_distance_m* (default 30 m) the whole
     change is skipped and a warning is recorded in the report.
   - Otherwise split that link (and its reverse, if present) at the foot
     point, introduce a ``new_node_N`` at the foot, and use it as the
     endpoint.

Public API
----------
insert_links(network_fc, changes, snap_tolerance_m, max_snap_distance_m)
    -> tuple[dict, dict]
    Returns (modified_feature_collection, report).
    report keys: ``inserted``, ``links_added``, ``skipped``, ``warnings``,
    ``changes`` (per-change outcome list).
"""

from __future__ import annotations

import logging
import math
from copy import deepcopy

from gmt_shared.displacer import _NEAR_NODE_M, _OFFSET_M, heading, offset_linestring

logger = logging.getLogger(__name__)

_EARTH_R = 6_371_000.0  # metres

# ---------------------------------------------------------------------------
# Geographic helpers
# ---------------------------------------------------------------------------


def _haversine(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """Haversine distance in metres between two WGS-84 points."""
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_phi = math.radians(lat2 - lat1)
    d_lam = math.radians(lon2 - lon1)
    a = math.sin(d_phi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(d_lam / 2) ** 2
    return 2 * _EARTH_R * math.atan2(math.sqrt(a), math.sqrt(1.0 - a))


def _bearing(lon1: float, lat1: float, lon2: float, lat2: float) -> float:
    """Compass bearing (0-360 deg clockwise from north) from point 1 to point 2."""
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    d_lam = math.radians(lon2 - lon1)
    y = math.sin(d_lam) * math.cos(phi2)
    x = math.cos(phi1) * math.sin(phi2) - math.sin(phi1) * math.cos(phi2) * math.cos(d_lam)
    return (math.degrees(math.atan2(y, x)) + 360) % 360


def _linestring_length(coords: list[list[float]]) -> float:
    """Sum of haversine distances along a LineString coordinate list."""
    total = 0.0
    for i in range(len(coords) - 1):
        total += _haversine(coords[i][0], coords[i][1], coords[i + 1][0], coords[i + 1][1])
    return total


def _to_flat(lon: float, lat: float, lon0: float, lat0: float) -> tuple[float, float]:
    """Flat-earth projection (metres) relative to (lon0, lat0)."""
    x = (lon - lon0) * math.cos(math.radians(lat0)) * (math.pi / 180.0) * _EARTH_R
    y = (lat - lat0) * (math.pi / 180.0) * _EARTH_R
    return x, y


def _from_flat(x: float, y: float, lon0: float, lat0: float) -> tuple[float, float]:
    """Inverse of _to_flat."""
    lon = lon0 + x / (math.cos(math.radians(lat0)) * (math.pi / 180.0) * _EARTH_R)
    lat = lat0 + y / ((math.pi / 180.0) * _EARTH_R)
    return lon, lat


def _foot_on_segment(
    px: float,
    py: float,
    ax: float,
    ay: float,
    bx: float,
    by: float,
) -> tuple[float, float, float]:
    """Return (foot_x, foot_y, t) — closest point on segment A->B to point P.

    t is clamped to [0, 1].  All coordinates are in flat-earth metres.
    """
    dx, dy = bx - ax, by - ay
    seg_len_sq = dx * dx + dy * dy
    if seg_len_sq < 1e-12:
        return ax, ay, 0.0
    t = ((px - ax) * dx + (py - ay) * dy) / seg_len_sq
    t = max(0.0, min(1.0, t))
    return ax + t * dx, ay + t * dy, t


# ---------------------------------------------------------------------------
# Network index helpers
# ---------------------------------------------------------------------------


def _build_node_positions(features: list[dict]) -> dict[str, tuple[float, float]]:
    """Build a map of node_id -> (lon, lat) from the first/last geometry coords."""
    node_pos: dict[str, tuple[float, float]] = {}
    for feat in features:
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        props = feat.get("properties") or {}
        if len(coords) >= 2:
            fn = props.get("fromNode")
            tn = props.get("toNode")
            if fn is not None:
                node_pos.setdefault(str(fn), (float(coords[0][0]), float(coords[0][1])))
            if tn is not None:
                node_pos.setdefault(str(tn), (float(coords[-1][0]), float(coords[-1][1])))
    return node_pos


# ---------------------------------------------------------------------------
# Snap endpoint to network
# ---------------------------------------------------------------------------


def _snap_endpoint(
    lon: float,
    lat: float,
    node_positions: dict[str, tuple[float, float]],
    features: list[dict],
    snap_tol: float,
    max_snap: float,
) -> tuple[str | None, float | None, float | None, str | None]:
    """Snap a geographic point to the nearest network node or link segment.

    Returns
    -------
    (node_id, snapped_lon, snapped_lat, split_feat_id)

    - ``(node_id, lon, lat, None)``  — snapped directly to an existing node.
    - ``(None, foot_lon, foot_lat, feat_id)``  — needs a link split at foot.
    - ``(None, None, None, None)``  — too far from everything; caller must skip.
    """
    # 1. Find nearest node within snap_tol
    best_node_id: str | None = None
    best_node_dist = snap_tol + 1.0
    for nid, (nlon, nlat) in node_positions.items():
        d = _haversine(lon, lat, nlon, nlat)
        if d <= snap_tol and d < best_node_dist:
            best_node_dist = d
            best_node_id = nid
    if best_node_id is not None:
        nlon, nlat = node_positions[best_node_id]
        return best_node_id, nlon, nlat, None

    # 2. Find nearest foot-of-perpendicular on any link edge segment
    # Use the query point as flat-earth reference origin.
    lon0, lat0 = lon, lat

    best_dist = max_snap + 1.0
    best_foot_lon: float | None = None
    best_foot_lat: float | None = None
    best_feat_id: str | None = None

    for feat in features:
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if len(coords) < 2:
            continue
        feat_id = str((feat.get("properties") or {}).get("linkId", id(feat)))
        for i in range(len(coords) - 1):
            ax, ay = _to_flat(coords[i][0], coords[i][1], lon0, lat0)
            bx, by = _to_flat(coords[i + 1][0], coords[i + 1][1], lon0, lat0)
            fx, fy, _ = _foot_on_segment(0.0, 0.0, ax, ay, bx, by)
            d = math.hypot(fx, fy)
            if d < best_dist:
                best_dist = d
                flon, flat = _from_flat(fx, fy, lon0, lat0)
                best_foot_lon = flon
                best_foot_lat = flat
                best_feat_id = feat_id

    if best_foot_lon is None or best_dist > max_snap:
        return None, None, None, None

    return None, best_foot_lon, best_foot_lat, best_feat_id


# ---------------------------------------------------------------------------
# Link splitting
# ---------------------------------------------------------------------------


def _taper_end(coords: list[list[float]], node_coord: list[float]) -> list[list[float]]:
    """Pull coords near the END toward node_coord, mirroring offset_linestring's taper."""
    result = [list(c) for c in coords]
    total = _linestring_length(result)
    near_m = _NEAR_NODE_M if total >= 10.0 else (1.0 if total >= 3.0 else 0.5)
    dist = 0.0
    for i in range(len(result) - 2, -1, -1):
        dist += _haversine(result[i][0], result[i][1], result[i + 1][0], result[i + 1][1])
        if dist >= near_m:
            break
        scale = dist / near_m  # 0 near endpoint → 1 at near_m
        result[i] = [
            node_coord[0] + scale * (result[i][0] - node_coord[0]),
            node_coord[1] + scale * (result[i][1] - node_coord[1]),
        ]
    return result


def _taper_start(coords: list[list[float]], node_coord: list[float]) -> list[list[float]]:
    """Pull coords near the START toward node_coord, mirroring offset_linestring's taper."""
    return list(reversed(_taper_end(list(reversed(coords)), node_coord)))


def _split_link(
    features: list[dict],
    split_feat_id: str,
    foot_lon: float,
    foot_lat: float,
    new_node_id: str,
    next_link_id: list[int],
) -> None:
    """Split the link with the given linkId at (foot_lon, foot_lat).

    Also splits the reverse link (fromNode/toNode swapped) if present.
    Modifies ``features`` in place.  ``next_link_id[0]`` is incremented for
    each new link created.
    """
    # Find the forward link to split
    split_idx: int | None = None
    for i, feat in enumerate(features):
        props = feat.get("properties") or {}
        if str(props.get("linkId")) == split_feat_id:
            split_idx = i
            break

    if split_idx is None:
        logger.warning("_split_link: linkId %s not found", split_feat_id)
        return

    split_feat = features[split_idx]
    split_props = dict(split_feat.get("properties") or {})
    split_coords = list((split_feat.get("geometry") or {}).get("coordinates") or [])
    from_node = str(split_props.get("fromNode", ""))
    to_node = str(split_props.get("toNode", ""))

    # Find which segment the foot point is closest to
    lon0, lat0 = foot_lon, foot_lat  # reference for flat-earth
    best_seg_idx = 0
    best_dist = float("inf")
    for i in range(len(split_coords) - 1):
        ax, ay = _to_flat(split_coords[i][0], split_coords[i][1], lon0, lat0)
        bx, by = _to_flat(split_coords[i + 1][0], split_coords[i + 1][1], lon0, lat0)
        fx, fy, _ = _foot_on_segment(0.0, 0.0, ax, ay, bx, by)
        d = math.hypot(fx, fy)
        if d < best_dist:
            best_dist = d
            best_seg_idx = i

    foot_coord = [foot_lon, foot_lat]
    first_half: list[list[float]] = [list(c) for c in split_coords[: best_seg_idx + 1]] + [
        foot_coord
    ]
    second_half: list[list[float]] = [foot_coord] + [
        list(c) for c in split_coords[best_seg_idx + 1 :]
    ]

    # Remove trivial duplicate at split boundary
    if len(first_half) >= 2 and first_half[-2] == first_half[-1]:
        first_half = first_half[:-1]
    if len(second_half) >= 2 and second_half[0] == second_half[1]:
        second_half = second_half[1:]

    def _make_half(hcoords: list[list[float]], fn: str, tn: str) -> dict:
        hprops = dict(split_props)
        lid = f"new_link_{next_link_id[0]}"
        next_link_id[0] += 1
        hprops["linkId"] = lid
        hprops["fromNode"] = fn
        hprops["toNode"] = tn
        hprops["length"] = _linestring_length(hcoords)
        hprops["heading"] = heading(hcoords)
        return {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": hcoords},
            "properties": hprops,
        }

    new_feats: list[dict] = [
        _make_half(_taper_end(first_half, foot_coord), from_node, new_node_id),
        _make_half(_taper_start(second_half, foot_coord), new_node_id, to_node),
    ]

    # Find and split reverse link (fromNode=to_node, toNode=from_node)
    reverse_idx: int | None = None
    for i, feat in enumerate(features):
        if i == split_idx:
            continue
        props = feat.get("properties") or {}
        if str(props.get("fromNode", "")) == to_node and str(props.get("toNode", "")) == from_node:
            reverse_idx = i
            break

    if reverse_idx is not None:
        rev_props = dict(features[reverse_idx].get("properties") or {})
        rev_coords = list((features[reverse_idx].get("geometry") or {}).get("coordinates") or [])

        # Find the closest point on the reverse link's own geometry to foot_coord.
        # The reverse link is offset to the opposite side, so we search its own segments.
        rev_best_seg_idx = 0
        rev_best_dist = float("inf")
        for i in range(len(rev_coords) - 1):
            ax, ay = _to_flat(rev_coords[i][0], rev_coords[i][1], lon0, lat0)
            bx, by = _to_flat(rev_coords[i + 1][0], rev_coords[i + 1][1], lon0, lat0)
            fx, fy, _ = _foot_on_segment(0.0, 0.0, ax, ay, bx, by)
            d = math.hypot(fx, fy)
            if d < rev_best_dist:
                rev_best_dist = d
                rev_best_seg_idx = i

        # The reverse link runs to_node -> from_node.  Use foot_coord (the new node's
        # canonical position) as the shared split point so all four half-links terminate
        # at exactly the same coordinate.
        rev_first_half: list[list[float]] = [
            list(c) for c in rev_coords[: rev_best_seg_idx + 1]
        ] + [foot_coord]
        rev_second_half: list[list[float]] = [foot_coord] + [
            list(c) for c in rev_coords[rev_best_seg_idx + 1 :]
        ]
        if len(rev_first_half) >= 2 and rev_first_half[-2] == rev_first_half[-1]:
            rev_first_half = rev_first_half[:-1]
        if len(rev_second_half) >= 2 and rev_second_half[0] == rev_second_half[1]:
            rev_second_half = rev_second_half[1:]

        # rh1: to_node -> new_node_id  (first portion of the reverse link)
        # rh2: new_node_id -> from_node (second portion of the reverse link)
        rh1_coords = _taper_end(rev_first_half, foot_coord)
        rh2_coords = _taper_start(rev_second_half, foot_coord)

        def _make_rev_half(hcoords: list[list[float]], fn: str, tn: str) -> dict:
            hprops = dict(rev_props)
            lid = f"new_link_{next_link_id[0]}"
            next_link_id[0] += 1
            hprops["linkId"] = lid
            hprops["fromNode"] = fn
            hprops["toNode"] = tn
            hprops["length"] = _linestring_length(hcoords)
            hprops["heading"] = _bearing(
                hcoords[0][0], hcoords[0][1], hcoords[-1][0], hcoords[-1][1]
            )
            return {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": hcoords},
                "properties": hprops,
            }

        new_feats.extend(
            [
                _make_rev_half(rh1_coords, to_node, new_node_id),
                _make_rev_half(rh2_coords, new_node_id, from_node),
            ]
        )

    # Rebuild features list
    indices_to_remove = {split_idx}
    if reverse_idx is not None:
        indices_to_remove.add(reverse_idx)

    surviving = [f for i, f in enumerate(features) if i not in indices_to_remove]
    features.clear()
    features.extend(surviving + new_feats)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def insert_links(
    network_fc: dict,
    changes: list[dict],
    snap_tolerance_m: float = 15.0,
    max_snap_distance_m: float = 30.0,
) -> tuple[dict, dict]:
    """Insert new directed links into a network GeoJSON FeatureCollection.

    Parameters
    ----------
    network_fc:
        Input GeoJSON FeatureCollection with directed network links.
    changes:
        List of change objects.  Each must have ``linkId`` set to ``null``
        and must include ``geometry`` (LineString), ``speed``, ``capacity``,
        ``direction`` (``"both"`` | ``"forward"`` | ``"backward"``; default
        ``"both"``), and optionally ``lanes`` (default ``1``).
    snap_tolerance_m:
        Maximum distance (metres) for snapping directly to an existing node.
    max_snap_distance_m:
        Maximum distance (metres) for snapping to a foot-of-perpendicular.
        Changes whose endpoints lie farther than this are skipped.

    Returns
    -------
    result:
        Modified FeatureCollection with new links inserted.
    report:
        Dict with ``"inserted"`` (changes applied), ``"links_added"``
        (new feature count), ``"skipped"``, ``"warnings"``, and
        ``"changes"`` (per-change outcome list).
    """
    features: list[dict] = [deepcopy(f) for f in (network_fc.get("features") or [])]
    next_link_id: list[int] = [1]
    next_node_id: list[int] = [1]

    inserted = 0
    links_added = 0
    skipped = 0
    warnings: list[str] = []
    change_outcomes: list[dict] = []

    for ci, change in enumerate(changes):
        # --- validate change object ---
        link_id_val = change.get("linkId")
        if link_id_val is not None:
            msg = f"Change #{ci}: linkId must be null for inserts (got {link_id_val!r}); skipping."
            warnings.append(msg)
            logger.warning(msg)
            skipped += 1
            change_outcomes.append({"index": ci, "status": "skipped", "reason": msg})
            continue

        geom = change.get("geometry") or {}
        if geom.get("type") != "LineString":
            msg = f"Change #{ci}: geometry must be a LineString; skipping."
            warnings.append(msg)
            logger.warning(msg)
            skipped += 1
            change_outcomes.append({"index": ci, "status": "skipped", "reason": msg})
            continue

        coords: list[list[float]] = geom.get("coordinates") or []
        if len(coords) < 2:
            msg = f"Change #{ci}: LineString must have >= 2 coordinates; skipping."
            warnings.append(msg)
            skipped += 1
            change_outcomes.append({"index": ci, "status": "skipped", "reason": msg})
            continue

        speed = float(change.get("speed", 50.0))
        capacity = float(change.get("capacity", 800.0))
        direction = str(change.get("direction", "both"))
        lanes_val = change.get("lanes")
        lanes = int(lanes_val) if lanes_val is not None else 1

        outcome: dict = {"index": ci, "status": "ok", "links_created": []}

        # --- snap start endpoint ---
        node_positions = _build_node_positions(features)
        start_lon, start_lat = float(coords[0][0]), float(coords[0][1])
        from_node_id, snapped_s_lon, snapped_s_lat, split_feat_start = _snap_endpoint(
            start_lon,
            start_lat,
            node_positions,
            features,
            snap_tolerance_m,
            max_snap_distance_m,
        )

        if from_node_id is None and split_feat_start is None:
            msg = (
                f"Change #{ci}: start endpoint ({start_lon},{start_lat}) is "
                f">{max_snap_distance_m}m from the network; skipping."
            )
            warnings.append(msg)
            logger.warning(msg)
            skipped += 1
            change_outcomes.append({"index": ci, "status": "skipped", "reason": msg})
            continue
        # _snap_endpoint returns coordinates whenever it returns a node or a split.
        assert snapped_s_lon is not None
        assert snapped_s_lat is not None

        if split_feat_start is not None:
            new_nid = f"new_node_{next_node_id[0]}"
            next_node_id[0] += 1
            _split_link(
                features,
                split_feat_start,
                snapped_s_lon,
                snapped_s_lat,
                new_nid,
                next_link_id,
            )
            from_node_id = new_nid
            outcome["start_snapped"] = {"method": "split", "node": new_nid}
        else:
            outcome["start_snapped"] = {"method": "node", "node": from_node_id}
        assert from_node_id is not None

        # --- snap end endpoint ---
        node_positions = _build_node_positions(features)
        # Ensure a freshly-created start node is visible
        if from_node_id not in node_positions and snapped_s_lon is not None:
            node_positions[from_node_id] = (snapped_s_lon, snapped_s_lat)

        end_lon, end_lat = float(coords[-1][0]), float(coords[-1][1])
        to_node_id, snapped_e_lon, snapped_e_lat, split_feat_end = _snap_endpoint(
            end_lon,
            end_lat,
            node_positions,
            features,
            snap_tolerance_m,
            max_snap_distance_m,
        )

        if to_node_id is None and split_feat_end is None:
            msg = (
                f"Change #{ci}: end endpoint ({end_lon},{end_lat}) is "
                f">{max_snap_distance_m}m from the network; skipping."
            )
            warnings.append(msg)
            logger.warning(msg)
            skipped += 1
            change_outcomes.append({"index": ci, "status": "skipped", "reason": msg})
            continue
        assert snapped_e_lon is not None
        assert snapped_e_lat is not None

        if split_feat_end is not None:
            new_nid = f"new_node_{next_node_id[0]}"
            next_node_id[0] += 1
            _split_link(
                features,
                split_feat_end,
                snapped_e_lon,
                snapped_e_lat,
                new_nid,
                next_link_id,
            )
            to_node_id = new_nid
            outcome["end_snapped"] = {"method": "split", "node": new_nid}
        else:
            outcome["end_snapped"] = {"method": "node", "node": to_node_id}
        assert to_node_id is not None

        # --- build new link geometry with snapped endpoints ---
        new_coords = [list(c) for c in coords]
        new_coords[0] = [snapped_s_lon, snapped_s_lat]
        new_coords[-1] = [snapped_e_lon, snapped_e_lat]
        list(reversed(new_coords))

        def _make_new_link(
            lcoords: list[list[float]],
            fn: str,
            tn: str,
            rev_ids: list[str] | None = None,
        ) -> tuple[str, dict]:
            lid = f"new_link_{next_link_id[0]}"
            next_link_id[0] += 1
            feat = {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": lcoords},
                "properties": {
                    "linkId": lid,
                    "fromNode": fn,
                    "toNode": tn,
                    "speed": speed,
                    "capacity": capacity,
                    "lanes": lanes,
                    "flow": 0,
                    "flow24hrs": 0,
                    "flowsPerDaypart": {"mrh": 0, "erh": 0, "rest": 0},
                    "length": _linestring_length(lcoords),
                    "heading": heading(lcoords),
                    "reverseLinkIds": rev_ids or [],
                    "parallelLinkIds": [],
                },
            }
            return lid, feat

        if direction == "forward":
            lid, new_feat = _make_new_link(new_coords, from_node_id, to_node_id)
            features.append(new_feat)
            outcome["links_created"].append(lid)
            links_added += 1

        elif direction == "backward":
            lid, new_feat = _make_new_link(list(reversed(new_coords)), to_node_id, from_node_id)
            features.append(new_feat)
            outcome["links_created"].append(lid)
            links_added += 1

        else:  # "both"
            heen_coords = offset_linestring(new_coords, _OFFSET_M)
            terug_coords = offset_linestring(list(reversed(new_coords)), _OFFSET_M)

            # Allocate both IDs upfront so each can reference the other
            fwd_id = f"new_link_{next_link_id[0]}"
            next_link_id[0] += 1
            rev_id = f"new_link_{next_link_id[0]}"
            next_link_id[0] += 1

            fwd_feat: dict = {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": heen_coords},
                "properties": {
                    "linkId": fwd_id,
                    "fromNode": from_node_id,
                    "toNode": to_node_id,
                    "speed": speed,
                    "capacity": capacity,
                    "lanes": lanes,
                    "flow": 0,
                    "flow24hrs": 0,
                    "flowsPerDaypart": {"mrh": 0, "erh": 0, "rest": 0},
                    "length": _linestring_length(heen_coords),
                    "heading": heading(heen_coords),
                    "reverseLinkIds": [rev_id],
                    "parallelLinkIds": [],
                },
            }
            rev_feat: dict = {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": terug_coords},
                "properties": {
                    "linkId": rev_id,
                    "fromNode": to_node_id,
                    "toNode": from_node_id,
                    "speed": speed,
                    "capacity": capacity,
                    "lanes": lanes,
                    "flow": 0,
                    "flow24hrs": 0,
                    "flowsPerDaypart": {"mrh": 0, "erh": 0, "rest": 0},
                    "length": _linestring_length(terug_coords),
                    "heading": heading(terug_coords),
                    "reverseLinkIds": [fwd_id],
                    "parallelLinkIds": [],
                },
            }
            features.extend([fwd_feat, rev_feat])
            outcome["links_created"].extend([fwd_id, rev_id])
            links_added += 2

        inserted += 1
        change_outcomes.append(outcome)

    result_fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": network_fc.get("properties"),
    }
    report = {
        "inserted": inserted,
        "links_added": links_added,
        "skipped": skipped,
        "warnings": warnings,
        "changes": change_outcomes,
    }
    logger.info(
        "insert_links complete: inserted=%d links_added=%d skipped=%d",
        inserted,
        links_added,
        skipped,
    )
    return result_fc, report
