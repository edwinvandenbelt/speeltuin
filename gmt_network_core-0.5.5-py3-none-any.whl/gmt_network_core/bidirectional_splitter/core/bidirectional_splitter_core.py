"""Pure-Python bidirectional-splitter core — no I/O, no boto3.

Converts raw bidirectional GeoJSON network features into directed unidirectional features.

Public API
----------
post_process_features(features) -> list
    Split bidirectional links into directed links, compute headings, and populate
    ``reverseLinkIds`` via a spatial KD-tree pass.
"""

from __future__ import annotations

from gmt_network_core.bidirectional_splitter.domain.network import (  # noqa: F401
    _estimate_capacity,
    _estimate_road_width,
    post_process_features,
)
