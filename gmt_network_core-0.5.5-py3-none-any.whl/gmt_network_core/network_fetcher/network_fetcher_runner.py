"""Local debug runner for network_fetcher.

Fetches raw network data from Databricks and writes bidirectional GeoJSON to S3 or disk.

Usage
-----
    # Using a bounding box (converted internally to a polygon):
    python -m network_fetcher.network_fetcher_runner \\
        --modes CAR BIKE --bbox 6.0 52.0 6.2 52.1 \\
        --output-folder s3://gmp-networks/network/ \\
        --area-id deventer-centrum \\
        --catalog spectrum --schema 2024_01

    # Using a GeoJSON polygon file (takes precedence over --bbox):
    python -m network_fetcher.network_fetcher_runner \\
        --modes CAR BIKE --polygon path/to/polygon.geojson \\
        --output-folder s3://gmp-networks/network/ \\
        --area-id deventer-centrum \\
        --catalog spectrum --schema 2024_01

Prerequisites
-------------
* Databricks credentials in a .env file or os.environ:
  DATABRICKS_HOST, DATABRICKS_WAREHOUSE_ID and one of:
  - DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET  (OAuth M2M, preferred)
  - DATABRICKS_TOKEN  (personal access token, fallback)
* AWS credentials available (only needed for s3:// URIs).
"""

from __future__ import annotations

import argparse
import json
import logging
import os
import sys
from pathlib import Path
from uuid import uuid4

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        data: bytes = get_bytes_s3(bucket, key)
        return data
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description="Local runner for network_fetcher (fetches raw network from Databricks)."
    )
    parser.add_argument(
        "--modes",
        nargs="+",
        required=True,
        metavar="MODE",
        help="One or more transport modes, e.g. CAR BIKE PEDESTRIAN",
    )
    parser.add_argument(
        "--bbox",
        nargs=4,
        type=float,
        default=None,
        metavar=("MIN_LON", "MIN_LAT", "MAX_LON", "MAX_LAT"),
        help="Bounding box as four floats (converted internally to a polygon).",
    )
    parser.add_argument(
        "--polygon",
        default=None,
        metavar="JSON_OR_PATH",
        help=(
            "Area of interest as a GeoJSON Polygon geometry — either an inline JSON string "
            "or a path to a .geojson/.json file. Takes precedence over --bbox when both are given."
        ),
    )
    parser.add_argument(
        "--output-folder",
        required=True,
        metavar="URI",
        help=(
            "Output folder URI (s3://bucket/prefix/ or local directory). "
            "Output files are named {area_id}-NETWORK-RAW-{mode}.parquet."
        ),
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help="Area identifier stored in output FC properties (optional).",
    )
    parser.add_argument(
        "--name", default=None, help="Human-readable area name stored in FC properties (optional)."
    )
    parser.add_argument("--catalog", default="spectrum", help="Databricks Unity Catalog name")
    parser.add_argument("--schema", default="2024_01", help="Databricks schema / dataset version")
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    parser.add_argument(
        "--regions-uri",
        default="s3://gmp-networks/indices/holiday_regions.geojson",
        metavar="URI",
        help=(
            "URI for holiday_regions.geojson used to determine the 'region' property "
            "stored in the output FC (used by flow_scaler). "
            "Pass an empty string to skip region detection. "
            "Default: s3://gmp-networks/indices/holiday_regions.geojson"
        ),
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Write debug artefacts such as the selection-polygon GeoJSON.",
    )
    parser.add_argument(
        "--w-mrh",
        type=float,
        default=2.0,
        metavar="HOURS",
        help="ETM hour-weight for ochtendspits (default: 2.0).",
    )
    parser.add_argument(
        "--w-erh",
        type=float,
        default=2.0,
        metavar="HOURS",
        help="ETM hour-weight for avondspits (default: 2.0).",
    )
    parser.add_argument(
        "--w-rest",
        type=float,
        default=20.0,
        metavar="HOURS",
        help="ETM hour-weight for restdag (default: 20.0).",
    )
    args = parser.parse_args()

    modes = [m.upper() for m in args.modes]

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    import gmt_shared.databricks_sql as databricks_sql
    from gmt_shared.geoparquet import to_geoparquet
    from gmt_shared.region import determine_region, to_bbox, to_polygon_geojson

    from gmt_network_core.network_fetcher.core.network_fetcher_core import (
        VALID_MODES,
        build_intersection_sql,
        get_pt_params,
        rows_to_feature_collection,
    )

    # --- resolve polygon JSON string ---
    if args.polygon is not None:
        polygon_src = args.polygon.strip()
        # treat as a file path if it doesn't start with '{'
        if not polygon_src.startswith("{"):
            polygon_path = Path(polygon_src)
            if not polygon_path.exists():
                parser.error(f"--polygon file not found: {polygon_path}")
            polygon_src = polygon_path.read_text(encoding="utf-8").strip()
        # validate it parses as JSON
        try:
            polygon_obj = json.loads(polygon_src)
        except json.JSONDecodeError as exc:
            parser.error(f"--polygon is not valid JSON: {exc}")
        polygon_json = json.dumps(polygon_obj, ensure_ascii=False)
        # derive a normalised bbox from polygon coordinates for FC properties.
        # Handles both Polygon (coordinates[0] = exterior ring)
        # and MultiPolygon (coordinates[i] = polygon with rings).
        geom_type = polygon_obj.get("type", "")
        raw_coords = polygon_obj.get("coordinates", [])
        all_lons: list[float] = []
        all_lats: list[float] = []
        if geom_type == "MultiPolygon":
            for poly in raw_coords:
                for ring in poly:
                    for c in ring:
                        all_lons.append(c[0])
                        all_lats.append(c[1])
        else:
            # Polygon or fallback: iterate exterior ring
            for ring in raw_coords:
                for c in ring:
                    if isinstance(c[0], (int, float)):
                        all_lons.append(c[0])
                        all_lats.append(c[1])
        if all_lons:
            normalised_bbox = [min(all_lons), min(all_lats), max(all_lons), max(all_lats)]
        else:
            normalised_bbox = []
    elif args.bbox is not None:
        polygon_json = to_polygon_geojson({"bbox": args.bbox})
        normalised_bbox = to_bbox({"bbox": args.bbox})
    else:
        parser.error("Provide at least one of --bbox or --polygon.")

    _PT_MODES = {"BUS", "TRAM", "METRO", "TRAIN"}

    if not args.area_id:
        args.area_id = str(uuid4())

    output_folder = args.output_folder.rstrip("/") + "/"

    # --- resolve holiday region (optional) ---
    region: str | None = None
    if args.regions_uri:
        try:
            print(f"Reading regions      : {args.regions_uri}")
            regions_raw = json.loads(_read_uri(args.regions_uri))
            region_features = regions_raw.get("features", [])
            region = determine_region(normalised_bbox, region_features)
            print(f"Region               : {region!r}")
        except Exception as exc:
            print(
                f"[warn] Could not load holiday regions from {args.regions_uri!r}: {exc}"
                " — region will be None",
                file=sys.stderr,
            )

    with databricks_sql.connect_from_env() as conn:
        # Write the selection polygon only in debug mode.
        if args.debug:
            polygon_uri = f"{output_folder}{args.area_id}-SELECTION-POLYGON.geojson"
            polygon_fc = json.dumps(
                {
                    "type": "FeatureCollection",
                    "features": [
                        {
                            "type": "Feature",
                            "geometry": json.loads(polygon_json),
                            "properties": {"area_id": args.area_id, "name": args.name},
                        }
                    ],
                },
                ensure_ascii=False,
            )
            print(f"\nWriting selection polygon : {polygon_uri}")
            _write_uri(polygon_uri, polygon_fc.encode("utf-8"))

        for mode in modes:
            if mode not in VALID_MODES:
                print(f"[warn] Unknown mode {mode!r} — skipping.", file=sys.stderr)
                continue

            print(f"\nMode     : {mode}")
            sql = build_intersection_sql(
                mode,
                args.catalog,
                args.schema,
                weights={"mrh": args.w_mrh, "erh": args.w_erh, "rest": args.w_rest},
            )

            with conn.cursor() as cur:
                if mode in _PT_MODES:
                    link_mode, modaliteit = get_pt_params(mode)
                    cur.execute(sql, (link_mode, polygon_json, modaliteit, mode))
                else:
                    cur.execute(sql, (polygon_json,))
                col_names = [d[0] for d in cur.description]
                rows = cur.fetchall()

            print(f"Raw rows : {len(rows)}")

            meta: dict = {}
            if args.area_id:
                meta["area_id"] = args.area_id
            if args.name:
                meta["name"] = args.name

            fc = rows_to_feature_collection(rows, col_names, mode)
            fc["properties"].update({"bbox": normalised_bbox, "region": region, **meta})

            print(f"Features : {len(fc['features'])}")

            out_uri = f"{output_folder}{args.area_id}-NETWORK-RAW-{mode}.parquet"
            print(f"Writing  : {out_uri}")
            _write_uri(out_uri, to_geoparquet(fc))

    print("\nDone.")


if __name__ == "__main__":
    main()
