"""Pure-Python network-fetcher core — no I/O, no boto3, no Databricks connections.

Builds Databricks SQL queries and assembles raw result rows into a GeoJSON FeatureCollection.

Public API
----------
build_intersection_sql(mode, catalog, schema) -> str
    Return the parameterised Databricks SQL string for the given transport mode.
get_pt_params(mode) -> tuple[str, str]
    Return (link_mode, modaliteit) for a public-transport mode.
rows_to_feature_collection(rows, col_names, mode) -> dict
    Convert raw Databricks result rows into a GeoJSON FeatureCollection.
filter_network_fc(network_fc, *, max_speed_kmh, max_flow) -> dict
    Remove links that exceed a speed or flow threshold.
merge_network_feature_collections(fcs) -> dict
    Merge multiple single-mode FeatureCollections into one multimodal collection.
"""

from __future__ import annotations

from gmt_network_core.network_fetcher.domain.network import (  # noqa: F401
    LINK_PROPERTIES,
    rows_to_feature_collection,
)
from gmt_network_core.network_fetcher.domain.sql import (  # noqa: F401
    _DAYPART_KEYS,
    _MOTIEF_KEYS,
    _PT_PARAMS,
    VALID_MODES,
    build_intersection_sql,
    get_pt_params,
)


def filter_network_fc(
    network_fc: dict,
    *,
    max_speed_kmh: float | None = None,
    max_flow: float | None = None,
) -> tuple[dict, dict]:
    """Remove links from *network_fc* that exceed speed or flow thresholds.

    Filtering is applied to the raw bidirectional network (output of
    ``rows_to_feature_collection``), before simplification and splitting.

    Parameters
    ----------
    network_fc:
        GeoJSON FeatureCollection as returned by ``rows_to_feature_collection``.
    max_speed_kmh:
        When set, links are excluded when the highest passable design speed
        (``max_snelheid_heen`` or ``max_snelheid_terug``) exceeds this value.
        Useful for removing motorways / snelwegen (e.g. ``max_speed_kmh=90``).
    max_flow:
        When set, links are excluded when the total 24-hr ETM flow
        (sum of all motives in both directions) exceeds this value.
        Useful for removing heavily loaded arterials.

    Returns
    -------
    tuple[dict, dict]
        ``(filtered_fc, stats)`` where *stats* contains:
        ``{"input": int, "removed_speed": int, "removed_flow": int, "kept": int}``.
    """
    if max_speed_kmh is None and max_flow is None:
        stats = {
            "input": len(network_fc.get("features") or []),
            "removed_speed": 0,
            "removed_flow": 0,
            "kept": len(network_fc.get("features") or []),
        }
        return network_fc, stats

    kept: list[dict] = []
    removed_speed = 0
    removed_flow = 0

    for feat in network_fc.get("features") or []:
        props = feat.get("properties") or {}

        # Speed filter: exclude if the highest design speed in any passable
        # direction exceeds max_speed_kmh.
        if max_speed_kmh is not None:
            spd_heen = props.get("max_snelheid_heen") or 0.0
            spd_terug = props.get("max_snelheid_terug") or 0.0
            if max(float(spd_heen), float(spd_terug)) > max_speed_kmh:
                removed_speed += 1
                continue

        # Flow filter: exclude if total 24-hr ETM flow exceeds max_flow.
        if max_flow is not None:
            flow_heen = props.get("flow_heen") or {}
            flow_terug = props.get("flow_terug") or {}
            total = sum(float(v) for v in flow_heen.values()) + sum(
                float(v) for v in flow_terug.values()
            )
            if total > max_flow:
                removed_flow += 1
                continue

        kept.append(feat)

    filtered_fc = {**network_fc, "features": kept}
    stats = {
        "input": len(network_fc.get("features") or []),
        "removed_speed": removed_speed,
        "removed_flow": removed_flow,
        "kept": len(kept),
    }
    return filtered_fc, stats


def merge_network_feature_collections(fcs: list[dict]) -> dict:
    """Merge multiple single-mode network FeatureCollections into one.

    Each input FeatureCollection must have been produced by
    ``rows_to_feature_collection`` for a single transport mode.  The resulting
    collection contains all features from every input; each feature retains its
    own ``"mode"`` property.  The FeatureCollection-level ``"modes"`` list is
    the union of all input ``"modes"`` lists (order preserved, no duplicates).
    The ``"fields"`` list is the union of all input ``"fields"`` lists.

    Parameters
    ----------
    fcs:
        One or more GeoJSON FeatureCollection dicts.  Must not be empty.

    Returns
    -------
    dict
        A single merged FeatureCollection.

    Raises
    ------
    ValueError
        When *fcs* is empty.
    """
    if not fcs:
        raise ValueError(
            "merge_network_feature_collections requires at least one FeatureCollection."
        )
    if len(fcs) == 1:
        return fcs[0]

    all_features: list[dict] = []
    merged_modes: list[str] = []
    merged_fields: list[str] = []
    fields_seen: set[str] = set()
    base_props: dict = {}

    for fc in fcs:
        all_features.extend(fc.get("features") or [])
        props = fc.get("properties") or {}
        for m in props.get("modes") or []:
            if m not in merged_modes:
                merged_modes.append(m)
        for f in props.get("fields") or []:
            if f not in fields_seen:
                merged_fields.append(f)
                fields_seen.add(f)
        if not base_props:
            base_props = {k: v for k, v in props.items() if k not in ("modes", "fields")}

    return {
        "type": "FeatureCollection",
        "features": all_features,
        "properties": {
            **base_props,
            "modes": merged_modes,
            "fields": merged_fields,
        },
    }
