"""Network GeoJSON parser for feedlink_fetcher — extracts node positions."""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


def parse_network_geojson(fc: dict) -> tuple[dict, set]:
    """Parse a network FeatureCollection into node lookup tables.

    Parameters
    ----------
    fc:
        GeoJSON FeatureCollection of directed network link features.

    Returns
    -------
    tuple[dict, set]
        ``(node_positions, all_node_ids)`` where *node_positions* maps
        ``node_id → (lon, lat)`` and *all_node_ids* is the complete set of
        node IDs seen in the network.
    """
    features = fc.get("features") or []
    node_positions: dict = {}

    for feat in features:
        props = feat.get("properties") or {}
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords:
            continue
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is not None:
            node_positions.setdefault(from_node, (coords[0][0], coords[0][1]))
        if to_node is not None:
            node_positions.setdefault(to_node, (coords[-1][0], coords[-1][1]))

    all_node_ids = set(node_positions.keys())
    logger.info("Parsed network: %d features, %d nodes", len(features), len(all_node_ids))
    return node_positions, all_node_ids


def node_flow_totals(fc: dict) -> tuple[dict, dict]:
    """Return per-node summed outgoing and incoming ``flow`` from a directed network.

    Used by the fallback feedlink attachment logic (see
    ``feedlink.build_feedlinks``/``feedlink._best_by_flow``) to pick, among the
    nodes geometrically nearest to a zone centroid, the one that actually
    carries the most traffic in the relevant direction — rather than literally
    the nearest point in space, which could be the endpoint of a minor
    residential or service road.

    Parameters
    ----------
    fc:
        GeoJSON FeatureCollection of directed network link features, each
        with a ``flow`` property and ``fromNode``/``toNode`` properties.

    Returns
    -------
    tuple[dict, dict]
        ``(outgoing_flow, incoming_flow)`` — two ``node_id -> float`` dicts.
        *outgoing_flow* sums a link's ``flow`` onto its ``fromNode``;
        *incoming_flow* sums it onto its ``toNode``.
    """
    features = fc.get("features") or []
    outgoing_flow: dict = {}
    incoming_flow: dict = {}
    for feat in features:
        props = feat.get("properties") or {}
        flow = float(props.get("flow") or 0.0)
        from_node = props.get("fromNode")
        to_node = props.get("toNode")
        if from_node is not None:
            outgoing_flow[from_node] = outgoing_flow.get(from_node, 0.0) + flow
        if to_node is not None:
            incoming_flow[to_node] = incoming_flow.get(to_node, 0.0) + flow
    logger.info(
        "Computed node flow totals: %d outgoing, %d incoming node(s) out of %d link features",
        len(outgoing_flow),
        len(incoming_flow),
        len(features),
    )
    return outgoing_flow, incoming_flow
