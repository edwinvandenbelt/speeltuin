"""Tests for feedlink_fetcher core domain logic."""

from __future__ import annotations

import pytest

from gmt_network_core.feedlink_fetcher.domain.feedlink import (
    FEEDLINK_PROPERTIES,
    _best_by_flow,
    _nearest_nodes,
    build_feedlinks,
)
from gmt_network_core.feedlink_fetcher.domain.network import (
    node_flow_totals,
    parse_network_geojson,
)
from gmt_network_core.feedlink_fetcher.domain.sql import (
    VOEDINGSLINKS_TABLE,
    build_voedingslinks_sql,
)

# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _make_zone_feature(
    gid: int,
    zone_id: str,
    zone_class: str = "STUDY",
    production: float = 100.0,
    attraction: float = 80.0,
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Point", "coordinates": [6.0, 52.0]},
        "properties": {
            "gid": gid,
            "zoneId": zone_id,
            "zoneClass": zone_class,
            "centroidLon": 6.0,
            "centroidLat": 52.0,
            "production": production,
            "attraction": attraction,
        },
    }


def _make_link_feature(
    from_node: str,
    to_node: str,
    from_coords: list,
    to_coords: list,
    speed: float | None = None,
    flow: float | None = None,
) -> dict:
    props: dict[str, object] = {
        "linkId": f"{from_node}-{to_node}",
        "fromNode": from_node,
        "toNode": to_node,
    }
    if speed is not None:
        props["speed"] = speed
    if flow is not None:
        props["flow"] = flow
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [from_coords, to_coords]},
        "properties": props,
    }


def _zones_fc(*features) -> dict:
    return {"type": "FeatureCollection", "features": list(features)}


def _network_fc(*features) -> dict:
    return {"type": "FeatureCollection", "features": list(features)}


# ---------------------------------------------------------------------------
# parse_network_geojson
# ---------------------------------------------------------------------------


class TestParseNetworkGeojson:
    def test_basic_two_nodes(self):
        fc = _network_fc(
            _make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1]),
        )
        pos, ids = parse_network_geojson(fc)
        assert ids == {"A", "B"}
        assert pos["A"] == (6.0, 52.0)
        assert pos["B"] == (6.1, 52.1)

    def test_empty_network(self):
        pos, ids = parse_network_geojson({"type": "FeatureCollection", "features": []})
        assert ids == set()
        assert pos == {}

    def test_duplicate_nodes_keep_first_position(self):
        fc = _network_fc(
            _make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1]),
            _make_link_feature(
                "A", "C", [6.9, 52.9], [6.2, 52.2]
            ),  # A seen again, different coords
        )
        pos, ids = parse_network_geojson(fc)
        # First-seen position is retained
        assert pos["A"] == (6.0, 52.0)
        assert "C" in ids

    def test_feature_without_geometry_skipped(self):
        fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": None,
                    "properties": {"fromNode": "X", "toNode": "Y"},
                },
            ],
        }
        _pos, ids = parse_network_geojson(fc)
        assert ids == set()


# ---------------------------------------------------------------------------
# build_voedingslinks_sql
# ---------------------------------------------------------------------------


class TestBuildVoedingslinksSql:
    def test_single_gid(self):
        sql = build_voedingslinks_sql("cat", "sch", "d110_voedingslinks", [42])
        assert "van_centroid_gid IN (42)" in sql
        assert "`cat`.`sch`.d110_voedingslinks" in sql

    def test_multiple_gids(self):
        sql = build_voedingslinks_sql("cat", "sch", "d110_voedingslinks", [1, 2, 3])
        assert "1, 2, 3" in sql

    def test_empty_gids_gives_where_false(self):
        sql = build_voedingslinks_sql("cat", "sch", "d110_voedingslinks", [])
        assert "WHERE FALSE" in sql

    def test_required_columns_present(self):
        sql = build_voedingslinks_sql("cat", "sch", "tbl", [1])
        for col in ("van_centroid_gid", "naar_knoop_id", "wkt_geom_4326"):
            assert col in sql

    def test_other_schema_uses_geom_4326(self):
        """Non-2024_01 schemas select geom_4326 directly."""
        sql = build_voedingslinks_sql("cat", "2025_01", "tbl", [1])
        assert "ST_AsText(geom_4326)" in sql
        assert "ST_Transform" not in sql

    def test_2024_01_transforms_geom_28992_to_4326(self):
        """2024_01 transforms geom_28992 to WGS-84 for consistent output."""
        sql = build_voedingslinks_sql("cat", "2024_01", "tbl", [1])
        assert "ST_AsText(ST_Transform(geom_28992, 4326))" in sql
        assert "ST_AsText(geom_4326)" not in sql  # raw geom_4326 column not used


class TestVoedingslinksTable:
    def test_car_has_table(self):
        assert VOEDINGSLINKS_TABLE["CAR"] == "d110_voedingslinks"

    def test_bike_has_table(self):
        assert VOEDINGSLINKS_TABLE["BIKE"] == "d120_voedingslinks"

    def test_pedestrian_is_none(self):
        assert VOEDINGSLINKS_TABLE["PEDESTRIAN"] is None


# ---------------------------------------------------------------------------
# build_feedlinks
# ---------------------------------------------------------------------------


def _vl_row(gid: int, node_id: str) -> dict:
    return {
        "van_centroid_gid": gid,
        "naar_knoop_id": node_id,
        "wkt_geom_4326": None,
    }


class TestBuildFeedlinks:
    def _run(self, zones_fc, network_fc, vl_rows, mode="CAR"):
        pos, ids = parse_network_geojson(network_fc)
        return build_feedlinks(zones_fc, pos, ids, vl_rows, mode)

    def test_production_and_attraction_created(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=100.0, attraction=80.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        props = [f["properties"] for f in fc["features"]]
        assert any(p["fromNode"] == "1" and p["toNode"] == "N1" for p in props), (
            "production missing"
        )
        assert any(p["fromNode"] == "N1" and p["toNode"] == "1" for p in props), (
            "attraction missing"
        )

    def test_area_zone_skipped(self):
        zones = _zones_fc(
            _make_zone_feature(1, "Z1", zone_class="AREA", production=100.0),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        assert fc["features"] == []

    def test_node_not_in_network_triggers_fallback(self):
        """When the vl_row references a missing node, the zone gets a fallback feedlink
        to the nearest real network node instead of being silently dropped."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "NONEXISTENT")])
        # Fallback to N1 (nearest node)
        node_ids = {
            f["properties"]["toNode"] for f in fc["features"] if f["properties"]["fromNode"] == "1"
        }
        assert len(node_ids) == 1
        assert node_ids.pop() in {"N1", "N2"}

    def test_zero_production_gets_zero_capacity_connectivity_feedlink(self):
        """Production has no demand, but the zone still gets a zero-capacity
        production feedlink (not suppressed) alongside the real attraction one."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=50.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        props = [f["properties"] for f in fc["features"]]
        prod = next(p for p in props if p["fromNode"] == "1")
        assert prod["source"] == "databricks-production-connectivity"
        assert prod["capacity"] == 0.0
        attr = next(p for p in props if p["toNode"] == "1")
        assert attr["source"] == "databricks"
        assert attr["capacity"] == 50.0

    def test_zero_attraction_gets_zero_capacity_connectivity_feedlink(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=50.0, attraction=0.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        props = [f["properties"] for f in fc["features"]]
        prod = next(p for p in props if p["fromNode"] == "1")
        assert prod["source"] == "databricks"
        assert prod["capacity"] == 50.0
        attr = next(p for p in props if p["toNode"] == "1")
        assert attr["source"] == "databricks-attraction-connectivity"
        assert attr["capacity"] == 0.0

    def test_feedlink_properties_present(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        for feat in fc["features"]:
            for key in FEEDLINK_PROPERTIES:
                assert key in feat["properties"], f"Missing property {key!r}"

    def test_capacity_equals_production_or_attraction(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=123.0, attraction=456.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        caps = {f["properties"]["capacity"] for f in fc["features"]}
        assert 123.0 in caps
        assert 456.0 in caps

    def test_multiple_zones(self):
        zones = _zones_fc(
            _make_zone_feature(1, "Z1", production=10.0, attraction=10.0),
            _make_zone_feature(2, "Z2", production=20.0, attraction=20.0),
        )
        net = _network_fc(
            _make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]),
            _make_link_feature("N3", "N4", [6.2, 52.2], [6.3, 52.3]),
        )
        fc = self._run(zones, net, [_vl_row(1, "N1"), _vl_row(2, "N3")])
        zone_ids = {f["properties"]["zoneId"] for f in fc["features"]}
        assert "Z1" in zone_ids
        assert "Z2" in zone_ids

    def test_empty_vl_rows_triggers_fallback(self):
        """No voedingslinks rows → all zones are uncovered → fallback feedlinks created."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        assert len(fc["features"]) > 0

    def test_output_is_feature_collection(self):
        fc = self._run(_zones_fc(), _network_fc(), [])
        assert fc["type"] == "FeatureCollection"
        assert "features" in fc

    def test_mode_stored_on_feedlink(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")], mode="BIKE")
        for feat in fc["features"]:
            assert feat["properties"]["mode"] == "BIKE"

    def test_feedlink_ids_sequential(self):
        zones = _zones_fc(
            _make_zone_feature(1, "Z1"),
            _make_zone_feature(2, "Z2"),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1"), _vl_row(2, "N1")])
        ids = [f["properties"]["feedlinkId"] for f in fc["features"]]
        assert ids == sorted(ids)
        assert len(set(ids)) == len(ids), "feedlinkIds must be unique"

    def test_reverse_link_ids_cross_reference(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        feats = fc["features"]
        assert len(feats) == 2
        prod = next(f for f in feats if f["properties"]["fromNode"] == "1")
        attr = next(f for f in feats if f["properties"]["toNode"] == "1")
        assert prod["properties"]["reverseLinkIds"] == [attr["properties"]["feedlinkId"]]
        assert attr["properties"]["reverseLinkIds"] == [prod["properties"]["feedlinkId"]]

    def test_geometry_is_linestring(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        for feat in fc["features"]:
            assert feat["geometry"]["type"] == "LineString"

    def test_influence_zone_included(self):
        zones = _zones_fc(_make_zone_feature(3, "Z3", zone_class="INFLUENCE"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(3, "N1")])
        assert len(fc["features"]) > 0

    def test_covered_zero_production_and_attraction_gets_connectivity_feedlink(self):
        """A zone covered by a vl_row but with 0 production and 0 attraction
        still gets one zero-capacity connectivity feedlink per direction."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=0.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 2
        assert all(f["properties"]["capacity"] == 0.0 for f in z1_feats)
        sources = {f["properties"]["source"] for f in z1_feats}
        assert sources == {
            "databricks-production-connectivity",
            "databricks-attraction-connectivity",
        }

    def test_covered_zero_demand_reverse_link_ids_cross_reference(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=0.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        prod = next(
            f
            for f in fc["features"]
            if f["properties"]["source"] == "databricks-production-connectivity"
        )
        attr = next(
            f
            for f in fc["features"]
            if f["properties"]["source"] == "databricks-attraction-connectivity"
        )
        assert prod["properties"]["reverseLinkIds"] == [attr["properties"]["feedlinkId"]]
        assert attr["properties"]["reverseLinkIds"] == [prod["properties"]["feedlinkId"]]

    def test_databricks_feedlinks_have_source_databricks(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        for feat in fc["features"]:
            assert feat["properties"]["source"] == "databricks"


# ---------------------------------------------------------------------------
# _nearest_nodes / _best_by_flow
# ---------------------------------------------------------------------------


class TestNearestNodes:
    def test_single_node_is_nearest(self):
        candidates = _nearest_nodes(6.0, 52.0, {"N1": (6.0, 52.0)}, top_n=10)
        assert candidates[0][0] == "N1"
        assert candidates[0][1] == pytest.approx(0.0, abs=1e-3)

    def test_sorted_ascending_by_distance(self):
        nodes = {
            "NEAR": (6.001, 52.0),  # ~70 m away
            "FAR": (6.1, 52.0),  # ~7 km away
        }
        candidates = _nearest_nodes(6.0, 52.0, nodes, top_n=10)
        assert [node_id for node_id, _ in candidates] == ["NEAR", "FAR"]

    def test_truncates_to_top_n(self):
        nodes = {
            "N0": (6.000, 52.0),
            "N1": (6.001, 52.0),
            "N2": (6.002, 52.0),
            "N3": (6.003, 52.0),
        }
        candidates = _nearest_nodes(6.0, 52.0, nodes, top_n=2)
        assert [node_id for node_id, _ in candidates] == ["N0", "N1"]

    def test_empty_node_positions_returns_empty_list(self):
        assert _nearest_nodes(6.0, 52.0, {}, top_n=10) == []


class TestBestByFlow:
    def test_picks_highest_flow_candidate(self):
        candidates = [("A", 100.0), ("B", 50.0), ("C", 10.0)]
        flow_by_node = {"A": 1.0, "B": 99.0, "C": 5.0}
        node_id, dist = _best_by_flow(candidates, flow_by_node)
        assert node_id == "B"
        assert dist == 50.0

    def test_ties_break_by_nearest_distance(self):
        candidates = [("FAR", 200.0), ("NEAR", 10.0)]
        flow_by_node = {"FAR": 5.0, "NEAR": 5.0}
        node_id, dist = _best_by_flow(candidates, flow_by_node)
        assert node_id == "NEAR"
        assert dist == 10.0

    def test_missing_flow_degrades_to_nearest(self):
        """With no flow data at all, the nearest candidate wins (plain
        nearest-node behaviour)."""
        candidates = [("FAR", 200.0), ("NEAR", 10.0)]
        node_id, dist = _best_by_flow(candidates, {})
        assert node_id == "NEAR"
        assert dist == 10.0

    def test_empty_candidates_returns_none_and_inf(self):
        node_id, dist = _best_by_flow([], {"A": 10.0})
        assert node_id is None
        assert dist == float("inf")


# ---------------------------------------------------------------------------
# node_flow_totals
# ---------------------------------------------------------------------------


class TestNodeFlowTotals:
    def test_sums_outgoing_and_incoming_flow(self):
        fc = _network_fc(
            _make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1], flow=10.0),
            _make_link_feature("A", "C", [6.0, 52.0], [6.2, 52.2], flow=5.0),
            _make_link_feature("D", "B", [6.3, 52.3], [6.1, 52.1], flow=2.0),
        )
        outgoing, incoming = node_flow_totals(fc)
        assert outgoing == {"A": 15.0, "D": 2.0}
        assert incoming == {"B": 12.0, "C": 5.0}

    def test_missing_flow_property_is_treated_as_zero(self):
        fc = _network_fc(_make_link_feature("A", "B", [6.0, 52.0], [6.1, 52.1]))
        outgoing, incoming = node_flow_totals(fc)
        assert outgoing == {"A": 0.0}
        assert incoming == {"B": 0.0}

    def test_empty_network(self):
        outgoing, incoming = node_flow_totals(_network_fc())
        assert outgoing == {}
        assert incoming == {}


# ---------------------------------------------------------------------------
# Fallback feedlink behaviour in build_feedlinks
# ---------------------------------------------------------------------------


class TestFallbackFeedlinks:
    def _run(
        self,
        zones_fc,
        network_fc,
        vl_rows,
        mode="CAR",
        outgoing_flow=None,
        incoming_flow=None,
        top_n=10,
    ):
        pos, ids = parse_network_geojson(network_fc)
        return build_feedlinks(
            zones_fc,
            pos,
            ids,
            vl_rows,
            mode,
            outgoing_flow=outgoing_flow,
            incoming_flow=incoming_flow,
            top_n=top_n,
        )

    def test_uncovered_zone_gets_fallback_feedlink(self):
        """Zone with no vl_row at all must receive a fallback feedlink."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        zone_ids = {f["properties"]["zoneId"] for f in fc["features"]}
        assert "Z1" in zone_ids

    def test_covered_zone_does_not_get_extra_fallback(self):
        """A zone linked by a valid vl_row must NOT also appear as a fallback."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        # Should have exactly 2 feedlinks (production + attraction), not 4
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 2

    def test_fallback_uses_nearest_node(self):
        """Among multiple nodes the fallback picks the closest one."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        # Z1 centroid at (6.0, 52.0) — N_NEAR is much closer than N_FAR
        net = _network_fc(
            _make_link_feature("N_NEAR", "X1", [6.001, 52.0], [6.002, 52.0]),
            _make_link_feature("N_FAR", "X2", [6.5, 52.0], [6.6, 52.0]),
        )
        fc = self._run(zones, net, [])
        prod = next(f for f in fc["features"] if f["properties"]["fromNode"] == "1")
        assert prod["properties"]["toNode"] == "N_NEAR"

    def test_fallback_prefers_highest_flow_node_over_nearer_zero_flow_node(self):
        """With outgoing_flow given, the fallback must skip a nearer node
        with no flow in favour of a farther one carrying outgoing flow."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(
            _make_link_feature("N_NEAR_NOFLOW", "X1", [6.001, 52.0], [6.002, 52.0], flow=0.0),
            _make_link_feature("N_FAR_FLOW", "X2", [6.01, 52.0], [6.02, 52.0], flow=80.0),
        )
        outgoing, incoming = node_flow_totals(net)
        fc = self._run(zones, net, [], outgoing_flow=outgoing, incoming_flow=incoming)
        prod = next(f for f in fc["features"] if f["properties"]["fromNode"] == "1")
        assert prod["properties"]["toNode"] == "N_FAR_FLOW"

    def test_fallback_production_and_attraction_attach_to_different_nodes(self):
        """When one nearby node has the highest outgoing flow and a different
        one has the highest incoming flow, production and attraction attach
        to two different nodes."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(
            # OUT_NODE: high outgoing flow, low incoming flow.
            _make_link_feature("OUT_NODE", "X1", [6.001, 52.0], [6.011, 52.0], flow=100.0),
            # IN_NODE: high incoming flow, low outgoing flow.
            _make_link_feature("X2", "IN_NODE", [6.012, 52.0], [6.002, 52.0], flow=100.0),
        )
        outgoing, incoming = node_flow_totals(net)
        fc = self._run(zones, net, [], outgoing_flow=outgoing, incoming_flow=incoming)
        prod = next(f for f in fc["features"] if f["properties"]["fromNode"] == "1")
        attr = next(f for f in fc["features"] if f["properties"]["toNode"] == "1")
        assert prod["properties"]["toNode"] == "OUT_NODE"
        assert attr["properties"]["fromNode"] == "IN_NODE"

    def test_fallback_ignores_high_flow_node_outside_top_n_window(self):
        """A node with the highest flow but outside the nearest-top_n window
        must be ignored in favour of the best candidate within the window."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(
            # N0, N1 are close to the zone (their link's far endpoint is
            # irrelevant and placed well outside the top_n window).
            _make_link_feature("N0", "Z_FAR0", [6.001, 52.0], [6.6, 52.0], flow=1.0),
            _make_link_feature("N1", "Z_FAR1", [6.002, 52.0], [6.7, 52.0], flow=2.0),
            # FAR_HIGH_FLOW is geometrically farther than N0/N1 and therefore
            # outside a top_n=2 window, despite carrying far more flow.
            _make_link_feature("FAR_HIGH_FLOW", "Z_FAR2", [6.5, 52.0], [6.8, 52.0], flow=1000.0),
        )
        outgoing, incoming = node_flow_totals(net)
        fc = self._run(zones, net, [], outgoing_flow=outgoing, incoming_flow=incoming, top_n=2)
        prod = next(f for f in fc["features"] if f["properties"]["fromNode"] == "1")
        assert prod["properties"]["toNode"] != "FAR_HIGH_FLOW"
        assert prod["properties"]["toNode"] == "N1"

    def test_fallback_zero_production_and_attraction_gets_connectivity_feedlink(self):
        """Zone with 0 production and 0 attraction still gets one zero-capacity
        connectivity feedlink per direction, instead of being left out entirely."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=0.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 2
        assert all(f["properties"]["capacity"] == 0.0 for f in z1_feats)
        sources = {f["properties"]["source"] for f in z1_feats}
        assert sources == {"fallback-production-connectivity", "fallback-attraction-connectivity"}

    def test_fallback_production_only_zero_gets_single_connectivity_feedlink(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=10.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 2
        by_source = {f["properties"]["source"]: f for f in z1_feats}
        assert by_source["fallback-production-connectivity"]["properties"]["capacity"] == 0.0
        assert by_source["fallback"]["properties"]["capacity"] == 10.0

    def test_fallback_attraction_only_zero_gets_single_connectivity_feedlink(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=0.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 2
        by_source = {f["properties"]["source"]: f for f in z1_feats}
        assert by_source["fallback-attraction-connectivity"]["properties"]["capacity"] == 0.0
        assert by_source["fallback"]["properties"]["capacity"] == 10.0

    def test_fallback_zero_demand_reverse_link_ids_cross_reference(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=0.0))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        prod = next(
            f
            for f in fc["features"]
            if f["properties"]["source"] == "fallback-production-connectivity"
        )
        attr = next(
            f
            for f in fc["features"]
            if f["properties"]["source"] == "fallback-attraction-connectivity"
        )
        assert prod["properties"]["reverseLinkIds"] == [attr["properties"]["feedlinkId"]]
        assert attr["properties"]["reverseLinkIds"] == [prod["properties"]["feedlinkId"]]

    def test_fallback_zero_production_and_attraction_no_network_gives_no_feedlink(self):
        """Without any network node, even the connectivity fallback can't be built."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=0.0, attraction=0.0))
        net = _network_fc()
        fc = self._run(zones, net, [])
        assert fc["features"] == []

    def test_fallback_empty_network_no_feedlinks(self):
        """If the network is empty no fallback feedlinks can be created."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc()
        fc = self._run(zones, net, [])
        assert fc["features"] == []

    def test_fallback_feedlink_properties_present(self):
        """All FEEDLINK_PROPERTIES must be present on fallback feedlinks."""
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        for feat in fc["features"]:
            for key in FEEDLINK_PROPERTIES:
                assert key in feat["properties"], f"Missing property {key!r}"

    def test_fallback_geometry_is_linestring(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        for feat in fc["features"]:
            assert feat["geometry"]["type"] == "LineString"

    def test_fallback_feedlink_ids_unique_across_vl_and_fallback(self):
        """IDs from the vl_rows loop and the fallback loop must not overlap."""
        zones = _zones_fc(
            _make_zone_feature(1, "Z1"),
            _make_zone_feature(2, "Z2"),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        # Z1 covered by vl_row, Z2 uncovered → gets fallback
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        ids = [f["properties"]["feedlinkId"] for f in fc["features"]]
        assert len(set(ids)) == len(ids), "feedlinkIds must be unique"

    def test_fallback_mode_stored_on_feedlink(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [], mode="PEDESTRIAN")
        for feat in fc["features"]:
            assert feat["properties"]["mode"] == "PEDESTRIAN"

    def test_fallback_feedlinks_have_source_fallback(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1"))
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [])
        for feat in fc["features"]:
            assert feat["properties"]["source"] == "fallback"

    def test_mixed_source_values_correct(self):
        """Z1 covered by Databricks, Z2 gets fallback — sources must differ."""
        zones = _zones_fc(
            _make_zone_feature(1, "Z1"),
            _make_zone_feature(2, "Z2"),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        fc = self._run(zones, net, [_vl_row(1, "N1")])
        z1_sources = {
            f["properties"]["source"] for f in fc["features"] if f["properties"]["zoneId"] == "Z1"
        }
        z2_sources = {
            f["properties"]["source"] for f in fc["features"] if f["properties"]["zoneId"] == "Z2"
        }
        assert z1_sources == {"databricks"}
        assert z2_sources == {"fallback"}

    def test_negative_gid_aggregated_zone_gets_fallback_alongside_covered_real_zone(self):
        """Integration contract with zone_fetcher_aggregated: a normal positive-gid
        zone covered by a vl_row keeps its databricks-sourced feedlinks unaffected,
        while a STUDY/INFLUENCE zone with a negative synthetic gid (never present in
        vl_rows, by construction) falls through to the fallback path — getting both
        a production (outbound) and attraction (inbound) feedlink attached to the
        highest-flow node among its nearest candidates."""
        zones = _zones_fc(
            _make_zone_feature(1, "Z1", zone_class="STUDY", production=10.0, attraction=10.0),
            _make_zone_feature(-1, "AGG1", zone_class="INFLUENCE", production=5.0, attraction=5.0),
        )
        net = _network_fc(
            _make_link_feature("N1", "X1", [6.0, 52.0], [6.1, 52.1]),
            _make_link_feature("N_NEAR_NOFLOW", "X2", [6.001, 52.0], [6.002, 52.0], flow=0.0),
            # N_FAR_FLOW carries both outgoing and incoming flow (two separate
            # links) so it wins the highest-flow pick in both directions.
            _make_link_feature("X3", "N_FAR_FLOW", [6.02, 52.0], [6.01, 52.0], flow=80.0),
            _make_link_feature("N_FAR_FLOW", "X4", [6.01, 52.0], [6.03, 52.0], flow=80.0),
        )
        outgoing, incoming = node_flow_totals(net)
        fc = self._run(
            zones, net, [_vl_row(1, "N1")], outgoing_flow=outgoing, incoming_flow=incoming
        )

        # Real zone Z1: unaffected, still sourced from databricks.
        z1_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "Z1"]
        assert len(z1_feats) == 2
        assert {f["properties"]["source"] for f in z1_feats} == {"databricks"}

        # Aggregated zone AGG1 (negative gid, no vl_row): fallback path, both
        # production (outbound) and attraction (inbound) feedlinks, attached to
        # the highest-flow node rather than the nearer zero-flow one.
        agg_feats = [f for f in fc["features"] if f["properties"]["zoneId"] == "AGG1"]
        assert len(agg_feats) == 2
        assert {f["properties"]["source"] for f in agg_feats} == {"fallback"}
        prod = next(f for f in agg_feats if f["properties"]["fromNode"] == "-1")
        attr = next(f for f in agg_feats if f["properties"]["toNode"] == "-1")
        assert prod["properties"]["toNode"] == "N_FAR_FLOW"
        assert attr["properties"]["fromNode"] == "N_FAR_FLOW"

    def test_pedestrian_mode_all_zones_get_fallback(self):
        """PEDESTRIAN has no Databricks table so all zones should be linked via fallback."""
        zones = _zones_fc(
            _make_zone_feature(1, "Z1"),
            _make_zone_feature(2, "Z2"),
        )
        net = _network_fc(_make_link_feature("N1", "N2", [6.0, 52.0], [6.1, 52.1]))
        # Simulate PEDESTRIAN: vl_rows is always empty
        fc = self._run(zones, net, [], mode="PEDESTRIAN")
        zone_ids = {f["properties"]["zoneId"] for f in fc["features"]}
        assert "Z1" in zone_ids
        assert "Z2" in zone_ids


# ---------------------------------------------------------------------------
# Fallback feedlinks restricted to boundary entry/exit node sets
# ---------------------------------------------------------------------------


class TestFallbackBoundaryNodeRestriction:
    def _run(
        self,
        zones_fc,
        network_fc,
        vl_rows,
        mode="CAR",
        outgoing_flow=None,
        incoming_flow=None,
        top_n=10,
        entry_node_ids=None,
        exit_node_ids=None,
    ):
        pos, ids = parse_network_geojson(network_fc)
        return build_feedlinks(
            zones_fc,
            pos,
            ids,
            vl_rows,
            mode,
            outgoing_flow=outgoing_flow,
            incoming_flow=incoming_flow,
            top_n=top_n,
            entry_node_ids=entry_node_ids,
            exit_node_ids=exit_node_ids,
        )

    def test_production_only_attaches_to_entry_node_even_if_closer_node_exists(self):
        """A geometrically closer node not in entry_node_ids must be ignored for
        the production feedlink when entry_node_ids is supplied."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(
            # CLOSER is nearer to the zone centroid but not an entry node.
            _make_link_feature("CLOSER", "X1", [6.0005, 52.0], [6.001, 52.0]),
            # ENTRY is farther but is the only valid entry-node candidate.
            _make_link_feature("ENTRY", "X2", [6.01, 52.0], [6.02, 52.0]),
        )
        fc = self._run(zones, net, [], entry_node_ids={"ENTRY"}, exit_node_ids=set())
        prod = next(f for f in fc["features"] if f["properties"]["fromNode"] == "1")
        assert prod["properties"]["toNode"] == "ENTRY"

    def test_attraction_only_attaches_to_exit_node_even_if_closer_node_exists(self):
        """A geometrically closer node not in exit_node_ids must be ignored for
        the attraction feedlink when exit_node_ids is supplied."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(
            _make_link_feature("CLOSER", "X1", [6.0005, 52.0], [6.001, 52.0]),
            _make_link_feature("EXIT", "X2", [6.01, 52.0], [6.02, 52.0]),
        )
        fc = self._run(zones, net, [], entry_node_ids=set(), exit_node_ids={"EXIT"})
        attr = next(f for f in fc["features"] if f["properties"]["toNode"] == "1")
        assert attr["properties"]["fromNode"] == "EXIT"

    def test_production_and_attraction_restricted_to_different_role_sets(self):
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(
            _make_link_feature("ENTRY_NODE", "X1", [6.001, 52.0], [6.002, 52.0]),
            _make_link_feature("EXIT_NODE", "X2", [6.003, 52.0], [6.004, 52.0]),
        )
        fc = self._run(
            zones,
            net,
            [],
            entry_node_ids={"ENTRY_NODE"},
            exit_node_ids={"EXIT_NODE"},
        )
        prod = next(f for f in fc["features"] if f["properties"]["fromNode"] == "1")
        attr = next(f for f in fc["features"] if f["properties"]["toNode"] == "1")
        assert prod["properties"]["toNode"] == "ENTRY_NODE"
        assert attr["properties"]["fromNode"] == "EXIT_NODE"

    def test_none_entry_exit_sets_match_previous_undifferentiated_behaviour(self):
        """Omitting entry_node_ids/exit_node_ids must reproduce the exact output
        of calling build_feedlinks without the new parameters at all."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(
            _make_link_feature("N_NEAR", "X1", [6.001, 52.0], [6.002, 52.0], flow=5.0),
            _make_link_feature("N_FAR", "X2", [6.01, 52.0], [6.02, 52.0], flow=50.0),
        )
        pos, ids = parse_network_geojson(net)
        outgoing, incoming = node_flow_totals(net)

        baseline = build_feedlinks(
            zones, pos, ids, [], "CAR", outgoing_flow=outgoing, incoming_flow=incoming
        )
        with_none = build_feedlinks(
            zones,
            pos,
            ids,
            [],
            "CAR",
            outgoing_flow=outgoing,
            incoming_flow=incoming,
            entry_node_ids=None,
            exit_node_ids=None,
        )
        assert baseline == with_none

    def test_empty_entry_exit_sets_degrade_to_full_node_pool(self):
        """Empty (falsy) sets must behave the same as None — full node pool."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(_make_link_feature("N1", "X1", [6.001, 52.0], [6.002, 52.0]))
        fc_none = self._run(zones, net, [], entry_node_ids=None, exit_node_ids=None)
        fc_empty = self._run(zones, net, [], entry_node_ids=set(), exit_node_ids=set())
        assert fc_none == fc_empty

    def test_entry_set_with_no_overlap_degrades_gracefully(self):
        """When entry_node_ids shares no nodes with the network, the production
        feedlink still gets created (degrading to the full node pool) rather
        than being dropped or crashing."""
        zones = _zones_fc(_make_zone_feature(1, "Z1", production=10.0, attraction=10.0))
        net = _network_fc(_make_link_feature("N1", "X1", [6.001, 52.0], [6.002, 52.0]))
        fc = self._run(zones, net, [], entry_node_ids={"NONEXISTENT"}, exit_node_ids=None)
        prod = next(f for f in fc["features"] if f["properties"]["fromNode"] == "1")
        assert prod["properties"]["toNode"] in {"N1", "X1"}
