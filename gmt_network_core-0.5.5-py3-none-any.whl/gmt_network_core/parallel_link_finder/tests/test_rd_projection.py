"""Unit tests for src/rd_projection.py — pure Python, no I/O."""

from __future__ import annotations

import math
import sys

import pytest

# Make sure 'src/' is on the path when running from repo root.
sys.path.insert(0, "src")

from gmt_shared.rd_projection import wgs84_to_rd

# ---------------------------------------------------------------------------
# Reference values produced by pyproj (EPSG:4326 → EPSG:28992, always_xy=True)
# Run with:
#   from pyproj import Transformer
#   t = Transformer.from_crs("EPSG:4326", "EPSG:28992", always_xy=True)
#   t.transform(lon, lat)
# ---------------------------------------------------------------------------

# (name, lon, lat, expected_x, expected_y)
_REFERENCE_POINTS = [
    ("Amersfoort ref", 5.38720621, 52.15517440, 155000.185, 463000.234),
    ("Amsterdam", 4.9, 52.37, 121819.365, 487013.762),
    ("Rotterdam", 4.47, 51.92, 91902.651, 437233.185),
    ("Den Haag", 4.31, 52.07, 81143.716, 454071.558),
    ("Groningen", 6.57, 53.22, 234002.373, 582136.018),
    ("Maastricht", 5.69, 50.85, 176325.222, 317840.150),
]

_MAX_ERROR_METRES = 1.0


class TestWgs84ToRd:
    @pytest.mark.parametrize(("name", "lon", "lat", "ref_x", "ref_y"), _REFERENCE_POINTS)
    def test_accuracy_under_1m(self, name, lon, lat, ref_x, ref_y):
        """Polynomial result must be within 1 m of the pyproj reference."""
        x, y = wgs84_to_rd(lon, lat)
        err = math.hypot(x - ref_x, y - ref_y)
        assert err < _MAX_ERROR_METRES, (
            f"{name}: error {err:.3f} m exceeds {_MAX_ERROR_METRES} m threshold"
        )

    def test_returns_tuple_of_two_floats(self):
        x, y = wgs84_to_rd(5.0, 52.0)
        assert isinstance(x, float)
        assert isinstance(y, float)

    def test_amersfoort_near_origin(self):
        """The Amersfoort reference point maps to approximately (155000, 463000)."""
        x, y = wgs84_to_rd(5.38720621, 52.15517440)
        assert abs(x - 155000) < 1.0
        assert abs(y - 463000) < 1.0

    def test_x_increases_eastward(self):
        """Moving east increases x (easting)."""
        x1, _ = wgs84_to_rd(5.0, 52.0)
        x2, _ = wgs84_to_rd(6.0, 52.0)
        assert x2 > x1

    def test_y_increases_northward(self):
        """Moving north increases y (northing)."""
        _, y1 = wgs84_to_rd(5.0, 51.0)
        _, y2 = wgs84_to_rd(5.0, 53.0)
        assert y2 > y1
