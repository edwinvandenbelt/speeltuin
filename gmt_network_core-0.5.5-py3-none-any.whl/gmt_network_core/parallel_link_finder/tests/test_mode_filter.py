"""Tests that parallel_link_finder respects mode boundaries.

Each scenario is isolated (no competing links) so results are unambiguous:

* Cross-mode test: only candidate is a different-mode link → must not appear.
* Same-mode test: only candidate is a same-mode link → must appear.
* No-mode backward-compat test: links with no mode → must match each other.

Note on algorithm mechanics
---------------------------
``map1to2`` sets ``mapped[i] = 1`` after the first accepted match for each
centroid, so a closer cross-mode link can "steal" the slot before a same-mode
link is reached.  The mode filter in the core is therefore a safety net for
direct/standalone calls.  In the prepare pipeline ``find_parallel_links`` is
called once per mode (the network is pre-split), which fully prevents
cross-mode competition.
"""

from __future__ import annotations

from gmt_network_core.parallel_link_finder.core.parallel_link_finder_core import find_parallel_links

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _feature(link_id: int, coords: list, mode: str | None = None) -> dict:
    props: dict = {"linkId": link_id}
    if mode is not None:
        props["mode"] = mode
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": props,
    }


def _fc(*features: dict) -> dict:
    return {"type": "FeatureCollection", "features": list(features), "properties": {}}


def _props_by_id(fc: dict) -> dict[int, dict]:
    return {f["properties"]["linkId"]: f["properties"] for f in fc["features"]}


# ---------------------------------------------------------------------------
# Geometry notes
# ---------------------------------------------------------------------------
# At latitude 52 °N:  1 ° lat  ≈ 111 km  →  0.00009 ° ≈ 10 m
#                     1 ° lon  ≈  68 km
# Links span 0.001 ° in longitude ≈ 68 m — long enough for reliable sub-linking.
# Lateral offset 0.00009 ° ≈ 10 m — within maxdist=20 m and perpendicular to
# the east-going direction, so dist_parallel ≈ 0 < maxlength_sublink/2 = 2.5 m.

_LON0, _LON1 = 5.0, 5.001
_LAT0 = 52.0
_LAT_OFFSET = 0.00009  # ≈ 10 m north


# ---------------------------------------------------------------------------
# 1. Cross-mode: only a BIKE candidate is present next to a CAR link
#    The mode filter must prevent the BIKE link from appearing.
# ---------------------------------------------------------------------------


class TestCrossModeSafety:
    """The mode filter rejects cross-mode candidates when they are the only match."""

    def test_cross_mode_parallel_not_tagged(self):
        """CAR link's only parallel candidate is BIKE → must not appear."""
        fc = _fc(
            _feature(1001, [[_LON0, _LAT0], [_LON1, _LAT0]], mode="CAR"),
            _feature(
                1002, [[_LON0, _LAT0 + _LAT_OFFSET], [_LON1, _LAT0 + _LAT_OFFSET]], mode="BIKE"
            ),
        )
        enriched, _ = find_parallel_links(fc)
        props = _props_by_id(enriched)
        assert 1002 not in props[1001]["parallelLinkIds"], (
            "CAR link 1001 must not list BIKE link 1002 as a parallel"
        )
        assert 1001 not in props[1002]["parallelLinkIds"], (
            "BIKE link 1002 must not list CAR link 1001 as a parallel"
        )

    def test_cross_mode_reverse_not_tagged(self):
        """CAR link's only reverse candidate is BIKE → must not appear."""
        fc = _fc(
            _feature(2001, [[_LON0, _LAT0], [_LON1, _LAT0]], mode="CAR"),
            _feature(
                2002, [[_LON1, _LAT0 + _LAT_OFFSET], [_LON0, _LAT0 + _LAT_OFFSET]], mode="BIKE"
            ),
        )
        enriched, _ = find_parallel_links(fc)
        props = _props_by_id(enriched)
        assert 2002 not in props[2001]["reverseLinkIds"], (
            "CAR link 2001 must not list BIKE link 2002 as a reverse"
        )
        assert 2001 not in props[2002]["reverseLinkIds"], (
            "BIKE link 2002 must not list CAR link 2001 as a reverse"
        )


# ---------------------------------------------------------------------------
# 2. Same-mode: only a same-mode candidate is present — must be detected
# ---------------------------------------------------------------------------


class TestSameModeDetection:
    """Same-mode links that are geometrically close must still be detected."""

    def test_same_mode_reverse_detected(self):
        """Two CAR links in opposite directions must recognise each other."""
        fc = _fc(
            _feature(3001, [[_LON0, _LAT0], [_LON1, _LAT0]], mode="CAR"),
            _feature(
                3002, [[_LON1, _LAT0 + _LAT_OFFSET], [_LON0, _LAT0 + _LAT_OFFSET]], mode="CAR"
            ),
        )
        enriched, _ = find_parallel_links(fc)
        props = _props_by_id(enriched)
        assert 3002 in props[3001]["reverseLinkIds"], (
            "CAR link 3001 should list CAR link 3002 as a reverse"
        )
        assert 3001 in props[3002]["reverseLinkIds"], (
            "CAR link 3002 should list CAR link 3001 as a reverse"
        )


# ---------------------------------------------------------------------------
# 3. No-mode backward compatibility: links without a mode property must still
#    match each other (None == None).
# ---------------------------------------------------------------------------


class TestNoModeBackwardCompat:
    def test_no_mode_reverse_detected(self):
        """Links with no mode property must still detect reverse links."""
        fc = _fc(
            _feature(4001, [[_LON0, _LAT0], [_LON1, _LAT0]]),  # no mode
            _feature(4002, [[_LON1, _LAT0], [_LON0, _LAT0]]),  # no mode — reverse
        )
        enriched, _ = find_parallel_links(fc)
        props = _props_by_id(enriched)
        assert 4002 in props[4001]["reverseLinkIds"], (
            "links without a mode property should still detect reverse links"
        )
        assert 4001 in props[4002]["reverseLinkIds"], (
            "links without a mode property should still detect reverse links (symmetric)"
        )
