"""Network GeoJSON reader for parallel_link_finder."""

from __future__ import annotations

try:
    import numpy as np
except ImportError as _np_err:
    raise ImportError(
        "numpy is required for parallel_link_finder. "
        "Install it with: pip install gmt-calculation-lib[prepare]"
    ) from _np_err

from gmt_shared.rd_projection import wgs84_to_rd


def get_links_spectrum(
    geojson_network: dict,
) -> tuple[list, list, list, list]:
    """Extract link attributes from a GeoJSON FeatureCollection.

    Returns
    -------
    links : list
        ``linkId`` values.
    lengths : list
        Link lengths in metres.
    xys : list
        RD-projected coordinate lists, one per link.
    modes : list
        ``mode`` property value per link (``None`` when absent).
    """
    links, lengths, xys, modes = [], [], [], []

    for feature in geojson_network["features"]:
        props = feature["properties"]
        geom = feature["geometry"]

        if geom is None:
            continue

        link_id = props["linkId"]

        coords = [list(wgs84_to_rd(c[0], c[1])) for c in geom["coordinates"]]

        if "length" in props and props["length"] is not None:
            length = float(props["length"])
        else:
            coords_arr = np.array(coords)
            diffs = np.diff(coords_arr, axis=0)
            length = float(np.sum(np.sqrt(diffs[:, 0] ** 2 + diffs[:, 1] ** 2)))

        links.append(link_id)
        lengths.append(length)
        xys.append(coords)
        modes.append(props.get("mode"))

    return links, lengths, xys, modes
