"""Local debug runner for network_zone_joiner.

Reads a zones GeoJSON file and a network GeoJSON file, clips the network to
the requested zone(s), and writes a single NETWORK, ZONE, and FEEDLINK output
file.  By default the input network and feedlinks files are overwritten in place,
consistent with other modules in this pipeline.

Usage
-----
    # Overwrite inputs in place (default):
    python -m network_zone_joiner.network_zone_joiner_runner \\
        --zones-file  path/to/{areaId}-ZONES.parquet \\
        --network-file path/to/{areaId}-NETWORK-CAR.parquet \\
        --feedlinks-file path/to/{areaId}-FEEDLINK-CAR.parquet \\
        --zone-output path/to/{areaId}-ZONE-CAR.parquet

    # Explicit output files:
    python -m network_zone_joiner.network_zone_joiner_runner \\
        --zones-file zones.parquet --network-file network.parquet \\
        --feedlinks-file feedlinks.parquet \\
        --network-output out/network-joined.parquet \\
        --zone-output out/zones-joined.parquet \\
        --feedlinks-output out/feedlinks-joined.parquet
"""

from __future__ import annotations

import argparse
import logging
import os
import sys
from pathlib import Path

# ---------------------------------------------------------------------------
# sys.path bootstrap
# ---------------------------------------------------------------------------


def _auto_src() -> None:
    _here = Path(__file__).resolve()
    for parent in _here.parents:
        candidate = parent / "src"
        if candidate.is_dir():
            if str(candidate) not in sys.path:
                sys.path.insert(0, str(candidate))
            break


_auto_src()


# ---------------------------------------------------------------------------
# .env reader
# ---------------------------------------------------------------------------


def _read_env_file(path: Path) -> dict[str, str]:
    result: dict[str, str] = {}
    if not path.exists():
        return result
    for raw_line in path.read_text(encoding="utf-8").splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, raw_val = line.partition("=")
        key = key.strip()
        val = raw_val.strip()
        if len(val) >= 2 and val[0] == val[-1] and val[0] in ('"', "'"):
            val = val[1:-1]
        if key:
            result[key] = val
    return result


# ---------------------------------------------------------------------------
# URI I/O helpers
# ---------------------------------------------------------------------------


def _read_uri(uri: str) -> bytes:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import get_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        data: bytes = get_bytes_s3(bucket, key)
        return data
    path = uri.removeprefix("file://")
    with open(path, "rb") as fh:
        return fh.read()


def _write_uri(uri: str, data: bytes) -> None:
    if uri.startswith("s3://"):
        from gmt_shared.s3 import put_bytes_s3, s3_split

        bucket, key = s3_split(uri)
        put_bytes_s3(bucket, key, data)
        return
    path = uri.removeprefix("file://")
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "wb") as fh:
        fh.write(data)
    print(f"Written {len(data):,} bytes -> {path}")


# ---------------------------------------------------------------------------
# Deduplication helpers
# ---------------------------------------------------------------------------


def _dedup_zone_features(features: list[dict]) -> list[dict]:
    """Return *features* with duplicates removed by ``zoneId`` (first occurrence wins).

    When both an AREA zone and individual STUDY/INFLUENCE zones are processed,
    every non-AREA zone appears in *all_zone_features* twice: once inside the AREA
    zone's ``zone_fc`` and once from its own result tuple.  This function keeps
    the first occurrence of each ``zoneId``.
    """
    seen: dict[str, dict] = {}
    for feat in features:
        zid = (feat.get("properties") or {}).get("zoneId") or ""
        if zid not in seen:
            seen[zid] = feat
    return list(seen.values())


def _dedup_net_features(features: list[dict]) -> list[dict]:
    """Return *features* with duplicates removed by ``(linkId, fromNode, toNode)``.

    Links that fall inside an individual zone's polygon are also present in the
    AREA zone's clipped network.  This function keeps the first occurrence of
    each ``(linkId, fromNode, toNode)`` triple, which is the AREA zone's version
    (the most complete clip).
    """
    seen: set[tuple] = set()
    result: list[dict] = []
    for feat in features:
        props = feat.get("properties") or {}
        key = (
            str(props.get("linkId") or props.get("spectrumId") or ""),
            str(props.get("fromNode") or ""),
            str(props.get("toNode") or ""),
        )
        if key not in seen:
            seen.add(key)
            result.append(feat)
    return result


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

    parser = argparse.ArgumentParser(
        description=(
            "Clip a network to zone polygon(s) and write merged NETWORK, ZONE, "
            "and FEEDLINK output files.  By default the input network and feedlinks "
            "files are overwritten in place."
        )
    )
    parser.add_argument(
        "--zones-file",
        required=True,
        metavar="URI",
        help="URI of the input zones GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--network-file",
        required=True,
        metavar="URI",
        help="URI of the input network GeoJSON file (s3:// or local path).",
    )
    parser.add_argument(
        "--feedlinks-file",
        default=None,
        metavar="URI",
        help=(
            "Optional URI of a feedlinks GeoJSON file (from gmt_network_core.feedlink_fetcher). "
            "When provided, filtered existing feedlinks and synthetic boundary-node "
            "feedlinks are written to the feedlinks output."
        ),
    )
    parser.add_argument(
        "--network-output",
        default=None,
        metavar="URI",
        help=("URI to write the clipped network GeoJSON. Defaults to overwriting --network-file."),
    )
    parser.add_argument(
        "--zone-output",
        required=True,
        metavar="URI",
        help="URI to write the zone GeoJSON output (s3:// or local path).",
    )
    parser.add_argument(
        "--feedlinks-output",
        default=None,
        metavar="URI",
        help=(
            "URI to write the extended feedlinks GeoJSON. "
            "Defaults to overwriting --feedlinks-file when that argument is provided."
        ),
    )
    parser.add_argument(
        "--area-id",
        default=None,
        metavar="ID",
        help="Override the area ID read from the zones file properties.",
    )
    parser.add_argument(
        "--mode",
        default=None,
        metavar="MODE",
        help="Override the transport mode read from the network file properties.",
    )
    parser.add_argument(
        "--zone-classes",
        nargs="+",
        default=None,
        metavar="CLASS",
        help=(
            "Only process zones whose zoneClass matches one of these values "
            "(e.g. AREA STUDY INFLUENCE).  Processes all classes when omitted."
        ),
    )
    parser.add_argument(
        "--no-adjust-boundary-demands",
        action="store_true",
        default=False,
        help=(
            "Disable the proportional reduction of internal zone production/"
            "attraction by boundary-crossing flow.  Use this when zone demands "
            "come from an external demand model (e.g. OmniTRANS) and are "
            "independent of the link flows used to size boundary mini-zones."
        ),
    )
    parser.add_argument(
        "--major-boundary-speed-kph",
        type=float,
        default=50.0,
        metavar="KPH",
        help=(
            "Every AREA-ring crossing on a link faster than this speed (km/h) "
            "produces a boundary mini-zone.  Crossings at exactly this speed "
            "are only used to top up to --min-boundary-zones; slower links (or "
            "links with no speed value) are dropped entirely. Default 50.0."
        ),
    )
    parser.add_argument(
        "--min-boundary-zones",
        type=int,
        default=10,
        metavar="N",
        help=(
            "Minimum number of boundary mini-zones.  When the major roads yield "
            "fewer, crossings at exactly --major-boundary-speed-kph are added, "
            "highest flow first. Default 10."
        ),
    )
    parser.add_argument(
        "--two-way-merge-dist-m",
        type=float,
        default=30.0,
        metavar="M",
        help=(
            "Combine an entry and an exit crossing within this distance (m) into "
            "one boundary mini-zone (both directions of a two-way road). "
            "0 disables combining. Default 30.0."
        ),
    )
    parser.add_argument("--env-file", default=None, help="Path to .env file for credentials.")
    args = parser.parse_args()

    # Load .env
    env_file = (
        Path(args.env_file)
        if args.env_file
        else next(
            (
                p / "tools" / ".env"
                for p in Path(__file__).resolve().parents
                if (p / "tools" / ".env").exists()
            ),
            None,
        )
    )
    if env_file:
        for k, v in _read_env_file(env_file).items():
            os.environ.setdefault(k, v)

    from gmt_shared.geoparquet import from_geoparquet, to_geoparquet

    from gmt_network_core.network_zone_joiner.core.network_zone_joiner_core import (
        join_zones_to_network,
    )

    # Read inputs
    print(f"Reading zones    : {args.zones_file}")
    zones_fc: dict = from_geoparquet(_read_uri(args.zones_file))

    print(f"Reading network  : {args.network_file}")
    network_fc: dict = from_geoparquet(_read_uri(args.network_file))

    feedlinks_fc: dict | None = None
    if args.feedlinks_file:
        print(f"Reading feedlinks: {args.feedlinks_file}")
        feedlinks_fc = from_geoparquet(_read_uri(args.feedlinks_file))

    # Resolve area_id and mode
    zones_props = zones_fc.get("properties") or {}
    network_props = network_fc.get("properties") or {}

    area_id = args.area_id or zones_props.get("areaId") or network_props.get("area_id") or "unknown"
    modes = network_props.get("modes") or []
    mode = args.mode or (modes[0] if modes else None) or "UNKNOWN"

    print(f"Area ID          : {area_id}")
    print(f"Mode             : {mode}")
    print(f"Zone features    : {len(zones_fc.get('features') or [])}")
    print(f"Network links    : {len(network_fc.get('features') or [])}")

    # Resolve output URIs
    net_out_uri = args.network_output or args.network_file
    zone_out_uri = args.zone_output
    feedlink_out_uri = args.feedlinks_output or args.feedlinks_file

    # Run the join
    zone_classes_filter = set(args.zone_classes) if args.zone_classes else None
    results = join_zones_to_network(
        zones_fc,
        network_fc,
        zone_classes=zone_classes_filter,
        feedlinks_fc=feedlinks_fc,
        adjust_boundary_demands=not args.no_adjust_boundary_demands,
        major_boundary_speed_kph=args.major_boundary_speed_kph,
        min_boundary_zones=args.min_boundary_zones,
        two_way_merge_dist_m=args.two_way_merge_dist_m,
    )

    print(f"\nProcessed {len(results)} zones:")
    for zone_feat, clipped_net_fc, zone_fc, ext_feedlinks_fc in results:
        zone_props = zone_feat.get("properties") or {}
        zone_id = zone_props.get("zoneId") or ""
        zone_class = zone_props.get("zoneClass") or ""
        n_links = len(clipped_net_fc.get("features") or [])
        n_feedlinks = len(ext_feedlinks_fc.get("features") or [])
        print(f"  {zone_class:10s} {zone_id!r:40s} -> {n_links} links, {n_feedlinks} feedlinks")

    # Merge all results into single output FeatureCollections.
    # For the common single-AREA-zone case this is a no-op merge.
    all_net_features: list[dict] = []
    all_zone_features: list[dict] = []
    all_feedlink_features: list[dict] = []

    for _zone_feat, clipped_net_fc, zone_fc, ext_feedlinks_fc in results:
        all_net_features.extend(clipped_net_fc.get("features") or [])
        all_zone_features.extend(zone_fc.get("features") or [])
        all_feedlink_features.extend(ext_feedlinks_fc.get("features") or [])

    # ------------------------------------------------------------------
    # Deduplication — see _dedup_zone_features / _dedup_net_features.
    # ------------------------------------------------------------------
    deduped_zones = _dedup_zone_features(all_zone_features)
    if len(deduped_zones) < len(all_zone_features):
        print(
            f"Deduplication: removed {len(all_zone_features) - len(deduped_zones)} "
            f"duplicate zone feature(s), {len(deduped_zones)} unique zone(s) remain."
        )
    all_zone_features = deduped_zones

    deduped_net = _dedup_net_features(all_net_features)
    if len(deduped_net) < len(all_net_features):
        print(
            f"Deduplication: removed {len(all_net_features) - len(deduped_net)} "
            f"duplicate network link(s), {len(deduped_net)} unique link(s) remain."
        )
    all_net_features = deduped_net

    merged_net_fc: dict = {**network_fc, "features": all_net_features}
    merged_zone_fc: dict = {
        "type": "FeatureCollection",
        "features": all_zone_features,
        "properties": {
            **(zones_fc.get("properties") or {}),
            "modes": (network_fc.get("properties") or {}).get("modes") or [],
        },
    }
    feedlinks_base_props = (feedlinks_fc.get("properties") or {}) if feedlinks_fc else {}
    merged_feedlinks_fc: dict = {
        "type": "FeatureCollection",
        "features": all_feedlink_features,
        "properties": {**feedlinks_base_props},
    }

    _write_uri(net_out_uri, to_geoparquet(merged_net_fc))
    _write_uri(zone_out_uri, to_geoparquet(merged_zone_fc))
    if feedlink_out_uri:
        _write_uri(feedlink_out_uri, to_geoparquet(merged_feedlinks_fc))

    print("\nDone.")


if __name__ == "__main__":
    main()
