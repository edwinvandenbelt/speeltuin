"""Zone-to-network join logic for network_zone_joiner — no I/O, no boto3.

For each zone polygon in the zones FeatureCollection, clips the network
LineString features to the zone boundary.  Links that cross the boundary are
clipped; the new boundary node receives the link's ``linkId`` as its node ID.

Public API
----------
join_zones_to_network(zones_fc, network_fc, zone_classes, feedlinks_fc)
    Returns a list of (zone_feature, clipped_network_fc, zone_fc, feedlinks_fc) tuples.
    When processing an AREA zone the zone_fc includes the AREA zone feature plus
    one small circular boundary zone for each clipped boundary node.

extend_feedlinks_for_zone(feedlinks_fc, clipped_network_fc, zone_feature, mode)
    Filters existing feedlinks to those relevant to the clipped network and adds
    synthetic feedlinks for boundary nodes (capacity = link flow).

build_zone_output_path(output_folder, area_id, zone_id, artifact_type, mode)
    Returns a filename like ``{area_id}[{zone_id}]-{artifact_type}-{mode}.parquet``.
"""

from __future__ import annotations

import copy
import logging
import math

from gmt_shared.geo_utils import _flat_earth_dist_m, _straight_line

from gmt_network_core.network_zone_joiner.domain.geometry import (
    _buffer_ring,
    clip_linestring_to_polygon_angled,
    point_in_polygon,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Output path helper
# ---------------------------------------------------------------------------


def build_zone_output_path(
    output_folder: str,
    area_id: str,
    zone_id: str,
    artifact_type: str,
    mode: str | None = None,
) -> str:
    """Build an output URI for a per-zone artifact.

    Pattern: ``{output_folder}/{area_id}[{zone_id}]-{artifact_type}[-{mode}].parquet``

    Parameters
    ----------
    output_folder:
        Base folder URI (s3://bucket/prefix/ or local directory).
    area_id:
        Area identifier (from the zones FeatureCollection).
    zone_id:
        Zone identifier (from the zone feature's ``zoneId`` property).
    artifact_type:
        ``"NETWORK"`` or ``"ZONE"``.
    mode:
        Transport mode string (e.g. ``"CAR"``). Omitted from filename when None.

    Returns
    -------
    str
        Full output URI.
    """
    filename = f"{area_id}[{zone_id}]-{artifact_type}"
    if mode:
        filename += f"-{mode}"
    filename += ".geojson"
    return f"{output_folder.rstrip('/')}/{filename}"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _coords_close(a: list[float], b: list[float], tol: float = 1e-9) -> bool:
    """Return True if two coordinate pairs are within *tol* of each other."""
    return abs(a[0] - b[0]) < tol and abs(a[1] - b[1]) < tol


def _clip_link_to_zone(
    feature: dict,
    ring: list,
    min_angle_deg: float = 2.0,
) -> tuple[list[dict], set[str]]:
    """Clip a single network link feature to a zone polygon ring.

    Parameters
    ----------
    feature:
        GeoJSON Feature with a LineString geometry and network link properties.
    ring:
        Exterior ring of the zone polygon (list of ``[lon, lat]`` pairs).
    min_angle_deg:
        Minimum acute crossing angle (degrees) required to clip the link.
        Crossings where the angle between the link and the boundary edge is
        ≤ this value are ignored (near-parallel links are not clipped).

    Returns
    -------
    tuple[list[dict], set[str]]
        * A list of zero or more clipped GeoJSON Features.  Each clipped
          feature that touches the zone boundary has its boundary node ID set
          to the original link's ``linkId`` (plus an optional suffix).
        * A set of node ID strings that were **assigned by this function** as
          boundary nodes.  Only these IDs should be treated as true boundary
          crossing points; the caller must not rely solely on
          ``fromNode == linkId`` in the properties, as the original data may
          already carry that coincidence for interior nodes.
    """
    geom = feature.get("geometry") or {}
    if geom.get("type") != "LineString":
        return [], set()

    coords = geom.get("coordinates") or []
    if len(coords) < 2:
        return [], set()

    props = feature.get("properties") or {}
    link_id = props.get("linkId") or props.get("spectrumId") or ""
    original_from = [coords[0][0], coords[0][1]]
    original_to = [coords[-1][0], coords[-1][1]]

    clipped_segments = clip_linestring_to_polygon_angled(coords, ring, min_angle_deg=min_angle_deg)
    if not clipped_segments:
        return [], set()

    result: list[dict] = []
    boundary_node_ids: set[str] = set()

    for seg_i, seg_coords in enumerate(clipped_segments):
        new_props = copy.deepcopy(props)

        seg_start = seg_coords[0]
        seg_end = seg_coords[-1]

        # If the segment start is a boundary point (not the original fromNode
        # coordinate), assign the link ID as the new fromNode.
        if not _coords_close(seg_start, original_from):
            suffix = "" if len(clipped_segments) == 1 else f"_{seg_i}_in"
            node_id = f"{link_id}{suffix}"
            new_props["fromNode"] = node_id
            boundary_node_ids.add(node_id)

        # If the segment end is a boundary point (not the original toNode
        # coordinate), assign the link ID as the new toNode.
        if not _coords_close(seg_end, original_to):
            suffix = "" if len(clipped_segments) == 1 else f"_{seg_i}_out"
            node_id = f"{link_id}{suffix}"
            new_props["toNode"] = node_id
            boundary_node_ids.add(node_id)

        result.append(
            {
                "type": "Feature",
                "geometry": {"type": "LineString", "coordinates": seg_coords},
                "properties": new_props,
            }
        )

    return result, boundary_node_ids


# ---------------------------------------------------------------------------
# Node proportion helpers
# ---------------------------------------------------------------------------


def _build_node_coords(features: list[dict]) -> dict[str, list[float]]:
    """Build ``{nodeId: [lon, lat]}`` from LineString link features.

    Uses the first coordinate as ``fromNode`` position and the last as
    ``toNode`` position, matching the convention in network GeoJSON.
    """
    coords: dict[str, list[float]] = {}
    for feat in features:
        props = feat.get("properties") or {}
        geom = feat.get("geometry") or {}
        from_n = str(props.get("fromNode") or "")
        to_n = str(props.get("toNode") or "")
        pts = geom.get("coordinates") or []
        if pts:
            if from_n and from_n not in coords:
                coords[from_n] = [float(pts[0][0]), float(pts[0][1])]
            if to_n and to_n not in coords:
                coords[to_n] = [float(pts[-1][0]), float(pts[-1][1])]
    return coords


def _build_node_total_length(features: list[dict]) -> dict[str, float]:
    """Build ``{nodeId: total_connected_length_m}`` from link features.

    Each link contributes its ``length`` property to both its ``fromNode`` and
    its ``toNode``.
    """
    totals: dict[str, float] = {}
    for feat in features:
        props = feat.get("properties") or {}
        length = float(props.get("length") or 0.0)
        from_n = str(props.get("fromNode") or "")
        to_n = str(props.get("toNode") or "")
        if from_n:
            totals[from_n] = totals.get(from_n, 0.0) + length
        if to_n:
            totals[to_n] = totals.get(to_n, 0.0) + length
    return totals


def _build_node_from_length(features: list[dict]) -> dict[str, float]:
    """Build ``{nodeId: outgoing_link_length_m}`` from link features.

    Each link contributes its ``length`` only to its ``fromNode`` (the origin
    end of the directed link).  Used to weight nodes by production capacity.
    """
    totals: dict[str, float] = {}
    for feat in features:
        props = feat.get("properties") or {}
        length = float(props.get("length") or 0.0)
        from_n = str(props.get("fromNode") or "")
        if from_n:
            totals[from_n] = totals.get(from_n, 0.0) + length
    return totals


def _build_node_to_length(features: list[dict]) -> dict[str, float]:
    """Build ``{nodeId: incoming_link_length_m}`` from link features.

    Each link contributes its ``length`` only to its ``toNode`` (the destination
    end of the directed link).  Used to weight nodes by attraction capacity.
    """
    totals: dict[str, float] = {}
    for feat in features:
        props = feat.get("properties") or {}
        length = float(props.get("length") or 0.0)
        to_n = str(props.get("toNode") or "")
        if to_n:
            totals[to_n] = totals.get(to_n, 0.0) + length
    return totals


def _compute_node_proportions(
    zone_feat: dict,
    node_total_length: dict[str, float],
    node_coords: dict[str, list[float]],
) -> dict[str, float]:
    """Return ``{nodeId: proportion}`` for all nodes within *zone_feat*.

    Proportion is each node's share of the total connected link length of all
    nodes in the zone, so the values sum to 1.0.

    For ``BOUNDARY`` mini-zones the nodes are identified by the ``nodeIds``
    property (falling back to ``zoneId``) — no point-in-polygon test needed.
    A single-node mini-zone gets proportion ``1.0`` for that node; a combined
    two-way mini-zone splits by connected length, which in practice puts the
    entry node in the ``from`` proportions and the exit node in the ``to``
    proportions.

    For zones with no connected links or no nodes inside the polygon, an empty
    dict is returned.
    """
    props = zone_feat.get("properties") or {}
    zone_class = props.get("zoneClass") or ""

    # BOUNDARY mini-zones: the node(s) are identified explicitly.
    if zone_class == "BOUNDARY":
        node_ids = [str(n) for n in props.get("nodeIds") or [props.get("zoneId") or ""]]
        node_lengths: dict[str, float] = {
            nid: node_total_length[nid] for nid in node_ids if nid in node_total_length
        }
        if not node_lengths:
            return {}
        if len(node_lengths) == 1:
            return {next(iter(node_lengths)): 1.0}
        total = sum(node_lengths.values())
        if total <= 0.0:
            return {nid: round(1.0 / len(node_lengths), 9) for nid in node_lengths}
        return {nid: round(length / total, 9) for nid, length in node_lengths.items()}

    geom = zone_feat.get("geometry") or {}
    geom_type = geom.get("type") or ""
    raw_coords = geom.get("coordinates") or []

    if geom_type == "Polygon":
        rings = [raw_coords[0]] if raw_coords and raw_coords[0] else []
    elif geom_type == "MultiPolygon":
        rings = [poly[0] for poly in raw_coords if poly and poly[0]]
    else:
        return {}

    # Collect nodes whose coordinates fall inside any ring of this zone.
    node_lengths = {}
    for node_id, coord in node_coords.items():
        if node_id not in node_total_length:
            continue
        for ring in rings:
            if point_in_polygon(coord[0], coord[1], ring):
                node_lengths[node_id] = node_total_length[node_id]
                break

    if not node_lengths:
        return {}

    total = sum(node_lengths.values())
    if total <= 0.0:
        # Equal weight when all connected lengths are zero.
        n = len(node_lengths)
        return {nid: round(1.0 / n, 9) for nid in node_lengths}

    return {nid: round(length / total, 9) for nid, length in node_lengths.items()}


def _adjust_internal_zone_demands(
    zone_fc_features: list[dict],
    boundary_zone_features: list[dict],
) -> list[dict]:
    """Reduce internal-zone attractions/productions by boundary-crossing flows.

    When an AREA zone has boundary mini-zones, those mini-zones carry flows that
    enter or leave the area across the boundary.  These flows are already
    accounted for at the boundary nodes, so the internal zones' demand totals
    must be reduced to avoid double-counting.

    For every non-``BOUNDARY`` zone:

    * ``originalAttraction`` is set to the zone's current ``attraction`` value.
    * ``originalProduction`` is set to the zone's current ``production`` value.
    * ``attraction`` is reduced by its proportional share of the **total
      boundary attraction** (sum of ``attraction`` over all boundary mini-zones),
      where the share is ``originalAttraction / sum(originalAttraction)`` over
      all internal zones.
    * ``production`` is reduced by its proportional share of the **total
      boundary production** (sum of ``production`` over all boundary mini-zones),
      where the share is ``originalProduction / sum(originalProduction)`` over
      all internal zones.

    When there are no boundary mini-zones, or the total boundary flow is zero,
    the zone features are returned unchanged (no ``original*`` attributes added).

    Parameters
    ----------
    zone_fc_features:
        Zone features, possibly including boundary mini-zones.
    boundary_zone_features:
        Only the boundary mini-zone features (``zoneClass == "BOUNDARY"``).
        These must also be present in *zone_fc_features*.

    Returns
    -------
    list[dict]
        Updated zone feature list.  Non-BOUNDARY zone features gain
        ``originalAttraction`` and ``originalProduction`` properties, and their
        ``attraction``/``production`` values are reduced accordingly.
        BOUNDARY mini-zone features are returned unmodified.
    """
    if not boundary_zone_features:
        return zone_fc_features

    total_boundary_attraction = sum(
        float((f.get("properties") or {}).get("attraction") or 0.0) for f in boundary_zone_features
    )
    total_boundary_production = sum(
        float((f.get("properties") or {}).get("production") or 0.0) for f in boundary_zone_features
    )

    if total_boundary_attraction == 0.0 and total_boundary_production == 0.0:
        return zone_fc_features

    internal_feats = [
        f for f in zone_fc_features if (f.get("properties") or {}).get("zoneClass") != "BOUNDARY"
    ]

    sum_orig_attractions = sum(
        float((f.get("properties") or {}).get("attraction") or 0.0) for f in internal_feats
    )
    sum_orig_productions = sum(
        float((f.get("properties") or {}).get("production") or 0.0) for f in internal_feats
    )
    sum_orig_productions = sum(
        float((f.get("properties") or {}).get("production") or 0.0) for f in internal_feats
    )

    print(
        f"  [adjust_demands] boundary_attr={total_boundary_attraction:.1f}"
        f"  boundary_prod={total_boundary_production:.1f}"
        f"  internal_attr={sum_orig_attractions:.1f}"
        f"  internal_prod={sum_orig_productions:.1f}"
        f"  ratio_attr={total_boundary_attraction / sum_orig_attractions:.2f}"
        if sum_orig_attractions > 0
        else f"  ratio_prod={total_boundary_production / sum_orig_productions:.2f}"
        if sum_orig_productions > 0
        else ""
    )

    result: list[dict] = []
    for feat in zone_fc_features:
        props = feat.get("properties") or {}
        if props.get("zoneClass") == "BOUNDARY":
            result.append(feat)
            continue

        orig_attr = float(props.get("attraction") or 0.0)
        orig_prod = float(props.get("production") or 0.0)

        attr_share = orig_attr / sum_orig_attractions if sum_orig_attractions > 0.0 else 0.0
        prod_share = orig_prod / sum_orig_productions if sum_orig_productions > 0.0 else 0.0
        attr_reduction = attr_share * total_boundary_attraction
        prod_reduction = prod_share * total_boundary_production

        new_props = {
            **props,
            "originalAttraction": orig_attr,
            "originalProduction": orig_prod,
            "attraction": round(max(0.0, orig_attr - attr_reduction), 6),
            "production": round(max(0.0, orig_prod - prod_reduction), 6),
        }
        result.append({**feat, "properties": new_props})

    return result


def _annotate_zone_proportions(
    zone_fc_features: list[dict],
    clipped_features: list[dict],
) -> list[dict]:
    """Return a new list of zone features with ``fromNodeProportions`` and
    ``toNodeProportions`` added to each.

    ``fromNodeProportions`` is a ``{nodeId: float}`` mapping weighted by each
    node's share of **outgoing** link length within the zone (production weight).
    ``toNodeProportions`` is weighted by **incoming** link length (attraction
    weight).  Values in each dict sum to 1.0 per zone.  Zones with no nodes
    inside them receive empty dicts for both keys.
    """
    node_coords = _build_node_coords(clipped_features)
    node_from_length = _build_node_from_length(clipped_features)
    node_to_length = _build_node_to_length(clipped_features)

    result: list[dict] = []
    for feat in zone_fc_features:
        from_proportions = _compute_node_proportions(feat, node_from_length, node_coords)
        to_proportions = _compute_node_proportions(feat, node_to_length, node_coords)
        new_props = {
            **(feat.get("properties") or {}),
            "fromNodeProportions": from_proportions,
            "toNodeProportions": to_proportions,
        }
        result.append({**feat, "properties": new_props})
    return result


def _build_node_zone_map(
    zone_fc_features: list[dict],
    prop_key: str,
) -> dict[str, dict[str, float]]:
    """Build ``{nodeId: {zoneId: proportion}}`` from annotated zone features.

    Inverts the proportions dict identified by *prop_key* on each zone feature
    so that callers can look up, for a given node, which zones it belongs to and
    with what proportion within each zone.

    Parameters
    ----------
    zone_fc_features:
        Zone features that already carry ``fromNodeProportions`` and/or
        ``toNodeProportions`` properties (as produced by
        ``_annotate_zone_proportions``).
    prop_key:
        The property key to invert — either ``"fromNodeProportions"`` or
        ``"toNodeProportions"``.

    Returns
    -------
    dict mapping nodeId (str) → {zoneId (str): proportion (float)}.
    """
    result: dict[str, dict[str, float]] = {}
    for feat in zone_fc_features:
        props = feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        node_proportions: dict = props.get(prop_key) or {}
        for node_id, proportion in node_proportions.items():
            result.setdefault(str(node_id), {})[zone_id] = proportion
    return result


# ---------------------------------------------------------------------------
# Boundary zone helpers
# ---------------------------------------------------------------------------

# Approximate metres per degree for WGS-84 at typical Dutch latitudes (~52 °N).
_M_PER_DEG_LAT = 111_320.0
_M_PER_DEG_LON_AT_52N = 111_320.0 * math.cos(math.radians(52.0))


def _make_circle_ring(
    lon: float,
    lat: float,
    radius_m: float = 15.0,
    n_points: int = 16,
) -> list[list[float]]:
    """Return a closed GeoJSON-style ring approximating a circle.

    Parameters
    ----------
    lon, lat:
        Centre of the circle in WGS-84 decimal degrees.
    radius_m:
        Radius in metres (default 15 m → 30 m diameter).
    n_points:
        Number of vertices in the approximation (polygon will have
        *n_points* + 1 coordinates, closed).

    Returns
    -------
    list of [lon, lat] pairs, closed (first == last).
    """
    d_lat = radius_m / _M_PER_DEG_LAT
    d_lon = radius_m / max(_M_PER_DEG_LON_AT_52N, 1.0)
    ring: list[list[float]] = []
    for i in range(n_points):
        angle = 2.0 * math.pi * i / n_points
        ring.append(
            [
                round(lon + d_lon * math.cos(angle), 9),
                round(lat + d_lat * math.sin(angle), 9),
            ]
        )
    ring.append(ring[0])  # close
    return ring


def _make_boundary_zone(
    zone_id: str,
    lon: float,
    lat: float,
    radius_m: float = 50.0,
    production: float = 0.0,
    attraction: float = 0.0,
    mode: str = "",
    entry_node: tuple[str, float, float] | None = None,
    exit_node: tuple[str, float, float] | None = None,
) -> dict:
    """Create a small circular boundary zone GeoJSON Feature.

    Parameters
    ----------
    zone_id:
        Identifier for the zone (typically the ``linkId`` of the crossing link).
    lon, lat:
        Centroid of the boundary zone in WGS-84 decimal degrees.
    radius_m:
        Radius of the circular approximation in metres.
    production:
        Total outbound flow originating from this zone (trips leaving the area).
    attraction:
        Total inbound flow destined for this zone (trips entering the area).
    mode:
        Transport mode of the links that cross this boundary (e.g. ``"CAR"``,
        ``"BIKE"``).  Empty string when the network carries no mode property.
    entry_node, exit_node:
        ``(node_id, lon, lat)`` of the entry resp. exit boundary node of a
        **combined** two-way mini-zone.  When both are given, the zone is not a
        network node itself: ``zoneId`` is a synthetic ID and the feedlinks
        connect it to the entry node (production) and from the exit node
        (attraction).  When omitted, the zone centroid *is* the boundary node
        identified by *zone_id*.

    Returns
    -------
    dict
        GeoJSON Feature with a Polygon geometry and zone properties.
    """
    ring = _make_circle_ring(lon, lat, radius_m=radius_m)
    props: dict = {
        "zoneId": zone_id,
        "zoneClass": "BOUNDARY",
        "centroidLon": lon,
        "centroidLat": lat,
        "production": production,
        "attraction": attraction,
        "mode": mode,
        "nodeIds": [zone_id],
    }
    if entry_node is not None and exit_node is not None:
        props["nodeIds"] = [entry_node[0], exit_node[0]]
        props["entryNode"] = {"nodeId": entry_node[0], "lon": entry_node[1], "lat": entry_node[2]}
        props["exitNode"] = {"nodeId": exit_node[0], "lon": exit_node[1], "lat": exit_node[2]}
    return {
        "type": "Feature",
        "geometry": {
            "type": "Polygon",
            "coordinates": [ring],
        },
        "properties": props,
    }


def _clip_network_to_rings(
    link_features: list[dict],
    clipping_rings: list[list],
) -> tuple[list[dict], set[str]]:
    """Clip every link in *link_features* against *clipping_rings*.

    Deduplicates clipped features by ``(linkId, fromNode, toNode)`` so that a
    link falling inside multiple rings (e.g. the sub-polygons of a
    MultiPolygon zone) is not duplicated.

    Parameters
    ----------
    link_features:
        Network link features (LineStrings) to clip.
    clipping_rings:
        One or more polygon rings (already buffered, if desired) to clip
        against. A link crossing any of the rings contributes clipped
        features and boundary node IDs.

    Returns
    -------
    tuple[list[dict], set[str]]
        ``(clipped_features, all_boundary_node_ids)`` — the deduplicated
        clipped features and the union of all true boundary-crossing node IDs
        assigned by :func:`_clip_link_to_zone`.
    """
    clipped_features: list[dict] = []
    all_boundary_node_ids: set[str] = set()
    seen_clip_keys: set[tuple[str, str, str]] = set()
    for link in link_features:
        for clipping_ring in clipping_rings:
            feats, bids = _clip_link_to_zone(link, clipping_ring)
            for feat in feats:
                fp = feat.get("properties") or {}
                clip_key = (
                    str(fp.get("linkId") or ""),
                    str(fp.get("fromNode") or ""),
                    str(fp.get("toNode") or ""),
                )
                if clip_key not in seen_clip_keys:
                    seen_clip_keys.add(clip_key)
                    clipped_features.append(feat)
            all_boundary_node_ids.update(bids)
    return clipped_features, all_boundary_node_ids


def _collect_boundary_node_info(
    clipped_features: list[dict],
    original_features: list[dict],
    boundary_node_ids: set[str],
    min_speed_kph: float = 50.0,
) -> dict[str, dict]:
    """Build a mapping of boundary node *candidates* from clipped network links.

    For every clipped link that has a **true boundary node** (i.e. a node ID
    that was assigned by ``_clip_link_to_zone`` at an actual ring crossing),
    record the node coordinates and accumulate production (exit links) and
    attraction (entry links) from the link ``flow``.

    The ``boundary_node_ids`` set is the authoritative source of which node IDs
    represent real boundary crossings.  This prevents false positives when the
    original network data already has ``fromNode == linkId`` for interior links.

    Parameters
    ----------
    clipped_features:
        Clipped link features (output of ``_clip_link_to_zone``).
    original_features:
        Original (unclipped) link features used as a fallback for ``flow``
        when the clipped feature does not carry a ``flow`` property.
    boundary_node_ids:
        Set of node ID strings assigned by ``_clip_link_to_zone`` at real
        boundary crossings.  Only nodes whose ID is in this set are processed.
    min_speed_kph:
        Minimum link ``speed`` (km/h) required for a crossing to be a
        boundary node candidate.  Crossings on links below this threshold —
        including links with no ``speed`` property at all — are dropped
        entirely: no node is recorded and the link's flow is not collected
        anywhere.  Which candidates actually become a mini-zone is decided by
        :func:`_select_boundary_groups`.  Default is 50.0.

    Returns
    -------
    dict mapping node_id → {"lon", "lat", "production", "attraction", "mode",
    "speed" (max speed of the crossing links), "isEntry", "isExit"}

    Notes
    -----
    Semantics (directed network, boundary zone perspective):

    * ``fromNode`` is a boundary node → the link *enters* the area at that node
      (traffic originates outside and flows in) → **production** of the boundary zone.
    * ``toNode`` is a boundary node → the link *exits* the area at that node
      (traffic flows out and terminates outside) → **attraction** of the boundary zone.
    """
    # Build a quick lookup: linkId → flow from original features
    original_flow: dict[str, float] = {}
    for feat in original_features:
        props = feat.get("properties") or {}
        lid = str(props.get("linkId") or props.get("spectrumId") or "")
        if lid:
            original_flow[lid] = float(props.get("flow") or 0.0)

    nodes: dict[str, dict] = {}

    for feat in clipped_features:
        props = feat.get("properties") or {}
        link_id = str(props.get("linkId") or props.get("spectrumId") or "")
        flow = float(props.get("flow") or original_flow.get(link_id) or 0.0)
        mode = str(props.get("mode") or "")
        coords = (feat.get("geometry") or {}).get("coordinates") or []
        if not coords:
            continue

        # Slow (or unclassified) crossings do not qualify as boundary nodes:
        # drop them entirely rather than recording a candidate for them.
        speed = float(props.get("speed") or 0.0)
        if speed < min_speed_kph:
            continue

        from_node = str(props.get("fromNode") or "")
        to_node = str(props.get("toNode") or "")

        def _node_entry(node_id: str, pt: list) -> dict:
            entry = nodes.setdefault(
                node_id,
                {
                    "lon": float(pt[0]),
                    "lat": float(pt[1]),
                    "production": 0.0,
                    "attraction": 0.0,
                    "mode": mode,
                    "speed": 0.0,
                    "isEntry": False,
                    "isExit": False,
                },
            )
            entry["speed"] = max(entry["speed"], speed)
            return entry

        # fromNode is a real boundary node → link enters the area → production
        if from_node in boundary_node_ids:
            entry = _node_entry(from_node, coords[0])
            entry["production"] += flow
            entry["isEntry"] = True

        # toNode is a real boundary node → link exits the area → attraction
        if to_node in boundary_node_ids:
            entry = _node_entry(to_node, coords[-1])
            entry["attraction"] += flow
            entry["isExit"] = True

    return nodes


def _group_boundary_nodes(
    nodes: dict[str, dict],
    merge_dist_m: float = 30.0,
) -> list[dict]:
    """Combine the two directions of two-way roads into one boundary group.

    A two-way road crosses the boundary as two directed links, each yielding
    its own boundary node: an entry-only node (production) and an exit-only
    node (attraction).  Entry/exit node pairs of the same ``mode`` that lie
    within *merge_dist_m* of each other are paired (closest pairs first) into
    a single combined group.  All other nodes become single-node groups.

    Parameters
    ----------
    nodes:
        Output of :func:`_collect_boundary_node_info`.
    merge_dist_m:
        Maximum distance (metres) between an entry and an exit node for them
        to be treated as the two directions of the same road.  ``0`` disables
        combining.

    Returns
    -------
    list of dict
        One dict per group with keys ``zoneId``, ``lon``, ``lat``,
        ``production``, ``attraction``, ``mode``, ``speed``,
        ``entryNodeIds``, ``exitNodeIds`` and — for combined groups only —
        ``entryNode`` / ``exitNode`` as ``(node_id, lon, lat)``.  Combined
        groups get the synthetic ``zoneId`` ``"{entryId}+{exitId}"`` and the
        midpoint of both nodes as position.  Order is deterministic (sorted by
        ``zoneId``).
    """
    entry_only = sorted(n for n, i in nodes.items() if i["isEntry"] and not i["isExit"])
    exit_only = sorted(n for n, i in nodes.items() if i["isExit"] and not i["isEntry"])

    candidate_pairs: list[tuple[float, str, str]] = []
    if merge_dist_m > 0.0:
        for en in entry_only:
            ei = nodes[en]
            for xn in exit_only:
                xi = nodes[xn]
                if ei["mode"] != xi["mode"]:
                    continue
                dist = _flat_earth_dist_m(ei["lon"], ei["lat"], xi["lon"], xi["lat"])
                if dist <= merge_dist_m:
                    candidate_pairs.append((dist, en, xn))
    candidate_pairs.sort()

    paired: set[str] = set()
    groups: list[dict] = []
    for _dist, en, xn in candidate_pairs:
        if en in paired or xn in paired:
            continue
        paired.update((en, xn))
        ei, xi = nodes[en], nodes[xn]
        groups.append(
            {
                "zoneId": f"{en}+{xn}",
                "lon": round((ei["lon"] + xi["lon"]) / 2.0, 9),
                "lat": round((ei["lat"] + xi["lat"]) / 2.0, 9),
                "production": ei["production"] + xi["production"],
                "attraction": ei["attraction"] + xi["attraction"],
                "mode": ei["mode"],
                "speed": max(ei["speed"], xi["speed"]),
                "entryNodeIds": {en},
                "exitNodeIds": {xn},
                "entryNode": (en, ei["lon"], ei["lat"]),
                "exitNode": (xn, xi["lon"], xi["lat"]),
            }
        )

    for node_id, info in nodes.items():
        if node_id in paired:
            continue
        groups.append(
            {
                "zoneId": node_id,
                "lon": info["lon"],
                "lat": info["lat"],
                "production": info["production"],
                "attraction": info["attraction"],
                "mode": info["mode"],
                "speed": info["speed"],
                "entryNodeIds": {node_id} if info["isEntry"] else set(),
                "exitNodeIds": {node_id} if info["isExit"] else set(),
            }
        )

    groups.sort(key=lambda g: g["zoneId"])
    return groups


def _select_boundary_groups(
    groups: list[dict],
    major_speed_kph: float = 50.0,
    min_boundary_zones: int = 10,
) -> list[dict]:
    """Select which boundary groups become boundary mini-zones.

    * Every group with ``speed > major_speed_kph`` is selected.
    * When that yields fewer than *min_boundary_zones* groups, the remaining
      groups (``speed <= major_speed_kph``; the caller has already dropped
      anything below the candidate floor) are added in order of importance —
      highest ``production + attraction`` first, ties broken by ``zoneId`` —
      until *min_boundary_zones* is reached or the candidates run out.

    A combined two-way group counts as one.  The input order is preserved in
    the result.
    """
    major = [g for g in groups if g["speed"] > major_speed_kph]
    shortfall = min_boundary_zones - len(major)
    if shortfall <= 0:
        return major

    minor = [g for g in groups if g["speed"] <= major_speed_kph]
    minor.sort(key=lambda g: (-(g["production"] + g["attraction"]), g["zoneId"]))
    selected_ids = {g["zoneId"] for g in major} | {g["zoneId"] for g in minor[:shortfall]}
    return [g for g in groups if g["zoneId"] in selected_ids]


def _boundary_groups_for_area(
    clipped_features: list[dict],
    link_features: list[dict],
    boundary_node_ids: set[str],
    major_boundary_speed_kph: float = 50.0,
    min_boundary_zones: int = 10,
    two_way_merge_dist_m: float = 30.0,
) -> list[dict]:
    """Collect, combine and select the boundary groups of an AREA zone.

    Shared by :func:`join_zones_to_network` and
    :func:`compute_network_boundary_node_roles` so both make the same
    selection.  Crossings slower than *major_boundary_speed_kph* are never
    candidates; see :func:`_select_boundary_groups` for the selection rule.
    """
    nodes = _collect_boundary_node_info(
        clipped_features,
        link_features,
        boundary_node_ids,
        min_speed_kph=major_boundary_speed_kph,
    )
    groups = _group_boundary_nodes(nodes, merge_dist_m=two_way_merge_dist_m)
    return _select_boundary_groups(
        groups,
        major_speed_kph=major_boundary_speed_kph,
        min_boundary_zones=min_boundary_zones,
    )


def compute_network_boundary_node_roles(
    area_zone_feature: dict,
    network_fc: dict,
    clip_buffer_m: float = 20.0,
    major_boundary_speed_kph: float = 50.0,
    min_boundary_zones: int = 10,
    two_way_merge_dist_m: float = 30.0,
) -> tuple[set[str], set[str]]:
    """Return ``(entry_node_ids, exit_node_ids)`` for an AREA zone's boundary.

    Clips every link in *network_fc* to the AREA zone's outer ring(s) — the
    same computation performed inline by :func:`join_zones_to_network` for
    AREA zones — and classifies the resulting true boundary-crossing node IDs
    by role:

    * ``entry_node_ids`` — nodes registered as the ``fromNode`` of a
      boundary-crossing link (traffic enters the network here). These are the
      valid attachment candidates for a **production** feedlink (zone →
      network).
    * ``exit_node_ids`` — nodes registered as the ``toNode`` of a
      boundary-crossing link (traffic exits the network here). These are the
      valid attachment candidates for an **attraction** feedlink (network →
      zone).

    A node can appear in both sets when it is crossed by multiple links in
    different directions.

    Only the nodes of the **selected** boundary mini-zones are returned — the
    same selection as :func:`join_zones_to_network` makes (see
    :func:`_boundary_groups_for_area`).  ``feedlink_fetcher`` uses these sets
    as the candidate pool for fallback feedlinks (notably the
    ``zone_fetcher_aggregated`` zones), so those zones deliberately attach to
    exactly the boundary mini-zone nodes; changing the boundary-zone
    selection changes that attachment too.

    Parameters
    ----------
    area_zone_feature:
        The AREA zone GeoJSON Feature (``properties.zoneClass == "AREA"``).
        Must have a Polygon or MultiPolygon geometry.
    network_fc:
        GeoJSON FeatureCollection of directed network link features.
    clip_buffer_m:
        Outward buffer in metres applied to the zone polygon before clipping,
        matching :func:`join_zones_to_network`'s ``clip_buffer_m`` parameter.
        Default is 20 m.
    major_boundary_speed_kph, min_boundary_zones, two_way_merge_dist_m:
        Boundary node selection, matching the parameters of the same name of
        :func:`join_zones_to_network`, so that exactly the nodes of the
        boundary mini-zones are returned.

    Returns
    -------
    tuple[set[str], set[str]]
        ``(entry_node_ids, exit_node_ids)``. Both are empty sets when
        *area_zone_feature* has no Polygon/MultiPolygon geometry, or no links
        cross its boundary.
    """
    zone_geom = area_zone_feature.get("geometry") or {}
    geom_type = zone_geom.get("type")
    if geom_type not in ("Polygon", "MultiPolygon"):
        return set(), set()

    raw_coords = zone_geom.get("coordinates") or []
    if geom_type == "Polygon":
        exterior_rings = [raw_coords[0]] if raw_coords and raw_coords[0] else []
    else:  # MultiPolygon
        exterior_rings = [poly[0] for poly in raw_coords if poly and poly[0]]

    if not exterior_rings:
        return set(), set()

    clipping_rings = [
        _buffer_ring(ring, clip_buffer_m) if clip_buffer_m > 0.0 else ring
        for ring in exterior_rings
    ]

    link_features = network_fc.get("features") or []
    clipped_features, all_boundary_node_ids = _clip_network_to_rings(link_features, clipping_rings)
    if not all_boundary_node_ids:
        return set(), set()

    groups = _boundary_groups_for_area(
        clipped_features,
        link_features,
        all_boundary_node_ids,
        major_boundary_speed_kph=major_boundary_speed_kph,
        min_boundary_zones=min_boundary_zones,
        two_way_merge_dist_m=two_way_merge_dist_m,
    )
    entry_node_ids: set[str] = set()
    exit_node_ids: set[str] = set()
    for group in groups:
        entry_node_ids |= group["entryNodeIds"]
        exit_node_ids |= group["exitNodeIds"]

    return entry_node_ids, exit_node_ids


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

# Property keys on every feedlink feature produced by this module.
FEEDLINK_PROPERTIES: tuple[str, ...] = (
    "feedlinkId",
    "reverseLinkIds",
    "zoneId",
    "fromNode",
    "toNode",
    "length",
    "capacity",
    "mode",
    "ringIndex",
    "ringLabel",
    "sectorIndex",
    "type",
)


def _make_boundary_mini_zone_feedlinks(
    boundary_zone_features: list[dict],
    mode: str,
    start_fid: int = 1,
) -> list[dict]:
    """Create centroid-connector feedlinks for boundary mini-zones.

    For each boundary mini-zone the zone centroid IS the boundary network node
    (they share the same coordinates and node ID).  The feedlinks therefore
    have zero length but are required so that the OD matrix builder can
    load/unload trips at each boundary node.

    Two feedlinks are produced per boundary mini-zone:

    * **Production** — zone centroid node → boundary network node,
      ``capacity`` = ``production`` property of the mini-zone.
    * **Attraction** — boundary network node → zone centroid node,
      ``capacity`` = ``attraction`` property of the mini-zone.

    A **combined** two-way mini-zone (with ``entryNode`` / ``exitNode``
    properties) is not a network node itself; its production feedlink runs
    from the zone centroid to the entry node and its attraction feedlink from
    the exit node to the zone centroid, with the actual distance as length.

    Parameters
    ----------
    boundary_zone_features:
        List of boundary mini-zone GeoJSON Features (``zoneClass == "BOUNDARY"``).
    mode:
        Transport mode string (e.g. ``"CAR"``).
    start_fid:
        First feedlink ID to assign.  IDs are allocated consecutively.

    Returns
    -------
    list[dict]
        GeoJSON Feature dicts with all keys in ``FEEDLINK_PROPERTIES``.
    """
    result: list[dict] = []
    fid = start_fid

    for zone_feat in boundary_zone_features:
        props = zone_feat.get("properties") or {}
        zone_id = str(props.get("zoneId") or "")
        lon = float(props.get("centroidLon") or 0.0)
        lat = float(props.get("centroidLat") or 0.0)
        production = float(props.get("production") or 0.0)
        attraction = float(props.get("attraction") or 0.0)

        # Single-node mini-zone: both ends are the boundary node ID
        # (== zone_id == linkId); the centroid is AT the network node, so length = 0.
        # Combined two-way mini-zone: connect to the entry resp. exit node.
        entry_node = props.get("entryNode") or {}
        exit_node = props.get("exitNode") or {}
        entry_id = str(entry_node.get("nodeId") or zone_id)
        entry_lon = float(entry_node.get("lon", lon))
        entry_lat = float(entry_node.get("lat", lat))
        exit_id = str(exit_node.get("nodeId") or zone_id)
        exit_lon = float(exit_node.get("lon", lon))
        exit_lat = float(exit_node.get("lat", lat))
        prod_length = round(_flat_earth_dist_m(lon, lat, entry_lon, entry_lat), 1)
        attr_length = round(_flat_earth_dist_m(exit_lon, exit_lat, lon, lat), 1)

        prod_fid = fid
        attr_fid = fid + 1

        result.append(
            {
                "type": "Feature",
                "geometry": _straight_line(lon, lat, entry_lon, entry_lat),
                "properties": {
                    "feedlinkId": prod_fid,
                    "reverseLinkIds": [attr_fid],
                    "zoneId": zone_id,
                    "fromNode": zone_id,
                    "toNode": entry_id,
                    "length": prod_length,
                    "capacity": production,
                    "mode": mode,
                    "ringIndex": -1,
                    "ringLabel": "",
                    "sectorIndex": -1,
                    "type": "feedlink",
                },
            }
        )
        result.append(
            {
                "type": "Feature",
                "geometry": _straight_line(exit_lon, exit_lat, lon, lat),
                "properties": {
                    "feedlinkId": attr_fid,
                    "reverseLinkIds": [prod_fid],
                    "zoneId": zone_id,
                    "fromNode": exit_id,
                    "toNode": zone_id,
                    "length": attr_length,
                    "capacity": attraction,
                    "mode": mode,
                    "ringIndex": -1,
                    "ringLabel": "",
                    "sectorIndex": -1,
                    "type": "feedlink",
                },
            }
        )
        fid += 2

    return result


def extend_feedlinks_for_zone(
    feedlinks_fc: dict | None,
    clipped_network_fc: dict,
    zone_feature: dict,
    mode: str,
    boundary_node_ids: set[str] | None = None,
) -> dict:
    """Build a feedlinks FeatureCollection for one clipped zone.

    Two operations are performed:

    1. **Filter** — from *feedlinks_fc* keep only feedlinks whose ``fromNode``
       or ``toNode`` appears as a node in the clipped network.
    2. **Synthesise** — for every **true** boundary node in the clipped network
       (i.e. a node whose ID is in *boundary_node_ids*, as set by
       ``_clip_link_to_zone``), create one production feedlink
       (zone centroid → boundary node) and one attraction feedlink
       (boundary node → zone centroid).  The ``capacity`` of each synthetic
       feedlink equals the ``flow`` property of the clipped link.

    Parameters
    ----------
    feedlinks_fc:
        Existing feedlinks FeatureCollection (e.g. from ``feedlink_fetcher``).
        May be *None* or empty.
    clipped_network_fc:
        FeatureCollection of clipped links within the zone (output of
        ``join_zones_to_network``).
    zone_feature:
        The original zone GeoJSON Feature; used for the zone centroid position
        and ``zoneId``.
    mode:
        Transport mode string, e.g. ``"CAR"``.
    boundary_node_ids:
        Set of node ID strings that were assigned by ``_clip_link_to_zone`` at
        real boundary crossings.  When provided, only nodes whose ID is in this
        set are synthesised as boundary feedlinks.  When *None*, falls back to
        the legacy heuristic (``fromNode == linkId``), which may produce false
        positives when original network data already carries that coincidence.

    Returns
    -------
    dict
        GeoJSON FeatureCollection of feedlinks for this zone.
    """
    zone_props = zone_feature.get("properties") or {}
    zone_id = str(zone_props.get("zoneId") or "")
    zone_lon = float(zone_props.get("centroidLon") or 0.0)
    zone_lat = float(zone_props.get("centroidLat") or 0.0)
    zone_node_id = str(zone_props.get("gid") or zone_id)

    clipped_features = clipped_network_fc.get("features") or []

    # Build set of all node IDs in the clipped network
    clipped_node_ids: set[str] = set()
    for feat in clipped_features:
        props = feat.get("properties") or {}
        fn = props.get("fromNode")
        tn = props.get("toNode")
        if fn is not None:
            clipped_node_ids.add(str(fn))
        if tn is not None:
            clipped_node_ids.add(str(tn))

    # 1. Filter existing feedlinks to those with a node in the clipped network
    existing: list[dict] = []
    for feat in (feedlinks_fc or {}).get("features") or []:
        props = feat.get("properties") or {}
        fn = str(props.get("fromNode") or "")
        tn = str(props.get("toNode") or "")
        if fn in clipped_node_ids or tn in clipped_node_ids:
            existing.append(copy.deepcopy(feat))

    # 2. Synthesise feedlinks for boundary nodes
    # A boundary node is one whose ID is in boundary_node_ids (set by _clip_link_to_zone).
    # When boundary_node_ids is None, fall back to the legacy heuristic (fromNode == linkId).
    synthetic: list[dict] = []
    fid = (
        max(
            (f["properties"].get("feedlinkId") or 0 for f in existing),
            default=0,
        )
        + 1
    )

    for feat in clipped_features:
        props = feat.get("properties") or {}
        link_id = str(props.get("linkId") or props.get("spectrumId") or "")
        flow = float(props.get("flow") or 0.0)
        coords = (feat.get("geometry") or {}).get("coordinates") or []

        boundary_nodes: list[tuple[str, list]] = []  # (node_id, [lon, lat])

        from_node = str(props.get("fromNode") or "")
        to_node = str(props.get("toNode") or "")

        def _is_boundary(node_id: str) -> bool:
            if boundary_node_ids is not None:
                return node_id in boundary_node_ids
            # Legacy fallback: fromNode/toNode equals the link's own linkId
            return node_id == link_id

        if _is_boundary(from_node) and coords:
            boundary_nodes.append((from_node, list(coords[0])))
        if _is_boundary(to_node) and coords:
            boundary_nodes.append((to_node, list(coords[-1])))

        for node_id, node_coords in boundary_nodes:
            node_lon = float(node_coords[0])
            node_lat = float(node_coords[1])
            dist_m = _flat_earth_dist_m(zone_lon, zone_lat, node_lon, node_lat)
            length = round(dist_m, 1)

            prod_fid = fid
            attr_fid = fid + 1

            # Production: zone centroid → boundary node
            synthetic.append(
                {
                    "type": "Feature",
                    "geometry": _straight_line(zone_lon, zone_lat, node_lon, node_lat),
                    "properties": {
                        "feedlinkId": prod_fid,
                        "reverseLinkIds": [attr_fid],
                        "zoneId": zone_id,
                        "fromNode": zone_node_id,
                        "toNode": node_id,
                        "length": length,
                        "capacity": flow,
                        "mode": mode,
                        "ringIndex": -1,
                        "ringLabel": "",
                        "sectorIndex": -1,
                        "type": "feedlink",
                    },
                }
            )
            # Attraction: boundary node → zone centroid
            synthetic.append(
                {
                    "type": "Feature",
                    "geometry": _straight_line(node_lon, node_lat, zone_lon, zone_lat),
                    "properties": {
                        "feedlinkId": attr_fid,
                        "reverseLinkIds": [prod_fid],
                        "zoneId": zone_id,
                        "fromNode": node_id,
                        "toNode": zone_node_id,
                        "length": length,
                        "capacity": flow,
                        "mode": mode,
                        "ringIndex": -1,
                        "ringLabel": "",
                        "sectorIndex": -1,
                        "type": "feedlink",
                    },
                }
            )
            fid += 2

    logger.info(
        "Zone %r: %d filtered feedlinks + %d synthetic = %d total",
        zone_id,
        len(existing),
        len(synthetic),
        len(existing) + len(synthetic),
    )
    return {
        "type": "FeatureCollection",
        "features": existing + synthetic,
        "properties": {"fields": list(FEEDLINK_PROPERTIES)},
    }


def join_zones_to_network(
    zones_fc: dict,
    network_fc: dict,
    zone_classes: set[str] | None = None,
    feedlinks_fc: dict | None = None,
    clip_buffer_m: float = 20.0,
    adjust_boundary_demands: bool = True,
    major_boundary_speed_kph: float = 50.0,
    min_boundary_zones: int = 10,
    two_way_merge_dist_m: float = 30.0,
) -> list[tuple[dict, dict, dict, dict]]:
    """Clip the network to each zone polygon.

    Parameters
    ----------
    zones_fc:
        GeoJSON FeatureCollection of zone features (STUDY, INFLUENCE, AREA).
        Expected to have ``properties.areaId``.
    network_fc:
        GeoJSON FeatureCollection of directed network link features (LineStrings).
        Expected to have ``properties.modes`` (list) and optionally
        ``properties.area_id``.
    zone_classes:
        Optional set of ``zoneClass`` values to process (e.g. ``{"AREA"}``).
        When *None* or empty, all zones are processed.
    feedlinks_fc:
        Optional feedlinks FeatureCollection (from ``feedlink_fetcher``).
        When provided, each result tuple includes an extended feedlinks FC
        with filtered existing feedlinks plus synthetic boundary-node feedlinks.
        When *None*, the feedlinks element of each tuple is an empty FC.
    clip_buffer_m:
        Outward buffer in metres applied to each zone polygon before clipping
        the network.  Links that lie within this distance outside the zone
        boundary are included in the clipped network.  The zone polygons in
        the output are **not** modified; only the clipping region is expanded.
        Default is 20 m.
    adjust_boundary_demands:
        When *True* (default), internal zone ``production`` and ``attraction``
        values are reduced by their proportional share of the total
        boundary-crossing flow to prevent double-counting with the synthetic
        boundary mini-zones.  Set to *False* when zone demands come from an
        external demand model (e.g. OmniTRANS) and are independent of the
        link-flow values used to size the boundary mini-zones.
    major_boundary_speed_kph:
        Speed (km/h) above which an AREA-ring crossing is a major road: every
        crossing with ``speed > major_boundary_speed_kph`` produces a boundary
        mini-zone.  Crossings slower than this value — including links with no
        ``speed`` property — are dropped entirely: no mini-zone is created and
        the link's flow is not collected anywhere.  Default is 50.0.
    min_boundary_zones:
        Minimum number of boundary mini-zones.  When the major roads yield
        fewer, crossings at exactly ``major_boundary_speed_kph`` are added,
        highest ``production + attraction`` first, until this number is
        reached.  Default is 10.
    two_way_merge_dist_m:
        An entry and an exit crossing within this distance (metres) of each
        other are treated as the two directions of one two-way road and
        combined into a single mini-zone (``zoneId`` ``"{entry}+{exit}"``).
        A combined mini-zone counts as one towards *min_boundary_zones*.
        ``0`` disables combining.  Default is 30.0.

    Returns
    -------
    list of (zone_feature, clipped_network_fc, zone_fc, extended_feedlinks_fc) tuples
        * ``zone_feature`` — the original zone GeoJSON Feature.
        * ``clipped_network_fc`` — FeatureCollection of clipped links within
          the (buffered) zone, with additional ``zoneId`` and ``zoneClass`` in
          its ``properties``.
        * ``zone_fc`` — FeatureCollection wrapping the single zone feature.
        * ``extended_feedlinks_fc`` — FeatureCollection of feedlinks for the
          zone (filtered existing + synthetic boundary-node feedlinks).

    Zones whose geometry is not a Polygon or MultiPolygon, or whose
    ``zoneClass`` is not in *zone_classes* (when given), are silently skipped.
    MultiPolygon zones are handled by clipping the network against each
    sub-polygon's exterior ring independently; duplicate clipped features
    (links inside multiple sub-polygons) are deduplicated.
    """
    zone_features = zones_fc.get("features") or []
    link_features = network_fc.get("features") or []
    network_props = network_fc.get("properties") or {}

    # Resolve transport mode from network properties for synthetic feedlinks
    mode = str(
        (network_props.get("modes") or [""])[0]
        if isinstance(network_props.get("modes"), list)
        else network_props.get("modes") or ""
    )

    results: list[tuple[dict, dict, dict, dict]] = []

    for zone_feat in zone_features:
        zone_geom = zone_feat.get("geometry") or {}
        zone_props = zone_feat.get("properties") or {}
        zone_id = zone_props.get("zoneId") or ""
        zone_class = zone_props.get("zoneClass") or ""

        geom_type = zone_geom.get("type")
        if geom_type not in ("Polygon", "MultiPolygon"):
            logger.debug("Skipping zone %r — geometry type is %r", zone_id, geom_type)
            continue

        if zone_classes and zone_class not in zone_classes:
            logger.debug(
                "Skipping zone %r — class %r not in filter %r", zone_id, zone_class, zone_classes
            )
            continue

        # Extract exterior rings from Polygon or MultiPolygon.
        # For Polygon: coordinates = [exterior_ring, *holes]
        # For MultiPolygon: coordinates = [[exterior_ring, *holes], ...]
        raw_coords = zone_geom.get("coordinates") or []
        if geom_type == "Polygon":
            exterior_rings = [raw_coords[0]] if raw_coords and raw_coords[0] else []
        else:  # MultiPolygon
            exterior_rings = [poly[0] for poly in raw_coords if poly and poly[0]]

        if not exterior_rings:
            logger.debug("Skipping zone %r — no exterior rings found", zone_id)
            continue

        # Expand each clipping ring outward by clip_buffer_m.
        clipping_rings = [
            _buffer_ring(ring, clip_buffer_m) if clip_buffer_m > 0.0 else ring
            for ring in exterior_rings
        ]

        clipped_features, all_boundary_node_ids = _clip_network_to_rings(
            link_features, clipping_rings
        )

        clipped_network_fc: dict = {
            "type": "FeatureCollection",
            "features": clipped_features,
            "properties": {
                **network_props,
                "zoneId": zone_id,
                "zoneClass": zone_class,
            },
        }

        # For AREA zones, collect boundary nodes and build mini-zones
        boundary_zone_features: list[dict] = []
        if zone_class == "AREA":
            groups = _boundary_groups_for_area(
                clipped_features,
                link_features,
                all_boundary_node_ids,
                major_boundary_speed_kph=major_boundary_speed_kph,
                min_boundary_zones=min_boundary_zones,
                two_way_merge_dist_m=two_way_merge_dist_m,
            )
            for group in groups:
                boundary_zone_features.append(
                    _make_boundary_zone(
                        zone_id=group["zoneId"],
                        lon=group["lon"],
                        lat=group["lat"],
                        production=group["production"],
                        attraction=group["attraction"],
                        mode=group["mode"],
                        entry_node=group.get("entryNode"),
                        exit_node=group.get("exitNode"),
                    )
                )
            logger.info(
                "Zone %r (AREA): %d boundary mini-zones created "
                "(%d major > %.0f km/h, %d combined two-way)",
                zone_id,
                len(boundary_zone_features),
                sum(1 for g in groups if g["speed"] > major_boundary_speed_kph),
                major_boundary_speed_kph,
                sum(1 for g in groups if "entryNode" in g),
            )

        # For AREA zones: include STUDY + INFLUENCE zones and boundary mini-zones,
        # but exclude the AREA zone itself (it is the clipping boundary and has no
        # meaning as a traffic zone for downstream tools such as the OD matrix builder).
        # For other zone classes: include only the single zone feature.
        if zone_class == "AREA":
            zone_fc_features: list[dict] = [
                f for f in zone_features if (f.get("properties") or {}).get("zoneClass") != "AREA"
            ] + boundary_zone_features
        else:
            zone_fc_features = [zone_feat, *boundary_zone_features]

        # For AREA zones: reduce internal-zone attractions/productions by the
        # boundary-crossing flows so that boundary demand is not double-counted.
        # Skip when adjust_boundary_demands=False (e.g. OmniTRANS data where
        # zone demands are independent of link flows).
        if zone_class == "AREA" and boundary_zone_features and adjust_boundary_demands:
            zone_fc_features = _adjust_internal_zone_demands(
                zone_fc_features, boundary_zone_features
            )

        # Annotate each zone feature with nodeProportions: {nodeId: proportion}
        # where proportion is each node's share of total connected link length
        # across all nodes within that zone (values sum to 1.0 per zone).
        zone_fc_features = _annotate_zone_proportions(zone_fc_features, clipped_features)

        zone_fc: dict = {
            "type": "FeatureCollection",
            "features": zone_fc_features,
            "properties": dict(zone_props),
        }

        extended_feedlinks_fc = extend_feedlinks_for_zone(
            feedlinks_fc,
            clipped_network_fc,
            zone_feat,
            mode,
            # For AREA zones, boundary nodes are handled by _make_boundary_mini_zone_feedlinks
            # (zero-length self-connections at each crossing node).  Do NOT synthesise
            # zone-centroid → boundary-node feedlinks here; those would originate from the
            # AREA zone centroid, which is not a meaningful network location.
            boundary_node_ids=set() if zone_class == "AREA" else all_boundary_node_ids,
        )

        # For AREA zones: append zero-length centroid connectors for each boundary mini-zone.
        # These feedlinks let the OD matrix builder load/unload trips at every boundary node.
        if boundary_zone_features:
            existing_fids = [
                f["properties"].get("feedlinkId") or 0
                for f in extended_feedlinks_fc.get("features") or []
            ]
            next_fid = max(existing_fids, default=0) + 1
            mini_zone_feedlinks = _make_boundary_mini_zone_feedlinks(
                boundary_zone_features,
                mode,
                start_fid=next_fid,
            )
            extended_feedlinks_fc = {
                **extended_feedlinks_fc,
                "features": extended_feedlinks_fc["features"] + mini_zone_feedlinks,
            }
            logger.info(
                "Zone %r (AREA): %d boundary mini-zone feedlinks added",
                zone_id,
                len(mini_zone_feedlinks),
            )

        logger.info(
            "Zone %r (%s): %d input links → %d clipped features",
            zone_id,
            zone_class,
            len(link_features),
            len(clipped_features),
        )
        results.append((zone_feat, clipped_network_fc, zone_fc, extended_feedlinks_fc))

    return results
