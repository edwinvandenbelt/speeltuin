"""Tests for network_zone_joiner — geometry, clipping, and join logic."""

from __future__ import annotations

import math

import pytest

from gmt_network_core.network_zone_joiner.domain.geometry import (
    _acute_angle_deg,
    _buffer_ring,
    _intersections_with_ring,
    _intersections_with_ring_extended,
    _ring_signed_area,
    _segment_intersect_t,
    clip_linestring_to_polygon,
    clip_linestring_to_polygon_angled,
    point_in_polygon,
)
from gmt_network_core.network_zone_joiner.domain.joiner import (
    FEEDLINK_PROPERTIES,
    _adjust_internal_zone_demands,
    _annotate_zone_proportions,
    _build_node_coords,
    _build_node_total_length,
    _build_node_zone_map,
    _clip_link_to_zone,
    _clip_network_to_rings,
    _collect_boundary_node_info,
    _compute_node_proportions,
    _coords_close,
    _group_boundary_nodes,
    _make_boundary_mini_zone_feedlinks,
    _make_boundary_zone,
    _make_circle_ring,
    _select_boundary_groups,
    build_zone_output_path,
    compute_network_boundary_node_roles,
    extend_feedlinks_for_zone,
    join_zones_to_network,
)

# ---------------------------------------------------------------------------
# Fixtures — a simple unit square polygon ring [0,0]→[1,0]→[1,1]→[0,1]→[0,0]
# ---------------------------------------------------------------------------

SQUARE_RING = [
    [0.0, 0.0],
    [1.0, 0.0],
    [1.0, 1.0],
    [0.0, 1.0],
    [0.0, 0.0],  # closed
]


def _make_zone_fc(zone_id: str = "z1", zone_class: str = "STUDY") -> dict:
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {
                    "type": "Polygon",
                    "coordinates": [SQUARE_RING],
                },
                "properties": {
                    "zoneId": zone_id,
                    "zoneClass": zone_class,
                },
            }
        ],
        "properties": {"areaId": "area-001"},
    }


def _make_link(
    coords: list,
    link_id: str = "L1",
    from_node: int = 10,
    to_node: int = 20,
    speed: float = 100.0,
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "spectrumId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "mode": "CAR",
            "speed": speed,
        },
    }


def _make_network_fc(features: list) -> dict:
    return {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"modes": ["CAR"], "area_id": "area-001"},
    }


# ===========================================================================
# point_in_polygon
# ===========================================================================


class TestPointInPolygon:
    def test_centre_is_inside(self):
        assert point_in_polygon(0.5, 0.5, SQUARE_RING) is True

    def test_outside_point(self):
        assert point_in_polygon(2.0, 2.0, SQUARE_RING) is False

    def test_negative_coords(self):
        assert point_in_polygon(-0.1, 0.5, SQUARE_RING) is False

    def test_near_edge(self):
        # Just inside near the bottom edge
        assert point_in_polygon(0.5, 0.01, SQUARE_RING) is True

    def test_just_outside_edge(self):
        assert point_in_polygon(0.5, -0.01, SQUARE_RING) is False

    def test_corner_region(self):
        # Near corner (0.01, 0.01) — inside
        assert point_in_polygon(0.01, 0.01, SQUARE_RING) is True

    def test_open_ring_same_as_closed(self):
        """An open ring (first != last) should produce the same result."""
        open_ring = SQUARE_RING[:-1]  # drop the closing duplicate
        assert point_in_polygon(0.5, 0.5, open_ring) is True
        assert point_in_polygon(2.0, 2.0, open_ring) is False


# ===========================================================================
# _segment_intersect_t
# ===========================================================================


class TestSegmentIntersectT:
    def test_crossing_segments(self):
        # Diagonal segments crossing at (0.5, 0.5)
        t = _segment_intersect_t(0, 0, 1, 1, 0, 1, 1, 0)
        assert t is not None
        assert abs(t - 0.5) < 1e-9

    def test_parallel_segments_return_none(self):
        t = _segment_intersect_t(0, 0, 1, 0, 0, 1, 1, 1)
        assert t is None

    def test_no_intersection_outside_range(self):
        # Segments that would cross if extended but don't overlap
        t = _segment_intersect_t(0, 0, 0.4, 0.4, 0, 1, 1, 0)
        assert t is None

    def test_t_endpoint(self):
        # Intersection exactly at B endpoint (t=1)
        t = _segment_intersect_t(0, 0, 1, 0, 1, -1, 1, 1)
        assert t is not None
        assert abs(t - 1.0) < 1e-9


# ===========================================================================
# _intersections_with_ring
# ===========================================================================


class TestIntersectionsWithRing:
    def test_horizontal_line_through_square(self):
        # Segment from (-0.5, 0.5) to (1.5, 0.5) crosses left and right sides
        hits = _intersections_with_ring(-0.5, 0.5, 1.5, 0.5, SQUARE_RING)
        assert len(hits) == 2
        ts = [h[0] for h in hits]
        assert ts[0] < ts[1]

    def test_line_entirely_inside_no_hits(self):
        hits = _intersections_with_ring(0.2, 0.2, 0.8, 0.8, SQUARE_RING)
        assert hits == []

    def test_line_entirely_outside_no_hits(self):
        hits = _intersections_with_ring(2.0, 0.0, 3.0, 1.0, SQUARE_RING)
        assert hits == []

    def test_single_crossing(self):
        # Segment from inside to outside; crosses right edge at x=1, y=0.5
        hits = _intersections_with_ring(0.5, 0.5, 1.5, 0.5, SQUARE_RING)
        assert len(hits) == 1
        _t, ix, iy = hits[0]
        assert abs(ix - 1.0) < 1e-9
        assert abs(iy - 0.5) < 1e-9


# ===========================================================================
# clip_linestring_to_polygon
# ===========================================================================


class TestClipLinestringToPolygon:
    def test_entirely_inside_returns_full_coords(self):
        coords = [[0.2, 0.2], [0.8, 0.8]]
        result = clip_linestring_to_polygon(coords, SQUARE_RING)
        assert len(result) == 1
        assert len(result[0]) == 2
        assert result[0][0] == [0.2, 0.2]
        assert result[0][-1] == [0.8, 0.8]

    def test_entirely_outside_returns_empty(self):
        coords = [[2.0, 0.0], [3.0, 1.0]]
        result = clip_linestring_to_polygon(coords, SQUARE_RING)
        assert result == []

    def test_entering_from_left(self):
        # Starts outside (left), enters at x=0, exits right at x=1
        coords = [[-0.5, 0.5], [1.5, 0.5]]
        result = clip_linestring_to_polygon(coords, SQUARE_RING)
        assert len(result) == 1
        seg = result[0]
        # First point should be on the left edge (x≈0)
        assert abs(seg[0][0] - 0.0) < 1e-9
        assert abs(seg[0][1] - 0.5) < 1e-9
        # Last point should be on the right edge (x≈1)
        assert abs(seg[-1][0] - 1.0) < 1e-9
        assert abs(seg[-1][1] - 0.5) < 1e-9

    def test_exiting_to_right(self):
        # Starts inside, exits right
        coords = [[0.5, 0.5], [1.5, 0.5]]
        result = clip_linestring_to_polygon(coords, SQUARE_RING)
        assert len(result) == 1
        seg = result[0]
        assert result[0][0] == [0.5, 0.5]
        assert abs(seg[-1][0] - 1.0) < 1e-9

    def test_passing_entirely_through(self):
        # Segment passes through the square entirely (both endpoints outside)
        coords = [[-0.5, 0.5], [1.5, 0.5]]
        result = clip_linestring_to_polygon(coords, SQUARE_RING)
        assert len(result) == 1
        assert abs(result[0][0][0] - 0.0) < 1e-9
        assert abs(result[0][-1][0] - 1.0) < 1e-9

    def test_multipoint_linestring_inside(self):
        coords = [[0.1, 0.1], [0.5, 0.5], [0.9, 0.2]]
        result = clip_linestring_to_polygon(coords, SQUARE_RING)
        assert len(result) == 1
        assert len(result[0]) == 3

    def test_linestring_enters_and_exits_multiple_times(self):
        # Zigzag: outside → inside → outside → inside
        # Horizontal at y=0.5: outside(-0.5) → inside(0.2) → outside(0.8) [wrong, both inside 0.2–0.8]
        # Use a more complex shape: goes outside the top edge and comes back
        # Square is [0,1]x[0,1]; go from (0.2,0.5) to (0.5,1.5) to (0.8,0.5)
        coords = [[0.2, 0.5], [0.5, 1.5], [0.8, 0.5]]
        result = clip_linestring_to_polygon(coords, SQUARE_RING)
        # Should produce 2 segments: [0.2,0.5]→boundary + boundary→[0.8,0.5]
        assert len(result) == 2

    def test_single_point_linestring_returns_empty(self):
        result = clip_linestring_to_polygon([[0.5, 0.5]], SQUARE_RING)
        assert result == []

    def test_empty_coords_returns_empty(self):
        result = clip_linestring_to_polygon([], SQUARE_RING)
        assert result == []

    def test_z_coordinates_are_preserved(self):
        # GeoJSON allows 3D coordinates; z should pass through unchanged
        coords = [[0.2, 0.2, 10.0], [0.8, 0.8, 20.0]]
        result = clip_linestring_to_polygon(coords, SQUARE_RING)
        assert len(result) == 1
        # The function only uses x,y but stores original coords incl. z?
        # Actually, our impl only stores [lon, lat] — this is acceptable.


# ===========================================================================
# _clip_link_to_zone
# ===========================================================================


class TestClipLinkToZone:
    def test_link_entirely_inside_kept_unchanged(self):
        link = _make_link([[0.2, 0.2], [0.8, 0.8]], link_id="L1", from_node=10, to_node=20)
        result, bids = _clip_link_to_zone(link, SQUARE_RING)
        assert len(result) == 1
        props = result[0]["properties"]
        assert props["fromNode"] == 10
        assert props["toNode"] == 20
        assert bids == set()

    def test_link_entirely_outside_excluded(self):
        link = _make_link([[2.0, 0.0], [3.0, 1.0]])
        result, bids = _clip_link_to_zone(link, SQUARE_RING)
        assert result == []
        assert bids == set()

    def test_link_entering_from_outside_gets_linkid_as_from_node(self):
        # Link goes from outside to inside; boundary node → linkId as fromNode
        link = _make_link([[-0.5, 0.5], [0.5, 0.5]], link_id="L42", from_node=1, to_node=2)
        result, bids = _clip_link_to_zone(link, SQUARE_RING)
        assert len(result) == 1
        props = result[0]["properties"]
        assert props["fromNode"] == "L42"
        assert props["toNode"] == 2  # original toNode preserved (inside)
        assert "L42" in bids

    def test_link_exiting_to_outside_gets_linkid_as_to_node(self):
        # Link goes from inside to outside; boundary node → linkId as toNode
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L99", from_node=5, to_node=6)
        result, bids = _clip_link_to_zone(link, SQUARE_RING)
        assert len(result) == 1
        props = result[0]["properties"]
        assert props["fromNode"] == 5  # original fromNode preserved (inside)
        assert props["toNode"] == "L99"
        assert "L99" in bids

    def test_link_passing_through_gets_linkid_both_ends(self):
        # Link passes fully through the square (both endpoints outside)
        link = _make_link([[-0.5, 0.5], [1.5, 0.5]], link_id="L7", from_node=100, to_node=200)
        result, bids = _clip_link_to_zone(link, SQUARE_RING)
        assert len(result) == 1
        props = result[0]["properties"]
        assert props["fromNode"] == "L7"
        assert props["toNode"] == "L7"
        assert "L7" in bids

    def test_non_linestring_skipped(self):
        point_feat = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0.5, 0.5]},
            "properties": {},
        }
        result, bids = _clip_link_to_zone(point_feat, SQUARE_RING)
        assert result == []
        assert bids == set()

    def test_link_properties_are_deep_copied(self):
        link = _make_link([[0.2, 0.2], [0.8, 0.8]], link_id="L1")
        result, _bids = _clip_link_to_zone(link, SQUARE_RING)
        # Mutating result props should not affect original
        result[0]["properties"]["mode"] = "BIKE"
        assert link["properties"]["mode"] == "CAR"


# ===========================================================================
# build_zone_output_path
# ===========================================================================


class TestBuildZoneOutputPath:
    def test_with_mode(self):
        path = build_zone_output_path("s3://bucket/out", "area1", "zone1", "NETWORK", "CAR")
        assert path == "s3://bucket/out/area1[zone1]-NETWORK-CAR.geojson"

    def test_without_mode(self):
        path = build_zone_output_path("/tmp/out", "area1", "zone1", "ZONE")
        assert path == "/tmp/out/area1[zone1]-ZONE.geojson"

    def test_trailing_slash_in_folder(self):
        path = build_zone_output_path("s3://bucket/out/", "a", "z", "NETWORK", "BIKE")
        assert path == "s3://bucket/out/a[z]-NETWORK-BIKE.geojson"

    def test_zone_id_with_special_chars(self):
        path = build_zone_output_path("/out", "area", "zone-uuid-123", "ZONE", "CAR")
        assert path == "/out/area[zone-uuid-123]-ZONE-CAR.geojson"


# ===========================================================================
# _coords_close
# ===========================================================================


class TestCoordsClose:
    def test_identical_coords(self):
        assert _coords_close([1.0, 2.0], [1.0, 2.0]) is True

    def test_very_close_coords(self):
        assert _coords_close([1.0, 2.0], [1.0 + 1e-10, 2.0]) is True

    def test_different_coords(self):
        assert _coords_close([1.0, 2.0], [1.1, 2.0]) is False


# ===========================================================================
# join_zones_to_network (integration)
# ===========================================================================


class TestJoinZonesToNetwork:
    def test_basic_join_produces_one_result_per_polygon_zone(self):
        link = _make_link([[0.5, 0.5], [0.8, 0.8]])
        zones_fc = _make_zone_fc("z1", "STUDY")
        net_fc = _make_network_fc([link])
        results = join_zones_to_network(zones_fc, net_fc)
        assert len(results) == 1

    def test_result_tuple_structure(self):
        link = _make_link([[0.5, 0.5], [0.8, 0.8]])
        zones_fc = _make_zone_fc("z1")
        net_fc = _make_network_fc([link])
        results = join_zones_to_network(zones_fc, net_fc)
        zone_feat, clipped_net, zone_fc, _ = results[0]
        assert zone_feat["type"] == "Feature"
        assert clipped_net["type"] == "FeatureCollection"
        assert zone_fc["type"] == "FeatureCollection"

    def test_clipped_network_fc_has_zone_metadata(self):
        link = _make_link([[0.5, 0.5], [0.8, 0.8]])
        zones_fc = _make_zone_fc("my-zone", "INFLUENCE")
        net_fc = _make_network_fc([link])
        _, clipped_net, _, _ = join_zones_to_network(zones_fc, net_fc)[0]
        assert clipped_net["properties"]["zoneId"] == "my-zone"
        assert clipped_net["properties"]["zoneClass"] == "INFLUENCE"

    def test_zone_fc_wraps_single_zone_feature(self):
        link = _make_link([[0.5, 0.5], [0.8, 0.8]])
        zones_fc = _make_zone_fc("z1")
        net_fc = _make_network_fc([link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc)[0]
        assert len(zone_fc["features"]) == 1
        assert zone_fc["features"][0]["properties"]["zoneId"] == "z1"

    def test_link_outside_zone_excluded(self):
        link = _make_link([[2.0, 2.0], [3.0, 3.0]])
        zones_fc = _make_zone_fc()
        net_fc = _make_network_fc([link])
        _, clipped_net, _, _ = join_zones_to_network(zones_fc, net_fc)[0]
        assert clipped_net["features"] == []

    def test_multiple_zones_produce_multiple_results(self):
        zones_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": [SQUARE_RING]},
                    "properties": {"zoneId": "z1", "zoneClass": "STUDY"},
                },
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "Polygon",
                        "coordinates": [
                            [[2.0, 2.0], [3.0, 2.0], [3.0, 3.0], [2.0, 3.0], [2.0, 2.0]]
                        ],
                    },
                    "properties": {"zoneId": "z2", "zoneClass": "INFLUENCE"},
                },
            ],
            "properties": {"areaId": "test-area"},
        }
        link = _make_link([[0.5, 0.5], [0.8, 0.8]])
        net_fc = _make_network_fc([link])
        results = join_zones_to_network(zones_fc, net_fc)
        assert len(results) == 2
        # Link is inside z1 but not z2
        _, net1, _, _ = results[0]
        _, net2, _, _ = results[1]
        assert len(net1["features"]) == 1
        assert len(net2["features"]) == 0

    def test_non_polygon_zone_is_skipped(self):
        zones_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Point", "coordinates": [0.5, 0.5]},
                    "properties": {"zoneId": "p1", "zoneClass": "STUDY"},
                }
            ],
            "properties": {"areaId": "test-area"},
        }
        net_fc = _make_network_fc([_make_link([[0.2, 0.2], [0.8, 0.8]])])
        results = join_zones_to_network(zones_fc, net_fc)
        assert results == []

    def test_empty_zones_returns_empty_list(self):
        zones_fc = {"type": "FeatureCollection", "features": [], "properties": {}}
        net_fc = _make_network_fc([_make_link([[0.2, 0.2], [0.8, 0.8]])])
        assert join_zones_to_network(zones_fc, net_fc) == []

    def test_multipolygon_zone_is_processed(self):
        """A MultiPolygon zone should produce one result (not be skipped)."""
        # Two separate squares: [0,0]-[1,1] and [3,3]-[4,4]
        square_a = [
            [0.0, 0.0],
            [1.0, 0.0],
            [1.0, 1.0],
            [0.0, 1.0],
            [0.0, 0.0],
        ]
        square_b = [
            [3.0, 3.0],
            [4.0, 3.0],
            [4.0, 4.0],
            [3.0, 4.0],
            [3.0, 3.0],
        ]
        zones_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "MultiPolygon",
                        "coordinates": [[square_a], [square_b]],
                    },
                    "properties": {"zoneId": "multi-zone", "zoneClass": "AREA"},
                }
            ],
            "properties": {"areaId": "area-mp"},
        }
        # Link inside square_a
        link_a = _make_link([[0.2, 0.2], [0.8, 0.8]], link_id="La")
        # Link inside square_b
        link_b = _make_link([[3.2, 3.2], [3.8, 3.8]], link_id="Lb")
        # Link outside both squares
        link_out = _make_link([[5.0, 5.0], [6.0, 6.0]], link_id="Lout")
        net_fc = _make_network_fc([link_a, link_b, link_out])
        results = join_zones_to_network(zones_fc, net_fc)
        assert len(results) == 1
        _, clipped_net, _, _ = results[0]
        clipped_link_ids = {f["properties"]["linkId"] for f in clipped_net["features"]}
        assert link_a["properties"]["linkId"] in clipped_link_ids
        assert link_b["properties"]["linkId"] in clipped_link_ids
        assert link_out["properties"]["linkId"] not in clipped_link_ids

    def test_multipolygon_zone_no_duplicate_links(self):
        """A link inside two overlapping sub-polygons should appear only once."""
        # Two overlapping squares
        square_a = [
            [0.0, 0.0],
            [2.0, 0.0],
            [2.0, 2.0],
            [0.0, 2.0],
            [0.0, 0.0],
        ]
        square_b = [
            [1.0, 0.0],
            [3.0, 0.0],
            [3.0, 2.0],
            [1.0, 2.0],
            [1.0, 0.0],
        ]
        zones_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {
                        "type": "MultiPolygon",
                        "coordinates": [[square_a], [square_b]],
                    },
                    "properties": {"zoneId": "overlap-zone", "zoneClass": "STUDY"},
                }
            ],
            "properties": {"areaId": "area-ov"},
        }
        # Link in the overlap region — should appear only once
        link = _make_link([[1.2, 0.5], [1.8, 1.5]], link_id="Loverlap")
        net_fc = _make_network_fc([link])
        results = join_zones_to_network(zones_fc, net_fc)
        assert len(results) == 1
        _, clipped_net, _, _ = results[0]
        link_id = link["properties"]["linkId"]
        ids_in_output = [f["properties"]["linkId"] for f in clipped_net["features"]]
        assert ids_in_output.count(link_id) == 1

    def test_network_props_are_carried_to_clipped_fc(self):
        link = _make_link([[0.5, 0.5], [0.8, 0.8]])
        zones_fc = _make_zone_fc()
        net_fc = _make_network_fc([link])
        net_fc["properties"]["region"] = "west"
        _, clipped_net, _, _ = join_zones_to_network(zones_fc, net_fc)[0]
        assert clipped_net["properties"]["region"] == "west"


# ===========================================================================
# extend_feedlinks_for_zone
# ===========================================================================


def _make_zone_feature(
    zone_id: str = "z1", gid: int = 1, centroid_lon: float = 0.5, centroid_lat: float = 0.5
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [SQUARE_RING]},
        "properties": {
            "zoneId": zone_id,
            "zoneClass": "AREA",
            "gid": gid,
            "centroidLon": centroid_lon,
            "centroidLat": centroid_lat,
        },
    }


def _make_clipped_link(
    link_id: str, from_node: str, to_node: str, coords: list, flow: float = 100.0
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": coords},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "flow": flow,
        },
    }


def _make_feedlink_feature(fid: int, zone_id: str, from_node: str, to_node: str) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[0.1, 0.1], [0.5, 0.5]]},
        "properties": {
            "feedlinkId": fid,
            "reverseLinkIds": [],
            "zoneId": zone_id,
            "fromNode": from_node,
            "toNode": to_node,
            "length": 10.0,
            "capacity": 50.0,
            "mode": "CAR",
            "ringIndex": -1,
            "ringLabel": "",
            "sectorIndex": -1,
            "type": "feedlink",
        },
    }


class TestExtendFeedlinksForZone:
    def _clipped_fc(self, features: list) -> dict:
        return {"type": "FeatureCollection", "features": features, "properties": {}}

    def _feedlinks_fc(self, features: list) -> dict:
        return {"type": "FeatureCollection", "features": features, "properties": {}}

    # ------------------------------------------------------------------
    # No feedlinks input
    # ------------------------------------------------------------------

    def test_no_input_feedlinks_returns_only_synthetic(self):
        """Boundary node → two synthetic feedlinks, no input feedlinks."""
        link_id = "L1"
        clipped = self._clipped_fc(
            [
                _make_clipped_link(link_id, link_id, "20", [[0.0, 0.0], [0.5, 0.5]], flow=200.0),
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(None, clipped, zone, "CAR")
        assert result["type"] == "FeatureCollection"
        # One boundary node (fromNode == link_id) → 2 synthetic feedlinks
        assert len(result["features"]) == 2

    def test_no_boundary_nodes_no_synthetic(self):
        """Link fully inside zone (no boundary nodes) → empty result if no input feedlinks."""
        clipped = self._clipped_fc(
            [
                _make_clipped_link("L1", "10", "20", [[0.2, 0.2], [0.8, 0.8]], flow=50.0),
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(None, clipped, zone, "CAR")
        assert result["features"] == []

    # ------------------------------------------------------------------
    # Filtering of existing feedlinks
    # ------------------------------------------------------------------

    def test_existing_feedlink_with_node_in_clipped_network_is_kept(self):
        clipped = self._clipped_fc(
            [
                _make_clipped_link("L1", "10", "20", [[0.2, 0.2], [0.8, 0.8]]),
            ]
        )
        feedlinks = self._feedlinks_fc(
            [
                _make_feedlink_feature(1, "z1", "10", "ZONE_NODE"),  # fromNode "10" is in network
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(feedlinks, clipped, zone, "CAR")
        assert any(f["properties"]["feedlinkId"] == 1 for f in result["features"])

    def test_existing_feedlink_with_no_node_in_clipped_network_is_removed(self):
        clipped = self._clipped_fc(
            [
                _make_clipped_link("L1", "10", "20", [[0.2, 0.2], [0.8, 0.8]]),
            ]
        )
        feedlinks = self._feedlinks_fc(
            [
                _make_feedlink_feature(1, "z1", "OUTSIDE_NODE", "ANOTHER_OUTSIDE"),
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(feedlinks, clipped, zone, "CAR")
        assert not any(f["properties"]["feedlinkId"] == 1 for f in result["features"])

    def test_existing_feedlink_via_to_node_is_kept(self):
        clipped = self._clipped_fc(
            [
                _make_clipped_link("L1", "10", "20", [[0.2, 0.2], [0.8, 0.8]]),
            ]
        )
        feedlinks = self._feedlinks_fc(
            [
                _make_feedlink_feature(1, "z1", "OUTSIDE", "20"),  # toNode "20" is in network
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(feedlinks, clipped, zone, "CAR")
        assert any(f["properties"]["feedlinkId"] == 1 for f in result["features"])

    # ------------------------------------------------------------------
    # Synthetic feedlink capacity = flow of clipped link
    # ------------------------------------------------------------------

    def test_synthetic_feedlink_capacity_equals_link_flow(self):
        link_id = "L99"
        flow = 333.0
        clipped = self._clipped_fc(
            [
                _make_clipped_link(link_id, link_id, "20", [[0.0, 0.0], [0.5, 0.5]], flow=flow),
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(None, clipped, zone, "CAR")
        synthetic = result["features"]
        assert all(f["properties"]["capacity"] == flow for f in synthetic)

    def test_synthetic_feedlink_nodes(self):
        """Production: zone_node → boundary_node; Attraction: boundary_node → zone_node."""
        link_id = "L5"
        zone = _make_zone_feature(gid=42)
        clipped = self._clipped_fc(
            [
                _make_clipped_link(link_id, link_id, "20", [[0.0, 0.0], [0.5, 0.5]]),
            ]
        )
        result = extend_feedlinks_for_zone(None, clipped, zone, "CAR")
        feats = result["features"]
        assert len(feats) == 2
        prod = next(f for f in feats if f["properties"]["toNode"] == link_id)
        attr = next(f for f in feats if f["properties"]["fromNode"] == link_id)
        assert prod["properties"]["fromNode"] == "42"  # str(gid)
        assert attr["properties"]["toNode"] == "42"

    def test_synthetic_feedlink_mode_is_set(self):
        link_id = "LM"
        clipped = self._clipped_fc(
            [
                _make_clipped_link(link_id, link_id, "X", [[0.0, 0.0], [0.5, 0.5]]),
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(None, clipped, zone, "BIKE")
        assert all(f["properties"]["mode"] == "BIKE" for f in result["features"])

    def test_synthetic_feedlink_properties_complete(self):
        link_id = "LP"
        clipped = self._clipped_fc(
            [
                _make_clipped_link(link_id, link_id, "N", [[0.0, 0.0], [0.5, 0.5]]),
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(None, clipped, zone, "CAR")
        for feat in result["features"]:
            for key in FEEDLINK_PROPERTIES:
                assert key in feat["properties"], f"Missing property {key!r}"

    def test_two_boundary_nodes_on_same_link_produces_four_feedlinks(self):
        """Link passes fully through zone → both fromNode and toNode are boundary nodes."""
        link_id = "THROUGH"
        clipped = self._clipped_fc(
            [
                _make_clipped_link(link_id, link_id, link_id, [[0.0, 0.0], [0.5, 0.5]]),
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(None, clipped, zone, "CAR")
        assert len(result["features"]) == 4

    def test_feedlink_ids_unique_across_existing_and_synthetic(self):
        link_id = "LU"
        clipped = self._clipped_fc(
            [
                _make_clipped_link(link_id, link_id, "20", [[0.0, 0.0], [0.5, 0.5]]),
            ]
        )
        feedlinks = self._feedlinks_fc(
            [
                _make_feedlink_feature(1, "z1", "20", "ZONE"),
            ]
        )
        zone = _make_zone_feature()
        result = extend_feedlinks_for_zone(feedlinks, clipped, zone, "CAR")
        ids = [f["properties"]["feedlinkId"] for f in result["features"]]
        assert len(ids) == len(set(ids)), "feedlinkIds must be unique"

    # ------------------------------------------------------------------
    # join_zones_to_network returns feedlinks as 4th element
    # ------------------------------------------------------------------

    def test_join_returns_feedlinks_as_fourth_element(self):
        link = _make_link([[0.5, 0.5], [0.8, 0.8]])
        zones_fc = _make_zone_fc()
        net_fc = _make_network_fc([link])
        result = join_zones_to_network(zones_fc, net_fc)
        assert len(result) == 1
        tup = result[0]
        assert len(tup) == 4
        assert tup[3]["type"] == "FeatureCollection"

    def test_join_feedlinks_none_gives_empty_fc(self):
        link = _make_link([[0.5, 0.5], [0.8, 0.8]])
        zones_fc = _make_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, _, fl_fc = join_zones_to_network(zones_fc, net_fc, feedlinks_fc=None)[0]
        assert fl_fc["features"] == []

    def test_join_with_feedlinks_passes_through_filtered(self):
        link = _make_link([[0.5, 0.5], [0.8, 0.8]])
        zones_fc = _make_zone_fc()
        net_fc = _make_network_fc([link])
        existing_fl = {
            "type": "FeatureCollection",
            "features": [_make_feedlink_feature(1, "z1", str(link["properties"]["fromNode"]), "Z")],
            "properties": {},
        }
        _, _, _, fl_fc = join_zones_to_network(
            zones_fc,
            net_fc,
            feedlinks_fc=existing_fl,
        )[0]
        # The feedlink has fromNode matching a network node → should be included
        assert any(f["properties"]["feedlinkId"] == 1 for f in fl_fc["features"])


# ===========================================================================
# _acute_angle_deg
# ===========================================================================


class TestAcuteAngleDeg:
    def test_perpendicular_vectors_give_90(self):
        # (1,0) ⊥ (0,1)
        angle = _acute_angle_deg(1.0, 0.0, 0.0, 1.0)
        assert abs(angle - 90.0) < 1e-9

    def test_parallel_vectors_give_0(self):
        angle = _acute_angle_deg(1.0, 0.0, 1.0, 0.0)
        assert abs(angle - 0.0) < 1e-9

    def test_anti_parallel_vectors_give_0(self):
        angle = _acute_angle_deg(1.0, 0.0, -1.0, 0.0)
        assert abs(angle - 0.0) < 1e-9

    def test_45_degree_angle(self):
        # (1,0) and (1,1) → 45 degrees

        angle = _acute_angle_deg(1.0, 0.0, 1.0, 1.0)
        assert abs(angle - 45.0) < 1e-6

    def test_zero_vector_returns_0(self):
        angle = _acute_angle_deg(0.0, 0.0, 1.0, 0.0)
        assert angle == 0.0

    def test_result_never_exceeds_90(self):
        # Even for obtuse angles between directions, result should be ≤ 90
        angle = _acute_angle_deg(1.0, 0.0, -1.0, -1.0)
        assert 0.0 <= angle <= 90.0


# ===========================================================================
# _intersections_with_ring_extended
# ===========================================================================


class TestIntersectionsWithRingExtended:
    def test_returns_7_tuples(self):
        hits = _intersections_with_ring_extended(-0.5, 0.5, 1.5, 0.5, SQUARE_RING)
        assert len(hits) == 2
        for h in hits:
            assert len(h) == 7

    def test_first_three_fields_match_basic_version(self):
        from gmt_network_core.network_zone_joiner.domain.geometry import _intersections_with_ring

        basic = _intersections_with_ring(-0.5, 0.5, 1.5, 0.5, SQUARE_RING)
        extended = _intersections_with_ring_extended(-0.5, 0.5, 1.5, 0.5, SQUARE_RING)
        assert len(basic) == len(extended)
        for b, e in zip(basic, extended, strict=False):
            assert abs(b[0] - e[0]) < 1e-12
            assert abs(b[1] - e[1]) < 1e-12
            assert abs(b[2] - e[2]) < 1e-12

    def test_boundary_edge_is_returned(self):
        # Crossing the bottom edge (y=0) with segment (0.5, -0.5) → (0.5, 0.5)
        hits = _intersections_with_ring_extended(0.5, -0.5, 0.5, 0.5, SQUARE_RING)
        assert len(hits) == 1
        _t, _ix, _iy, _ex0, ey0, _ex1, ey1 = hits[0]
        # Bottom edge of SQUARE_RING is [0,0]→[1,0]
        assert ey0 == 0.0
        assert ey1 == 0.0


# ===========================================================================
# clip_linestring_to_polygon_angled
# ===========================================================================


class TestClipLinestringToPolygonAngled:
    def test_perpendicular_crossing_is_clipped(self):
        # Horizontal link crosses vertical boundary at 90° → should be clipped
        coords = [[0.5, 0.5], [1.5, 0.5]]  # exits right (x=1) at 90°
        result = clip_linestring_to_polygon_angled(coords, SQUARE_RING, min_angle_deg=2.0)
        assert len(result) == 1
        # Clipped at x=1
        assert abs(result[0][-1][0] - 1.0) < 1e-9

    def test_near_parallel_crossing_is_not_clipped(self):
        # A link running nearly parallel to the top boundary (y=1), just inside.
        # If we make the link slightly diagonal with a very small angle relative
        # to a boundary edge, the crossing should be ignored.
        # We use min_angle_deg=45 to make it easy to trigger.
        # Link: (0.2, 0.5) → (0.8, 0.5) — entirely inside, no crossing → same result
        # For a near-parallel crossing: link goes from inside at (0.1, 0.99)
        # to outside at (0.9, 1.001) — crosses top edge almost horizontally.
        # Top boundary edge is horizontal (y=1), link is also nearly horizontal → small angle.
        coords = [[0.1, 0.99], [0.9, 1.001]]
        # With min_angle_deg=2: angle between link (dx=0.8, dy=0.011) and top edge (dx=1, dy=0)

        dx1, dy1 = 0.9 - 0.1, 1.001 - 0.99  # (0.8, 0.011)
        dx2, dy2 = 1.0, 0.0  # top edge direction
        angle = _acute_angle_deg(dx1, dy1, dx2, dy2)
        assert angle < 2.0  # confirm this is a near-parallel case

        result_strict = clip_linestring_to_polygon_angled(coords, SQUARE_RING, min_angle_deg=2.0)
        result_normal = clip_linestring_to_polygon(coords, SQUARE_RING)

        # With angle check: crossing is skipped → link treated as fully inside
        # Without angle check: link is clipped at the boundary
        assert len(result_normal) >= 1  # normal clip finds the crossing
        # With angle check, the near-parallel crossing is ignored
        # so the full inside portion is returned without clipping at boundary
        assert len(result_strict) >= 1
        # The key difference: the angled result should end at x=0.9 (original end)
        # rather than being clipped at the boundary
        if result_strict and result_normal:
            # If angled version skipped the crossing, the segment extends to end
            # (may still start from boundary at left edge if it enters from outside)
            # At minimum, verify the angled version is at least as long
            angled_len = sum(len(s) for s in result_strict)
            normal_len = sum(len(s) for s in result_normal)
            assert angled_len >= normal_len

    def test_entirely_inside_unchanged(self):
        coords = [[0.2, 0.2], [0.8, 0.8]]
        result = clip_linestring_to_polygon_angled(coords, SQUARE_RING)
        assert len(result) == 1
        assert result[0][0] == [0.2, 0.2]
        assert result[0][-1] == [0.8, 0.8]

    def test_entirely_outside_returns_empty(self):
        coords = [[2.0, 0.0], [3.0, 1.0]]
        result = clip_linestring_to_polygon_angled(coords, SQUARE_RING)
        assert result == []


# ===========================================================================
# _make_circle_ring / _make_boundary_zone
# ===========================================================================


class TestMakeCircleRing:
    def test_ring_is_closed(self):
        ring = _make_circle_ring(5.0, 52.0, radius_m=15.0)
        assert ring[0] == ring[-1]

    def test_ring_has_correct_length(self):
        ring = _make_circle_ring(5.0, 52.0, radius_m=15.0, n_points=16)
        assert len(ring) == 17  # n_points + 1 (closed)

    def test_points_are_near_centre(self):
        lon, lat = 5.0, 52.0
        ring = _make_circle_ring(lon, lat, radius_m=15.0)
        for pt in ring[:-1]:
            dist_lon = abs(pt[0] - lon)
            dist_lat = abs(pt[1] - lat)
            # Both offsets should be very small (< 0.01 degrees)
            assert dist_lon < 0.01
            assert dist_lat < 0.01


class TestMakeBoundaryZone:
    def test_returns_feature(self):
        feat = _make_boundary_zone("L1", 5.0, 52.0, production=100.0, attraction=50.0)
        assert feat["type"] == "Feature"
        assert feat["geometry"]["type"] == "Polygon"

    def test_properties_set(self):
        feat = _make_boundary_zone("L1", 5.0, 52.0, production=100.0, attraction=50.0)
        props = feat["properties"]
        assert props["zoneId"] == "L1"
        assert props["zoneClass"] == "BOUNDARY"
        assert props["centroidLon"] == 5.0
        assert props["centroidLat"] == 52.0
        assert props["production"] == 100.0
        assert props["attraction"] == 50.0

    def test_ring_is_closed_polygon(self):
        feat = _make_boundary_zone("X", 5.0, 52.0)
        ring = feat["geometry"]["coordinates"][0]
        assert ring[0] == ring[-1]


# ===========================================================================
# _collect_boundary_node_info
# ===========================================================================


class TestCollectBoundaryNodeInfo:
    def _make_clipped(self, link_id, from_node, to_node, coords, flow=100.0, speed=100.0):
        return {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": coords},
            "properties": {
                "linkId": link_id,
                "fromNode": from_node,
                "toNode": to_node,
                "flow": flow,
                "speed": speed,
            },
        }

    def test_exit_link_gives_attraction(self):
        # toNode == linkId → exits the area → attraction
        feat = self._make_clipped("L1", "10", "L1", [[0.1, 0.1], [1.0, 0.5]], flow=200.0)
        info = _collect_boundary_node_info([feat], [feat], boundary_node_ids={"L1"})
        assert "L1" in info
        assert info["L1"]["attraction"] == 200.0
        assert info["L1"]["production"] == 0.0

    def test_entry_link_gives_production(self):
        # fromNode == linkId → enters the area → production
        feat = self._make_clipped("L2", "L2", "20", [[0.0, 0.5], [0.5, 0.5]], flow=150.0)
        info = _collect_boundary_node_info([feat], [feat], boundary_node_ids={"L2"})
        assert "L2" in info
        assert info["L2"]["production"] == 150.0
        assert info["L2"]["attraction"] == 0.0

    def test_interior_link_not_in_result(self):
        # Neither node is in boundary_node_ids → not a boundary node
        feat = self._make_clipped("L3", "10", "20", [[0.2, 0.2], [0.8, 0.8]])
        info = _collect_boundary_node_info([feat], [feat], boundary_node_ids=set())
        assert info == {}

    def test_multiple_links_accumulate(self):
        exit1 = self._make_clipped("LA", "10", "LA", [[0.5, 0.5], [1.0, 0.5]], flow=100.0)
        exit2 = self._make_clipped("LA", "20", "LA", [[0.5, 0.3], [1.0, 0.5]], flow=50.0)
        # Both exit at same node ID "LA"
        info = _collect_boundary_node_info([exit1, exit2], [exit1, exit2], boundary_node_ids={"LA"})
        assert info["LA"]["attraction"] == 150.0

    def test_slow_crossing_dropped_by_default(self):
        # Speed below the default 50 km/h candidate floor → no boundary node at all
        feat = self._make_clipped(
            "L4", "10", "L4", [[0.1, 0.1], [1.0, 0.5]], flow=200.0, speed=40.0
        )
        info = _collect_boundary_node_info([feat], [feat], boundary_node_ids={"L4"})
        assert info == {}

    def test_missing_speed_treated_as_disqualifying(self):
        feat = self._make_clipped(
            "L5", "10", "L5", [[0.1, 0.1], [1.0, 0.5]], flow=200.0, speed=None
        )
        del feat["properties"]["speed"]
        info = _collect_boundary_node_info([feat], [feat], boundary_node_ids={"L5"})
        assert info == {}

    def test_crossing_at_exactly_threshold_qualifies(self):
        feat = self._make_clipped(
            "L6", "10", "L6", [[0.1, 0.1], [1.0, 0.5]], flow=200.0, speed=50.0
        )
        info = _collect_boundary_node_info([feat], [feat], boundary_node_ids={"L6"})
        assert "L6" in info

    def test_custom_threshold_allows_slower_crossing(self):
        feat = self._make_clipped(
            "L7", "10", "L7", [[0.1, 0.1], [1.0, 0.5]], flow=200.0, speed=30.0
        )
        info = _collect_boundary_node_info(
            [feat], [feat], boundary_node_ids={"L7"}, min_speed_kph=30.0
        )
        assert "L7" in info

    def test_records_speed_and_role(self):
        feat = self._make_clipped("L8", "L8", "20", [[0.0, 0.5], [0.5, 0.5]], speed=70.0)
        info = _collect_boundary_node_info([feat], [feat], boundary_node_ids={"L8"})
        assert info["L8"]["speed"] == 70.0
        assert info["L8"]["isEntry"] is True
        assert info["L8"]["isExit"] is False


# ===========================================================================
# _group_boundary_nodes / _select_boundary_groups
# ===========================================================================

# ~10 m apart in longitude at 52 °N.
_LON_10M = 10.0 / (111_320.0 * math.cos(math.radians(52.0)))


def _node(lon, lat, *, entry=False, exit_=False, prod=0.0, attr=0.0, speed=80.0, mode="CAR"):
    return {
        "lon": lon,
        "lat": lat,
        "production": prod,
        "attraction": attr,
        "mode": mode,
        "speed": speed,
        "isEntry": entry,
        "isExit": exit_,
    }


def _group(zone_id, speed, flow=0.0):
    return {"zoneId": zone_id, "speed": speed, "production": flow, "attraction": 0.0}


class TestGroupBoundaryNodes:
    def test_close_entry_and_exit_are_combined(self):
        nodes = {
            "IN": _node(5.0, 52.0, entry=True, prod=100.0),
            "OUT": _node(5.0 + _LON_10M, 52.0, exit_=True, attr=80.0),
        }
        groups = _group_boundary_nodes(nodes, merge_dist_m=30.0)
        assert len(groups) == 1
        g = groups[0]
        assert g["zoneId"] == "IN+OUT"
        assert g["production"] == 100.0
        assert g["attraction"] == 80.0
        assert g["entryNodeIds"] == {"IN"}
        assert g["exitNodeIds"] == {"OUT"}
        assert g["entryNode"][0] == "IN"
        assert g["exitNode"][0] == "OUT"

    def test_far_apart_nodes_stay_separate(self):
        nodes = {
            "IN": _node(5.0, 52.0, entry=True),
            "OUT": _node(5.0 + 10 * _LON_10M, 52.0, exit_=True),
        }
        groups = _group_boundary_nodes(nodes, merge_dist_m=30.0)
        assert sorted(g["zoneId"] for g in groups) == ["IN", "OUT"]

    def test_two_entries_are_not_combined(self):
        nodes = {
            "A": _node(5.0, 52.0, entry=True),
            "B": _node(5.0 + _LON_10M, 52.0, entry=True),
        }
        groups = _group_boundary_nodes(nodes, merge_dist_m=30.0)
        assert len(groups) == 2

    def test_different_modes_are_not_combined(self):
        nodes = {
            "IN": _node(5.0, 52.0, entry=True, mode="CAR"),
            "OUT": _node(5.0 + _LON_10M, 52.0, exit_=True, mode="BIKE"),
        }
        assert len(_group_boundary_nodes(nodes, merge_dist_m=30.0)) == 2

    def test_closest_pair_wins(self):
        nodes = {
            "IN": _node(5.0, 52.0, entry=True),
            "OUT_NEAR": _node(5.0 + _LON_10M, 52.0, exit_=True),
            "OUT_FAR": _node(5.0 - 2 * _LON_10M, 52.0, exit_=True),
        }
        ids = sorted(g["zoneId"] for g in _group_boundary_nodes(nodes, merge_dist_m=30.0))
        assert ids == ["IN+OUT_NEAR", "OUT_FAR"]

    def test_merge_disabled_with_zero_distance(self):
        nodes = {
            "IN": _node(5.0, 52.0, entry=True),
            "OUT": _node(5.0 + _LON_10M, 52.0, exit_=True),
        }
        assert len(_group_boundary_nodes(nodes, merge_dist_m=0.0)) == 2

    def test_combined_speed_is_max(self):
        nodes = {
            "IN": _node(5.0, 52.0, entry=True, speed=50.0),
            "OUT": _node(5.0 + _LON_10M, 52.0, exit_=True, speed=60.0),
        }
        assert _group_boundary_nodes(nodes)[0]["speed"] == 60.0


class TestSelectBoundaryGroups:
    def test_all_major_roads_selected_even_beyond_minimum(self):
        groups = [_group(f"M{i:02d}", 80.0) for i in range(12)]
        groups.append(_group("S", 50.0, flow=1000.0))
        selected = _select_boundary_groups(groups, major_speed_kph=50.0, min_boundary_zones=10)
        ids = [g["zoneId"] for g in selected]
        assert len(ids) == 12
        assert "S" not in ids

    def test_tops_up_with_highest_flow_50_kph_roads(self):
        groups = [_group(f"M{i}", 70.0) for i in range(3)]
        groups += [_group(f"S{i}", 50.0, flow=float(i)) for i in range(10)]
        selected = _select_boundary_groups(groups, major_speed_kph=50.0, min_boundary_zones=5)
        ids = {g["zoneId"] for g in selected}
        assert ids == {"M0", "M1", "M2", "S9", "S8"}

    def test_fewer_candidates_than_minimum_selects_all(self):
        groups = [_group("M", 80.0), _group("S", 50.0)]
        selected = _select_boundary_groups(groups, major_speed_kph=50.0, min_boundary_zones=10)
        assert [g["zoneId"] for g in selected] == ["M", "S"]

    def test_ties_broken_by_zone_id(self):
        groups = [_group("S_b", 50.0, 5.0), _group("S_a", 50.0, 5.0)]
        selected = _select_boundary_groups(groups, major_speed_kph=50.0, min_boundary_zones=1)
        assert [g["zoneId"] for g in selected] == ["S_a"]

    def test_preserves_input_order(self):
        groups = [_group("S1", 50.0, 1.0), _group("M", 80.0), _group("S2", 50.0, 9.0)]
        selected = _select_boundary_groups(groups, major_speed_kph=50.0, min_boundary_zones=3)
        assert [g["zoneId"] for g in selected] == ["S1", "M", "S2"]


# ===========================================================================
# join_zones_to_network — AREA zone produces boundary mini-zones
# ===========================================================================


def _make_area_zone_fc(zone_id: str = "area1") -> dict:
    return {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Polygon", "coordinates": [SQUARE_RING]},
                "properties": {"zoneId": zone_id, "zoneClass": "AREA"},
            }
        ],
        "properties": {"areaId": "test-area"},
    }


class TestJoinZonesToNetworkAreaBoundaryZones:
    def test_area_zone_fc_has_area_feature_plus_mini_zones(self):
        # Link exits the SQUARE_RING zone on the right (x=1)
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        link["properties"]["flow"] = 100.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc)[0]

        # zone_fc should contain only the boundary mini-zone (AREA is excluded)
        assert len(zone_fc["features"]) == 1
        zone_classes = [f["properties"]["zoneClass"] for f in zone_fc["features"]]
        assert "AREA" not in zone_classes
        assert "BOUNDARY" in zone_classes

    def test_boundary_mini_zone_has_correct_properties(self):
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L99", from_node=10, to_node=20)
        link["properties"]["flow"] = 250.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc)[0]

        boundary = next(
            f for f in zone_fc["features"] if f["properties"]["zoneClass"] == "BOUNDARY"
        )
        props = boundary["properties"]
        # toNode == linkId → exits the area → attraction
        assert props["zoneId"] == "L99"
        assert props["attraction"] == 250.0
        assert props["production"] == 0.0
        assert boundary["geometry"]["type"] == "Polygon"

    def test_non_area_zone_fc_has_only_one_feature(self):
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        link["properties"]["flow"] = 100.0
        zones_fc = _make_zone_fc("z1", "STUDY")
        net_fc = _make_network_fc([link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc)[0]
        # STUDY zone: no mini-zones
        assert len(zone_fc["features"]) == 1

    def test_entry_link_gives_production_on_boundary_zone(self):
        # Link from outside enters the zone: fromNode → boundary
        link = _make_link([[-0.5, 0.5], [0.5, 0.5]], link_id="L5", from_node=10, to_node=20)
        link["properties"]["flow"] = 180.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc)[0]

        boundary = next(
            f for f in zone_fc["features"] if f["properties"]["zoneClass"] == "BOUNDARY"
        )
        # fromNode == linkId → enters the area → production
        assert boundary["properties"]["production"] == 180.0
        assert boundary["properties"]["attraction"] == 0.0

    def test_no_boundary_crossings_gives_empty_zone_fc(self):
        # Link fully inside — no boundary nodes, no mini-zones, AREA excluded
        link = _make_link([[0.2, 0.2], [0.8, 0.8]], link_id="L0", from_node=10, to_node=20)
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc)[0]
        assert len(zone_fc["features"]) == 0

    def test_area_zone_fc_includes_study_influence_and_mini_zones_not_area(self):
        """AREA zone output must include STUDY + INFLUENCE zones and boundary
        mini-zones, but NOT the AREA zone itself."""
        study_ring = [[0.1, 0.1], [0.4, 0.1], [0.4, 0.4], [0.1, 0.4], [0.1, 0.1]]
        influence_ring = [[0.5, 0.5], [0.9, 0.5], [0.9, 0.9], [0.5, 0.9], [0.5, 0.5]]
        zones_fc_multi = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": [study_ring]},
                    "properties": {
                        "zoneId": "study-1",
                        "zoneClass": "STUDY",
                        "centroidLon": 0.25,
                        "centroidLat": 0.25,
                    },
                },
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": [influence_ring]},
                    "properties": {
                        "zoneId": "inf-1",
                        "zoneClass": "INFLUENCE",
                        "centroidLon": 0.7,
                        "centroidLat": 0.7,
                    },
                },
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": [SQUARE_RING]},
                    "properties": {"zoneId": "area-1", "zoneClass": "AREA"},
                },
            ],
            "properties": {"areaId": "test-area"},
        }
        # Link exits the AREA zone on the right → 1 boundary mini-zone
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        link["properties"]["flow"] = 100.0
        net_fc = _make_network_fc([link])

        results = join_zones_to_network(zones_fc_multi, net_fc, zone_classes={"AREA"})
        assert len(results) == 1
        _, _, zone_fc, _ = results[0]

        zone_classes_in_output = [f["properties"]["zoneClass"] for f in zone_fc["features"]]
        # Must contain STUDY, INFLUENCE and BOUNDARY — but NOT AREA
        assert "STUDY" in zone_classes_in_output
        assert "INFLUENCE" in zone_classes_in_output
        assert "BOUNDARY" in zone_classes_in_output
        assert "AREA" not in zone_classes_in_output
        # Total: 2 non-AREA original zones + 1 boundary mini-zone
        assert len(zone_fc["features"]) == 3

        # Original geometries must be preserved (not replaced by tiny circles)
        study_feat = next(f for f in zone_fc["features"] if f["properties"]["zoneClass"] == "STUDY")
        assert study_feat["geometry"]["type"] == "Polygon"
        assert study_feat["geometry"]["coordinates"] == [study_ring]

    def test_slow_crossing_produces_no_boundary_zone(self):
        # Link exits the AREA zone, but below the default 50 km/h threshold
        link = _make_link(
            [[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20, speed=40.0
        )
        link["properties"]["flow"] = 100.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc)[0]

        assert zone_fc["features"] == []

    def test_missing_speed_crossing_produces_no_boundary_zone(self):
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        del link["properties"]["speed"]
        link["properties"]["flow"] = 100.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc)[0]

        assert zone_fc["features"] == []

    def test_only_fast_crossing_of_mix_produces_boundary_zone(self):
        fast_link = _make_link(
            [[0.5, 0.5], [1.5, 0.5]], link_id="FAST", from_node=10, to_node=20, speed=100.0
        )
        fast_link["properties"]["flow"] = 100.0
        slow_link = _make_link(
            [[0.5, 0.7], [1.5, 0.7]], link_id="SLOW", from_node=11, to_node=21, speed=30.0
        )
        slow_link["properties"]["flow"] = 100.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([fast_link, slow_link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc)[0]

        boundary_ids = [
            f["properties"]["zoneId"]
            for f in zone_fc["features"]
            if f["properties"]["zoneClass"] == "BOUNDARY"
        ]
        assert boundary_ids == ["FAST"]

    def test_custom_major_boundary_speed_kph_allows_slower_crossing(self):
        link = _make_link(
            [[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20, speed=30.0
        )
        link["properties"]["flow"] = 100.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, zone_fc, _ = join_zones_to_network(zones_fc, net_fc, major_boundary_speed_kph=30.0)[0]

        zone_classes = [f["properties"]["zoneClass"] for f in zone_fc["features"]]
        assert "BOUNDARY" in zone_classes

    @staticmethod
    def _exit_links(prefix: str, n: int, speed: float, y0: float) -> list[dict]:
        """*n* parallel exit links (crossing x=1), far enough apart not to merge."""
        links = []
        for i in range(n):
            y = y0 + i * 0.01
            link = _make_link(
                [[0.5, y], [1.5, y]],
                link_id=f"{prefix}{i}",
                from_node=100 + i,
                to_node=200 + i,
                speed=speed,
            )
            link["properties"]["flow"] = float(i + 1)
            links.append(link)
        return links

    def _boundary_ids(self, links: list[dict], **kwargs) -> set[str]:
        _, _, zone_fc, _ = join_zones_to_network(
            _make_area_zone_fc(), _make_network_fc(links), **kwargs
        )[0]
        return {
            f["properties"]["zoneId"]
            for f in zone_fc["features"]
            if f["properties"]["zoneClass"] == "BOUNDARY"
        }

    def test_50_kph_crossing_fills_up_when_few_major_roads(self):
        link = _make_link(
            [[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20, speed=50.0
        )
        assert self._boundary_ids([link]) == {"L1"}

    def test_tops_up_to_min_boundary_zones_with_highest_flow(self):
        major = self._exit_links("M", 3, speed=60.0, y0=0.1)
        minor = self._exit_links("S", 10, speed=50.0, y0=0.5)
        ids = self._boundary_ids(major + minor, min_boundary_zones=5)
        # 3 major + the 2 highest-flow 50 km/h roads (S9 flow=10, S8 flow=9)
        assert ids == {"M0", "M1", "M2", "S9", "S8"}

    def test_no_top_up_when_enough_major_roads(self):
        major = self._exit_links("M", 10, speed=60.0, y0=0.1)
        minor = self._exit_links("S", 3, speed=50.0, y0=0.5)
        ids = self._boundary_ids(major + minor, min_boundary_zones=10)
        assert ids == {f"M{i}" for i in range(10)}

    def test_two_way_road_gives_one_combined_zone(self):
        # Two directions of one road, ~10 m apart around (lon 5, lat 52).
        ring = [[4.9, 51.9], [5.0, 51.9], [5.0, 52.1], [4.9, 52.1], [4.9, 51.9]]
        dy = 10.0 / 111_320.0
        link_out = _make_link(
            [[4.99, 52.0], [5.01, 52.0]], link_id="OUT", from_node=1, to_node=2, speed=80.0
        )
        link_out["properties"]["flow"] = 300.0
        link_in = _make_link(
            [[5.01, 52.0 + dy], [4.99, 52.0 + dy]],
            link_id="IN",
            from_node=3,
            to_node=4,
            speed=80.0,
        )
        link_in["properties"]["flow"] = 200.0
        zones_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": [ring]},
                    "properties": {"zoneId": "area", "zoneClass": "AREA"},
                }
            ],
        }
        _, _, zone_fc, feedlinks_fc = join_zones_to_network(
            zones_fc, _make_network_fc([link_out, link_in])
        )[0]

        boundary = [f for f in zone_fc["features"] if f["properties"]["zoneClass"] == "BOUNDARY"]
        assert len(boundary) == 1
        props = boundary[0]["properties"]
        assert props["zoneId"] == "IN+OUT"
        assert props["production"] == 200.0
        assert props["attraction"] == 300.0
        assert props["nodeIds"] == ["IN", "OUT"]
        assert props["fromNodeProportions"] == {"IN": 1.0}
        assert props["toNodeProportions"] == {"OUT": 1.0}

        fl = [
            f["properties"]
            for f in feedlinks_fc["features"]
            if f["properties"]["zoneId"] == "IN+OUT"
        ]
        prod = next(p for p in fl if p["fromNode"] == "IN+OUT")
        attr = next(p for p in fl if p["toNode"] == "IN+OUT")
        assert prod["toNode"] == "IN"
        assert prod["capacity"] == 200.0
        assert attr["fromNode"] == "OUT"
        assert attr["capacity"] == 300.0
        assert 0.0 < prod["length"] < 30.0

    def test_two_way_merge_can_be_disabled(self):
        ring = [[4.9, 51.9], [5.0, 51.9], [5.0, 52.1], [4.9, 52.1], [4.9, 51.9]]
        dy = 10.0 / 111_320.0
        link_out = _make_link([[4.99, 52.0], [5.01, 52.0]], link_id="OUT", from_node=1, to_node=2)
        link_in = _make_link(
            [[5.01, 52.0 + dy], [4.99, 52.0 + dy]], link_id="IN", from_node=3, to_node=4
        )
        zones_fc = {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": [ring]},
                    "properties": {"zoneId": "area", "zoneClass": "AREA"},
                }
            ],
        }
        _, _, zone_fc, _ = join_zones_to_network(
            zones_fc, _make_network_fc([link_out, link_in]), two_way_merge_dist_m=0.0
        )[0]
        ids = {f["properties"]["zoneId"] for f in zone_fc["features"]}
        assert ids == {"IN", "OUT"}


# ===========================================================================
# _clip_network_to_rings
# ===========================================================================


class TestClipNetworkToRings:
    def test_single_link_crossing_boundary(self):
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        clipped, bids = _clip_network_to_rings([link], [SQUARE_RING])
        assert len(clipped) == 1
        assert "L1" in bids

    def test_link_fully_inside_no_boundary_nodes(self):
        link = _make_link([[0.2, 0.2], [0.8, 0.8]], link_id="L1", from_node=10, to_node=20)
        clipped, bids = _clip_network_to_rings([link], [SQUARE_RING])
        assert len(clipped) == 1
        assert bids == set()

    def test_link_fully_outside_excluded(self):
        link = _make_link([[2.0, 2.0], [3.0, 3.0]], link_id="L1")
        clipped, bids = _clip_network_to_rings([link], [SQUARE_RING])
        assert clipped == []
        assert bids == set()

    def test_dedup_across_overlapping_rings(self):
        """A link inside two overlapping rings must only be clipped once."""
        ring_a = [[0.0, 0.0], [2.0, 0.0], [2.0, 2.0], [0.0, 2.0], [0.0, 0.0]]
        ring_b = [[1.0, 0.0], [3.0, 0.0], [3.0, 2.0], [1.0, 2.0], [1.0, 0.0]]
        link = _make_link([[1.2, 0.5], [1.8, 1.5]], link_id="Lov")
        clipped, _bids = _clip_network_to_rings([link], [ring_a, ring_b])
        assert len(clipped) == 1

    def test_empty_links_returns_empty(self):
        clipped, bids = _clip_network_to_rings([], [SQUARE_RING])
        assert clipped == []
        assert bids == set()


# ===========================================================================
# compute_network_boundary_node_roles
# ===========================================================================


class TestComputeNetworkBoundaryNodeRoles:
    def _area_zone_feature(self, zone_id: str = "area1") -> dict:
        return {
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [SQUARE_RING]},
            "properties": {"zoneId": zone_id, "zoneClass": "AREA"},
        }

    def test_entry_link_populates_entry_set(self):
        # Link enters the area from outside: fromNode becomes the boundary node.
        link = _make_link([[-0.5, 0.5], [0.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        net_fc = _make_network_fc([link])
        entry_ids, exit_ids = compute_network_boundary_node_roles(self._area_zone_feature(), net_fc)
        assert "L1" in entry_ids
        assert exit_ids == set()

    def test_exit_link_populates_exit_set(self):
        # Link exits the area: toNode becomes the boundary node.
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L2", from_node=10, to_node=20)
        net_fc = _make_network_fc([link])
        entry_ids, exit_ids = compute_network_boundary_node_roles(self._area_zone_feature(), net_fc)
        assert "L2" in exit_ids
        assert entry_ids == set()

    def test_link_fully_inside_gives_empty_sets(self):
        link = _make_link([[0.2, 0.2], [0.8, 0.8]], link_id="L3", from_node=10, to_node=20)
        net_fc = _make_network_fc([link])
        entry_ids, exit_ids = compute_network_boundary_node_roles(self._area_zone_feature(), net_fc)
        assert entry_ids == set()
        assert exit_ids == set()

    def test_major_boundary_speed_kph_filters_slow_crossing(self):
        link = _make_link(
            [[0.5, 0.5], [1.5, 0.5]], link_id="L4", from_node=10, to_node=20, speed=40.0
        )
        net_fc = _make_network_fc([link])
        entry_ids, exit_ids = compute_network_boundary_node_roles(self._area_zone_feature(), net_fc)
        assert entry_ids == set()
        assert exit_ids == set()

        _entry_ids2, exit_ids2 = compute_network_boundary_node_roles(
            self._area_zone_feature(), net_fc, major_boundary_speed_kph=40.0
        )
        assert "L4" in exit_ids2

    def test_matches_top_up_selection(self):
        links = []
        for i, speed in enumerate([60.0, 50.0, 50.0]):
            y = 0.1 + i * 0.1
            link = _make_link(
                [[0.5, y], [1.5, y]],
                link_id=f"L{i}",
                from_node=10 + i,
                to_node=20 + i,
                speed=speed,
            )
            link["properties"]["flow"] = float(i)
            links.append(link)
        _entry, exit_ids = compute_network_boundary_node_roles(
            self._area_zone_feature(), _make_network_fc(links), min_boundary_zones=2
        )
        # L0 is major; L2 (flow 2) beats L1 (flow 1) for the single top-up slot.
        assert exit_ids == {"L0", "L2"}

    def test_non_polygon_zone_returns_empty_sets(self):
        zone = {
            "type": "Feature",
            "geometry": {"type": "Point", "coordinates": [0.5, 0.5]},
            "properties": {"zoneId": "p1", "zoneClass": "AREA"},
        }
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L5")
        net_fc = _make_network_fc([link])
        entry_ids, exit_ids = compute_network_boundary_node_roles(zone, net_fc)
        assert entry_ids == set()
        assert exit_ids == set()

    def test_no_crossings_returns_empty_sets(self):
        link = _make_link([[2.0, 2.0], [3.0, 3.0]], link_id="L6")
        net_fc = _make_network_fc([link])
        entry_ids, exit_ids = compute_network_boundary_node_roles(self._area_zone_feature(), net_fc)
        assert entry_ids == set()
        assert exit_ids == set()

    def test_node_can_appear_in_both_sets(self):
        """A node crossed by two different links in opposite directions is
        both an entry and an exit candidate."""
        link_in = _make_link([[-0.5, 0.5], [0.5, 0.5]], link_id="DUAL", from_node=10, to_node=20)
        link_out = _make_link([[0.5, 0.7], [1.5, 0.7]], link_id="DUAL", from_node=11, to_node=21)
        net_fc = _make_network_fc([link_in, link_out])
        entry_ids, exit_ids = compute_network_boundary_node_roles(self._area_zone_feature(), net_fc)
        assert "DUAL" in entry_ids
        assert "DUAL" in exit_ids


# ===========================================================================
# ===========================================================================
# Regression: AREA zone feedlinks must not originate from (0, 0)
# ===========================================================================


class TestAreaZoneFeedlinksNotFromOrigin:
    def test_area_zone_feedlinks_are_zero_length_at_boundary_node(self):
        """Boundary mini-zone feedlinks must be zero-length self-connections at
        the boundary node — NOT lines from the AREA zone centroid (which would
        default to (0, 0) since AREA zones carry no centroidLon/Lat property)."""
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        link["properties"]["flow"] = 100.0
        zones_fc = _make_area_zone_fc()  # zoneClass=AREA, no centroid props
        net_fc = _make_network_fc([link])

        _, _, _, feedlinks_fc = join_zones_to_network(zones_fc, net_fc)[0]

        features = feedlinks_fc.get("features") or []
        assert features, "Expected at least one feedlink for the boundary mini-zone"

        for feat in features:
            coords = (feat.get("geometry") or {}).get("coordinates") or []
            for pt in coords:
                assert not (pt[0] == 0.0 and pt[1] == 0.0), (
                    f"Feedlink coordinate is (0, 0) — synthetic centroid feedlinks "
                    f"must not be created for AREA zones: {feat}"
                )

        # All feedlinks must be zero-length (fromNode == toNode, same position)
        for feat in features:
            coords = (feat.get("geometry") or {}).get("coordinates") or []
            if len(coords) == 2:
                assert coords[0] == coords[1], (
                    f"AREA boundary feedlink must be zero-length (self-connection): {feat}"
                )


# ===========================================================================
# _make_boundary_mini_zone_feedlinks
# ===========================================================================


def _make_boundary_zone_feat(
    zone_id: str, lon: float, lat: float, production: float = 0.0, attraction: float = 0.0
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [[]]},
        "properties": {
            "zoneId": zone_id,
            "zoneClass": "BOUNDARY",
            "centroidLon": lon,
            "centroidLat": lat,
            "production": production,
            "attraction": attraction,
        },
    }


class TestMakeBoundaryMiniZoneFeedlinks:
    def test_produces_two_feedlinks_per_mini_zone(self):
        bz = _make_boundary_zone_feat("L1", 5.0, 52.0, production=100.0, attraction=50.0)
        result = _make_boundary_mini_zone_feedlinks([bz], "CAR", start_fid=1)
        assert len(result) == 2

    def test_feedlinks_have_all_required_properties(self):
        bz = _make_boundary_zone_feat("L1", 5.0, 52.0, production=100.0)
        result = _make_boundary_mini_zone_feedlinks([bz], "CAR", start_fid=1)
        for feat in result:
            for key in FEEDLINK_PROPERTIES:
                assert key in feat["properties"], f"Missing property {key!r}"

    def test_production_feedlink_capacity_equals_production(self):
        bz = _make_boundary_zone_feat("L1", 5.0, 52.0, production=200.0, attraction=80.0)
        result = _make_boundary_mini_zone_feedlinks([bz], "CAR", start_fid=1)
        capacities = {f["properties"]["capacity"] for f in result}
        assert 200.0 in capacities
        assert 80.0 in capacities

    def test_feedlinks_have_zone_id_as_from_and_to_node(self):
        bz = _make_boundary_zone_feat("L99", 5.0, 52.0)
        result = _make_boundary_mini_zone_feedlinks([bz], "CAR")
        for feat in result:
            assert feat["properties"]["fromNode"] == "L99"
            assert feat["properties"]["toNode"] == "L99"

    def test_feedlinks_have_zero_length(self):
        bz = _make_boundary_zone_feat("L1", 5.0, 52.0)
        result = _make_boundary_mini_zone_feedlinks([bz], "CAR")
        for feat in result:
            assert feat["properties"]["length"] == 0.0

    def test_feedlink_ids_are_sequential_and_unique(self):
        bz1 = _make_boundary_zone_feat("L1", 5.0, 52.0)
        bz2 = _make_boundary_zone_feat("L2", 5.1, 52.1)
        result = _make_boundary_mini_zone_feedlinks([bz1, bz2], "CAR", start_fid=10)
        ids = [f["properties"]["feedlinkId"] for f in result]
        assert len(ids) == 4
        assert len(set(ids)) == 4  # all unique

    def test_reverse_link_ids_cross_reference(self):
        bz = _make_boundary_zone_feat("L1", 5.0, 52.0)
        result = _make_boundary_mini_zone_feedlinks([bz], "CAR", start_fid=1)
        prod = next(f for f in result if f["properties"]["feedlinkId"] == 1)
        attr = next(f for f in result if f["properties"]["feedlinkId"] == 2)
        assert prod["properties"]["reverseLinkIds"] == [2]
        assert attr["properties"]["reverseLinkIds"] == [1]

    def test_mode_is_set(self):
        bz = _make_boundary_zone_feat("L1", 5.0, 52.0)
        result = _make_boundary_mini_zone_feedlinks([bz], "BIKE")
        assert all(f["properties"]["mode"] == "BIKE" for f in result)

    def test_empty_input_returns_empty_list(self):
        result = _make_boundary_mini_zone_feedlinks([], "CAR")
        assert result == []


# ===========================================================================
# join_zones_to_network — AREA zone feedlinks include boundary mini-zone connectors
# ===========================================================================


class TestJoinZonesToNetworkAreaFeedlinks:
    def test_feedlinks_include_boundary_mini_zone_connectors(self):
        # One exit link → 1 boundary node → 2 mini-zone feedlinks
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        link["properties"]["flow"] = 100.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, _, fl_fc = join_zones_to_network(zones_fc, net_fc)[0]

        boundary_feedlinks = [
            f
            for f in fl_fc["features"]
            if f["properties"].get("zoneClass") == "BOUNDARY"
            or f["properties"].get("fromNode") == "L1"
        ]
        # At minimum, 2 boundary mini-zone feedlinks should exist (production + attraction)
        assert len(boundary_feedlinks) >= 2

    def test_feedlinks_fc_has_unique_ids_across_all_types(self):
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        link["properties"]["flow"] = 100.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, _, fl_fc = join_zones_to_network(zones_fc, net_fc)[0]
        ids = [f["properties"]["feedlinkId"] for f in fl_fc["features"]]
        assert len(ids) == len(set(ids)), "feedlinkIds must be unique across all feedlinks"

    def test_boundary_mini_zone_feedlinks_have_zero_length(self):
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="LZ", from_node=10, to_node=20)
        link["properties"]["flow"] = 50.0
        zones_fc = _make_area_zone_fc()
        net_fc = _make_network_fc([link])
        _, _, _, fl_fc = join_zones_to_network(zones_fc, net_fc)[0]

        # Mini-zone feedlinks: fromNode == toNode == linkId
        mini_feedlinks = [
            f
            for f in fl_fc["features"]
            if f["properties"].get("fromNode") == "LZ" and f["properties"].get("toNode") == "LZ"
        ]
        assert len(mini_feedlinks) == 2
        for fl in mini_feedlinks:
            assert fl["properties"]["length"] == 0.0

    def test_non_area_zone_has_no_boundary_mini_zone_feedlinks(self):
        link = _make_link([[0.5, 0.5], [1.5, 0.5]], link_id="L1", from_node=10, to_node=20)
        link["properties"]["flow"] = 100.0
        zones_fc = _make_zone_fc("z1", "STUDY")
        net_fc = _make_network_fc([link])
        _, _, _, fl_fc = join_zones_to_network(zones_fc, net_fc)[0]

        # STUDY zone: no mini-zone feedlinks (fromNode == toNode == linkId is the boundary
        # synthetic feedlink pattern but those use AREA zone centroid, not self-loops)
        self_loops = [
            f
            for f in fl_fc["features"]
            if f["properties"].get("fromNode") == f["properties"].get("toNode")
        ]
        assert self_loops == []


# ===========================================================================
# _ring_signed_area and _buffer_ring
# ===========================================================================

# A unit square with known winding.  In GeoJSON lon/lat convention the shoelace
# formula using our implementation yields a *negative* value for CW rings and
# *positive* for CCW.
_SQUARE_CCW = [[0.0, 0.0], [0.0, 1.0], [1.0, 1.0], [1.0, 0.0], [0.0, 0.0]]
_SQUARE_CW = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.0, 0.0]]


class TestRingSignedArea:
    def test_ccw_positive(self):
        assert _ring_signed_area(_SQUARE_CCW) > 0

    def test_cw_negative(self):
        assert _ring_signed_area(_SQUARE_CW) < 0

    def test_degenerate_collinear_zero(self):
        line = [[0.0, 0.0], [1.0, 0.0], [2.0, 0.0], [0.0, 0.0]]
        assert abs(_ring_signed_area(line)) < 1e-12


class TestBufferRing:
    """Verify that _buffer_ring expands a polygon outward by buffer_m metres."""

    # Approximate metres-per-degree at 52 °N (must match implementation constants).
    _M_LAT = 111_320.0
    _M_LON = 68_583.0  # 111320 * cos(52°)

    def _ring_area_deg2(self, ring: list) -> float:
        """Return the absolute area of a ring in squared degrees."""
        area: float = abs(_ring_signed_area(ring))
        return area

    def test_buffer_expands_polygon(self):
        """Buffering should produce a strictly larger polygon."""
        ring = _SQUARE_CW
        buffered = _buffer_ring(ring, 500.0)  # 500 m buffer
        assert self._ring_area_deg2(buffered) > self._ring_area_deg2(ring)

    def test_buffer_zero_returns_equivalent_ring(self):
        """Zero buffer should leave the ring unchanged."""
        ring = _SQUARE_CW
        buffered = _buffer_ring(ring, 0.0)
        for orig, buf in zip(ring, buffered, strict=False):
            assert abs(orig[0] - buf[0]) < 1e-9
            assert abs(orig[1] - buf[1]) < 1e-9

    def test_buffer_preserves_vertex_count(self):
        """Buffered ring should have the same number of vertices as the input."""
        ring = _SQUARE_CW
        buffered = _buffer_ring(ring, 20.0)
        assert len(buffered) == len(ring)

    def test_buffer_ring_is_closed(self):
        """First and last vertex of the buffered ring must be identical."""
        buffered = _buffer_ring(_SQUARE_CW, 20.0)
        assert buffered[0] == buffered[-1]

    def test_buffer_works_for_ccw_ring(self):
        """CCW ring should expand outward just like a CW ring."""
        cw_buf = _buffer_ring(_SQUARE_CW, 200.0)
        ccw_buf = _buffer_ring(_SQUARE_CCW, 200.0)
        # Both should be larger than the original
        assert self._ring_area_deg2(cw_buf) > self._ring_area_deg2(_SQUARE_CW)
        assert self._ring_area_deg2(ccw_buf) > self._ring_area_deg2(_SQUARE_CCW)

    def test_buffer_offset_magnitude(self):
        """Buffer of 1 000 m on a 1°-square should widen each side by ~1 000 m."""
        import math

        # 1°-square (≈ 111 km wide) at lat≈0 for simpler maths
        square = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.0, 0.0]]
        buffered = _buffer_ring(square, 1000.0)
        # Bottom-left corner should move SW; check lon component
        M_LON = 111_320.0 * math.cos(math.radians(52.0))
        M_LAT = 111_320.0
        delta_lon = abs(buffered[0][0] - square[0][0]) * M_LON
        delta_lat = abs(buffered[0][1] - square[0][1]) * M_LAT
        assert abs(delta_lon - 1000.0) < 5.0  # within 5 m
        assert abs(delta_lat - 1000.0) < 5.0


class TestJoinZonesNetworkBuffer:
    """Check that clip_buffer_m brings in links just outside the zone boundary."""

    def _zone_fc(self):
        # Unit square [0,0]→[1,0]→[1,1]→[0,1] as an AREA zone.
        return {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": [_SQUARE_CW]},
                    "properties": {
                        "zoneId": "Z1",
                        "zoneClass": "AREA",
                        "centroidLon": 0.5,
                        "centroidLat": 0.5,
                    },
                }
            ],
            "properties": {"areaId": "A1"},
        }

    def _network_fc(self, *links):
        return {
            "type": "FeatureCollection",
            "features": list(links),
            "properties": {"modes": ["CAR"]},
        }

    def _make_link(self, coords, link_id="L1", from_node=1, to_node=2):
        return {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": coords},
            "properties": {
                "linkId": link_id,
                "fromNode": from_node,
                "toNode": to_node,
                "modes": ["CAR"],
                "flow": 0.0,
            },
        }

    def test_link_just_outside_excluded_without_buffer(self):
        """A link just outside the zone is excluded when buffer_m=0."""
        # Link runs just outside the right edge (x=1) of the unit square
        link = self._make_link([[1.0001, 0.2], [1.0001, 0.8]])
        results = join_zones_to_network(
            self._zone_fc(),
            self._network_fc(link),
            zone_classes={"AREA"},
            clip_buffer_m=0.0,
        )
        clipped_fc = results[0][1]
        assert len(clipped_fc["features"]) == 0

    def test_link_just_outside_included_with_buffer(self):
        """A link just outside (< 20 m) the zone boundary is included when buffer_m=20."""
        import math

        # Place the link ~10 m outside the right edge (lon=1.0)
        # 10 m in longitude ≈ 10 / (111320 * cos(52°)) degrees
        M_LON = 111_320.0 * math.cos(math.radians(52.0))
        offset = 10.0 / M_LON
        link = self._make_link([[1.0 + offset, 0.3], [1.0 + offset, 0.7]])
        results = join_zones_to_network(
            self._zone_fc(),
            self._network_fc(link),
            zone_classes={"AREA"},
            clip_buffer_m=20.0,
        )
        clipped_fc = results[0][1]
        assert len(clipped_fc["features"]) >= 1

    def test_link_far_outside_still_excluded_with_buffer(self):
        """A link more than 20 m outside is still excluded even with buffer_m=20."""
        import math

        M_LON = 111_320.0 * math.cos(math.radians(52.0))
        offset = 50.0 / M_LON  # 50 m outside
        link = self._make_link([[1.0 + offset, 0.3], [1.0 + offset, 0.7]])
        results = join_zones_to_network(
            self._zone_fc(),
            self._network_fc(link),
            zone_classes={"AREA"},
            clip_buffer_m=20.0,
        )
        clipped_fc = results[0][1]
        assert len(clipped_fc["features"]) == 0


# ---------------------------------------------------------------------------
# Helpers for nodeProportions tests
# ---------------------------------------------------------------------------


def _make_link_feat(link_id, from_node, to_node, lon0, lat0, lon1, lat1, length):
    """Return a minimal LineString link feature."""
    return {
        "type": "Feature",
        "geometry": {"type": "LineString", "coordinates": [[lon0, lat0], [lon1, lat1]]},
        "properties": {
            "linkId": link_id,
            "fromNode": from_node,
            "toNode": to_node,
            "length": length,
        },
    }


def _make_zone_feat(zone_id, zone_class, ring):
    """Return a minimal Polygon zone feature."""
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [ring]},
        "properties": {"zoneId": zone_id, "zoneClass": zone_class},
    }


# ---------------------------------------------------------------------------
# Unit tests: _build_node_coords
# ---------------------------------------------------------------------------


class TestBuildNodeCoords:
    def test_empty(self):
        assert _build_node_coords([]) == {}

    def test_single_link(self):
        feat = _make_link_feat("L1", "A", "B", 1.0, 2.0, 3.0, 4.0, 100.0)
        coords = _build_node_coords([feat])
        assert coords["A"] == [1.0, 2.0]
        assert coords["B"] == [3.0, 4.0]

    def test_shared_node_keeps_first_occurrence(self):
        feat1 = _make_link_feat("L1", "A", "B", 1.0, 2.0, 3.0, 4.0, 100.0)
        feat2 = _make_link_feat("L2", "B", "C", 9.0, 9.0, 5.0, 6.0, 50.0)
        coords = _build_node_coords([feat1, feat2])
        # B was first seen as toNode in feat1 → coords from feat1
        assert coords["B"] == [3.0, 4.0]
        assert coords["C"] == [5.0, 6.0]

    def test_missing_geometry_skipped(self):
        feat = {"type": "Feature", "geometry": None, "properties": {"fromNode": "X", "toNode": "Y"}}
        assert _build_node_coords([feat]) == {}

    def test_missing_nodes_skipped(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [1.0, 1.0]]},
            "properties": {},
        }
        assert _build_node_coords([feat]) == {}


# ---------------------------------------------------------------------------
# Unit tests: _build_node_total_length
# ---------------------------------------------------------------------------


class TestBuildNodeTotalLength:
    def test_empty(self):
        assert _build_node_total_length([]) == {}

    def test_single_link_contributes_to_both_nodes(self):
        feat = _make_link_feat("L1", "A", "B", 0.0, 0.0, 1.0, 0.0, 200.0)
        totals = _build_node_total_length([feat])
        assert totals["A"] == pytest.approx(200.0)
        assert totals["B"] == pytest.approx(200.0)

    def test_shared_node_accumulates(self):
        feat1 = _make_link_feat("L1", "A", "B", 0.0, 0.0, 1.0, 0.0, 100.0)
        feat2 = _make_link_feat("L2", "B", "C", 1.0, 0.0, 2.0, 0.0, 300.0)
        totals = _build_node_total_length([feat1, feat2])
        assert totals["B"] == pytest.approx(400.0)

    def test_missing_length_treated_as_zero(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "LineString", "coordinates": [[0.0, 0.0], [1.0, 0.0]]},
            "properties": {"fromNode": "A", "toNode": "B"},
        }
        totals = _build_node_total_length([feat])
        assert totals["A"] == pytest.approx(0.0)
        assert totals["B"] == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# Unit tests: _compute_node_proportions
# ---------------------------------------------------------------------------

# A unit square centred-ish around (0.5, 0.5) in lon/lat
_SQUARE_RING = [[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.0, 0.0]]


class TestComputeNodeProportions:
    def _zone(self, zone_class="STUDY"):
        return _make_zone_feat("Z1", zone_class, _SQUARE_RING)

    def test_empty_clipped_features_returns_empty(self):
        zone = self._zone()
        result = _compute_node_proportions(zone, {}, {})
        assert result == {}

    def test_node_inside_gets_proportion_1(self):
        zone = self._zone()
        node_coords = {"N1": [0.5, 0.5]}
        node_total = {"N1": 100.0}
        result = _compute_node_proportions(zone, node_total, node_coords)
        assert result == {"N1": pytest.approx(1.0)}

    def test_two_equal_nodes_proportions_sum_to_1(self):
        zone = self._zone()
        node_coords = {"N1": [0.3, 0.3], "N2": [0.7, 0.7]}
        node_total = {"N1": 100.0, "N2": 100.0}
        result = _compute_node_proportions(zone, node_total, node_coords)
        assert sum(result.values()) == pytest.approx(1.0)
        assert result["N1"] == pytest.approx(0.5)
        assert result["N2"] == pytest.approx(0.5)

    def test_proportional_to_length(self):
        zone = self._zone()
        node_coords = {"N1": [0.3, 0.3], "N2": [0.7, 0.7]}
        node_total = {"N1": 100.0, "N2": 300.0}
        result = _compute_node_proportions(zone, node_total, node_coords)
        assert result["N1"] == pytest.approx(0.25)
        assert result["N2"] == pytest.approx(0.75)

    def test_node_outside_excluded(self):
        zone = self._zone()
        node_coords = {"N1": [0.5, 0.5], "N2": [2.0, 2.0]}
        node_total = {"N1": 100.0, "N2": 100.0}
        result = _compute_node_proportions(zone, node_total, node_coords)
        assert "N2" not in result
        assert result == {"N1": pytest.approx(1.0)}

    def test_boundary_zone_returns_zone_id_with_1(self):
        zone = _make_zone_feat("N_BOUNDARY", "BOUNDARY", _SQUARE_RING)
        node_total = {"N_BOUNDARY": 50.0}
        node_coords = {"N_BOUNDARY": [0.5, 0.5]}
        result = _compute_node_proportions(zone, node_total, node_coords)
        assert result == {"N_BOUNDARY": 1.0}

    def test_boundary_zone_node_not_in_total_returns_empty(self):
        zone = _make_zone_feat("N_BOUNDARY", "BOUNDARY", _SQUARE_RING)
        result = _compute_node_proportions(zone, {}, {})
        assert result == {}

    def test_all_zero_lengths_equal_weights(self):
        zone = self._zone()
        node_coords = {"N1": [0.3, 0.3], "N2": [0.7, 0.7]}
        node_total = {"N1": 0.0, "N2": 0.0}
        result = _compute_node_proportions(zone, node_total, node_coords)
        assert sum(result.values()) == pytest.approx(1.0)
        assert result["N1"] == pytest.approx(result["N2"])

    def test_multipolygon_zone(self):
        zone = {
            "type": "Feature",
            "geometry": {
                "type": "MultiPolygon",
                "coordinates": [
                    [[[0.0, 0.0], [1.0, 0.0], [1.0, 1.0], [0.0, 1.0], [0.0, 0.0]]],
                    [[[2.0, 0.0], [3.0, 0.0], [3.0, 1.0], [2.0, 1.0], [2.0, 0.0]]],
                ],
            },
            "properties": {"zoneId": "Z_MULTI", "zoneClass": "STUDY"},
        }
        node_coords = {"N1": [0.5, 0.5], "N2": [2.5, 0.5]}
        node_total = {"N1": 200.0, "N2": 200.0}
        result = _compute_node_proportions(zone, node_total, node_coords)
        assert result["N1"] == pytest.approx(0.5)
        assert result["N2"] == pytest.approx(0.5)


# ---------------------------------------------------------------------------
# Unit tests: _annotate_zone_proportions
# ---------------------------------------------------------------------------


class TestAnnotateZoneProportions:
    def _link_inside(self):
        return _make_link_feat("L1", "N1", "N2", 0.3, 0.3, 0.7, 0.7, 100.0)

    def test_empty_features_returns_empty(self):
        assert _annotate_zone_proportions([], []) == []

    def test_proportions_key_added(self):
        zone = _make_zone_feat("Z1", "STUDY", _SQUARE_RING)
        links = [self._link_inside()]
        result = _annotate_zone_proportions([zone], links)
        assert len(result) == 1
        assert "fromNodeProportions" in result[0]["properties"]
        assert "toNodeProportions" in result[0]["properties"]

    def test_no_links_gives_empty_proportions(self):
        zone = _make_zone_feat("Z1", "STUDY", _SQUARE_RING)
        result = _annotate_zone_proportions([zone], [])
        assert result[0]["properties"]["fromNodeProportions"] == {}
        assert result[0]["properties"]["toNodeProportions"] == {}

    def test_proportions_sum_to_1(self):
        zone = _make_zone_feat("Z1", "STUDY", _SQUARE_RING)
        links = [
            _make_link_feat("L1", "N1", "N2", 0.2, 0.2, 0.4, 0.4, 80.0),
            _make_link_feat("L2", "N2", "N3", 0.4, 0.4, 0.8, 0.8, 120.0),
        ]
        result = _annotate_zone_proportions([zone], links)
        from_props = result[0]["properties"]["fromNodeProportions"]
        to_props = result[0]["properties"]["toNodeProportions"]
        if from_props:
            assert sum(from_props.values()) == pytest.approx(1.0)
        if to_props:
            assert sum(to_props.values()) == pytest.approx(1.0)

    def test_original_features_not_mutated(self):
        zone = _make_zone_feat("Z1", "STUDY", _SQUARE_RING)
        original_keys = set(zone["properties"].keys())
        _annotate_zone_proportions([zone], [])
        assert set(zone["properties"].keys()) == original_keys

    def test_multiple_zones_each_annotated(self):
        ring2 = [[2.0, 0.0], [3.0, 0.0], [3.0, 1.0], [2.0, 1.0], [2.0, 0.0]]
        zone1 = _make_zone_feat("Z1", "STUDY", _SQUARE_RING)
        zone2 = _make_zone_feat("Z2", "INFLUENCE", ring2)
        links = [
            _make_link_feat("L1", "N1", "N2", 0.3, 0.3, 0.7, 0.7, 100.0),
            _make_link_feat("L2", "N3", "N4", 2.2, 0.5, 2.8, 0.5, 200.0),
        ]
        result = _annotate_zone_proportions([zone1, zone2], links)
        assert "fromNodeProportions" in result[0]["properties"]
        assert "fromNodeProportions" in result[1]["properties"]
        assert "toNodeProportions" in result[0]["properties"]
        assert "toNodeProportions" in result[1]["properties"]
        from_props0 = result[0]["properties"]["fromNodeProportions"]
        from_props1 = result[1]["properties"]["fromNodeProportions"]
        if from_props0:
            assert sum(from_props0.values()) == pytest.approx(1.0)
        if from_props1:
            assert sum(from_props1.values()) == pytest.approx(1.0)


# ---------------------------------------------------------------------------
# Integration tests: nodeProportions via join_zones_to_network
# ---------------------------------------------------------------------------


class TestJoinZonesToNetworkNodeProportions:
    """Verify that join_zones_to_network populates nodeProportions on zone feats."""

    def _network_fc(self, *links):
        return {"type": "FeatureCollection", "features": list(links)}

    def _zone_fc(self):
        """A single STUDY zone covering the unit square."""
        return {
            "type": "FeatureCollection",
            "features": [
                {
                    "type": "Feature",
                    "geometry": {"type": "Polygon", "coordinates": [_SQUARE_RING]},
                    "properties": {"zoneId": "ZA", "zoneClass": "STUDY", "name": "TestZone"},
                }
            ],
        }

    def test_zone_features_have_node_proportions_key(self):
        link = _make_link_feat("L1", "N1", "N2", 0.3, 0.3, 0.7, 0.7, 100.0)
        results = join_zones_to_network(
            self._zone_fc(), self._network_fc(link), zone_classes={"STUDY"}
        )
        zone_fc_features = results[0][2]["features"]
        assert len(zone_fc_features) > 0
        assert "fromNodeProportions" in zone_fc_features[0]["properties"]
        assert "toNodeProportions" in zone_fc_features[0]["properties"]

    def test_node_proportions_sum_to_1_when_links_present(self):
        link1 = _make_link_feat("L1", "N1", "N2", 0.2, 0.2, 0.5, 0.5, 100.0)
        link2 = _make_link_feat("L2", "N2", "N3", 0.5, 0.5, 0.8, 0.8, 300.0)
        results = join_zones_to_network(
            self._zone_fc(), self._network_fc(link1, link2), zone_classes={"STUDY"}
        )
        zone_fc_features = results[0][2]["features"]
        from_props = zone_fc_features[0]["properties"]["fromNodeProportions"]
        to_props = zone_fc_features[0]["properties"]["toNodeProportions"]
        if from_props:
            assert sum(from_props.values()) == pytest.approx(1.0)
        if to_props:
            assert sum(to_props.values()) == pytest.approx(1.0)

    def test_empty_network_gives_empty_node_proportions(self):
        results = join_zones_to_network(self._zone_fc(), self._network_fc(), zone_classes={"STUDY"})
        zone_fc_features = results[0][2]["features"]
        assert zone_fc_features[0]["properties"]["fromNodeProportions"] == {}
        assert zone_fc_features[0]["properties"]["toNodeProportions"] == {}


# ---------------------------------------------------------------------------
# Unit tests: _build_node_zone_map
# ---------------------------------------------------------------------------


class TestBuildNodeZoneMap:
    def _zone_feat_with_proportions(self, zone_id, from_proportions, to_proportions=None):
        return {
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [_SQUARE_RING]},
            "properties": {
                "zoneId": zone_id,
                "zoneClass": "STUDY",
                "fromNodeProportions": from_proportions,
                "toNodeProportions": to_proportions
                if to_proportions is not None
                else from_proportions,
            },
        }

    def test_empty_returns_empty(self):
        assert _build_node_zone_map([], "fromNodeProportions") == {}

    def test_single_zone_single_node(self):
        feat = self._zone_feat_with_proportions("Z1", {"N1": 1.0})
        result = _build_node_zone_map([feat], "fromNodeProportions")
        assert result == {"N1": {"Z1": 1.0}}

    def test_single_zone_multiple_nodes(self):
        feat = self._zone_feat_with_proportions("Z1", {"N1": 0.3, "N2": 0.7})
        result = _build_node_zone_map([feat], "fromNodeProportions")
        assert result["N1"] == {"Z1": pytest.approx(0.3)}
        assert result["N2"] == {"Z1": pytest.approx(0.7)}

    def test_multiple_zones_same_node(self):
        z1 = self._zone_feat_with_proportions("Z1", {"N1": 0.4})
        z2 = self._zone_feat_with_proportions("Z2", {"N1": 0.6, "N2": 1.0})
        result = _build_node_zone_map([z1, z2], "fromNodeProportions")
        assert result["N1"] == {"Z1": pytest.approx(0.4), "Z2": pytest.approx(0.6)}
        assert result["N2"] == {"Z2": pytest.approx(1.0)}

    def test_zone_without_proportions_skipped(self):
        feat = {
            "type": "Feature",
            "geometry": {"type": "Polygon", "coordinates": [_SQUARE_RING]},
            "properties": {"zoneId": "Z1", "zoneClass": "STUDY"},
        }
        assert _build_node_zone_map([feat], "fromNodeProportions") == {}

    def test_node_ids_coerced_to_str(self):
        feat = self._zone_feat_with_proportions("Z1", {123: 1.0})
        result = _build_node_zone_map([feat], "fromNodeProportions")
        assert "123" in result

    def test_to_proportions_key(self):
        feat = self._zone_feat_with_proportions("Z1", {"N1": 0.4}, {"N2": 1.0})
        from_result = _build_node_zone_map([feat], "fromNodeProportions")
        to_result = _build_node_zone_map([feat], "toNodeProportions")
        assert "N1" in from_result
        assert "N2" in to_result
        assert "N1" not in to_result


# ---------------------------------------------------------------------------
# Unit: _adjust_internal_zone_demands
# ---------------------------------------------------------------------------


def _make_internal_zone(
    zone_id: str, zone_class: str, attraction: float, production: float
) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [SQUARE_RING]},
        "properties": {
            "zoneId": zone_id,
            "zoneClass": zone_class,
            "attraction": attraction,
            "production": production,
        },
    }


def _make_boundary_zone_for_adjust(zone_id: str, attraction: float, production: float) -> dict:
    return {
        "type": "Feature",
        "geometry": {"type": "Polygon", "coordinates": [SQUARE_RING]},
        "properties": {
            "zoneId": zone_id,
            "zoneClass": "BOUNDARY",
            "centroidLon": 0.5,
            "centroidLat": 0.5,
            "attraction": attraction,
            "production": production,
        },
    }


class TestAdjustInternalZoneDemands:
    """_adjust_internal_zone_demands reduces attraction/production on internal zones."""

    def test_no_boundary_zones_returns_unchanged(self):
        z = _make_internal_zone("Z1", "STUDY", 100.0, 200.0)
        result = _adjust_internal_zone_demands([z], [])
        assert result == [z]

    def test_zero_boundary_flows_returns_unchanged(self):
        z = _make_internal_zone("Z1", "STUDY", 100.0, 200.0)
        b = _make_boundary_zone_for_adjust("B1", 0.0, 0.0)
        result = _adjust_internal_zone_demands([z, b], [b])
        # No original* keys added when there is nothing to subtract
        assert "originalAttraction" not in result[0]["properties"]

    def test_single_internal_zone_full_reduction(self):
        """One internal zone absorbs 100% of the boundary flow."""
        z = _make_internal_zone("Z1", "STUDY", 100.0, 200.0)
        b = _make_boundary_zone_for_adjust("B1", 30.0, 50.0)
        result = _adjust_internal_zone_demands([z, b], [b])

        internal = next(f for f in result if f["properties"]["zoneClass"] != "BOUNDARY")
        props = internal["properties"]
        assert props["originalAttraction"] == pytest.approx(100.0)
        assert props["originalProduction"] == pytest.approx(200.0)
        assert props["attraction"] == pytest.approx(70.0)  # 100 - 30
        assert props["production"] == pytest.approx(150.0)  # 200 - 50

    def test_two_internal_zones_proportional_reduction(self):
        """Boundary flow is split proportionally between two internal zones."""
        z1 = _make_internal_zone("Z1", "STUDY", 100.0, 200.0)
        z2 = _make_internal_zone("Z2", "INFLUENCE", 300.0, 800.0)
        b = _make_boundary_zone_for_adjust("B1", 40.0, 100.0)
        result = _adjust_internal_zone_demands([z1, z2, b], [b])

        by_id = {f["properties"]["zoneId"]: f["properties"] for f in result}

        # Z1 share of attraction = 100/(100+300) = 25% → gets 10 subtracted
        assert by_id["Z1"]["originalAttraction"] == pytest.approx(100.0)
        assert by_id["Z1"]["attraction"] == pytest.approx(90.0)
        # Z1 share of production = 200/(200+800) = 20% → gets 20 subtracted
        assert by_id["Z1"]["originalProduction"] == pytest.approx(200.0)
        assert by_id["Z1"]["production"] == pytest.approx(180.0)

        # Z2 share of attraction = 300/400 = 75% → gets 30 subtracted
        assert by_id["Z2"]["originalAttraction"] == pytest.approx(300.0)
        assert by_id["Z2"]["attraction"] == pytest.approx(270.0)
        # Z2 share of production = 800/1000 = 80% → gets 80 subtracted
        assert by_id["Z2"]["originalProduction"] == pytest.approx(800.0)
        assert by_id["Z2"]["production"] == pytest.approx(720.0)

    def test_multiple_boundary_zones_summed(self):
        """Attraction from multiple boundary mini-zones is summed before redistribution."""
        z = _make_internal_zone("Z1", "STUDY", 100.0, 100.0)
        b1 = _make_boundary_zone_for_adjust("B1", 10.0, 20.0)
        b2 = _make_boundary_zone_for_adjust("B2", 15.0, 5.0)
        result = _adjust_internal_zone_demands([z, b1, b2], [b1, b2])

        props = next(f for f in result if f["properties"]["zoneClass"] != "BOUNDARY")["properties"]
        assert props["attraction"] == pytest.approx(75.0)  # 100 - (10+15)
        assert props["production"] == pytest.approx(75.0)  # 100 - (20+5)

    def test_boundary_features_unmodified(self):
        """BOUNDARY features must not gain originalAttraction/originalProduction."""
        z = _make_internal_zone("Z1", "STUDY", 100.0, 100.0)
        b = _make_boundary_zone_for_adjust("B1", 20.0, 30.0)
        result = _adjust_internal_zone_demands([z, b], [b])

        boundary = next(f for f in result if f["properties"]["zoneClass"] == "BOUNDARY")
        assert "originalAttraction" not in boundary["properties"]
        assert "originalProduction" not in boundary["properties"]
        assert boundary["properties"]["attraction"] == pytest.approx(20.0)
        assert boundary["properties"]["production"] == pytest.approx(30.0)

    def test_zero_internal_attraction_no_division(self):
        """No ZeroDivisionError when all internal zones have zero attraction."""
        z = _make_internal_zone("Z1", "STUDY", 0.0, 0.0)
        b = _make_boundary_zone_for_adjust("B1", 30.0, 50.0)
        result = _adjust_internal_zone_demands([z, b], [b])
        # attraction stays 0 (no reduction possible), no crash
        props = next(f for f in result if f["properties"]["zoneClass"] != "BOUNDARY")["properties"]
        assert props["attraction"] == pytest.approx(0.0)
        assert props["production"] == pytest.approx(0.0)


# ---------------------------------------------------------------------------
# _dedup_zone_features / _dedup_net_features
# ---------------------------------------------------------------------------

from gmt_network_core.network_zone_joiner.network_zone_joiner_runner import (
    _dedup_net_features,
    _dedup_zone_features,
)


def _zone_feat(zone_id: str, zone_class: str = "STUDY") -> dict:
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {"zoneId": zone_id, "zoneClass": zone_class},
    }


def _net_feat(link_id: str, from_node: str, to_node: str) -> dict:
    return {
        "type": "Feature",
        "geometry": None,
        "properties": {"linkId": link_id, "fromNode": from_node, "toNode": to_node},
    }


class TestDedupZoneFeatures:
    def test_no_duplicates_unchanged(self):
        feats = [_zone_feat("z1"), _zone_feat("z2"), _zone_feat("z3")]
        result = _dedup_zone_features(feats)
        assert len(result) == 3
        assert [f["properties"]["zoneId"] for f in result] == ["z1", "z2", "z3"]

    def test_exact_duplicate_removed(self):
        """Same feature object appearing twice — second occurrence dropped."""
        f = _zone_feat("z1")
        result = _dedup_zone_features([f, f])
        assert len(result) == 1
        assert result[0] is f

    def test_different_objects_same_zone_id(self):
        """Two distinct dicts with the same zoneId — first wins."""
        f1 = _zone_feat("z1")
        f2 = _zone_feat("z1")
        result = _dedup_zone_features([f1, f2])
        assert len(result) == 1
        assert result[0] is f1

    def test_area_zone_included_once(self):
        """AREA zone appearing from its own tuple and via another route is deduped."""
        area = _zone_feat("AREA-1", "AREA")
        study = _zone_feat("S1", "STUDY")
        # Simulate: AREA zone's zone_fc contributed [study], then individual study added study again.
        result = _dedup_zone_features([study, area, study])
        ids = [f["properties"]["zoneId"] for f in result]
        assert ids.count("S1") == 1
        assert ids.count("AREA-1") == 1

    def test_boundary_mini_zones_kept(self):
        """BOUNDARY mini-zones (only appear once) are always included."""
        boundary = _zone_feat("link-42", "BOUNDARY")
        study = _zone_feat("s1")
        result = _dedup_zone_features([study, boundary, study])
        ids = {f["properties"]["zoneId"] for f in result}
        assert "link-42" in ids
        assert "s1" in ids
        assert len(result) == 2

    def test_empty_input(self):
        assert _dedup_zone_features([]) == []

    def test_missing_zone_id_treated_as_empty_string(self):
        """Features with no zoneId are bucketed under '' — only first kept."""
        f1 = {"type": "Feature", "geometry": None, "properties": {}}
        f2 = {"type": "Feature", "geometry": None, "properties": {}}
        result = _dedup_zone_features([f1, f2])
        assert len(result) == 1


class TestDedupNetFeatures:
    def test_no_duplicates_unchanged(self):
        feats = [
            _net_feat("L1", "A", "B"),
            _net_feat("L2", "B", "C"),
            _net_feat("L3", "C", "D"),
        ]
        result = _dedup_net_features(feats)
        assert len(result) == 3

    def test_exact_duplicate_removed(self):
        f = _net_feat("L1", "A", "B")
        result = _dedup_net_features([f, f])
        assert len(result) == 1

    def test_same_link_different_boundary_nodes_kept_separately(self):
        """The same linkId with different fromNode/toNode represents different graph edges."""
        f1 = _net_feat("L1", "A", "B")
        f2 = _net_feat("L1", "L1", "B")  # AREA boundary clip: fromNode replaced with linkId
        result = _dedup_net_features([f1, f2])
        assert len(result) == 2

    def test_first_occurrence_wins(self):
        f1 = _net_feat("L1", "A", "B")
        f2 = _net_feat("L1", "A", "B")
        result = _dedup_net_features([f1, f2])
        assert result[0] is f1

    def test_falls_back_to_spectrum_id(self):
        """When linkId is absent, spectrumId is used as the key."""
        f1 = {
            "type": "Feature",
            "geometry": None,
            "properties": {"spectrumId": "S9", "fromNode": "X", "toNode": "Y"},
        }
        f2 = {
            "type": "Feature",
            "geometry": None,
            "properties": {"spectrumId": "S9", "fromNode": "X", "toNode": "Y"},
        }
        result = _dedup_net_features([f1, f2])
        assert len(result) == 1

    def test_empty_input(self):
        assert _dedup_net_features([]) == []
