"""Pure-Python network_zone_joiner core — no I/O, no boto3, no external deps.

Clips a network GeoJSON FeatureCollection to each zone polygon in a zones
FeatureCollection, producing per-zone network, zone, and feedlinks output files.

Public API
----------
join_zones_to_network(zones_fc, network_fc, zone_classes, feedlinks_fc)
    Returns a list of (zone_feature, clipped_network_fc, zone_fc, feedlinks_fc) tuples.

extend_feedlinks_for_zone(feedlinks_fc, clipped_network_fc, zone_feature, mode)
    Filters existing feedlinks and adds synthetic boundary-node feedlinks.

compute_network_boundary_node_roles(area_zone_feature, network_fc)
    Returns (entry_node_ids, exit_node_ids) — the AREA zone's boundary-crossing
    node IDs, split by role (entry = fromNode, exit = toNode of a crossing link).

build_zone_output_path(output_folder, area_id, zone_id, artifact_type, mode)
    Constructs the output filename: {areaId}[{zoneId}]-{artifact_type}-{mode}.geojson
"""

from __future__ import annotations

from gmt_network_core.network_zone_joiner.domain.geometry import (  # noqa: F401
    clip_linestring_to_polygon,
    point_in_polygon,
)
from gmt_network_core.network_zone_joiner.domain.joiner import (  # noqa: F401
    FEEDLINK_PROPERTIES,
    _adjust_internal_zone_demands,
    build_zone_output_path,
    compute_network_boundary_node_roles,
    extend_feedlinks_for_zone,
    join_zones_to_network,
)
