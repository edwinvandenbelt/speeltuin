"""Tests for gmt_shared.ogc_features (URL building + pagination, no network)."""

from __future__ import annotations

import urllib.parse

import pytest

from gmt_shared import ogc_features
from gmt_shared.ogc_features import CURRENT_ONLY_FILTER, build_items_url, fetch_collection_items

BBOX = [6.57, 52.27, 6.59, 52.28]


def _query(url: str) -> dict[str, str]:
    return dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(url).query))


def test_url_filters_current_versions_by_default() -> None:
    q = _query(build_items_url("wegdeel", BBOX, url="https://example.test/v1/"))
    assert q["filter"] == CURRENT_ONLY_FILTER == "eind_registratie IS NULL"
    assert q["filter-lang"] == "cql2-text"
    assert q["bbox"] == "6.57,52.27,6.59,52.28"


def test_url_path() -> None:
    url = build_items_url("wegdeel", BBOX, url="https://example.test/v1/")
    assert url.startswith("https://example.test/v1/collections/wegdeel/items?")


def test_url_without_current_only_has_no_filter() -> None:
    q = _query(build_items_url("wegdeel", BBOX, current_only=False))
    assert "filter" not in q
    assert "filter-lang" not in q


def test_url_property_filters() -> None:
    q = _query(build_items_url("wegdeel", BBOX, properties={"functie": "parkeervlak"}))
    assert q["functie"] == "parkeervlak"
    assert q["filter"] == CURRENT_ONLY_FILTER


def test_cache_key_differs_per_filter() -> None:
    a = build_items_url("wegdeel", BBOX)
    b = build_items_url("wegdeel", BBOX, current_only=False)
    c = build_items_url("wegdeel", BBOX, properties={"functie": "parkeervlak"})
    assert len({a, b, c}) == 3


def test_fetch_follows_next_links(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("PDOK_BGT_CACHE_DIR", "")
    pages: dict[str, dict[str, object]] = {
        "first": {
            "features": [{"id": 1}],
            "links": [{"rel": "next", "href": "second"}],
        },
        "second": {"features": [{"id": 2}], "links": []},
    }
    seen: list[str] = []

    def fake_get_json(url: str, **_kwargs: int) -> dict:
        seen.append(url)
        return pages["second"] if url == "second" else pages["first"]

    monkeypatch.setattr(ogc_features, "_get_json", fake_get_json)
    feats = fetch_collection_items("wegdeel", BBOX, url="https://example.test/v1")
    assert [f["id"] for f in feats] == [1, 2]
    assert _query(seen[0])["filter"] == CURRENT_ONLY_FILTER
    assert seen[1] == "second"
