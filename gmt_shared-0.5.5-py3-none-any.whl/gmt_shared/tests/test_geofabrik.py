"""Tests for gmt_shared.geofabrik — extract selection and per-bbox clipping (no network)."""

from __future__ import annotations

import os
from pathlib import Path

import pytest
from shapely.geometry import LineString, MultiLineString, box

from gmt_shared import geofabrik
from gmt_shared.geofabrik import (
    Extract,
    ensure_pbf,
    local_pbf_for_bbox,
    parse_poly,
    resolve_pbf_paths,
    select_extracts,
)

# Two adjacent "provinces" (slightly overlapping, like Geofabrik polys), a third
# one further east, and the country containing all of them.
_WEST = Extract("west", "europe/x/west")
_EAST = Extract("east", "europe/x/east")
_FAR = Extract("far", "europe/x/far")
_POLYS = {
    "west": box(0.0, 0.0, 1.01, 1.0),
    "east": box(0.99, 0.0, 2.01, 1.0),
    "far": box(1.99, 0.0, 3.0, 1.0),
    "netherlands": box(-0.1, -0.1, 3.1, 1.1),
}


@pytest.fixture
def fake_polys(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(geofabrik, "load_poly", lambda e, _cache_dir: _POLYS[e.slug])
    monkeypatch.setattr(geofabrik, "LEAF_EXTRACTS", (_WEST, _EAST, _FAR))


@pytest.fixture
def fake_sources(fake_polys: None, monkeypatch: pytest.MonkeyPatch) -> list:  # noqa: ARG001
    """``ensure_pbf`` writes a dummy file per extract; ``_make_clip`` records its sources."""
    monkeypatch.delenv("OSM_PBF_PATH", raising=False)

    def _fake_ensure(extract: Extract, cache_dir: Path) -> Path:
        path = cache_dir / f"{extract.slug}.osm.pbf"
        if not path.exists():
            path.write_bytes(b"pbf")
        return path

    calls: list = []

    def _fake_clip(sources, _bbox, out_path: Path) -> None:
        calls.append([p.name for p in sources])
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_bytes(b"clip")

    monkeypatch.setattr(geofabrik, "ensure_pbf", _fake_ensure)
    monkeypatch.setattr(geofabrik, "_make_clip", _fake_clip)
    return calls


def _lines(*coords_list) -> MultiLineString:
    return MultiLineString([LineString(c) for c in coords_list])


# ---------------------------------------------------------------------------
# select_extracts / resolve_pbf_paths
# ---------------------------------------------------------------------------


@pytest.mark.usefixtures("fake_polys")
def test_network_inside_one_extract(tmp_path: Path) -> None:
    geom = _lines([(0.2, 0.5), (0.6, 0.5)])
    assert select_extracts(geom, cache_dir=tmp_path) == [_WEST]


@pytest.mark.usefixtures("fake_polys")
def test_network_on_border_uses_both_extracts(tmp_path: Path) -> None:
    geom = _lines([(0.8, 0.5), (1.3, 0.5)])
    assert {e.slug for e in select_extracts(geom, cache_dir=tmp_path)} == {"west", "east"}


@pytest.mark.usefixtures("fake_polys")
def test_bbox_corner_in_other_extract_is_not_selected(tmp_path: Path) -> None:
    # The bbox of these links reaches into "east", but no link does.
    geom = _lines([(0.2, 0.1), (0.3, 0.1)], [(0.95, 0.9), (0.96, 0.9)])
    assert select_extracts(geom, cache_dir=tmp_path) == [_WEST]


@pytest.mark.usefixtures("fake_polys")
def test_bbox_polygon_on_border_uses_both_extracts(tmp_path: Path) -> None:
    chosen = select_extracts(box(0.8, 0.2, 1.3, 0.4), cache_dir=tmp_path)
    assert {e.slug for e in chosen} == {"west", "east"}


@pytest.mark.usefixtures("fake_polys")
def test_uncovered_network_raises(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="not fully covered"):
        select_extracts(_lines([(2.5, 0.5), (4.0, 0.5)]), cache_dir=tmp_path)


def test_default_registry_has_no_country_with_provinces() -> None:
    slugs = {e.slug for e in geofabrik.LEAF_EXTRACTS}
    assert not slugs & {"netherlands", "germany", "europe"}


def test_ensure_pbf_uses_cache(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    cached = tmp_path / "west.osm.pbf"
    cached.write_bytes(b"pbf")
    monkeypatch.setattr(geofabrik, "_download", lambda *_a, **_kw: pytest.fail("downloaded"))
    assert ensure_pbf(_WEST, tmp_path) == cached


def test_ensure_pbf_downloads_missing(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    calls = []

    def _fake_download(url: str, dest: Path, **_kw: object) -> None:
        calls.append(url)
        dest.write_bytes(b"pbf")

    monkeypatch.setattr(geofabrik, "_download", _fake_download)
    assert ensure_pbf(_EAST, tmp_path).read_bytes() == b"pbf"
    assert calls == ["https://download.geofabrik.de/europe/x/east-latest.osm.pbf"]


@pytest.mark.usefixtures("fake_polys")
def test_resolve_pbf_paths(monkeypatch: pytest.MonkeyPatch, tmp_path: Path) -> None:
    monkeypatch.setattr(geofabrik, "ensure_pbf", lambda e, c: c / f"{e.slug}.osm.pbf")
    paths = resolve_pbf_paths(_lines([(0.8, 0.5), (1.3, 0.5)]), cache_dir=tmp_path)
    assert sorted(p.name for p in paths) == ["east.osm.pbf", "west.osm.pbf"]


def test_parse_poly_with_hole() -> None:
    shell = ["1", "0 0", "10 0", "10 10", "0 10", "END"]
    hole = ["!2", "4 4", "6 4", "6 6", "4 6", "END"]
    text = "\n".join(["region", *shell, *hole, "END"])
    assert parse_poly(text).area == pytest.approx(100 - 4)


# ---------------------------------------------------------------------------
# local_pbf_for_bbox (clipping mocked)
# ---------------------------------------------------------------------------


def test_bbox_in_one_extract_is_clipped(fake_sources: list, tmp_path: Path) -> None:
    out = local_pbf_for_bbox([0.2, 0.2, 0.4, 0.4], cache_dir=tmp_path)
    assert out.parent == tmp_path / "clips"
    assert out.name.startswith("west-")
    assert fake_sources == [["west.osm.pbf"]]


def test_bbox_on_border_merges_two_extracts(fake_sources: list, tmp_path: Path) -> None:
    out = local_pbf_for_bbox([0.8, 0.2, 1.3, 0.4], cache_dir=tmp_path)
    assert out.name.startswith("east+west-")
    assert fake_sources == [["east.osm.pbf", "west.osm.pbf"]]


def test_more_than_max_merge_extracts_uses_netherlands(fake_sources: list, tmp_path: Path) -> None:
    out = local_pbf_for_bbox([0.5, 0.2, 2.5, 0.4], cache_dir=tmp_path)
    assert out.name.startswith("netherlands-")
    assert fake_sources == [["netherlands.osm.pbf"]]


@pytest.mark.usefixtures("fake_sources")
def test_uncovered_bbox_raises(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="not covered"):
        local_pbf_for_bbox([2.5, 0.2, 5.0, 0.4], cache_dir=tmp_path)


def test_clip_is_cached_and_remade_when_source_is_newer(fake_sources: list, tmp_path: Path) -> None:
    bbox = [0.2, 0.2, 0.4, 0.4]
    first = local_pbf_for_bbox(bbox, cache_dir=tmp_path)
    assert local_pbf_for_bbox(bbox, cache_dir=tmp_path) == first
    assert len(fake_sources) == 1

    src = tmp_path / "west.osm.pbf"
    newer = first.stat().st_mtime + 10
    os.utime(src, (newer, newer))
    local_pbf_for_bbox(bbox, cache_dir=tmp_path)
    assert len(fake_sources) == 2


def test_explicit_path_wins_and_is_clipped(
    fake_sources: list, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    explicit = tmp_path / "custom.osm.pbf"
    explicit.write_bytes(b"pbf")
    monkeypatch.setenv("OSM_PBF_PATH", str(explicit))
    out = local_pbf_for_bbox([0.8, 0.2, 1.3, 0.4], cache_dir=tmp_path)
    assert out.name.startswith("custom-")
    assert fake_sources == [["custom.osm.pbf"]]


def test_explicit_province_not_covering_bbox_is_ignored(
    fake_sources: list, monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    # A fixed "west" snapshot for a bbox that reaches into "east".
    explicit = tmp_path / "west-260903-internal.osm.pbf"
    explicit.write_bytes(b"pbf")
    monkeypatch.setenv("OSM_PBF_PATH", str(explicit))
    out = local_pbf_for_bbox([0.8, 0.2, 1.3, 0.4], cache_dir=tmp_path)
    assert out.name.startswith("east+west-")
    assert fake_sources == [["east.osm.pbf", "west.osm.pbf"]]


@pytest.mark.usefixtures("fake_polys")
def test_explicit_pbf_covers_bbox_by_extract_name(tmp_path: Path) -> None:
    west = tmp_path / "west-latest.osm.pbf"
    assert geofabrik.explicit_pbf_covers_bbox(west, [0.2, 0.2, 0.4, 0.4]) is True
    assert geofabrik.explicit_pbf_covers_bbox(west, [0.8, 0.2, 1.3, 0.4]) is False
    nl = tmp_path / "netherlands-latest.osm.pbf"
    assert geofabrik.explicit_pbf_covers_bbox(nl, [0.8, 0.2, 2.5, 0.4]) is True


def test_explicit_pbf_covers_bbox_unknown(tmp_path: Path) -> None:
    unknown = tmp_path / "custom.osm.pbf"
    unknown.write_bytes(b"not a pbf")
    assert geofabrik.explicit_pbf_covers_bbox(unknown, [0.2, 0.2, 0.4, 0.4]) is None


@pytest.mark.usefixtures("fake_sources")
def test_failed_clip_falls_back_to_single_source(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(geofabrik, "_make_clip", _raise_import_error)
    out = local_pbf_for_bbox([0.2, 0.2, 0.4, 0.4], cache_dir=tmp_path)
    assert out == tmp_path / "west.osm.pbf"


@pytest.mark.usefixtures("fake_sources")
def test_failed_merge_falls_back_to_netherlands(
    monkeypatch: pytest.MonkeyPatch, tmp_path: Path
) -> None:
    monkeypatch.setattr(geofabrik, "_make_clip", _raise_import_error)
    out = local_pbf_for_bbox([0.8, 0.2, 1.3, 0.4], cache_dir=tmp_path)
    assert out == tmp_path / "netherlands.osm.pbf"


def _raise_import_error(*_args: object) -> None:
    raise ImportError("No module named 'osmium'")


def test_prune_clips_removes_old_files(tmp_path: Path) -> None:
    old, fresh = tmp_path / "old-1.osm.pbf", tmp_path / "fresh-1.osm.pbf"
    for p in (old, fresh):
        p.write_bytes(b"clip")
    os.utime(old, (0, 0))
    geofabrik._prune_clips(tmp_path)
    assert not old.exists()
    assert fresh.exists()


# ---------------------------------------------------------------------------
# Real clipping and merging (pyosmium)
# ---------------------------------------------------------------------------


def _write_pbf(path: Path, nodes: dict, ways: dict, relations: dict | None = None) -> Path:
    import osmium
    from osmium.osm.mutable import Node, Relation, Way

    with osmium.SimpleWriter(str(path)) as writer:
        for nid, loc in sorted(nodes.items()):
            writer.add_node(Node(id=nid, location=loc, version=1, tags={}))
        for wid, refs in sorted(ways.items()):
            writer.add_way(Way(id=wid, nodes=refs, version=1, tags={"highway": "road"}))
        for rid, members in sorted((relations or {}).items()):
            writer.add_relation(
                Relation(
                    id=rid,
                    members=members,
                    version=1,
                    tags={"type": "multipolygon", "natural": "wood"},
                )
            )
    return path


def _contents(path: Path) -> dict[str, set[int]]:
    import osmium

    out: dict[str, set[int]] = {"n": set(), "w": set(), "r": set()}
    for obj in osmium.FileProcessor(str(path)):
        out[obj.type_str()].add(obj.id)
    return out


_NODES_WEST = {1: (0.10, 0.5), 2: (0.95, 0.5), 3: (1.05, 0.5), 4: (0.10, 0.9), 5: (0.2, 0.9)}
_NODES_EAST = {2: (0.95, 0.5), 3: (1.05, 0.5), 6: (1.90, 0.5), 7: (1.5, 0.1), 8: (1.6, 0.1)}
#: way 10 crosses the border and is present (complete) in both extracts.
_WAYS_WEST = {10: [1, 2, 3], 11: [4, 5]}
_WAYS_EAST = {10: [1, 2, 3], 12: [3, 6], 13: [7, 8]}


def test_node_ids_in_bbox_matches_pyosmium(tmp_path: Path) -> None:
    pytest.importorskip("osmium")
    src = _write_pbf(tmp_path / "west.osm.pbf", _NODES_WEST, _WAYS_WEST)
    ids = geofabrik._node_ids_in_bbox(src, (0.0, 0.4, 1.0, 0.6))
    assert sorted(ids.tolist()) == [1, 2]


def test_clip_keeps_complete_ways_and_multipolygons(tmp_path: Path) -> None:
    pytest.importorskip("osmium")
    src = _write_pbf(
        tmp_path / "west.osm.pbf",
        {**_NODES_WEST, 20: (0.8, 0.9), 21: (0.9, 0.95)},
        {**_WAYS_WEST, 30: [20, 21, 4]},
        {40: [("w", 30, "outer")]},
    )
    out = geofabrik.clip_pbf_to_bbox(src, [0.85, 0.45, 1.0, 0.55], tmp_path / "c.osm.pbf", 0.0)
    got = _contents(out)
    # way 10 touches the bbox (node 2) and keeps all its nodes, also node 1 outside.
    assert got["w"] == {10}
    assert got["n"] == {1, 2, 3}
    assert got["r"] == set()

    out = geofabrik.clip_pbf_to_bbox(src, [0.75, 0.85, 0.85, 0.95], tmp_path / "d.osm.pbf", 0.0)
    got = _contents(out)
    assert got["r"] == {40}
    assert got["w"] == {30}
    assert got["n"] == {20, 21, 4}


def test_clip_and_merge_two_extracts(tmp_path: Path) -> None:
    pytest.importorskip("osmium")
    from gmt_shared._osm_pbf import fetch_from_pbf

    west = _write_pbf(tmp_path / "west.osm.pbf", _NODES_WEST, _WAYS_WEST)
    east = _write_pbf(tmp_path / "east.osm.pbf", _NODES_EAST, _WAYS_EAST)
    out = tmp_path / "clips" / "merged.osm.pbf"
    geofabrik._make_clip([west, east], [0.5, 0.3, 1.95, 0.7], out)

    got = _contents(out)
    assert got["w"] == {10, 12}  # 11 and 13 are outside the bbox
    assert got["n"] == {1, 2, 3, 6}
    assert not list(out.parent.glob("*.part*"))

    resp = fetch_from_pbf('way["highway"](0.3,0.5,0.7,1.95);out geom;', out)
    assert sorted(e["id"] for e in resp["elements"]) == [10, 12]
