"""Geofabrik ``.osm.pbf`` extracts: selection, download and per-bbox clipping.

Only the smallest ("leaf") extracts are downloaded: Dutch provinces plus the
neighbouring Belgian / German extracts.  When an area straddles the border of
two extracts, *both* are used instead of escalating to a larger extract (e.g.
``netherlands``); the country extract is only a fallback.

Files are cached in ``$OSM_PBF_CACHE_DIR`` (default ``<tempdir>/geofabrik_pbf``)
as ``<slug>.poly`` / ``<slug>.osm.pbf``; bbox clips live in ``clips/``.

Public API
----------
local_pbf_for_bbox(bbox, *, osm_path, cache_dir, max_merge) -> Path
    A small, cached cut-out of the local OSM data for *bbox*: clipped from one
    leaf extract, from the merge of two, from the Netherlands extract (fallback)
    or from an explicit ``osm_path`` / ``OSM_PBF_PATH``.  Clipping needs
    pyosmium (``gmt-shared[osm]``); without it the source file is returned.
resolve_pbf_paths(geometry, *, cache_dir) -> list[Path]
    The (downloaded) leaf extracts that together cover *geometry*, unclipped.
select_extracts(geometry, *, cache_dir, extracts) -> list[Extract]
    The smallest set of leaf extracts covering *geometry* (greedy set cover).
clip_pbf_to_bbox(src, bbox, out_path, buffer_deg) -> Path
    Write a reference-complete cut-out of *src* (needs pyosmium).
"""

from __future__ import annotations

import hashlib
import logging
import os
import tempfile
import threading
import time
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from gmt_shared._osm_pbf_reader import _read_varint, _skip, iter_block_frames, read_blob

if TYPE_CHECKING:
    from collections.abc import Callable, Iterable, Iterator, Sequence

logger = logging.getLogger(__name__)

GEOFABRIK_BASE = "https://download.geofabrik.de"
OSM_PBF_CACHE_DIR_ENV_VAR = "OSM_PBF_CACHE_DIR"

#: Remaining uncovered size (degrees for lines, degrees² for areas) treated as
#: fully covered.
_COVER_TOLERANCE = 1e-7

#: Margin (degrees, ~1 km) added around the bbox when clipping, so a query bbox
#: slightly larger than the requested one stays inside the clip.
CLIP_BUFFER_DEG = 0.01

#: Clips not used for this long are removed from ``clips/``.
CLIP_MAX_AGE_S = 30 * 24 * 3600

#: Relation types kept (with all members) in a clip.  The OSM fetchers only
#: query multipolygon relations (natural=wood, landuse=forest); boundary/route
#: relations would drag in hundreds of kilometres of member ways.
_CLIP_RELATION_TYPES = frozenset({"multipolygon"})


@dataclass(frozen=True)
class Extract:
    slug: str
    path: str

    @property
    def poly_url(self) -> str:
        return f"{GEOFABRIK_BASE}/{self.path}.poly"

    @property
    def pbf_url(self) -> str:
        return f"{GEOFABRIK_BASE}/{self.path}-latest.osm.pbf"


#: Leaf extracts only — never a country that is itself split into regions here.
LEAF_EXTRACTS: tuple[Extract, ...] = (
    Extract("drenthe", "europe/netherlands/drenthe"),
    Extract("flevoland", "europe/netherlands/flevoland"),
    Extract("friesland", "europe/netherlands/friesland"),
    Extract("gelderland", "europe/netherlands/gelderland"),
    Extract("groningen", "europe/netherlands/groningen"),
    Extract("limburg", "europe/netherlands/limburg"),
    Extract("noord-brabant", "europe/netherlands/noord-brabant"),
    Extract("noord-holland", "europe/netherlands/noord-holland"),
    Extract("overijssel", "europe/netherlands/overijssel"),
    Extract("utrecht", "europe/netherlands/utrecht"),
    Extract("zeeland", "europe/netherlands/zeeland"),
    Extract("zuid-holland", "europe/netherlands/zuid-holland"),
    Extract("belgium", "europe/belgium"),
    Extract("niedersachsen", "europe/germany/niedersachsen"),
    Extract("nordrhein-westfalen", "europe/germany/nordrhein-westfalen"),
)

#: Fallback when an area needs more than ``max_merge`` leaf extracts.
NETHERLANDS = Extract("netherlands", "europe/netherlands")


def default_cache_dir() -> Path:
    env = os.environ.get(OSM_PBF_CACHE_DIR_ENV_VAR, "").strip()
    return Path(env) if env else Path(tempfile.gettempdir()) / "geofabrik_pbf"


def _log(msg: str) -> None:
    logger.info(msg)
    print(f"  [geofabrik] {msg}", flush=True)


_locks: dict[Path, threading.Lock] = {}
_locks_guard = threading.Lock()


def _lock_for(path: Path) -> threading.Lock:
    """Per-path lock: concurrent jobs wait for one download/clip of the same file."""
    with _locks_guard:
        return _locks.setdefault(path.resolve(), threading.Lock())


def _tmp_path(dest: Path) -> Path:
    """Process-unique temp name next to *dest*, keeping the ``.osm.pbf`` suffix."""
    return dest.with_name(f"{dest.name}.{os.getpid()}.{threading.get_ident()}.tmp.osm.pbf")


# ---------------------------------------------------------------------------
# I/O (module-level so tests can monkeypatch them)
# ---------------------------------------------------------------------------


def _download(url: str, dest: Path, timeout: int = 600) -> None:
    """Stream *url* to *dest* atomically (via a temp file)."""
    dest.parent.mkdir(parents=True, exist_ok=True)
    part = _tmp_path(dest)
    _log(f"downloading {url}")
    request = urllib.request.Request(url, headers={"User-Agent": "gmt-shared-geofabrik/1.0"})
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp, part.open("wb") as fh:
            while chunk := resp.read(1 << 20):
                fh.write(chunk)
        part.replace(dest)
    finally:
        part.unlink(missing_ok=True)


def parse_poly(text: str) -> Any:
    """Parse an Osmosis/Geofabrik ``.poly`` file into a shapely geometry.

    Rings whose header starts with ``!`` are holes of the preceding ring.
    """
    from shapely.geometry import MultiPolygon, Polygon

    lines = [ln.strip() for ln in text.strip().splitlines()]
    shells: list[tuple[list, list]] = []
    idx = 1  # first line is the region name
    while idx < len(lines):
        header = lines[idx]
        idx += 1
        if header == "END":
            break
        if not header:
            continue
        ring: list[tuple[float, float]] = []
        while idx < len(lines) and lines[idx] != "END":
            parts = lines[idx].split()
            idx += 1
            if len(parts) >= 2:
                ring.append((float(parts[0]), float(parts[1])))
        idx += 1  # skip ring END
        if len(ring) < 3:
            continue
        if header.startswith("!") and shells:
            shells[-1][1].append(ring)
        else:
            shells.append((ring, []))
    if not shells:
        raise ValueError("no valid rings found in .poly file")
    polygons = [Polygon(shell, holes) for shell, holes in shells]
    return polygons[0] if len(polygons) == 1 else MultiPolygon(polygons)


def load_poly(extract: Extract, cache_dir: Path) -> Any:
    path = cache_dir / f"{extract.slug}.poly"
    with _lock_for(path):
        if not path.is_file():
            _download(extract.poly_url, path, timeout=60)
    return parse_poly(path.read_text(encoding="utf-8"))


def ensure_pbf(extract: Extract, cache_dir: Path) -> Path:
    """Return the cached ``.osm.pbf`` of *extract*, downloading it when missing."""
    path = cache_dir / f"{extract.slug}.osm.pbf"
    with _lock_for(path):
        if not path.is_file():
            _download(extract.pbf_url, path)
    return path


# ---------------------------------------------------------------------------
# Extract selection
# ---------------------------------------------------------------------------


def _size(geometry: Any) -> float:
    """Area for polygons (a bbox), length for lines (link geometries)."""
    return float(geometry.area if geometry.area > 0.0 else geometry.length)


def select_extracts(
    geometry: Any,
    *,
    cache_dir: Path | None = None,
    extracts: Iterable[Extract] | None = None,
) -> list[Extract]:
    """Return the smallest set of leaf extracts that together cover *geometry*.

    Greedy set cover: repeatedly take the extract that covers most of the
    still-uncovered part (length of link geometries, or area of a bbox).

    Raises
    ------
    ValueError:
        When part of *geometry* lies outside every known extract.
    """
    cache_dir = cache_dir or default_cache_dir()
    extracts = LEAF_EXTRACTS if extracts is None else extracts
    candidates = []
    for extract in extracts:
        poly = load_poly(extract, cache_dir)
        if poly.intersects(geometry):
            candidates.append((extract, poly))

    remaining = geometry
    chosen: list[Extract] = []
    while not remaining.is_empty and _size(remaining) > _COVER_TOLERANCE:
        best = max(
            candidates,
            key=lambda c: _size(remaining.intersection(c[1])),
            default=None,
        )
        if best is None or _size(remaining.intersection(best[1])) <= 0.0:
            b = remaining.bounds
            raise ValueError(
                "Area is not fully covered by the known Geofabrik extracts; "
                f"uncovered part within bbox ({b[0]:.5f}, {b[1]:.5f}, {b[2]:.5f}, {b[3]:.5f})."
            )
        chosen.append(best[0])
        candidates.remove(best)
        remaining = remaining.difference(best[1])
    return chosen


def resolve_pbf_paths(
    geometry: Any,
    *,
    cache_dir: Path | str | None = None,
) -> list[Path]:
    """Select, download (if needed) and return the local PBF files for *geometry*."""
    cache = Path(cache_dir) if cache_dir else default_cache_dir()
    chosen = select_extracts(geometry, cache_dir=cache)
    _log(f"extracts: {', '.join(e.slug for e in chosen)}")
    return [ensure_pbf(e, cache) for e in chosen]


def _extracts_for_bbox(bbox: Sequence[float], cache_dir: Path, max_merge: int) -> list[Extract]:
    """Leaf extracts covering *bbox* (at most *max_merge*), else the Netherlands."""
    area = _bbox_polygon(bbox)
    try:
        chosen = select_extracts(area, cache_dir=cache_dir)
        if len(chosen) <= max_merge:
            return sorted(chosen, key=lambda e: e.slug)  # stable clip cache key
        reason = f"{len(chosen)} extracts needed ({', '.join(e.slug for e in chosen)})"
    except ValueError as exc:
        reason = str(exc)
    if load_poly(NETHERLANDS, cache_dir).covers(area):
        _log(f"{reason}; using {NETHERLANDS.slug}")
        return [NETHERLANDS]
    raise ValueError(f"bbox {list(bbox)} is not covered by the known Geofabrik extracts: {reason}")


# ---------------------------------------------------------------------------
# Clipping
# ---------------------------------------------------------------------------


def _np_varints(buf: bytes) -> Any:
    """Decode a packed run of protobuf varints into a ``uint64`` array."""
    import numpy as np

    b = np.frombuffer(buf, np.uint8)
    ends = np.flatnonzero(b < 0x80)
    starts = np.empty_like(ends)
    starts[0] = 0
    starts[1:] = ends[:-1] + 1
    lengths = ends - starts + 1
    vals = (b[starts] & 0x7F).astype(np.uint64)
    for k in range(1, int(lengths.max())):
        m = lengths > k
        vals[m] |= (b[starts[m] + k] & 0x7F).astype(np.uint64) << np.uint64(7 * k)
    return vals


def _np_delta(buf: bytes) -> Any:
    """Decode packed zig-zag deltas (DenseNodes id/lat/lon) into absolute ``int64`` values."""
    import numpy as np

    v = _np_varints(buf)
    signed = (v >> np.uint64(1)).astype(np.int64) ^ -(v & np.uint64(1)).astype(np.int64)
    return np.cumsum(signed)


def _fields(buf: bytes, pos: int, end: int) -> Iterator[tuple[int, int, Any]]:
    """Yield ``(field, wire, value)`` of a protobuf message; value is a span for wire 2."""
    while pos < end:
        tag, pos = _read_varint(buf, pos)
        field, wire = tag >> 3, tag & 7
        if wire == 2:
            ln, pos = _read_varint(buf, pos)
            yield field, wire, (pos, pos + ln)
            pos += ln
        elif wire == 0:
            value, pos = _read_varint(buf, pos)
            yield field, wire, value
        else:
            pos = _skip(buf, pos, wire)


def _node_ids_in_bbox(path: Path, bbox: Sequence[float]) -> Any:
    """Return the ids of all nodes of *path* inside *bbox* ``(w, s, e, n)``.

    Decodes the DenseNodes groups with numpy.  In a file sorted by type and id
    (Geofabrik, osmium output) the scan stops at the first block without nodes.
    """
    import numpy as np

    w, s, e, n = bbox
    found = []
    sorted_file = False
    with path.open("rb") as fh:
        for blob_type, offset, datasize in list(iter_block_frames(fh)):
            raw = read_blob(fh, offset, datasize)
            if blob_type == "OSMHeader":
                # optional_features (5): "Sort.Type_then_ID"
                sorted_file = any(
                    f == 5 and raw[v[0] : v[1]] == b"Sort.Type_then_ID"
                    for f, _w, v in _fields(raw, 0, len(raw))
                )
                continue
            if blob_type != "OSMData":
                continue
            granularity, lat_offset, lon_offset, groups = 100, 0, 0, []
            for f, _w, v in _fields(raw, 0, len(raw)):
                if f == 2:
                    groups.append(v)
                elif f == 17:
                    granularity = v
                elif f == 19:
                    lat_offset = _as_int64(v)
                elif f == 20:
                    lon_offset = _as_int64(v)
            has_nodes = False
            for gpos, gend in groups:
                for f, wire, span in _fields(raw, gpos, gend):
                    if f != 2 or wire != 2:  # only DenseNodes
                        continue
                    has_nodes = True
                    packed = {
                        df: raw[dv[0] : dv[1]]
                        for df, dw, dv in _fields(raw, *span)
                        if dw == 2 and df in (1, 8, 9)
                    }
                    if 1 not in packed:
                        continue
                    ids = _np_delta(packed[1])
                    lat = (lat_offset + granularity * _np_delta(packed[8])) * 1e-9
                    lon = (lon_offset + granularity * _np_delta(packed[9])) * 1e-9
                    found.append(ids[(lon >= w) & (lon <= e) & (lat >= s) & (lat <= n)])
            if sorted_file and not has_nodes:
                break
    return np.concatenate(found) if found else np.empty(0, np.int64)


def _as_int64(v: int) -> int:
    """``lat_offset``/``lon_offset`` are plain int64 varints (two's complement)."""
    return v - (1 << 64) if v >= 1 << 63 else v


def clip_pbf_to_bbox(
    src: Path,
    bbox: Sequence[float],
    out_path: Path,
    buffer_deg: float = CLIP_BUFFER_DEG,
) -> Path:
    """Write a reference-complete cut-out of *src* for the (buffered) bbox.

    Same semantics as Overpass ``out geom`` for the fetchers: every node in the
    bbox, every way with at least one node in the bbox (with *all* its nodes),
    and every multipolygon relation with a member in the bbox (with all member
    ways and their nodes).  Requires pyosmium.
    """
    import osmium

    min_lon, min_lat, max_lon, max_lat = bbox
    w, s = min_lon - buffer_deg, min_lat - buffer_deg
    e, n = max_lon + buffer_deg, max_lat + buffer_deg

    tracker = osmium.IdTracker()
    # 1. Nodes inside the bbox (vectorised; a pyosmium loop is ~40x slower).
    for node_id in _node_ids_in_bbox(src, (w, s, e, n)).tolist():
        tracker.add_node(node_id)
    # 2. Ways touching those nodes (C++ pass, no per-way Python).
    tracker.complete_forward_references(str(src), relation_depth=-1)
    # 3. Multipolygon relations with a tracked member, plus all their members.
    #    complete_backward_references() does not add member ways of tracked
    #    relations (pyosmium 4.3), so that is done here.
    for rel in osmium.FileProcessor(str(src), osmium.osm.RELATION):
        if rel.tags.get("type") in _CLIP_RELATION_TYPES and tracker.contains_any_references(rel):
            tracker.add_relation(rel.id)
            for member in rel.members:  # type: ignore[union-attr]
                if member.type == "w":
                    tracker.add_way(member.ref)
                elif member.type == "n":
                    tracker.add_node(member.ref)
    # 4. Complete: all nodes of all tracked ways.
    tracker.complete_backward_references(str(src), relation_depth=0)

    out_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_path(out_path)
    try:
        with osmium.SimpleWriter(str(tmp)) as writer:
            for obj in osmium.FileProcessor(str(src)).with_filter(tracker.id_filter()):
                writer.add(obj)
        os.replace(tmp, out_path)
    finally:
        tmp.unlink(missing_ok=True)
    return out_path


def merge_pbfs(inputs: Sequence[Path], out_path: Path) -> Path:
    """Merge PBF files into one sorted file, de-duplicating objects by (type, id).

    Geofabrik extracts share global OSM ids and both contain border-crossing
    ways in full, so a plain union is correct.  Requires pyosmium.
    """
    import osmium

    reader = osmium.MergeInputReader()
    for path in inputs:
        reader.add_file(str(path))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tmp = _tmp_path(out_path)
    try:
        writer = osmium.WriteHandler(str(tmp))
        try:
            reader.apply(writer, simplify=True)
        finally:
            writer.close()
        os.replace(tmp, out_path)
    finally:
        tmp.unlink(missing_ok=True)
    return out_path


def clip_cache_path(
    sources: Sequence[Path], bbox: Sequence[float], label: str, cache_dir: Path
) -> Path:
    """Return the cache path of the clip of *sources* for *bbox*."""
    key = "|".join(str(p.resolve()) for p in sources)
    key += "|" + "_".join(f"{v:.4f}" for v in bbox)
    digest = hashlib.sha1(key.encode()).hexdigest()[:12]  # noqa: S324 — cache key only
    return cache_dir / "clips" / f"{label}-{digest}.osm.pbf"


def _prune_clips(clips_dir: Path, max_age_s: float = CLIP_MAX_AGE_S) -> None:
    """Remove clips unused for *max_age_s* and temp files older than a day."""
    now = time.time()
    for path in clips_dir.glob("*.osm.pbf"):
        limit = 24 * 3600 if path.name.endswith(".tmp.osm.pbf") else max_age_s
        try:
            if now - path.stat().st_mtime > limit:
                path.unlink()
        except OSError:
            pass  # in use by another process, or already gone


def _make_clip(sources: Sequence[Path], bbox: Sequence[float], out_path: Path) -> None:
    if len(sources) == 1:
        clip_pbf_to_bbox(sources[0], bbox, out_path)
        return
    parts = [out_path.with_name(f"{out_path.name}.part{i}.osm.pbf") for i in range(len(sources))]
    try:
        for src, part in zip(sources, parts, strict=True):
            clip_pbf_to_bbox(src, bbox, part)
        merge_pbfs(parts, out_path)
    finally:
        for part in parts:
            part.unlink(missing_ok=True)


def _clipped(
    sources: Sequence[Path],
    bbox: Sequence[float],
    label: str,
    cache_dir: Path,
    fallback: Callable[[], Path],
) -> Path:
    out_path = clip_cache_path(sources, bbox, label, cache_dir)
    with _lock_for(out_path):
        newest = max(p.stat().st_mtime for p in sources)
        if out_path.is_file() and out_path.stat().st_mtime >= newest:
            os.utime(out_path)  # mark as recently used for _prune_clips
            _log(f"uitsnede uit cache: {out_path.name}")
            return out_path
        try:
            started = time.monotonic()
            _log(f"uitsnede maken ({label}) voor bbox {[round(v, 5) for v in bbox]} ...")
            _make_clip(sources, bbox, out_path)
            _log(
                f"uitsnede klaar: {out_path.name} "
                f"({out_path.stat().st_size / 1e6:.1f} MB, {time.monotonic() - started:.0f}s)"
            )
        except Exception as exc:
            path = fallback()
            _log(f"uitsnede mislukt ({exc}); val terug op {path.name}")
            return path
    _prune_clips(out_path.parent)
    return out_path


def local_pbf_for_bbox(
    bbox: Sequence[float],
    *,
    osm_path: str | Path | None = None,
    cache_dir: Path | str | None = None,
    max_merge: int = 2,
) -> Path:
    """Return a small, cached ``.osm.pbf`` cut-out covering *bbox*.

    *bbox* is ``[min_lon, min_lat, max_lon, max_lat]`` (WGS-84).  Sources:

    1. An explicit *osm_path*, else the ``OSM_PBF_PATH`` environment variable —
       unless it demonstrably does not cover the bbox (see
       :func:`explicit_pbf_covers_bbox`), e.g. a fixed province snapshot used
       for an area elsewhere.
    2. Otherwise the leaf extracts covering the bbox — at most *max_merge*
       (two provinces on a border are clipped and merged) — else the
       Netherlands extract.  Missing extracts are downloaded.

    The clip is cached in ``<cache_dir>/clips`` and re-made when a source is
    newer.  When clipping is impossible (no pyosmium) or fails, a source that
    covers the whole bbox is returned instead.

    Raises
    ------
    ValueError:
        When an explicit path is invalid, or the bbox is not covered by the
        known extracts.
    """
    from gmt_shared.overpass import _resolve_pbf_path

    cache = Path(cache_dir) if cache_dir else default_cache_dir()
    bbox = [float(v) for v in bbox]

    explicit = _resolve_pbf_path(str(osm_path) if osm_path else None)
    if explicit is not None:
        if explicit_pbf_covers_bbox(explicit, bbox, cache_dir=cache) is not False:
            label = explicit.name.split(".")[0]
            return _clipped([explicit], bbox, label, cache, lambda: explicit)
        _log(f"{explicit.name} dekt bbox {bbox} niet; automatische Geofabrik-keuze")

    extracts = _extracts_for_bbox(bbox, cache, max_merge)
    _log(f"bbox {[round(v, 5) for v in bbox]} -> extracts: {', '.join(e.slug for e in extracts)}")
    sources = [ensure_pbf(e, cache) for e in extracts]

    def _fallback() -> Path:
        if len(sources) == 1:
            return sources[0]
        if not load_poly(NETHERLANDS, cache).covers(_bbox_polygon(bbox)):
            raise RuntimeError(
                "clipping/merging several extracts needs pyosmium (pip install gmt-shared[osm])"
            )
        return ensure_pbf(NETHERLANDS, cache)

    return _clipped(sources, bbox, "+".join(e.slug for e in extracts), cache, _fallback)


def explicit_pbf_covers_bbox(
    path: Path, bbox: Sequence[float], *, cache_dir: Path | None = None
) -> bool | None:
    """Best-effort check whether an explicitly configured PBF covers *bbox*.

    1. When the file name contains known extract slugs (``gelderland-260903-
       internal.osm.pbf``), the real borders of those extracts (Geofabrik
       ``.poly``) must cover the bbox.  Only this catches a bbox just across a
       province border: the bounding *boxes* of neighbouring provinces overlap.
    2. Otherwise the bounding box in the PBF header must cover the bbox.

    Returns None when neither can be determined (the caller trusts the file).
    """
    area = _bbox_polygon(bbox)
    name = path.name.lower()
    named = [e for e in (*LEAF_EXTRACTS, NETHERLANDS) if e.slug in name]
    if named:
        try:
            from shapely.ops import unary_union

            return bool(
                unary_union([load_poly(e, cache_dir or default_cache_dir()) for e in named]).covers(
                    area
                )
            )
        except Exception as exc:
            logger.warning("extract border check for %s failed: %s", path.name, exc)
    header = pbf_header_bbox(path)
    if header is None:
        return None
    margin = CLIP_BUFFER_DEG
    return bool(_bbox_polygon(header).buffer(margin, join_style="mitre").covers(area))


def pbf_header_bbox(path: Path) -> tuple[float, float, float, float] | None:
    """Return ``(min_lon, min_lat, max_lon, max_lat)`` from the PBF header, if present."""
    try:
        with path.open("rb") as fh:
            blob_type, offset, datasize = next(iter_block_frames(fh))
            if blob_type != "OSMHeader":
                return None
            raw = read_blob(fh, offset, datasize)
        for field, wire, span in _fields(raw, 0, len(raw)):
            if field == 1 and wire == 2:  # HeaderBBox: left/right/top/bottom (sint64, nano°)
                v = {f: (x >> 1) ^ -(x & 1) for f, w, x in _fields(raw, *span) if w == 0}
                if all(k in v for k in (1, 2, 3, 4)):
                    return (v[1] * 1e-9, v[4] * 1e-9, v[2] * 1e-9, v[3] * 1e-9)
    except Exception:  # unreadable or not a PBF: coverage unknown
        return None
    return None


def _bbox_polygon(bbox: Sequence[float]) -> Any:
    from shapely.geometry import box

    return box(*bbox)
