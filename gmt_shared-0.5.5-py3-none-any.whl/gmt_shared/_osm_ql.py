"""Minimal Overpass QL parser — translates the QL subset emitted by this repo's
``build_*_query`` helpers into a structured selector list the local ``.osm.pbf``
backend (:mod:`shared._osm_pbf`) can evaluate.

This is deliberately *not* a general Overpass QL implementation.  It supports
exactly the constructs produced by the query builders in the ``osm*`` /
``*_fetcher`` / ``*_annotator`` modules:

* a ``[out:json][timeout:N];`` header (ignored),
* an optional union block ``( ... );`` around one or more statements,
* one or more bare statements ``{node|way|relation}<selectors>(<bbox>);``,
* an optional recurse-down ``(._;>;);`` (ignored — the network splitter rebuilds
  intersections from each way's ``nodes`` id-list, so standalone nodes are not
  needed),
* a terminator ``out geom;`` or ``out body;`` (ignored).

Selectors understood inside ``[ ... ]``:

* ``["key"="value"]``   — equality
* ``["key"~"regex"]``   — regex match (Python :mod:`re`)
* ``["key"]``           — key present (any value)
* ``[!"key"]``          — key absent

The bbox is the Overpass ``(south,west,north,east)`` order (lat/lon).

Any construct outside this subset raises :class:`NotImplementedError` so a
mis-parsed query fails loudly rather than silently returning wrong data.

Public API
----------
parse_overpass_ql(query) -> list[Selector]
    Parse a QL string into a list of :class:`Selector`.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field

#: Filter operators.
OP_EQ = "="
OP_REGEX = "~"
OP_EXISTS = "exists"
OP_ABSENT = "absent"

_KINDS = ("node", "way", "relation")


@dataclass(frozen=True)
class Filter:
    """A single tag filter, e.g. ``("highway", "=", "crossing")``."""

    key: str
    op: str
    value: str | None = None

    def matches(self, tags: dict[str, str]) -> bool:
        """Return True when *tags* satisfies this filter."""
        if self.op == OP_EXISTS:
            return self.key in tags
        if self.op == OP_ABSENT:
            return self.key not in tags
        actual = tags.get(self.key)
        if actual is None:
            return False
        if self.op == OP_EQ:
            return actual == self.value
        if self.op == OP_REGEX:
            return re.search(self.value or "", actual) is not None
        raise NotImplementedError(f"Unsupported filter op: {self.op!r}")


@dataclass(frozen=True)
class Selector:
    """A single ``{node|way|relation}`` statement with its filters and bbox."""

    kind: str
    filters: list[Filter] = field(default_factory=list)
    #: ``(south, west, north, east)`` in WGS-84, or None when no bbox given.
    bbox: tuple[float, float, float, float] | None = None

    def matches(self, tags: dict[str, str]) -> bool:
        """Return True when every filter matches *tags*."""
        return all(f.matches(tags) for f in self.filters)


def _strip_comments(query: str) -> str:
    """Remove ``/* ... */`` block comments."""
    return re.sub(r"/\*.*?\*/", " ", query, flags=re.DOTALL)


def _split_statements(text: str) -> list[str]:
    """Split *text* on ``;`` that is not inside a double-quoted string.

    Union / recurse parentheses are left in place; they are stripped per
    fragment by the caller.  Bbox parentheses stay attached to their statement.
    """
    fragments: list[str] = []
    buf: list[str] = []
    in_quote = False
    escape = False
    for ch in text:
        if escape:
            buf.append(ch)
            escape = False
            continue
        if ch == "\\":
            buf.append(ch)
            escape = True
            continue
        if ch == '"':
            in_quote = not in_quote
            buf.append(ch)
            continue
        if ch == ";" and not in_quote:
            frag = "".join(buf).strip()
            if frag:
                fragments.append(frag)
            buf = []
            continue
        buf.append(ch)
    frag = "".join(buf).strip()
    if frag:
        fragments.append(frag)
    return fragments


def _strip_union_parens(fragment: str) -> str:
    """Remove an unmatched leading union ``(`` from a ``;``-split fragment.

    A well-formed statement has balanced parentheses (its bbox group).  A
    fragment that opens a union block carries one extra leading ``(`` which is
    not part of any statement, so we drop it.  A fragment that is only a closing
    ``)`` (the end of a union block) collapses to empty.
    """
    frag = fragment.strip()
    while frag.startswith("(") and frag.count("(") > frag.count(")"):
        frag = frag[1:].strip()
    # A trailing unmatched ')' closes a union block — drop it.
    while frag.endswith(")") and frag.count(")") > frag.count("("):
        frag = frag[:-1].strip()
    return frag


def _parse_filters(selector_text: str) -> list[Filter]:
    """Parse the concatenated ``[ ... ]`` groups of one statement."""
    filters: list[Filter] = []
    for raw in _iter_bracket_groups(selector_text):
        inner = raw.strip()
        if not inner:
            continue
        # [!"key"] — absent
        m = re.fullmatch(r'!\s*"([^"]+)"', inner)
        if m:
            filters.append(Filter(m.group(1), OP_ABSENT))
            continue
        # ["key"="value"] or ["key"~"regex"]
        m = re.fullmatch(r'"([^"]+)"\s*([=~])\s*"(.*)"', inner, flags=re.DOTALL)
        if m:
            op = OP_EQ if m.group(2) == "=" else OP_REGEX
            filters.append(Filter(m.group(1), op, m.group(3)))
            continue
        # ["key"] — present
        m = re.fullmatch(r'"([^"]+)"', inner)
        if m:
            filters.append(Filter(m.group(1), OP_EXISTS))
            continue
        raise NotImplementedError(f"Unsupported selector: [{inner}]")
    return filters


def _iter_bracket_groups(text: str) -> list[str]:
    """Yield the contents of each top-level ``[ ... ]`` group (quote-aware)."""
    groups: list[str] = []
    depth = 0
    buf: list[str] = []
    in_quote = False
    escape = False
    for ch in text:
        if escape:
            buf.append(ch)
            escape = False
            continue
        if ch == "\\":
            buf.append(ch)
            escape = True
            continue
        if ch == '"':
            in_quote = not in_quote
            buf.append(ch)
            continue
        if not in_quote and ch == "[":
            depth += 1
            if depth == 1:
                buf = []
                continue
        if not in_quote and ch == "]":
            depth -= 1
            if depth == 0:
                groups.append("".join(buf))
                buf = []
                continue
        if depth >= 1:
            buf.append(ch)
    return groups


def _parse_bbox(text: str) -> tuple[float, float, float, float] | None:
    """Extract a trailing ``(s,w,n,e)`` bbox group from a statement, if present."""
    # Find the last top-level (...) group that contains only numbers/commas.
    m = re.search(r"\(([^()]*)\)\s*$", text)
    if not m:
        return None
    parts = [p.strip() for p in m.group(1).split(",")]
    if len(parts) != 4:
        raise NotImplementedError(f"Unsupported bbox group: ({m.group(1)})")
    try:
        s, w, n, e = (float(p) for p in parts)
    except ValueError as exc:
        raise NotImplementedError(f"Unsupported bbox group: ({m.group(1)})") from exc
    return (s, w, n, e)


def _parse_statement(fragment: str) -> Selector | None:
    """Parse a single statement fragment into a :class:`Selector`.

    Returns None for ignorable control fragments (``._``, ``>``, ``out ...``).
    """
    frag = fragment.strip()
    if not frag:
        return None
    # Ignore recurse-down / recurse tokens and the output terminator.
    if frag in ("._", ">", "<", "._;>"):
        return None
    if frag.split()[0] == "out":  # 'out geom', 'out body', ...
        return None

    m = re.match(r"^(node|way|relation)\b", frag)
    if not m:
        raise NotImplementedError(f"Unsupported statement: {frag!r}")
    kind = m.group(1)
    rest = frag[m.end() :]

    bbox = _parse_bbox(rest)
    if bbox is not None:
        rest = re.sub(r"\([^()]*\)\s*$", "", rest)
    filters = _parse_filters(rest)
    return Selector(kind=kind, filters=filters, bbox=bbox)


def parse_overpass_ql(query: str) -> list[Selector]:
    """Parse an Overpass QL *query* into a list of :class:`Selector`.

    Raises
    ------
    NotImplementedError:
        When the query uses a construct outside the supported subset.
    """
    text = _strip_comments(query)
    fragments = _split_statements(text)
    selectors: list[Selector] = []
    for frag in fragments:
        stripped = _strip_union_parens(frag)
        if not stripped:
            continue
        # Settings header: leading [out:...] / [timeout:...] with no kind.
        if stripped.startswith("[") and not re.match(r"^(node|way|relation)", stripped):
            continue
        # Recurse-down union artefacts.
        if stripped in ("._", ">", "<"):
            continue
        sel = _parse_statement(stripped)
        if sel is not None:
            selectors.append(sel)
    if not selectors:
        raise NotImplementedError("No supported statements found in query")
    return selectors
