"""Pure-Python bag_fetcher core — fetches BAG pand bouwjaar, merges onto buildings.

Fetches Dutch BAG (Basisregistratie Adressen en Gebouwen) ``pand`` features
for a bounding box from the PDOK BAG OGC API Features service, then merges
the construction year (``bouwjaar``) onto an existing OSM-derived buildings
FeatureCollection (e.g. the output of
``osm.osm_building_fetcher.build_buildings``).

Matching a building to its BAG pand is tried in two steps:

1. **By id** — the OSM building's ``ref:bag`` tag (stored under the
   ``tag_ref:bag`` property by ``osm_building_fetcher``, which preserves
   every original OSM tag with a ``tag_`` prefix) equals a BAG pand's
   ``identificatie``.  Exact and cheap, but only works when OSM carries the
   tag.
2. **By geometry** — when there is no id match, the building's centroid is
   tested against every BAG pand polygon via a ``shapely.STRtree`` spatial
   index; the pand whose polygon contains the centroid wins.

BAG ``bouwjaar`` uses ``9999`` as a sentinel for "unknown"; it is normalised
to ``None`` on fetch. The BAG OGC API has no ``eind_registratie``-style
"current version" filter like BGT, so ``current_only=False`` is always
passed to the shared OGC client.

The service serves GeoJSON in CRS84 (WGS-84 lon/lat), so no reprojection is
needed.  BAG only covers the Netherlands: outside NL, fetching is skipped.

Public API
----------
fetch_bag_panden(bbox, *, url, timeout) -> tuple[dict, dict]
    Fetch BAG pand features (geometry + identificatie + bouwjaar) for a bbox.
merge_bag_bouwjaar(buildings_fc, bag_fc, *, ref_bag_property) -> tuple[dict, dict]
    Merge bouwjaar onto buildings_fc, by id then by centroid-in-polygon.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from gmt_shared.geo import is_netherlands

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

#: Bump to invalidate any cached BAG output.
BAG_QUERY_VER: int = 1

#: BAG collection id on the PDOK BAG OGC API Features (v2) service.
COLLECTION_PAND: str = "pand"

#: BAG's sentinel value for "construction year unknown".
BOUWJAAR_UNKNOWN: int = 9999

_BAG_URL_FALLBACK: str = "https://api.pdok.nl/kadaster/bag/ogc/v2"
DEFAULT_BAG_URL: str = os.environ.get("PDOK_BAG_URL", _BAG_URL_FALLBACK)

#: Property on an OSM building feature holding the BAG pand id.  Written by
#: osm_building_fetcher as ``tag_<osm-tag>`` for every original OSM tag, so
#: an OSM ``ref:bag`` tag ends up under this property name.
DEFAULT_REF_BAG_PROPERTY: str = "tag_ref:bag"


# ---------------------------------------------------------------------------
# Parsing
# ---------------------------------------------------------------------------


def parse_bouwjaar(raw: object) -> int | None:
    """Normalise a raw BAG ``bouwjaar`` value to an int, or None if unknown.

    Returns None for a missing value, an unparsable value, or the BAG
    sentinel ``9999`` ("onbekend").
    """
    if raw is None:
        return None
    if not isinstance(raw, int | float | str):
        return None
    try:
        year = int(raw)
    except (TypeError, ValueError):
        return None
    if year == BOUWJAAR_UNKNOWN:
        return None
    return year


def _pand_feature_properties(feature: dict) -> dict[str, Any]:
    """Return normalised ``{identificatie, bouwjaar}`` for a raw pand feature."""
    props = feature.get("properties") or {}
    return {
        "identificatie": props.get("identificatie"),
        "bouwjaar": parse_bouwjaar(props.get("bouwjaar")),
    }


# ---------------------------------------------------------------------------
# Fetch
# ---------------------------------------------------------------------------


def fetch_bag_panden(
    bbox: list[float],
    *,
    url: str | None = None,
    timeout: int = 60,
) -> tuple[dict, dict]:
    """Fetch BAG pand features (geometry + identificatie + bouwjaar) for bbox.

    Parameters
    ----------
    bbox:
        ``[minLon, minLat, maxLon, maxLat]`` in WGS-84.
    url:
        OGC API Features base URL.  Defaults to :data:`DEFAULT_BAG_URL`
        (``PDOK_BAG_URL`` env var or the public PDOK BAG v2 endpoint).
    timeout:
        HTTP request timeout in seconds (per page).

    Returns
    -------
    fc:
        A GeoJSON ``FeatureCollection`` of BAG pand Polygon features.  Every
        feature's properties are normalised to exactly ``identificatie``
        (str or None) and ``bouwjaar`` (int or None — ``9999`` mapped to
        None).
    stats:
        ``{"total": int, "source": "BAG" | "skipped"}``.  ``source`` is
        ``"skipped"`` when the bbox lies outside the Netherlands.
    """
    if not is_netherlands(bbox):
        logger.info("bbox centroid outside NL — skipping BAG fetch.")
        return (
            {
                "type": "FeatureCollection",
                "features": [],
                "properties": {"_qv": BAG_QUERY_VER, "source": "skipped"},
            },
            {"total": 0, "source": "skipped"},
        )

    from gmt_shared.ogc_features import fetch_collection_items

    base_url = url if url is not None else DEFAULT_BAG_URL
    raw_panden = fetch_collection_items(
        COLLECTION_PAND,
        bbox,
        url=base_url,
        timeout=timeout,
        # BAG has no eind_registratie-style "current version" field like BGT.
        current_only=False,
    )

    features = [
        {
            "type": "Feature",
            "geometry": feat.get("geometry"),
            "properties": _pand_feature_properties(feat),
        }
        for feat in raw_panden
    ]
    logger.info("BAG panden: %d", len(features))

    fc = {
        "type": "FeatureCollection",
        "features": features,
        "properties": {"_qv": BAG_QUERY_VER, "source": "BAG"},
    }
    stats = {"total": len(features), "source": "BAG"}
    return fc, stats


# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------


def merge_bag_bouwjaar(
    buildings_fc: dict,
    bag_fc: dict,
    *,
    ref_bag_property: str = DEFAULT_REF_BAG_PROPERTY,
) -> tuple[dict, dict]:
    """Merge BAG ``bouwjaar`` onto every feature of *buildings_fc*.

    Matching is tried in two steps per building feature:

    1. **By id** — ``properties[ref_bag_property]`` (the OSM ``ref:bag`` tag)
       is looked up directly in the BAG pand ``identificatie`` index.
    2. **By geometry** — when there is no tag, or its value is not a known
       BAG pand, the building's centroid is tested against every BAG pand
       polygon; the pand whose polygon contains the centroid wins.

    Does not mutate *buildings_fc* or *bag_fc*; returns a new
    FeatureCollection.  Fail-open: when *bag_fc* has no features (e.g. the
    bbox was outside the Netherlands), every building gets
    ``bagBouwjaar=None``, ``bagIdentificatie=None``, ``_bagMatch=None``.

    Returns
    -------
    fc:
        *buildings_fc* with three new properties on every feature:
        ``bagBouwjaar`` (int or None), ``bagIdentificatie`` (str or None),
        ``_bagMatch`` (``"id"`` | ``"centroid"`` | None).
    stats:
        ``{"matched_by_id": int, "matched_by_centroid": int,
        "unmatched": int, "total": int}``.
    """
    by_id: dict[str, int | None] = {}
    for feat in bag_fc.get("features") or []:
        props = feat.get("properties") or {}
        ident = props.get("identificatie")
        if ident:
            by_id[str(ident)] = props.get("bouwjaar")

    buildings = buildings_fc.get("features") or []
    stats = {
        "matched_by_id": 0,
        "matched_by_centroid": 0,
        "unmatched": 0,
        "total": len(buildings),
    }

    if not by_id:
        out_features = [_tag_no_match(feat) for feat in buildings]
        stats["unmatched"] = len(buildings)
        return {**buildings_fc, "features": out_features}, stats

    tree, pand_records = _build_pand_index(bag_fc)

    out_features = []
    for feat in buildings:
        props = feat.get("properties") or {}
        raw_ref = props.get(ref_bag_property)
        ref = str(raw_ref) if raw_ref else None

        if ref is not None and ref in by_id:
            out_features.append(_tag_match(feat, ref, by_id[ref], "id"))
            stats["matched_by_id"] += 1
            continue

        match = _match_by_centroid(feat, tree, pand_records) if tree is not None else None
        if match is not None:
            matched_ident, matched_bouwjaar = match
            out_features.append(_tag_match(feat, matched_ident, matched_bouwjaar, "centroid"))
            stats["matched_by_centroid"] += 1
            continue

        out_features.append(_tag_no_match(feat))
        stats["unmatched"] += 1

    return {**buildings_fc, "features": out_features}, stats


def _tag_match(feature: dict, identificatie: str, bouwjaar: int | None, how: str) -> dict:
    props = {
        **(feature.get("properties") or {}),
        "bagBouwjaar": bouwjaar,
        "bagIdentificatie": identificatie,
        "_bagMatch": how,
    }
    return {**feature, "properties": props}


def _tag_no_match(feature: dict) -> dict:
    props = {
        **(feature.get("properties") or {}),
        "bagBouwjaar": None,
        "bagIdentificatie": None,
        "_bagMatch": None,
    }
    return {**feature, "properties": props}


def _build_pand_index(bag_fc: dict) -> tuple[Any, list[tuple[str | None, int | None]]]:
    """Build a shapely STRtree over BAG pand polygons for centroid matching.

    Returns ``(tree, records)`` where *records* is a list of
    ``(identificatie, bouwjaar)`` tuples in the same order as the geometries
    fed to the tree, so a query result index maps directly into *records*
    (same pattern as ``road_enricher_core``'s ``STRtree`` usage).  Returns
    ``(None, [])`` when there are no usable pand polygons.
    """
    from shapely import STRtree
    from shapely.geometry import shape

    geoms = []
    records: list[tuple[str | None, int | None]] = []
    for feat in bag_fc.get("features") or []:
        geom = feat.get("geometry")
        if not geom:
            continue
        try:
            shapely_geom = shape(geom)
        except Exception:
            continue
        props = feat.get("properties") or {}
        geoms.append(shapely_geom)
        records.append((props.get("identificatie"), props.get("bouwjaar")))

    if not geoms:
        return None, []
    return STRtree(geoms), records


def _match_by_centroid(
    feature: dict,
    tree: Any,
    records: list[tuple[str | None, int | None]],
) -> tuple[str, int | None] | None:
    """Return ``(identificatie, bouwjaar)`` for the BAG pand whose polygon
    contains *feature*'s centroid, or None when no pand polygon matches."""
    from shapely.geometry import shape

    geom = feature.get("geometry")
    if not geom:
        return None
    try:
        centroid = shape(geom).centroid
    except Exception:
        return None

    # STRtree predicates are evaluated as predicate(query_geometry, tree_geometry),
    # so "a pand polygon contains the centroid" is queried as "within".
    for idx in tree.query(centroid, predicate="within"):
        ident, bouwjaar = records[int(idx)]
        if ident is None:
            continue
        return str(ident), bouwjaar
    return None
