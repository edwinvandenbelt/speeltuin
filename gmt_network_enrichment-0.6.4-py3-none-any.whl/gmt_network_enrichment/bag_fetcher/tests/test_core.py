"""Unit tests for bag_fetcher core (pure functions + stubbed OGC client)."""

from __future__ import annotations

from gmt_network_enrichment.bag_fetcher.core.bag_fetcher_core import (
    BAG_QUERY_VER,
    BOUWJAAR_UNKNOWN,
    COLLECTION_PAND,
    DEFAULT_REF_BAG_PROPERTY,
    fetch_bag_panden,
    merge_bag_bouwjaar,
    parse_bouwjaar,
)

# NL bbox (Lochem-ish) and a non-NL bbox (Paris) — same bboxes as bgt_fetcher's tests.
_NL_BBOX = [6.39, 52.14, 6.43, 52.17]
_PARIS_BBOX = [2.2, 48.8, 2.4, 48.9]


def _square(cx: float, cy: float, half: float = 0.001) -> dict:
    return {
        "type": "Polygon",
        "coordinates": [
            [
                [cx - half, cy - half],
                [cx + half, cy - half],
                [cx + half, cy + half],
                [cx - half, cy + half],
                [cx - half, cy - half],
            ]
        ],
    }


def _building(ref_bag: str | None, cx: float, cy: float) -> dict:
    props: dict = {"buildingType": "house"}
    if ref_bag is not None:
        props[DEFAULT_REF_BAG_PROPERTY] = ref_bag
    return {"type": "Feature", "geometry": _square(cx, cy), "properties": props}


def _pand(identificatie: str, bouwjaar: int | None, cx: float, cy: float) -> dict:
    return {
        "type": "Feature",
        "geometry": _square(cx, cy),
        "properties": {"identificatie": identificatie, "bouwjaar": bouwjaar},
    }


def _fc(features: list[dict]) -> dict:
    return {"type": "FeatureCollection", "features": features, "properties": {}}


# ---------------------------------------------------------------------------
# parse_bouwjaar
# ---------------------------------------------------------------------------


def test_parse_bouwjaar_normal_int() -> None:
    assert parse_bouwjaar(1991) == 1991


def test_parse_bouwjaar_numeric_string() -> None:
    assert parse_bouwjaar("1975") == 1975


def test_parse_bouwjaar_none() -> None:
    assert parse_bouwjaar(None) is None


def test_parse_bouwjaar_unknown_sentinel() -> None:
    assert parse_bouwjaar(BOUWJAAR_UNKNOWN) is None
    assert parse_bouwjaar("9999") is None


def test_parse_bouwjaar_unparsable() -> None:
    assert parse_bouwjaar("onbekend") is None


# ---------------------------------------------------------------------------
# fetch_bag_panden
# ---------------------------------------------------------------------------


def test_fetch_bag_panden_skips_outside_nl() -> None:
    fc, stats = fetch_bag_panden(_PARIS_BBOX)
    assert stats["source"] == "skipped"
    assert stats["total"] == 0
    assert fc["features"] == []


def test_fetch_bag_panden_normalises_bouwjaar(monkeypatch) -> None:
    def _fake_fetch(collection: str, _bbox: list[float], **_kwargs) -> list[dict]:
        assert collection == COLLECTION_PAND
        return [
            {
                "type": "Feature",
                "geometry": _square(6.40, 52.15),
                "properties": {"identificatie": "0003100000117485", "bouwjaar": 1991},
            },
            {
                "type": "Feature",
                "geometry": _square(6.41, 52.16),
                "properties": {
                    "identificatie": "0003100000117486",
                    "bouwjaar": BOUWJAAR_UNKNOWN,
                },
            },
        ]

    monkeypatch.setattr("gmt_shared.ogc_features.fetch_collection_items", _fake_fetch, raising=True)

    fc, stats = fetch_bag_panden(_NL_BBOX)
    assert stats["source"] == "BAG"
    assert stats["total"] == 2
    assert fc["properties"]["_qv"] == BAG_QUERY_VER
    bouwjaren = {
        f["properties"]["identificatie"]: f["properties"]["bouwjaar"] for f in fc["features"]
    }
    assert bouwjaren["0003100000117485"] == 1991
    assert bouwjaren["0003100000117486"] is None


# ---------------------------------------------------------------------------
# merge_bag_bouwjaar
# ---------------------------------------------------------------------------


def test_merge_matches_by_ref_bag_id() -> None:
    buildings = _fc([_building("0003100000117485", 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1991, 10.0, 10.0)])

    merged, stats = merge_bag_bouwjaar(buildings, bag)

    props = merged["features"][0]["properties"]
    assert props["bagBouwjaar"] == 1991
    assert props["bagIdentificatie"] == "0003100000117485"
    assert props["_bagMatch"] == "id"
    assert stats == {"matched_by_id": 1, "matched_by_centroid": 0, "unmatched": 0, "total": 1}


def test_merge_falls_back_to_centroid_when_no_ref_bag_tag() -> None:
    # Building has no ref:bag tag, but its centroid lies inside the pand polygon.
    buildings = _fc([_building(None, 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1975, 10.0, 10.0)])

    merged, stats = merge_bag_bouwjaar(buildings, bag)

    props = merged["features"][0]["properties"]
    assert props["bagBouwjaar"] == 1975
    assert props["bagIdentificatie"] == "0003100000117485"
    assert props["_bagMatch"] == "centroid"
    assert stats["matched_by_centroid"] == 1


def test_merge_falls_back_to_centroid_when_ref_bag_tag_not_found() -> None:
    # Tag present but points to a pand id that was not fetched for this bbox.
    buildings = _fc([_building("unknown-id", 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1975, 10.0, 10.0)])

    merged, _stats = merge_bag_bouwjaar(buildings, bag)

    assert merged["features"][0]["properties"]["_bagMatch"] == "centroid"


def test_merge_unmatched_when_centroid_outside_every_pand() -> None:
    buildings = _fc([_building(None, 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1975, 50.0, 50.0)])

    merged, stats = merge_bag_bouwjaar(buildings, bag)

    props = merged["features"][0]["properties"]
    assert props["bagBouwjaar"] is None
    assert props["bagIdentificatie"] is None
    assert props["_bagMatch"] is None
    assert stats == {"matched_by_id": 0, "matched_by_centroid": 0, "unmatched": 1, "total": 1}


def test_merge_fail_open_when_bag_fc_empty() -> None:
    buildings = _fc([_building("0003100000117485", 10.0, 10.0), _building(None, 20.0, 20.0)])
    bag = _fc([])

    merged, stats = merge_bag_bouwjaar(buildings, bag)

    assert all(f["properties"]["_bagMatch"] is None for f in merged["features"])
    assert stats["unmatched"] == 2
    assert stats["total"] == 2


def test_merge_preserves_original_properties_and_geometry() -> None:
    buildings = _fc([_building("0003100000117485", 10.0, 10.0)])
    bag = _fc([_pand("0003100000117485", 1991, 10.0, 10.0)])

    merged, _stats = merge_bag_bouwjaar(buildings, bag)

    assert merged["features"][0]["properties"]["buildingType"] == "house"
    assert merged["features"][0]["geometry"]["type"] == "Polygon"
